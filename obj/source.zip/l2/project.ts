/// <mls shortName="project" project="102020" enhancement="_blank" groupName="other" />

export const projectConfig = {
  "modules": []
}