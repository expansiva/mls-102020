/// <mls fileReference="_102020_/l2/agentMaterializeL2/steps/shared40/run.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import test from 'node:test';
import type { Ns5FileInfo } from '/_102035_/l2/solution/fs.js';
import { runM4Input } from '/_102020_/l2/agentMaterializeL2/steps/input20/run.js';
import {
  M4_SHARED_RUNTIME_REFS, approveM4Shared, m4SharedRules, buildM4SharedContext, buildM4SharedPrompt, buildM4SharedRepairPrompt, m4AddedMemberFindings, m4SharedEnvironmentFailure, m4SharedReuseBlocker, mergeM4Findings, m4SharedToolFindings, m4SharedToolSchema, m4SharedToolSource, recordM4SharedAttempt, reusableM4Shared, studioSharedPort, type M4SharedPort,
} from '/_102020_/l2/agentMaterializeL2/steps/shared40/run.js';
import { createAgent as createSharedAgent } from '/_102020_/l2/agentMaterializeL2/steps/shared40/agentM4SharedPage.js';

interface Fixture {
  project: number; module: string; defsPipelineStatus: string; knownMolecules: string[]; knownTemplates: string[];
  pages: Record<string, { contract: string; shared: string; desktop: string; mobile: string }>;
}
const fixture = JSON.parse(readFileSync(new URL('../input20/fixtures/controleEstoque.json', import.meta.url), 'utf8')) as Fixture;
const reference = (JSON.parse(readFileSync(new URL('./fixtures/produtosShared.json', import.meta.url), 'utf8')) as { source: string }).source;
const promptText = readFileSync(new URL('./prompt.md', import.meta.url), 'utf8');
const repairText = readFileSync(new URL('./promptRepair.md', import.meta.url), 'utf8');
const identity = { project: fixture.project, module: fixture.module };
const key = (info: Ns5FileInfo) => `${info.project}/l${info.level}/${info.folder}/${info.shortName}${info.extension}`;
const DECLARATION = 'export declare class ControleEstoqueProdutosShared {}\n';

function listIn(files: Map<string, string>, project: number, folder: string, level: number): string[] {
  const prefix = `${project}/l${level}/${folder}/`;
  return [...files.keys()].filter(item => item.startsWith(prefix) && item.endsWith('.defs.ts') && !item.slice(prefix.length).includes('/')).map(item => item.slice(item.lastIndexOf('/') + 1, -'.defs.ts'.length));
}

/** In-memory Studio holding the module defs, the prompt, molecule indexes and template; compile is scripted. */
async function studio(compileErrors: string[] = []) {
  const files = new Map<string, string>();
  const put = (info: Ns5FileInfo, text: string) => files.set(key(info), text);
  const folders = { contract: 'web/contracts', shared: 'web/shared', desktop: 'web/desktop/page11', mobile: 'web/mobile/page11' } as const;
  for (const [pageId, row] of Object.entries(fixture.pages)) {
    for (const [kind, folder] of Object.entries(folders)) put({ project: identity.project, level: 2, folder: `${identity.module}/${folder}`, shortName: pageId, extension: '.defs.ts' }, row[kind as keyof typeof row]);
  }
  put({ project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2`, shortName: 'pipeline', extension: '.json' }, JSON.stringify({ status: 'complete' }));
  put({ project: 102020, level: 4, folder: 'collabux/templates/inventoryControl', shortName: 'page21', extension: '.md' }, '# template');
  for (const tag of fixture.knownMolecules) {
    const info = { project: 102040, level: 2, folder: `molecules/${tag.split('--')[0]}`, shortName: 'index', extension: '.defs.ts' };
    put(info, `${files.get(key(info)) ?? ''}{ tag: '${tag}' },\n`);
  }
  // The real L4 of the module, as the Studio serves it (level 4): module, rules, access, ontology/, journeys/.
  const l4Root = new URL(`../../../../../mls-102047/l4/${identity.module}/`, import.meta.url);
  for (const sub of ['', 'ontology/', 'journeys/']) {
    const dir = new URL(sub, l4Root);
    if (!existsSync(dir)) continue;
    for (const name of readdirSync(dir).filter(item => item.endsWith('.defs.ts'))) {
      put({ project: identity.project, level: 4, folder: `${identity.module}${sub ? `/${sub.slice(0, -1)}` : ''}`, shortName: name.slice(0, -'.defs.ts'.length), extension: '.defs.ts' }, readFileSync(new URL(name, dir), 'utf8'));
    }
  }
  put({ project: 102020, level: 2, folder: 'agentMaterializeL2/steps/shared40', shortName: 'prompt', extension: '.md' }, promptText);
  put({ project: 102020, level: 2, folder: 'agentMaterializeL2/steps/shared40', shortName: 'promptRepair', extension: '.md' }, repairText);
  const compiled: string[] = [];
  const declared: string[][] = [];
  const port: M4SharedPort & { files: Map<string, string>; compiled: string[]; declared: string[][] } = {
    files, compiled, declared,
    declarations: async refs => { declared.push([...refs]); return refs.map(ref => ({ ref, declaration: ref.endsWith('stateLitElement.js') ? 'export declare abstract class StateLitElement {}' : `declare module ${ref}` })); },
    read: async info => { const text = files.get(key(info)); if (text === undefined) throw new Error(`file not found: ${key(info)}`); return text; },
    exists: info => files.has(key(info)),
    readJson: async <T>(info: Ns5FileInfo) => { const text = files.get(key(info)); return text === undefined ? null : JSON.parse(text) as T; },
    writeText: async (info, text) => { files.set(key(info), text); },
    writeJson: async (info, value) => { files.set(key(info), JSON.stringify(value)); },
    deleteText: async info => { files.delete(key(info)); },
    listDefs: (project, folder, level) => listIn(files, project, folder, level),
    compile: async (info, source) => { compiled.push(key(info)); return compileErrors.length ? { errors: compileErrors, declaration: null } : { errors: [], declaration: source.includes('export class') ? DECLARATION : '' }; },
  };
  await runM4Input(identity, {
    listDefs: (project, folder, level = 2) => listIn(files, project, folder, level),
    exists: port.exists, read: port.read, readJson: port.readJson, write: port.writeJson,
  });
  return port;
}

test('an empty draft stays quiet and a reference list loads whole', () => {
  for (const needle of [
    'When the draft has nothing to send and no required leaf is empty, do not call and do not publish an error: the status stays as it was.',
    'A paged query whose state feeds the options of a selector',
    'loads **every page** on open, up to 500 items',
    "searches on the server through that query's own search parameter",
  ]) assert.ok(promptText.includes(needle), needle);
});

test('the prompt carries target, contract, shared, organisms, the methods the pages call and the notes', async () => {
  const port = await studio();
  const context = await buildM4SharedContext(identity, 'produtos', port);
  const { systemPrompt, humanPrompt } = await buildM4SharedPrompt(context, port);
  assert.equal(systemPrompt, promptText);
  for (const needle of [
    '- path: _102047_/l2/controleEstoque/web/shared/produtos.ts',
    '- class: ControleEstoqueProdutosShared',
    '- contract import: /_102047_/l2/controleEstoque/web/contracts/produtos.defs.js',
    'export interface ProdutosContracts',
    '"cadastrarProduto.input"',
    '- alertasSaldoBaixo (highlights):',
    'Intents: abrirMovimentacoes/navigate→movimentacoes',
    '# Methods the pages call',
    '- cadastrarProduto',
    '- abrirMovimentacoes',
    '# Navigations',
    '- abrirMovimentacoes (organism detalheProduto) → /controleEstoque/movimentacoes; entry params of movimentacoes: produtoId, page',
    '# Business context (L4)',
    '## Entities (meaning and field titles)',
    '# Notes on the defs',
    '# Runtime declarations (the real types you code against)',
    '## /_102029_/l2/stateLitElement.js',
    'export declare abstract class StateLitElement',
  ]) assert.ok(humanPrompt.includes(needle), needle);
  assert.deepEqual(port.declared[0], M4_SHARED_RUNTIME_REFS);
});

test('a repair is a focused fix (agentFix style): errors, refused file, its import declarations, ids to keep', async () => {
  const port = await studio();
  const context = await buildM4SharedContext(identity, 'produtos', port);
  const diagnostic = "M4_SHARED_COMPILE:\nline 94:37 - TS2540 - Cannot assign to 'childNodes' because it is a read-only property. (and 67 more of the same error at this position)\n    > this[member] = value;";
  const { systemPrompt, humanPrompt } = await buildM4SharedRepairPrompt(context, { diagnostic, previous: reference }, port);
  assert.equal(systemPrompt, repairText);
  assert.ok(!humanPrompt.includes('# Organisms'), 'not the generation prompt again');
  for (const needle of [
    '# Ids to keep',
    '- states: listaProdutos, filtroBuscaProdutos, paginaProdutos, produtoSelecionado, produtoCadastro, produtoCadastrado, scenary',
    '- methods: load, cadastrarProduto, abrirMovimentacoes, setScenario',
    '- routes: controleEstoque.produtos.load, controleEstoque.produtos.cadastrarProduto',
    '# Errors', 'TS2540', '# Refused file', 'export class ControleEstoqueProdutosShared',
    '# Import declarations', '## /_102033_/l2/shared/layout/auraNavigate.js',
    'export interface ProdutosContracts',
  ]) assert.ok(humanPrompt.includes(needle), needle);
  assert.deepEqual(port.declared[0].sort(), [
    '/_102029_/l2/bffClient.js', '/_102029_/l2/collabState.js', '/_102029_/l2/interactionRuntime.js', '/_102029_/l2/stateLitElement.js',
    '/_102033_/l2/shared/layout/auraNavigate.js', '/_102047_/l2/controleEstoque/web/contracts/produtos.defs.js',
  ], 'the imports of the refused file, read from its source');
  assert.match(repairText, /^<!-- modelType: code -->/u);
  assert.match(repairText, /TS2540[\s\S]*keyof <ClassName>/u);
});

test('approval writes the source, compiles it, writes the declaration and a receipt; then the unit is reused', async () => {
  const port = await studio();
  const context = await buildM4SharedContext(identity, 'produtos', port);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), false);
  const receipt = await approveM4Shared(context, reference, 1, port);
  assert.equal(receipt.sourcePath, 'l2/controleEstoque/web/shared/produtos.ts');
  assert.equal(receipt.declarationPath, 'l2/controleEstoque/web/shared/produtosDts.txt');
  assert.deepEqual(port.compiled, ['102047/l2/controleEstoque/web/shared/produtos.ts']);
  assert.equal(port.files.get('102047/l2/controleEstoque/web/shared/produtosDts.txt'), DECLARATION);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true);
  const written = port.files.get('102047/l2/controleEstoque/web/shared/produtos.ts') ?? '';
  assert.match(written, /import \{ wasRebuiltByStudio \} from '\/_102033_\/l2\/shared\/elementSwapRegistry\.js';/u);
  assert.match(written, /if \(!wasRebuiltByStudio\(this\)\) this\.resetVisit\(\);/u);

  port.files.set('102047/l2/controleEstoque/web/shared/produtos.ts', `${reference}// edited by hand\n`);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true, 'a file that exists is kept');
});

test('a note change from input20 regenerates nothing: notes follow agent code (22/10)', async () => {
  const port = await studio();
  await approveM4Shared(await buildM4SharedContext(identity, 'produtos', port), reference, 1, port);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true);
  const path = '102047/l2/controleEstoque/pipeline/agentMaterializeL2/input.json';
  const snapshot = JSON.parse(port.files.get(path)!);
  const produtos = snapshot.pages.find((page: { pageId: string }) => page.pageId === 'produtos');
  produtos.problems = [...produtos.problems, { severity: 'warning', code: 'M4_INPUT_ROUTE_KIND', page: 'produtos', path: 'shared:requests.load', message: 'a new note' }];
  port.files.set(path, JSON.stringify(snapshot));
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true);
  const unit = produtos.units.find((item: { kind: string }) => item.kind === 'shared');
  unit.inputHash = 'sha256:the-defs-changed';
  port.files.set(path, JSON.stringify(snapshot));
  assert.equal(await m4SharedReuseBlocker(identity, 'produtos', port), null, 'a data change does not regenerate a file that exists');
});

test('shared is skipped when the .ts and the Dts.txt exist, receipt or not; only the .defs.ts means generate', async () => {
  const port = await studio();
  assert.equal(port.files.has('102047/l2/controleEstoque/web/shared/produtos.defs.ts'), true);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), false, 'only the .defs.ts is present');
  assert.equal(await m4SharedReuseBlocker(identity, 'produtos', port), 'l2/controleEstoque/web/shared/produtos.ts does not exist');
  await approveM4Shared(await buildM4SharedContext(identity, 'produtos', port), reference, 1, port);
  const receiptKey = '102047/l2/controleEstoque/pipeline/agentMaterializeL2/shared40/produtos.json';
  const receipt = JSON.parse(port.files.get(receiptKey)!);
  port.files.set(receiptKey, JSON.stringify({ ...receipt, sourceHash: 'sha256:other', unitInputHash: 'sha256:other' }));
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true, 'a receipt with a different hash does not decide');
  assert.equal(JSON.parse(port.files.get(receiptKey)!).sourceHash, 'sha256:other', 'reuse does not rewrite the receipt');
  port.files.delete(receiptKey);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true, 'no receipt');
  port.files.delete('102047/l2/controleEstoque/web/shared/produtosDts.txt');
  assert.equal(await m4SharedReuseBlocker(identity, 'produtos', port), 'l2/controleEstoque/web/shared/produtosDts.txt does not exist');
});

test('a prompt change regenerates nothing until --force (22/10)', async () => {
  const port = await studio();
  await approveM4Shared(await buildM4SharedContext(identity, 'produtos', port), reference, 1, port);
  port.files.set('102020/l2/agentMaterializeL2/steps/shared40/prompt.md', `${promptText}\nextra rule\n`);
  assert.equal(await reusableM4Shared(identity, 'produtos', port), true);
});

test('a gate refusal writes nothing; a compile error leaves no receipt', async () => {
  const port = await studio();
  const context = await buildM4SharedContext(identity, 'produtos', port);
  await assert.rejects(approveM4Shared(context, reference.replace('@property({ attribute: false }) filtroBuscaProdutos', 'filtroBuscaProdutos'), 1, port), /M4_SHARED_GATE:\nM4_SHARED_STATE_MISSING/u);
  assert.equal(port.files.has('102047/l2/controleEstoque/web/shared/produtos.ts'), false);

  const failing = await studio(["produtos.ts(10,1): error TS2304: Cannot find name 'x'."]);
  await assert.rejects(approveM4Shared(await buildM4SharedContext(identity, 'produtos', failing), reference, 1, failing), /M4_SHARED_COMPILE:\n.*TS2304/u);
  assert.equal(failing.files.has('102047/l2/controleEstoque/web/shared/produtos.ts'), false, 'a compile error removes the new file');
  assert.equal(await reusableM4Shared(identity, 'produtos', failing), false);
  const prior = `${reference}\n// previous\n`;
  const priorDts = 'export declare class Previous {}\n';
  failing.files.set('102047/l2/controleEstoque/web/shared/produtos.ts', prior);
  failing.files.set('102047/l2/controleEstoque/web/shared/produtosDts.txt', priorDts);
  await assert.rejects(approveM4Shared(await buildM4SharedContext(identity, 'produtos', failing), reference, 1, failing), /M4_SHARED_COMPILE:\n.*TS2304/u);
  assert.equal(failing.files.get('102047/l2/controleEstoque/web/shared/produtos.ts'), prior, 'a compile error restores the previous file');
  assert.equal(failing.files.get('102047/l2/controleEstoque/web/shared/produtosDts.txt'), priorDts, 'the declaration is left until it is written');
  failing.compile = async () => { throw new Error('compiler crashed'); };
  await assert.rejects(approveM4Shared(await buildM4SharedContext(identity, 'produtos', failing), reference, 1, failing), /compiler crashed/u);
  assert.equal(failing.files.get('102047/l2/controleEstoque/web/shared/produtos.ts'), prior);
  const writing = await studio();
  writing.files.set('102047/l2/controleEstoque/web/shared/produtosDts.txt', priorDts);
  let declarationWrites = 0;
  writing.writeText = async (info, text) => {
    if (info.extension === '.txt' && declarationWrites++ === 0) throw new Error('declaration write failed');
    writing.files.set(`${info.project}/l${info.level}/${info.folder}/${info.shortName}${info.extension}`, text);
  };
  await assert.rejects(approveM4Shared(await buildM4SharedContext(identity, 'produtos', writing), reference, 1, writing), /declaration write failed/u);
  assert.equal(writing.files.get('102047/l2/controleEstoque/web/shared/produtosDts.txt'), priorDts, 'a failed declaration write restores the previous declaration');
  assert.equal(writing.files.has('102047/l2/controleEstoque/web/shared/produtos.ts'), true, 'the compiled source stays');
});

test('a repair with the shared files present calls the model', async () => {
  const port = await studio();
  await approveM4Shared(await buildM4SharedContext(identity, 'produtos', port), reference, 1, port);
  const saved = { ...studioSharedPort };
  Object.assign(studioSharedPort, port);
  try {
    const agent = createSharedAgent();
    const ctx = { message: { orderAt: '1', threadId: 't' }, task: { PK: 'task' } } as mls.msg.ExecutionContext;
    const parent = { stepId: 1 } as mls.msg.AIAgentStep;
    const repair = JSON.stringify({ project: identity.project, module: identity.module, pageId: 'produtos', attempt: 2, diagnostic: 'TS2304', previous: reference });
    const intents = await agent.beforePromptStep!({} as never, ctx, parent, { prompt: repair, stepId: 2 } as mls.msg.AIAgentStep, 1);
    assert.equal(intents[0]?.type, 'prompt_ready');
  } finally {
    Object.assign(studioSharedPort, saved);
  }
});

test('a refused answer is kept for diagnosis next to the receipts', async () => {
  const port = await studio();
  await recordM4SharedAttempt(identity, 'produtos', 2, 'export class X {}', 'M4_SHARED_GATE:\nM4_SHARED_NAVIGATE: x */ y', port);
  const text = port.files.get('102047/l2/controleEstoque/pipeline/agentMaterializeL2/shared40/produtosAttempt2.txt')!;
  assert.match(text, /^\/\* refused: M4_SHARED_GATE:\nM4_SHARED_NAVIGATE: x \* \/ y \*\/\n\nexport class X \{\}\n$/u);
});

test('a defs change after input20 is refused as stale', async () => {
  const port = await studio();
  const path = '102047/l2/controleEstoque/web/shared/produtos.defs.ts';
  port.files.set(path, port.files.get(path)!.replace('"Produtos carregados"', '"Todos os produtos carregados"'));
  await assert.rejects(buildM4SharedContext(identity, 'produtos', port), /M4_SHARED_INPUT_STALE: produtos shared/u);
});

test('environment compile failures are told apart from code errors (no repair is spent on them)', () => {
  assert.equal(m4SharedEnvironmentFailure('M4_SHARED_COMPILE:\nStudio imports unavailable: _102033_/l2/shared/layout/auraNavigate.ts (fecthQl: Please connect to github!)'), true);
  assert.equal(m4SharedEnvironmentFailure('M4_SHARED_COMPILE:\nStudio TypeScript compiler is unavailable'), true);
  assert.equal(m4SharedEnvironmentFailure("M4_SHARED_COMPILE:\nline 3:5 - TS18047 - 'output' is possibly 'null'."), false);
  assert.equal(m4SharedEnvironmentFailure('M4_SHARED_GATE:\nM4_SHARED_NAVIGATE: x'), false);
});

test('the tool answer is read from object or JSON string arguments', () => {
  assert.equal(m4SharedToolSource({ arguments: { source: 'x' } }), 'x');
  assert.equal(m4SharedToolSource({ type: 'flexible', result: { toolName: 'submitSharedTs', arguments: '{"source":"y"}' } }), 'y');
  assert.throws(() => m4SharedToolSource({ type: 'flexible', result: { toolName: 'other', arguments: {} } }), /M4_SHARED_TOOL_MISMATCH/u);
});

test('findings (V5): the tool requires them, the receipt keeps them, malformed rows are dropped', async () => {
  assert.deepEqual(m4SharedToolSchema.required, ['source', 'findings']);
  const payload = { arguments: JSON.stringify({ source: 'x', findings: [{ code: 'FORM_DRAFT_MISSING', message: 'no input state for formularioProduto; added produtoCadastro' }, { code: 1 }] }) };
  assert.equal(m4SharedToolSource(payload), 'x');
  const findings = m4SharedToolFindings(payload);
  assert.deepEqual(findings.map(item => item.code), ['FORM_DRAFT_MISSING']);
  const port = await studio();
  const receipt = await approveM4Shared(await buildM4SharedContext(identity, 'produtos', port), reference, 1, port, findings);
  assert.deepEqual(receipt.findings, findings);
});

test('findings (V5) from the declaration: every public member the defs do not declare, even when the LLM forgets', async () => {
  const port = await studio();
  const context = await buildM4SharedContext(identity, 'produtos', port);
  const declaration = [
    'export declare class ControleEstoqueProdutosShared extends StateLitElement {',
    '    listaProdutos: ProdutoLoad[];',
    '    filtroBuscaProdutos: string | null;',
    "    loadStatus: 'idle' | 'loading';",
    '    scenary: string;',
    '    novoRascunho: { details: {',
    '        name: string | null;',
    '    } };',
    '    private publish;',
    '    connectedCallback(): void;',
    '    load(): Promise<void>;',
    '    setNovoRascunho(value: unknown): void;',
    '    get detalheProduto(): ProdutoLoad | null;',
    '}',
  ].join('\n');
  const added = m4AddedMemberFindings(declaration, context.target).map(item => item.message.split(' ')[1]);
  assert.deepEqual(added, ['detalheProduto', 'novoRascunho', 'setNovoRascunho']);
  assert.deepEqual(mergeM4Findings([{ code: 'A', message: 'x' }], [{ code: 'A', message: 'x' }, { code: 'B', message: 'y' }]).map(item => item.code), ['A', 'B']);
});

// 14/10/2026: a page21 folder brought notes of the variant (template not found…) into the page warnings, and every
// shared was regenerated. The shared is generated with the page11 notes only.
test('the notes of a UX variant never reach the shared rules', () => {
  const problems = [
    { severity: 'warning', code: 'M4_INPUT_RETURN_UNREAD', page: 'p', path: 'shared:requests.x.returns', message: 'a' },
    { severity: 'warning', code: 'M4_INPUT_TEMPLATE_MISSING', page: 'p', path: 'desktop:template.category', message: 'b' },
    { severity: 'warning', code: 'M4_INPUT_TEMPLATE_MISSING', page: 'p', path: 'page21/desktop:template.category', message: 'c' },
    { severity: 'warning', code: 'M4_INPUT_VARIANT_REFUSED', page: 'p', path: 'page21:', message: 'd' },
    { severity: 'error', code: 'M4_INPUT_ROUTE_MISSING', page: 'p', path: 'shared:requests.y', message: 'e' },
  ];
  assert.deepEqual(m4SharedRules(problems).map(item => item.message), ['a', 'b']);
});
