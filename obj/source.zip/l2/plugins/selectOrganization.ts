/// <mls fileReference="_102020_/l2/plugins/selectOrganization.ts" enhancement="_102027_/l2/enhancementLit.ts"/>

import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import '/_102020_/l2/plugins/markdownViewer.js';

// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Select Organization',
    desc: 'An organization groups multiple projects under the same umbrella. Select one to browse the projects available to your team.',
    allTitle: 'All Organizations',
    allDesc: 'Overview of all organizations available in the system.',
    customTitle: 'New Organization',
    customDesc: 'Create a new organization to group your projects.',
    projects: 'projects',
    noOrgs: 'No organizations found.',
    createNew: 'Create new organization',
    inDevelopment: 'In development',
    edit: 'Edit',
    cancel: 'Cancel',
    save: 'Save',
};
type MessageType = typeof message_en;
const messages: Record<string, MessageType> = {
    en: message_en,
    pt: {
        title: 'Selecionar Organização',
        desc: 'Uma organização agrupa vários projetos sob o mesmo guarda-chuva. Selecione uma para navegar pelos projetos disponíveis para o seu time.',
        allTitle: 'Todas as Organizações',
        allDesc: 'Visão geral de todas as organizações disponíveis no sistema.',
        customTitle: 'Nova Organização',
        customDesc: 'Crie uma nova organização para agrupar seus projetos.',
        projects: 'projetos',
        noOrgs: 'Nenhuma organização encontrada.',
        createNew: 'Criar nova organização',
        inDevelopment: 'Em desenvolvimento',
        edit: 'Editar',
        cancel: 'Cancelar',
        save: 'Salvar',
    },
    es: {
        title: 'Seleccionar Organización',
        desc: 'Una organización agrupa múltiples proyectos bajo el mismo paraguas. Seleccione una para explorar los proyectos disponibles para su equipo.',
        allTitle: 'Todas las Organizaciones',
        allDesc: 'Visión general de todas las organizaciones disponibles en el sistema.',
        customTitle: 'Nueva Organización',
        customDesc: 'Cree una nueva organización para agrupar sus proyectos.',
        projects: 'proyectos',
        noOrgs: 'No se encontraron organizaciones.',
        createNew: 'Crear nueva organización',
        inDevelopment: 'En desarrollo',
        edit: 'Editar',
        cancel: 'Cancelar',
        save: 'Guardar',
    },
};
/// **collab_i18n_end**

// ─── Types ───────────────────────────────────────────────────────────

interface IProject {
    project: number;
    name: string;
    doSelect: boolean;
}

interface IOrg {
    name: string;
    created_at: string;
    description: string;
    key: string;
    index: number;
    projects: IProject[];
}

// ─── Component ───────────────────────────────────────────────────────

@customElement('plugins--select-organization-102020')
export class PluginSelectOrganization extends StateLitElement {

    @property({ attribute: false }) orgs: IOrg[] = [];
    @property({ attribute: false }) value: number | null = null;

    @state() private _editing: boolean = false;
    @state() private _editText: string = '';
    private readonly _descriptions: Map<string, string> = new Map();

    willUpdate(changed: Map<string, unknown>) {
        if (changed.has('value')) this._editing = false;
    }

    private get msg(): MessageType {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }

    private get _isAll(): boolean {
        return this.value === 0;
    }

    private get _isCustom(): boolean {
        return this.value !== null && this.value > this.orgs.length;
    }

    private get _selectedOrg(): IOrg | null {
        if (this.value === null || this.value <= 0 || this.value > this.orgs.length) return null;
        return this.orgs[this.value - 1];
    }

    createRenderRoot() { return this; }

    render() {
        if (this._isAll) return this._renderAll();
        if (this._isCustom) return this._renderCustom();
        return this._renderSelected();
    }

    private _renderSelected() {
        const org = this._selectedOrg;
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, null, this.msg.desc)}
                ${org ? this._renderSelectedOrgDetail(org) : nothing}
            </div>
        `;
    }

    private _renderSelectedOrgDetail(org: IOrg) {
        const date = org.created_at
            ? new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short' }).format(new Date(org.created_at))
            : null;
        const description = this._descriptions.get(org.key) ?? org.description ?? '';
        return html`
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5
            ">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-xs font-semibold text-gray-700 dark:text-gray-300">${org.name}</span>
                    ${date ? html`<span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">(${date})</span>` : nothing}
                    <span class="text-gray-300 dark:text-gray-700">·</span>
                    <span class="
                        text-[10px] px-2 py-0.5 rounded-full font-medium
                        bg-indigo-100 dark:bg-indigo-900/30
                        text-indigo-600 dark:text-indigo-400
                    ">${org.projects.length} ${this.msg.projects}</span>
                </div>
            </div>

            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-3 flex flex-col gap-2
            ">
                ${this._editing
                    ? this._renderEditMode(org, description)
                    : this._renderViewMode(description)}
            </div>
        `;
    }

    private _renderViewMode(description: string) {
        return html`
            <div class="flex items-start gap-2">
                <div class="flex-1 min-w-0">
                    ${description
                        ? html`<plugins--markdown-viewer-102020 .text=${description}></plugins--markdown-viewer-102020>`
                        : html`<span class="text-xs text-gray-400 dark:text-gray-600 italic">—</span>`}
                </div>
                <button
                    class="
                        shrink-0 text-[10px] px-2 py-0.5 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-400 dark:text-gray-600
                        hover:text-gray-600 dark:hover:text-gray-400
                        hover:border-gray-300 dark:hover:border-gray-600
                        transition-colors
                    "
                    @click=${() => { this._editText = description; this._editing = true; }}
                >${this.msg.edit}</button>
            </div>
        `;
    }

    private _renderEditMode(org: IOrg, description: string) {
        return html`
            <textarea
                class="
                    w-full text-xs font-mono leading-relaxed resize-none
                    bg-white dark:bg-gray-900
                    border border-gray-300 dark:border-gray-700 rounded-md
                    px-2.5 py-2
                    text-gray-700 dark:text-gray-300
                    placeholder-gray-400 dark:placeholder-gray-600
                    focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                "
                rows="6"
                .value=${this._editText || description}
                @input=${(e: Event) => { this._editText = (e.target as HTMLTextAreaElement).value; }}
            ></textarea>
            <div class="flex justify-end gap-2">
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-500 dark:text-gray-400
                        hover:bg-gray-100 dark:hover:bg-gray-800
                        transition-colors
                    "
                    @click=${() => { this._editing = false; }}
                >${this.msg.cancel}</button>
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors
                    "
                    @click=${() => {
                        this._descriptions.set(org.key, this._editText);
                        this._editing = false;
                        this.requestUpdate();
                    }}
                >${this.msg.save}</button>
            </div>
        `;
    }

    private _renderAll() {
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.allTitle, null, this.msg.allDesc)}
                ${this.orgs.length === 0
                    ? html`<span class="text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noOrgs}</span>`
                    : html`
                        <div class="flex flex-col gap-1.5">
                            ${this.orgs.map((org, i) => this._renderOrgCard(org, i + 1))}
                        </div>
                    `}
                <button
                    class="self-start text-xs text-indigo-500 dark:text-indigo-400 hover:underline"
                    @click=${() => this._dispatchSelect(this.orgs.length + 1)}
                >+ ${this.msg.createNew}</button>
            </div>
        `;
    }

    private _renderCustom() {
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.customTitle, null, this.msg.customDesc)}
                <div class="
                    rounded-lg border border-amber-200 dark:border-amber-800/40
                    bg-amber-50 dark:bg-amber-900/10
                    px-3 py-2.5
                ">
                    <span class="text-xs text-amber-600 dark:text-amber-400">${this.msg.inDevelopment}</span>
                </div>
            </div>
        `;
    }

    private _renderHeader(title: string, badge: string | null, description: string) {
        return html`
            <div class="flex flex-col gap-1">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    ${badge ? html`
                        <span class="
                            text-[10px] font-mono px-1.5 py-0.5 rounded
                            bg-gray-100 dark:bg-gray-800
                            text-gray-500 dark:text-gray-400
                        ">${badge}</span>
                    ` : nothing}
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">
                    ${description}
                </span>
            </div>
        `;
    }

    private _renderOrgCard(org: IOrg, selectValue?: number) {
        const clickable = selectValue !== undefined;
        return html`
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center justify-between
                    ${clickable ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors' : ''}
                "
                @click=${clickable ? () => this._dispatchSelect(selectValue!) : nothing}
            >
                <span class="text-xs font-medium text-gray-700 dark:text-gray-300">${org.name}</span>
                <span class="
                    text-[10px] px-2 py-0.5 rounded-full font-medium
                    bg-indigo-100 dark:bg-indigo-900/30
                    text-indigo-600 dark:text-indigo-400
                ">${org.projects.length} ${this.msg.projects}</span>
            </div>
        `;
    }

    private _dispatchSelect(value: number) {
        this.dispatchEvent(new CustomEvent('select-org', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
}
