/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/effort40/gate.ts" enhancement="_blank"/>

import {
  P2_EFFORT_ENDPOINT_KINDS,
  P2_EFFORT_REMOVED_KINDS,
  P2_EFFORT_SCHEMA_VERSION,
  P2_EFFORT_STATUSES,
  P2_TEST_SUPPORT_OWNERS,
  countP2EffortStatuses,
  isP2EffortEndpointKind,
  isP2EffortRemovedKind,
  isP2EffortStatus,
  isP2TestSupportOwner,
  p2StatusFromMenuAction,
} from '/_102020_/l2/agentPlannerL2/steps/effort40/contracts.js';
import type {
  MenuStampedNode,
  MenuStampedPageNode,
  PoolEffortFile,
  PoolEffortTotalsBucket,
  PoolMenuFile,
  PoolTestSupportItem,
} from '/_102035_/l2/solution/poolPlan.js';

export interface P2EffortGateIssue {
  severity: 'error' | 'warning';
  code: string;
  message: string;
  path?: string;
}

export interface P2EffortGateResult {
  ok: boolean;
  issues: P2EffortGateIssue[];
}

export function validateP2Effort(
  file: PoolEffortFile,
  menu: PoolMenuFile,
  options?: { screenStatusFromAction?: boolean },
): P2EffortGateResult {
  const issues: P2EffortGateIssue[] = [];
  if (file.schemaVersion !== P2_EFFORT_SCHEMA_VERSION) {
    error(issues, 'P2_EFFORT_SCHEMA', `schemaVersion must be ${P2_EFFORT_SCHEMA_VERSION}.`, '$.schemaVersion');
  }

  const fromAction = options?.screenStatusFromAction !== false;
  const menuPages = stampedPages(menu.tree);
  const screenIds = new Set(file.screens.map(screen => screen.pageId));
  for (const page of menuPages) {
    const screen = file.screens.find(item => item.pageId === page.id);
    if (!screen) {
      error(issues, 'P2_EFFORT_SCREEN_MISSING', `Menu page ${page.id} is missing from screens.`, '$.screens');
      continue;
    }
    if (!fromAction) continue;
    const expected = p2StatusFromMenuAction(page.action);
    if (screen.status !== expected) {
      error(
        issues,
        'P2_EFFORT_SCREEN_STATUS',
        `Screen ${page.id} status must be ${expected} from action ${page.action}.`,
        `$.screens[pageId=${page.id}].status`,
      );
    }
  }
  if (fromAction) {
    for (const page of stampedPages(menu.meta.removed)) {
      if (screenIds.has(page.id) && menuPages.some(item => item.id === page.id)) continue;
      const screen = file.screens.find(item => item.pageId === page.id);
      if (!screen) {
        error(issues, 'P2_EFFORT_SCREEN_MISSING', `Removed page ${page.id} is missing from screens.`, '$.screens');
      } else if (screen.status !== 'toRemove') {
        error(
          issues,
          'P2_EFFORT_SCREEN_STATUS',
          `Removed page ${page.id} status must be toRemove.`,
          `$.screens[pageId=${page.id}].status`,
        );
      }
    }
  }

  const usecaseIds = new Set(file.usecases.map(item => item.usecaseId));
  file.endpoints.forEach((endpoint, index) => {
    const path = `$.endpoints[${index}]`;
    if (!isP2EffortEndpointKind(endpoint.kind)) {
      error(issues, 'P2_EFFORT_KIND', `kind must be ${P2_EFFORT_ENDPOINT_KINDS.join('|')}.`, `${path}.kind`);
    }
    if (!isP2EffortStatus(endpoint.status)) {
      error(issues, 'P2_EFFORT_STATUS', `status must be ${P2_EFFORT_STATUSES.join('|')}.`, `${path}.status`);
    }
    if (!usecaseIds.has(endpoint.usecaseRef)) {
      error(issues, 'P2_EFFORT_USECASE_REF', `Unknown usecaseRef ${endpoint.usecaseRef}.`, `${path}.usecaseRef`);
    }
  });

  file.screens.forEach((screen, index) => {
    if (!isP2EffortStatus(screen.status)) {
      error(issues, 'P2_EFFORT_STATUS', `status must be ${P2_EFFORT_STATUSES.join('|')}.`, `$.screens[${index}].status`);
    }
  });
  file.usecases.forEach((usecase, index) => {
    if (!isP2EffortStatus(usecase.status)) {
      error(issues, 'P2_EFFORT_STATUS', `status must be ${P2_EFFORT_STATUSES.join('|')}.`, `$.usecases[${index}].status`);
    }
  });
  file.tables.forEach((table, index) => {
    if (!isP2EffortStatus(table.status)) {
      error(issues, 'P2_EFFORT_STATUS', `status must be ${P2_EFFORT_STATUSES.join('|')}.`, `$.tables[${index}].status`);
    }
  });
  if (!Array.isArray(file.testSupport)) {
    error(issues, 'P2_EFFORT_TEST_SUPPORT', 'testSupport must be an array.', '$.testSupport');
  } else {
    file.testSupport.forEach((item, index) => validateTestSupport(issues, item, index));
  }
  file.removed.forEach((row, index) => {
    const path = `$.removed[${index}]`;
    if (!isP2EffortRemovedKind(row.kind)) {
      error(issues, 'P2_EFFORT_REMOVED_KIND', `kind must be ${P2_EFFORT_REMOVED_KINDS.join('|')}.`, `${path}.kind`);
    }
    if (row.status !== 'toRemove') {
      error(issues, 'P2_EFFORT_STATUS', 'removed status must be toRemove.', `${path}.status`);
    }
  });

  checkTotals(issues, 'screens', file.totals.screens, countP2EffortStatuses(file.screens));
  checkTotals(issues, 'endpoints', file.totals.endpoints, countP2EffortStatuses(file.endpoints));
  checkTotals(issues, 'usecases', file.totals.usecases, countP2EffortStatuses(file.usecases));
  checkTotals(issues, 'tables', file.totals.tables, countP2EffortStatuses(file.tables));

  return { ok: issues.every(issue => issue.severity !== 'error'), issues };
}

function validateTestSupport(issues: P2EffortGateIssue[], item: PoolTestSupportItem, index: number): void {
  const path = `$.testSupport[${index}]`;
  if (!item || typeof item !== 'object' || Array.isArray(item)) {
    error(issues, 'P2_EFFORT_TEST_SUPPORT', 'Each testSupport item must be an object.', path);
    return;
  }
  if (typeof item.id !== 'string' || !item.id.trim()) {
    error(issues, 'P2_EFFORT_TEST_SUPPORT', 'id must be a non-empty string.', `${path}.id`);
  }
  for (const field of ['actorRefs', 'entityRefs', 'sourceRefs'] as const) {
    if (!Array.isArray(item[field]) || item[field].some(ref => typeof ref !== 'string')) {
      error(issues, 'P2_EFFORT_TEST_SUPPORT', `${field} must be an array of strings.`, `${path}.${field}`);
    }
  }
  if (!isP2EffortStatus(item.status)) {
    error(issues, 'P2_EFFORT_STATUS', `status must be ${P2_EFFORT_STATUSES.join('|')}.`, `${path}.status`);
  }
  if (typeof item.owner !== 'string' || !isP2TestSupportOwner(item.owner)) {
    error(issues, 'P2_EFFORT_TEST_SUPPORT_OWNER', `owner must be ${P2_TEST_SUPPORT_OWNERS.join('|')}.`, `${path}.owner`);
  }
  for (const field of ['executorRef', 'cleanupRef', 'gap'] as const) {
    if (typeof item[field] !== 'string') {
      error(issues, 'P2_EFFORT_TEST_SUPPORT', `${field} must be a string.`, `${path}.${field}`);
    }
  }
}

export function formatP2EffortGate(issues: readonly P2EffortGateIssue[]): string {
  return issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
}

function checkTotals(
  issues: P2EffortGateIssue[],
  name: string,
  actual: PoolEffortTotalsBucket,
  expected: PoolEffortTotalsBucket,
): void {
  for (const status of P2_EFFORT_STATUSES) {
    if (actual[status] !== expected[status]) {
      error(
        issues,
        'P2_EFFORT_TOTALS',
        `totals.${name}.${status} is ${actual[status]}, expected ${expected[status]}.`,
        `$.totals.${name}.${status}`,
      );
    }
  }
}

function stampedPages(nodes: readonly MenuStampedNode[]): MenuStampedPageNode[] {
  const out: MenuStampedPageNode[] = [];
  const walk = (list: readonly MenuStampedNode[]) => {
    for (const node of list) {
      if (node.kind === 'page') out.push(node);
      else walk(node.children);
    }
  };
  walk(nodes);
  return out;
}

function error(issues: P2EffortGateIssue[], code: string, message: string, path?: string): void {
  issues.push({ severity: 'error', code, message, path });
}
