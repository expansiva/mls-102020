/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/needs30/contracts.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import {
  parseP2Grants,
  parseP2Processes,
  type P2ProcessView,
} from '/_102020_/l2/agentPlannerL2/steps/menu20/contracts.js';
import {
  parseP2L4Sources,
  type P2L4Sources,
} from '/_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.js';
import {
  buildP2NeedsFile,
  buildP2NeedsMessage,
  p2EntityFamily,
  p2NeedsSubject,
  p2WidestScope,
} from '/_102020_/l2/agentPlannerL2/steps/needs30/contracts.js';
import { validateP2Needs } from '/_102020_/l2/agentPlannerL2/steps/needs30/gate.js';
import type { PoolMenuFile, PoolNeedsPage } from '/_102035_/l2/solution/poolPlan.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const L4_FIXTURE = path.join(HERE, '../workspaces20/fixtures/mensalidadesAcademia');
const AGENDA_FIXTURE = path.join(HERE, 'fixtures/clinic_2509');
const WORKFLOWS = path.join(HERE, '../menu20/fixtures/workflows.defs.ts');
const MENU_PATH = path.join(HERE, 'fixtures/menu.json');
const AT = new Date(Date.UTC(2026, 8, 21, 12, 0, 0));

function extractDefsJson(source: string): unknown {
  const assignment = source.search(/export\s+const\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=/);
  const start = source.indexOf('{', Math.max(0, assignment));
  if (assignment < 0 || start < 0) throw new Error('no json object in defs');
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < source.length; index += 1) {
    const char = source[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === '\\') escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') { inString = true; continue; }
    if (char === '{') depth += 1;
    else if (char === '}') {
      depth -= 1;
      if (depth === 0) return JSON.parse(source.slice(start, index + 1));
    }
  }
  throw new Error('unbalanced defs json');
}

function readDefs(root: string, rel: string): unknown {
  return extractDefsJson(readFileSync(path.join(root, rel), 'utf8'));
}

function renameIds<T>(value: T, ids: Readonly<Record<string, string>>): T {
  if (typeof value === 'string') return (ids[value] || value) as T;
  if (Array.isArray(value)) return value.map(item => renameIds(item, ids)) as T;
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [ids[key] || key, renameIds(item, ids)])) as T;
}

function loadSources(): P2L4Sources {
  const journeyDir = path.join(L4_FIXTURE, 'journeys');
  const ontologyDir = path.join(L4_FIXTURE, 'ontology');
  const journeys = readdirSync(journeyDir)
    .filter(name => name.endsWith('.defs.ts') && name !== 'index.defs.ts')
    .sort()
    .map(name => readDefs(L4_FIXTURE, `journeys/${name}`));
  const ontologyEntities = readdirSync(ontologyDir)
    .filter(name => name.endsWith('.defs.ts') && name !== 'index.defs.ts')
    .sort()
    .map(name => readDefs(L4_FIXTURE, `ontology/${name}`));
  const moduleArtifact = readDefs(L4_FIXTURE, 'module.defs.ts') as { userLanguage?: string; moduleName?: string };
  return parseP2L4Sources({
    moduleName: moduleArtifact.moduleName,
    userLanguage: moduleArtifact.userLanguage,
    journeyIndex: readDefs(L4_FIXTURE, 'journeys/index.defs.ts'),
    journeys,
    access: readDefs(L4_FIXTURE, 'access.defs.ts'),
    ontologyIndex: readDefs(L4_FIXTURE, 'ontology/index.defs.ts'),
    ontologyEntities,
  });
}

function loadAgendaSources(): { sources: P2L4Sources; grants: ReturnType<typeof parseP2Grants> } {
  const journeyDir = path.join(AGENDA_FIXTURE, 'journeys');
  const ontologyDir = path.join(AGENDA_FIXTURE, 'ontology');
  const journeys = readdirSync(journeyDir)
    .filter(name => name.endsWith('.defs.ts') && name !== 'index.defs.ts')
    .sort()
    .map(name => readDefs(AGENDA_FIXTURE, `journeys/${name}`));
  const ontologyEntities = readdirSync(ontologyDir)
    .filter(name => name.endsWith('.defs.ts') && name !== 'index.defs.ts')
    .sort()
    .map(name => readDefs(AGENDA_FIXTURE, `ontology/${name}`));
  const moduleArtifact = readDefs(AGENDA_FIXTURE, 'module.defs.ts') as { userLanguage?: string; moduleName?: string };
  const access = readDefs(AGENDA_FIXTURE, 'access.defs.ts');
  const sources = parseP2L4Sources({
    moduleName: moduleArtifact.moduleName,
    userLanguage: moduleArtifact.userLanguage,
    journeyIndex: readDefs(AGENDA_FIXTURE, 'journeys/index.defs.ts'),
    journeys,
    access,
    ontologyIndex: readDefs(AGENDA_FIXTURE, 'ontology/index.defs.ts'),
    ontologyEntities,
  });
  return { sources, grants: parseP2Grants(access) };
}

function loadMenu(): PoolMenuFile {
  return JSON.parse(readFileSync(MENU_PATH, 'utf8')) as PoolMenuFile;
}

function loadBuilt() {
  const sources = loadSources();
  const grants = parseP2Grants(readDefs(L4_FIXTURE, 'access.defs.ts'));
  const processes = parseP2Processes(extractDefsJson(readFileSync(WORKFLOWS, 'utf8')));
  const menu = loadMenu();
  const file = buildP2NeedsFile({ menu, sources, grants, processes, now: AT });
  return { sources, grants, processes, menu, file };
}

function pageOf(pages: readonly PoolNeedsPage[], pageId: string): PoolNeedsPage {
  const page = pages.find(item => item.pageId === pageId);
  assert.ok(page, `missing page ${pageId}`);
  return page;
}

void test('family table of mensalidadesAcademia: Aluno mdm, IndicadoresAcademia ddm, rest tdm', () => {
  const sources = loadSources();
  const familyOf = (entityId: string) => {
    const entity = sources.entities.find(item => item.entityId === entityId);
    assert.ok(entity, entityId);
    return p2EntityFamily(entity);
  };
  assert.equal(familyOf('Aluno'), 'mdm');
  assert.equal(familyOf('IndicadoresAcademia'), 'ddm');
  assert.equal(familyOf('Plano'), 'tdm');
  assert.equal(familyOf('Matricula'), 'tdm');
  assert.equal(familyOf('Mensalidade'), 'tdm');
  assert.equal(familyOf('Pagamento'), 'tdm');
});

void test('widest scope wins own < related < organization', () => {
  assert.equal(p2WidestScope(['own', 'organization']), 'organization');
  assert.equal(p2WidestScope(['related', 'own']), 'related');
  assert.equal(p2WidestScope(['own']), 'own');
  assert.equal(p2WidestScope([]), '');
});

void test('mensalidadesAcademia pages: payments, plans, home, cancel transition', () => {
  const { file, menu, sources, grants } = loadBuilt();
  assert.equal(file.schemaVersion, '2026-09-21-p2-needs-v1');
  assert.equal(file.moduleName, 'mensalidadesAcademia');
  assert.equal(file.device, 'web');
  assert.equal(file.menuSchema, '2026-09-20-p2-menu-v2.2');
  assert.equal(file.meta.sourceMenu, 'pool/l2/web/menu.json');
  assert.equal(file.meta.generatedAt, AT.toISOString());
  assert.equal('entities' in menu.meta, false);

  const payments = pageOf(file.pages, 'mensalidades_pagamentos');
  assert.deepEqual(payments.actors, ['recepcao']);
  assert.deepEqual(payments.reads.map(item => item.entity), ['Matricula', 'Mensalidade', 'Pagamento']);
  assert.equal(payments.reads.find(item => item.entity === 'Mensalidade')?.scope, 'organization');
  assert.ok(payments.reads.find(item => item.entity === 'Mensalidade')?.from.includes(
    'journey:registrarPagamentoMensalidade/localizarMensalidade',
  ));
  assert.ok(payments.reads.find(item => item.entity === 'Mensalidade')?.derived.includes('details.situacao'));
  assert.ok(payments.reads.find(item => item.entity === 'Mensalidade')?.derived.includes('details.saldoDevedor'));
  assert.deepEqual(
    payments.writes.map(item => `${item.entity}:${item.operation}:${item.transitionRef}`),
    ['Pagamento:create:'],
  );
  assert.ok(payments.writes[0].from.includes('journey:registrarPagamentoMensalidade/registrarPagamento'));

  const plans = pageOf(file.pages, 'planos');
  assert.deepEqual(plans.actors, ['gerencia', 'recepcao']);
  assert.deepEqual(plans.reads.map(item => item.entity), ['Plano']);
  assert.deepEqual(
    plans.writes.map(item => `${item.entity}:${item.operation}`).sort(),
    ['Plano:create', 'Plano:update'],
  );
  assert.ok(plans.writes.every(item => item.from.includes('organism:form')));

  const home = pageOf(file.pages, 'inicio_recepcao');
  assert.deepEqual(home.writes, []);
  assert.ok(home.reads.every(item => item.from.some(from => from.startsWith('organism:'))));
  assert.ok(home.reads.some(item => item.entity === 'Mensalidade'));

  const mine = pageOf(file.pages, 'minha_matricula');
  assert.deepEqual(mine.actors, ['aluno']);
  assert.ok(mine.reads.some(item => item.entity === 'Matricula' && item.scope === 'own'));
  assert.deepEqual(
    mine.writes.map(item => `${item.entity}:${item.operation}:${item.transitionRef}`),
    ['Matricula:transition:cancelarMatricula'],
  );

  const recepcaoAluno = grants.find(item => item.grantId === 'alunoCancelarPropriaMatricula');
  assert.equal(recepcaoAluno?.dataScope.mode, 'own');
  const recepcaoCadastros = grants.find(item => item.grantId === 'recepcaoGerenciarCadastrosEcobrancas');
  assert.equal(recepcaoCadastros?.dataScope.mode, 'organization');
  assert.equal(grants.length, 5);

  const gate = validateP2Needs(file, menu, sources, grants);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));

});

void test('needs message is English, one line per page, current thread round', () => {
  const { file } = loadBuilt();
  const message = buildP2NeedsMessage({
    file,
    received: { thread: 'mensalidadesAcademia-20260918103000', round: 1, mode: 'implement' },
  });
  assert.equal(message.from, 'l2');
  assert.equal(message.to, 'l1');
  assert.equal(message.subject, p2NeedsSubject('mensalidadesAcademia'));
  assert.deepEqual(message.artifacts, ['pool/l1/web/needs.json']);
  assert.equal(message.round, 1);
  assert.equal(message.body.split('\n').length, file.pages.length);
  assert.match(message.body, /mensalidades_pagamentos: 3 reads \/ 1 writes/);
  assert.match(message.body, /inicio_recepcao: \d+ reads \/ 0 writes/);
  assert.equal(message.body.includes('lê'), false);
});

void test('inbox home reads the human-stage entity when entityRef is set, and nothing when it is not', () => {
  const { sources, grants, menu } = loadBuilt();
  const homeOnlyInbox = structuredClone(menu);
  const home = homeOnlyInbox.tree.find(node => node.id === 'inicio_recepcao');
  assert.ok(home && home.kind === 'page');
  home.organisms = [{ kind: 'inbox', text: 'What waits for you.' }];

  const humanProcess = (entityRef: string): P2ProcessView[] => [{
    processId: 'aprovarPedidoAcimaDoLimite',
    trigger: { kind: 'manual', schedule: '', event: '', actorRef: 'recepcao' },
    tasks: [{
      taskId: 'decidirPedidoEncaminhado',
      kind: 'human',
      description: 'The purchasing manager decides the forwarded order.',
      actorRef: 'recepcao',
      entityRef,
      effect: '',
      journeyRef: '',
      transitionRef: '',
    }],
  }];

  const withRef = buildP2NeedsFile({
    menu: homeOnlyInbox,
    sources,
    grants,
    processes: humanProcess('Mensalidade'),
    now: AT,
  });
  const inboxPage = pageOf(withRef.pages, 'inicio_recepcao');
  assert.deepEqual(inboxPage.writes, []);
  assert.deepEqual(inboxPage.reads.map(item => item.entity), ['Mensalidade']);
  assert.ok(inboxPage.reads[0].from.includes('organism:inbox'));
  assert.ok(inboxPage.reads[0].from.includes('grant:recepcaoGerenciarCadastrosEcobrancas'));

  const withoutRef = buildP2NeedsFile({
    menu: homeOnlyInbox,
    sources,
    grants,
    processes: humanProcess(''),
    now: AT,
  });
  const empty = pageOf(withoutRef.pages, 'inicio_recepcao');
  assert.deepEqual(empty.reads, []);
  assert.deepEqual(empty.writes, []);
});

void test('agenda derives only used, authorized relational reads with source and grant references', () => {
  const { sources, grants } = loadAgendaSources();
  const menu = structuredClone(loadMenu());
  const page = menu.tree.find(node => node.kind === 'page');
  assert.ok(page && page.kind === 'page');
  menu.tree = [
    { ...structuredClone(page), id: 'daily_schedule', label: 'Daily schedule', organisms: [{ kind: 'list', text: 'Review the patient and appointment assigned for the day.' }] },
    { ...structuredClone(page), id: 'phone_confirmation', label: 'Phone confirmation', organisms: [{ kind: 'detail', text: 'Confirm the selected patient appointment by telephone.' }] },
  ];
  menu.authorities = {
    'actor:profissional': ['daily_schedule'],
    'actor:recepcionista': ['phone_confirmation'],
  };
  menu.meta.journeys = {
    consultarAgendaDiaria: ['daily_schedule'],
    confirmarConsultaPorTelefone: ['phone_confirmation'],
  };
  menu.meta.processes = {};
  const file = buildP2NeedsFile({ menu, sources, grants, processes: [], now: AT });
  const daily = pageOf(file.pages, 'daily_schedule');
  const confirmation = pageOf(file.pages, 'phone_confirmation');

  const patient = daily.reads.find(item => item.entity === 'Paciente');
  assert.ok(patient, 'the professional agenda includes its related patient');
  assert.equal(patient.scope, 'related');
  assert.ok(patient.from.includes('journey:consultarAgendaDiaria/inspecionarAgendaDiaria'));
  assert.ok(patient.from.includes('relationship:Consulta/consultaPaciente'));
  assert.ok(patient.from.includes('grant:profissionalPacientesDaAgenda'));
  assert.equal(daily.reads.some(item => item.entity === 'ContatoPaciente'), false, 'a granted but unneeded contact is not read');

  const contact = confirmation.reads.find(item => item.entity === 'ContatoPaciente');
  assert.ok(contact, 'phone confirmation includes its related contact');
  assert.equal(contact.scope, 'organization');
  assert.ok(contact.from.includes('journey:confirmarConsultaPorTelefone/inspecionarConsulta'));
  assert.ok(contact.from.includes('relationship:ContatoPaciente/pacienteHasContact'));
  assert.ok(contact.from.includes('grant:recepcionistaGestaoAgenda'));

  const gate = validateP2Needs(file, menu, sources, grants);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));

  const ids: Record<string, string> = {
    Consulta: 'RecordA', Paciente: 'RecordB', ContatoPaciente: 'RecordC', Profissional: 'RecordD', Recepcionista: 'RecordE',
    consultaPaciente: 'linkA', consultaProfissional: 'linkB', pacienteHasContact: 'linkC',
    consultarAgendaDiaria: 'journeyA', confirmarConsultaPorTelefone: 'journeyB',
    localizarConsultasDoDia: 'stepA', inspecionarAgendaDiaria: 'stepB', localizarConsulta: 'stepC',
    inspecionarConsulta: 'stepD', registrarConfirmacaoTelefonica: 'stepE',
    recepcionistaGestaoAgenda: 'grantA', profissionalAgendaPropria: 'grantB', profissionalPacientesDaAgenda: 'grantC',
    daily_schedule: 'pageA', phone_confirmation: 'pageB',
  };
  const renamedSources = renameIds(structuredClone(sources), ids);
  renamedSources.entities.reverse();
  renamedSources.journeys.reverse();
  renamedSources.ontologyEntities.reverse();
  const renamedGrants = renameIds(structuredClone(grants), ids).reverse();
  const renamedMenu = renameIds(structuredClone(menu), ids);
  renamedMenu.authorities = Object.fromEntries(Object.entries(menu.authorities).reverse().map(([key, pages]) => [
    `actor:${ids[key.slice('actor:'.length)] || key.slice('actor:'.length)}`,
    [...pages].reverse().map(pageId => ids[pageId] || pageId),
  ]));
  renamedMenu.meta.journeys = Object.fromEntries(Object.entries(menu.meta.journeys).reverse().map(([journeyId, pageIds]) => [
    ids[journeyId] || journeyId,
    pageIds.map(pageId => ids[pageId] || pageId),
  ]));
  const renamedFile = buildP2NeedsFile({ menu: renamedMenu, sources: renamedSources, grants: renamedGrants, processes: [], now: AT });
  assert.deepEqual(renamedFile.pages.map(item => item.pageId), ['pageA', 'pageB']);
  const readShape = (needsPage: PoolNeedsPage, reverse = false) => needsPage.reads.map(read => {
    const originalEntity = reverse ? Object.keys(ids).find(key => ids[key] === read.entity) || read.entity : read.entity;
    return `${originalEntity}:${read.family}:${read.scope}`;
  }).sort();
  assert.deepEqual(readShape(pageOf(renamedFile.pages, 'pageA'), true), readShape(daily));
  assert.deepEqual(readShape(pageOf(renamedFile.pages, 'pageB'), true), readShape(confirmation));
});

void test('agenda does not derive a related entity when the actor has no grant for it', () => {
  const { sources, grants } = loadAgendaSources();
  const menu = structuredClone(loadMenu());
  const page = menu.tree.find(node => node.kind === 'page');
  assert.ok(page && page.kind === 'page');
  menu.tree = [{ ...structuredClone(page), id: 'phone_confirmation', label: 'Phone confirmation', organisms: [{ kind: 'detail', text: 'Confirm the selected patient appointment by telephone.' }] }];
  menu.authorities = { 'actor:recepcionista': ['phone_confirmation'] };
  menu.meta.journeys = { confirmarConsultaPorTelefone: ['phone_confirmation'] };
  menu.meta.processes = {};
  const withoutContactGrant = grants.filter(grant => !grant.entityRefs.includes('ContatoPaciente'));
  const file = buildP2NeedsFile({ menu, sources, grants: withoutContactGrant, processes: [], now: AT });
  assert.equal(pageOf(file.pages, 'phone_confirmation').reads.some(item => item.entity === 'ContatoPaciente'), false);
});
