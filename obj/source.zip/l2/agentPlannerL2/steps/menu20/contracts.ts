/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/menu20/contracts.ts" enhancement="_blank"/>

import {
  P2_MENU_DEVICE,
  readReadyL2Manifest,
  type P2MenuDevice,
} from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import {
  collectP2WorkspaceCandidates,
  isDdmEntity,
  type P2L4Sources,
  type P2WorkspaceCandidate,
} from '/_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.js';
import type {
  MenuGroupNode,
  MenuHubNode,
  MenuNode,
  MenuOrganism,
  MenuPageNode,
  MenuPlacement,
  MenuStampedNode,
  PoolMenuFile,
  PoolMenuMeta,
} from '/_102035_/l2/solution/poolPlan.js';
import { isLucideIcon } from '/_102035_/l2/solution/lucideIcons.js';
import {
  MENU_PLACEMENTS,
  MENU_ACTIONS as POOL_MENU_ACTIONS,
  MENU_NODE_KINDS as POOL_MENU_NODE_KINDS,
  MENU_ORGANISM_KINDS as POOL_MENU_ORGANISM_KINDS,
  MENU_SCHEMA_VERSION as POOL_MENU_SCHEMA_VERSION,
} from '/_102035_/l2/solution/poolPlan.js';

// Lists and version of menu.json come from the pool's one type (p2_34).
export const P2_MENU_SCHEMA_VERSION = POOL_MENU_SCHEMA_VERSION;
export const MENU_NODE_KINDS = POOL_MENU_NODE_KINDS;
export type MenuNodeKind = typeof MENU_NODE_KINDS[number];
export const MENU_ORGANISM_KINDS = POOL_MENU_ORGANISM_KINDS;
export type MenuOrganismKind = typeof MENU_ORGANISM_KINDS[number];
export const MENU_MECHANICAL_EFFECTS = ['transition', 'create', 'update'] as const;
export const MENU_ACTIONS = POOL_MENU_ACTIONS;
export type MenuAction = typeof MENU_ACTIONS[number];

const NODE_ID = /^[a-z][a-z0-9]*(_[a-z0-9]+)*$/;
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const ENTITY_ID = /^[A-Z][A-Za-z0-9]*$/;
const ACTOR_KEY = /^actor:([a-z][A-Za-z0-9]*)$/;

export interface MenuV2 {
  tree: MenuNode[];
  authorities: Record<string, string[]>;
  meta: PoolMenuMeta;
}

export interface P2GrantView {
  grantId: string;
  actorRef: string;
  title: string;
  description: string;
  entityRefs: string[];
  dataScope: { mode: string; anchorEntity: string; description: string };
  disclosure: { mode: string; description: string };
}

export interface P2ProcessTaskView {
  taskId: string;
  kind: string;
  description: string;
  actorRef: string;
  entityRef: string;
  effect: string;
  journeyRef: string;
  transitionRef: string;
}

export interface P2ProcessView {
  processId: string;
  trigger: { kind: string; schedule: string; event: string; actorRef: string };
  tasks: P2ProcessTaskView[];
}

export interface P2MenuHubCandidate {
  entityRef: string;
  actorRefs: string[];
}

export interface P2ActorMustSeeTask {
  processId: string;
  taskId: string;
  description: string;
  entityRef: string;
}

export interface P2ActorMustSeeEffect extends P2ActorMustSeeTask {
  effect: string;
}

export interface P2ActorMustSeeDerived {
  entityRef: string;
  fieldId?: string;
  title: string;
}

/** Per actor, what the person must see beyond journeys (classes 1–4). */
export interface P2ActorMustSee {
  actorRef: string;
  human: P2ActorMustSeeTask[];
  alerts: P2ActorMustSeeTask[];
  mechanicalEffects: P2ActorMustSeeEffect[];
  derived: P2ActorMustSeeDerived[];
}

export interface P2RecordKeptGrant {
  actorRef: string;
  dataScope: { mode: string };
  disclosure: { mode: string };
  description: string;
}

export interface P2RecordKept {
  entityRef: string;
  grants: P2RecordKeptGrant[];
}

export interface P2MenuCandidates {
  hubs: P2MenuHubCandidate[];
  pages: P2WorkspaceCandidate[];
  beyondJourneys: P2ActorMustSee[];
  recordsKept: P2RecordKept[];
}

export function isMenuNodeKind(value: string): value is MenuNodeKind {
  return (MENU_NODE_KINDS as readonly string[]).includes(value);
}

export function isMenuOrganismKind(value: string): value is MenuOrganismKind {
  return (MENU_ORGANISM_KINDS as readonly string[]).includes(value);
}

export function isMenuAction(value: string): value is MenuAction {
  return (MENU_ACTIONS as readonly string[]).includes(value);
}

export function actorAuthorityKey(actorRef: string): string {
  return `actor:${actorRef}`;
}

export function parseP2Grants(access: unknown): P2GrantView[] {
  return list(record(access).grants).map(item => {
    const grant = record(item);
    const dataScope = record(grant.dataScope);
    const disclosure = record(grant.disclosure);
    return {
      grantId: memberId(text(grant.grantId)),
      actorRef: memberId(text(grant.actorRef)),
      title: text(grant.title),
      description: text(grant.description),
      entityRefs: uniqueIds(grant.entityRefs, entityId),
      dataScope: {
        mode: text(dataScope.mode),
        anchorEntity: text(dataScope.anchorEntity),
        description: text(dataScope.description),
      },
      disclosure: {
        mode: text(disclosure.mode),
        description: text(disclosure.description),
      },
    };
  }).filter(grant => grant.grantId);
}

export function parseP2Processes(workflows: unknown): P2ProcessView[] {
  return list(record(workflows).processes).map(item => {
    const process = record(item);
    const trigger = record(process.trigger);
    return {
      processId: memberId(text(process.processId)),
      trigger: {
        kind: text(trigger.kind),
        schedule: text(trigger.schedule),
        event: text(trigger.event),
        actorRef: memberId(text(trigger.actorRef)),
      },
      tasks: list(process.tasks).map(taskItem => {
        const task = record(taskItem);
        return {
          taskId: memberId(text(task.taskId)),
          kind: text(task.kind),
          description: text(task.description),
          actorRef: memberId(text(task.actorRef)),
          entityRef: text(task.entityRef),
          effect: text(task.effect),
          journeyRef: memberId(text(task.journeyRef)),
          transitionRef: memberId(text(task.transitionRef)),
        };
      }).filter(task => task.taskId),
    };
  }).filter(process => process.processId);
}

/** Hubs = grant anchors; pages = (entity, actor) groups from workspaces20. Candidates, not the answer. */
export function menuCandidates(
  sources: P2L4Sources,
  grants: readonly P2GrantView[],
  processes: readonly P2ProcessView[] = [],
): P2MenuCandidates {
  const hubActors = new Map<string, Set<string>>();
  for (const grant of grants) {
    const anchor = grant.dataScope.anchorEntity;
    if (!anchor) continue;
    let actors = hubActors.get(anchor);
    if (!actors) {
      actors = new Set();
      hubActors.set(anchor, actors);
    }
    if (grant.actorRef) actors.add(grant.actorRef);
  }
  const hubs = [...hubActors.entries()]
    .map(([entityRef, actors]) => ({ entityRef, actorRefs: [...actors].sort((a, b) => a.localeCompare(b)) }))
    .sort((left, right) => left.entityRef.localeCompare(right.entityRef));
  return {
    hubs,
    pages: collectP2WorkspaceCandidates(sources),
    beyondJourneys: collectBeyondJourneys(sources, grants, processes),
    recordsKept: collectRecordsKept(sources, grants),
  };
}

/** Pure. Per `writer: crud` entity, the grants that reach it. Description as-is. */
export function collectRecordsKept(
  sources: P2L4Sources,
  grants: readonly P2GrantView[],
): P2RecordKept[] {
  const crudIds = new Set(
    sources.entities.filter(entity => entity.writer === 'crud' && entity.entityId).map(entity => entity.entityId),
  );
  const byEntity = new Map<string, P2RecordKeptGrant[]>();
  for (const grant of grants) {
    if (!grant.actorRef) continue;
    for (const entityRef of grant.entityRefs) {
      if (!entityRef || !crudIds.has(entityRef)) continue;
      let rows = byEntity.get(entityRef);
      if (!rows) {
        rows = [];
        byEntity.set(entityRef, rows);
      }
      rows.push({
        actorRef: grant.actorRef,
        dataScope: { mode: grant.dataScope.mode },
        disclosure: { mode: grant.disclosure.mode },
        description: grant.description,
      });
    }
  }
  return [...byEntity.entries()]
    .map(([entityRef, entityGrants]) => ({
      entityRef,
      grants: entityGrants.sort((left, right) => {
        const actor = left.actorRef.localeCompare(right.actorRef);
        return actor !== 0 ? actor : left.description.localeCompare(right.description);
      }),
    }))
    .sort((left, right) => left.entityRef.localeCompare(right.entityRef));
}

export function isMechanicalEffectTask(task: P2ProcessTaskView): boolean {
  return (task.kind === 'mechanical' || task.kind === 'llm')
    && (MENU_MECHANICAL_EFFECTS as readonly string[]).includes(task.effect);
}

/** Pure. Per actor: human stages, alerts, mechanical effects, derived/ddm their grant reaches. */
export function collectBeyondJourneys(
  sources: P2L4Sources,
  grants: readonly P2GrantView[],
  processes: readonly P2ProcessView[],
): P2ActorMustSee[] {
  const grantEntities = new Map<string, Set<string>>();
  for (const grant of grants) {
    if (!grant.actorRef) continue;
    let entities = grantEntities.get(grant.actorRef);
    if (!entities) {
      entities = new Set();
      grantEntities.set(grant.actorRef, entities);
    }
    for (const entityRef of grant.entityRefs) {
      if (entityRef) entities.add(entityRef);
    }
  }
  const ddmIds = new Set(sources.entities.filter(isDdmEntity).map(entity => entity.entityId));
  const derivedByEntity = new Map<string, P2ActorMustSeeDerived[]>();
  for (const entity of sources.ontologyEntities) {
    const entityId = text(record(entity).entityId);
    if (!entityId) continue;
    derivedByEntity.set(entityId, collectDerivedOfEntity(entity, ddmIds.has(entityId)));
  }
  const byActor = new Map<string, P2ActorMustSee>();
  const actorOf = (actorRef: string): P2ActorMustSee => {
    let row = byActor.get(actorRef);
    if (!row) {
      row = { actorRef, human: [], alerts: [], mechanicalEffects: [], derived: [] };
      byActor.set(actorRef, row);
    }
    return row;
  };
  for (const actor of sources.actors) {
    if (actor.actorId) actorOf(actor.actorId);
  }
  for (const process of processes) {
    for (const task of process.tasks) {
      if (task.kind === 'human' && task.actorRef) {
        actorOf(task.actorRef).human.push({
          processId: process.processId,
          taskId: task.taskId,
          description: task.description,
          entityRef: task.entityRef,
        });
      }
      if (task.kind === 'alert' && task.actorRef) {
        actorOf(task.actorRef).alerts.push({
          processId: process.processId,
          taskId: task.taskId,
          description: task.description,
          entityRef: task.entityRef,
        });
      }
      if (isMechanicalEffectTask(task) && task.entityRef) {
        for (const [actorRef, entities] of grantEntities) {
          if (!entities.has(task.entityRef)) continue;
          actorOf(actorRef).mechanicalEffects.push({
            processId: process.processId,
            taskId: task.taskId,
            description: task.description,
            entityRef: task.entityRef,
            effect: task.effect,
          });
        }
      }
    }
  }
  for (const [actorRef, entities] of grantEntities) {
    const row = actorOf(actorRef);
    const derived: P2ActorMustSeeDerived[] = [];
    for (const entityRef of [...entities].sort((left, right) => left.localeCompare(right))) {
      derived.push(...(derivedByEntity.get(entityRef) || []));
    }
    row.derived = derived;
  }
  return [...byActor.values()].sort((left, right) => left.actorRef.localeCompare(right.actorRef));
}

export function normalizeMenuV2(value: unknown): MenuV2 {
  const root = asRecord(value, '$');
  exactKeys(root, ['tree', 'authorities', 'meta'], '$');
  const meta = asRecord(root.meta, '$.meta');
  // Model answers must name a place for every journey. A menu.json written before the field never comes through here.
  exactKeys(meta, ['journeys', 'processes', 'records', 'placements'], '$.meta');
  return {
    tree: list(root.tree, '$.tree').map((item, index) => normalizeNode(item, `$.tree[${index}]`, 'model')),
    authorities: normalizeAuthorities(root.authorities, '$.authorities'),
    meta: {
      journeys: normalizeIdPagesMap(meta.journeys, '$.meta.journeys', 'journeyId'),
      processes: normalizeIdPagesMap(meta.processes, '$.meta.processes', 'processId'),
      records: normalizeIdPagesMap(meta.records, '$.meta.records', 'entityId'),
      placements: normalizePlacements(meta.placements, '$.meta.placements'),
    },
  };
}

export function buildP2MenuFile(input: {
  moduleName: string;
  userLanguage: string;
  draft: MenuV2;
  device?: P2MenuDevice;
}): PoolMenuFile {
  const device = input.device || P2_MENU_DEVICE;
  const ready = readReadyL2Manifest(input.moduleName, device);
  return {
    schemaVersion: P2_MENU_SCHEMA_VERSION,
    moduleName: input.moduleName,
    userLanguage: input.userLanguage,
    device,
    tree: stampAllNew(input.draft.tree, ready),
    authorities: input.draft.authorities,
    meta: {
      journeys: input.draft.meta.journeys,
      processes: input.draft.meta.processes,
      records: input.draft.meta.records,
      ...(input.draft.meta.placements !== undefined ? { placements: input.draft.meta.placements } : {}),
      removed: [],
    },
  };
}

export function menuActionCounts(file: PoolMenuFile): Record<MenuAction, number> {
  const counts: Record<MenuAction, number> = { new: 0, change: 0, keep: 0, remove: 0 };
  const visit = (nodes: readonly MenuStampedNode[]) => {
    for (const node of nodes) {
      counts[node.action] += 1;
      if (node.kind === 'hub' || node.kind === 'group') visit(node.children);
    }
  };
  visit(file.tree);
  visit(file.meta.removed);
  return counts;
}

function stampAllNew(nodes: readonly MenuNode[], ready: null): MenuStampedNode[] {
  void ready;
  return nodes.map((node): MenuStampedNode => {
    if (node.kind === 'page') {
      const { icon, ...page } = node;
      return icon ? { ...page, icon, action: 'new' } : { ...page, action: 'new' };
    }
    return { ...node, action: 'new', children: stampAllNew(node.children, ready) };
  });
}

/** Unknown Lucide names become `""`. Hubs, groups and every other field stay as they are. */
export function dropUnknownMenuIcons(draft: MenuV2): { draft: MenuV2; dropped: Array<{ pageId: string; icon: string }> } {
  const dropped: Array<{ pageId: string; icon: string }> = [];
  const walk = (nodes: readonly MenuNode[]): MenuNode[] => nodes.map(node => {
    if (node.kind === 'hub' || node.kind === 'group') return { ...node, children: walk(node.children) };
    const icon = node.icon ?? '';
    if (icon !== '' && !isLucideIcon(icon)) {
      dropped.push({ pageId: node.id, icon });
      return { ...node, icon: '' };
    }
    return node;
  });
  return { draft: { ...draft, tree: walk(draft.tree) }, dropped };
}

export function menuIconDropWarnings(dropped: readonly { pageId: string; icon: string }[]): string[] {
  return dropped.map(row => `icon dropped: ${row.pageId} ${row.icon}`);
}

/** Read a stamped menu tree, stripping `action` so the node shape matches the draft. */
export function parsePreviousMenuTree(value: unknown): MenuNode[] {
  const root = asRecord(value, '$');
  return list(root.tree, '$.tree').map((item, index) => (
    normalizeNode(stripAction(item), `$.tree[${index}]`)
  ));
}

/** Ids the code knows (entities, actors, journeys, processes, kept records) become enums of the menu schema (d2_67). */
export function withP2MenuEnums(schema: Record<string, unknown>, sources: P2L4Sources, grants: readonly P2GrantView[], processes: readonly P2ProcessView[]): Record<string, unknown> {
  const copy = structuredClone(schema) as { $defs: Record<string, { properties: Record<string, Record<string, unknown>> }> };
  const limit = (def: string, field: string, values: readonly string[]) => {
    const target = copy.$defs[def]?.properties?.[field];
    if (!target) throw new Error(`menu.schema.json has no $defs.${def}.properties.${field}.`);
    const list = [...new Set(values.filter(Boolean))];
    if (list.length) target.enum = list;
  };
  limit('hubNode', 'context', sources.entities.map(entity => entity.entityId));
  limit('authority', 'actorRef', sources.actors.map(actor => actor.actorId));
  limit('journeyPages', 'journeyId', sources.journeys.map(journey => journey.journeyId));
  limit('processPages', 'processId', processes.map(process => process.processId));
  limit('recordPages', 'entityId', collectRecordsKept(sources, grants).map(row => row.entityRef));
  return copy;
}

export function buildP2MenuTool(schema: Record<string, unknown>): mls.msg.LLMTool {
  return createP2ArtifactTool(
    'submitP2Menu',
    'Submit the module menu tree: hubs, pages with organisms, authorities by actor, and journey/process mapping.',
    schema,
  );
}

function normalizeNode(value: unknown, path: string, mode: 'model' | 'file' = 'file'): MenuNode {
  const source = asRecord(value, path);
  const kind = text(source.kind);
  if (kind === 'hub') return normalizeHub(source, path, mode);
  if (kind === 'page') return normalizePage(source, path, mode);
  if (kind === 'group') return normalizeGroup(source, path, mode);
  throw new Error(`${path}.kind must be hub, page or group.`);
}

function normalizeHub(source: Record<string, unknown>, path: string, mode: 'model' | 'file'): MenuHubNode {
  exactKeys(source, ['id', 'kind', 'label', 'context', 'text', 'children'], path);
  const children = list(source.children, `${path}.children`);
  return {
    id: nodeId(source.id, `${path}.id`),
    kind: 'hub',
    label: requiredText(source.label, `${path}.label`),
    context: entityIdRequired(source.context, `${path}.context`),
    text: requiredText(source.text, `${path}.text`),
    children: children.map((item, index) => normalizeNode(item, `${path}.children[${index}]`, mode)),
  };
}

function normalizePage(source: Record<string, unknown>, path: string, mode: 'model' | 'file'): MenuPageNode {
  const keys = ['id', 'kind', 'label', 'organisms'];
  if (mode === 'model' || Object.prototype.hasOwnProperty.call(source, 'icon')) keys.push('icon');
  exactKeys(source, keys, path);
  const page: MenuPageNode = {
    id: nodeId(source.id, `${path}.id`),
    kind: 'page',
    label: requiredText(source.label, `${path}.label`),
    organisms: list(source.organisms, `${path}.organisms`).map((item, index) => (
      normalizeOrganism(item, `${path}.organisms[${index}]`)
    )),
  };
  if (mode === 'model' || Object.prototype.hasOwnProperty.call(source, 'icon')) {
    if (typeof source.icon !== 'string') throw new Error(`${path}.icon must be a string.`);
    page.icon = source.icon.trim();
  }
  return page;
}

function normalizeGroup(source: Record<string, unknown>, path: string, mode: 'model' | 'file'): MenuGroupNode {
  exactKeys(source, ['id', 'kind', 'label', 'text', 'children'], path);
  const children = list(source.children, `${path}.children`);
  return {
    id: nodeId(source.id, `${path}.id`),
    kind: 'group',
    label: requiredText(source.label, `${path}.label`),
    text: requiredText(source.text, `${path}.text`),
    children: children.map((item, index) => normalizeNode(item, `${path}.children[${index}]`, mode)),
  };
}

function normalizeOrganism(value: unknown, path: string): MenuOrganism {
  const source = asRecord(value, path);
  exactKeys(source, ['kind', 'text'], path);
  const kind = text(source.kind);
  if (!isMenuOrganismKind(kind)) {
    throw new Error(`${path}.kind must be one of ${MENU_ORGANISM_KINDS.join(', ')}.`);
  }
  return { kind, text: requiredText(source.text, `${path}.text`) };
}

function normalizeAuthorities(value: unknown, path: string): Record<string, string[]> {
  if (Array.isArray(value)) {
    const out: Record<string, string[]> = {};
    value.forEach((item, index) => {
      const row = asRecord(item, `${path}[${index}]`);
      exactKeys(row, ['actorRef', 'nodes'], `${path}[${index}]`);
      const actorRef = memberIdRequired(row.actorRef, `${path}[${index}].actorRef`);
      const key = actorAuthorityKey(actorRef);
      if (out[key]) throw new Error(`${path}[${index}]: duplicate actorRef ${actorRef}.`);
      out[key] = stringIdList(row.nodes, `${path}[${index}].nodes`, nodeId);
    });
    return out;
  }
  const source = asRecord(value, path);
  const out: Record<string, string[]> = {};
  for (const [key, nodes] of Object.entries(source)) {
    if (!ACTOR_KEY.test(key)) throw new Error(`${path}.${key}: authority key must be actor:<lowerCamel>.`);
    out[key] = stringIdList(nodes, `${path}[${JSON.stringify(key)}]`, nodeId);
  }
  return out;
}

function normalizeIdPagesMap(value: unknown, path: string, idKey: 'journeyId' | 'processId' | 'entityId'): Record<string, string[]> {
  const idOf = idKey === 'entityId' ? entityIdRequired : memberIdRequired;
  if (Array.isArray(value)) {
    const out: Record<string, string[]> = {};
    value.forEach((item, index) => {
      const row = asRecord(item, `${path}[${index}]`);
      exactKeys(row, [idKey, 'pages'], `${path}[${index}]`);
      const id = idOf(row[idKey], `${path}[${index}].${idKey}`);
      if (out[id]) throw new Error(`${path}[${index}]: duplicate ${idKey} ${id}.`);
      out[id] = stringIdList(row.pages, `${path}[${index}].pages`, nodeId);
    });
    return out;
  }
  const source = asRecord(value, path);
  const out: Record<string, string[]> = {};
  for (const [key, pages] of Object.entries(source)) {
    const id = idOf(key, `${path}.${key}`);
    out[id] = stringIdList(pages, `${path}.${id}`, nodeId);
  }
  return out;
}

function collectDerivedOfEntity(entity: unknown, isDdm: boolean): P2ActorMustSeeDerived[] {
  const root = record(entity);
  const entityRef = text(root.entityId);
  if (!entityRef) return [];
  const title = text(root.title) || entityRef;
  if (isDdm) return [{ entityRef, title }];
  const out: P2ActorMustSeeDerived[] = [];
  walkDerivedFields(record(record(root.record).fields), false, '', (fieldId, fieldTitle) => {
    out.push({ entityRef, fieldId, title: fieldTitle });
  });
  return out;
}

function walkDerivedFields(
  fields: Record<string, unknown>,
  platform: boolean,
  prefix: string,
  visit: (fieldId: string, title: string) => void,
): void {
  for (const [id, raw] of Object.entries(fields)) {
    const field = record(raw);
    const nextPlatform = platform || text(field.owner) === 'platform';
    const path = prefix ? `${prefix}.${id}` : id;
    const nested = field.fields;
    const container = isRecord(nested) && Object.keys(nested).length > 0;
    if (!nextPlatform && field.derived === true && id !== 'id' && id !== 'version' && !container) {
      visit(path, text(field.title) || path);
    }
    if (isRecord(nested)) walkDerivedFields(nested, nextPlatform, path, visit);
  }
}

function createP2ArtifactTool(
  toolName: string,
  description: string,
  artifactSchema: Record<string, unknown>,
): mls.msg.LLMTool {
  const result: Record<string, unknown> = { ...artifactSchema };
  const defs = result.$defs;
  delete result.$defs;
  delete result.$id;
  delete result.$schema;
  const parameters: Record<string, unknown> = {
    type: 'object',
    additionalProperties: false,
    required: ['type', 'result'],
    properties: {
      type: { type: 'string', const: 'flexible' },
      result,
    },
  };
  if (isRecord(defs)) parameters.$defs = defs;
  return { type: 'function', function: { name: toolName, description, parameters } } as mls.msg.LLMTool;
}

function stringIdList(
  value: unknown,
  path: string,
  normalize: (raw: unknown, at: string) => string,
): string[] {
  return list(value, path).map((item, index) => normalize(item, `${path}[${index}]`));
}

function uniqueIds(value: unknown, normalize: (raw: string) => string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of Array.isArray(value) ? value : []) {
    const id = normalize(typeof item === 'string' ? item : text(record(item).id));
    if (!id || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}

function exactKeys(source: Record<string, unknown>, allowed: readonly string[], path: string): void {
  const allowedSet = new Set(allowed);
  for (const key of Object.keys(source)) {
    if (!allowedSet.has(key)) throw new Error(`${path}: unexpected field '${key}'.`);
  }
  for (const key of allowed) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) throw new Error(`${path}: missing field '${key}'.`);
  }
}

function normalizePlacements(value: unknown, path: string): MenuPlacement[] {
  return list(value, path).map((item, index) => {
    const row = asRecord(item, `${path}[${index}]`);
    exactKeys(row, ['journeyId', 'actorRef', 'placement', 'pageId', 'reason'], `${path}[${index}]`);
    const placement = text(row.placement);
    if (!MENU_PLACEMENTS.includes(placement as typeof MENU_PLACEMENTS[number])) {
      throw new Error(`${path}[${index}].placement must be ${MENU_PLACEMENTS.join(', ')}.`);
    }
    return {
      journeyId: memberIdRequired(row.journeyId, `${path}[${index}].journeyId`),
      actorRef: memberIdRequired(row.actorRef, `${path}[${index}].actorRef`),
      placement: placement as typeof MENU_PLACEMENTS[number],
      pageId: nodeId(row.pageId, `${path}[${index}].pageId`),
      reason: requiredText(row.reason, `${path}[${index}].reason`),
    };
  });
}

function stripAction(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(stripAction);
  if (!isRecord(value)) return value;
  const { action: _action, ...rest } = value;
  const out: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(rest)) out[key] = stripAction(item);
  return out;
}

function asRecord(value: unknown, path: string): Record<string, unknown> {
  if (!isRecord(value)) throw new Error(`${path} must be an object.`);
  return value;
}

function list(value: unknown, path?: string): unknown[] {
  if (Array.isArray(value)) return value;
  if (path) throw new Error(`${path} must be an array.`);
  return [];
}

function nodeId(value: unknown, path: string): string {
  const id = text(value);
  if (!NODE_ID.test(id)) throw new Error(`${path} must be snake_case.`);
  return id;
}

function memberIdRequired(value: unknown, path: string): string {
  const id = text(value);
  if (!MEMBER_ID.test(id)) throw new Error(`${path} must be lowerCamel.`);
  return id;
}

function entityIdRequired(value: unknown, path: string): string {
  const id = text(value);
  if (!ENTITY_ID.test(id)) throw new Error(`${path} must be an l4 entity id.`);
  return id;
}

function requiredText(value: unknown, path: string): string {
  const trimmed = text(value);
  if (!trimmed) throw new Error(`${path} must be a non-empty string.`);
  return trimmed;
}

function memberId(value: string): string {
  const trimmed = value.trim();
  return MEMBER_ID.test(trimmed) ? trimmed : trimmed;
}

function entityId(value: string): string {
  return value.trim();
}

function record(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {};
}

function text(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}
