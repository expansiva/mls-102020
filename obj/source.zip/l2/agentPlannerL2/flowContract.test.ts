/// <mls fileReference="_102020_/l2/agentPlannerL2/flowContract.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { P2_STEP_HOOKS } from '/_102020_/l2/agentPlannerL2/helpers/p2Dispatch.js';
import {
  P2_FLOW_ID,
  P2_FLOW_LAST_STEP_ID,
  P2_FLOW_STEP_IDS,
  P2_FLOW_VERSION,
  P2_PARKED_STEP_IDS,
  P2_STEP_DEPENDS_ON,
} from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FLOW_PATH = path.join(HERE, 'docs/flow.json');
const STEPS_ROOT = path.join(HERE, 'steps');

interface FlowStep {
  id: string;
  kind: string;
  status?: string;
  dependsOn: string[];
  doneAnchor: string;
  modelAlias?: string;
  artifact: string;
}

interface FlowDoc {
  flowId: string;
  schemaVersion: string;
  status?: string;
  artifacts: Record<string, string>;
  steps: FlowStep[];
}

const EXPECTED_ARTIFACTS: Record<string, string> = {
  pipeline: 'l2/{module}/pipeline/pipeline.json',
  menu: 'l4/{module}/pool/l2/web/menu.json',
  needs: 'l4/{module}/pool/l1/web/needs.json',
  effort: 'l4/{module}/pool/l2/web/effort.json',
};

const WAITING_STEPS: readonly string[] = [];

function loadFlow(): FlowDoc {
  return JSON.parse(readFileSync(FLOW_PATH, 'utf8')) as FlowDoc;
}

void test('flow has exactly four steps in declared order with declared dependencies', () => {
  const flow = loadFlow();
  assert.equal(flow.flowId, P2_FLOW_ID);
  assert.equal(flow.schemaVersion, P2_FLOW_VERSION);
  assert.equal(flow.status, 'effort40');
  assert.equal(flow.steps.length, 4);
  assert.deepEqual(flow.steps.map(step => step.id), [...P2_FLOW_STEP_IDS]);

  for (const step of flow.steps) {
    assert.deepEqual(step.dependsOn, [...P2_STEP_DEPENDS_ON[step.id as keyof typeof P2_STEP_DEPENDS_ON]]);
    assert.equal(step.doneAnchor, `${step.id}-done`);
    assert.ok(step.artifact, `${step.id} missing artifact`);
  }

  const entry = flow.steps.find(step => step.id === 'entry10');
  assert.equal(entry?.kind, 'deterministic');
  assert.equal(entry?.modelAlias, undefined);
  assert.equal(entry?.status, undefined);

  const menu = flow.steps.find(step => step.id === 'menu20');
  assert.equal(menu?.kind, 'agent-checkpoint');
  assert.equal(menu?.modelAlias, 'reasoning');
  assert.equal(menu?.status, undefined);
  assert.equal(menu?.artifact, 'l4/{module}/pool/l2/web/menu.json');

  const needs = flow.steps.find(step => step.id === 'needs30');
  assert.equal(needs?.kind, 'deterministic');
  assert.equal(needs?.modelAlias, undefined);
  assert.equal(needs?.status, undefined);
  assert.equal(needs?.artifact, 'l4/{module}/pool/l1/web/needs.json');

  const effort = flow.steps.find(step => step.id === 'effort40');
  assert.equal(effort?.kind, 'deterministic');
  assert.equal(effort?.modelAlias, undefined);
  assert.equal(effort?.status, undefined);
  assert.equal(effort?.artifact, 'l4/{module}/pool/l2/web/effort.json');
  assert.deepEqual(effort?.dependsOn, ['entry10-done']);

  for (const id of P2_PARKED_STEP_IDS) {
    assert.equal(flow.steps.some(step => step.id === id), false, `${id} must stay out of flow.json v6`);
  }

  for (const id of WAITING_STEPS) {
    const step = flow.steps.find(item => item.id === id);
    assert.equal(step?.status, 'waiting', `${id} must stay declared as waiting until its spec lands`);
  }
});

void test('flow artifacts match the l2 table', () => {
  const flow = loadFlow();
  assert.deepEqual(flow.artifacts, EXPECTED_ARTIFACTS);
});

void test('each step folder that exists implements beforePromptStep and is on the dispatch table', async () => {
  if (!existsSync(STEPS_ROOT)) return;
  for (const stepId of P2_FLOW_STEP_IDS) {
    const folder = path.join(STEPS_ROOT, stepId);
    if (!existsSync(folder)) continue;
    const agentFiles = readdirSync(folder).filter(name => /^agentP2\w+\.ts$/.test(name) && !name.endsWith('.test.ts'));
    assert.ok(agentFiles.length > 0, `${stepId} has a folder but no agentP2*.ts`);
    const source = readFileSync(path.join(folder, agentFiles[0]), 'utf8');
    assert.match(source, /export async function beforeP2\w+PromptStep/, `${agentFiles[0]} must export beforePromptStep`);
    await import(`/_102020_/l2/agentPlannerL2/steps/${stepId}/${agentFiles[0].replace(/\.ts$/, '.js')}`);
    assert.equal(typeof P2_STEP_HOOKS[stepId]?.beforePromptStep, 'function', `${stepId} folder exists but is missing from P2_STEP_HOOKS`);
  }
});

void test('waiting steps have no folder yet', () => {
  for (const id of WAITING_STEPS) {
    assert.equal(existsSync(path.join(STEPS_ROOT, id)), false, `${id} folder must wait for its spec`);
  }
});

function agentSourceOf(stepId: string): string {
  const folder = path.join(STEPS_ROOT, stepId);
  const agentFiles = readdirSync(folder).filter(name => /^agentP2\w+\.ts$/.test(name) && !name.endsWith('.test.ts'));
  assert.ok(agentFiles.length > 0, `${stepId} has no agentP2*.ts`);
  return readFileSync(path.join(folder, agentFiles[0]), 'utf8');
}

void test('the last flow.json step is who writes pipeline.status complete', () => {
  const flow = loadFlow();
  const last = flow.steps[flow.steps.length - 1];
  assert.ok(last, 'flow.json has no steps');
  assert.equal(last.id, P2_FLOW_LAST_STEP_ID);
  assert.equal(last.id, P2_FLOW_STEP_IDS[P2_FLOW_STEP_IDS.length - 1]);
  assert.match(agentSourceOf(last.id), /markP2Complete/, `${last.id} afterPrompt must close the pipeline`);
  for (const step of flow.steps.slice(0, -1)) {
    assert.doesNotMatch(agentSourceOf(step.id), /markP2Complete/, `${step.id} must not close the pipeline`);
  }
});
