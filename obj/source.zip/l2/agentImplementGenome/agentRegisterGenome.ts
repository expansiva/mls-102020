/// <mls fileReference="_102020_/l2/agentImplementGenome/agentRegisterGenome.ts" enhancement="_102027_/l2/enhancementAgent"/>

// Terminal step — NO-LLM wrapper agent (like agentNewSolutionPlanner: only
// beforePromptStep, returns completed). Its `dependsOn` lists EVERY gen:<page> step, so
// the framework only starts it once ALL pages produced their final defs. It then, ONCE:
//   1. registers the variation in module.ts (module-level, deterministic).
//
// It no longer records `resolvedMolecules` on the DS: the molecules a page used live in
// the page's own defs (moleculeAssignments) — the authoritative, per-page source — and
// nothing reads a DS-level aggregate. Staleness uses dsVersion (per-page stamp) instead.

import { IAgentAsync, IAgentMeta } from '/_102027_/l2/aiAgentBase.js';
// [DESATIVADO temporariamente] avaliando se module.ts/moduleGenome ainda é necessário.
// import { registerPageGenome } from '/_102020_/l2/dsMatch/registerPageGenome.js';
import { parseStepArgs, mkCompleted, mkFail } from '/_102020_/l2/agentImplementGenome/planning.js';

export function createAgent(): IAgentAsync {
  return {
    agentName: 'agentRegisterGenome',
    agentProject: 102020,
    agentFolder: 'agentImplementGenome',
    agentDescription: 'Register the new page variation in module.ts (terminal, no LLM)',
    visibility: 'private',
    beforePromptStep,
  };
}

async function beforePromptStep(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  args?: string,
): Promise<mls.msg.AgentIntent[]> {

  try {
    const a = parseStepArgs(args ?? step.prompt);
    const project = mls.actualProject || 0;
    console.info(`[agentRegisterGenome] ▶ terminal — page${a.layout}${a.ds} (${a.module})`);
    if (!context.isTest) {
      // [DESATIVADO temporariamente] registro da variação no module.ts (moduleGenome).
      // O materializador atual (agentMaterializeL2) lê o .defs.ts direto e ignora o moduleGenome;
      // avaliando se ainda há consumidor vivo antes de remover de vez. Reative as 2 linhas + o import.
      // await registerPageGenome(project, a.module, a.layout, a.ds, a.device);
      // console.info(`[agentRegisterGenome] module.ts atualizado (web/${a.device}/page${a.layout}${a.ds})`);

      // Styling tokens live in designSystem.ts (single home) — nothing to regenerate here:
      // the Design System plugin/reconciliation agent write it directly.
    }
    console.info('[agentRegisterGenome] ✓ fluxo agentImplementGenome concluído');
    return [mkCompleted(context, parentStep, step, hookSequential)];
  } catch (error) {
    const msg = `[agentRegisterGenome] ${error instanceof Error ? error.message : String(error)}`;
    console.error('✗', msg);
    return [mkFail(context, parentStep, step, hookSequential, msg)];
  }
}
