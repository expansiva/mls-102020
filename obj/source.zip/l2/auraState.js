/// <mls fileReference="_102020_/l2/auraState.ts" enhancement="_blank" />
import { getState, setState, initState } from '/_102029_/l2/collabState.js';
const STATE_KEY = 'aura';
function getActualProject() {
    return mls.actualProject || null;
}
function getActualModule() {
    return loadAuraProject(getActualProject())?.actualModule ?? null;
}
function getStoredLanguage() {
    return loadAuraProject(getActualProject())?.actualLanguage ?? null;
}
function getStoredLanguageByModule() {
    return loadAuraProject(getActualProject())?.actualLanguageByModule ?? null;
}
function getActualDevice() {
    return loadAuraProject(getActualProject())?.actualDevice ?? null;
}
function getActualLayout() {
    return loadAuraProject(getActualProject())?.actualLayout ?? null;
}
function getActualDesignSystem() {
    return loadAuraProject(getActualProject())?.actualDesignSystem ?? null;
}
function getActualPage() {
    return loadAuraProject(getActualProject())?.actualPage ?? null;
}
export function AuraInitState() {
    if (getAuraState())
        return;
    initState(STATE_KEY, {
        actualProject: getActualProject(),
        actualModule: getActualModule(),
        actualLanguage: getStoredLanguage(),
        actualLanguageByModule: getStoredLanguageByModule(),
        actualDevice: getActualDevice(),
        actualLayout: getActualLayout(),
        actualDesignSystem: getActualDesignSystem(),
        actualPage: getActualPage(),
    });
}
export function getAuraState() {
    return getState(STATE_KEY);
}
export function setAuraState(key, value) {
    setState(`${STATE_KEY}.${key}`, value);
    // Switching module changes the EFFECTIVE language — re-emit 'aura.actualLanguage' so
    // existing subscribers (e.g. servicePreview) keep working without a new key.
    if (key === 'actualModule') {
        const effective = getActualLanguage(value);
        if (effective)
            setState(`${STATE_KEY}.actualLanguage`, effective);
    }
}
/**
 * Language of a module (or of the actual module when omitted).
 * Falls back to the legacy single `actualLanguage` when the module has no entry yet
 * (migration seed of states saved before actualLanguageByModule existed).
 * No module resolvable → null (consumer falls back to the 1st language of module.defs).
 */
export function getActualLanguage(module) {
    const state = getAuraState();
    if (!state)
        return null;
    const target = module ?? state.actualModule;
    if (!target)
        return null;
    return state.actualLanguageByModule?.[target] ?? state.actualLanguage ?? null;
}
export function setActualLanguage(module, language) {
    const state = getAuraState();
    const byModule = { ...(state?.actualLanguageByModule ?? {}) };
    if (language)
        byModule[module] = language;
    else
        delete byModule[module];
    setAuraState('actualLanguageByModule', byModule);
    if (!state?.actualModule || state.actualModule === module) {
        setAuraState('actualLanguage', language);
    }
}
// ─── localStorage ─────────────────────────────────────────────────────
const LS_KEY = 'AuraProjects';
function readStore() {
    try {
        return JSON.parse(localStorage.getItem(LS_KEY) ?? '{}');
    }
    catch {
        return {};
    }
}
function writeStore(store) {
    localStorage.setItem(LS_KEY, JSON.stringify(store));
}
export function saveAuraProject() {
    const state = getAuraState();
    const project = state.actualProject;
    if (!project)
        return;
    const store = readStore();
    store[project] = {
        actualModule: state.actualModule,
        actualLanguage: state.actualLanguage,
        actualLanguageByModule: state.actualLanguageByModule,
        actualDevice: state.actualDevice,
        actualLayout: state.actualLayout,
        actualDesignSystem: state.actualDesignSystem,
        actualPage: state.actualPage,
    };
    writeStore(store);
}
export function deleteAuraProject(project) {
    const store = readStore();
    if (!store[project])
        return;
    delete store[project];
    writeStore(store);
}
export function loadAuraProject(project) {
    if (!project)
        return null;
    const store = readStore();
    return store[project] ?? null;
}
export function restoreAuraProject(project) {
    const entry = loadAuraProject(project);
    if (!entry)
        return;
    setAuraState('actualProject', project);
    // Entries saved before actualLanguageByModule existed lack the key — reset it
    // explicitly so the previous project's per-module map never leaks across projects.
    if (!('actualLanguageByModule' in entry))
        setAuraState('actualLanguageByModule', null);
    Object.keys(entry).forEach(key => {
        setAuraState(key, entry[key]);
    });
}
