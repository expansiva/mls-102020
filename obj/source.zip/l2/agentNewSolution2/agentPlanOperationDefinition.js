/// <mls fileReference="_102020_/l2/agentNewSolution2/agentPlanOperationDefinition.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createPromptReadyIntent, createUpdateStatusIntent, getPlannerOutputs, normalizeStringList, optionalString, resolveCapabilityInfo, EXPERIENCE_STATUS_INITIAL, } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
import { createPlannerToolSchema, extractPlannerOutput } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
import { getApprovedModuleName, operationFileInfo, readOperationDefs, saveAgentTrace, saveDefsArtifact } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { operationDefinitionResultSchema } from '/_102020_/l2/agentNewSolution2/ns2Schemas.js';
import { getOperationIndex } from '/_102020_/l2/agentNewSolution2/agentPlanOperationIndex.js';
import { getBehaviorIndex } from '/_102020_/l2/agentNewSolution2/agentClassifyBehavior.js';
import { getEnrichedOntology } from '/_102020_/l2/agentNewSolution2/agentNs2EntityDefinition.js';
import { getFinalizeOutput } from '/_102020_/l2/agentNewSolution2/agentNs2Finalize.js';
const AGENT_NAME = 'agentPlanOperationDefinition';
const TOOL_NAME = 'submitOperationDefinition';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the definition for the current operation selector.', operationDefinitionResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102020, agentFolder: 'agentNewSolution2', agentDescription: 'Detail one operation into its intent-level BFF contract', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[${AGENT_NAME}] operation selector args invalid`);
    const indexItem = getOperationIndex(context).result.operations.find(o => o.operationId === args);
    if (!indexItem)
        throw new Error(`[${AGENT_NAME}] operation selector not in index: ${args}`);
    const story = getBehaviorIndex(context).result.operations.find(o => o.operationId === args)?.story;
    const ontology = await getEnrichedOntology(context);
    const entityShape = ontology[indexItem.entity];
    const behavior = getBehaviorIndex(context).result;
    const workflowOwner = behavior.workflows.find(w => (w.operationIds || []).includes(args));
    const reduced = { selector: args, indexItem, story, workflowOwner, entityShape, ontologyEntityIds: Object.keys(ontology) };
    return [createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(TOOL_NAME), `## Operation selector\n${args}\n\n## Reduced context\n${JSON.stringify(reduced, null, 2)}\n`, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    const selector = (step.prompt || '').trim();
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlannerOutput(payload, config);
        if (selector && output.result.operationDefinition.operationId !== selector)
            output.result.operationDefinition.operationId = selector;
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = `${AGENT_NAME} returned failed`;
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${AGENT_NAME}] ${traceMsg}`);
    }
    if (status === 'completed' && output && output.status === 'ok') {
        try {
            const def = output.result.operationDefinition;
            // Attach the realized capability (id + title + priority) deterministically. A classified operation
            // carries its own capabilityId; an operation synthesized from a workflow's operationIds inherits the
            // capability of the workflow that orchestrates it.
            const behavior = getBehaviorIndex(context).result;
            const capabilityId = behavior.operations.find(o => o.operationId === def.operationId)?.capabilityId
                ?? behavior.workflows.find(w => (w.operationIds || []).includes(def.operationId))?.capabilityIds[0];
            def.capability = capabilityId ? resolveCapabilityInfo([capabilityId], getFinalizeOutput(context).result.capabilities)[0] : undefined;
            attachBffNaming(context, def);
            def.statusFrontend = EXPERIENCE_STATUS_INITIAL; // agentChangeFrontend picks up statusFrontend != 'done'
            def.statusBackend = EXPERIENCE_STATUS_INITIAL; // agentChangeBackend picks up statusBackend != 'done'
            await saveDefsArtifact(operationFileInfo(def.operationId), `operation${capitalize(def.operationId)}`, def);
        }
        catch (error) {
            console.warn(`[${AGENT_NAME}] save failed for ${selector}`, error);
        }
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg)];
}
/** Reads the GLOBAL l4/operations/*.defs.ts (fan-out children are deleted); in-task payloads override. */
export async function getOperationDefinitions(context) {
    const byId = new Map();
    for (const d of await readOperationDefs()) {
        const id = typeof d.operationId === 'string' ? d.operationId : '';
        if (id)
            byId.set(id, d);
    }
    for (const o of getPlannerOutputs(context, AGENT_NAME, config)) {
        if (o.status === 'ok') {
            const def = o.result.operationDefinition;
            attachBffNaming(context, def);
            byId.set(def.operationId, def);
        }
    }
    return [...byId.values()];
}
const config = { toolName: TOOL_NAME, normalizeResult };
function normalizeResult(value) {
    const result = assertRecord(value, 'result');
    const d = assertRecord(result.operationDefinition, 'result.operationDefinition');
    const s = assertRecord(d.story, 'result.operationDefinition.story');
    return {
        operationDefinition: {
            operationId: assertString(d.operationId, 'result.operationDefinition.operationId'),
            title: assertString(d.title, 'result.operationDefinition.title'),
            actor: assertString(d.actor, 'result.operationDefinition.actor'),
            entity: assertString(d.entity, 'result.operationDefinition.entity'),
            kind: assertString(d.kind, 'result.operationDefinition.kind'),
            reads: normalizeStringList(d.reads, 'result.operationDefinition.reads'),
            writes: normalizeStringList(d.writes, 'result.operationDefinition.writes'),
            rulesApplied: normalizeStringList(d.rulesApplied, 'result.operationDefinition.rulesApplied'),
            story: { actor: assertString(s.actor, 'story.actor'), goal: assertString(s.goal, 'story.goal'), soThat: optionalString(s.soThat), steps: normalizeStringList(s.steps, 'story.steps'), outcome: assertString(s.outcome, 'story.outcome') },
            accessPattern: normalizeAccessPattern(d.accessPattern, 'result.operationDefinition.accessPattern'),
            inputs: normalizeOperationInputs(d.inputs, 'result.operationDefinition.inputs'),
            contextResolution: normalizeContextResolution(d.contextResolution, 'result.operationDefinition.contextResolution'),
            acceptanceAssertions: normalizeStringList(d.acceptanceAssertions, 'result.operationDefinition.acceptanceAssertions'),
        },
    };
}
function normalizeAccessPattern(value, path) {
    const p = assertRecord(value, path);
    const kind = assertString(p.kind, `${path}.kind`);
    if (!['list', 'getById', 'lookup', 'commandInput'].includes(kind))
        throw new Error(`${path}.kind invalid`);
    const pagination = optionalString(p.pagination);
    const selection = optionalString(p.selection);
    return {
        kind,
        description: assertString(p.description, `${path}.description`),
        entity: optionalString(p.entity),
        keyField: optionalString(p.keyField),
        filters: normalizeStringList(p.filters, `${path}.filters`),
        sort: normalizeStringList(p.sort, `${path}.sort`),
        pagination: pagination && ['none', 'optional', 'required'].includes(pagination) ? pagination : undefined,
        selection: selection && ['none', 'single', 'multiple'].includes(selection) ? selection : undefined,
        output: normalizeStringList(p.output, `${path}.output`),
    };
}
function normalizeOperationInputs(value, path) {
    return assertArray(value || [], path).map((item, index) => {
        const input = assertRecord(item, `${path}[${index}]`);
        return {
            inputId: assertString(input.inputId, `${path}[${index}].inputId`),
            fieldRef: assertString(input.fieldRef, `${path}[${index}].fieldRef`),
            required: input.required === true,
            source: normalizeContextSource(input.source, `${path}[${index}].source`),
            description: assertString(input.description, `${path}[${index}].description`),
        };
    });
}
function normalizeContextResolution(value, path) {
    return assertArray(value || [], path).map((item, index) => {
        const ctx = assertRecord(item, `${path}[${index}]`);
        return {
            inputId: optionalString(ctx.inputId),
            fieldRef: assertString(ctx.fieldRef, `${path}[${index}].fieldRef`),
            source: normalizeContextSource(ctx.source, `${path}[${index}].source`),
            description: assertString(ctx.description, `${path}[${index}].description`),
        };
    });
}
function normalizeContextSource(value, path) {
    const source = assertString(value, path);
    if (['userInput', 'actorSession', 'currentWorkspace', 'selectedEntity', 'activeLifecycleInstance', 'workflowState', 'routeParam', 'previousStepOutput', 'systemDefault'].includes(source))
        return source;
    throw new Error(`${path} invalid`);
}
function attachBffNaming(context, def) {
    const moduleName = getApprovedModuleName(context) || 'module';
    const pageId = pageIdForOperation(context, def.operationId);
    const commandName = def.operationId;
    def.pageId = pageId;
    def.commandName = commandName;
    def.bffName = `${moduleName}.${pageId}.${commandName}`;
}
function pageIdForOperation(context, operationId) {
    try {
        const workflow = getBehaviorIndex(context).result.workflows.find(w => (w.operationIds || []).includes(operationId));
        if (workflow?.workflowId)
            return workflow.workflowId;
    }
    catch { /* fallback below */ }
    return operationId;
}
function capitalize(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}
const systemPrompt = `
<!-- modelType: codepro -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} for the collab.codes "newSolution2" flow (Stage 1).
Detail exactly ONE operation (the current selector) into its intent-level BFF contract.

Call the "{{toolName}}" tool with: status, result, questions, trace. Do not return prose.

In result.operationDefinition: operationId (== selector), title, actor (actorId), entity (canonical
ontology id), kind (create|update|delete|query|view), reads[] and writes[] (ontology entities or
"Entity.field" the operation reads/writes), rulesApplied[] (ruleIds), embedded story, accessPattern,
inputs[], contextResolution[] and acceptanceAssertions[].

Rules:
- operationId must equal the selector. No tables. Do not invent page, command or route names; the
  agent attaches pageId, commandName and bffName deterministically after the tool call.
- reads/writes reference canonical ontology ids (optionally "Entity.field"), never aggregate names.
- accessPattern.kind must be exactly one of list|getById|lookup|commandInput. For query/view, choose
  the user journey's best access: list for browsable sets, getById only when the journey already
  carries a selected id, lookup for compact selectors. For create/update/delete use commandInput.
- inputs[] must list every BFF input the frontend/backend contract needs. Each input.fieldRef must be
  an ontology field ref (Entity.field or Entity) and each input.source must be one of:
  userInput, actorSession, currentWorkspace, selectedEntity, activeLifecycleInstance, workflowState,
  routeParam, previousStepOutput, systemDefault.
- Required identifier inputs (id fields) must not be plain userInput. Resolve them from routeParam,
  selectedEntity, activeLifecycleInstance, workflowState or previousStepOutput whenever the system can
  know the value. If the actor selects it from a list/detail, use selectedEntity or previousStepOutput.
- contextResolution[] declares fields resolved by the system/runtime, never typed manually. Do not put
  persistence/table/usecase internals here.
- acceptanceAssertions[] must be objective checks for this operation, e.g. "opening the menu list
  requires no typed id" or "payment uses the order id selected in the journey".

`;
