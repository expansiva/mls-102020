/// <mls fileReference="_102020_/l2/agentNewSolution2/agentPlanOperationDefinition.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createPromptReadyIntent, createUpdateStatusIntent, getPlannerOutputs, normalizeStringList, optionalString, resolveCapabilityInfo, } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
import { createPlannerToolSchema, extractPlannerOutput, isRecord } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
import { getApprovedModuleName, operationFileInfo, readOntologyEntities, readOperationDefs, saveAgentTrace, saveDefsArtifact } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { operationDefinitionResultSchema } from '/_102020_/l2/agentNewSolution2/ns2Schemas.js';
import { getOperationIndex } from '/_102020_/l2/agentNewSolution2/agentPlanOperationIndex.js';
import { getBehaviorIndex } from '/_102020_/l2/agentNewSolution2/agentClassifyBehavior.js';
import { getEnrichedOntology } from '/_102020_/l2/agentNewSolution2/agentNs2EntityDefinition.js';
import { getFinalizeOutput } from '/_102020_/l2/agentNewSolution2/agentNs2Finalize.js';
const AGENT_NAME = 'agentPlanOperationDefinition';
const TOOL_NAME = 'submitOperationDefinition';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the definition for the current operation selector.', operationDefinitionResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102020, agentFolder: 'agentNewSolution2', agentDescription: 'Detail one operation into its intent-level BFF contract', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[${AGENT_NAME}] operation selector args invalid`);
    const indexItem = getOperationIndex(context).result.operations.find(o => o.operationId === args);
    if (!indexItem)
        throw new Error(`[${AGENT_NAME}] operation selector not in index: ${args}`);
    const story = getBehaviorIndex(context).result.operations.find(o => o.operationId === args)?.story;
    const ontology = await getEnrichedOntology(context);
    const entityShape = ontology[indexItem.entity];
    const behavior = getBehaviorIndex(context).result;
    const workflowOwner = behavior.workflows.find(w => (w.operationIds || []).includes(args));
    // Other entities go with id + title + description (not just ids) so a referenced entity is matched
    // by meaning; the operation's own target entity still goes fully expanded in entityShape.
    const ontologyEntities = Object.entries(ontology).map(([id, meta]) => ({ entityId: id, ...(isRecord(meta) ? { title: meta.title, description: meta.description } : {}) }));
    const reduced = { selector: args, indexItem, story, workflowOwner, entityShape, ontologyEntities };
    return [createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(TOOL_NAME), `## Operation selector\n${args}\n\n## Reduced context\n${JSON.stringify(reduced, null, 2)}\n`, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    const selector = (step.prompt || '').trim();
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlannerOutput(payload, config);
        if (selector && output.result.operationDefinition.operationId !== selector)
            output.result.operationDefinition.operationId = selector;
        // Any non-ok status (failed OR needs_input) fails the step loudly with the questions in the trace,
        // instead of silently completing without saving (which surfaced later as plan.disk.divergence).
        if (output.status !== 'ok') {
            status = 'failed';
            const questions = Array.isArray(output.questions) && output.questions.length ? ` — questions: ${output.questions.join(' | ')}` : '';
            traceMsg = `${AGENT_NAME} returned '${output.status}' for operation ${selector}${questions}`;
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${AGENT_NAME}] ${traceMsg}`);
    }
    if (status === 'completed' && output && output.status === 'ok') {
        const def = output.result.operationDefinition;
        try {
            // Attach the realized capability (id + title + priority) deterministically. A classified operation
            // carries its own capabilityId; an operation synthesized from a workflow's operationIds inherits the
            // capability of the workflow that orchestrates it.
            const behavior = getBehaviorIndex(context).result;
            const capabilityId = behavior.operations.find(o => o.operationId === def.operationId)?.capabilityId
                ?? behavior.workflows.find(w => (w.operationIds || []).includes(def.operationId))?.capabilityIds[0];
            def.capability = capabilityId ? resolveCapabilityInfo([capabilityId], getFinalizeOutput(context).result.capabilities)[0] : undefined;
            attachBffNaming(context, def);
            // Deterministic repair: rewrite generic 'Entity.id' refs to the entity's canonical pk field
            // (convention '<entity>Id') when it resolves in the ontology — removes a common LLM slip that
            // otherwise hard-fails validation (operation.context.origin.unknown / accessPattern.key.unknown).
            try {
                normalizeIdRefs(def, await readOntologyEntities(getApprovedModuleName(context) || ''));
            }
            catch { /* ontology optional */ }
        }
        catch (error) {
            status = 'failed';
            traceMsg = `prepare failed for operation ${selector}: ${error instanceof Error ? error.message : String(error)}`;
            console.error(`[${AGENT_NAME}] ${traceMsg}`);
        }
        // Save with one retry, then fail loudly (mirrors agentNs2EntityDefinition §14.1): a swallowed save
        // used to leave the operation missing on disk and only surface later as plan.disk.divergence.
        if (status === 'completed') {
            try {
                await saveDefsArtifact(operationFileInfo(def.operationId), `operation${capitalize(def.operationId)}`, def);
            }
            catch (firstError) {
                try {
                    await saveDefsArtifact(operationFileInfo(def.operationId), `operation${capitalize(def.operationId)}`, def);
                }
                catch (secondError) {
                    status = 'failed';
                    traceMsg = `save failed for operation ${selector}: ${secondError instanceof Error ? secondError.message : String(secondError)}`;
                    console.error(`[${AGENT_NAME}] ${traceMsg}`);
                }
            }
        }
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg)];
}
/** Reads the GLOBAL l4/operations/*.defs.ts (fan-out children are deleted); in-task payloads override. */
export async function getOperationDefinitions(context) {
    const byId = new Map();
    for (const d of await readOperationDefs()) {
        const id = typeof d.operationId === 'string' ? d.operationId : '';
        if (id)
            byId.set(id, d);
    }
    for (const o of getPlannerOutputs(context, AGENT_NAME, config)) {
        if (o.status === 'ok') {
            const def = o.result.operationDefinition;
            attachBffNaming(context, def);
            byId.set(def.operationId, def);
        }
    }
    return [...byId.values()];
}
const config = { toolName: TOOL_NAME, normalizeResult };
function normalizeResult(value) {
    const result = assertRecord(value, 'result');
    const d = assertRecord(result.operationDefinition, 'result.operationDefinition');
    const s = assertRecord(d.story, 'result.operationDefinition.story');
    return {
        operationDefinition: {
            operationId: assertString(d.operationId, 'result.operationDefinition.operationId'),
            title: assertString(d.title, 'result.operationDefinition.title'),
            actor: assertString(d.actor, 'result.operationDefinition.actor'),
            entity: assertString(d.entity, 'result.operationDefinition.entity'),
            kind: assertString(d.kind, 'result.operationDefinition.kind'),
            reads: normalizeStringList(d.reads, 'result.operationDefinition.reads'),
            writes: normalizeStringList(d.writes, 'result.operationDefinition.writes'),
            rulesApplied: normalizeStringList(d.rulesApplied, 'result.operationDefinition.rulesApplied'),
            story: { actor: assertString(s.actor, 'story.actor'), goal: assertString(s.goal, 'story.goal'), soThat: optionalString(s.soThat), steps: normalizeStringList(s.steps, 'story.steps'), outcome: assertString(s.outcome, 'story.outcome') },
            accessPattern: normalizeAccessPattern(d.accessPattern, 'result.operationDefinition.accessPattern'),
            inputs: normalizeOperationInputs(d.inputs, 'result.operationDefinition.inputs'),
            contextResolution: normalizeContextResolution(d.contextResolution, 'result.operationDefinition.contextResolution'),
            acceptanceAssertions: normalizeStringList(d.acceptanceAssertions, 'result.operationDefinition.acceptanceAssertions'),
        },
    };
}
function normalizeAccessPattern(value, path) {
    const p = assertRecord(value, path);
    const kind = assertString(p.kind, `${path}.kind`);
    if (!['list', 'getById', 'lookup', 'commandInput'].includes(kind))
        throw new Error(`${path}.kind invalid`);
    const pagination = optionalString(p.pagination);
    const selection = optionalString(p.selection);
    return {
        kind,
        description: assertString(p.description, `${path}.description`),
        entity: optionalString(p.entity),
        keyField: optionalString(p.keyField),
        filters: normalizeStringList(p.filters, `${path}.filters`),
        sort: normalizeStringList(p.sort, `${path}.sort`),
        pagination: pagination && ['none', 'optional', 'required'].includes(pagination) ? pagination : undefined,
        selection: selection && ['none', 'single', 'multiple'].includes(selection) ? selection : undefined,
        output: normalizeStringList(p.output, `${path}.output`),
    };
}
function normalizeOperationInputs(value, path) {
    return assertArray(value || [], path).map((item, index) => {
        const input = assertRecord(item, `${path}[${index}]`);
        return {
            inputId: assertString(input.inputId, `${path}[${index}].inputId`),
            fieldRef: assertString(input.fieldRef, `${path}[${index}].fieldRef`),
            required: input.required === true,
            source: normalizeContextSource(input.source, `${path}[${index}].source`),
            description: assertString(input.description, `${path}[${index}].description`),
        };
    });
}
function normalizeContextResolution(value, path) {
    return assertArray(value || [], path).map((item, index) => {
        const ctx = assertRecord(item, `${path}[${index}]`);
        return {
            inputId: optionalString(ctx.inputId),
            targetRef: assertString(ctx.targetRef, `${path}[${index}].targetRef`),
            source: normalizeContextSource(ctx.source, `${path}[${index}].source`),
            originRef: assertString(ctx.originRef, `${path}[${index}].originRef`),
            description: assertString(ctx.description, `${path}[${index}].description`),
        };
    });
}
function normalizeContextSource(value, path) {
    const source = assertString(value, path);
    if (['userInput', 'actorSession', 'businessContext', 'currentWorkspace', 'selectedEntity', 'activeLifecycleInstance', 'workflowState', 'routeParam', 'previousStepOutput', 'systemDefault'].includes(source))
        return source;
    throw new Error(`${path} invalid`);
}
function attachBffNaming(context, def) {
    const moduleName = getApprovedModuleName(context) || 'module';
    const pageId = pageIdForOperation(context, def.operationId);
    const commandName = def.operationId;
    def.pageId = pageId;
    def.commandName = commandName;
    def.bffName = `${moduleName}.${pageId}.${commandName}`;
}
function pageIdForOperation(context, operationId) {
    try {
        const workflow = getBehaviorIndex(context).result.workflows.find(w => (w.operationIds || []).includes(operationId));
        if (workflow?.workflowId)
            return workflow.workflowId;
    }
    catch { /* fallback below */ }
    return operationId;
}
function capitalize(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}
// Rewrite generic 'Entity.id' refs to the entity's canonical pk field (convention '<entity>Id', e.g.
// Order.id -> Order.orderId) when the pk resolves in the ontology and no literal 'id' field exists.
// Conservative: leaves the ref untouched if the entity/pk is unknown, so a real error still surfaces.
function normalizeIdRefs(def, ontology) {
    const fix = (ref) => {
        const dot = ref.indexOf('.');
        if (dot <= 0 || ref.slice(dot + 1) !== 'id')
            return ref;
        const entity = ref.slice(0, dot);
        const ent = ontology[entity];
        if (!ent || fieldExists(ent, 'id'))
            return ref;
        const pk = `${entity.charAt(0).toLowerCase()}${entity.slice(1)}Id`;
        return fieldExists(ent, pk) ? `${entity}.${pk}` : ref;
    };
    if (Array.isArray(def.inputs))
        for (const input of def.inputs)
            if (typeof input.fieldRef === 'string')
                input.fieldRef = fix(input.fieldRef);
    if (Array.isArray(def.contextResolution))
        for (const ctx of def.contextResolution) {
            if (typeof ctx.targetRef === 'string')
                ctx.targetRef = fix(ctx.targetRef);
            if (typeof ctx.originRef === 'string')
                ctx.originRef = fix(ctx.originRef);
        }
    if (def.accessPattern && typeof def.accessPattern.keyField === 'string')
        def.accessPattern.keyField = fix(def.accessPattern.keyField);
}
function fieldExists(entity, fieldId) {
    const fields = Array.isArray(entity.fields) ? entity.fields : [];
    return fields.some(field => !!field && typeof field === 'object' && field.fieldId === fieldId);
}
const systemPrompt = `
<!-- modelType: codepro -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} for the collab.codes "newSolution2" flow (Stage 1).
Detail exactly ONE operation (the current selector) into its intent-level BFF contract.

Call the "{{toolName}}" tool with: status, result, questions, trace. Do not return prose.

In result.operationDefinition: operationId (== selector), title, actor (actorId), entity (canonical
ontology id), kind (create|update|delete|query|view), reads[] and writes[] (ontology entities or
"Entity.field" the operation reads/writes), rulesApplied[] (ruleIds), embedded story, accessPattern,
inputs[], contextResolution[] and acceptanceAssertions[].

Rules:
- operationId must equal the selector. No tables. Do not invent page, command or route names; the
  agent attaches pageId, commandName and bffName deterministically after the tool call.
- reads/writes reference canonical ontology ids (optionally "Entity.field"), never aggregate names.
- accessPattern.kind must be exactly one of list|getById|lookup|commandInput. For query/view, choose
  the user journey's best access: list for browsable sets, getById only when the journey already
  carries a selected id, lookup for compact selectors. For create/update/delete use commandInput.
  Exception: a read-only compute/assistant query (e.g. an AI assistant answering a free-form question)
  may use commandInput — but only if it has NO keyField and NO filters/sort/pagination/selection
  (otherwise it is a list/getById and must say so) and writes[] is empty.
- accessPattern.keyField, when present, must be fully qualified as Entity.field; never use a bare id.
- inputs[] must list every BFF input the frontend/backend contract needs. Each input.fieldRef must be
  an ontology field ref (Entity.field or Entity) and each input.source must be one of:
  userInput, actorSession, businessContext, currentWorkspace, selectedEntity, activeLifecycleInstance, workflowState,
  routeParam, previousStepOutput, systemDefault.
- Composition: if this create/update writes a child entity that is "partOf" the operation's root entity
  (e.g. OrderItem partOf Order), you MUST declare that child as a composed input (fieldRef = the child
  entity, e.g. "OrderItem", a repeatable list like items[]). The root and its composed children are
  ONE BFF command / one submit — never a separate "save order" then "save order item". Do not split a
  parent+children write into two operations.
- Required technical identifier inputs must not be plain userInput. A technical identifier is a
  primary id generated by the system or a field whose ontology type references another entity. Resolve
  those ids from selectedEntity, routeParam, previousStepOutput, activeLifecycleInstance,
  workflowState, actorSession, businessContext, currentWorkspace or systemDefault. userInput is for business values the
  actor types or chooses by label/value, not for raw entity ids.
- contextResolution[] declares fields resolved by the system/runtime, never typed manually. Each item
  must have targetRef, source and originRef:
  - targetRef = the operation input, ontology field, BFF filter or runtime field being filled. Use one
    of these exact forms: Entity.field for domain data, input.<inputId> for an operation input,
    filter.<name> for a BFF/runtime filter, or one of the explicit runtime attributes below. Do not
    use loose names such as "id", "workspaceId" or "referenceDate".
  - source = one of the closed context sources.
  - originRef = the concrete source path.
  Valid originRef formats:
  - actorSession: actorSession.actorId or actorSession.scope.
  - businessContext: businessContext.activeCompanyId or businessContext.activeUnitId. Use this for
    business scope such as primary company/unit; do not use currentWorkspace as a company filter.
  - currentWorkspace: currentWorkspace.workspaceId.
  - systemDefault: systemDefault.now, systemDefault.uuid or systemDefault.locale.
  - selectedEntity, activeLifecycleInstance, workflowState: Entity.field.
- routeParam: routeParam.<name>, matching a journey edge/inputResolution.
- previousStepOutput: previousStepOutput.<operationId>.<field>, matching a journey edge/inputResolution.
  Do not put persistence/table/usecase internals here.
- acceptanceAssertions[] must be objective checks for this operation, such as "opening the list
  requires no typed technical id" or "the action uses the id selected in the journey".

`;
