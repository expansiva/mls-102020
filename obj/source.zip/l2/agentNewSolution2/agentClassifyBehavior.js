/// <mls fileReference="_102020_/l2/agentNewSolution2/agentClassifyBehavior.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createPromptReadyIntent, createUpdateStatusIntent, getActorIdSet, getOntologyEntityIdSet, getPlannerOutput, isKnownEntityRef, normalizeStringList, summarizeRecords, } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
import { createPlannerToolSchema, extractPlannerOutput } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
import { saveAgentTrace, saveIndexCheckpoint } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { behaviorClassificationResultSchema } from '/_102020_/l2/agentNewSolution2/ns2Schemas.js';
import { getFinalizeOutput } from '/_102020_/l2/agentNewSolution2/agentNs2Finalize.js';
import { getEnrichedOntology } from '/_102020_/l2/agentNewSolution2/agentNs2EntityDefinition.js';
import { getRequirementsClarificationAnswer } from '/_102020_/l2/agentNewSolution2/agentNewSolution2Requirements.js';
const AGENT_NAME = 'agentClassifyBehavior';
const TOOL_NAME = 'submitBehaviorIndex';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the behavior index (workflows + operations with embedded stories).', behaviorClassificationResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102020, agentFolder: 'agentNewSolution2', agentDescription: 'Classify capabilities into workflows vs operations (absorbing the user stories)', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[${AGENT_NAME}] args invalid`);
    const fp = getFinalizeOutput(context).result;
    const ontology = await getEnrichedOntology(context);
    const clarification = getRequirementsClarificationAnswer(context);
    const capabilities = summarizeRecords(fp.capabilities, ['capabilityId', 'title', 'actor', 'priority', 'behaviorHint']).filter(c => c.priority !== 'never');
    const human = `## Actors\n${JSON.stringify(summarizeRecords(fp.actors, ['actorId', 'title']), null, 2)}\n\n## Capabilities (own each one)\n${JSON.stringify(capabilities, null, 2)}\n\n## Ontology entity ids\n${JSON.stringify(Object.keys(ontology), null, 2)}\n\n## Rules\n${JSON.stringify(summarizeRecords(fp.rules, ['ruleId', 'title']), null, 2)}\n\n## Clarification (source for stories)\n${JSON.stringify(clarification, null, 2)}\n`;
    return [createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    const warnings = [];
    let output;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlannerOutput(payload, config);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = `${AGENT_NAME} returned failed`;
        }
        else
            warnings.push(...(await checkReferences(context, output.result)));
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${AGENT_NAME}] ${traceMsg}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    if (status === 'completed' && output)
        await saveIndexCheckpoint(context, 'behaviorIndex', output.result, warnings.map(message => ({ severity: 'warning', message })));
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg || (warnings.length ? `${warnings.length} reference warning(s)` : undefined))];
}
/** Deterministic, non-blocking ref integrity: unknown entity ids and uncovered capabilities -> warnings. */
async function checkReferences(context, index) {
    const warnings = [];
    const fp = getFinalizeOutput(context).result;
    const knownEntities = getOntologyEntityIdSet(await getEnrichedOntology(context));
    const knownActors = getActorIdSet(fp.actors);
    const checkEntity = (ref, where) => { if (!isKnownEntityRef(ref, knownEntities))
        warnings.push(`${where}: unknown entity ref '${ref}'`); };
    const checkActor = (ref, where) => { if (ref && knownActors.size > 0 && !knownActors.has(ref))
        warnings.push(`${where}: unknown actor '${ref}'`); };
    const opIds = new Set(index.operations.map(o => o.operationId));
    for (const w of index.workflows) {
        checkActor(w.actor, `workflow ${w.workflowId}`);
        for (const e of w.entities)
            checkEntity(e, `workflow ${w.workflowId}`);
        // item 4: workflow -> operation link must resolve and stateful workflows should orchestrate ops.
        for (const opId of w.operationIds)
            if (!opIds.has(opId))
                warnings.push(`workflow ${w.workflowId}: operationId '${opId}' is not in operations[]`);
        if (w.operationIds.length === 0)
            warnings.push(`workflow ${w.workflowId}: no operations orchestrated (stateful workflow with zero operations is a smell)`);
    }
    for (const o of index.operations) {
        checkActor(o.actor, `operation ${o.operationId}`);
        checkEntity(o.entity, `operation ${o.operationId}`);
    }
    const owned = new Set();
    for (const w of index.workflows)
        for (const c of w.capabilityIds)
            owned.add(c);
    for (const o of index.operations)
        owned.add(o.capabilityId);
    for (const cap of fp.capabilities) {
        if (cap.priority === 'now' && cap.capabilityId && !owned.has(cap.capabilityId))
            warnings.push(`capability '${cap.capabilityId}' (now) is not owned by any workflow or operation`);
    }
    return warnings;
}
export function getBehaviorIndex(context) {
    return getPlannerOutput(context, AGENT_NAME, config);
}
const config = { toolName: TOOL_NAME, normalizeResult };
function normalizeStory(value, path) {
    const s = assertRecord(value, path);
    return { actor: assertString(s.actor, `${path}.actor`), goal: assertString(s.goal, `${path}.goal`), soThat: typeof s.soThat === 'string' ? s.soThat : undefined, steps: normalizeStringList(s.steps, `${path}.steps`), outcome: assertString(s.outcome, `${path}.outcome`) };
}
function normalizeResult(value) {
    const result = assertRecord(value, 'result');
    const workflows = assertArray(result.workflows || [], 'result.workflows').map((item, index) => {
        const w = assertRecord(item, `result.workflows[${index}]`);
        return {
            workflowId: assertString(w.workflowId, `result.workflows[${index}].workflowId`),
            title: assertString(w.title, `result.workflows[${index}].title`),
            actor: assertString(w.actor, `result.workflows[${index}].actor`),
            entities: normalizeStringList(w.entities, `result.workflows[${index}].entities`),
            capabilityIds: normalizeStringList(w.capabilityIds, `result.workflows[${index}].capabilityIds`),
            operationIds: normalizeStringList(w.operationIds, `result.workflows[${index}].operationIds`),
            story: normalizeStory(w.story, `result.workflows[${index}].story`),
        };
    });
    const operations = assertArray(result.operations || [], 'result.operations').map((item, index) => {
        const o = assertRecord(item, `result.operations[${index}]`);
        return {
            operationId: assertString(o.operationId, `result.operations[${index}].operationId`),
            title: assertString(o.title, `result.operations[${index}].title`),
            actor: assertString(o.actor, `result.operations[${index}].actor`),
            entity: assertString(o.entity, `result.operations[${index}].entity`),
            kind: assertString(o.kind, `result.operations[${index}].kind`),
            capabilityId: assertString(o.capabilityId, `result.operations[${index}].capabilityId`),
            story: normalizeStory(o.story, `result.operations[${index}].story`),
        };
    });
    return { workflows, operations };
}
const systemPrompt = `
<!-- modelType: codereasoning -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} for the collab.codes "newSolution2" flow (Stage 1 — the heart of it).
Classify EVERY capability that is NOT priority "never" (i.e. now AND soon AND later) into exactly one of:
- a Workflow: stateful, triggered, spanning time and/or multiple actors (a request/order/approval lifecycle).
- an Operation: a direct action of ONE actor on ONE entity (create/update/delete/query/view; dashboards = query/view).
Do NOT drop soon/later capabilities — they must be classified too (their priority is carried by the
capability and used later to phase the work). Key screens the user asked for (e.g. dashboards, AI
summaries) are often "soon": classify them as query/view operations (AI ones call the platform LLM proxy).

Call the "{{toolName}}" tool with: status, result, questions, trace. Do not return prose.

In result:
- workflows[]: { workflowId, title, actor, entities[], capabilityIds[], operationIds[], story }.
- operations[]: { operationId, title, actor, entity, kind, capabilityId, story }.
- story = { actor, goal, soThat?, steps[], outcome } — derive it from the clarification/scope. These
  stories are the source material for the later journey map.

Rules:
- Use canonical ONTOLOGY entity ids for entities/entity (the provided ids), never aggregate/group names.
- Use actorId values for actors.
- Every capability that is not "never" must be owned by exactly one workflow or operation.
- Emit Operations for managing master-data / MDM entities (create/update/delete/query) even when the
  capability is implicit (e.g. manage categories, manage tables).
- workflow.operationIds: list the discrete reusable actions the workflow orchestrates AND emit each of
  those as an Operation in operations[] (e.g. createStockMovement, updateKitchenStatus,
  cancelOrderAndReconcile). A stateful workflow must NOT have an empty operationIds — every workflow
  step that creates/updates/changes-status of an entity is an Operation it orchestrates.
- camelCase workflowId/operationId.

`;
