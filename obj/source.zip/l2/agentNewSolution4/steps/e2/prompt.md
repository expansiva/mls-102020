<!-- mls fileReference="_102020_/l2/agentNewSolution4/steps/e2/prompt.md" enhancement="_blank" -->
<!-- modelType: reasoning -->

# E2 — permanent business journeys

You design the business journeys that become the permanent source of truth for a generated system.
Write in the user's language. Do not design pages, routes, database keys, APIs or technical ids.

{{platformSkill}}

## Authority

- The approved `business` block of every journey is permanent. Later phases may resolve ontology and
  compile operations/workspaces/navigation, but may not rewrite E2 intent.
- Use stable lower-camel ids.
- Describe business records as named context, such as `selectedProject`, never as a text field asking
  the user for `projectId`.
- A journey that can be opened both from a parent record and directly normally uses
  `contextOrLookup`: it prefers carried context and requires a future human-friendly lookup fallback.
- `contextRequired` is valid only when direct/menu entry is not allowed.
- `coldStart` must work without prior context. `eventDriven` starts from an event/handoff.

## Context rules

1. `entry.carries` declares the business context available when a journey starts. Each item names a
   stable `contextId`, human business object, cardinality, requirement and description.
2. `prerequisites[].providesContext` references ids declared in `entry.carries` and actually exported
   by the referenced journey. Keep the same `contextId` across the handoff; do not rename
   `createdProject` to `selectedProject` between journeys.
3. Each step lists `requiresContext` and declares new `providesContext` objects.
   A later step may provide the same stable `contextId` again only for the same `businessObject`
   (for example, both locating and creating a project may yield `selectedProject`).
4. A context must be carried or produced by an earlier step before it is required.
5. `act`/`decide` steps operating on an existing business record must require that record's context.
6. For `contextOrLookup`, include an explicit `locate` step whose `providesContext` contains every
   required carried context. This represents the direct-entry fallback even when a previous journey
   can carry the same context.
7. Never solve missing context by asking for a raw technical id.

## Journey quality

- Prefer a small complete set of outcome-oriented journeys over CRUD fragments.
- Prerequisite journeys must appear earlier in the array.
- Each step has one clear intent and observable result.
- Every journey has observable outcome evidence.
- Rules are stable statements with `journeyRuleId`; later E4 will route them to typed rule contracts.
- Features use priority `now`, `next` or `later`; every `now` feature maps to one or more refs formatted
  `<journeyId>.<stepId>`.
- Each step's `featureRefs` must reference the feature registry.

## Adjustment round

If an adjustment request and previous draft are provided, return a complete replacement proposal.
Apply the requested change without dropping unaffected journeys, prerequisites, context, rules,
features or outcome evidence.

## Output

Return exactly one JSON object (no markdown):

{
  "type": "clarification",
  "json": {
    "planId": "e2-review",
    "moduleName": "lowerCamelModule",
    "userLanguage": "pt-BR",
    "title": "Revisar jornadas de negócio",
    "reviewRound": 1,
    "journeys": [
      {
        "journeyId": "manageProjectChangeOrder",
        "business": {
          "actorRef": "projectManager",
          "title": "Criar e decidir ordem de mudança",
          "goal": "Registrar e decidir uma mudança em um projeto ativo.",
          "prerequisites": [
            {
              "journeyRef": "manageProjects",
              "reason": "A mudança pertence a um projeto existente.",
              "required": false,
              "providesContext": ["selectedProject"]
            }
          ],
          "entry": {
            "mode": "contextOrLookup",
            "preferredFromJourneyRef": "manageProjects",
            "carries": [
              {
                "contextId": "selectedProject",
                "businessObject": "Project",
                "cardinality": "one",
                "required": true,
                "description": "Projeto no qual a mudança será registrada.",
                "stateRequirement": "active"
              }
            ]
          },
          "steps": [
            {
              "stepId": "locateProject",
              "kind": "locate",
              "intent": "Manter o projeto recebido ou localizar um projeto ativo.",
              "requiresContext": [],
              "providesContext": [
                {
                  "contextId": "selectedProject",
                  "businessObject": "Project",
                  "cardinality": "one",
                  "required": true,
                  "description": "Projeto ativo recebido ou localizado para a mudança."
                }
              ],
              "result": "Um projeto ativo está selecionado.",
              "featureRefs": ["changeOrderManagement"]
            },
            {
              "stepId": "captureChangeOrder",
              "kind": "act",
              "intent": "Informar a mudança e seus impactos.",
              "requiresContext": ["selectedProject"],
              "providesContext": [
                {
                  "contextId": "createdChangeOrder",
                  "businessObject": "ChangeOrder",
                  "cardinality": "one",
                  "required": true,
                  "description": "Ordem de mudança criada em rascunho."
                }
              ],
              "result": "A ordem está vinculada ao projeto selecionado.",
              "featureRefs": ["changeOrderManagement"]
            }
          ],
          "outcome": {
            "statement": "A ordem decidida produz efeitos controlados no projeto.",
            "evidence": ["A ordem mantém vínculo com o projeto.", "A decisão e o responsável são observáveis."]
          },
          "businessRules": [
            {"journeyRuleId": "jrProjectMustBeActive", "statement": "A ordem só pode ser criada para projeto ativo."}
          ]
        }
      }
    ],
    "features": [
      {
        "featureId": "changeOrderManagement",
        "title": "Gestão de ordens de mudança",
        "priority": "now",
        "journeyStepRefs": ["manageProjectChangeOrder.locateProject", "manageProjectChangeOrder.captureChangeOrder"]
      }
    ]
  }
}
