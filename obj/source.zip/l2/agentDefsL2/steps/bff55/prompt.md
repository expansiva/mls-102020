Design the BFF of one page: the endpoints the page calls, as functions of the page, never one per organism or one
per entity. Read the page intent, its sections, the organisms with their text and intents, what each organism reads,
edits, selects and submits (page11Needs), the writes the plan allows, the journeys of the page, the L4 entities it
touches (fields, derived fields, transitions with payload, relationships, capabilities), the rule texts and the grants
of the page actors.

Decide how many endpoints there are, the shape of each output, paging, filters and names. Weigh what is best for the
app: transfer and performance. Load what the page shows when it opens in one call, already in the shape the page uses:
a header with its lines, an indicator already computed, a list already filtered by the situation the intent names.
Fetch on demand what the person searches or selects. Page a list only when it can grow beyond what one screen needs.
What the endpoint filters, cuts or limits comes from the inputs (L4 rules, fields, capabilities and grants); do not write a maximum quantity, a cut, a fixed number or a threshold the L4 does not name; a list that can grow beyond one screen is paged as this prompt already defines, never truncated.
A command returns the record it changed, in its new state, with its lines and totals. An indicator is computed in the
endpoint: the output is the number, never a raw list for the page to sum.

Kinds and triggers:
- qry runs onLoad or on interaction; cmd runs on a submit intent and its when is that intent id.
- Every submit intent has exactly one cmd. Its writes is the write the page draft binds to that intent.
- A cmd input carries what its write asks for: the transition payload; on create, the fields the page edits for that
  entity and the required foreign key of the context; on update and transition, the id and the version when the entity declares them; for an entity of another system, the inputs of the connection operation.

Types and origins:
- types are named shapes reused by several endpoints, such as a record with its lines. A field is a leaf: string,
  number, boolean, a union of literals ('a' | 'b'), or the name of another type; add [] for a list. Nested shapes are
  always a named type.
- A type description says what the record is, never where or how the page uses it.
- A leaf with a field origin keeps the field's place in the ontology: in a shape, the path relative to the shape's
  root entity, nested as the ontology nests it; a field of another entity in the same shape sits under that entity's
  name in lowerCamel. The code writes those names from the origin, and the field keeps its ontology type.
- A list the page pages is marked paginated: the contract gives it as { items, page, pageSize, hasMore } and the
  query takes page and pageSize, plus the filters and the search it needs. Do not invent another paging shape (no
  total, no cursor). A list that is not paged stays a plain list.
- Every value leaf names its origin: field with the one Entity.path it carries; aggregate with every Entity.path the
  value is computed from; context for a value that comes from the URL or a selection and fills no stored field.
- A leaf that names another type carries origin: null. A value leaf never carries null.
- The person who calls is never an input: the server knows who is logged in, fills the creator or the person of
  their own records with them and filters the records that are theirs. Do not ask the page for that person, in a command or a query.
- A cmd input leaf that fills a stored field uses field with that field's Entity.path, never context.
- coverage lists every Entity.path the organisms read, with derived marking a field the server computes. Each one is
  the origin of some output leaf, or is inside an aggregate; a derived field is no exception.
- A literal union uses only values of that L4 enum.
- Use only fields the page actors can see through their grants.

rules lists, for each endpoint, the rules whose text binds what this endpoint does: what a command must refuse or
record, what a query computes. Read the rule text, not the entity: a rule about cancelling does not apply to adding.

jsdoc is written for the person and the model that implement the endpoint, in userLanguage:
- purpose: what the function does for the page, not the organism text;
- input: the meaning of each input;
- processing: the filter, the composition, the computation and the rules it applies, by id and by what they demand;
  a derived field is computed, never stored or recorded by the endpoint;
- output: what comes back: which record, in which state, with what. Say what it is, never what the page does with it
  (insert, replace, reload, redraw): that is the page's decision.

bindings link the page to its endpoints; the shared and the contract are written from them by code:
- organisms: for every organism that reads, one or more sources, one for each output key it shows, each as
  <endpointId>.<output key>.
- commands: for each command, the queries the page reloads after it. A command whose output already redraws a state does
  not reload it; list a query only for what the output does not bring back.
- selections: for every organism that selects, how the selected record is resolved: kind query with the endpoint that
  loads it by id, or kind list with the <endpointId>.<output key> that already holds it.
- updates: where an endpoint's output lands, as a source already listed in organisms, with the mode: replace (a search
  replaces the list), append (the next page is added), upsert (a saved record is inserted or updated in place) or remove.
  Every command and every interaction query has a destination: an update, a reload (commands) or an organism that reads
  its own output.
- journeys: for each journey step of the page (journeySteps), the organisms and the endpoints that serve it, or the page
  it continues in (menuPages).

When approved is present, the page is being redone: keep what still fits the inputs and change only what they changed.
When repair is present, fix exactly the findings named in repair.diagnostic and keep the rest.
