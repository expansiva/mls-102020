/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/run.ts" enhancement="_blank"/>

import { readJson, writeJson, writeSourceText, type Ns5FileInfo } from '/_102035_/l2/solution/fs.js';
import type { Ns5OntologyAnyEntity } from '/_102035_/l2/solution/types.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { d2NormalizeWriteKey, d2WriteKey, type D2Write } from '/_102020_/l2/helpers/defsInput/writeKey.js';
import type { D2InputSnapshot, D2InputArtifacts, D2SelectedPage, D2RunIdentity } from '/_102020_/l2/helpers/defsInput/contracts.js';
import { buildD2Page11WithExperience, gateD2Page11, gateD2Page11Pair, type D2Page11GateSources, type D2Page11Menu, type D2Page11NeedPage } from '/_102020_/l2/agentDefsL2/helpers/page11Gate.js';
import { renderD2Page11Definition, type D2Page11Definition, type D2Page11Device } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs, type D2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import type { D2MoleculeInventory, D2MoleculeGroup } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.js';
import { gateD2MoleculeRoles, moleculeDecisionContext } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeSelection.js';
import type { D2PageTemplateContext } from '/_102020_/l2/agentDefsL2/steps/pages50/templateContext.js';

export const D2_PAGES_VERSION = '2026-09-30-agent-defs-l2-pages-v2.1' as const;
export const D2_PAGE11_NEEDS_VERSION = '2026-09-30-agent-defs-l2-page11-needs-v1' as const;
export const D2_PAGES_PROMPT_LIMIT_CHARS = 640_000;

export interface D2PagesResponse {
  desktop: { definition: unknown; needs: unknown };
  mobile: { definition: unknown; needs: unknown };
  categoryReason: string;
}
export interface D2PagesReceipt {
  schemaVersion: typeof D2_PAGES_VERSION;
  needsVersion: typeof D2_PAGE11_NEEDS_VERSION;
  project: number;
  module: string;
  pageId: string;
  inputHash: string;
  unitInputHash: string;
  template: { category: string; experience: string; reason: string; reference: string | null; hash: string; catalogHash: string };
  moleculeInventoryHash: string;
  moleculeHashes: Record<string, string>;
  moleculeGroupAssessments?: D2PagesContext['groupAssessments'];
  skillHash: string;
  promptHash: string;
  promptChars: number;
  repairPromptChars: number;
  needsHashes: Record<D2Page11Device, string>;
  sourceHashes: Record<D2Page11Device, string>;
  menuOrigins: Array<{ organismId: string; sourceIndex: number; kind: string; text: string }>;
}

export interface D2PagesContext {
  identity: D2RunIdentity;
  snapshot: D2InputSnapshot;
  artifacts: D2InputArtifacts;
  page: D2SelectedPage;
  template: D2PageTemplateContext;
  inventory: D2MoleculeInventory;
  selectedGroups: Record<string, string[]>;
  groupAssessments?: Array<{ organismId: string; groups: Array<{ groupId: string; relevant: boolean; reason: string }> }>;
  groups: D2MoleculeGroup[];
  moleculeHashes: Record<string, string>;
  skill: string;
  prompt: string;
}

function record(value: unknown): Record<string, unknown> { return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {}; }
function text(value: unknown): string { return typeof value === 'string' ? value.trim() : ''; }
function menuOrigins(page: D2SelectedPage, definition?: D2Page11Definition): D2PagesReceipt['menuOrigins'] {
  const assigned = new Set<string>();
  return page.organisms.map((raw, sourceIndex) => {
    const item = record(raw);
    const kind = text(item.kind);
    const organismId = definition ? Object.entries(definition.organisms).find(([id, value]) => value.kind === kind && !assigned.has(id))?.[0] ?? '' : `organism${sourceIndex + 1}`;
    assigned.add(organismId);
    return { organismId, sourceIndex, kind, text: text(item.text) };
  });
}
function owned(identity: D2RunIdentity, pageId: string): Ns5FileInfo { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/pages50`, shortName: pageId, extension: '.json' }; }
export function sourceInfo(identity: D2RunIdentity, pageId: string, device: D2Page11Device): Ns5FileInfo { return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' }; }
export function needsInfo(identity: D2RunIdentity, pageId: string, device: D2Page11Device): Ns5FileInfo { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' }; }

/** A page fingerprint avoids invalidating its receipt when another page changes. */
export async function pageUnitInputHash(context: D2PagesContext): Promise<string> {
  const { page, artifacts } = context;
  const needsPage = (record(artifacts.needs).pages as unknown[] | undefined)?.find(item => text(record(item).pageId) === page.pageId) ?? null;
  const contextText = JSON.stringify({ page, needsPage });
  const entities = Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => contextText.includes(id)));
  const journeys = Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]]));
  const entityIds = new Set(Object.keys(entities));
  for (const row of [...page.reads, ...page.writes, ...((record(needsPage).reads as unknown[] | undefined) ?? []), ...((record(needsPage).writes as unknown[] | undefined) ?? [])]) {
    const entity = text(record(row).entity);
    if (entity) entityIds.add(entity);
  }
  for (const binding of page.operationBindings ?? []) entityIds.add(binding.entityId);
  const actors = new Set(page.actors);
  const grants = ((record(artifacts.access).grants as unknown[] | undefined) ?? [])
    .filter(raw => actors.has(text(record(raw).actorRef)) && ((record(raw).entityRefs as unknown[] | undefined) ?? []).some(id => entityIds.has(text(id))))
    .map(raw => {
      const grant = record(raw);
      const disclosure = record(grant.disclosure);
      return canonicalValue({ ...grant,
        entityRefs: [...((grant.entityRefs as string[] | undefined) ?? [])].sort(),
        disclosure: { ...disclosure,
          ...(Array.isArray(disclosure.allowedFields) ? { allowedFields: [...disclosure.allowedFields].sort() } : {}),
          ...(Array.isArray(disclosure.deniedFields) ? { deniedFields: [...disclosure.deniedFields].sort() } : {}),
        },
      });
    })
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
  return sha256Text(JSON.stringify(canonicalValue({ page, needsPage, entities, journeys,
    userLanguage: text(record(artifacts.menu).userLanguage) || 'en', grants })));
}

function canonicalValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (value && typeof value === 'object') {
    const source = value as Record<string, unknown>;
    return Object.fromEntries(Object.keys(source).sort().map(key => [key, canonicalValue(source[key])]));
  }
  return value;
}

/** Lists the code already knows for the page decision; each becomes an enum of the tool schema (d2_67). */
export interface D2PageChoiceEnums { writeKeys: string[]; categories: string[]; kinds: string[]; targets: string[]; tags: string[] }
export function d2PageChoiceEnums(context: D2PagesContext): D2PageChoiceEnums {
  const pageIds: string[] = [];
  const walk = (nodes: unknown[]): void => { for (const raw of nodes) {
    const node = record(raw);
    if (text(node.kind) === 'page' && text(node.id)) pageIds.push(text(node.id));
    walk(Array.isArray(node.children) ? node.children : []);
  } };
  walk(Array.isArray(record(context.artifacts.menu).tree) ? record(context.artifacts.menu).tree as unknown[] : []);
  return {
    writeKeys: d2PageWriteKeys(context.page),
    categories: [...context.template.categories.filter(item => item.experiences?.page11 || item.experiences?.page21).map(item => item.categoryId), 'bespoke'],
    kinds: [...new Set(context.page.organisms.map(raw => text(record(raw).kind)).filter(Boolean))],
    // A submit has no target: '' is the value for it.
    targets: ['', ...new Set(pageIds)],
    tags: [...new Set(context.groups.flatMap(group => group.tags))],
  };
}

/** The exact write keys of the page; a submit writes one of them (schema enum and prompt list). */
export function d2PageWriteKeys(page: D2SelectedPage): string[] {
  return [...new Set((page.writes as unknown[]).map(raw => {
    const row = record(raw);
    return d2WriteKey({ entity: text(row.entity), operation: text(row.operation), transitionRef: text(row.transitionRef) });
  }))];
}

function pageWrites(page: D2SelectedPage): D2Write[] {
  return (page.writes as unknown[]).map(raw => { const row = record(raw); return { entity: text(row.entity), operation: text(row.operation), transitionRef: text(row.transitionRef) }; });
}

/** `Entity.transition` from the answer resolves to the page's only transition of that entity, or is refused naming the keys. */
function normalizeSubmitWrites(needs: unknown, writes: readonly D2Write[]): unknown {
  const root = record(needs);
  const organisms = record(root.organisms);
  return { ...root, organisms: Object.fromEntries(Object.entries(organisms).map(([id, raw]) => {
    const unit = record(raw);
    const submits = Array.isArray(unit.submits) ? unit.submits.map(item => {
      const submit = record(item);
      return typeof submit.write === 'string' ? { ...submit, write: d2NormalizeWriteKey(submit.write, writes) } : submit;
    }) : unit.submits;
    return [id, { ...unit, submits }];
  })) };
}

export function buildD2PagesDecisionPrompt(context: D2PagesContext, repair?: { diagnostic: string; previous: unknown }, approved?: D2ApprovedPage11 | null): { prompt: string; chars: number } {
  const { page, artifacts } = context;
  const payload = {
    page: { pageId: page.pageId, label: page.label, actors: page.actors, authorityRefs: page.authorityRefs,
      ancestors: page.ancestors, organisms: menuOrigins(page), reads: page.reads, writes: page.writes, writeKeys: d2PageWriteKeys(page),
      journeys: Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]])),
      userLanguage: text(record(artifacts.menu).userLanguage) || 'en' },
    menu: artifacts.menu,
    // Other pages only matter for the writes a navigate may cover; this page keeps its full needs.
    needs: { pages: ((record(artifacts.needs).pages as unknown[] | undefined) ?? []).map(raw => {
      const row = record(raw);
      return text(row.pageId) === page.pageId ? row : { pageId: row.pageId, writes: row.writes };
    }) },
    ontology: Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => JSON.stringify([page.reads, page.writes, page.organisms]).includes(id))),
    // Disclosure is checked against the page actors' grants only.
    access: { grants: ((record(artifacts.access).grants as unknown[] | undefined) ?? []).filter(raw => page.actors.includes(text(record(raw).actorRef))) },
    categories: context.template.categories,
    moleculeResearch: JSON.parse(moleculeDecisionContext(context.selectedGroups, context.groups)),
    // d2_71: a regeneration starts from the approved page11 and changes only what the reason asks.
    approved: approved ? { desktop: { definition: approved.definitions.desktop, needs: approved.needs.desktop }, mobile: { definition: approved.definitions.mobile, needs: approved.needs.mobile } } : null,
    regeneration: approved ? { reason: d2RegenerationReason(context, approved) } : null,
    repair: repair ?? null,
  };
  const prompt = JSON.stringify(payload);
  if (prompt.length > D2_PAGES_PROMPT_LIMIT_CHARS) throw new Error(`D2_PAGE11_PROMPT_LIMIT: ${prompt.length} > ${D2_PAGES_PROMPT_LIMIT_CHARS}`);
  return { prompt, chars: prompt.length };
}

export interface D2PagesWriter { writeSource(info: Ns5FileInfo, source: string): Promise<void>; writeJson(info: Ns5FileInfo, value: unknown): Promise<unknown> }
const productionWriter: D2PagesWriter = { writeSource: writeSourceText, writeJson };
/** Every page11 gate the approval runs, for an answer or for an approved page11 under the current inputs. */
export function d2PageIssues(context: D2PagesContext, definitions: Record<D2Page11Device, D2Page11Definition>, needs: Record<D2Page11Device, D2Page11Needs>, promptChars = 0): Array<{ code: string; path: string; message: string }> {
  const menu = context.artifacts.menu as D2Page11Menu;
  const needPages = record(context.artifacts.needs).pages as D2Page11NeedPage[];
  if (!Array.isArray(needPages)) throw new Error('D2_PAGE11_SOURCE_NEEDS');
  const sources: D2Page11GateSources = { pageId: context.page.pageId, actor: context.page.actors[0], menu,
    needsPages: needPages, entities: context.artifacts.entities as Record<string, Ns5OntologyAnyEntity>,
    access: context.artifacts.access as D2Page11GateSources['access'], categories: context.template.categories,
    templatePaths: context.template.templatePaths, moleculeTags: new Set(context.groups.flatMap(group => group.tags)),
    promptTokens: Math.ceil(promptChars / 4) };
  const origins = menuOrigins(context.page, definitions.desktop);
  const groupsByOrganism = Object.fromEntries(origins.map(origin => [origin.organismId, context.selectedGroups[`organism${origin.sourceIndex + 1}`] ?? []]));
  const kindMismatch = Object.keys(definitions.desktop.organisms).filter(id => definitions.mobile.organisms[id]?.kind !== definitions.desktop.organisms[id].kind);
  return [...gateD2Page11Pair(definitions.desktop, definitions.mobile),
    ...kindMismatch.map(id => ({ code: 'D2_PAGE11_DEVICE_KIND', path: `organisms.${id}`, message: `Organism ${id} has different kinds across devices.` })),
    ...(['desktop', 'mobile'] as const).flatMap(device => [
      ...context.page.actors.flatMap(actor => gateD2Page11(definitions[device], needs[device], { ...sources, actor })),
      ...gateD2MoleculeRoles(definitions[device].molecules, groupsByOrganism, context.groups).map(message => ({ code: 'D2_MOLECULE_ROLE_UNSELECTED', path: device, message })),
    ])];
}

/** The page11 already approved for this page, kept as the base of a regeneration (d2_71). */
export interface D2ApprovedPage11 { definitions: Record<D2Page11Device, D2Page11Definition>; needs: Record<D2Page11Device, D2Page11Needs> }

/** Molecule tags a page11 chose, with the organisms that use each. */
export function d2ChosenMolecules(definitions: Record<D2Page11Device, D2Page11Definition>): Map<string, Set<string>> {
  const chosen = new Map<string, Set<string>>();
  for (const definition of Object.values(definitions)) {
    for (const [organismId, choices] of Object.entries(definition.molecules)) {
      for (const choice of choices) for (const tag of [choice.preferred, choice.alternative]) {
        if (tag) chosen.set(tag, (chosen.get(tag) ?? new Set()).add(organismId));
      }
    }
  }
  return chosen;
}

/**
 * Why an approved page11 is regenerated: what its current gate refuses, the molecules it chose that left the catalog,
 * and the writes the page gained or lost. The answer keeps everything else (ids, prose, molecules).
 */
export function d2RegenerationReason(context: D2PagesContext, approved: D2ApprovedPage11): string[] {
  const reasons: string[] = [];
  const tags = new Set(context.groups.flatMap(group => group.tags));
  for (const [tag, organisms] of d2ChosenMolecules(approved.definitions)) {
    if (!tags.has(tag)) reasons.push(`molecule ${tag} is no longer in the catalog; change it only in ${[...organisms].sort().join(', ')}`);
  }
  const pageKeys = new Set(d2PageWriteKeys(context.page));
  const submitted = new Set(Object.values(approved.needs).flatMap(needs => Object.values(needs.organisms).flatMap(unit => unit.submits.map(submit => submit.write))));
  for (const key of pageKeys) if (!submitted.has(key)) reasons.push(`the page now writes ${key}; add its submit (or navigate) and keep the rest`);
  for (const key of submitted) if (!pageKeys.has(key)) reasons.push(`the page no longer writes ${key}; remove its submit and keep the rest`);
  for (const issue of d2PageIssues(context, approved.definitions, approved.needs)) {
    if (issue.code === 'D2_PAGE11_WRITE_UNCOVERED' || issue.code === 'D2_PAGE11_SUBMIT_WRITE' || issue.code === 'D2_PAGE11_MOLECULE_UNKNOWN') continue;
    reasons.push(`${issue.code} at ${issue.path}: ${issue.message}`);
  }
  if (!reasons.length) reasons.push('the generator or the page inputs changed; keep the approved page11 unless a gate refuses it');
  return [...new Set(reasons)];
}

export async function approveD2PagesUnit(context: D2PagesContext, raw: D2PagesResponse, promptChars: number, repairPromptChars = 0, writer: D2PagesWriter = productionWriter): Promise<D2PagesReceipt> {
  const category = text(record(record(raw.desktop).definition).template && record(record(record(raw.desktop).definition).template).category);
  if (!category || category !== text(record(record(record(raw.mobile).definition).template).category)) throw new Error('D2_PAGE11_DEVICE_CATEGORY');
  if (!text(raw.categoryReason)) throw new Error('D2_PAGE11_CATEGORY_REASON');
  const selectedTemplate = await context.template.select(category);
  const definitions: Record<D2Page11Device, D2Page11Definition> = {
    desktop: buildD2Page11WithExperience(raw.desktop.definition, context.template.categories),
    mobile: buildD2Page11WithExperience(raw.mobile.definition, context.template.categories),
  };
  const writes = pageWrites(context.page);
  const needs: Record<D2Page11Device, D2Page11Needs> = {
    desktop: buildD2Page11Needs(normalizeSubmitWrites(raw.desktop.needs, writes)),
    mobile: buildD2Page11Needs(normalizeSubmitWrites(raw.mobile.needs, writes)),
  };
  if (!context.page.actors.length) throw new Error('D2_PAGE11_ACTOR_MISSING');
  const issues = d2PageIssues(context, definitions, needs, Math.max(promptChars, repairPromptChars));
  if (issues.length) throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
  const origins = menuOrigins(context.page, definitions.desktop);
  if (origins.some(origin => !origin.organismId)) throw new Error('D2_PAGE11_MENU_ORIGIN_MISSING');
  const sourcesText = Object.fromEntries((['desktop', 'mobile'] as const).map(device => [device, renderD2Page11Definition({ ...context.identity, pageId: context.page.pageId, device }, definitions[device])])) as Record<D2Page11Device, string>;
  const needsText = Object.fromEntries((['desktop', 'mobile'] as const).map(device => [device, JSON.stringify(needs[device])])) as Record<D2Page11Device, string>;
  const receipt: D2PagesReceipt = {
    schemaVersion: D2_PAGES_VERSION, needsVersion: D2_PAGE11_NEEDS_VERSION, ...context.identity, pageId: context.page.pageId,
    inputHash: context.snapshot.snapshotHash,
    unitInputHash: await pageUnitInputHash(context),
    template: { category, experience: selectedTemplate.experience, reason: `${raw.categoryReason} ${selectedTemplate.reason}`, reference: selectedTemplate.reference, hash: selectedTemplate.hash, catalogHash: await sha256Text(context.template.catalog) },
    moleculeInventoryHash: context.inventory.sourceHash, moleculeHashes: context.moleculeHashes, moleculeGroupAssessments: context.groupAssessments,
    skillHash: await sha256Text(context.skill), promptHash: await sha256Text(context.prompt), promptChars, repairPromptChars,
    sourceHashes: { desktop: await sha256Text(sourcesText.desktop), mobile: await sha256Text(sourcesText.mobile) },
    needsHashes: { desktop: await sha256Text(needsText.desktop), mobile: await sha256Text(needsText.mobile) },
    menuOrigins: origins,
  };
  for (const device of ['desktop', 'mobile'] as const) {
    await writer.writeSource(sourceInfo(context.identity, context.page.pageId, device), sourcesText[device]);
    await writer.writeJson(needsInfo(context.identity, context.page.pageId, device), needs[device]);
  }
  await writer.writeJson(owned(context.identity, context.page.pageId), receipt);
  return receipt;
}

export async function readD2PagesReceipt(identity: D2RunIdentity, pageId: string): Promise<D2PagesReceipt | null> { return readJson<D2PagesReceipt>(owned(identity, pageId)); }
