# Changelog

- 2026-09-21 — Reserved by d2_01; no hook or placeholder approval exists.
- 2026-09-21 — d2_06 added the compact molecule inventory and selected-group resolver. Discovery stays
  project-relative, all reads record stor/published provenance, selected index + handwritten usage refs
  are normalized/deduplicated for `pipeline.skills`, and real UTF-8 context bytes are measured.
- 2026-09-21 — d2_07 implemented the pages50 coordinator/worker, closed two-device judgment, shared
  capability parity gate, deterministic defs/pipeline rendering, minimal consumer parser and hash barrier.
- 2026-09-23 — d2_12 added canonical category classification, mandatory technical/category skills,
  scenario-backed molecule candidates with exact tag validation, and catalog/skill context hashes for reuse.
- 2026-09-23 — d2_13 added per-organism descriptions, real Scene/content references and capability parity.
- 2026-09-23 — d2_14 removed inverse Scene coverage and made a real compatible molecule recommendation
  mandatory per non-static organism for query/view, input/entry and command/trigger families. Receipt v4
  invalidates earlier all-empty results; static or genuinely unmatched organisms retain an explained empty.
- 2026-09-23 — d2_16 adds project-level `l2/designSystem.ts` after shared in every page11
  `dependsFiles`. Parser/finalize require the exact ordered pair; materializers resolve the relative ref
  against the active project, summarize real token names, fail nominally when absent and observe token edits.
  Receipt v5 invalidates defs emitted with the old dependency list.
