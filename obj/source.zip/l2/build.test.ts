/// <mls shortName="build" project="102020" enhancement="_blank" folder="" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];