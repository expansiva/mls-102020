/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeStudio.ts" enhancement="_blank"/>

import { parseDefs, type PipelineItem } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeCore.js';
import { createStorFile } from '/_102027_/l2/libStor.js';

declare const mls: any;

export interface MaterializeStudioMessage {
  level: 'warn' | 'error';
  message: string;
}

export interface GenStepArgs {
  planId: string;
  defPath: string;
  /**
   * WHICH pipeline item of that defs this slot generates.
   *
   * One defs used to mean one artifact, so the slot could assume `pipeline[0]`. A SPLIT page breaks that:
   * the same defs carries N organisms plus the page (paginaDividida.md §5), and without this the slot
   * would always build the first one. Optional so a task queued before this change still resolves to
   * `pipeline[0]`, which is what it meant.
   */
  itemId?: string;
  attempt?: number;
  repairHint?: string;
}

export interface ParsedMlsPath {
  project: number;
  level: number;
  folder: string;
  shortName: string;
  extension: string;
}

export function parsePipelineFromContent(content: string): PipelineItem[] | null {
  const parsed = parseDefs(content);
  return parsed.item ? [parsed.item] : null;
}

const studioMessages: MaterializeStudioMessage[] = [];

export function consumeMaterializeStudioMessages(): MaterializeStudioMessage[] {
  const ret = [...studioMessages];
  studioMessages.length = 0;
  return ret;
}

export function parseMlsPath(mlsPath: string): ParsedMlsPath | null {
  const match = mlsPath.match(/^_(\d+)_\/l(\d+)\/(.+)$/);
  if (!match) return null;

  const project = Number(match[1]);
  const level = Number(match[2]);
  const rest = match[3];
  const lastSlash = rest.lastIndexOf('/');
  const folder = lastSlash >= 0 ? rest.slice(0, lastSlash) : '';
  const filename = lastSlash >= 0 ? rest.slice(lastSlash + 1) : rest;

  if (filename.endsWith('.defs.ts')) {
    return { project, level, folder, shortName: filename.slice(0, -'.defs.ts'.length), extension: '.defs.ts' };
  }
  if (filename.endsWith('.test.ts')) {
    return { project, level, folder, shortName: filename.slice(0, -'.test.ts'.length), extension: '.test.ts' };
  }
  if (filename.endsWith('.d.ts')) {
    return { project, level, folder, shortName: filename.slice(0, -'.d.ts'.length), extension: '.d.ts' };
  }

  const dot = filename.lastIndexOf('.');
  return {
    project,
    level,
    folder,
    shortName: dot >= 0 ? filename.slice(0, dot) : filename,
    extension: dot >= 0 ? filename.slice(dot) : '',
  };
}

export function getFileModified(
  project: number,
  level: number,
  folder: string,
  shortName: string,
  extension: string,
): number | null {
  try {
    const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension });
    const file = (mls.stor.files as Record<string, any>)[key];
    if (!file || file.status === 'deleted') return null;
    if (file.status === 'new' || file.status === 'changed') return Number.MAX_SAFE_INTEGER;
    if (file.updatedAt) return Date.parse(file.updatedAt);
    return null;
  } catch {
    return null;
  }
}

export function getFileModifiedByMlsPath(mlsPath: string): number | null {
  const parsed = parseMlsPath(mlsPath);
  if (!parsed) return null;
  return getFileModified(parsed.project, parsed.level, parsed.folder, parsed.shortName, parsed.extension);
}

export async function getContentByMlsPath(mlsPath: string): Promise<string | null> {
  try {
    const info = mls.stor.convertFileReferenceToFile(mlsPath);
    if (!info) return null;
    const key = mls.stor.getKeyToFile(info);
    const file = (mls.stor.files as Record<string, any>)[key];
    if (!file || file.status === 'deleted') return null;
    return String(await file.getContent());
  } catch {
    return null;
  }
}

export async function loadModuleByBuild(path: string): Promise<any> {
  try {
    const source = await getContentByMlsPath(path);
    if (!source) return null;
    const esbuild = await getEsbuild();
    const result = await esbuild.transform(source, { loader: 'ts', format: 'esm', target: 'esnext' });
    const blobUrl = URL.createObjectURL(new Blob([result.code], { type: 'text/javascript' }));
    try {
      return await import(blobUrl);
    } finally {
      URL.revokeObjectURL(blobUrl);
    }
  } catch {
    return null;
  }
}

interface BorrowedModel { project: number; shortName: string; folder: string; level: number; }

let activeCompiles = 0;
const pendingRelease: BorrowedModel[] = [];

/**
 * Release the Monaco models THIS step created, once no compile is in flight.
 *
 * Without any release the registry only grows — every materialized file leaves a model behind and Monaco
 * hits "potential listener LEAK detected, having 200 listeners already", after which the console is
 * useless for diagnosis. A module generates dozens of files (a page11 per workspace + contracts + tests).
 *
 * Safe because nothing in this agent needs a model to outlive its compile: `mls.editor.models` is read in
 * exactly two places, both inside getGeneratedModel and both "return it if it already exists" guards. The
 * materialization step is an independent process (it also runs from the CLI, `pnpm materializeL2`), so it
 * can never assume a warm registry — whoever needs a model loads it. `deleteModels` only disposes the
 * model and drops the registry entry; it never touches `mls.stor`, so the generated file stays intact.
 *
 * Deferred until `activeCompiles === 0` because the phase fans out in `parallel_dynamic`: file A can be
 * an import of B, and disposing A mid-compile of B yields a FALSE compile error that burns repair budget.
 */
function releaseBorrowedModels(borrowed: BorrowedModel[]): void {
  pendingRelease.push(...borrowed);
  if (activeCompiles > 0) return;
  for (const model of pendingRelease.splice(0, pendingRelease.length)) {
    // Signature is (project, shortName, folder, releaseMonacoModel, level) — the boolean comes BEFORE
    // the level. `true` disposes the underlying monaco model, which is what holds the listeners.
    try { mls.editor.deleteModels(model.project, model.shortName, model.folder, true, model.level); } catch { /* best effort */ }
  }
}

export async function saveGeneratedTs(
  project: number,
  level: number,
  folder: string,
  shortName: string,
  content: string,
  extension = '.ts',
): Promise<boolean> {
  // OWNERSHIP, decided BEFORE anything below can create a model: createStorFile(needCreateModel=true) and
  // getGeneratedModel's getOrCreateModel both create one, so checking afterwards would always say "not
  // ours" and nothing would ever be released. A model already in the registry belongs to the Studio (the
  // file is open in a tab) and must never be disposed.
  const ownsModel = !mls.editor.models[mls.editor.getKeyModel(project, shortName, folder, level)];
  activeCompiles++;
  try {
    const fileInfo = { project, level, folder, shortName, extension };
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = (mls.stor.files as Record<string, any>)[key];
    if (!file) {
      file = await createStorFile({ ...fileInfo, source: content }, true, false, false);
    }
    if (file.status !== 'renamed' && file.status !== 'new') file.status = 'changed';
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
    const model = await getGeneratedModel(project, level, folder, shortName, extension);
    if (model?.model && model.model.getValue?.() !== content) model.model.setValue(content);
    await compileGeneratedTs(project, level, folder, shortName, extension);
    return true;
  } catch (error) {
    recordStudioMessage('error', 'saveGeneratedTs failed', error);
    return false;
  } finally {
    // The content is durable in stor; the model was only a working copy for the compile. Queue it even on
    // failure — a thrown compile leaks exactly the same listeners.
    activeCompiles--;
    if (ownsModel) releaseBorrowedModels([{ project, shortName, folder, level }]);
  }
}

export async function saveGeneratedTsByMlsPath(mlsPath: string, content: string): Promise<boolean> {
  const parsed = parseMlsPath(mlsPath);
  if (!parsed || !isGeneratedTsExtension(parsed.extension)) return false;
  return saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, content, parsed.extension);
}

// Plain text artifact writer (no editor model, no compile) — used to persist the shared compiled
// .d.ts to trace/frontend-shared-dts so the CLI runtime can read the same context from disk.
export async function saveArtifactTextByMlsPath(mlsPath: string, content: string): Promise<boolean> {
  try {
    const parsed = parseMlsPath(mlsPath);
    if (!parsed) return false;
    const fileInfo = { project: parsed.project, level: parsed.level, folder: parsed.folder, shortName: parsed.shortName, extension: parsed.extension };
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = (mls.stor.files as Record<string, any>)[key];
    if (!file) {
      // needCreateModel=FALSE: this writer never compiles and nothing reads a model for a trace artifact,
      // so creating one only leaked listeners (it contradicted this function's own contract above).
      file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
    }
    if (file.status !== 'renamed' && file.status !== 'new') file.status = 'changed';
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
    return true;
  } catch (error) {
    recordStudioMessage('error', 'saveArtifactTextByMlsPath failed', error);
    return false;
  }
}

export async function compileAndGetErrors(
  project: number,
  level: number,
  folder: string,
  shortName: string,
  extension = '.ts',
): Promise<string[]> {
  try {
    const modelTs = await getGeneratedModel(project, level, folder, shortName, extension);
    if (!modelTs?.model) return [];
    if (modelTs.compilerResults) modelTs.compilerResults.modelNeedCompile = true;
    await mls.l2.typescript.compile(modelTs);
    const errors: unknown[] = modelTs.compilerResults?.errors ?? [];
    return errors.map(formatCompilerDiagnostic);
  } catch (error) {
    recordStudioMessage('error', 'compileAndGetErrors failed', error);
    return [`compileAndGetErrors failed: ${formatUnknownError(error)}`];
  }
}

export async function compileMlsPathAndGetErrors(mlsPath: string): Promise<string[]> {
  const parsed = parseMlsPath(mlsPath);
  if (!parsed || !isGeneratedTsExtension(parsed.extension)) return [];
  return compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName, parsed.extension);
}

// Compiled .d.ts (prodDTS) of a runtime .ts model, compiling on demand when the model has not been
// compiled yet in this session. Used to give the page-materialization LLM the EXACT public surface
// of its base class (typed msg keys, @property names, handlers) instead of only the raw source.
export async function getCompiledDtsByMlsPath(mlsPath: string): Promise<string | null> {
  try {
    const parsed = parseMlsPath(mlsPath);
    if (!parsed || parsed.extension !== '.ts') return null;
    const modelTs = await getGeneratedModel(parsed.project, parsed.level, parsed.folder, parsed.shortName, parsed.extension);
    if (!modelTs?.model) return null;
    if (!modelTs.compilerResults?.prodDTS) {
      if (modelTs.compilerResults) modelTs.compilerResults.modelNeedCompile = true;
      await mls.l2.typescript.compile(modelTs);
    }
    const dts = modelTs.compilerResults?.prodDTS;
    return typeof dts === 'string' && dts.trim() ? dts : null;
  } catch (error) {
    recordStudioMessage('error', 'getCompiledDtsByMlsPath failed', error);
    return null;
  }
}

export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null {
  const value = parseMaybeJson(raw);
  if (!isRecord(value)) return null;

  if (value.toolName === toolName) {
    const args = parseMaybeJson(value.arguments);
    return isRecord(args) ? args as T : null;
  }

  if (value.type === 'flexible' && value.result !== undefined) {
    const result = parseMaybeJson(value.result);
    if (isRecord(result) && result.toolName === toolName) {
      const args = parseMaybeJson(result.arguments);
      return isRecord(args) ? args as T : null;
    }
  }

  if (Array.isArray(value.tool_calls)) {
    const call = value.tool_calls.find(item => isRecord(item) && isRecord(item.function) && item.function.name === toolName);
    if (isRecord(call) && isRecord(call.function)) {
      const args = parseMaybeJson(call.function.arguments);
      return isRecord(args) ? args as T : null;
    }
  }

  return null;
}

async function getEsbuild(): Promise<any> {
  const w = window as any;
  const url = 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esm/browser.js';
  if (!w.__cfeEsbuildInstance) w.__cfeEsbuildInstance = import(url);
  const esbuild = await w.__cfeEsbuildInstance;
  if (!w.__cfeEsbuildReady) {
    w.__cfeEsbuildReady = esbuild.initialize({
      wasmURL: 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esbuild.wasm',
    });
  }
  await w.__cfeEsbuildReady;
  return esbuild;
}

async function compileGeneratedTs(project: number, level: number, folder: string, shortName: string, extension: string): Promise<void> {
  try {
    const modelTs = await getGeneratedModel(project, level, folder, shortName, extension);
    if (!modelTs) return;
    if (modelTs.compilerResults) modelTs.compilerResults.modelNeedCompile = true;
    await mls.l2.typescript.compileAndPostProcess(modelTs, extension === '.ts', true);
    mls.editor.forceModelUpdate(modelTs.model);
  } catch (error) {
    recordStudioMessage('warn', 'compileGeneratedTs failed', error);
  }
}

function recordStudioMessage(level: 'warn' | 'error', message: string, error?: unknown): void {
  const detail = error === undefined ? message : `${message}: ${formatUnknownError(error)}`;
  studioMessages.push({ level, message: detail });
  const line = `[cfeMaterializeStudio] ${detail}`;
  if (level === 'error') console.error(line);
  else console.warn(line);
}

function formatCompilerDiagnostic(error: unknown): string {
  if (typeof error === 'string') return error;
  if (!isRecord(error)) return formatUnknownError(error);

  const code = typeof error.code === 'number' ? `TS${error.code}` : '';
  const file = isRecord(error.file) && typeof error.file.fileName === 'string' ? error.file.fileName : '';
  const position = diagnosticPosition(error);
  const message = flattenMessageText(error.messageText ?? error.message ?? error);
  return [file ? `${file}${position}` : '', code, message].filter(Boolean).join(' - ');
}

function diagnosticPosition(error: Record<string, any>): string {
  const file = error.file;
  if (!isRecord(file) || typeof error.start !== 'number' || typeof file.getLineAndCharacterOfPosition !== 'function') return '';
  try {
    const pos = file.getLineAndCharacterOfPosition(error.start);
    if (!pos || typeof pos.line !== 'number' || typeof pos.character !== 'number') return '';
    return `:${pos.line + 1}:${pos.character + 1}`;
  } catch {
    return '';
  }
}

function flattenMessageText(value: unknown): string {
  if (typeof value === 'string') return value;
  if (isRecord(value)) {
    const head = flattenMessageText(value.messageText ?? '');
    const next = Array.isArray(value.next) ? value.next.map(flattenMessageText).filter(Boolean) : [];
    return [head, ...next].filter(Boolean).join(' ');
  }
  return formatUnknownError(value);
}

function formatUnknownError(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'string') return error;
  try { return JSON.stringify(error); } catch { return String(error); }
}

async function getGeneratedModel(
  project: number,
  level: number,
  folder: string,
  shortName: string,
  extension: string,
): Promise<any | null> {
  const editorKey = mls.editor.getKeyModel(project, shortName, folder, level);
  const slot = getModelSlot(extension);
  let modelBase = mls.editor.models[editorKey];
  if (modelBase?.[slot]?.model) return modelBase[slot];

  const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension });
  const file = (mls.stor.files as Record<string, any>)[key];
  if (!file || file.status === 'deleted') return null;

  const model = await file.getOrCreateModel?.();
  modelBase = mls.editor.models[editorKey];
  return modelBase?.[slot] ?? model ?? null;
}

function isGeneratedTsExtension(extension: string): boolean {
  return extension === '.ts' || extension === '.test.ts';
}

function getModelSlot(extension: string): 'ts' | 'test' {
  return extension === '.test.ts' ? 'test' : 'ts';
}

function parseMaybeJson(raw: unknown): unknown {
  if (typeof raw !== 'string') return raw;
  try { return JSON.parse(raw); } catch { return null; }
}

function isRecord(value: unknown): value is Record<string, any> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
