/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeL4Contract.test.ts" enhancement="_blank"/>
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  frontendOutputShapeForOperation,
  frontendQueryStateDefaults,
  frontendInputPresentation,
  queryQualifiesForInitialLoad,
  isRuntimeResolvedInputSource,
  isUserFacingOperationInput,
  l4OperationInputs,
  hasWorkspaceBffCalls,
  parseWorkspaceBffCalls,
  parseWorkspaceSections,
  bffCallCommandShape,
  isContentOrganismRole,
  buildWorkspaceContractSource,
  isCopiedL4Contract,
  type CfeL4OperationInput,
} from '/_102020_/l2/agentChangeFrontend/helpers/cfeL4Contract.js';
import {
  buildMaterializeTypecheckTest,
  collectDesignTokenRoleIssues,
  collectHeadingDisciplineIssues,
  collectMutationFeedbackIssues,
  collectPageExperienceIssues,
  collectTechnicalVocabularyIssues,
  isL4LookupGap,
  normalizeGeneratedCode,
} from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeCore.js';

test('frontendOutputShapeForOperation follows L4 accessPattern pagination', () => {
  assert.equal(frontendOutputShapeForOperation({ kind: 'query', accessPattern: { kind: 'list', pagination: 'required' } }), 'paginated');
  assert.equal(frontendOutputShapeForOperation({ kind: 'query', accessPattern: { kind: 'list', pagination: 'none' } }), 'array');
  assert.equal(frontendOutputShapeForOperation({ kind: 'view', accessPattern: { kind: 'getById' } }), 'object');
  assert.equal(frontendOutputShapeForOperation({ kind: 'create', accessPattern: { kind: 'commandInput' } }), 'object');
});

test('frontendQueryStateDefaults preserves paginated object shape', () => {
  assert.deepEqual(frontendQueryStateDefaults('array'), { collection: true, defaultValue: [] });
  assert.deepEqual(frontendQueryStateDefaults('paginated'), { collection: false, defaultValue: { items: [], total: 0 } });
  assert.deepEqual(frontendQueryStateDefaults('object'), { collection: false, defaultValue: null });
});

test('L4 inputs retain every browser boundary input and classify contextual inputs', () => {
  const inputs = l4OperationInputs({
    inputs: [
      { inputId: 'nameFilter', fieldRef: 'Company.name', required: false, source: 'userInput', description: 'Filter by name.' },
      { inputId: 'companyId', fieldRef: 'Company.companyId', required: true, source: 'businessContext', description: 'Active company.' },
      { inputId: 'workspaceId', fieldRef: 'Workspace.workspaceId', required: true, source: 'currentWorkspace', description: 'Current UI workspace.' },
      { inputId: 'statusReportId', fieldRef: 'StatusReport.statusReportId', required: true, source: 'routeParam', description: 'Share link route parameter.' },
      { inputId: 'selectedId', fieldRef: 'StatusReport.statusReportId', required: true, source: 'selectedEntity', description: 'Selected report.' },
    ],
  });

  assert.deepEqual(inputs.filter(isUserFacingOperationInput).map(input => input.inputId), ['nameFilter', 'statusReportId', 'selectedId']);
  assert.equal(frontendInputPresentation(inputs[0]), 'form');
  assert.equal(frontendInputPresentation(inputs[3]), 'route');
  assert.equal(frontendInputPresentation(inputs[4]), 'selection');
  assert.equal(isRuntimeResolvedInputSource('businessContext'), true);
  assert.equal(isRuntimeResolvedInputSource('currentWorkspace'), true);
  assert.equal(isRuntimeResolvedInputSource('userInput'), false);
  assert.equal(isRuntimeResolvedInputSource('routeParam'), false);
  assert.equal(isRuntimeResolvedInputSource('selectedEntity'), false);
});

test('queryQualifiesForInitialLoad: route-only required is boot-safe; user/selection required is not', () => {
  assert.equal(queryQualifiesForInitialLoad([]), true);
  assert.equal(queryQualifiesForInitialLoad([{ required: false, presentation: 'form' }]), true);
  assert.equal(queryQualifiesForInitialLoad([{ required: true, presentation: 'route' }]), true);
  assert.equal(queryQualifiesForInitialLoad([
    { required: true, presentation: 'route' },
    { required: false, presentation: 'form' },
  ]), true);
  assert.equal(queryQualifiesForInitialLoad([{ required: true, presentation: 'form' }]), false);
  assert.equal(queryQualifiesForInitialLoad([{ required: true, presentation: 'selection' }]), false);
});

test('generated contract typecheck expects paginated query output when outputShape is paginated', () => {
  const source = buildMaterializeTypecheckTest({
    id: 'orders__l2_contract',
    type: 'l2_contract',
    outputPath: '_102050_/l2/cafeFlow/web/contracts/orders.ts',
  }, [{
    commandName: 'listOrders',
    kind: 'query',
    outputShape: 'paginated',
    input: [{ name: 'nameFilter', type: 'string', required: false }],
    output: [{ name: 'orderId', type: 'string', required: true }],
  }]);

  assert.match(source || '', /type ExpectedListOrdersOutput = \{ items: ExpectedListOrdersOutputItem\[\]; total: number; page\?: number; pageSize\?: number; \};/);
});

// Generated tests must import through the project alias (/_<project>_/...), never a relative path —
// a relative import (`./x.js`, `../contracts/x.js`) does not resolve and fails compilation (102051 run18).
test('generated typecheck tests import via the project alias, not relative paths', () => {
  const contract = buildMaterializeTypecheckTest({
    id: 'menuManagement__l2_contract', type: 'l2_contract', outputPath: '_102051_/l2/cafeFlow/web/contracts/menuManagement.ts',
  }, [{ commandName: 'listMenuItems', kind: 'query', input: [{ name: 'status' }], output: [{ name: 'name' }] }]) || '';
  const shared = buildMaterializeTypecheckTest({
    id: 'menuManagement__l2_shared', type: 'l2_shared', outputPath: '_102051_/l2/cafeFlow/web/shared/menuManagement.ts',
  }, { moduleName: 'cafeFlow', pageId: 'menuManagement', contractRef: { tsPath: '_102051_/l2/cafeFlow/web/contracts/menuManagement.ts' },
    states: [{ name: 'listMenuItemsData', stateKey: 'ui.menuManagement.data.listMenuItems', kind: 'queryResult', contractRef: { commandName: 'listMenuItems', direction: 'output' } }], actions: [] }) || '';
  for (const src of [contract, shared]) {
    for (const line of src.split('\n').filter(l => l.startsWith('import'))) {
      assert.doesNotMatch(line, /from '\.\.?\//, `relative import in generated test: ${line}`);
      assert.match(line, /from '\/_\d+_\/l2\//, `import must use project alias: ${line}`);
    }
  }
  assert.match(shared, /from '\/_102051_\/l2\/cafeFlow\/web\/shared\/menuManagement\.js'/);
});

test('shared enum input assertion includes the empty sentinel the property is initialized with', () => {
  const shared = buildMaterializeTypecheckTest({
    id: 'taskCatalogue__l2_shared', type: 'l2_shared', outputPath: '_102047_/l2/todo/web/shared/taskCatalogue.ts',
  }, {
    moduleName: 'todo',
    pageId: 'taskCatalogue',
    contractRef: { tsPath: '_102047_/l2/todo/web/contracts/taskCatalogue.ts' },
    states: [{
      name: 'cmdDecideNextTaskStatusStatus',
      kind: 'input',
      defaultValue: '',
      valueSet: ['pending', 'inProgress', 'completed', 'cancelled'],
      contractRef: { commandName: 'cmdDecideNextTaskStatus', direction: 'input', field: 'status' },
    }],
    actions: [],
  }) || '';
  assert.match(shared, /Assignable<typeof page\.cmdDecideNextTaskStatusStatus, "pending" \| "inProgress" \| "completed" \| "cancelled" \| CmdDecideNextTaskStatusInput\["status"\] \| ''>/);
  assert.doesNotMatch(shared, /Assignable<typeof page\.cmdDecideNextTaskStatusStatus, string>/);
});

// ---- L4 v2: workspace bffCalls -> page commands ----

// Trimmed fixture mirroring l4/petShop/workspaces/catalog.defs.ts (a query surface + a detailPanel query).
const CATALOG_WORKSPACE = {
  workspaceId: 'catalog',
  title: 'Catálogo de produtos',
  actors: ['cliente'],
  kind: 'operation',
  bffCalls: [
    {
      bffId: 'catalogList',
      kind: 'query',
      uses: [{ operationId: 'browseCatalog' }],
      input: [
        { name: 'searchTerm', from: 'browseCatalog.searchTerm' },
        { name: 'page', from: 'browseCatalog.page' },
      ],
      output: { kind: 'paginated', fields: [{ name: 'productId', from: 'browseCatalog.$items.productId' }, { name: 'name', from: 'browseCatalog.$items.name' }] },
      route: 'petShop.catalog.catalogList',
    },
    {
      bffId: 'productDetail',
      kind: 'query',
      uses: [{ operationId: 'viewProductDetail' }],
      input: [{ name: 'productId', from: 'viewProductDetail.productId' }],
      output: { kind: 'object', fields: [{ name: 'productId', from: 'viewProductDetail.productId' }] },
      route: 'petShop.catalog.productDetail',
    },
  ],
  sections: [
    {
      sectionId: 'catalog',
      intent: 'Navegar, buscar e filtrar o catálogo',
      organisms: [
        { role: 'primarySurface', dataSource: 'catalogList' },
        { role: 'filterControl', attachTo: 'catalogList' },
        { role: 'detailPanel', dataSource: 'productDetail' },
      ],
    },
  ],
};

test('hasWorkspaceBffCalls distinguishes l4 v2 workspaces from the legacy operationIds-only shape', () => {
  assert.equal(hasWorkspaceBffCalls(CATALOG_WORKSPACE), true);
  assert.equal(hasWorkspaceBffCalls({ workspaceId: 'legacy', operationIds: ['browseCatalog'] }), false);
  assert.equal(hasWorkspaceBffCalls({ bffCalls: [] }), false);
});

test('parseWorkspaceBffCalls reads bffId/kind/route/uses/input/output projection', () => {
  const calls = parseWorkspaceBffCalls(CATALOG_WORKSPACE);
  assert.equal(calls.length, 2);
  assert.equal(calls[0].bffId, 'catalogList');
  assert.equal(calls[0].kind, 'query');
  assert.equal(calls[0].route, 'petShop.catalog.catalogList');
  assert.deepEqual(calls[0].uses, ['browseCatalog']);
  assert.equal(calls[0].output?.kind, 'paginated');
  assert.deepEqual(calls[0].output?.fields.map(f => f.name), ['productId', 'name']);
  assert.equal(calls[1].output?.kind, 'object');
});

test('parseWorkspaceSections keeps organism roles and their bffId references', () => {
  const sections = parseWorkspaceSections(CATALOG_WORKSPACE);
  assert.equal(sections.length, 1);
  assert.deepEqual(sections[0].organisms.map(o => o.role), ['primarySurface', 'filterControl', 'detailPanel']);
  assert.equal(sections[0].organisms[0].dataSource, 'catalogList');
  assert.equal(sections[0].organisms[1].attachTo, 'catalogList');
  assert.equal(sections[0].organisms[2].dataSource, 'productDetail');
});

test('parseWorkspaceSections keeps usage summary on a collection-indicator organism', () => {
  const sections = parseWorkspaceSections({
    sections: [{
      sectionId: 'inspectTaskSummary',
      intent: 'Totais visíveis.',
      organisms: [{ role: 'primarySurface', dataSource: 'qryInspectTaskSummary', usage: 'summary' }],
    }],
  });
  assert.equal(sections[0].organisms[0].usage, 'summary');
  assert.equal(sections[0].organisms[0].dataSource, 'qryInspectTaskSummary');
  assert.equal(isContentOrganismRole('showcase'), true);
  assert.equal(isContentOrganismRole('primarySurface'), false);
});

test('bffCallCommandShape maps a query bffCall to a paginated command, resolving required from the operation', () => {
  const operationInputs = new Map<string, CfeL4OperationInput[]>([
    ['browseCatalog', [
      { inputId: 'searchTerm', fieldRef: 'Product.name', required: false, source: 'userInput', description: '' },
      { inputId: 'page', fieldRef: '', required: false, source: 'userInput', description: '' },
    ]],
  ]);
  const [catalogList] = parseWorkspaceBffCalls(CATALOG_WORKSPACE);
  const command = bffCallCommandShape(catalogList, operationInputs);
  assert.equal(command.commandName, 'catalogList');
  assert.equal(command.kind, 'query');
  assert.equal(command.routeKey, 'petShop.catalog.catalogList');
  assert.equal(command.outputShape, 'paginated');
  assert.deepEqual(command.input.map(i => i.name), ['searchTerm', 'page']);
  assert.equal(command.input[0].required, false);
  assert.equal(command.input[0].presentation, 'form');
  assert.deepEqual(command.output.map(o => o.name), ['productId', 'name']);
  assert.equal(command.canonicalOutputShape?.kind, 'paginated');
});

test('buildWorkspaceContractSource generates ONE file per workspace: all bffCall interfaces + route consts (no l4 .ts read)', () => {
  const source = buildWorkspaceContractSource({
    l2Ref: '_102049_/l2/petShop/web/contracts/catalog.ts',
    workspaceId: 'catalog',
    calls: [
      { interfaceName: 'CatalogList', bffId: 'catalogList', kind: 'query', outputKind: 'paginated', route: 'petShop.catalog.catalogList',
        input: [{ name: 'searchTerm', type: 'string', optional: true }], output: [{ name: 'productId', type: 'string' }, { name: 'name', type: 'string' }] },
      { interfaceName: 'ProductDetail', bffId: 'productDetail', kind: 'query', outputKind: 'object', route: 'petShop.catalog.productDetail',
        input: [{ name: 'productId', type: 'string' }], output: [{ name: 'productId', type: 'string' }, { name: 'description', type: 'string' }] },
    ],
  });
  assert.match(source, /<mls fileReference="_102049_\/l2\/petShop\/web\/contracts\/catalog\.ts"/);
  assert.doesNotMatch(source, /l4\/petShop\/contracts/); // NEVER references an l4 .ts
  // Both bffCalls' interfaces + route consts live in the single file.
  assert.match(source, /export interface CatalogListInput \{\n {2}searchTerm\?: string;\n\}/);
  assert.match(source, /export interface CatalogListOutput \{/);
  assert.match(source, /export const catalogListRoute = 'petShop\.catalog\.catalogList' as const;/);
  assert.match(source, /export interface ProductDetailInput \{/);
  assert.match(source, /export const productDetailRoute = 'petShop\.catalog\.productDetail' as const;/);
  assert.equal(isCopiedL4Contract(source), true);
  assert.equal(isCopiedL4Contract('export const x = 1;'), false);
});

test('buildWorkspaceContractSource emits empty interfaces for a command with no projected fields', () => {
  const source = buildWorkspaceContractSource({
    l2Ref: '_1_/l2/m/web/contracts/w.ts', workspaceId: 'w',
    calls: [{ interfaceName: 'Act', bffId: 'act', kind: 'command', outputKind: 'object', route: 'm.w.act', input: [], output: [] }],
  });
  assert.match(source, /export interface ActInput \{\}/);
  assert.match(source, /export interface ActOutput \{\}/);
});

test('materialization fixes deterministic page seams without changing generated render logic', () => {
  const page = normalizeGeneratedCode({ id: 'report__l2_page', type: 'l2_page', outputPath: '_102048_/l2/buildFlowFsm/web/desktop/page11/report.ts' }, { baseClassName: 'BuildFlowFsmReportBase' }, "import { WrongBase } from '/_102048_/l2/buildFlowFsm/web/shared/report.ts';\nexport class ReportPage extends WrongBase {}");
  assert.match(page, /import \{ BuildFlowFsmReportBase \} from '\/_102048_\/l2\/buildFlowFsm\/web\/shared\/report\.js';/);

  const shared = normalizeGeneratedCode({ id: 'report__l2_shared', type: 'l2_shared', outputPath: '_102048_/l2/buildFlowFsm/web/shared/report.ts' }, { baseClassName: 'BuildFlowFsmReportBase' }, 'export class WrongBase extends CollabLitElement {}');
  assert.match(shared, /export class BuildFlowFsmReportBase extends CollabLitElement/);
});

// ---- design tokens used against their role ----
// mls-102045 shipped `bg-[var(--bg-secondary-color,#334155)] text-[var(--bg-primary-color,#ffffff)]`:
// a BACKGROUND token as the label color. Readable only while the hardcoded fallback applies; with the
// theme on (both tokens dark) the label disappears. No prior check saw it — the token name was real.
test('design token role guard flags a -bg token used as text (and a -text token as background)', () => {
  const bgAsText = collectDesignTokenRoleIssues('html`<button class="bg-[var(--button-secondary-bg,#334155)] text-[var(--button-primary-bg,#ffffff)]">x</button>`');
  assert.equal(bgAsText.length, 1);
  assert.match(bgAsText[0], /BACKGROUND token in a text utility/);
  assert.match(bgAsText[0], /button-primary-text/, 'names the correct token of the same role');

  const textAsBg = collectDesignTokenRoleIssues('html`<div class="bg-[var(--status-error-text,#fff)]">x</div>`');
  assert.equal(textAsBg.length, 1);
  assert.match(textAsBg[0], /TEXT token in a background utility/);
  assert.match(textAsBg[0], /status-error-bg/);
});

test('design token role guard accepts correct pairing and ignores the legacy flat vocabulary', () => {
  // Correct: same role, bg on background, text on label — including state prefixes and variants.
  assert.deepEqual(collectDesignTokenRoleIssues(
    'html`<button class="bg-[var(--button-primary-bg,#1d4ed8)] hover:bg-[var(--button-primary-bg-hover,#1e40af)] text-[var(--button-primary-text,#ffffff)] border-[var(--surface-bg,#eee)]">x</button>`',
  ), []);
  // Legacy flat names (bg-primary-color / text-primary-color) carry no role suffix — nothing to enforce,
  // so a project still on the old design system is never flagged.
  assert.deepEqual(collectDesignTokenRoleIssues('html`<button class="bg-[var(--bg-secondary-color,#334155)] text-[var(--bg-primary-color,#ffffff)]">x</button>`'), []);
  // No colors at all / no tokens.
  assert.deepEqual(collectDesignTokenRoleIssues('html`<div class="px-3 py-1.5 rounded-md">x</div>`'), []);
  assert.deepEqual(collectDesignTokenRoleIssues(''), []);
});

test('design token role guard reports each distinct misuse once', () => {
  const code = 'html`<i class="text-[var(--nav-bg)]"></i><i class="text-[var(--nav-bg)]"></i><i class="placeholder-[var(--surface-bg)]"></i>`';
  const issues = collectDesignTokenRoleIssues(code);
  assert.equal(issues.length, 2, 'the repeated one is deduped, the second kind is kept');
});

// ---- item B: os 4 defeitos transversais, checados sobre o .ts gerado ----
// Com o defs reduzido a verdade mora no OUTPUT: os checks leem o codigo, ancorados em dataBindings.
const PAGE_DEFS = {
  pageId: 'orders',
  dataBindings: [
    { id: 'b1', command: 'listOrders', kind: 'query', inputs: [
      { name: 'page', stateKey: 'ui.orders.input.listOrders.page', source: 'userInput', required: false },
      { name: 'status', stateKey: 'ui.orders.input.listOrders.status', source: 'userInput', required: false },
    ] },
    { id: 'b2', command: 'updateOrderCmd', kind: 'command', inputs: [
      { name: 'orderId', stateKey: 'ui.orders.input.updateOrderCmd.orderId', source: 'selectedEntity', required: true },
      { name: 'notes', stateKey: 'ui.orders.input.updateOrderCmd.notes', source: 'userInput', required: true },
    ] },
  ],
};
const SHARED_DEFS = { states: [
  { stateKey: 'ui.orders.input.listOrders.page', name: 'listOrdersPage' },
  { stateKey: 'ui.orders.input.listOrders.status', name: 'listOrdersStatus' },
  { stateKey: 'ui.orders.input.updateOrderCmd.orderId', name: 'updateOrderCmdOrderId' },
  { stateKey: 'ui.orders.input.updateOrderCmd.notes', name: 'updateOrderCmdNotes' },
] };

test('B2/B3: pagination and non-user-decided ids must not be editable controls', () => {
  const bad = collectPageExperienceIssues(PAGE_DEFS, SHARED_DEFS, `html\`
    <input .value=\${this.listOrdersPage}>
    <input .value=\${this.updateOrderCmdOrderId}>
  \``);
  assert.equal(bad.length, 2);
  assert.match(bad[0], /collection wiring/);
  assert.match(bad[1], /technical id with source 'selectedentity'/);
  // Without a sourceRef there is no query on the page to pick FROM, so the message says exactly that
  // and the issue is tagged as an l4 gap: no rewrite of this .ts can produce the picker, and the
  // materialization phase reports it as a warning instead of looping the repair rounds on it.
  assert.match(bad[1], /NO query that could populate a picker/);
  assert.equal(isL4LookupGap(bad[1]), true);
  assert.equal(isL4LookupGap(bad[0]), false);

  // WITH a sourceRef the page DOES have the query: the remedy names it and the issue stays a
  // repairable error — the downgrade must never swallow a defect the rewrite can fix.
  const pageWithQuery = {
    ...PAGE_DEFS,
    dataBindings: PAGE_DEFS.dataBindings.map(binding => ({
      ...binding,
      inputs: binding.inputs.map(input => input.name === 'orderId' ? { ...input, sourceRef: 'listOrders' } : input),
    })),
  };
  const withQuery = collectPageExperienceIssues(pageWithQuery, SHARED_DEFS, `html\`<input .value=\${this.updateOrderCmdOrderId}>\``);
  assert.equal(withQuery.length, 1);
  assert.match(withQuery[0], /render a picker over the 'listOrders' query already on this page/);
  assert.equal(isL4LookupGap(withQuery[0]), false);

  // Correct: the user-decided fields ARE editable; the id comes from selection; no pager input.
  assert.deepEqual(collectPageExperienceIssues(PAGE_DEFS, SHARED_DEFS, `html\`
    <select .value=\${this.listOrdersStatus}></select>
    <textarea .value=\${this.updateOrderCmdNotes}></textarea>
    <button @click=\${() => this.handleSelectOrder(row)}>\${row.code}</button>
  \``), []);
});

test('mutation feedback: both paths, judged on presence not on the i18n key', () => {
  const missing = collectMutationFeedbackIssues(PAGE_DEFS, SHARED_DEFS, 'html`<button @click=${this.updateOrderCmd}>Save</button>`');
  assert.equal(missing.length, 1);
  assert.match(missing[0], /renders no success\/error feedback/);
  // The literal action.<cmd>.success/error key is accepted as evidence...
  assert.deepEqual(collectMutationFeedbackIssues(PAGE_DEFS, SHARED_DEFS,
    "html`<div>${this.msg['action.updateOrderCmd.success']}</div><div>${this.msg['action.updateOrderCmd.error']}</div>`"), []);
  // ...and so is any local success/error rendering (the reduced defs carries no i18n contract).
  assert.deepEqual(collectMutationFeedbackIssues(PAGE_DEFS, SHARED_DEFS,
    "html`<span>${this.updateOrderCmdState === 'success' ? 'Salvo' : ''}</span><span>${this.updateOrderCmdState === 'error' ? 'Falhou' : ''}</span>`"), []);
  // Queries are not mutations.
  assert.deepEqual(collectMutationFeedbackIssues({ pageId: 'orders', dataBindings: [PAGE_DEFS.dataBindings[0]] }, SHARED_DEFS, 'html`<table></table>`'), []);
});

test('B1: internal vocabulary never becomes screen text', () => {
  const bad = collectTechnicalVocabularyIssues(PAGE_DEFS, 'html`<h2>Summary first</h2><span>List orders</span>`');
  assert.equal(bad.length, 2, 'the displayHint AND the bffCall id humanized as copy');
  assert.match(bad[0], /Summary first/);
  assert.deepEqual(collectTechnicalVocabularyIssues(PAGE_DEFS, 'html`<h2>Pedidos do turno</h2><span>Ver detalhes</span>`'), []);
});

test('B4: a heading that repeats the adjacent control label fails', () => {
  const bad = collectHeadingDisciplineIssues('html`<h3>Aprovar</h3><button>Aprovar</button>`');
  assert.equal(bad.length, 1);
  assert.match(bad[0], /repeats the label of the adjacent control/);
  assert.deepEqual(collectHeadingDisciplineIssues('html`<h3>Ordens pendentes</h3><button>Aprovar</button>`'), []);
});
