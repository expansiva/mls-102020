/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeSharedScaffold.ts" enhancement="_blank"/>

// Deterministic scaffold generator for l2_shared materialization items.
//
// The shared base class is a mechanical projection of the .defs.ts (states, actions, i18n,
// route params) plus the workspace contract (.ts under web/contracts). This module renders it
// WITHOUT an LLM call: output size stops being bounded by model max_tokens (run03: projectDetail
// 157KB defs -> ~55k output tokens exceeded every provider ceiling) and reruns become exact.
//
// Policy: PURE module (no fs, no mls.*, no DOM) so the Node CLI runner and the Studio agent share
// one implementation. When the defs uses a shape this generator does not model, it returns
// { code: null, reason } and the caller falls back to the LLM path — never guess here.
// The canonical output style mirrors the mls-102045 golden files (clientManagement/clientPortal);
// the arbiter of correctness is strict tsc + the generated typecheck .test.ts, not byte equality.

export interface SharedScaffoldResult {
  code: string | null;
  reason?: string;
}

interface ContractField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'stringUnion';
  optional: boolean;
  /** first literal of a string-union type — the zero value for generated defaults */
  firstLiteral?: string;
}

interface ContractInterface {
  name: string;
  fields: ContractField[];
}

interface DefsState {
  stateKey: string;
  name: string;
  kind: 'pageStatus' | 'actionStatus' | 'input' | 'queryResult' | 'commandOutput' | 'actionError';
  defaultValue: unknown;
  actionRef?: string;
  valueSet?: string[];
  contractRef?: { commandName: string; direction: 'input' | 'output'; field?: string };
  outputShape?: 'paginated' | 'object' | 'array';
  collection?: boolean;
}

interface DefsPrefillField { itemField: string; targetStateKey: string }

interface DefsPrefill {
  command: string;
  sourceStateKey: string;
  sourceOutputShape: 'array' | 'object';
  matchField: string;
  fields: DefsPrefillField[];
}

interface DefsAction {
  actionId: string;
  kind: 'query' | 'command' | 'stateSetter';
  methodName: string;
  handlerName: string;
  commandRef?: string;
  routeKey?: string;
  inputStateKeys?: string[];
  routeParamInputStateKeys?: string[];
  selectedEntityInputStateKeys?: string[];
  outputStateKeys?: string[];
  statusStateKey?: string;
  errorStateKey?: string;
  feedback?: { successMessageKey?: string; errorMessageKey?: string };
  clearInputStateKeys?: string[];
  refreshActionIds?: string[];
  stateKey?: string;
  prefill?: DefsPrefill;
}

interface ScaffoldModel {
  outputPath: string;
  baseClassName: string;
  routePattern: string;
  states: DefsState[];
  actions: DefsAction[];
  initialLoads: { actionId: string }[];
  i18n: Record<string, string>;
  // The module's default locale (defs i18nMeta.defaultLocale). The catalog is keyed by its LOWERCASE
  // form because the runtime always sets document.documentElement.lang from the normalized config list
  // (102033 listRuntimeLanguages -> lowercase) and the base class looks up messages[lang.toLowerCase()].
  defaultLocale: string;
  // Every locale the module declares (defs i18nMeta.runtimeLocales, region preserved and lowercased).
  // The catalog emits ALL of them, not just the default: a page references sharedMessages['pt-br'], so a
  // shared regenerated with one locale would silently resolve every page label back to English.
  runtimeLocales: string[];
  // Text already translated in the .ts being overwritten, per locale. Regenerating the shared used to
  // drop every added language and depend on @@addLanguage retranslating the whole module (i18n.md item 4:
  // "churn"), which also lost any translation fixed by hand. Carried over by key.
  previousText: Map<string, Record<string, string>>;
  contractTsPath: string;
  contracts: { commandName: string; routeConst: string }[];
  interfaces: Map<string, ContractInterface>;
  stateByKey: Map<string, DefsState>;
  actionById: Map<string, DefsAction>;
}

class ScaffoldBail extends Error {}

function bail(reason: string): never {
  throw new ScaffoldBail(reason);
}

/**
 * @param previousSource content of the .ts being overwritten, when it exists. Only its i18n block is
 *        read, to carry translations forward (see ScaffoldModel.previousText).
 */
export function generateSharedScaffold(outputPath: string, data: unknown, contractSource: string, previousSource?: string): SharedScaffoldResult {
  try {
    const model = buildModel(outputPath, data, contractSource, previousSource);
    return { code: render(model) };
  } catch (error) {
    if (error instanceof ScaffoldBail) return { code: null, reason: error.message };
    throw error;
  }
}

/**
 * Read `const message_<locale> = { 'key': 'text', … }` entries out of a previously generated i18n block.
 * Text-level parse on purpose: the block is machine-written with one single-quoted pair per line, and this
 * must never throw on a hand-edited file — an unparsable block just yields no carry-over.
 */
export function parsePreviousI18n(source: string | undefined): Map<string, Record<string, string>> {
  const out = new Map<string, Record<string, string>>();
  if (!source) return out;
  const start = source.indexOf('/// **collab_i18n_start**');
  const end = source.indexOf('/// **collab_i18n_end**');
  if (start < 0 || end < 0 || end < start) return out;
  const block = source.slice(start, end);
  // The optional `: MessageType` matters: every non-default locale carries that annotation (it is what
  // makes a forgotten translation a compile error), so a parser that only accepted `= {` would read the
  // default locale and silently drop every translated one.
  const constRe = /const\s+message_([A-Za-z0-9_]+)\s*(?::\s*[A-Za-z0-9_]+\s*)?=\s*\{([\s\S]*?)\n\};/gu;
  for (const constMatch of block.matchAll(constRe)) {
    const locale = constMatch[1].replace(/_/gu, '-').toLowerCase();
    const entries: Record<string, string> = {};
    for (const pair of constMatch[2].matchAll(/^\s*'((?:[^'\\]|\\.)*)'\s*:\s*'((?:[^'\\]|\\.)*)'\s*,?\s*$/gmu)) {
      entries[unescapeSingle(pair[1])] = unescapeSingle(pair[2]);
    }
    if (Object.keys(entries).length > 0) out.set(locale, entries);
  }
  return out;
}

function unescapeSingle(value: string): string {
  return value.replace(/\\(['\\])/gu, '$1');
}

// ---------------------------------------------------------------------------
// Contract parsing (contracts/*.ts is generated by genCfeContractTs — regular shape)

export function parseContractInterfaces(source: string): Map<string, ContractInterface> {
  const interfaces = new Map<string, ContractInterface>();
  const re = /export interface ([A-Za-z0-9_]+)\s*\{/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(source))) {
    const name = m[1];
    const body = readBraceBody(source, re.lastIndex - 1);
    if (body === null) bail(`contract interface ${name} has unbalanced braces`);
    interfaces.set(name, { name, fields: parseInterfaceFields(name, body) });
    re.lastIndex += body.length;
  }
  return interfaces;
}

/** Returns the text between the brace at openIndex and its matching close (exclusive). */
function readBraceBody(source: string, openIndex: number): string | null {
  let depth = 0;
  for (let i = openIndex; i < source.length; i++) {
    const c = source[i];
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return source.slice(openIndex + 1, i);
    }
  }
  return null;
}

/** Fields end at a ';' at brace-depth 0 so inline object types ('{ a: string; }[]') stay intact. */
function parseInterfaceFields(interfaceName: string, body: string): ContractField[] {
  const fields: ContractField[] = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c === '{') depth++;
    else if (c === '}') depth--;
    else if (c === ';' && depth === 0) {
      const entry = body.slice(start, i).trim();
      start = i + 1;
      if (!entry) continue;
      const fm = /^([A-Za-z0-9_]+)(\?)?:\s*([\s\S]+)$/.exec(entry);
      if (!fm) bail(`contract interface ${interfaceName} has unparseable member: ${entry.slice(0, 60)}`);
      const rawType = fm[3].trim();
      const unionLiterals = parseStringUnion(rawType);
      const type = rawType === 'string' ? 'string'
        : rawType === 'number' ? 'number'
        : rawType === 'boolean' ? 'boolean'
        : rawType.endsWith('[]') ? 'array'
        : unionLiterals ? 'stringUnion'
        : null;
      if (!type) bail(`contract field ${interfaceName}.${fm[1]} has unsupported type: ${rawType.slice(0, 40)}`);
      const field: ContractField = { name: fm[1], type, optional: fm[2] === '?' };
      if (unionLiterals) field.firstLiteral = unionLiterals[0];
      fields.push(field);
    }
  }
  if (body.slice(start).trim()) bail(`contract interface ${interfaceName} has a trailing member without ';': ${body.slice(start).trim().slice(0, 60)}`);
  return fields;
}

/** '"a" | "b" | "c"' -> ['a', 'b', 'c']; null when the type is not a pure string-literal union. */
function parseStringUnion(rawType: string): string[] | null {
  const parts = rawType.split('|').map(part => part.trim());
  const literals: string[] = [];
  for (const part of parts) {
    const m = /^"([^"]*)"$/.exec(part) || /^'([^']*)'$/.exec(part);
    if (!m) return null;
    literals.push(m[1]);
  }
  return literals.length ? literals : null;
}

// ---------------------------------------------------------------------------
// Model building + validation (bail on any shape this generator does not model)

function buildModel(outputPath: string, data: unknown, contractSource: string, previousSource?: string): ScaffoldModel {
  if (!isRecord(data)) bail('definition is not an object');
  const baseClassName = stringOf(data.baseClassName) || bail('missing baseClassName');
  const routePattern = stringOf(data.routePattern) || bail('missing routePattern');
  const contractRef = isRecord(data.contractRef) ? data.contractRef : bail('missing contractRef');
  const contractTsPath = stringOf(contractRef.tsPath) || bail('missing contractRef.tsPath');
  // Operation-sourced workspaces list route consts under contractRef.contracts; workflow-sourced
  // contracts export no route consts, so execBff receives the action routeKey as a string literal.
  const contracts = Array.isArray(contractRef.contracts)
    ? contractRef.contracts.filter(isRecord).map(c => ({
      commandName: stringOf(c.commandName) || bail('contractRef.contracts entry missing commandName'),
      routeConst: stringOf(c.routeConst) || bail('contractRef.contracts entry missing routeConst'),
    }))
    : [];

  const i18nRaw = isRecord(data.i18n) ? data.i18n : bail('missing i18n');
  const i18n: Record<string, string> = {};
  for (const [key, value] of Object.entries(i18nRaw)) {
    if (typeof value !== 'string') bail(`i18n value for ${key} is not a string`);
    i18n[key] = value;
  }

  const states = (Array.isArray(data.states) ? data.states.filter(isRecord) : bail('missing states')).map(parseState);
  if (!states.length) bail('states is empty');
  const actions = (Array.isArray(data.actions) ? data.actions.filter(isRecord) : bail('missing actions')).map(parseAction);
  if (!actions.length) bail('actions is empty');

  const initialLoads = Array.isArray(data.initialLoads)
    ? data.initialLoads.filter(isRecord).map(load => ({ actionId: stringOf(load.actionId) || bail('initialLoads entry missing actionId') }))
    : [];

  const interfaces = parseContractInterfaces(contractSource);
  const stateByKey = new Map(states.map(state => [state.stateKey, state]));
  const actionById = new Map(actions.map(action => [action.actionId, action]));

  // defs i18nMeta.defaultLocale names the language the i18n catalog is written in. Falls back to 'en'
  // ONLY when the defs carries no meta at all (older defs) — never assume the catalog is English.
  const i18nMeta = isRecord(data.i18nMeta) ? data.i18nMeta : {};
  const defaultLocale = normalizeLocaleKey(stringOf(i18nMeta.defaultLocale)) || 'en';
  // runtimeLocales keeps the region ('pt-br', not 'pt') — it is what the runtime config lists and what
  // document.documentElement.lang carries. The default always comes first: getMessageKey falls back to
  // keys[0] when the language is unknown.
  const declared = Array.isArray(i18nMeta.runtimeLocales) ? i18nMeta.runtimeLocales.map(item => normalizeLocaleKey(stringOf(item))) : [];
  const runtimeLocales = [defaultLocale, ...declared.filter(locale => locale && locale !== defaultLocale)];

  const model: ScaffoldModel = {
    outputPath, baseClassName, routePattern, states, actions, initialLoads,
    i18n, defaultLocale, runtimeLocales, previousText: parsePreviousI18n(previousSource),
    contractTsPath, contracts, interfaces, stateByKey, actionById,
  };
  validateModel(model);
  return model;
}

function parseState(raw: Record<string, unknown>): DefsState {
  const kind = stringOf(raw.kind);
  if (!['pageStatus', 'actionStatus', 'input', 'queryResult', 'commandOutput', 'actionError'].includes(kind)) {
    bail(`state ${stringOf(raw.stateKey)} has unsupported kind: ${kind}`);
  }
  const state: DefsState = {
    stateKey: stringOf(raw.stateKey) || bail('state missing stateKey'),
    name: stringOf(raw.name) || bail(`state ${stringOf(raw.stateKey)} missing name`),
    kind: kind as DefsState['kind'],
    defaultValue: raw.defaultValue,
  };
  if (typeof raw.actionRef === 'string') state.actionRef = raw.actionRef;
  if (Array.isArray(raw.valueSet)) {
    if (!raw.valueSet.every(v => typeof v === 'string')) bail(`state ${state.stateKey} valueSet is not string[]`);
    state.valueSet = raw.valueSet as string[];
  }
  if (isRecord(raw.contractRef)) {
    const direction = stringOf(raw.contractRef.direction);
    if (direction !== 'input' && direction !== 'output') bail(`state ${state.stateKey} contractRef.direction invalid`);
    state.contractRef = {
      commandName: stringOf(raw.contractRef.commandName) || bail(`state ${state.stateKey} contractRef missing commandName`),
      direction,
    };
    if (typeof raw.contractRef.field === 'string') state.contractRef.field = raw.contractRef.field;
  }
  if (raw.outputShape !== undefined) {
    const shape = stringOf(raw.outputShape);
    if (shape !== 'paginated' && shape !== 'object' && shape !== 'array') bail(`state ${state.stateKey} outputShape unsupported: ${shape}`);
    state.outputShape = shape;
  }
  if (typeof raw.collection === 'boolean') state.collection = raw.collection;
  if (state.kind === 'actionStatus' && (!state.valueSet || !state.valueSet.length)) bail(`state ${state.stateKey} actionStatus without valueSet`);
  if (state.kind === 'queryResult' && !state.contractRef) bail(`state ${state.stateKey} queryResult without contractRef`);
  if (state.kind === 'commandOutput' && !state.contractRef) bail(`state ${state.stateKey} commandOutput without contractRef`);
  return state;
}

function parseAction(raw: Record<string, unknown>): DefsAction {
  const kind = stringOf(raw.kind);
  if (kind !== 'query' && kind !== 'command' && kind !== 'stateSetter') bail(`action ${stringOf(raw.actionId)} has unsupported kind: ${kind}`);
  const action: DefsAction = {
    actionId: stringOf(raw.actionId) || bail('action missing actionId'),
    kind,
    methodName: stringOf(raw.methodName) || bail(`action ${stringOf(raw.actionId)} missing methodName`),
    handlerName: stringOf(raw.handlerName) || bail(`action ${stringOf(raw.actionId)} missing handlerName`),
  };
  if (typeof raw.commandRef === 'string') action.commandRef = raw.commandRef;
  if (typeof raw.routeKey === 'string') action.routeKey = raw.routeKey;
  if (typeof raw.stateKey === 'string') action.stateKey = raw.stateKey;
  action.inputStateKeys = stringArray(raw.inputStateKeys);
  action.routeParamInputStateKeys = stringArray(raw.routeParamInputStateKeys);
  action.selectedEntityInputStateKeys = stringArray(raw.selectedEntityInputStateKeys);
  action.outputStateKeys = stringArray(raw.outputStateKeys);
  if (typeof raw.statusStateKey === 'string') action.statusStateKey = raw.statusStateKey;
  if (typeof raw.errorStateKey === 'string') action.errorStateKey = raw.errorStateKey;
  if (isRecord(raw.feedback)) {
    action.feedback = {
      successMessageKey: stringOf(raw.feedback.successMessageKey) || undefined,
      errorMessageKey: stringOf(raw.feedback.errorMessageKey) || undefined,
    };
  }
  action.clearInputStateKeys = stringArray(raw.clearInputStateKeys);
  action.refreshActionIds = stringArray(raw.refreshActionIds);
  if (isRecord(raw.prefill)) {
    const shape = stringOf(raw.prefill.sourceOutputShape);
    if (shape !== 'array' && shape !== 'object') bail(`action ${action.actionId} prefill sourceOutputShape unsupported: ${shape}`);
    action.prefill = {
      command: stringOf(raw.prefill.command),
      sourceStateKey: stringOf(raw.prefill.sourceStateKey) || bail(`action ${action.actionId} prefill missing sourceStateKey`),
      sourceOutputShape: shape,
      matchField: stringOf(raw.prefill.matchField) || bail(`action ${action.actionId} prefill missing matchField`),
      fields: Array.isArray(raw.prefill.fields)
        ? raw.prefill.fields.filter(isRecord).map(f => ({
          itemField: stringOf(f.itemField) || bail(`action ${action.actionId} prefill field missing itemField`),
          targetStateKey: stringOf(f.targetStateKey) || bail(`action ${action.actionId} prefill field missing targetStateKey`),
        }))
        : [],
    };
  }

  if (kind === 'stateSetter' && !action.stateKey) bail(`action ${action.actionId} stateSetter without stateKey`);
  if ((kind === 'query' || kind === 'command') && (!action.commandRef || !action.routeKey || !action.statusStateKey)) {
    bail(`action ${action.actionId} missing commandRef/routeKey/statusStateKey`);
  }
  if (kind === 'command' && (!action.errorStateKey || !action.feedback?.errorMessageKey)) {
    bail(`action ${action.actionId} command without errorStateKey/feedback`);
  }
  return action;
}

function validateModel(model: ScaffoldModel): void {
  // Class-member namespace is shared between state properties and action methods/handlers; a
  // collision makes ANY generation (deterministic or LLM) fail its own typecheck test, so surface
  // it as a precise bail — the fix belongs in the defs generator's naming rules.
  const memberOwner = new Map<string, string>();
  for (const state of model.states) memberOwner.set(state.name, `state ${state.stateKey}`);
  for (const action of model.actions) {
    for (const member of [action.methodName, action.handlerName]) {
      const owner = memberOwner.get(member);
      if (owner) bail(`defs naming collision: ${owner} and action ${action.actionId} both claim class member '${member}'`);
      memberOwner.set(member, `action ${action.actionId}`);
    }
  }
  for (const action of model.actions) {
    if (action.kind === 'stateSetter') {
      const state = model.stateByKey.get(action.stateKey || '');
      if (!state) bail(`setter ${action.actionId} references unknown state ${action.stateKey}`);
      if (state.kind !== 'input') bail(`setter ${action.actionId} targets non-input state ${state.stateKey}`);
      if (action.prefill) validatePrefill(model, action);
      continue;
    }
    const commandName = action.commandRef || '';
    inputInterfaceOf(model, commandName);
    outputInterfaceOf(model, commandName);
    for (const key of action.inputStateKeys || []) {
      const state = model.stateByKey.get(key);
      if (!state) bail(`action ${action.actionId} references unknown input state ${key}`);
      if (!state.contractRef?.field) bail(`input state ${key} has no contractRef.field`);
    }
    const statusState = model.stateByKey.get(action.statusStateKey || '');
    if (!statusState || !statusState.valueSet) bail(`action ${action.actionId} status state missing/invalid`);
    for (const value of ['idle', 'loading', 'success', 'error']) {
      if (!statusState.valueSet.includes(value)) bail(`action ${action.actionId} status valueSet missing '${value}'`);
    }
    const outputKeys = action.outputStateKeys || [];
    if (action.kind === 'query') {
      if (outputKeys.length !== 1) bail(`query ${action.actionId} must have exactly one output state`);
      const dataState = model.stateByKey.get(outputKeys[0]);
      if (!dataState || dataState.kind !== 'queryResult') bail(`query ${action.actionId} output state is not a queryResult`);
    } else {
      if (outputKeys.length !== 1) bail(`command ${action.actionId} must have exactly one output state`);
      const outState = model.stateByKey.get(outputKeys[0]);
      if (!outState || outState.kind !== 'commandOutput') bail(`command ${action.actionId} output state is not a commandOutput`);
      const errorState = model.stateByKey.get(action.errorStateKey || '');
      if (!errorState || errorState.kind !== 'actionError') bail(`command ${action.actionId} error state missing`);
      for (const refreshId of action.refreshActionIds || []) {
        const refresh = model.actionById.get(refreshId);
        if (!refresh || refresh.kind !== 'query') bail(`command ${action.actionId} refresh target ${refreshId} is not a query`);
      }
      for (const key of action.clearInputStateKeys || []) {
        if (!model.stateByKey.get(key)) bail(`command ${action.actionId} clear target ${key} unknown`);
      }
    }
  }
  for (const load of model.initialLoads) {
    const action = model.actionById.get(load.actionId);
    if (!action || action.kind !== 'query') bail(`initialLoads references non-query action ${load.actionId}`);
  }
  for (const state of model.states) {
    if (state.kind === 'queryResult' && !state.outputShape) bail(`queryResult ${state.stateKey} missing outputShape`);
  }
}

function validatePrefill(model: ScaffoldModel, action: DefsAction): void {
  const prefill = action.prefill!;
  const source = model.stateByKey.get(prefill.sourceStateKey);
  if (!source || source.kind !== 'queryResult') bail(`prefill of ${action.actionId} sources non-queryResult ${prefill.sourceStateKey}`);
  const output = outputInterfaceOf(model, source.contractRef!.commandName);
  const known = new Set(output.fields.map(f => f.name));
  if (!known.has(prefill.matchField)) bail(`prefill of ${action.actionId} matchField ${prefill.matchField} not in ${output.name}`);
  for (const field of prefill.fields) {
    if (!known.has(field.itemField)) bail(`prefill of ${action.actionId} field ${field.itemField} not in ${output.name}`);
    const target = model.stateByKey.get(field.targetStateKey);
    if (!target || target.kind !== 'input') bail(`prefill of ${action.actionId} target ${field.targetStateKey} is not an input state`);
  }
}

// ---------------------------------------------------------------------------
// Rendering

function render(model: ScaffoldModel): string {
  const out: string[] = [];
  out.push(mlsHeaderForOutputPath(model.outputPath));
  out.push('');
  out.push(...renderImports(model));
  out.push('');
  out.push(...renderI18n(model));
  out.push('');
  out.push(...renderDefaultConsts(model));
  out.push(...renderSubscribedKeys(model));
  out.push('');
  out.push(`export class ${model.baseClassName} extends CollabLitElement {`);
  out.push(...renderProperties(model));
  out.push('');
  out.push(...renderConnectedCallback(model));
  out.push('');
  out.push(...renderDisconnectedCallback());
  out.push('');
  out.push(...renderStateChange(model));
  out.push('');
  out.push(...renderInitStateValue(model));
  if (routeParams(model).length) {
    out.push('');
    out.push(...renderSyncRouteParams(model));
  }
  if (model.actions.some(a => a.kind === 'command')) {
    out.push('');
    out.push(...renderReadErrorMessage());
  }
  for (const action of model.actions) {
    if (action.kind === 'stateSetter') continue;
    out.push('');
    out.push(...(action.kind === 'query' ? renderQuery(model, action) : renderCommand(model, action)));
  }
  for (const action of model.actions) {
    if (action.kind !== 'stateSetter') continue;
    out.push('');
    out.push(...renderSetter(model, action));
  }
  out.push('}');
  out.push('');
  return out.join('\n');
}

function renderImports(model: ScaffoldModel): string[] {
  const hasCommand = model.actions.some(a => a.kind === 'command');
  const contractImport = aliasJsImport(model.contractTsPath);
  const typeNames: string[] = [];
  for (const commandName of usedCommands(model)) {
    typeNames.push(`${toPascalCase(commandName)}Input`);
    typeNames.push(`${toPascalCase(commandName)}Output`);
  }
  const lines = [
    `import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';`,
    `import { property } from 'lit/decorators.js';`,
    `import { execBff, type BffClientOptions } from '/_102029_/l2/bffClient.js';`,
    `import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';`,
  ];
  if (hasCommand) lines.push(`import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';`);
  lines.push('import type {');
  for (const name of typeNames) lines.push(`  ${name},`);
  lines.push(`} from '${contractImport}';`);
  if (model.contracts.length) {
    lines.push('import {');
    for (const contract of model.contracts) lines.push(`  ${contract.routeConst},`);
    lines.push(`} from '${contractImport}';`);
  }
  lines.push('');
  lines.push('export type {');
  for (const name of typeNames) lines.push(`  ${name},`);
  lines.push(`} from '${contractImport}';`);
  return lines;
}

/** Commands referenced by query/command actions, in defs order (deduped). */
function usedCommands(model: ScaffoldModel): string[] {
  const commands: string[] = [];
  for (const action of model.actions) {
    if (action.kind === 'stateSetter' || !action.commandRef) continue;
    if (!commands.includes(action.commandRef)) commands.push(action.commandRef);
  }
  return commands;
}

// The catalog is named after the module's DEFAULT LOCALE, never a hardcoded 'en': a pt-BR module used to
// emit `message_en`/`messages.en` holding Portuguese text, so a pt-br runtime found no `messages['pt-br']`
// (nor the 'pt' prefix fallback) and silently rendered whatever keys[0] happened to be.
// The map key is the lowercase locale ('pt-br') because the runtime sets document.documentElement.lang
// from the normalized config list (102033 listRuntimeLanguages) and the base class getter looks up
// messages[lang.toLowerCase()]. The const name uses a TS-safe form of it ('pt-br' -> message_pt_br).
// EVERY declared locale is emitted, not only the default. The pages reference sharedMessages['pt-br'], so
// a shared regenerated with a single locale makes every page label fall back to the default language
// without any error (i18n.md item 4). Text already translated in the previous file is carried over per
// key; a key with no prior translation starts as the default-locale text, which agentAddLanguage then
// translates. Non-default locales are annotated `: MessageType` so the compiler enforces locale parity —
// a missing key is TS2741 and a typo'd key is TS2353, instead of a silent hole at runtime.
function renderI18n(model: ScaffoldModel): string[] {
  const constNameOf = (locale: string): string => `message_${locale.replace(/[^a-zA-Z0-9]+/gu, '_')}`;
  const defaultConst = constNameOf(model.defaultLocale);
  const lines = ['/// **collab_i18n_start**'];

  for (const locale of model.runtimeLocales) {
    const isDefault = locale === model.defaultLocale;
    const previous = model.previousText.get(locale) || {};
    lines.push(`const ${constNameOf(locale)}${isDefault ? '' : ': MessageType'} = {`);
    for (const [key, value] of Object.entries(model.i18n)) {
      const text = isDefault ? value : (previous[key] ?? value);
      lines.push(`  '${escapeSingle(key)}': '${escapeSingle(text)}',`);
    }
    lines.push('};');
    if (isDefault) lines.push(`export type MessageType = typeof ${defaultConst};`);
  }

  const entries = model.runtimeLocales.map(locale => `'${escapeSingle(locale)}': ${constNameOf(locale)}`).join(', ');
  lines.push(`export const messages: { [key: string]: MessageType } = { ${entries} };`);
  lines.push('/// **collab_i18n_end**');
  return lines;
}

// Lowercase, '_' -> '-' — the SAME normalization the runtime applies to the config language list
// (102033 languageRuntime.normalizeLanguage), so the catalog key always matches documentElement.lang.
function normalizeLocaleKey(value: string): string {
  return value.trim().replace(/_/gu, '-').toLowerCase();
}

function renderDefaultConsts(model: ScaffoldModel): string[] {
  const lines: string[] = [];
  for (const state of model.states) {
    if (state.kind !== 'queryResult' || state.outputShape !== 'paginated') continue;
    const output = outputInterfaceOf(model, state.contractRef!.commandName);
    const fields = output.fields.filter(f => !f.optional).map(f => `${f.name}: ${zeroValue(f)}`);
    lines.push(`const ${defaultConstName(state)}: ${output.name} = { ${fields.join(', ')} };`);
  }
  if (lines.length) lines.push('');
  return lines;
}

function renderSubscribedKeys(model: ScaffoldModel): string[] {
  const lines = ['const SUBSCRIBED_STATE_KEYS: string[] = ['];
  for (const state of model.states) lines.push(`  '${state.stateKey}',`);
  lines.push('];');
  return lines;
}

function renderProperties(model: ScaffoldModel): string[] {
  const lines: string[] = [];
  for (const state of model.states) {
    lines.push(`  /** ${stateDoc(state)} */`);
    lines.push(`  @property() ${state.name}: ${propertyType(model, state)} = ${propertyInit(model, state)};`);
  }
  return lines;
}

function renderConnectedCallback(model: ScaffoldModel): string[] {
  const lines = ['  connectedCallback(): void {', '    super.connectedCallback();'];
  for (const state of model.states) {
    lines.push(`    this.initStateValue('${state.stateKey}', ${propertyInit(model, state)});`);
  }
  if (routeParams(model).length) lines.push('    this.syncRouteParams();');
  lines.push('    subscribe(SUBSCRIBED_STATE_KEYS, this);');
  for (const load of model.initialLoads) {
    const action = model.actionById.get(load.actionId)!;
    lines.push(`    void this.${action.methodName}();`);
  }
  lines.push('  }');
  return lines;
}

function renderDisconnectedCallback(): string[] {
  return [
    '  disconnectedCallback(): void {',
    '    unsubscribe(SUBSCRIBED_STATE_KEYS, this);',
    '    super.disconnectedCallback();',
    '  }',
  ];
}

function renderStateChange(model: ScaffoldModel): string[] {
  const lines = [
    '  /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */',
    '  handleIcaStateChange(key: string, value: unknown): void {',
    '    switch (key) {',
  ];
  for (const state of model.states) {
    lines.push(`      case '${state.stateKey}':`);
    lines.push(`        this.${state.name} = ${castExpression(model, state)};`);
    lines.push('        break;');
  }
  lines.push('      default:');
  lines.push('        break;');
  lines.push('    }');
  lines.push('    this.requestUpdate();');
  lines.push('  }');
  return lines;
}

function renderInitStateValue(model: ScaffoldModel): string[] {
  const lines = [
    '  private initStateValue(stateKey: string, defaultValue: unknown): void {',
    '    const existing: unknown = getState(stateKey);',
    '    const value: unknown = existing !== undefined ? existing : defaultValue;',
    '    switch (stateKey) {',
  ];
  for (const state of model.states) {
    lines.push(`      case '${state.stateKey}':`);
    lines.push(`        this.${state.name} = ${castExpression(model, state)};`);
    lines.push('        break;');
  }
  lines.push('      default:');
  lines.push('        break;');
  lines.push('    }');
  lines.push('    if (existing === undefined) {');
  lines.push('      setState(stateKey, value);');
  lines.push('    }');
  lines.push('  }');
  return lines;
}

interface RouteParamTargets { param: string; targets: { propName: string; stateKey: string }[] }

function routeParams(model: ScaffoldModel): RouteParamTargets[] {
  const names = [...model.routePattern.matchAll(/:([A-Za-z0-9_]+)\??/g)].map(m => m[1]);
  const params: RouteParamTargets[] = names.map(name => ({ param: name, targets: [] }));
  const seen = new Set<string>();
  for (const action of model.actions) {
    for (const key of action.routeParamInputStateKeys || []) {
      if (seen.has(key)) continue;
      const field = key.split('.').pop() || '';
      const entry = params.find(p => p.param === field);
      const state = model.stateByKey.get(key);
      if (!entry || !state) continue;
      seen.add(key);
      entry.targets.push({ propName: state.name, stateKey: key });
    }
  }
  return params.filter(p => p.targets.length > 0);
}

function renderSyncRouteParams(model: ScaffoldModel): string[] {
  const allNames = [...model.routePattern.matchAll(/:([A-Za-z0-9_]+)\??/g)].map(m => m[1]);
  const basePath = model.routePattern.split('/:')[0];
  const regex = `/^${basePath.replace(/\//g, '\\/')}${'(?:\\/([^/]+))?'.repeat(allNames.length)}\\/?$/`;
  const lines = [
    '  private syncRouteParams(): void {',
    '    const pathname: string = window.location.pathname;',
    '    const match: RegExpMatchArray | null = pathname.match(',
    `      ${regex},`,
    '    );',
  ];
  const params = routeParams(model);
  for (const { param, targets } of params) {
    const index = allNames.indexOf(param) + 1;
    lines.push(`    const raw${toPascalCase(param)}: string = match && match[${index}] ? match[${index}] : '';`);
    lines.push(`    let ${param}: string = '';`);
    lines.push(`    if (raw${toPascalCase(param)}) {`);
    lines.push('      try {');
    lines.push(`        ${param} = decodeURIComponent(raw${toPascalCase(param)});`);
    lines.push('      } catch {');
    lines.push(`        ${param} = raw${toPascalCase(param)};`);
    lines.push('      }');
    lines.push('    }');
    lines.push(`    if (${param}) {`);
    for (const target of targets) {
      lines.push(`      if (!this.${target.propName}) {`);
      lines.push(`        this.${target.propName} = ${param};`);
      lines.push(`        setState('${target.stateKey}', ${param});`);
      lines.push('      }');
    }
    lines.push('    }');
  }
  lines.push('  }');
  return lines;
}

function renderReadErrorMessage(): string[] {
  return [
    '  private readErrorMessage(error: unknown, fallback: string): string {',
    '    if (error && typeof error === \'object\') {',
    '      const record = error as { message?: unknown; error?: unknown };',
    '      if (typeof record.message === \'string\' && record.message) {',
    '        return record.message;',
    '      }',
    '      if (typeof record.error === \'string\' && record.error) {',
    '        return record.error;',
    '      }',
    '    }',
    '    return fallback;',
    '  }',
  ];
}

function renderQuery(model: ScaffoldModel, action: DefsAction): string[] {
  const input = inputInterfaceOf(model, action.commandRef!);
  const dataState = model.stateByKey.get((action.outputStateKeys || [])[0])!;
  const statusState = model.stateByKey.get(action.statusStateKey!)!;
  const route = routeExprOf(model, action);
  const lines = [
    `  /** ${actionDoc(model, action)} */`,
    `  async ${action.methodName}(): Promise<void> {`,
  ];
  if (routeParams(model).length) lines.push('    this.syncRouteParams();');
  lines.push(...renderRequiredGuards(model, action, statusState, '    '));
  lines.push(`    this.${statusState.name} = 'loading';`);
  lines.push(`    setState('${statusState.stateKey}', 'loading');`);
  lines.push(...renderParams(model, action, input, '    '));
  lines.push(`    const options: BffClientOptions = { mode: 'silent' };`);
  lines.push(`    const response = await execBff<${queryExecType(model, dataState)}>(${route}, params, options);`);
  lines.push('    if (response.ok) {');
  lines.push(`      const data = response.data ?? ${queryFallback(model, dataState)};`);
  lines.push(`      this.${dataState.name} = data;`);
  lines.push(`      setState('${dataState.stateKey}', data);`);
  lines.push(`      this.${statusState.name} = 'success';`);
  lines.push(`      setState('${statusState.stateKey}', 'success');`);
  lines.push('    } else {');
  lines.push(`      this.${statusState.name} = 'error';`);
  lines.push(`      setState('${statusState.stateKey}', 'error');`);
  lines.push('      if (response.error) {');
  lines.push(`        console.error('${action.actionId} failed', response.error);`);
  lines.push('      }');
  lines.push('    }');
  lines.push('    this.requestUpdate();');
  lines.push('  }');
  lines.push('');
  lines.push(`  /** handler for action ${action.actionId} — bind UI events here */`);
  lines.push(`  ${action.handlerName}(event?: Event): void {`);
  lines.push('    if (event) {');
  lines.push('      event.preventDefault();');
  lines.push('    }');
  lines.push(`    void this.${action.methodName}();`);
  lines.push('  }');
  return lines;
}

function renderCommand(model: ScaffoldModel, action: DefsAction): string[] {
  const input = inputInterfaceOf(model, action.commandRef!);
  const outputState = model.stateByKey.get((action.outputStateKeys || [])[0])!;
  const outputType = `${toPascalCase(action.commandRef!)}Output`;
  const statusState = model.stateByKey.get(action.statusStateKey!)!;
  const errorState = model.stateByKey.get(action.errorStateKey!)!;
  const route = routeExprOf(model, action);
  const errorKey = action.feedback!.errorMessageKey!;
  const lines = [
    `  /** ${actionDoc(model, action)} */`,
    `  async ${action.methodName}(): Promise<void> {`,
  ];
  if (routeParams(model).length) lines.push('    this.syncRouteParams();');
  lines.push(...renderRequiredGuards(model, action, statusState, '    '));
  lines.push(`    this.${statusState.name} = 'loading';`);
  lines.push(`    setState('${statusState.stateKey}', 'loading');`);
  lines.push(`    this.${errorState.name} = '';`);
  lines.push(`    setState('${errorState.stateKey}', '');`);
  lines.push(...renderParams(model, action, input, '    '));
  lines.push(`    const options: BffClientOptions = { mode: 'blocking' };`);
  lines.push(`    const response = await execBff<${outputType}>(${route}, params, options);`);
  lines.push('    if (!response.ok) {');
  lines.push(`      const errMsg: string = this.readErrorMessage(response.error, '${errorKey}');`);
  lines.push(`      this.${errorState.name} = errMsg;`);
  lines.push(`      setState('${errorState.stateKey}', errMsg);`);
  lines.push(`      this.${statusState.name} = 'error';`);
  lines.push(`      setState('${statusState.stateKey}', 'error');`);
  lines.push('      this.requestUpdate();');
  lines.push('      return;');
  lines.push('    }');
  lines.push(`    const data: ${outputType} | null = response.data ?? null;`);
  lines.push(`    this.${outputState.name} = data;`);
  lines.push(`    setState('${outputState.stateKey}', data);`);
  for (const refreshId of action.refreshActionIds || []) {
    const refresh = model.actionById.get(refreshId)!;
    const refreshStatus = model.stateByKey.get(refresh.statusStateKey!)!;
    lines.push('    try {');
    lines.push(`      await this.${refresh.methodName}();`);
    lines.push(`      if (this.${refreshStatus.name} === 'error') {`);
    lines.push(`        this.${statusState.name} = 'error';`);
    lines.push(`        setState('${statusState.stateKey}', 'error');`);
    lines.push('        this.requestUpdate();');
    lines.push('        return;');
    lines.push('      }');
    lines.push('    } catch (refreshError: unknown) {');
    lines.push(`      console.error('${action.actionId} refresh failed', refreshError);`);
    lines.push(`      this.${statusState.name} = 'error';`);
    lines.push(`      setState('${statusState.stateKey}', 'error');`);
    lines.push('      this.requestUpdate();');
    lines.push('      return;');
    lines.push('    }');
  }
  for (const key of action.clearInputStateKeys || []) {
    const clearState = model.stateByKey.get(key)!;
    lines.push(`    this.${clearState.name} = '';`);
    lines.push(`    setState('${key}', '');`);
  }
  lines.push(`    this.${statusState.name} = 'success';`);
  lines.push(`    setState('${statusState.stateKey}', 'success');`);
  lines.push('    this.requestUpdate();');
  lines.push('  }');
  lines.push('');
  lines.push(`  /** handler for action ${action.actionId} — bind UI events here */`);
  lines.push(`  ${action.handlerName}(event?: Event): void {`);
  lines.push('    if (event) {');
  lines.push('      event.preventDefault();');
  lines.push('    }');
  lines.push('    void runBlockingUiAction(async (_signal: AbortSignal) => {');
  lines.push(`      await this.${action.methodName}();`);
  lines.push('    });');
  lines.push('  }');
  return lines;
}

/**
 * Guard route-param/selected-entity ids only (the values arriving programmatically): user-typed
 * required fields are the SERVER's validation to report, never a silent client-side skip — this
 * mirrors the golden convention (deleteClient guards clientId, createClient does not guard name).
 */
function renderRequiredGuards(model: ScaffoldModel, action: DefsAction, statusState: DefsState, indent: string): string[] {
  const input = inputInterfaceOf(model, action.commandRef!);
  const requiredFields = new Set(input.fields.filter(f => !f.optional).map(f => f.name));
  const lines: string[] = [];
  const guardKeys = [...(action.routeParamInputStateKeys || []), ...(action.selectedEntityInputStateKeys || [])];
  const seen = new Set<string>();
  for (const key of guardKeys) {
    if (seen.has(key)) continue;
    seen.add(key);
    const state = model.stateByKey.get(key);
    if (!state || !state.contractRef?.field || !requiredFields.has(state.contractRef.field)) continue;
    lines.push(`${indent}if (!this.${state.name}) {`);
    lines.push(`${indent}  this.${statusState.name} = 'idle';`);
    lines.push(`${indent}  setState('${statusState.stateKey}', 'idle');`);
    lines.push(`${indent}  this.requestUpdate();`);
    lines.push(`${indent}  return;`);
    lines.push(`${indent}}`);
  }
  return lines;
}

function renderParams(model: ScaffoldModel, action: DefsAction, input: ContractInterface, indent: string): string[] {
  const inputStates = (action.inputStateKeys || []).map(key => model.stateByKey.get(key)!);
  const stateByField = new Map(inputStates.map(state => [state.contractRef!.field!, state]));
  const lines: string[] = [];
  const requiredLines: string[] = [];

  for (const field of input.fields.filter(f => !f.optional)) {
    const state = stateByField.get(field.name);
    if (!state) bail(`action ${action.actionId} has no input state for required contract field ${field.name}`);
    if (field.type === 'string') {
      requiredLines.push(`${indent}  ${field.name}: this.${state.name},`);
    } else if (field.type === 'stringUnion') {
      // Input states are plain strings; the contract narrows to a literal union — cast at the seam.
      requiredLines.push(`${indent}  ${field.name}: this.${state.name} as ${input.name}['${field.name}'],`);
    } else if (field.type === 'number') {
      lines.push(`${indent}const ${field.name}Num = Number(this.${state.name});`);
      requiredLines.push(`${indent}  ${field.name}: Number.isNaN(${field.name}Num) ? 0 : ${field.name}Num,`);
    } else if (field.type === 'boolean') {
      requiredLines.push(`${indent}  ${field.name}: this.${state.name} === 'true',`);
    } else {
      bail(`action ${action.actionId} required field ${field.name} has unsupported input type ${field.type}`);
    }
  }
  lines.push(`${indent}const params: ${input.name} = {`);
  lines.push(...requiredLines);
  lines.push(`${indent}};`);

  for (const field of input.fields.filter(f => f.optional)) {
    const state = stateByField.get(field.name);
    if (!state) continue; // optional contract field without a UI input state simply stays unset
    if (field.type === 'string') {
      lines.push(`${indent}if (this.${state.name}) {`);
      lines.push(`${indent}  params.${field.name} = this.${state.name};`);
      lines.push(`${indent}}`);
    } else if (field.type === 'stringUnion') {
      lines.push(`${indent}if (this.${state.name}) {`);
      lines.push(`${indent}  params.${field.name} = this.${state.name} as ${input.name}['${field.name}'];`);
      lines.push(`${indent}}`);
    } else if (field.type === 'number') {
      lines.push(`${indent}if (this.${state.name} !== '') {`);
      lines.push(`${indent}  const ${field.name}Num = Number(this.${state.name});`);
      lines.push(`${indent}  if (!Number.isNaN(${field.name}Num)) {`);
      lines.push(`${indent}    params.${field.name} = ${field.name}Num;`);
      lines.push(`${indent}  }`);
      lines.push(`${indent}}`);
    } else if (field.type === 'boolean') {
      // Input states are always `string` (propertyType), so a checkbox arrives as 'true'/'false'/''.
      // Empty means "not set" and the optional field stays out of the payload.
      lines.push(`${indent}if (this.${state.name} !== '') {`);
      lines.push(`${indent}  params.${field.name} = this.${state.name} === 'true';`);
      lines.push(`${indent}}`);
    } else {
      bail(`action ${action.actionId} optional field ${field.name} has unsupported input type ${field.type}`);
    }
  }
  return lines;
}

function renderSetter(model: ScaffoldModel, action: DefsAction): string[] {
  const state = model.stateByKey.get(action.stateKey!)!;
  const lines = [
    `  /** setter for state ${state.stateKey} */`,
    `  ${action.methodName}(value: string): void {`,
    `    this.${state.name} = value;`,
    `    setState('${state.stateKey}', value);`,
  ];
  if (action.prefill) lines.push(...renderPrefill(model, action.prefill, '    '));
  lines.push('    this.requestUpdate();');
  lines.push('  }');
  lines.push('');
  lines.push(`  /** handler for action ${action.actionId} — bind UI events here */`);
  lines.push(`  ${action.handlerName}(event: Event): void {`);
  lines.push('    const target = event.target as HTMLInputElement | HTMLSelectElement | null;');
  lines.push(`    const value: string = target && 'value' in target ? String(target.value) : '';`);
  lines.push(`    this.${action.methodName}(value);`);
  lines.push('  }');
  return lines;
}

function renderPrefill(model: ScaffoldModel, prefill: DefsPrefill, indent: string): string[] {
  const source = model.stateByKey.get(prefill.sourceStateKey)!;
  const output = outputInterfaceOf(model, source.contractRef!.commandName);
  const fieldTypes = new Map(output.fields.map(f => [f.name, f.type]));
  const copyExpr = (itemVar: string, field: DefsPrefillField): string => (
    fieldTypes.get(field.itemField) === 'string' ? `${itemVar}.${field.itemField}` : `String(${itemVar}.${field.itemField})`
  );
  const lines: string[] = [];
  if (prefill.sourceOutputShape === 'array') {
    lines.push(`${indent}const collection =`);
    lines.push(`${indent}  (getState('${prefill.sourceStateKey}') as ${output.name}[] | null | undefined) ?? this.${source.name};`);
    lines.push(`${indent}if (Array.isArray(collection) && collection.length > 0) {`);
    lines.push(`${indent}  const item = collection.find(`);
    lines.push(`${indent}    (row: ${output.name}) => String(row.${prefill.matchField}) === String(value),`);
    lines.push(`${indent}  );`);
    lines.push(`${indent}  if (item) {`);
    for (const field of prefill.fields) {
      const target = model.stateByKey.get(field.targetStateKey)!;
      lines.push(`${indent}    this.${target.name} = ${copyExpr('item', field)};`);
      lines.push(`${indent}    setState('${field.targetStateKey}', ${copyExpr('item', field)});`);
    }
    lines.push(`${indent}  }`);
    lines.push(`${indent}}`);
    return lines;
  }
  lines.push(`${indent}const source =`);
  lines.push(`${indent}  (getState('${prefill.sourceStateKey}') as ${output.name} | null | undefined) ?? this.${source.name};`);
  lines.push(`${indent}if (source && String(source.${prefill.matchField}) === String(value)) {`);
  for (const field of prefill.fields) {
    const target = model.stateByKey.get(field.targetStateKey)!;
    lines.push(`${indent}  this.${target.name} = ${copyExpr('source', field)};`);
    lines.push(`${indent}  setState('${field.targetStateKey}', ${copyExpr('source', field)});`);
  }
  lines.push(`${indent}}`);
  return lines;
}

// ---------------------------------------------------------------------------
// Type/value mapping

function propertyType(model: ScaffoldModel, state: DefsState): string {
  switch (state.kind) {
    case 'pageStatus':
    case 'input':
    case 'actionError':
      return 'string';
    case 'actionStatus':
      return state.valueSet!.map(v => `'${v}'`).join(' | ');
    case 'commandOutput':
      return `${toPascalCase(state.contractRef!.commandName)}Output | null`;
    case 'queryResult': {
      const output = outputInterfaceOf(model, state.contractRef!.commandName);
      if (state.outputShape === 'paginated') return output.name;
      if (state.outputShape === 'array') return `${output.name}[]`;
      return `${output.name} | null`;
    }
  }
}

function propertyInit(model: ScaffoldModel, state: DefsState): string {
  switch (state.kind) {
    case 'pageStatus':
    case 'input':
    case 'actionError':
      return `'${escapeSingle(String(state.defaultValue ?? ''))}'`;
    case 'actionStatus':
      return `'${escapeSingle(String(state.defaultValue ?? 'idle'))}'`;
    case 'commandOutput':
      return 'null';
    case 'queryResult':
      if (state.outputShape === 'paginated') return defaultConstName(state);
      if (state.outputShape === 'array') return '[]';
      return 'null';
  }
}

function castExpression(model: ScaffoldModel, state: DefsState): string {
  const type = propertyType(model, state);
  const fallback = state.kind === 'queryResult' && state.outputShape === 'paginated'
    ? defaultConstName(state)
    : state.kind === 'queryResult' && state.outputShape === 'array'
      ? '[]'
      : state.kind === 'queryResult' || state.kind === 'commandOutput'
        ? 'null'
        : propertyInit(model, state);
  return `(value as ${type}) ?? ${fallback}`;
}

function queryExecType(model: ScaffoldModel, state: DefsState): string {
  const output = outputInterfaceOf(model, state.contractRef!.commandName);
  return state.outputShape === 'array' ? `${output.name}[]` : output.name;
}

function queryFallback(model: ScaffoldModel, state: DefsState): string {
  if (state.outputShape === 'paginated') return defaultConstName(state);
  if (state.outputShape === 'array') return '[]';
  return 'null';
}

function stateDoc(state: DefsState): string {
  const parts = [`state ${state.name} — ${state.kind}`];
  if (state.kind === 'actionStatus') parts.push(`, values: ${state.valueSet!.join('|')}`);
  if (state.kind === 'queryResult') parts.push(`, outputShape: ${state.outputShape}`);
  return parts.join('');
}

function actionDoc(model: ScaffoldModel, action: DefsAction): string {
  const input = inputInterfaceOf(model, action.commandRef!);
  const inputs = input.fields.map(f => f.name).join(', ');
  const parts = [
    `action ${action.actionId} (${action.kind}) — route ${action.routeKey}`,
    `inputs: ${inputs || '(none)'}`,
    `writes ${(action.outputStateKeys || [])[0]}`,
    `status ${action.statusStateKey}`,
  ];
  if (action.kind === 'command' && action.feedback?.successMessageKey) {
    parts.push(`feedback keys ${action.feedback.successMessageKey} / ${action.feedback.errorMessageKey}`);
  }
  return parts.join('; ');
}

function zeroValue(field: ContractField): string {
  switch (field.type) {
    case 'string': return `''`;
    case 'number': return '0';
    case 'boolean': return 'false';
    case 'array': return '[]';
    case 'stringUnion': return `'${escapeSingle(field.firstLiteral ?? '')}'`;
  }
}

function defaultConstName(state: DefsState): string {
  return `${toConstCase(state.name)}_DEFAULT`;
}

function inputInterfaceOf(model: ScaffoldModel, commandName: string): ContractInterface {
  return model.interfaces.get(`${toPascalCase(commandName)}Input`) ?? bail(`contract interface ${toPascalCase(commandName)}Input not found`);
}

function outputInterfaceOf(model: ScaffoldModel, commandName: string): ContractInterface {
  return model.interfaces.get(`${toPascalCase(commandName)}Output`) ?? bail(`contract interface ${toPascalCase(commandName)}Output not found`);
}

/** Route expression for execBff: the contract route const when declared, else the routeKey literal. */
function routeExprOf(model: ScaffoldModel, action: DefsAction): string {
  const contract = model.contracts.find(c => c.commandName === action.commandRef);
  return contract ? contract.routeConst : `'${escapeSingle(action.routeKey!)}'`;
}

// ---------------------------------------------------------------------------
// Small utilities (local so the module stays import-free: the CLI runs it under plain tsx where
// the '/_102020_/...' alias does not resolve — same constraint as cfeMaterializeCore itself)

// Mirrors cfeMaterializeCore mlsHeaderForOutputPath/headerEnhancementForOutputPath — keep in sync.
function mlsHeaderForOutputPath(outputPath: string): string {
  return `/// <mls fileReference="${outputPath}" enhancement="${headerEnhancementForOutputPath(outputPath)}"/>`;
}

function headerEnhancementForOutputPath(outputPath: string): string {
  if (/^_\d+_\/l2\/[^/]+\/web\/shared\/[^/]+\.ts$/.test(outputPath)) return '_102020_/l2/enhancementAura';
  if (/^_\d+_\/l2\/[^/]+\/web\/(?:desktop|mobile)\/page\d+\/[^/]+\.ts$/.test(outputPath)) return '_102020_/l2/enhancementAura';
  return '_blank';
}

function aliasJsImport(mlsPath: string): string {
  const withJs = mlsPath.replace(/\.ts$/, '.js');
  return withJs.startsWith('/') ? withJs : `/${withJs}`;
}

function toPascalCase(value: string): string {
  return value.replace(/(?:^|[-_\s]+)([A-Za-z0-9])/g, (_m, c: string) => c.toUpperCase());
}

function toConstCase(value: string): string {
  return value.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toUpperCase();
}

function escapeSingle(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\r?\n/g, '\\n');
}

function stringOf(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
