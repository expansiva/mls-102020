/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentCfeCreatePage.ts" enhancement="_102027_/l2/enhancementAgent"/>

import { IAgentAsync, IAgentMeta } from '/_102027_/l2/aiAgentBase.js';
import {
  cfePageLayoutToolName,
  cfePageLayoutToolSchema,
  createPromptReadyIntent,
  createUpdateStatusIntent,
  extractCfePageLayoutOutput,
  parseCreatePageArgs,
  preparePageCreate,
  readCreateContext,
  saveContractDefs,
  savePageVariants,
} from '/_102020_/l2/agentChangeFrontend/cfeCreateShared.js';
import { skill as uxGuidanceSkill } from '/_102020_/l2/agentChangeFrontend/skills/uxGuidance.js';

const AGENT_NAME = 'agentCfeCreatePage';

export function createAgent(): IAgentAsync {
  return {
    agentName: 'agentCfeCreatePage',
    agentProject: 102020,
    agentFolder: 'agentChangeFrontend',
    agentDescription: 'Create contract/shared defs deterministically and page layout defs with LLM',
    visibility: 'private',
    beforePromptStep,
    afterPromptStep,
  };
}

async function beforePromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]> {
  try {
    consumeCreateDiagnostics();
    const { pageId } = parseCreatePageArgs(args || step.prompt);
    const createContext = await readCreateContext();
    const page = createContext.pages.find(item => item.pageId === pageId);
    if (!page) throw new Error(`page not found for create: ${pageId}`);
    const prepared = await preparePageCreate(page);
    await saveContractDefs(prepared);
    return [
      createPromptReadyIntent(
        context,
        parentStep,
        hookSequential,
        args || step.prompt || JSON.stringify({ pageId }),
        systemPrompt,
        `## Page selector\n${pageId}\n\n## Reduced L4 + contract/shared context\n${JSON.stringify(prepared.promptContext, null, 2)}\n`,
        cfePageLayoutToolSchema,
        cfePageLayoutToolName,
      ),
    ];
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`[${agent.agentName}] ${message}`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
  }
}

async function afterPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]> {
  try {
    consumeCreateDiagnostics();
    const { pageId } = parseCreatePageArgs(step.prompt);
    const payload = step.interaction?.payload?.[0];
    if (!payload) throw new Error('missing LLM payload');
    const output = extractCfePageLayoutOutput(payload);
    if (output.status !== 'ok') throw new Error(output.questions.join('; ') || `${AGENT_NAME} returned ${output.status}`);

    const createContext = await readCreateContext();
    const page = createContext.pages.find(item => item.pageId === pageId);
    if (!page) throw new Error(`page not found for layout save: ${pageId}`);
    const prepared = await preparePageCreate(page);
    await savePageVariants(prepared, output.result);
    const diagnostics = consumeCreateDiagnostics();
    const trace = diagnostics.length ? formatCreateDiagnostics(diagnostics) : undefined;
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace)];
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`[${agent.agentName}] ${message}`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
  }
}

function consumeCreateDiagnostics(): string[] {
  const w = window as any;
  const diagnostics = Array.isArray(w.__agentChangeFrontendCreateDiagnostics) ? w.__agentChangeFrontendCreateDiagnostics : [];
  w.__agentChangeFrontendCreateDiagnostics = [];
  return diagnostics.map(String);
}

function formatCreateDiagnostics(diagnostics: string[]): string {
  return `Warnings:\n${diagnostics.map(item => `- ${item}`).join('\n')}`;
}

const systemPrompt = `
<!-- modelType: codehigh -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME}, the page-layout agent for collab.codes Stage 2 frontend creation.

Create the semantic layout for ONE page. Produce exactly promptContext.variantPlan.length UX variant(s):
the primary in result.pageLayout (variantPlan[0], genome page11) and the rest in result.pageVariants
(variantPlan[1..], genomes page21, page31...). Call the "${cfePageLayoutToolName}" tool with
{ status, result, questions, trace }. Do not return prose.

Tool argument shape:
- status must be "ok".
- result contains { pageLayout } and, when promptContext.variantPlan has more than one entry, also { pageVariants }.
- result.pageLayout is the primary variant, built from variantPlan[0].templateId (genome page11).
- result.pageVariants has one entry { templateId, pageLayout } per remaining variantPlan entry, IN ORDER:
  pageVariants[i].templateId must equal variantPlan[i+1].templateId (genomes page21, page31...). Omit
  pageVariants when variantPlan has a single entry. Never reuse a templateId; never emit more entries
  than variantPlan defines.
- Build each variant strictly from ITS assigned template (that template's userJourney/layoutGuidance in
  promptContext.uxTemplateCandidates) so the variants are structurally distinct, not near-duplicates.
- Every pageVariants[].pageLayout has the same pageId, commands and fields as result.pageLayout; only the
  UX structure differs. Do not invent new commands/fields per variant.
- Every variant (result.pageLayout AND each pageVariants entry) must INDEPENDENTLY represent every
  operation: each operation must appear in at least one organism.userActions in that layout. A layout
  that omits an operation is rejected — do not split operations across variants.
- questions must be [] when there are no questions.
- trace must be [] when there is no trace to report.
- Do not put i18n or dataBindings beside result.pageLayout; keep them inside each pageLayout.

The result must preserve the section -> organism structure:
- result.pageLayout.sections[] is the source of truth for page sections.
- every section contains organisms[].
- every organism contains intentions[].
- keep compatibility fields sectionName, mode, organismName, userActions, requiredEntities,
  readsFields, writesFields and rulesApplied.

Layout rules:
- Stable ids are required for sections, organisms, intentions, fields, columns and actions.
- Every section must include sectionName.
- Prefer including result.pageLayout.i18n and result.pageLayout.dataBindings; use {} and [] when empty.
- result.pageLayout.i18n must be a flat object of "key": "localized text for the project default locale";
  do not hard-code locale keys in the shape and do not return empty strings.
- Before creating sections, read promptContext.userJourney. The PRIMARY ordering signal is userJourney.microUserFlow (derived from l4 story.steps): order fields, intentions and organisms to follow those user steps. Use operationsInOrder and recommendedStages as secondary structure.
- microUserFlow.operations[].steps is the intended intra-operation sequence (e.g. "select table" -> "add menu items" -> "confirm order"); order the command form fields to match it. microUserFlow.workflowSteps is the cross-operation sequence for workflow pages.
- If userJourney.isMultiStep is true, create distinct intentions for the stages instead of one generic form.
- For parent-child flows such as orders with items, a composed input (e.g. items[]) is a repeatable sub-form (add/remove lines) inside the SAME single submit command — never model a separate save for the child. Separate the parent/header fields, the repeatable item sub-form, totals/summary and the single confirm/submit action.
- Query/list/selection intentions should appear before dependent create/update/status command intentions when both exist.
- Use order numbers in increments of 10.
- Always include fields, columns, filters, toolbar, rowActions and actions arrays on every intention;
  use [] when a list is empty.
- Use plain page11 intentions such as "queryList", "commandForm", "summary", "workflowStatus",
  "actionList" or another short semantic intent.
- Do not reference molecule groups, molecule tags, web-component tags, DOM slots or package-specific component names.
- Use fields/columns/filters/action references only from the provided contract/shared context.
- Do not invent actions, entities, commands or payloads.
- The only legal BFF action values are shared.availableActions from the prompt. This applies to
  organism.userActions, intention.action, intention.submitAction, toolbar[].action, rowActions[].action
  and actions[].action.
- Use shared.baseStateKeys only when you need to reference an existing state explicitly.
- Do not invent stateKey values. If a layout element needs state and no shared.baseStateKeys entry fits,
  omit stateKey; the agent will reconcile page11 state references into shared after layout generation.
- Do not use UI-only action names such as select*, cancel, close, open, edit, view, remove or clear
  unless the exact name appears in shared.availableActions. Row selection and cancel/reset gestures
  should be represented as state/display intent or omitted, not as BFF actions.
- Treat all filters, form fields, selections, loaded data and action statuses as shared state.
- Do not describe local page variables; page11 will only render shared state and call shared handlers.
- Do not output HTML, CSS, web component slots, raw DOM or design-system implementation details.
- All visible text must be referenced by titleKey, labelKey or emptyKey and declared in i18n.
- Prefer useful operational layouts: list/search/table for query/view commands, form/action panel for
  create/update/delete commands, status/summary/action intentions for workflows.

## UX template selection
- promptContext.uxTemplateCandidates lists deterministically scored templates (highest score first).
  Pick the final structure from these candidates; do not invent a structure that a candidate's
  rejectsWhen forbids. Follow the chosen template's userJourney, layoutGuidance and validationChecks.
- The template defines structure; the guidance below defines how to fill the slots. When they
  conflict, the template wins.

${uxGuidanceSkill}
`;
