/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/scan/agentCfeCreateScanL4.test.ts" enhancement="_blank"/>

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

void test('agentCfeCreateScanL4 declares the scan step agent contract', () => {
  const src = readFileSync(path.join(HERE, 'agentCfeCreateScanL4.ts'), 'utf8');
  const flow = readFileSync(path.join(HERE, '..', '..', 'flow.json'), 'utf8');
  assert.match(src, /agentCfeCreateScanL4/);
  assert.match(src, /export function createAgent/);
  assert.match(src, /beforePromptStep/);
  assert.match(flow, /"agentName": "agentCfeCreateScanL4"/);
});

void test('T2: o step de materialize leva o módulo do comando', () => {
  const src = readFileSync(path.join(HERE, 'agentCfeCreateScanL4.ts'), 'utf8');
  assert.match(src, /function createMaterializeStep\(scanArgs: ScanArgs, dependsOn: string\[\], moduleName = ''\)/);
  assert.match(src, /createMaterializeStep\(scanArgs, \[\], requested \|\| sweepModule\)/);
  assert.match(src, /createMaterializeStep\(scanArgs, \['verify-create-layouts'\], runModule\)/);
});

void test('scan page-queue args carry moduleName', () => {
  const src = readFileSync(path.join(HERE, 'agentCfeCreateScanL4.ts'), 'utf8');
  assert.match(src, /JSON\.stringify\(cfeCreatePageArgs\(\{\s*moduleName:\s*page\.moduleName,\s*pageId:\s*page\.pageId,\s*runId\s*\}\)\)/);
  assert.doesNotMatch(src, /JSON\.stringify\(\{\s*pageId:\s*page\.pageId,\s*runId\s*\}\)/);
});

void test('scan records createContext.warnings as scan-warning and prints them on the step status', () => {
  const src = readFileSync(path.join(HERE, 'agentCfeCreateScanL4.ts'), 'utf8');
  assert.match(src, /recordCfeDegradation\(moduleName, 'scan-warning', warning\)/);
  assert.match(src, /recordScanWarnings\(sweepModule \|\| requested \|\| '', createContext\.warnings\)/);
  assert.match(src, /Warnings: \$\{warnings\.slice\(0, 8\)\.join\('; '\)\}/);
  assert.match(src, /\$\{orphanNote\}\$\{warningTrace\}/);
});
