<!-- mls fileReference="_102020_/l2/agentChangeFrontend/steps/finalize/CHANGELOG.md" enhancement="_blank" -->

# Changelog

- 2026-09-07: compile gate by capability. Monaco when `mls.l2.typescript.compile` exists (Studio
  path unchanged). Otherwise one `npx tsc -p tsconfig.frontend.json --noEmit`; diagnostics outside
  `l2/<module>/` are filtered. Missing compiler is `tscGate: 'unavailable'` — a state, never a
  clean compile. `compileAndGetErrors` returns `null` when Monaco is absent (`[]` still means
  compiled and clean). `cf-run.json` › `gate.path` / `gate.trace`; `runNN_changefrontend.json` ›
  `tscGate: 'ran' | 'unavailable'` (omitted on Monaco). Blocking policy unchanged
  (`MODULE-COMPILE-FAILED` after the existing repair rounds).

- 2026-09-07: `persistCfeRunSummary` splits `kind: 'scan-warning'` out of `degradations[]` into
  `scanWarnings[]` on `runNN_changefrontend.json` so an orphan/unparsable todo of another module
  stays informational (CB parity) and does not flip the verdict to `degraded`.

- 2026-08-26 (gates declaram) — closing gate still compiles `.test.ts` (detector stays loud) but
  those findings are `declared`, never `MODULE-COMPILE-FAILED`. Only shipped `.ts` errors block.

- 2026-08-22 (dossiê do último finalize) — o run fe4 gravou UM `cf-run-*.json`, do finalize que
  FALHOU (`repairRounds: 0`); o `finalize-create-r2` completou a task e não deixou arquivo. Quem
  lê o único dossiê conclui o oposto do que aconteceu. Causa: só havia snapshot com stamp, e o
  caminho limpo do r2 podia gravar (e o post-mortem não tinha como saber qual era o último). Agora
  todo finalize grava `attempt` + `final` + `repairRounds`, um snapshot com stamp E o estável
  `l4/<módulo>/trace/cf-run.json` (overwrite). O último finalize — sucesso ou orçamento esgotado —
  tem `final: true`; o que abre repair tem `final: false`. Monaco viu 1× TS2339 `confirmedAt` no
  primeiro e 0 dos 6 `serviceExecutionId` no segundo: mesma classe, import degradado a `any` (já
  declarado em `describeCompilerFidelity`; fora de escopo desta spec).

- 2026-07-30 (handoff @@addLanguage no fim da task) — o shared `.ts` gerado carrega UM catálogo de
  mensagens (o `defaultLocale` do módulo): `cfeSharedScaffold.renderI18n` emite um único
  `message_<default>` + `messages`. Um módulo que declara 2+ idiomas em `l4/<module>/module.defs.ts`
  ficava só com o default. O último step agora despacha uma
  mensagem `@@addLanguage <json>` — task INDEPENDENTE pelo `beforePromptImplicit` do próprio
  `agentAddLanguage` (mesmo handoff que o agentNewSolution usa para `@@changeBackend`/`@@changeFrontend`;
  o runtime remove a menção antes do agente ver o payload, `aiAgentOrchestration.ts:48`). Barato por
  construção: o agentAddLanguage manda só o bloco i18n de cada shared para um modelo `translate`
  (gpt-4.1-mini, ~$0.025/arquivo) — nada é regerado. Payload igual ao do plugin
  `aura/plugins/selectLanguage.ts`: `[{languages:[{code,name}],projectId,moduleName}]`, com o `name`
  caindo no próprio `code` quando o catálogo (`_102027_/l2/collabLanguages`) não o conhece.
  **Módulo com 1 idioma não gera task nenhuma** (`buildAddLanguageMessage` devolve null). O módulo sai
  das páginas efetivamente finalizadas (não de `context.moduleNames`, que lista todo o projeto) e os
  códigos são os `activeLocales` já normalizados (2 letras), que é a chave em que o bloco i18n indexa
  (`messages.pt`). Falha no despacho é traçada e NUNCA derruba a task (os artefatos já estão em disco;
  o trace mostra a mensagem para reenvio manual). Verificado: payload idêntico ao
 para o 102045 (en + pt-BR -> pt/Portuguese), null para
  módulo de 1 idioma, default nunca retraduzido, código desconhecido cai no code.

- 2026-07-13: documented the current finalize step boundary and moved `agentCfeCreateFinalize.ts` into this step folder.
