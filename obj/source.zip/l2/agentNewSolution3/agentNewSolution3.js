/// <mls fileReference="_102020_/l2/agentNewSolution3/agentNewSolution3.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { isRecord, listExistingModuleFolders, ns3PipelineArtifactFileInfo, parseMaybeJson, readJsonArtifact, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js';
import { readNs3Pipeline } from '/_102020_/l2/agentNewSolution3/helpers/ns3Pipeline.js';
export const NS3_PLAN_IDS = [
    'e1-clarification', 'e1-clarification-answer', 'e1-draft', 'checkpoint-draft', 'e2-journeys', 'checkpoint-journeys',
    'e3-ontology', 'e4-actors-rules-refs', 'e5-workflows-operations', 'e6-journey-map', 'e7-validation-summary',
];
export function createAgent() {
    return {
        agentName: 'agentNewSolution3',
        agentProject: 102020,
        agentFolder: 'agentNewSolution3',
        agentDescription: 'Spec-first step pipeline to create a module',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
        beforeClarificationStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const normalized = (userPrompt || '').trim();
    // Empty "@@newSolution3" (the runtime strips the mention) means resume the first module whose
    // Phase 1 is incomplete, so the user does not repeat the clarification they already answered.
    if (!normalized) {
        const resume = await findResumableNs3Module();
        if (resume)
            return [buildRootMessageAI(agent, context, resume.sourcePrompt, { resumeModule: resume.moduleName, resumeTarget: resume.target })];
    }
    return [buildRootMessageAI(agent, context, normalized || '(empty prompt)', {})];
}
function buildRootMessageAI(agent, context, content, extraMemory) {
    return {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt.replace('{{planIds}}', NS3_PLAN_IDS.join(', ')) },
                { type: 'human', content },
            ],
            taskTitle: 'newSolution3',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'newSolution3', flowName: 'agentNewSolution3', ...extraMemory },
        },
    };
}
// Scan modules in the active project and return the first one whose Phase 1 artifacts are not done.
// A step counts as done when it was approved or its last gate passed (the human checkpoint that
// freezes it is layered on top and does not change which step must run next).
async function findResumableNs3Module() {
    for (const moduleName of listExistingModuleFolders()) {
        const pipeline = await readNs3Pipeline(moduleName);
        if (!pipeline)
            continue;
        const target = resolveResumeTarget(pipeline);
        // Phase 1 resume currently re-enters at E2 only (E1 needs the clarification the fresh flow owns).
        if (target !== 'e2-journeys')
            continue;
        const draft = await readJsonArtifact(ns3PipelineArtifactFileInfo(moduleName, 'e1-draft', '.json'), false);
        if (!draft)
            continue;
        return { moduleName, sourcePrompt: readString(draft.sourcePrompt) || moduleName, target };
    }
    return null;
}
function resolveResumeTarget(pipeline) {
    const e1 = pipeline.steps['e1-draft'];
    const e2 = pipeline.steps['e2-journeys'];
    if (!e1 || !(e1.status === 'approved' || e1.lastGate?.ok))
        return 'e1-draft';
    if (!e2 || !(e2.status === 'approved' || e2.lastGate?.ok))
        return 'e2-journeys';
    return null;
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const rootPlan = normalizeRootPlan(step.interaction?.payload?.[0]);
        const resumeModule = readString(context.task?.iaCompressed?.longMemory?.resumeModule);
        if (resumeModule) {
            return buildResumeTree(resumeModule).map(resumeStep => ({
                type: 'add-step',
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: step.stepId,
                step: resumeStep,
            }));
        }
        const addSteps = buildPlannedTree(rootPlan, rootPlan.validPrompt).map(plannedStep => ({
            type: 'add-step',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: step.stepId,
            step: plannedStep,
        }));
        if (!rootPlan.validPrompt) {
            return [
                ...addSteps,
                updateStatus(context, parentStep, step, hookSequential, 'failed', rootPlan.invalidReason || 'Invalid or insufficient prompt.'),
            ];
        }
        return addSteps;
    }
    catch (error) {
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const parsed = parseStepJson(json);
    if (parsed.planId !== 'e1-clarification') {
        throw new Error(`[agentNewSolution3] unsupported clarification ${parsed.planId || '(missing)'}`);
    }
    await import('/_102025_/l2/widgetQuestionsForClarification.js');
    const rootPlan = getRootPlan(context);
    const clarification = rootPlan.clarification;
    const el = document.createElement('widget-questions-for-clarification-102025');
    el.value = {
        taskId: context.task?.PK || '',
        stepId: step.stepId,
        title: clarification.title,
        legends: clarification.legends,
        userLanguage: clarification.userLanguage,
        questions: clarification.questions,
    };
    el.setAttribute('mode', 'new');
    el.addEventListener('clarification-finish', (event) => {
        const detail = event.detail;
        void applyInitialClarification(context, parentStep, step, hookSequential, detail.value, detail.action);
    });
    return el;
}
function buildPlannedTree(plan, includePhase2) {
    const title = (planId) => getTitle(plan, planId);
    const phase1 = [
        agentStep('e1-clarification', 'agentNs3Draft', title('e1-clarification'), [], 'waiting_human_input'),
        agentStep('e1-draft', 'agentNs3Draft', title('e1-draft'), ['e1-clarification-answer'], 'waiting_dependency'),
        clarificationStep('checkpoint-draft', title('checkpoint-draft'), ['e1-draft'], { planId: 'checkpoint-draft' }, 'waiting_dependency'),
    ];
    if (!includePhase2)
        return phase1;
    return [
        ...phase1,
        agentStep('e2-journeys', 'agentNs3Journeys', title('e2-journeys'), ['checkpoint-draft'], 'waiting_dependency'),
        plannedStep('checkpoint-journeys', title('checkpoint-journeys'), ['e2-journeys']),
        plannedStep('e3-ontology', title('e3-ontology'), ['checkpoint-journeys']),
        plannedStep('e4-actors-rules-refs', title('e4-actors-rules-refs'), ['e3-ontology']),
        plannedStep('e5-workflows-operations', title('e5-workflows-operations'), ['e4-actors-rules-refs']),
        plannedStep('e6-journey-map', title('e6-journey-map'), ['e5-workflows-operations']),
        plannedStep('e7-validation-summary', title('e7-validation-summary'), ['e6-journey-map']),
    ];
}
function agentStep(planId, agentName, stepTitle, dependsOn, status) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        agentName,
        prompt: JSON.stringify({ planId }),
        rags: [],
        planning: { planId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
function clarificationStep(planId, stepTitle, dependsOn, json, status) {
    const jsonRecord = isRecord(json) ? json : {};
    return {
        type: 'clarification',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        json: JSON.stringify({ planId, ...jsonRecord }),
        planning: { planId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
function plannedStep(planId, stepTitle, dependsOn) {
    return {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: `${stepTitle} (planned)`,
        status: 'waiting_dependency',
        nextSteps: [],
        result: JSON.stringify({ planId, status: 'planned' }),
        planning: { planId, dependsOn, executionMode: 'manual_later', executionHost: 'client', plannedOnly: true },
    };
}
// Resume tree: a completed anchor plus the E2 agent step that depends on it. The agent resolves the
// module and reads e1-draft.json from disk, so no clarification/draft steps need to be rebuilt.
function buildResumeTree(moduleName) {
    const anchorPlanId = 'e2-resume-anchor';
    return [
        {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle: 'Resume Phase 1',
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify({ planId: anchorPlanId, moduleName, resumedTo: 'e2-journeys' }, null, 2),
            planning: { planId: anchorPlanId, dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
        },
        {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: defaultTitles['e2-journeys'],
            status: 'waiting_dependency',
            nextSteps: [],
            agentName: 'agentNs3Journeys',
            prompt: JSON.stringify({ planId: 'e2-journeys', moduleName }),
            rags: [],
            planning: { planId: 'e2-journeys', dependsOn: [anchorPlanId], executionMode: 'sequential', executionHost: 'client' },
        },
    ];
}
async function applyInitialClarification(context, parentStep, step, hookSequential, value, action) {
    if (!context.task)
        throw new Error('[agentNewSolution3] task invalid');
    const status = action === 'continue' ? 'completed' : 'failed';
    const intents = [updateStatus(context, parentStep, step, hookSequential, status)];
    if (action === 'continue') {
        const answer = normalizeClarificationAnswer(value);
        intents.unshift(resultStep(context, parentStep, 'e1-clarification-answer', ['e1-clarification'], answer.title, answer));
    }
    const response = await mls.api.msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200) {
        throw new Error(response?.msg || 'Error applying clarification');
    }
    const ret = response;
    context.task = ret.task;
    if (ret.message)
        context.message = ret.message;
    if (action === 'continue')
        await continuePoolingTask(context);
}
function resultStep(context, parentStep, planId, dependsOn, stepTitle, result) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify(result, null, 2),
            planning: { planId, dependsOn, executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
}
export function getRootPlan(context) {
    if (!context.task)
        throw new Error('[getRootPlan] task invalid');
    const root = getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.type === 'agent' && item.agentName === 'agentNewSolution3');
    const payload = root?.interaction?.payload?.[0];
    return normalizeRootPlan(payload);
}
export function getInitialClarificationAnswer(context) {
    const step = findStepByPlanId(context, 'e1-clarification-answer');
    if (!step?.result)
        return null;
    const parsed = parseMaybeJson(step.result);
    return isRecord(parsed) ? parsed : null;
}
function findStepByPlanId(context, planId) {
    if (!context.task)
        return null;
    return getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.planning?.planId === planId) || null;
}
function normalizeRootPlan(payload) {
    const parsed = parseMaybeJson(payload);
    const result = isRecord(parsed) && parsed.type === 'flexible' ? parseMaybeJson(parsed.result) : parsed;
    const record = isRecord(result) ? result : {};
    const prompt = readString(record.userPrompt) || '';
    const userLanguage = readString(record.userLanguage) || 'en';
    const titles = isRecord(record.titles) ? record.titles : {};
    const uiLabels = isRecord(record.uiLabels) ? record.uiLabels : {};
    return {
        userLanguage,
        validPrompt: record.validPrompt !== false && prompt.trim().length >= 5,
        userPrompt: prompt,
        invalidReason: readString(record.invalidReason),
        titles,
        uiLabels,
        clarification: normalizeClarification(record.clarification, userLanguage, titles['e1-clarification'], prompt),
    };
}
function normalizeClarification(value, userLanguage, title, userPrompt = '') {
    const record = isRecord(value) ? value : {};
    const fallbackQuestions = defaultQuestions(userLanguage, userPrompt);
    const rawQuestions = isRecord(record.questions) ? record.questions : fallbackQuestions;
    const questions = normalizeClarificationQuestions(rawQuestions, fallbackQuestions);
    return {
        userLanguage: readString(record.userLanguage) || userLanguage,
        title: readString(record.title) || title || 'Clarification 1',
        legends: Array.isArray(record.legends) ? record.legends.filter((item) => typeof item === 'string') : [],
        questions,
    };
}
function normalizeClarificationQuestions(rawQuestions, fallbackQuestions) {
    const normalized = {};
    for (const [key, fallback] of Object.entries(fallbackQuestions)) {
        const question = rawQuestions[key] || fallback;
        const text = readString(question.question) || fallback.question;
        const answer = question.answer === undefined || question.answer === '' ? fallback.answer : question.answer;
        normalized[key] = {
            ...question,
            type: question.type || fallback.type,
            question: text,
            answer,
            ...(question.options || fallback.options ? { options: question.options || fallback.options } : {}),
        };
    }
    for (const [key, question] of Object.entries(rawQuestions)) {
        if (normalized[key])
            continue;
        const text = readString(question.question) || key;
        normalized[key] = {
            ...question,
            type: question.type || 'open',
            question: text,
            answer: question.answer === undefined ? '' : question.answer,
        };
    }
    return normalized;
}
function normalizeClarificationAnswer(value) {
    return {
        title: value.title || 'Clarification 1',
        userLanguage: value.userLanguage || '',
        answers: Object.fromEntries(Object.entries(value.questions || {}).map(([key, question]) => [key, question.answer ?? ''])),
    };
}
function defaultQuestions(userLanguage, userPrompt = '') {
    const defaults = deriveClarificationDefaults(userPrompt, userLanguage);
    return {
        moduleName: { type: 'open', question: 'What short module name do you want?', answer: defaults.moduleName },
        mainActors: { type: 'open', question: 'Who uses this module day to day?', answer: defaults.mainActors },
        mainGoal: { type: 'open', question: 'What main outcome should this module deliver?', answer: defaults.mainGoal },
        boundaries: { type: 'open', question: 'What should stay out of this module for now?', answer: defaults.boundaries },
    };
}
function deriveClarificationDefaults(userPrompt, userLanguage) {
    const prompt = userPrompt.replace(/\s+/g, ' ').trim();
    const portuguese = prefersPortuguese(prompt, userLanguage);
    const moduleName = extractFirstMatch(prompt, [
        /(?:chamado|chamada|called|named)\s+["']?([A-Za-z][\w-]{1,48})/i,
        /(?:app|module|modulo|módulo|solucao|solução)\s+([A-Za-z][\w-]{1,48})/i,
    ]) || 'module';
    const mainGoal = extractSection(prompt, ['Foco:', 'Focus:', 'Objetivo:', 'Goal:']) || truncateText(prompt, 220);
    const mainActors = extractSection(prompt, ['Atores:', 'Actors:', 'Usuários:', 'Usuarios:', 'Users:'])
        || inferActorsFromPrompt(prompt, portuguese);
    const boundaries = extractSection(prompt, ['Fora de escopo:', 'Out of scope:', 'Limites:', 'Boundaries:'])
        || (portuguese
            ? 'Usar apenas o escopo de negócio descrito no prompt; adiar detalhes de implementação, banco de dados e layout para etapas posteriores.'
            : 'Use only the business scope described in the prompt; defer implementation details, database design, and page layout until later steps.');
    return { moduleName, mainActors, mainGoal, boundaries };
}
function inferActorsFromPrompt(prompt, portuguese) {
    const lower = prompt.toLowerCase();
    if (lower.includes('cafe') || lower.includes('café') || lower.includes('cafeteria') || lower.includes('lanchonete')) {
        return portuguese ? 'Atendente/operador de POS, equipe de cozinha e gestor da loja.' : 'Attendant/POS operator, kitchen staff, and store manager.';
    }
    return portuguese ? 'Principais usuários de negócio descritos no prompt.' : 'Primary business users described by the prompt.';
}
function prefersPortuguese(prompt, userLanguage) {
    const text = `${userLanguage} ${prompt}`.toLowerCase();
    return text.includes('pt-br') || text.includes('portugu') || text.includes('módulo') || text.includes('solução');
}
function extractFirstMatch(text, patterns) {
    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1])
            return match[1].trim();
    }
    return undefined;
}
function extractSection(text, labels) {
    for (const label of labels) {
        const index = text.toLowerCase().indexOf(label.toLowerCase());
        if (index < 0)
            continue;
        const after = text.slice(index + label.length).trim();
        const stop = after.search(/\s(?:Entidades principais|Telas chave|Funcionalidade LLM|Foco|Entities|Screens|Key screens|LLM feature|Focus|linguagem|language):/i);
        return truncateText((stop >= 0 ? after.slice(0, stop) : after).trim(), 240);
    }
    return undefined;
}
function truncateText(text, maxLength) {
    const clean = text.trim();
    if (clean.length <= maxLength)
        return clean;
    return `${clean.slice(0, maxLength - 1).trim()}...`;
}
function getTitle(plan, planId) {
    const custom = plan.titles?.[planId];
    if (typeof custom === 'string' && custom.trim().length > 0 && custom.trim().length < 140)
        return custom.trim();
    return defaultTitles[planId];
}
function parseStepJson(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
const defaultTitles = {
    'e1-clarification': 'Clarify the initial request',
    'e1-clarification-answer': 'Initial clarification answer',
    'e1-draft': 'Draft understanding',
    'checkpoint-draft': 'Approve draft', 'e2-journeys': 'Map journeys and features',
    'checkpoint-journeys': 'Approve journeys', 'e3-ontology': 'Plan ontology',
    'e4-actors-rules-refs': 'Plan actors, rules and references',
    'e5-workflows-operations': 'Plan workflows and operations',
    'e6-journey-map': 'Consolidate journey map', 'e7-validation-summary': 'Validate and summarize',
};
const systemPrompt = `
<!-- modelType: codefast -->

Initialize collab.codes agentNewSolution3. Validate whether the prompt asks for a business module or
solution. Use the user's language for visible titles and clarification questions.

Return JSON only: { "type": "flexible", "result": { "userLanguage": "pt-BR|en|...", "validPrompt":
true, "invalidReason": "", "userPrompt": "...", "titles": { "plan id": "localized title" },
"uiLabels": { "draftTitle": "", "approve": "", "adjust": "", "adjustmentPlaceholder": "",
"approving": "", "adjusting": "", "approved": "", "loading": "", "noDraft": "", "gateOk": "",
"gateFailed": "", "adjustDraftStepTitle": "", "blockingClarificationTitle": "" },
"clarification": { "userLanguage": "...", "title": "Clarification 1", "legends": ["..."],
"questions": { "moduleName": { "type": "open", "question": "", "answer": "" }, "mainActors":
{ "type": "open", "question": "", "answer": "" }, "mainGoal": { "type": "open", "question": "",
"answer": "" }, "boundaries": { "type": "open", "question": "", "answer": "" } } } } }

Rules: invalid/vague prompts set validPrompt=false and invalidReason, but still produce clarification.
Include titles for these plan ids and UI labels in the user's language. Do not invent dependencies or
phase-2 executable agents. Do not ask architecture, ontology, page, database or workflow questions in
clarification 1. Every clarification question must include a visible, useful default answer derived
from the user's prompt; use an empty answer only when the prompt provides no safe default.

{{planIds}}
`;
