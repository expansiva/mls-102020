/// <mls fileReference="_102020_/l2/agentNewSolution3/steps/e2-journeys/gate.ts" enhancement="_blank"/>
import { errorIssue, warningIssue, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Gate.js';
import { collectDuplicateIds, normalizeModuleFolderName, normalizeNs3Id, uniqueNs3Id, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Ids.js';
export const E2_JOURNEYS_SCHEMA_VERSION = '2026-07-06-ns3-e2-v1';
const PRIORITIES = ['now', 'soon', 'later', 'never'];
const DECISION_KINDS = ['actorRemoved', 'featurePriority', 'scopeChange', 'other'];
export function prepareE2JourneysArtifact(input, options = {}) {
    const record = asRecord(input, 'artifact');
    const usedActors = new Set();
    const usedJourneys = new Set();
    const usedFeatures = new Set();
    const usedDecisions = new Set();
    const actors = readArray(record.actors).map((item, index) => {
        const actor = asRecord(item, `actors[${index}]`);
        const name = readString(actor.name) || readString(actor.actorId) || `Actor ${index + 1}`;
        const normalized = {
            actorId: uniqueNs3Id(actor.actorId || name, usedActors, `actor${index + 1}`),
            name,
        };
        const description = readString(actor.description);
        if (description)
            normalized.description = description;
        return normalized;
    });
    const features = readArray(record.features).map((item, index) => {
        const feature = asRecord(item, `features[${index}]`);
        const title = readString(feature.title) || readString(feature.featureId) || `Feature ${index + 1}`;
        const normalized = {
            featureId: uniqueNs3Id(feature.featureId || title, usedFeatures, `feature${index + 1}`),
            title,
            priority: normalizePriority(feature.priority),
            actorIds: readArray(feature.actorIds).map(actor => normalizeNs3Id(actor, 'actor')).filter(Boolean),
        };
        const description = readString(feature.description);
        if (description)
            normalized.description = description;
        const rationale = readString(feature.rationale);
        if (rationale)
            normalized.rationale = rationale;
        return normalized;
    });
    const journeys = readArray(record.journeys).map((item, index) => {
        const journey = asRecord(item, `journeys[${index}]`);
        const usedSteps = new Set();
        const title = readString(journey.title) || `Journey ${index + 1}`;
        const steps = readArray(journey.steps).map((rawStep, stepIndex) => {
            const step = asRecord(rawStep, `journeys[${index}].steps[${stepIndex}]`);
            const stepTitle = readString(step.title) || `Step ${stepIndex + 1}`;
            const normalizedStep = {
                stepId: uniqueNs3Id(step.stepId || stepTitle, usedSteps, `step${stepIndex + 1}`),
                title: stepTitle,
                intent: readString(step.intent) || stepTitle,
                featureRefs: readArray(step.featureRefs).map(ref => normalizeNs3Id(ref, 'feature')).filter(Boolean),
            };
            const result = readString(step.result);
            if (result)
                normalizedStep.result = result;
            return normalizedStep;
        });
        const normalized = {
            journeyId: uniqueNs3Id(journey.journeyId || title, usedJourneys, `journey${index + 1}`),
            actorId: normalizeNs3Id(journey.actorId, 'actor'),
            title,
            goal: readString(journey.goal) || 'Goal not described.',
            steps,
            outcome: readString(journey.outcome) || 'Outcome not described.',
            businessRules: readArray(journey.businessRules).map(rule => readString(rule)).filter((rule) => !!rule),
            notes: readString(journey.notes) || '',
        };
        const soThat = readString(journey.soThat);
        if (soThat)
            normalized.soThat = soThat;
        const trigger = readString(journey.trigger);
        if (trigger)
            normalized.trigger = trigger;
        return normalized;
    });
    const decisions = readArray(record.decisions).map((item, index) => {
        const decision = asRecord(item, `decisions[${index}]`);
        const normalized = {
            decisionId: uniqueNs3Id(decision.decisionId || decision.summary, usedDecisions, `decision${index + 1}`),
            kind: normalizeDecisionKind(decision.kind),
            summary: readString(decision.summary) || 'Decision not described.',
        };
        const target = readString(decision.target);
        if (target)
            normalized.target = target;
        return normalized;
    });
    return {
        schemaVersion: E2_JOURNEYS_SCHEMA_VERSION,
        moduleName: normalizeModuleFolderName(record.moduleName),
        moduleTitle: readString(record.moduleTitle) || humanizeModuleName(normalizeModuleFolderName(record.moduleName)),
        userLanguage: readString(record.userLanguage) || 'en',
        version: normalizeVersion(record.version),
        actors,
        journeys,
        features,
        decisions,
        createdAt: readString(record.createdAt) || new Date().toISOString(),
    };
}
export function validateE2JourneysInvariants(artifact, options = {}) {
    const issues = [];
    const normalizedModuleName = normalizeModuleFolderName(artifact.moduleName);
    if (artifact.moduleName !== normalizedModuleName) {
        issues.push(errorIssue('module_name_not_normalized', `moduleName must be ${normalizedModuleName}`, 'moduleName'));
    }
    const duplicateActors = collectDuplicateIds(artifact.actors.map(actor => actor.actorId));
    if (duplicateActors.length > 0)
        issues.push(errorIssue('duplicate_actor_ids', `duplicated actors: ${duplicateActors.join(', ')}`, 'actors'));
    const duplicateJourneys = collectDuplicateIds(artifact.journeys.map(journey => journey.journeyId));
    if (duplicateJourneys.length > 0)
        issues.push(errorIssue('duplicate_journey_ids', `duplicated journeys: ${duplicateJourneys.join(', ')}`, 'journeys'));
    const duplicateFeatures = collectDuplicateIds(artifact.features.map(feature => feature.featureId));
    if (duplicateFeatures.length > 0)
        issues.push(errorIssue('duplicate_feature_ids', `duplicated features: ${duplicateFeatures.join(', ')}`, 'features'));
    const actorIds = new Set(artifact.actors.map(actor => actor.actorId));
    const featureIds = new Set(artifact.features.map(feature => feature.featureId));
    const referencedFeatures = new Set();
    artifact.journeys.forEach((journey, index) => {
        if (!actorIds.has(journey.actorId)) {
            issues.push(errorIssue('unknown_journey_actor', `journey ${journey.journeyId} references unknown actor ${journey.actorId}`, `journeys[${index}].actorId`));
        }
        const duplicateSteps = collectDuplicateIds(journey.steps.map(step => step.stepId));
        if (duplicateSteps.length > 0)
            issues.push(errorIssue('duplicate_step_ids', `journey ${journey.journeyId} has duplicated steps: ${duplicateSteps.join(', ')}`, `journeys[${index}].steps`));
        journey.steps.forEach((step, stepIndex) => {
            step.featureRefs.forEach(ref => {
                referencedFeatures.add(ref);
                if (!featureIds.has(ref)) {
                    issues.push(errorIssue('dangling_feature_ref', `journey ${journey.journeyId} step ${step.stepId} references unknown feature ${ref}`, `journeys[${index}].steps[${stepIndex}].featureRefs`));
                }
            });
        });
    });
    const journeyActorIds = new Set(artifact.journeys.map(journey => journey.actorId));
    artifact.actors.forEach((actor, index) => {
        if (!journeyActorIds.has(actor.actorId)) {
            issues.push(errorIssue('actor_without_journey', `actor ${actor.actorId} has no journey`, `actors[${index}]`));
        }
    });
    artifact.features.forEach((feature, index) => {
        if (!PRIORITIES.includes(feature.priority)) {
            issues.push(errorIssue('feature_priority', `feature ${feature.featureId} must have a priority (now|soon|later|never)`, `features[${index}].priority`));
        }
        if (!referencedFeatures.has(feature.featureId)) {
            issues.push(errorIssue('unreferenced_feature', `feature ${feature.featureId} is not referenced by any journey step`, `features[${index}]`));
        }
    });
    const removedActors = new Set(artifact.decisions.filter(decision => decision.kind === 'actorRemoved').map(decision => normalizeNs3Id(decision.target, 'actor')));
    for (const e1ActorId of Array.from(options.e1ActorIds || []).map(id => normalizeNs3Id(id, 'actor'))) {
        if (!actorIds.has(e1ActorId) && !removedActors.has(e1ActorId)) {
            issues.push(errorIssue('missing_e1_actor', `E1 actor ${e1ActorId} is missing; keep it or record an actorRemoved decision`, 'actors'));
        }
    }
    if (artifact.journeys.length === 0)
        issues.push(warningIssue('empty_journeys', 'no journeys were produced', 'journeys'));
    return { artifact, issues, needsHumanInput: false };
}
export function renderE2JourneysMarkdown(artifact) {
    const featureById = new Map(artifact.features.map(feature => [feature.featureId, feature]));
    const lines = [
        `# ${artifact.moduleTitle} - Journeys and Features`,
        '',
        `Module: \`${artifact.moduleName}\``,
        `Language: ${artifact.userLanguage}`,
        `Version: v${artifact.version}`,
        '',
        '## Journeys by Actor',
    ];
    for (const actor of artifact.actors) {
        const actorJourneys = artifact.journeys.filter(journey => journey.actorId === actor.actorId);
        lines.push('', `### ${actor.name} (\`${actor.actorId}\`)`);
        if (actor.description)
            lines.push(actor.description);
        if (actorJourneys.length === 0) {
            lines.push('- No journeys.');
            continue;
        }
        for (const journey of actorJourneys) {
            lines.push('', `#### ${journey.title} (\`${journey.journeyId}\`)`);
            lines.push(`- Goal: ${journey.goal}`);
            if (journey.soThat)
                lines.push(`- So that: ${journey.soThat}`);
            if (journey.trigger)
                lines.push(`- Trigger: ${journey.trigger}`);
            lines.push('- Steps:');
            journey.steps.forEach((step, index) => {
                const refs = step.featureRefs.map(ref => featureById.get(ref)?.title || ref).join(', ');
                lines.push(`  ${index + 1}. ${step.title} - ${step.intent}${refs ? ` _(features: ${refs})_` : ''}`);
            });
            lines.push(`- Outcome: ${journey.outcome}`);
            if (journey.businessRules.length) {
                lines.push('- Business rules:');
                journey.businessRules.forEach(rule => lines.push(`  - ${rule}`));
            }
            if (journey.notes)
                lines.push(`- Notes: ${journey.notes}`);
        }
    }
    lines.push('', '## Feature Catalog');
    for (const priority of PRIORITIES) {
        const featuresForPriority = artifact.features.filter(feature => feature.priority === priority);
        if (featuresForPriority.length === 0)
            continue;
        lines.push('', `### ${priority}`);
        featuresForPriority.forEach(feature => {
            const actors = feature.actorIds.join(', ');
            lines.push(`- ${feature.title} (\`${feature.featureId}\`)${feature.description ? `: ${feature.description}` : ''}${actors ? ` [${actors}]` : ''}`);
        });
    }
    if (artifact.decisions.length) {
        lines.push('', '## Decisions');
        artifact.decisions.forEach(decision => lines.push(`- [${decision.kind}] ${decision.summary}${decision.target ? ` (${decision.target})` : ''}`));
    }
    lines.push('');
    return `${lines.join('\n')}\n`;
}
function normalizePriority(value) {
    return PRIORITIES.includes(value) ? value : 'later';
}
function normalizeDecisionKind(value) {
    return DECISION_KINDS.includes(value) ? value : 'other';
}
function normalizeVersion(value) {
    return typeof value === 'number' && Number.isInteger(value) && value >= 1 ? value : 1;
}
function asRecord(value, path, allowEmpty = false) {
    if (typeof value === 'object' && value !== null && !Array.isArray(value))
        return value;
    if (allowEmpty)
        return {};
    throw new Error(`${path} must be an object`);
}
function readArray(value) {
    return Array.isArray(value) ? value : [];
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
function humanizeModuleName(moduleName) {
    const spaced = moduleName.replace(/([a-z0-9])([A-Z])/g, '$1 $2');
    return spaced.slice(0, 1).toUpperCase() + spaced.slice(1);
}
