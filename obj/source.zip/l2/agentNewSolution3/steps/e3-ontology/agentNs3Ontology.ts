/// <mls fileReference="_102020_/l2/agentNewSolution3/steps/e3-ontology/agentNs3Ontology.ts" enhancement="_102027_/l2/enhancementAgent"/>

// E3 — ontology. Two kinds of runs handled by ONE agent (single maintenance unit):
// - planId "e3-ontology": the PLAN call. Reads e2-journeys.json (+ e1-draft.json), produces
//   e3-model.json (module block + slim entity index + relationships) and starts the item chain.
// - planId "e3-entity": one ITEM call per entity (sequential chain). Produces the canonical
//   l4/{module}/ontology/{EntityId}.defs.ts. The LAST item writes e3-ontology.md, approves the
//   pipeline step and emits the completed "e3-done" anchor result that unlocks E4.
// Retry = 1 per run, with the gate error in context (dynamic "-retry" step). No LLM critic.

import { IAgentAsync, IAgentMeta } from '/_102027_/l2/aiAgentBase.js';
import {
  isRecord,
  NS3_AGENT_FOLDER,
  ns3L2File,
  ns3PipelineArtifactFileInfo,
  parseMaybeJson,
  readJsonArtifact,
  readStorText,
  writeDefsArtifact,
  writeJsonArtifact,
  writeMarkdownArtifact,
} from '/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution3/helpers/ns3Ids.js';
import { runNs3Gate } from '/_102020_/l2/agentNewSolution3/helpers/ns3Gate.js';
import {
  buildNs3ToolInstruction,
  createNs3ToolSchema,
  extractNs3ToolOutput,
} from '/_102020_/l2/agentNewSolution3/helpers/ns3Llm.js';
import {
  ns3AgentStepIntent,
  ns3FindMutableParentStep,
  ns3ResultStepIntent,
  ns3UpdateStatusIntent,
} from '/_102020_/l2/agentNewSolution3/helpers/ns3Steps.js';
import {
  approveNs3Step,
  createNs3Pipeline,
  markNs3StepRunning,
  readNs3Pipeline,
  writeNs3Pipeline,
} from '/_102020_/l2/agentNewSolution3/helpers/ns3Pipeline.js';
import { writeNs3Trace } from '/_102020_/l2/agentNewSolution3/helpers/ns3Trace.js';
import { Ns3E2JourneysArtifact } from '/_102020_/l2/agentNewSolution3/steps/e2-journeys/gate.js';
import {
  Ns3E3EntityArtifact,
  Ns3E3ModelArtifact,
  prepareE3EntityArtifact,
  prepareE3ModelArtifact,
  renderE3OntologyMarkdown,
  validateE3EntityInvariants,
  validateE3ModelInvariants,
} from '/_102020_/l2/agentNewSolution3/steps/e3-ontology/gate.js';

const AGENT_NAME = 'agentNs3Ontology';
const STEP_ID = 'e3-ontology';
const DONE_ANCHOR = 'e3-done';
const MODEL_TOOL = 'submitNs3Model';
const ENTITY_TOOL = 'submitNs3Entity';
const STEP_FOLDER = `${NS3_AGENT_FOLDER}/steps/e3-ontology`;

export function createAgent(): IAgentAsync {
  return {
    agentName: AGENT_NAME,
    agentProject: 102020,
    agentFolder: STEP_FOLDER,
    agentDescription: 'E3 - ontology plan and per-entity generation for agentNewSolution3',
    visibility: 'private',
    beforePromptStep,
    afterPromptStep,
  };
}

interface E3Args {
  planId?: string;
  moduleName?: string;
  entityId?: string;
  entityIndex?: number;
  retryAttempt?: number;
  retryContext?: string;
}

async function beforePromptStep(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  args?: string,
): Promise<mls.msg.AgentIntent[]> {
  if (!context.task) throw new Error(`[${AGENT_NAME}] task invalid`);
  const hookArgs = args || step.prompt || JSON.stringify({ planId: STEP_ID });
  const parsedArgs = parseE3Args(hookArgs);

  if (parsedArgs.planId === 'e3-entity') return [await buildEntityPrompt(context, parentStep, hookSequential, parsedArgs, hookArgs)];
  return [await buildModelPrompt(context, parentStep, hookSequential, parsedArgs, hookArgs)];
}

async function buildModelPrompt(
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  hookSequential: number,
  parsedArgs: E3Args,
  hookArgs: string,
): Promise<mls.msg.AgentIntentPromptReady> {
  const moduleName = await resolveE3Module(parsedArgs.moduleName);
  const journeys = await readJsonArtifact<Ns3E2JourneysArtifact>(ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), true);
  if (!journeys) throw new Error(`[${AGENT_NAME}] e2-journeys.json not found for ${moduleName}`);
  const draft = await readJsonArtifact<Record<string, unknown>>(ns3PipelineArtifactFileInfo(moduleName, 'e1-draft', '.json'), false);

  const schema = await readE3Schema('e3-model.schema');
  const platform = await readNs3Text('skills', 'platform', '.md', true);
  const prompt = await readNs3Text('steps/e3-ontology', 'prompt', '.md', true);
  const humanPrompt = [
    '## E2 journeys (frozen, primary source)',
    JSON.stringify(journeys, null, 2),
    '',
    draft ? `## E1 draft (context)\n${JSON.stringify(draft, null, 2)}\n` : '',
    parsedArgs.retryContext ? `## Gate retry context (fix exactly these problems)\n${parsedArgs.retryContext}\n` : '',
  ].filter(Boolean).join('\n');

  return {
    type: 'prompt_ready',
    args: hookArgs,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || '',
    hookSequential,
    parentStepId: parentStep.stepId,
    systemPrompt: `${prompt.split('{{toolName}}').join(MODEL_TOOL)}\n\n${platform}\n\n${buildNs3ToolInstruction(MODEL_TOOL, 'the E2 journeys artifact is missing or unusable')}`,
    humanPrompt,
    tools: [createNs3ToolSchema(MODEL_TOOL, 'Submit the E3 ontology model plan.', schema)],
    toolChoice: { type: 'function', function: { name: MODEL_TOOL } },
  } as mls.msg.AgentIntentPromptReady;
}

async function buildEntityPrompt(
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  hookSequential: number,
  parsedArgs: E3Args,
  hookArgs: string,
): Promise<mls.msg.AgentIntentPromptReady> {
  const moduleName = normalizeModuleFolderName(parsedArgs.moduleName || '');
  const model = await readJsonArtifact<Ns3E3ModelArtifact>(ns3PipelineArtifactFileInfo(moduleName, 'e3-model', '.json'), true);
  if (!model) throw new Error(`[${AGENT_NAME}] e3-model.json not found for ${moduleName}`);
  const target = model.entities.find(entity => entity.entityId === parsedArgs.entityId);
  if (!target) throw new Error(`[${AGENT_NAME}] entity ${parsedArgs.entityId} not found in e3-model.json`);
  const journeys = await readJsonArtifact<Ns3E2JourneysArtifact>(ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), true);

  const schema = await readE3Schema('e3-entity.schema');
  const prompt = await readNs3Text('steps/e3-ontology', 'promptEntity', '.md', true);
  const relationships = model.relationships.filter(rel => rel.fromEntity === target.entityId || rel.toEntity === target.entityId);
  const relatedJourneys = (journeys?.journeys || []).filter(journey =>
    !target.sourceRefs?.journeyIds?.length || target.sourceRefs.journeyIds.includes(journey.journeyId));
  const businessRules = relatedJourneys.flatMap(journey => journey.businessRules || []);

  const humanPrompt = [
    `## Target entity (from e3-model.json)`,
    JSON.stringify(target, null, 2),
    '',
    '## All entity ids (valid reference field types)',
    model.entities.map(entity => entity.entityId).join(', '),
    '',
    '## Relationships touching this entity',
    JSON.stringify(relationships, null, 2),
    '',
    '## Business rules from related journeys (source for status/enums/invariant fields)',
    businessRules.length ? businessRules.map(rule => `- ${rule}`).join('\n') : '(none)',
    '',
    `## userLanguage: ${model.userLanguage}`,
    parsedArgs.retryContext ? `\n## Gate retry context (fix exactly these problems)\n${parsedArgs.retryContext}\n` : '',
  ].filter(Boolean).join('\n');

  return {
    type: 'prompt_ready',
    args: hookArgs,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || '',
    hookSequential,
    parentStepId: parentStep.stepId,
    systemPrompt: `${prompt.split('{{toolName}}').join(ENTITY_TOOL)}\n\n${buildNs3ToolInstruction(ENTITY_TOOL, 'the target entity is missing from the model')}`,
    humanPrompt,
    tools: [createNs3ToolSchema(ENTITY_TOOL, 'Submit one canonical ontology entity definition.', schema)],
    toolChoice: { type: 'function', function: { name: ENTITY_TOOL } },
  } as mls.msg.AgentIntentPromptReady;
}

async function afterPromptStep(
  agent: IAgentMeta,
  context: mls.msg.ExecutionContext,
  parentStep: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
): Promise<mls.msg.AgentIntent[]> {
  const mutationParent = ns3FindMutableParentStep(context, parentStep);
  const parsedArgs = parseE3Args(step.prompt);
  try {
    if (parsedArgs.planId === 'e3-entity') return await handleEntityResult(context, mutationParent, step, hookSequential, parsedArgs);
    return await handleModelResult(context, mutationParent, step, hookSequential, parsedArgs);
  } catch (error) {
    const traceMsg = error instanceof Error ? error.message : String(error);
    if (parsedArgs.moduleName) {
      await writeNs3Trace(normalizeModuleFolderName(parsedArgs.moduleName), STEP_ID, AGENT_NAME, parsedArgs.retryAttempt || 1, { stepId: step.stepId }, traceMsg);
    }
    return [ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', traceMsg)];
  }
}

async function handleModelResult(
  context: mls.msg.ExecutionContext,
  mutationParent: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  parsedArgs: E3Args,
): Promise<mls.msg.AgentIntent[]> {
  const moduleName = await resolveE3Module(parsedArgs.moduleName);
  const journeys = await readJsonArtifact<Ns3E2JourneysArtifact>(ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), true);
  if (!journeys) throw new Error(`[${AGENT_NAME}] e2-journeys.json not found for ${moduleName}`);

  const output = extractNs3ToolOutput(step.interaction?.payload?.[0], MODEL_TOOL);
  if (output.status === 'failed') {
    return [ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', output.trace.join('\n') || 'E3 model returned failed')];
  }

  const artifact = prepareE3ModelArtifact(output.result, { moduleName, userLanguage: journeys.userLanguage });
  const gateContext = {
    moduleName,
    userLanguage: journeys.userLanguage,
    e2FeatureIds: journeys.features.map(feature => feature.featureId),
    e2JourneyIds: journeys.journeys.map(journey => journey.journeyId),
    e2NonNeverFeatureIds: journeys.features.filter(feature => feature.priority !== 'never').map(feature => feature.featureId),
  };
  const schema = await readE3Schema('e3-model.schema');
  let pipeline = await readNs3Pipeline(moduleName) || createNs3Pipeline(moduleName);
  pipeline = markNs3StepRunning(pipeline, STEP_ID, { e2CreatedAt: journeys.createdAt, retryContext: parsedArgs.retryContext || '' });
  const gate = await runNs3Gate({
    stepId: STEP_ID,
    schema,
    artifact,
    inputs: { e2CreatedAt: journeys.createdAt },
    pipeline,
    validate: item => validateE3ModelInvariants(item, gateContext),
  });
  if (gate.pipeline) pipeline = gate.pipeline;
  await writeNs3Pipeline(pipeline);
  await writeJsonArtifact(ns3PipelineArtifactFileInfo(moduleName, 'e3-model', '.json'), artifact);

  const attempt = parsedArgs.retryAttempt || gate.attempts;
  if (!gate.ok) {
    const traceMsg = gate.errors.map(issue => `${issue.code}: ${issue.message}`).join('\n');
    await writeNs3Trace(moduleName, STEP_ID, AGENT_NAME, attempt, { artifact, gate, retryContext: gate.retryContext }, traceMsg);
    const intents: mls.msg.AgentIntent[] = [ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', traceMsg)];
    if (attempt < 2) {
      intents.unshift(ns3AgentStepIntent(context, mutationParent, {
        agentName: AGENT_NAME,
        stepTitle: 'Retry E3 model gate',
        planId: `e3-ontology-retry-${Date.now()}`,
        prompt: { planId: STEP_ID, moduleName, retryAttempt: 2, retryContext: gate.retryContext || traceMsg },
      }));
    }
    return intents;
  }

  await writeNs3Trace(moduleName, STEP_ID, AGENT_NAME, attempt, { artifact, gate });
  // Chain start: first entity item BEFORE completing this step (parent auto-completion rule).
  return [
    buildEntityStepIntent(context, mutationParent, moduleName, artifact, 0),
    ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', `e3-model ready for ${moduleName} (${artifact.entities.length} entities)`),
  ];
}

async function handleEntityResult(
  context: mls.msg.ExecutionContext,
  mutationParent: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  parsedArgs: E3Args,
): Promise<mls.msg.AgentIntent[]> {
  const moduleName = normalizeModuleFolderName(parsedArgs.moduleName || '');
  const model = await readJsonArtifact<Ns3E3ModelArtifact>(ns3PipelineArtifactFileInfo(moduleName, 'e3-model', '.json'), true);
  if (!model) throw new Error(`[${AGENT_NAME}] e3-model.json not found for ${moduleName}`);
  const entityIndex = parsedArgs.entityIndex ?? 0;

  const output = extractNs3ToolOutput(step.interaction?.payload?.[0], ENTITY_TOOL);
  if (output.status === 'failed') {
    return [ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', output.trace.join('\n') || 'E3 entity returned failed')];
  }

  const artifact = prepareE3EntityArtifact({ ...output.result, entityId: parsedArgs.entityId || output.result.entityId });
  const schema = await readE3Schema('e3-entity.schema');
  const gate = await runNs3Gate({
    stepId: STEP_ID,
    schema,
    artifact,
    validate: item => validateE3EntityInvariants(item, { model }),
  });

  const attempt = parsedArgs.retryAttempt || gate.attempts;
  if (!gate.ok) {
    const traceMsg = gate.errors.map(issue => `${issue.code}: ${issue.message}`).join('\n');
    await writeNs3Trace(moduleName, `e3-entity-${artifact.entityId}`, AGENT_NAME, attempt, { artifact, gate, retryContext: gate.retryContext }, traceMsg);
    const intents: mls.msg.AgentIntent[] = [ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', traceMsg)];
    if (attempt < 2) {
      intents.unshift(ns3AgentStepIntent(context, mutationParent, {
        agentName: AGENT_NAME,
        stepTitle: `Retry entity ${artifact.entityId}`,
        planId: `e3-entity-retry-${Date.now()}`,
        prompt: { planId: 'e3-entity', moduleName, entityId: artifact.entityId, entityIndex, retryAttempt: 2, retryContext: gate.retryContext || traceMsg },
      }));
    }
    return intents;
  }

  await writeDefsArtifact(
    { project: mls.actualProject || 0, level: 4, folder: `${moduleName}/ontology`, shortName: artifact.entityId, extension: '.ts' },
    `${moduleName}Entity${artifact.entityId}`,
    artifact,
  );
  await writeNs3Trace(moduleName, `e3-entity-${artifact.entityId}`, AGENT_NAME, attempt, { artifact, gate });

  const nextIndex = entityIndex + 1;
  if (nextIndex < model.entities.length) {
    return [
      buildEntityStepIntent(context, mutationParent, moduleName, model, nextIndex),
      ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', `${artifact.entityId} defs saved`),
    ];
  }
  return finalizeE3(context, mutationParent, step, hookSequential, moduleName, model);
}

// Last item: index markdown, pipeline approval and the completed 'e3-done' anchor.
async function finalizeE3(
  context: mls.msg.ExecutionContext,
  mutationParent: mls.msg.AIAgentStep,
  step: mls.msg.AIAgentStep,
  hookSequential: number,
  moduleName: string,
  model: Ns3E3ModelArtifact,
): Promise<mls.msg.AgentIntent[]> {
  const entities: Ns3E3EntityArtifact[] = [];
  for (const modelEntity of model.entities) {
    const saved = await readJsonDefs<Ns3E3EntityArtifact>(moduleName, modelEntity.entityId);
    if (saved) entities.push(saved);
  }
  await writeMarkdownArtifact(
    ns3PipelineArtifactFileInfo(moduleName, 'e3-ontology', '.md'),
    renderE3OntologyMarkdown(model, entities, { generatedAt: new Date().toISOString() }),
  );
  let pipeline = await readNs3Pipeline(moduleName) || createNs3Pipeline(moduleName);
  pipeline = approveNs3Step(pipeline, STEP_ID, 'auto');
  await writeNs3Pipeline(pipeline);

  return [
    ns3ResultStepIntent(context, mutationParent, {
      planId: DONE_ANCHOR,
      dependsOn: [STEP_ID],
      stepTitle: 'Ontology ready',
      result: { type: DONE_ANCHOR, moduleName, entities: model.entities.map(entity => entity.entityId) },
    }),
    ns3UpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', `e3-ontology approved for ${moduleName}`),
  ];
}

function buildEntityStepIntent(
  context: mls.msg.ExecutionContext,
  mutationParent: mls.msg.AIAgentStep,
  moduleName: string,
  model: Ns3E3ModelArtifact,
  entityIndex: number,
): mls.msg.AgentIntentAddStep {
  const entity = model.entities[entityIndex];
  return ns3AgentStepIntent(context, mutationParent, {
    agentName: AGENT_NAME,
    stepTitle: `Entity ${entity.entityId} (${entityIndex + 1}/${model.entities.length})`,
    planId: `e3-entity-${entityIndex + 1}-${entity.entityId}`,
    prompt: { planId: 'e3-entity', moduleName, entityId: entity.entityId, entityIndex },
  });
}

async function resolveE3Module(requested?: string): Promise<string> {
  if (requested) return normalizeModuleFolderName(requested);
  const { listExistingModuleFolders } = await import('/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js');
  for (const moduleName of listExistingModuleFolders()) {
    const pipeline = await readNs3Pipeline(moduleName);
    if (!pipeline) continue;
    const checkpoint = pipeline.steps['checkpoint-journeys'];
    const e3 = pipeline.steps[STEP_ID];
    if (checkpoint?.status === 'approved' && (!e3 || e3.status !== 'approved' || e3.dirty)) return moduleName;
  }
  throw new Error(`[${AGENT_NAME}] no module with an approved journeys checkpoint waiting for E3`);
}

// Ontology defs files are `export const x = {...} as const;` — extract the JSON block.
async function readJsonDefs<T>(moduleName: string, shortName: string): Promise<T | null> {
  const raw = await readStorText({ project: mls.actualProject || 0, level: 4, folder: `${moduleName}/ontology`, shortName, extension: '.ts' }, false);
  if (!raw.trim()) return null;
  const start = raw.indexOf('= {');
  const end = raw.lastIndexOf('} as const;');
  if (start < 0 || end < 0) return null;
  const parsed = parseMaybeJson(raw.slice(start + 2, end + 1));
  return isRecord(parsed) ? parsed as T : null;
}

async function readE3Schema(shortName: string): Promise<Record<string, unknown>> {
  const raw = await readNs3Text('schemas', shortName, '.json', true);
  const parsed = parseMaybeJson(raw);
  if (!isRecord(parsed)) throw new Error(`[${AGENT_NAME}] invalid schema ${shortName}`);
  return parsed;
}

async function readNs3Text(folder: string, shortName: string, extension: string, required = false): Promise<string> {
  return readStorText(ns3L2File(`${NS3_AGENT_FOLDER}/${folder}`, shortName, extension), required);
}

function parseE3Args(value: unknown): E3Args {
  const parsed = parseMaybeJson(value);
  if (!isRecord(parsed)) return {};
  return {
    planId: readString(parsed.planId),
    moduleName: readString(parsed.moduleName),
    entityId: readString(parsed.entityId),
    entityIndex: typeof parsed.entityIndex === 'number' ? parsed.entityIndex : undefined,
    retryAttempt: typeof parsed.retryAttempt === 'number' ? parsed.retryAttempt : undefined,
    retryContext: readString(parsed.retryContext),
  };
}

function readString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
