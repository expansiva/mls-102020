/// <mls fileReference="_102020_/l2/agentNewSolution3/widgetNs3Draft.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { ns3PipelineArtifactFileInfo, readJsonArtifact, readStorText, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js';
import { approveNs3Step, createNs3Pipeline, readNs3Pipeline, writeNs3Pipeline, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Pipeline.js';
const message_en = {
    title: 'Understanding draft',
    approve: 'Approve',
    adjust: 'Adjust',
    adjustmentPlaceholder: 'Describe the smallest change needed in this draft.',
    approving: 'Approving...',
    adjusting: 'Requesting adjustment...',
    approved: 'Approved. The next step can run.',
    loading: 'Loading...',
    noDraft: 'No E1 draft artifact found.',
    gateOk: 'Gate passed',
    gateFailed: 'Gate failed',
    adjustDraftStepTitle: 'Adjust draft',
};
let WidgetNs3Draft102020 = class WidgetNs3Draft102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this._loading = true;
        this._artifact = null;
        this._markdown = '';
        this._pipeline = null;
        this._adjustment = '';
        this._busy = null;
        this._done = false;
        this._error = '';
        this._loadedFor = '';
    }
    async connectedCallback() {
        super.connectedCallback();
        await this._load();
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('value') && this.value && this.value.moduleName !== this._loadedFor)
            void this._load();
    }
    get _msg() {
        return { ...message_en, ...(this.value?.uiLabels || {}) };
    }
    async _load() {
        if (!this.value?.moduleName)
            return;
        this._loadedFor = this.value.moduleName;
        this._loading = true;
        this._error = '';
        try {
            this._artifact = await readJsonArtifact(ns3PipelineArtifactFileInfo(this.value.moduleName, 'e1-draft', '.json'), false);
            this._markdown = await readStorText(ns3PipelineArtifactFileInfo(this.value.moduleName, 'e1-draft', '.md'), false);
            this._pipeline = await readNs3Pipeline(this.value.moduleName);
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._loading = false;
        }
    }
    render() {
        const m = this._msg;
        if (this._loading)
            return html `<div class="ns3-draft"><div class="ns3-state">${m.loading}</div></div>`;
        if (this._error)
            return html `<div class="ns3-draft"><div class="ns3-state ns3-error">${this._error}</div></div>`;
        if (!this._artifact)
            return html `<div class="ns3-draft"><div class="ns3-state">${m.noDraft}</div></div>`;
        return html `
      <section class="ns3-draft">
        <header class="ns3-head">
          <div>
            <h3>${m.title}</h3>
            <p>${this._artifact.moduleTitle} <span>${this._artifact.moduleName}</span></p>
          </div>
          ${this._renderGate()}
        </header>
        <pre class="ns3-md">${this._markdown}</pre>
        ${this._done ? html `<div class="ns3-done">${m.approved}</div>` : this._renderActions()}
      </section>
    `;
    }
    _renderGate() {
        const m = this._msg;
        const gate = this._pipeline?.steps['e1-draft']?.lastGate;
        if (!gate)
            return html ``;
        return html `<span class="ns3-gate ${gate.ok ? 'ns3-gate--ok' : 'ns3-gate--bad'}">${gate.ok ? m.gateOk : m.gateFailed}</span>`;
    }
    _renderActions() {
        const m = this._msg;
        return html `
      <div class="ns3-actions">
        <textarea
          .value=${this._adjustment}
          placeholder=${m.adjustmentPlaceholder}
          @input=${(event) => { this._adjustment = event.target.value; }}
          ?disabled=${!!this._busy}
        ></textarea>
        <div class="ns3-buttons">
          <button class="ns3-secondary" ?disabled=${!!this._busy || !this._adjustment.trim()} @click=${() => this._onAdjust()}>
            ${this._busy === 'adjust' ? m.adjusting : m.adjust}
          </button>
          <button class="ns3-primary" ?disabled=${!!this._busy} @click=${() => this._onApprove()}>
            ${this._busy === 'approve' ? m.approving : m.approve}
          </button>
        </div>
      </div>
    `;
    }
    async _onApprove() {
        if (!this.value || !this._artifact || this._busy)
            return;
        this._busy = 'approve';
        this._error = '';
        try {
            const pipeline = approveNs3Step(this._pipeline || await readNs3Pipeline(this._artifact.moduleName) || this._newPipelineFallback(), 'e1-draft', 'human');
            await writeNs3Pipeline(pipeline);
            this._pipeline = pipeline;
            await this._completeCheckpoint('completed', 'checkpoint-draft approved');
            this._done = true;
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._busy = null;
        }
    }
    async _onAdjust() {
        if (!this.value || !this._artifact || this._busy || !this._adjustment.trim())
            return;
        this._busy = 'adjust';
        this._error = '';
        try {
            const addStep = {
                type: 'add-step',
                messageId: this.value.messageId,
                threadId: this.value.threadId,
                taskId: this.value.taskId,
                parentStepId: this.value.rerunParentStepId,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    stepTitle: this._msg.adjustDraftStepTitle,
                    status: 'waiting_human_input',
                    nextSteps: [],
                    agentName: 'agentNs3Draft',
                    prompt: JSON.stringify({ planId: 'e1-draft', adjustment: this._adjustment.trim(), previousModuleName: this._artifact.moduleName }),
                    rags: [],
                    planning: { planId: `e1-draft-adjustment-${Date.now()}`, dependsOn: ['checkpoint-draft'], executionMode: 'sequential', executionHost: 'client' },
                },
            };
            await this._applyIntents([addStep, this._checkpointStatus('completed', 'checkpoint-draft adjustment requested')]);
            this._done = true;
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._busy = null;
        }
    }
    async _completeCheckpoint(status, traceMsg) {
        await this._applyIntents([this._checkpointStatus(status, traceMsg)]);
    }
    _checkpointStatus(status, traceMsg) {
        const v = this.value;
        return {
            type: 'update-status',
            hookSequential: v.hookSequential,
            messageId: v.messageId,
            threadId: v.threadId,
            taskId: v.taskId,
            parentStepId: v.parentStepId,
            stepId: v.stepId,
            status,
            traceMsg,
            cleaner: 'input_output',
        };
    }
    async _applyIntents(intents) {
        const response = await mls.api.msgApplyIntents({ userId: this.value.senderId, intents });
        if (!response || response.statusCode !== 200) {
            throw new Error(response?.msg || 'Error applying checkpoint action');
        }
        const ret = response;
        if (!ret.message)
            throw new Error('No message returned after checkpoint action');
        const context = { task: ret.task, message: ret.message, isTest: ret.task?.iaCompressed?.isTest || false };
        await continuePoolingTask(context);
    }
    _newPipelineFallback() {
        return createNs3Pipeline(this._artifact?.moduleName || 'module');
    }
};
__decorate([
    property({ type: Object })
], WidgetNs3Draft102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_loading", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_artifact", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_markdown", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_pipeline", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_adjustment", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_busy", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_done", void 0);
__decorate([
    state()
], WidgetNs3Draft102020.prototype, "_error", void 0);
WidgetNs3Draft102020 = __decorate([
    customElement('widget-ns3-draft-102020')
], WidgetNs3Draft102020);
export { WidgetNs3Draft102020 };
