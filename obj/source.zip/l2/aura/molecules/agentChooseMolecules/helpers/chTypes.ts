/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.ts" enhancement="_blank"/>

// Types, constants and the PURE helpers of agentChooseMolecules. No I/O, no mls.* access — which is
// what makes every gate and the report renderer node-testable (skills/agentTest.md, category B).
//
// Plumbing that already exists is imported, not restated: intents and l4 mechanics come from
// agentNewMolecule2/helpers (nmSteps, nmFs) and the strict tool wrapper from shared/llmTool. This file
// only declares what is specific to CHOOSING from the catalog. See flow.json.

export const CH_AGENT_NAME = 'agentChooseMolecules';
export const CH_AGENT_FOLDER = 'aura/molecules/agentChooseMolecules';
/** The agent lives in 102020 whatever project's catalog it reads. */
export const CH_AGENT_PROJECT = 102020;

/** One retry with the gate errors in the prompt, then stop. Same budget as agentImproveMolecule2. */
export const CH_MAX_ATTEMPTS = 2;

/** Steps whose planId is fixed. The c2 steps are one per chosen group — see chGroupPlanId. */
export const CH_PLAN_C1 = 'c1-groups';
export const CH_PLAN_FANOUT = 'c1r-fanout';
export const CH_PLAN_C3 = 'c3-report';

/**
 * 'c1-groups' -> 'c1-done'. Same convention as the rest of the family.
 *
 * ⚠️ NOT USABLE FOR THE c2 STEPS, and that is the whole reason chGroupDoneAnchor exists: splitting on
 * '-' would give every group's step the same 'c2-done' anchor, so a c3 that dependsOn it would be
 * waiting on an anchor several steps write — and the first one to land would unlock it.
 */
export function chDoneAnchor(planId: string): string {
  return `${planId.split('-')[0]}-done`;
}

/** The folder spelling of a group: the catalog publishes 'groupSelectOne', the folder is lowercase. */
export function chGroupFolder(groupName: string): string {
  return (groupName || '').trim().toLowerCase();
}

export function chGroupPlanId(groupName: string): string {
  return `c2-${chGroupFolder(groupName)}`;
}

export function chGroupDoneAnchor(groupName: string): string {
  return `${chGroupPlanId(groupName)}-done`;
}

/** How many runs one slug can hold before the caller has to clean up l4. Two digits, to fit the slug cap. */
export const CH_MAX_RUN_SEQ = 99;

/**
 * The l4 folder of a run, made UNIQUE by a sequence.
 *
 * ⚠️ THE SLUG ALONE COLLIDES, and it cost a measurement. The runKey is derived from the definition, so two
 * runs of the same page produce the same folder and the second one OVERWRITES the first in silence — on
 * 2026-09-04 a re-run of 'cadastro-usuarios' took the pre-amendment baseline with it (recovered from the
 * fs trash, which is luck, not a design). The report is the only thing a probe run produces, so losing the
 * previous one loses the comparison the run existed to make.
 *
 * The FIRST run of a slug keeps the clean name: a folder that already exists is never renamed, so whoever
 * scored an old run still finds it where they left it. From the second on, '-02', '-03' … is appended.
 *
 * Pure — the caller supplies `taken`, which is what makes this testable with no stor. The suffix is
 * budgeted inside nmRunKey's 40-character cap, because the slug is also a file path.
 */
export function chUniqueRunKey(base: string, taken: (runKey: string) => boolean): string {
  const slug = base || 'run';
  if (!taken(slug)) return slug;
  const stem = slug.slice(0, 37).replace(/-+$/g, '') || 'run';
  for (let seq = 2; seq <= CH_MAX_RUN_SEQ; seq += 1) {
    const candidate = `${stem}-${String(seq).padStart(2, '0')}`;
    if (!taken(candidate)) return candidate;
  }
  throw new Error(`[chUniqueRunKey] '${stem}' already has ${CH_MAX_RUN_SEQ} runs in l4 — remove the old ones or change the definition`);
}

/**
 * The catalog's own spelling for a group the model named, or '' when it named one that does not exist.
 *
 * Case-insensitive on purpose: 'groupselectone' for 'groupSelectOne' is a spelling slip, and spending a
 * retry on it would teach nothing about the catalog. The TAG is the opposite case — there the exact
 * spelling is the thing being measured (flow.json.decisions.tagSpelling).
 */
export function chCanonicalGroup(groupName: string, known: string[]): string {
  const wanted = (groupName || '').trim().toLowerCase();
  if (!wanted) return '';
  return known.find(name => name.trim().toLowerCase() === wanted) || '';
}

export interface ChGateResult {
  ok: boolean;
  errors: string[];
}

export function chGateOk(): ChGateResult {
  return { ok: true, errors: [] };
}

export function chGateFail(...errors: string[]): ChGateResult {
  return { ok: false, errors: errors.filter(Boolean) };
}

export function chIssue(code: string, message: string): string {
  return `${code}: ${message}`;
}

// ---- what the two LLM steps produce ----

export interface ChRegion {
  /** The join key between c1 and c2. Unique within a run; c2 echoes it verbatim. */
  region: string;
  /** What the region has to do, in the user's words — this is what c2 reads, not the whole definition. */
  need: string;
  /** The catalog's spelling of the group, or null when no published group covers the need. */
  group: string | null;
  reason: string;
}

export interface ChGroupsArtifact {
  schemaVersion: 1;
  savedAt: string;
  runKey: string;
  /** The project whose catalog answered this run — not necessarily the project the run belongs to. */
  catalogProject: number;
  level1Reference: string;
  regions: ChRegion[];
  /** Distinct groups, in the catalog's spelling — what the fan-out plants from. */
  groups: string[];
  /**
   * Each chosen group's level-2 reference, as level 1 published it.
   *
   * Pinned here so the c2 steps never look level 1 up again: re-discovering could land on a different
   * catalog than the one c1 answered from, and a run must measure ONE catalog.
   */
  groupRefs: Array<{ group: string; indexDefs: string }>;
}

export interface ChChoice {
  region: string;
  group: string;
  /** The FULL published tag, or null when no molecule of this group serves the region. */
  tag: string | null;
  /** Which quick-reference scenario was used, or null when none applied. */
  scenarioUsed: string | null;
  reason: string;
}

export interface ChGroupArtifact {
  schemaVersion: 1;
  savedAt: string;
  runKey: string;
  group: string;
  indexDefsReference: string;
  /** Which rung of the read ladder answered — a finding of the first Studio run, not a detail. */
  catalogVia: ChCatalogVia;
  choices: ChChoice[];
  /** false = the gate never accepted an answer for this group. The run still reports. */
  ok: boolean;
  /** How many attempts the anti-invention gate refused. Zero is the acceptance criterion. */
  gateHits: number;
  /** Tags chosen whose catalog entry has no .defs (the ml-table-multi-select case). */
  chosenWithoutDefs: string[];
  errors: string[];
}

// ---- prompt size, which is how "tokens per step" is measured here ----

/**
 * 4 chars per token, the usual ratio for prose in English and Portuguese.
 *
 * ⚠️ IT IS AN ESTIMATE AND IT IS THE METRIC (decision of 2026-08-19). There is no token telemetry on
 * this platform: the step contract carries no provider `usage`, so a step cannot read what its own call
 * consumed. The estimate errs by roughly ±20%, and the §11.4 question — does one level per prompt stay
 * in the 1–2k range? — has 2× to 4× of margin on the measured files, so the error cannot flip it.
 */
export const CH_CHARS_PER_TOKEN = 4;

export function chEstTokens(chars: number): number {
  return Math.ceil(Math.max(0, chars) / CH_CHARS_PER_TOKEN);
}

export interface ChPromptSize {
  planId: string;
  attempt: number;
  /** The `<!-- modelType: X -->` marker actually shipped in the prompt, parsed from it. */
  modelType: string;
  /** The prompt.md, after substitution, WITHOUT the catalog block. */
  instructionChars: number;
  /** The catalog level injected into this call — the number §11.4 is about. */
  catalogChars: number;
  /** The human prompt: the definition, or the regions of one group. */
  inputChars: number;
  totalChars: number;
  instructionTokensEst: number;
  catalogTokensEst: number;
  inputTokensEst: number;
  totalTokensEst: number;
}

export function chMeasurePrompt(args: {
  planId: string;
  attempt: number;
  /** The assembled system prompt, catalog included — the catalog is subtracted here. */
  systemPrompt: string;
  catalog: string;
  humanPrompt: string;
}): ChPromptSize {
  const catalogChars = args.catalog.length;
  const instructionChars = Math.max(0, args.systemPrompt.length - catalogChars);
  const inputChars = args.humanPrompt.length;
  const totalChars = args.systemPrompt.length + inputChars;
  return {
    planId: args.planId,
    attempt: args.attempt,
    modelType: chParseModelType(args.systemPrompt),
    instructionChars,
    catalogChars,
    inputChars,
    totalChars,
    instructionTokensEst: chEstTokens(instructionChars),
    catalogTokensEst: chEstTokens(catalogChars),
    inputTokensEst: chEstTokens(inputChars),
    totalTokensEst: chEstTokens(totalChars),
  };
}

// ---- what the CALL actually cost, from the step's own trace ----

/**
 * ⚠️ THE PLATFORM DOES EXPOSE USAGE, and I said it did not (2026-08-19). It is not in the step contract —
 * no field carries it — but the runtime appends a line to `interaction.trace` after the call:
 *
 *   provider: openrouter model:openai/gpt-5.6-terra-pro alias:reasoning stage:primary user:'…'
 *   inputTokens:7727 outputTokens:649 cost:$0.0239 llmTime: 00:00:07.895
 *
 * Measured on the run of 2026-08-21 and it changes the reading of §11.4: the c1 prompt this agent
 * ASSEMBLES was 1.203 estimated tokens, and the provider counted 7.727 of input — 6.4×. The difference is
 * the platform's own additions (the Content Memory block it appends, the tool schema, thread context). Both
 * numbers matter and they answer different questions: the estimate says how big the CATALOG block is, which
 * is what the design is about; this says what the call costs, which is what the real consumer pays.
 *
 * It is parsed defensively because the format is a platform string, not a contract: no line, no usage, and
 * the report says "not measured" rather than zero.
 */
export interface ChStepUsage {
  inputTokens: number;
  outputTokens: number;
  costUsd: number;
  /** Provider lines summed. More than one means a fallback stage or a retry inside the same call. */
  calls: number;
  models: string[];
}

export function chParseUsage(trace: unknown): ChStepUsage | null {
  const lines = Array.isArray(trace) ? trace.filter((line): line is string => typeof line === 'string') : [];
  const usage: ChStepUsage = { inputTokens: 0, outputTokens: 0, costUsd: 0, calls: 0, models: [] };

  for (const line of lines) {
    const input = /inputTokens:\s*(\d+)/.exec(line);
    const output = /outputTokens:\s*(\d+)/.exec(line);
    if (!input && !output) continue;
    usage.calls += 1;
    usage.inputTokens += input ? Number(input[1]) : 0;
    usage.outputTokens += output ? Number(output[1]) : 0;
    const cost = /cost:\s*\$?([\d.]+)/.exec(line);
    if (cost) usage.costUsd += Number(cost[1]);
    const model = /\bmodel:\s*(\S+)/.exec(line);
    if (model && !usage.models.includes(model[1])) usage.models.push(model[1]);
  }

  if (!usage.calls) return null;
  // Float addition of dollar amounts drifts; the cost is reported to the cent-of-a-cent it came in at.
  usage.costUsd = Math.round(usage.costUsd * 1e6) / 1e6;
  return usage;
}

/** The marker skills/modelTypes.md makes mandatory. Reported, so the run says which model type ran. */
export function chParseModelType(prompt: string): string {
  const match = /<!--\s*modelType:\s*([a-zA-Z]+)\s*-->/.exec(prompt || '');
  return match ? match[1] : '';
}

/**
 * The "nothing fits" sentinel, at both levels.
 *
 * The strict tool schema cannot express a nullable string — a `["string","null"]` union is refused by
 * the strictest providers (agentsBestPractices §9) — so the schema asks for the word 'none' and the
 * gates turn it into null here. The accepted spellings include the Portuguese ones on purpose: the
 * prompts are answered in the user's language, and refusing 'nenhum' would spend a retry on a slip
 * that says nothing about the catalog.
 */
const CH_NONE_WORDS = ['', 'none', 'null', 'nenhum', 'nenhuma', 'nenhum grupo', 'n/a'];

export function chIsNone(value: unknown): boolean {
  return CH_NONE_WORDS.includes(String(value ?? '').trim().toLowerCase());
}

/**
 * The GROUP a c2 step is about, read from its own args.
 *
 * nmParseStepArgs is the shared reader of step args (planId, runKey, retry) and knows nothing about a
 * group — widening a shared helper for one agent's field is the boundary agentsBestPractices §2 warns
 * about, so this reads the one extra field and the shared helper keeps reading the rest. Parsing the
 * same short string twice costs nothing.
 */
export function chGroupArg(value: unknown): string {
  if (typeof value !== 'string') {
    return isPlainRecord(value) && typeof value.group === 'string' ? value.group.trim() : '';
  }
  const trimmed = value.trim();
  if (!trimmed.startsWith('{')) return '';
  try {
    const parsed = JSON.parse(trimmed) as unknown;
    return isPlainRecord(parsed) && typeof parsed.group === 'string' ? parsed.group.trim() : '';
  } catch {
    return '';
  }
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

// ---- import references, and the file behind them ----

/**
 * The five fields the stor identifies a file by. Structurally the same as nmFs.NmFileInfo, declared here
 * so this module keeps importing nothing and stays node-testable.
 */
export interface ChFileRef {
  project: number;
  level: number;
  folder: string;
  shortName: string;
  extension: string;
}

/**
 * The stor file behind an import reference: '/_102040_/l2/molecules/groupenterdate/index.defs' ->
 * { project: 102040, level: 2, folder: 'molecules/groupenterdate', shortName: 'index', extension: '.defs.ts' }.
 *
 * ⚠️ MEASURED ON THE FIRST STUDIO RUN (2026-08-19): a dynamic import is served from the PUBLISHED project
 * (`https://on.collab.codes/_102040_/...`), so a catalog file that exists in the editor and was never
 * published fails with 'Failed to fetch dynamically imported module'. Reading it needs the stor, and the
 * stor is addressed by these five fields — hence this parse. Derived from the reference and never from a
 * second assumption about where a group's catalog lives, so the two cannot drift.
 *
 * `.defs` is an EXTENSION and not part of the shortName (the rule nmFs documents at length): 'index.defs'
 * is shortName 'index' + extension '.defs.ts', and getting it wrong files the model under a phantom group
 * where nothing finds it.
 */
export function chFileRefFromImport(reference: string): ChFileRef | null {
  const match = /^\/?_(\d+)_\/l(\d+)\/(.+)$/.exec((reference || '').trim());
  if (!match) return null;
  const project = Number(match[1]);
  const level = Number(match[2]);
  const rest = match[3].replace(/\.ts$/, '');
  const parts = rest.split('/');
  const last = parts.pop() || '';
  if (!project || !level || !last) return null;
  const defs = last.endsWith('.defs');
  return {
    project,
    level,
    folder: parts.join('/'),
    shortName: defs ? last.slice(0, -'.defs'.length) : last,
    extension: defs ? '.defs.ts' : '.ts',
  };
}

/**
 * How a catalog level was actually read: from the editor's stor, or from the published module.
 *
 * Recorded per level because the first Studio run turned it into a finding — a catalog that only exists
 * in the editor is invisible to any consumer that is not the editor.
 */
export type ChCatalogVia = 'stor' | 'published';
