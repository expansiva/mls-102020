/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.test.ts" enhancement="_blank"/>

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CH_CHARS_PER_TOKEN,
  chParseUsage,
  chCanonicalGroup,
  chFileRefFromImport,
  chDoneAnchor,
  chEstTokens,
  chGroupArg,
  chGroupDoneAnchor,
  chGroupFolder,
  chGroupPlanId,
  chIsNone,
  chMeasurePrompt,
  chParseModelType,
  chUniqueRunKey,
  CH_MAX_RUN_SEQ,
} from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';

void test('the fixed anchors follow the family convention', () => {
  assert.equal(chDoneAnchor('c1-groups'), 'c1-done');
  assert.equal(chDoneAnchor('c3-report'), 'c3-done');
});

void test('every group gets its OWN c2 anchor — a shared one would unlock the report early', () => {
  assert.equal(chGroupPlanId('groupSelectOne'), 'c2-groupselectone');
  assert.equal(chGroupDoneAnchor('groupSelectOne'), 'c2-groupselectone-done');
  assert.notEqual(chGroupDoneAnchor('groupSelectOne'), chGroupDoneAnchor('groupViewTable'));
  assert.equal(chGroupFolder('groupViewTable'), 'groupviewtable');
});

void test('a group is matched case-insensitively and reported in the catalog spelling', () => {
  const known = ['groupSelectOne', 'groupViewTable'];
  assert.equal(chCanonicalGroup('groupselectone', known), 'groupSelectOne');
  assert.equal(chCanonicalGroup('  GROUPVIEWTABLE ', known), 'groupViewTable');
  assert.equal(chCanonicalGroup('groupViewChart', known), '');
  assert.equal(chCanonicalGroup('', known), '');
});

void test('the "nothing fits" sentinel is accepted in both languages the prompts are answered in', () => {
  for (const word of ['none', 'None', ' NULL ', 'nenhum', 'nenhuma', '', 'n/a']) assert.equal(chIsNone(word), true, word);
  for (const word of ['groupSelectOne', 'ml-combobox', 'nenhumaideia']) assert.equal(chIsNone(word), false, word);
});

void test('the token estimate is chars / 4, rounded up', () => {
  assert.equal(CH_CHARS_PER_TOKEN, 4);
  assert.equal(chEstTokens(0), 0);
  assert.equal(chEstTokens(1), 1);
  assert.equal(chEstTokens(1547), 387);
  assert.equal(chEstTokens(-10), 0);
});

void test('the prompt measurement separates the catalog from the instructions and the input', () => {
  const catalog = 'C'.repeat(400);
  const systemPrompt = `<!-- modelType: reasoning -->${'I'.repeat(100)}${catalog}`;
  const humanPrompt = 'H'.repeat(40);
  const size = chMeasurePrompt({ planId: 'c1-groups', attempt: 2, systemPrompt, catalog, humanPrompt });

  assert.equal(size.catalogChars, 400);
  assert.equal(size.instructionChars, systemPrompt.length - 400);
  assert.equal(size.inputChars, 40);
  assert.equal(size.totalChars, systemPrompt.length + 40);
  assert.equal(size.totalTokensEst, Math.ceil((systemPrompt.length + 40) / 4));
  assert.equal(size.modelType, 'reasoning');
  assert.equal(size.attempt, 2);
});

void test('the modelType marker is reported from the prompt that actually shipped', () => {
  assert.equal(chParseModelType('<!-- modelType: classifier -->\nx'), 'classifier');
  assert.equal(chParseModelType('<!--modelType:reasoning-->'), 'reasoning');
  assert.equal(chParseModelType('no marker here'), '');
});

void test('the group travels in the step args, and a step planted without one says so', () => {
  assert.equal(chGroupArg(JSON.stringify({ planId: 'c2-groupselectone', runKey: 'r', group: 'groupSelectOne' })), 'groupSelectOne');
  assert.equal(chGroupArg({ group: ' groupViewTable ' }), 'groupViewTable');
  assert.equal(chGroupArg(JSON.stringify({ planId: 'c1-groups' })), '');
  assert.equal(chGroupArg('not json'), '');
  assert.equal(chGroupArg(undefined), '');
});

void test('an import reference maps to the stor file behind it — .defs is an extension, not a name', () => {
  assert.deepEqual(chFileRefFromImport('/_102040_/l2/molecules/groupenterdate/index.defs'), {
    project: 102040,
    level: 2,
    folder: 'molecules/groupenterdate',
    shortName: 'index',
    extension: '.defs.ts',
  });
  assert.deepEqual(chFileRefFromImport('/_102040_/l2/molecules/skill'), {
    project: 102040,
    level: 2,
    folder: 'molecules',
    shortName: 'skill',
    extension: '.ts',
  });
  // The trailing .ts is tolerated: the same reference is written both ways across the codebase.
  assert.equal(chFileRefFromImport('_102040_/l2/molecules/skill.ts')?.shortName, 'skill');
});

void test('anything that is not a project reference is refused instead of guessed', () => {
  for (const bad of ['', 'https://on.collab.codes/x.js', '/_abc_/l2/x', '/_102040_/molecules/x', '/_102040_/l2/']) {
    assert.equal(chFileRefFromImport(bad), null, bad);
  }
});

// The line the runtime appends after a call, verbatim from the run of 2026-08-21.
const PROVIDER_LINE = "provider: openrouter model:openai/gpt-5.6-terra-pro alias:reasoning stage:primary user:'lucasexpansiva@gmail.com' inputTokens:7727 outputTokens:649 cost:$0.0239 llmTime: 00:00:07.895";

void test('the real usage is read from the step trace — the platform does expose it', () => {
  const usage = chParseUsage(['starting at 2026-08-21T12:26:21.104Z', PROVIDER_LINE, 'finished at ...']);
  assert.deepEqual(usage, {
    inputTokens: 7727,
    outputTokens: 649,
    costUsd: 0.0239,
    calls: 1,
    models: ['openai/gpt-5.6-terra-pro'],
  });
});

void test('a fallback stage inside one call is summed and counted', () => {
  const second = PROVIDER_LINE.replace('inputTokens:7727', 'inputTokens:100').replace('outputTokens:649', 'outputTokens:20').replace('cost:$0.0239', 'cost:$0.0011').replace('terra-pro', 'luna');
  const usage = chParseUsage([PROVIDER_LINE, second]);
  assert.equal(usage?.calls, 2);
  assert.equal(usage?.inputTokens, 7827);
  assert.equal(usage?.outputTokens, 669);
  assert.equal(usage?.costUsd, 0.025);
  assert.deepEqual(usage?.models, ['openai/gpt-5.6-terra-pro', 'openai/gpt-5.6-luna']);
});

void test('no provider line means NOT MEASURED, never zero', () => {
  assert.equal(chParseUsage(['starting at x', 'finished at y']), null);
  assert.equal(chParseUsage(undefined), null);
  assert.equal(chParseUsage('provider: inputTokens:1'), null);
});

// ---- the run folder is unique, because losing a previous report loses the comparison ----

/** `taken` reads a set instead of a stor, which is the whole point of the helper being pure. */
const takenIn = (...keys: string[]) => (runKey: string) => keys.includes(runKey);

void test('the FIRST run of a slug keeps the clean name — an existing folder is never renamed', () => {
  assert.equal(chUniqueRunKey('cadastro-usuarios', takenIn()), 'cadastro-usuarios');
});

void test('a slug already used gets a sequence, and the sequence skips what is taken', () => {
  assert.equal(chUniqueRunKey('cadastro-usuarios', takenIn('cadastro-usuarios')), 'cadastro-usuarios-02');
  assert.equal(
    chUniqueRunKey('cadastro-usuarios', takenIn('cadastro-usuarios', 'cadastro-usuarios-02')),
    'cadastro-usuarios-03',
  );
});

void test('the suffix is budgeted INSIDE the 40-character slug cap — the runKey is also a file path', () => {
  const long = 'a'.repeat(40);
  const sequenced = chUniqueRunKey(long, takenIn(long));
  assert.equal(sequenced.length, 40);
  assert.match(sequenced, /^[a-z0-9][a-z0-9-]{0,39}$/);
  assert.equal(sequenced, `${'a'.repeat(37)}-02`);
});

void test('a stem left ending in a dash by the truncation does not produce a double dash', () => {
  const slug = `${'a'.repeat(36)}-bbb`;
  assert.equal(chUniqueRunKey(slug, takenIn(slug)), `${'a'.repeat(36)}-02`);
});

void test('an empty base still names a folder rather than writing to the run root', () => {
  assert.equal(chUniqueRunKey('', takenIn()), 'run');
});

void test('a slug with every sequence taken refuses out loud instead of overwriting', () => {
  const all = ['x', ...Array.from({ length: CH_MAX_RUN_SEQ - 1 }, (_, i) => `x-${String(i + 2).padStart(2, '0')}`)];
  assert.throws(() => chUniqueRunKey('x', takenIn(...all)), /already has 99 runs/);
});
