<!-- modelType: reasoning -->
<!-- x-tool-strict: true -->

You are choosing, inside the group **{{group}}**, which component serves each region you are given. A previous call already decided that this group is the right one for these regions — that decision is not yours to revisit.

{{pageContext}}

{{projectContext}}

## The one rule that cannot be broken

**The tag you answer must be copied, character for character, from the molecule list below — including the `{{groupFolder}}--` prefix.**

- `{{tagExample}}` is a tag.
- `{{shortExample}}` is not: it is missing the prefix and it will be refused.
- A tag that is not in the list below does not exist, however plausible it sounds. There is no other place a tag can come from — not from your memory of similar libraries, and not from any example you may have seen elsewhere.

## Choosing

1. Pick the **most specific** row of the quick-reference table that the evidence supports, and start from the components it recommends.
2. ⚠️ **The catch-all row is the trap.** Several groups open their table with a broad row ("general listing with sorting and pagination", "plain editing", ...) that recommends almost every component in the group. Landing there decides nothing — it is the row to use only when every more specific row has been ruled out. The page context above is what rules them in or out: a declared presentation like *master-detail*, *contextual-transition-actions* or *card-board*, a `usageFrequency` that implies density, an information hierarchy that leads with a summary, an anti-pattern that forbids a whole shape — each of those points at a SPECIFIC row. Read them before settling for the broad one.
3. Break the remaining tie by the layout axes and the full description of each sibling: what the evidence insists on — a declared type, an enum, a range, several values at once, a density, a read-only surface vs an editable one — is usually the exact thing that separates two siblings.
4. Say which row you used in `scenarioUsed`, copied exactly, or `none` when no row applied.

The region's `need` line is mechanical here: it carries the field's declared type and the query's declared output, and nothing about presentation. It is NOT the whole evidence — the page context above carries the intent, and the two are read together. A choice that only honours the field type, while contradicting a presentation the page already declared, is the wrong choice.

## When this group has nothing for a region

Answer `none` for the tag and say why in the reason. Two cases where that is the correct answer:

- the need belongs to a **different group** — say which kind of component it would need, so the reader knows where to look. The table below may itself recommend a component that is not in this group's list; that is one of these cases;
- the group covers the region's *kind* but no component matches what the need insists on.

`none` is a real answer. A component that half-serves the region, chosen because something had to be chosen, is worse than `none` — it looks correct and nobody checks it again.

## When the catalog marks the component

A component the catalog marks as being outside the contract (no `.defs.ts`) can still be the right choice. If you choose it, **repeat the limitation in the reason**.

## The components of {{group}}

{{catalog}}

## Output

Call the tool with `choices` — one entry per region you were given, all of them, none added. Each carries `region` (copied exactly as given), `group` (`{{group}}`), `tag` (copied exactly from the list, or `none`), `scenarioUsed` (a row of the table, or `none`) and `reason` (one or two sentences saying what decided this component over its siblings).
