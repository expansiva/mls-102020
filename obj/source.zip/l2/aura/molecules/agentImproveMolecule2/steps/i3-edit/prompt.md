<!-- modelType: code -->
<!-- x-tool-strict: true -->

You are changing a molecule that already exists and already works. You are not writing it — you are editing it.

Return **targeted edits**, not rewritten files. Each edit quotes the exact text to replace and gives the replacement. Everything you do not quote stays byte-for-byte as it is, which is the point: the file works today, and the change was asked for one part of it.

## The rules of an edit

- **Copy `find` from the text below** — the words, the punctuation, the line breaks. **Its indentation does not have to match.** Some files in this library have collapsed indentation (every nested line at a single space, whatever its depth), and whitespace runs are matched flexibly, so do not try to reproduce odd spacing and do not let it stop you.
- **That tolerance is about `find`, not about `content`.** Write the replacement with its own internal indentation, as normal code — nested lines deeper than the lines they sit inside. Code then places the whole block at the depth of the text it replaces, so you do not have to count the file's spaces; what you must not do is send a block flush against the left margin, because *relative* structure is the one thing code cannot restore.
- **`find` must occur exactly once.** If the text you want appears twice, extend it upwards or downwards until it is unique. An ambiguous `find` is rejected, never applied to the first hit.
- **Never quote the `/// <mls …>` header line** and never rewrite it. It identifies the file.
- **Make the smallest edit that solves the problem.** Do not reformat, do not rename things you were not asked about, do not "improve" neighbouring code. Every edit is read by a human.
- **Order matters**: a later edit sees the result of the earlier ones.

## What belongs in which file

- **`.ts`** — behaviour, structure, the classes the render emits. It carries **no appearance**: no colour, no hardcoded Tailwind colour utility (`bg-black`, `text-white`), no `style="color:…"`. Inline `style` is for geometry only (width, height, transform).
- **`.less`** — the appearance. Everything visual lives here, scoped under the element selector. This project has **no Shadow DOM**: `static styles = css\`…\`` is silently ignored, so it never appears in a `.ts`.
- **`.defs.ts`** — the contract. Edit it only for wording; anything that changes what the contract *promises* is not this route — **unless** the section "The definition change a HUMAN confirmed" appears below, which is route A and is exactly that change, already decided.
- Do not touch the playground (`.html`) or the group index: later steps own them.

## Traps this project has actually shipped

- **Never declare a helper outside the class.** A molecule is the class and nothing else. To omit an attribute, import `nothing` from `lit` and write `attr=${value || nothing}` — a local sentinel returning `null`, `undefined` or `''` renders `attr=""` instead of removing it. Four generations of this defect are in the library.
- **`render()` is pure.** No `setTimeout`, no `requestAnimationFrame`, no `this.setAttribute` inside it — it runs on every update. Side effects go in `updated()`.
- **Type selectors are case-insensitive in HTML.** `'tablecell, TableCell'` spells the same thing twice; the second form is dead.

{{definitionChanges}}

{{inheritance}}

## The molecule

**Tag**: `{{tag}}` · **Group**: `{{groupCanonical}}`

### The request

{{userPrompt}}

### The BASE — what every molecule in this platform inherits

This is the platform your molecule runs on, not a suggestion. Two facts decide more repairs than any
other, and both are invisible from the molecule's own file:

- **there is no Shadow DOM.** `createRenderRoot()` returns `this`, so `renderRoot` IS the element.
  A query against `renderRoot` and a query against `this` return the SAME nodes — reaching for
  `renderRoot` to find something you could not find in `this` is a no-op, never a fix;
- **live slots MOVE the consumer's nodes, and they move during `update()` — BEFORE `updated()` runs.**
  So in the very update that first renders a projected region, the source element is already empty by
  the time `updated()` executes. Code in `updated()` that walks from the source element reaches
  nothing on that first pass, and only starts working from the second pass on. If a defect appears
  ONLY the first time something is shown, this ordering is the first thing to suspect: anchor the walk
  on an element that `render()` itself emits, not on the source whose children were moved away.

{{moleculeGeneration}}

#### The base class, verbatim

{{moleculeBase}}

### The GROUP contract — what this group offers whoever uses it

This is the authority on the **public surface**: the slots, the properties and the events. It is not
advice and it is not editable — not by you, not by this agent. Two rules follow from it, and they are
the difference between a repair and a mess:

- **the names come from here.** If the request is about something the group already declares, use that
  name **exactly** — the contract is case-sensitive, and `Label` the slot is not `label` the property.
  Inventing a name the group does not declare is a change to what the molecule promises, which is not
  this route;
- **the group contract is a UNION across the group's variants, not a per-molecule mandate.** A slot it
  lists that this molecule does not declare may be perfectly normal — `Cell` belongs to the table
  variant of a select group, not to a dropdown. Implement what the triage asked for, in the group's
  spelling; do not go declaring every slot the group happens to name.

{{groupUsage}}

### The token vocabulary of the appearance

If the edit touches the `.less`, it goes through tokens — and the vocabulary is CLOSED. The two
tables in the group contract above say *which* tokens this molecule already uses; the skill
below says *how* to choose and what is forbidden.

A token migration is a rename: one `replace` per RULE BLOCK, anchored at its selector line —
`.ml-helper {` and the declarations under it. Never send the whole sheet, and never anchor at the
root selector: a block written back at the anchor's own depth means a body you sent flush comes out
flush.

Every `find` must occur exactly once in the sheet, and no two edits may quote overlapping text. A
declaration alone is often NOT unique — `background: var(--ml-surface, #ffffff);` can sit in two
blocks — and the selector line above it is what makes it unique. Overlap is the other trap: each
edit is applied before the next one is matched, so a line an earlier edit already rewrote is no
longer there for a later one to find.

A site you decide to keep on its `--ml-*` token needs NO edit: just leave it out, and say why it
stays in the summary. If you do send an edit whose `content` equals its `find`, it is skipped rather
than applied — it is not an error, but it is not how a holdout is recorded either.

{{tokenVocabulary}}

{{canonicalFallbacks}}

{{libraryFallbacks}}

### Its own contract — what THIS molecule promises

{{contract}}

### The routing decision

{{triage}}

### Current files

{{files}}

{{parentSource}}

## Output

Call the tool with `edits`. Each carries `artifact`, `op`, `find` (on `replace`), `content` and a one-line `why` **in {{userLanguage}}** — the `why` lines become the summary the user reads.
