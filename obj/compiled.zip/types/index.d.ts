declare module "_102020_/l2/aura" {
    export class Aura {
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102020_/l2/auraState" {
    export interface IAuraPage {
        project: number;
        shortName: string;
        folder: string | null;
        level: number;
        extension: string;
    }
    export interface IAuraState {
        actualProject: number | null;
        actualModule: string | null;
        actualLanguage: string | null;
        actualDevice: string | null;
        actualLayout: number | null;
        actualDesignSystem: number | null;
        actualPage: IAuraPage | null;
    }
    export function AuraInitState(): void;
    export function getAuraState(): IAuraState;
    export function setAuraState<K extends keyof IAuraState>(key: K, value: IAuraState[K]): void;
    type IAuraProjectEntry = Omit<IAuraState, 'actualProject'>;
    export function saveAuraProject(): void;
    export function loadAuraProject(project: number | null): IAuraProjectEntry | null;
    export function restoreAuraProject(project: number): void;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102020_/l2/buildFile" {
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
    export function getDependenciesByHtml(file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean): Promise<IJSONDependence>;
}
declare module "_102020_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102027_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102027_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102020_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102020_/l2/enhancementStyleAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/stateLitElement" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { PropertyValueMap } from 'lit';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/shared/api" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
        };
    };
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function prepareClarificationElement(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], clarification: ClarificationValue | Object | string): Promise<HTMLElement>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102020_/l2/pageCraft" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PageCraft102020 extends StateLitElement {
        private _loading;
        private _modules;
        private _selectedDevice;
        private _selectedPages;
        private _generating;
        private _error;
        preview: HTMLTextAreaElement | undefined;
        private readonly _devices;
        connectedCallback(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        private _renderLoading;
        private _renderError;
        private _renderEmpty;
        private _renderMain;
        private _renderModule;
        private _renderDraftItem;
        private _renderDoneItem;
        private _scanProject;
        /**
         * Safely extract `status` and `pages` from a raw TS/JS file that uses
         * `export const definition = { ... }`.
         * Strategy: pull out the object literal and JSON.parse a cleaned version.
         */
        private _parseDefinition;
        private _selectDevice;
        private _togglePage;
        private _generate;
        private executeAgent;
        private _allDraft;
        private _allGenerated;
        private getSkill;
        private ex;
    }
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_102020_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from "_102027_/l2/pluginBaseIndex";
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginCollabCoreIndex;
    export default _default_1;
}
declare module "_102020_/l2/previewEditorL3" { }
declare module "_102020_/l2/previewModeAura" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeAura {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        private esbuild;
        private needAwait;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        buildJS(other: string[]): Promise<any>;
        private configIframe;
        private _buildJS;
        private parseImportsMap;
        private findWidgets;
        private getImportsAuraWigetsPlayGround;
        private loadEsbuild;
        private initializeEsBuild;
        private loadCache;
        private mountJSImporMap;
        private mountLinks;
        /**
         * Injects Tailwind v4 dark mode configuration into the iframe.
         *
         * Tailwind v4 uses `prefers-color-scheme` by default.
         * This overrides it to use the `dark` class on <html>,
         * so toggleDarkLight() in servicePreview can control it via classList.
         *
         * Must be called BEFORE Tailwind processes the DOM (before the script runs).
         */
        private mountTailwindDarkMode;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private addGlobalCss;
        private addJsReference;
    }
}
declare module "_102020_/l2/previewTextEditor" {
    /**
     * previewTextEditor.ts
     *
     * Helper para identificar a origem de um texto visível no preview
     * e aplicar edições no source .ts correspondente.
     *
     * Três cenários:
     *  1. static  — texto literal no template html`...`  → editável
     *  2. i18n    — texto em blocos message_xx do mesmo arquivo → editável
     *  3. dynamic — texto vindo de fonte externa (API, state, props) → NÃO editável
     */
    export type TextOrigin = IStaticOrigin | II18nOrigin | IDynamicOrigin;
    export interface IStaticOrigin {
        type: 'static';
        /** Posição (offset) no source onde o texto começa */
        startOffset: number;
        /** Posição (offset) no source onde o texto termina */
        endOffset: number;
        /** Texto original encontrado no source */
        originalText: string;
    }
    export interface II18nOrigin {
        type: 'i18n';
        /** Chave no objeto de mensagens (ex: 'login') */
        key: string;
        /** Expressão no template (ex: 'this.msg.login') */
        templateExpression: string;
        /** Todas as ocorrências nos objetos de mensagem, por idioma */
        languages: II18nEntry[];
    }
    export interface II18nEntry {
        /** Nome do objeto (ex: 'message_en') */
        objectName: string;
        /** Idioma (ex: 'en') */
        lang: string;
        /** Valor atual */
        value: string;
        /** Offset no source onde o valor (string literal) começa (inclui aspas) */
        startOffset: number;
        /** Offset no source onde o valor (string literal) termina (inclui aspas) */
        endOffset: number;
    }
    export interface IDynamicOrigin {
        type: 'dynamic';
        /** Explicação de por que não é editável */
        reason: string;
    }
    export interface IEditResult {
        success: boolean;
        newSource?: string;
        error?: string;
    }
    /**
     * Identifica a origem de um texto visível no preview.
     *
     * @param text - Texto visível no preview (ex: "Login")
     * @param source - Conteúdo completo do arquivo .ts
     * @returns Origem do texto
     */
    export function findTextOrigin(text: string, source: string): TextOrigin;
    /**
     * Aplica uma edição de texto no source.
     *
     * @param origin - Origem retornada por findTextOrigin
     * @param newText - Novo texto
     * @param source - Conteúdo completo do arquivo .ts
     * @param lang - Idioma atual (para i18n, edita só esse idioma). Se undefined, edita todos.
     * @returns Resultado com o novo source
     */
    export function applyTextEdit(origin: TextOrigin, newText: string, source: string, lang?: string): IEditResult;
    /**
     * Representa uma expressão ${...} no template, na ordem em que aparece.
     */
    export interface ITemplateExpression {
        /** Índice sequencial da expressão no template (0, 1, 2, ...) */
        index: number;
        /** Expressão completa (ex: 'this.msg.login') */
        expression: string;
        /** Se é i18n, a chave extraída (ex: 'login'). null se não for padrão i18n */
        i18nKey: string | null;
        /** Tipo detectado: 'i18n' | 'static-text' | 'dynamic' */
        type: 'i18n' | 'dynamic';
        /** Offset no source onde a expressão começa (depois do ${) */
        startOffset: number;
        /** Offset no source onde a expressão termina (antes do }) */
        endOffset: number;
    }
    /**
     * Constrói um mapa ordenado de todas as expressões ${...} no template html`...` do render().
     * A ordem corresponde à ordem dos nós de texto no DOM renderizado.
     *
     * @param source - Conteúdo completo do arquivo .ts
     * @returns Lista ordenada de expressões
     */
    export function buildTemplateMap(source: string): ITemplateExpression[];
    /**
     * Encontra a origem do texto usando o índice da expressão no DOM.
     *
     * Fluxo:
     *  1. Constrói o mapa de expressões do template
     *  2. Usa o expressionIndex para encontrar a expressão exata
     *  3. Se é i18n, retorna a chave correta (sem ambiguidade)
     *  4. Se não, faz fallback para busca por texto
     *
     * @param text - Texto visível no preview
     * @param source - Conteúdo do .ts
     * @param expressionIndex - Índice da expressão ${...} no template (posição no DOM)
     */
    export function findTextOriginByIndex(text: string, source: string, expressionIndex: number): TextOrigin;
    /**
     * Resolve a origem i18n DIRETAMENTE pela chave, sem qualquer ambiguidade.
     *
     * Este é o caminho 100% correto: usado quando o DOM carrega a chave via
     * data-i18n-key (emitido pelo helper t()). Não depende de contagem de
     * ocorrência, de ordem no DOM, nem de o texto bater com algum literal —
     * portanto resolve corretamente chaves distintas com o MESMO valor
     * (ex: formaPagamento vs colFormaPagamento).
     *
     * @param key - Chave i18n (ex: 'colFormaPagamento')
     * @param source - Conteúdo completo do arquivo .ts
     * @param _lang - Idioma atual (não usado na resolução; a edição por idioma
     *                acontece em applyTextEdit). Mantido por simetria de assinatura.
     */
    export function findTextOriginByKey(key: string, source: string, _lang?: string): TextOrigin;
    /**
     * Finds ALL i18n keys whose value matches the given text.
     * Returns them in declaration order.
     */
    export function findAllI18nMatches(text: string, source: string, lang?: string): {
        key: string;
        origin: II18nOrigin;
    }[];
    /**
     * Resolves text origin using DOM occurrence index to disambiguate
     * when multiple i18n keys have the same value.
     *
     * NOTA: este é o caminho de FALLBACK, usado apenas para texto que não foi
     * tagueado com data-i18n-key. Para resolução determinística, prefira
     * findTextOriginByKey.
     *
     * @param text - Visible text
     * @param source - Full .ts source
     * @param occurrenceIndex - Which occurrence of this text in the DOM (0-based)
     * @param lang - Current language
     */
    export function findTextOriginByOccurrence(text: string, source: string, occurrenceIndex: number, lang?: string): TextOrigin;
    export interface ITagReplaceResult {
        success: boolean;
        newSource?: string;
        /** Número de ocorrências substituídas (abertura + fechamento) */
        replacements?: number;
        error?: string;
    }
    /**
     * Substitui uma ocorrência específica ou todas as ocorrências de uma tag
     * de web component no template do render().
     *
     * Também gerencia os imports:
     * - Se oldTag ainda existe no template após a troca → mantém import antigo E adiciona novo
     * - Se oldTag não existe mais → remove import antigo e adiciona novo
     * - Se import do newTag já existe → não duplica
     *
     * @param oldTag - Tag atual (ex: 'ml-floating-text-input')
     * @param newTag - Nova tag (ex: 'ml-new-text-input')
     * @param source - Conteúdo completo do arquivo .ts
     * @param selectorPath - Path do elemento selecionado no DOM
     * @param mode - 'selected' troca só o selecionado, 'all' troca todas as ocorrências
     * @returns Resultado com o novo source
     */
    export function replaceComponentTag(oldTag: string, newTag: string, source: string, selectorPath?: string, mode?: 'selected' | 'all'): ITagReplaceResult;
}
declare module "_102020_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/collabSelectKnob" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class SelectOneKnobWidget extends StateLitElement {
        min: number;
        max: number;
        value: number | null;
        step: number;
        disabled: boolean;
        active: boolean;
        selected: boolean;
        showTicks: boolean;
        private _focused;
        private _editing;
        private _dragStartY;
        private _dragStartValue;
        private _dragging;
        private _pendingDigit;
        private _digitTimeout;
        private _pendingDisplay;
        private _pendingInvalid;
        private get _hasValue();
        private get _rotation();
        private get _tickCount();
        private get _displayValue();
        private get _displayHidden();
        private get _canInteract();
        private _clamp;
        private _setValue;
        private _cycleValue;
        private _onKeyDown;
        private _cancelDigitInput;
        private _onMouseDown;
        private _onWheel;
        private _onFocus;
        private _onBlur;
        private _onDisplayClick;
        private _onClick;
        private _renderTicks;
        render(): any;
    }
}
declare module "_102020_/l2/serviceExploreProjects" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabSelectKnob";
    import '/_102020_/l2/plugins/selectOrganization.js';
    import '/_102020_/l2/plugins/selectProject.js';
    import '/_102020_/l2/plugins/selectDesignSystem.js';
    import '/_102020_/l2/plugins/selectLanguage.js';
    export class ServiceExploreProjects102020 extends ServiceBase {
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        private msg;
        private _orgs;
        private _orgConfig;
        private _orgValue;
        private _projectValue;
        private _dsValue;
        private _langValue;
        private _selectedKnob;
        private _projectConfig;
        private _dsConfig;
        private _langConfig;
        private _loadOrgs;
        private _initLangConfig;
        private _getOrgsFromMls;
        private _buildOrgConfig;
        private _buildProjectConfigFromOrg;
        private get _selectedOrg();
        private get _selectedProject();
        private get _knobValues();
        private _getKnobConfig;
        private _setKnobValue;
        private _onKnobChange;
        private _onKnobClick;
        private _onLangConfig;
        private _onDsConfig;
        private _initDsConfig;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): any;
        private _renderKnobRow;
        private _renderKnobItem;
        private _renderDetailsRow;
        private _renderContextStatusArea;
    }
}
declare module "_102020_/l2/serviceGenome" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabSelectKnob";
    import '/_102020_/l2/plugins/selectLayout.js';
    import '/_102020_/l2/plugins/selectDesignSystem.js';
    import '/_102020_/l2/plugins/selectMolecule.js';
    export class ServiceGenome102020 extends ServiceBase {
        details: IService;
        onClickMain(_op: string): void;
        menu: IServiceMenu;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): Promise<void>;
        private msg;
        private _layoutValue;
        private _currentPageFile;
        private _isPageContext;
        private _dsValue;
        private _moleculesValue;
        private _selectedKnob;
        private _layoutConfig;
        private _dsConfig;
        private _moleculesConfig;
        private _selectedMoleculeGroup;
        private _selectedMoleculeGroupDescription;
        private _selectedMoleculeFiles;
        private _oldSelectedTag;
        private _moleculeError;
        private _moleculeReplaceMode;
        private _actualPage;
        handleIcaStateChange(key: string, value: any): void;
        private _loadProjectConfig;
        private _initLayoutKnob;
        private _initDsKnob;
        private _onDsConfig;
        private _getMolecules;
        private _isWebComponent;
        private _extractGroupFromTag;
        private _onPreviewSelectedElementChanged;
        private _onMoleculesChanged;
        private get _knobValues();
        private _getKnobConfig;
        private _setKnobValue;
        private _onKnobChange;
        private _onKnobClick;
        private setLastOpenedFileIfNeeded;
        private _getActual3File;
        private _trySetActualModule;
        private _updateCurrentPage;
        private _onFileActionGenome;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        firstUpdated(): Promise<void>;
        createRenderRoot(): this;
        render(): any;
        private _renderKnobRow;
        private _renderKnobItem;
        private _renderDetailsRow;
        private _renderContextStatusArea;
    }
}
declare module "_102020_/l2/servicePage" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabSelectKnob";
    import '/_102020_/l2/plugins/selectPage.js';
    import '/_102020_/l2/plugins/selectRule.js';
    export class ServicePage102020 extends ServiceBase {
        details: IService;
        onClickMain(_op: string): void;
        menu: IServiceMenu;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        private msg;
        private _modules;
        private _pageConfig;
        private _ruleConfig;
        private _pageValue;
        private _ruleValue;
        private _reloadToken;
        private _pageEntries;
        private _selectedKnob;
        private _loadData;
        private get _selectedModule();
        private get _knobValues();
        private _getKnobConfig;
        private _setKnobValue;
        private _onKnobChange;
        private _onKnobClick;
        private _onPageSelect;
        private _setActualPage;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): any;
        private _renderKnobRow;
        private _renderKnobItem;
        private _onPageConfig;
        private _onRuleConfig;
        private _renderDetailsRow;
        private _renderContextStatusArea;
    }
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_pin: any;
    export const collab_star: any;
    export const collab_paperclip: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_circle_check: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'heading';
        level: number;
        children: RichToken[];
    } | {
        type: 'horizontal-rule';
    } | {
        type: 'blockquote';
        children: RichToken[];
        lines: RichToken[][];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichListItem[];
    };
    export interface RichListItem {
        marker: string;
        children: RichToken[];
    }
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPromptEditing" {
    export interface EditResult {
        text: string;
        selectionStart: number;
        selectionEnd: number;
    }
    interface LineInfo {
        start: number;
        end: number;
        text: string;
    }
    interface ListMarker {
        indent: string;
        marker: string;
        spacing: string;
        content: string;
        ordered: boolean;
    }
    export function getLineInfo(text: string, cursor: number): LineInfo;
    export function replaceRange(text: string, start: number, end: number, value: string, cursorOffset?: number): EditResult;
    export function insertText(text: string, selectionStart: number, selectionEnd: number, value: string, cursorOffset?: number): EditResult;
    export function getListMarker(line: string): ListMarker | undefined;
    export function getNextListPrefix(marker: ListMarker): string;
    export function applySmartNewline(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function indentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function outdentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function wrapSelection(text: string, selectionStart: number, selectionEnd: number, before: string, after: string, placeholder?: string): EditResult;
    export function makeCodeBlock(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function makeLinePrefix(text: string, selectionStart: number, selectionEnd: number, prefix: string): EditResult;
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export function serializeUserMentions(text: string, users: msg.User[]): string;
    export function deserializeUserMentions(text: string, users?: msg.User[]): string;
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        hasSelection: boolean;
        selectedFiles: File[];
        sendError: string;
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        allowAttachments: boolean;
        showSubmitButton: boolean;
        submitOnEnter: boolean;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderRichToken;
        private renderRichOverlay;
        render(): any;
        private renderToolbar;
        private renderReply;
        private renderSelectedAttachments;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private preventToolbarFocus;
        private updateSelectionState;
        private clearSelectionState;
        private applyEditResult;
        private applyInlineFormat;
        private applyCodeBlock;
        private applyLinePrefix;
        private applyLink;
        private openAttachmentPicker;
        private handleAttachmentInput;
        private removeSelectedAttachment;
        private emitTextChange;
        private formatFileSize;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private handlePaste;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102027_/l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        private collab_chevron_down;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "_102027_/l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed102027 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        private collab_chevron_right;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "_102020_/l2/servicePreview" {
    import "_102025_/l2/collabMessagesPrompt";
    import "_102027_/l2/collabSpliterVerticalVarFixed";
    import "_102027_/l2/collabSpliterHorizontalVarFixed";
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServicePreview extends ServiceBase {
        private msg;
        private languages;
        private tasksInProgress;
        private monacoEditor;
        private _ed1;
        private threadCache;
        elPreview: HTMLIFrameElement | undefined;
        modePreview: PreviewMode;
        watch: boolean;
        light: boolean;
        msize: string;
        lang: string;
        actualFiles: mls.stor.IInfo | undefined;
        actualModels: mls.editor.IModels;
        actualTheme: string;
        project: number;
        shortName: string;
        folder: string;
        hasErrorLess: boolean;
        get page(): string;
        get confE(): string;
        get isL3(): boolean;
        get isL4(): boolean;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onClickTools(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        handleIcaStateChange(key: string, value: any): void;
        private initStatesPreview;
        private initStatesPreviewL3;
        private initStatesPreviewL4;
        private toogleWatch;
        private toggleDarkLight;
        private changeFilePreview;
        private changeLanguagePreview;
        private onChangeLanguage;
        private getIframePreviewHTML;
        private onStyleChanged;
        private onFileAction;
        private setActualFileInfos;
        private setLastOpenedFile;
        private setActualFiles;
        private setActualModels;
        private createPreview;
        private writePreviewContent;
        private modeSinglePage;
        private updatePreviewMode;
        private clearPreview;
        private setLanguages;
        private configureTools;
        private addStyles;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private createEditor;
        private setModel;
        private createModelIfNeeded;
        handleSend(value: string, opt: {
            isSpecialMention: boolean;
            agentName: string;
        }): Promise<void>;
        private onTaskChange;
        private updateLoadingToFalseIfNoTasksRunning;
        private fireCollab;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
    }
    type PreviewMode = 'Desktop' | 'Mobile';
}
declare module "_102020_/l2/serviceProject" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabSelectKnob";
    import '/_102020_/l2/plugins/selectModule.js';
    import '/_102020_/l2/plugins/selectDesignSystem.js';
    import '/_102020_/l2/plugins/selectDevice.js';
    import '/_102020_/l2/plugins/selectAssetsComponents.js';
    import '/_102020_/l2/plugins/selectAssetsPlugins.js';
    import '/_102020_/l2/plugins/selectAssetsMedia.js';
    export class ServiceProject102020 extends ServiceBase {
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        private msg;
        private _modules;
        private _moduleConfig;
        private _moduleValue;
        private _dsValue;
        private _deviceValue;
        private _assetsValue;
        private _selectedKnob;
        private _dsConfig;
        private _deviceConfig;
        private _assetsConfig;
        private _loadModules;
        private _initDsConfig;
        private _buildModuleConfig;
        private get _selectedModule();
        private get _knobValues();
        private _getKnobConfig;
        private _setKnobValue;
        private _onKnobChange;
        private _onKnobClick;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): any;
        private _renderKnobRow;
        private _renderKnobItem;
        private _renderDetailsRow;
        private _renderContextStatusArea;
        private _renderAssetsPanel;
    }
}
declare module "_102020_/l2/start" {
    export function start(): void;
}
declare module "_102020_/l2/taskManager" {
    export type TaskStatus = 'running' | 'done' | 'error';
    export interface ITask {
        status: TaskStatus;
        startedAt: number;
        message?: string;
        messageId?: string;
        taskId?: string;
        taskData?: any;
        taskMessage?: any;
    }
    export function setTask(key: string, task: ITask): void;
    export function getTask(key: string): ITask | undefined;
    export function getTasksByScope(scope: string): Map<string, ITask>;
    export function hasRunning(scope: string): boolean;
    export function clearScope(scope: string): void;
    export function subscribeTaskManager(listener: () => void): () => void;
}
declare module "_102020_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function isPageFile(folder: string): boolean;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102020_/l2/widgetGenoma" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import "_102027_/l2/collabSelectKnob";
    export class WidgetGenoma102020 extends StateLitElement {
        private currentView;
        private selectedGroup;
        private knobIndex;
        private filterCategory;
        private groupWidgetTags;
        private importedTags;
        private categoryMeta;
        connectedCallback(): void;
        private buildGroupWidgetTags;
        private handleGroupSelect;
        private handleBackToGrid;
        private importAndRenderWidget;
        private updateDemoContainer;
        private handleKnobChange;
        private handlePillClick;
        private handleFilterChange;
        private getFilteredGroups;
        private getActiveCategories;
        render(): any;
        private renderGridView;
        private renderGroupCard;
        private renderKnobView;
    }
}
declare module "_102020_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_102027_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateBoolean" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class WcInputBoolean102020 extends CollabLitElement {
        value: boolean;
        name: string | undefined;
        label: string | undefined;
        disabled: boolean;
        hint: string | undefined;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateNumber" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class WcInputNumber102020 extends CollabLitElement {
        value: number | undefined;
        name: string | undefined;
        label: string | undefined;
        min: number | undefined;
        max: number | undefined;
        step: number | undefined;
        placeholder: string | undefined;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        hint: string | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStatePreviewCode" {
    import { TemplateResult, LitElement } from 'lit';
    export class PlaygroundStatePreviewCode extends LitElement {
        protected createRenderRoot(): HTMLElement | DocumentFragment;
        target: string;
        language: string;
        private code;
        private targetElement;
        private hljsLoaded;
        private codeEditor;
        firstUpdated(): Promise<void>;
        private loadHljs;
        private getSourceCode;
        private initContent;
        private formatHtml;
        private highlightCode;
        private debounceTimer;
        private handleInput;
        private updateDemo;
        private setStateDeep;
        private savedRange;
        private savedOffset;
        private saveSelection;
        private restoreSelection;
        private handleKeyDown;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateText" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class WidgetPlaygroundStateText extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/agentNewSolution/agentDiscoverSolutionScope" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export const DISCOVER_SOLUTION_SCOPE_TOOL_NAME = "submitSolutionScopeDraft";
    export const DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION = "2026-06-02";
    export const DISCOVER_SOLUTION_SCOPE_STEP_ID = "03-discover-scope";
    type ScopeStatus = 'ok' | 'needs_input' | 'failed';
    type Priority = 'now' | 'soon' | 'later' | 'never';
    export interface RequirementsClarificationAnswer {
        title: string;
        userLanguage: string;
        answers: Record<string, string | boolean | string[]>;
    }
    export interface SolutionScopeActor {
        actorId: string;
        title?: string;
        description: string;
    }
    export interface SolutionScopeCapability {
        capabilityId: string;
        title?: string;
        description?: string;
        actor: string;
        priority: Priority;
    }
    export interface SolutionArtifactSignal {
        signal: string;
        title?: string;
        actor?: string;
        reason: string;
        priority?: Priority;
        mdmKind?: string;
    }
    export interface SolutionScopeDraft {
        domain: string;
        summary: string;
        actors: SolutionScopeActor[];
        capabilities: SolutionScopeCapability[];
        artifactSignals: {
            pages: SolutionArtifactSignal[];
            workflows: SolutionArtifactSignal[];
            plugins: SolutionArtifactSignal[];
            agents: SolutionArtifactSignal[];
            horizontalModules: SolutionArtifactSignal[];
            mdm: SolutionArtifactSignal[];
            metrics: SolutionArtifactSignal[];
            usecases: SolutionArtifactSignal[];
        };
        businessRisks: string[];
        missingContext: string[];
    }
    export interface DiscoverSolutionScopeOutput {
        runId: string;
        stepId: typeof DISCOVER_SOLUTION_SCOPE_STEP_ID;
        schemaVersion: typeof DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION;
        status: ScopeStatus;
        result: SolutionScopeDraft;
        questions: string[];
        trace: string[];
    }
    export interface DiscoverSolutionScopeToolArguments {
        type: 'flexible';
        result: DiscoverSolutionScopeOutput;
    }
    export interface DiscoverSolutionScopeToolCall {
        toolName: typeof DISCOVER_SOLUTION_SCOPE_TOOL_NAME;
        arguments: DiscoverSolutionScopeToolArguments | DiscoverSolutionScopeOutput | string;
    }
    export type Output = {
        type: 'flexible';
        result: DiscoverSolutionScopeOutput | DiscoverSolutionScopeToolCall | DiscoverSolutionScopeToolArguments;
    } | DiscoverSolutionScopeToolCall | {
        type: 'result';
        result: string;
    };
    export const discoverSolutionScopeToolSchema: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitSolutionScopeDraft";
            readonly description: "Submit a validated scope draft for the newSolution planner.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["type", "result"];
                readonly properties: {
                    readonly type: {
                        readonly const: "flexible";
                    };
                    readonly result: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["runId", "stepId", "schemaVersion", "status", "result", "questions", "trace"];
                        readonly properties: {
                            readonly runId: {
                                readonly type: "string";
                            };
                            readonly stepId: {
                                readonly const: "03-discover-scope";
                            };
                            readonly schemaVersion: {
                                readonly const: "2026-06-02";
                            };
                            readonly status: {
                                readonly enum: readonly ["ok", "needs_input", "failed"];
                            };
                            readonly result: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["domain", "summary", "actors", "capabilities", "artifactSignals", "businessRisks", "missingContext"];
                                readonly properties: {
                                    readonly domain: {
                                        readonly type: "string";
                                    };
                                    readonly summary: {
                                        readonly type: "string";
                                    };
                                    readonly actors: {
                                        readonly type: "array";
                                        readonly items: {
                                            readonly type: "object";
                                            readonly additionalProperties: false;
                                            readonly required: readonly ["actorId", "description"];
                                            readonly properties: {
                                                readonly actorId: {
                                                    readonly type: "string";
                                                };
                                                readonly title: {
                                                    readonly type: "string";
                                                };
                                                readonly description: {
                                                    readonly type: "string";
                                                };
                                            };
                                        };
                                    };
                                    readonly capabilities: {
                                        readonly type: "array";
                                        readonly items: {
                                            readonly type: "object";
                                            readonly additionalProperties: false;
                                            readonly required: readonly ["capabilityId", "actor", "priority"];
                                            readonly properties: {
                                                readonly capabilityId: {
                                                    readonly type: "string";
                                                };
                                                readonly title: {
                                                    readonly type: "string";
                                                };
                                                readonly description: {
                                                    readonly type: "string";
                                                };
                                                readonly actor: {
                                                    readonly type: "string";
                                                };
                                                readonly priority: {
                                                    readonly enum: readonly ["now", "soon", "later", "never"];
                                                };
                                            };
                                        };
                                    };
                                    readonly artifactSignals: {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["pages", "workflows", "plugins", "agents", "horizontalModules", "mdm", "metrics", "usecases"];
                                        readonly properties: {
                                            readonly pages: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly workflows: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly plugins: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly agents: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly horizontalModules: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly mdm: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly metrics: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                            readonly usecases: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly $ref: "#/$defs/artifactSignal";
                                                };
                                            };
                                        };
                                    };
                                    readonly businessRisks: {
                                        readonly type: "array";
                                        readonly items: {
                                            readonly type: "string";
                                        };
                                    };
                                    readonly missingContext: {
                                        readonly type: "array";
                                        readonly items: {
                                            readonly type: "string";
                                        };
                                    };
                                };
                            };
                            readonly questions: {
                                readonly type: "array";
                                readonly items: {
                                    readonly type: "string";
                                };
                            };
                            readonly trace: {
                                readonly type: "array";
                                readonly items: {
                                    readonly type: "string";
                                };
                            };
                        };
                    };
                };
                readonly $defs: {
                    readonly artifactSignal: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["signal", "reason"];
                        readonly properties: {
                            readonly signal: {
                                readonly type: "string";
                            };
                            readonly title: {
                                readonly type: "string";
                            };
                            readonly actor: {
                                readonly type: "string";
                            };
                            readonly reason: {
                                readonly type: "string";
                            };
                            readonly priority: {
                                readonly enum: readonly ["now", "soon", "later", "never"];
                            };
                            readonly mdmKind: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
    };
    export function extractDiscoverSolutionScopeOutput(payload: unknown): DiscoverSolutionScopeOutput;
    export function wantsInitialMetricsDashboard(answer?: RequirementsClarificationAnswer): boolean;
    export function getDiscoverSolutionScopeOutput(context: mls.msg.ExecutionContext): DiscoverSolutionScopeOutput;
    export function getDiscoverSolutionScopeDraft(context: mls.msg.ExecutionContext): SolutionScopeDraft;
}
declare module "_102020_/l2/agentNewSolution/agentNewSolution" {
    import { IAgentAsync, IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export const PLAN_IDS: readonly ["org-requirements", "org-planner", "org-materialization", "req-discover-scope", "req-clarification-answer", "req-recommend-implementations", "req-implementation-decisions", "plan-solution-blueprint", "plan-blueprint-review", "plan-finalize-solution-plan", "plan-mdm", "plan-horizontals", "plan-plugins", "plan-persistence-index", "plan-table-definition", "plan-metrics-index", "plan-metric-table-definition", "plan-usecase-entities", "plan-workflow-index", "plan-workflow-definition", "plan-agents", "plan-page-index", "plan-page-definition", "plan-validate-solution-coverage"];
    export type NewSolutionPlanId = typeof PLAN_IDS[number];
    export type Output = {
        type: 'flexible';
        result: InitialNewSolutionPlan;
    } | {
        type: 'result';
        result: string;
    };
    export interface InitialNewSolutionPlan {
        userLanguage: string;
        requestKind: 'module' | 'solution' | 'module_solution';
        userPrompt: string;
        titles: Partial<Record<NewSolutionPlanId, string>>;
        todoItems: {
            planId: NewSolutionPlanId;
            done: boolean;
            title: string;
            description: string;
        }[];
        openDetails: {
            title: string;
            description: string;
        }[];
    }
    export function getInitialNewSolutionPlan(agent: IAgentMeta, context: mls.msg.ExecutionContext): InitialNewSolutionPlan;
}
declare module "_102020_/l2/agentNewSolution/agentNewSolutionPlanner" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102020_/l2/agentNewSolution/agentNewSolutionRequirements" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { ImplementationRecommendation } from '_102020_/l2/agentNewSolution/agentRecommendImplementations';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: 'clarification';
        json: RequirementsClarification;
    } | {
        type: 'result';
        result: string;
    };
    export interface RequirementsClarification {
        userLanguage: string;
        title: string;
        userPrompt: string;
        questions: Record<string, RequirementsQuestion>;
        legends: string[];
    }
    export interface RequirementsQuestion {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer: string | boolean;
        options?: {
            id: string;
            label: string;
        }[];
    }
    export interface RequirementsClarificationAnswer {
        title: string;
        userLanguage: string;
        answers: Record<string, string | boolean>;
    }
    type ImplementationDecisionPriority = 'now' | 'soon' | 'later' | 'never';
    export interface ImplementationDecisionItem {
        recommendationId: string;
        artifactType: ImplementationRecommendation['artifactType'];
        title: string;
        description: string;
        originalPriority: ImplementationDecisionPriority;
        defaultPriority: ImplementationDecisionPriority;
        decidedPriority: ImplementationDecisionPriority;
        accepted: boolean;
        requiresClientDecision: boolean;
        dependencies: string[];
        reason: string;
    }
    export interface ImplementationDecisionResult {
        title: string;
        userLanguage: string;
        sourceStepId: string;
        sourceSchemaVersion: string;
        decisions: ImplementationDecisionItem[];
        trace: string[];
    }
    export function getRequirementsClarificationAnswer(context: mls.msg.ExecutionContext): RequirementsClarificationAnswer;
}
declare module "_102020_/l2/agentNewSolution/agentRecommendImplementations" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export const RECOMMEND_IMPLEMENTATIONS_TOOL_NAME = "submitImplementationRecommendations";
    export const RECOMMEND_IMPLEMENTATIONS_SCHEMA_VERSION = "2026-06-02";
    export const RECOMMEND_IMPLEMENTATIONS_STEP_ID = "04-recommend-implementations";
    type RecommendationStatus = 'ok' | 'needs_input' | 'failed';
    type Priority = 'now' | 'soon' | 'later' | 'never';
    type ArtifactType = 'page' | 'workflow' | 'plugin' | 'agent' | 'horizontalModule' | 'mdm' | 'ontology' | 'metric' | 'metricTable' | 'usecaseEntity';
    export interface ImplementationRecommendation {
        recommendationId: string;
        artifactType: ArtifactType;
        title: string;
        description: string;
        priority: Priority;
        defaultPriority: Priority;
        reason: string;
        requiresClientDecision: boolean;
        dependencies: string[];
    }
    export interface RecommendImplementationsOutput {
        runId: string;
        stepId: typeof RECOMMEND_IMPLEMENTATIONS_STEP_ID;
        schemaVersion: typeof RECOMMEND_IMPLEMENTATIONS_SCHEMA_VERSION;
        status: RecommendationStatus;
        result: {
            recommendations: ImplementationRecommendation[];
        };
        questions: string[];
        trace: string[];
    }
    export interface RecommendImplementationsToolArguments {
        type: 'flexible';
        result: RecommendImplementationsOutput;
    }
    export interface RecommendImplementationsToolCall {
        toolName: typeof RECOMMEND_IMPLEMENTATIONS_TOOL_NAME;
        arguments: RecommendImplementationsToolArguments | RecommendImplementationsOutput | string;
    }
    export type Output = {
        type: 'flexible';
        result: RecommendImplementationsOutput | RecommendImplementationsToolCall | RecommendImplementationsToolArguments;
    } | RecommendImplementationsToolCall | {
        type: 'result';
        result: string;
    };
    export const recommendImplementationsToolSchema: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitImplementationRecommendations";
            readonly description: "Submit prioritized implementation recommendations for the newSolution planner.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["type", "result"];
                readonly properties: {
                    readonly type: {
                        readonly const: "flexible";
                    };
                    readonly result: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["runId", "stepId", "schemaVersion", "status", "result", "questions", "trace"];
                        readonly properties: {
                            readonly runId: {
                                readonly type: "string";
                            };
                            readonly stepId: {
                                readonly const: "04-recommend-implementations";
                            };
                            readonly schemaVersion: {
                                readonly const: "2026-06-02";
                            };
                            readonly status: {
                                readonly enum: readonly ["ok", "needs_input", "failed"];
                            };
                            readonly result: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["recommendations"];
                                readonly properties: {
                                    readonly recommendations: {
                                        readonly type: "array";
                                        readonly items: {
                                            readonly type: "object";
                                            readonly additionalProperties: false;
                                            readonly required: readonly ["recommendationId", "artifactType", "title", "description", "priority", "defaultPriority", "reason", "requiresClientDecision", "dependencies"];
                                            readonly properties: {
                                                readonly recommendationId: {
                                                    readonly type: "string";
                                                };
                                                readonly artifactType: {
                                                    readonly enum: readonly ["page", "workflow", "plugin", "agent", "horizontalModule", "mdm", "ontology", "metric", "metricTable", "usecaseEntity"];
                                                };
                                                readonly title: {
                                                    readonly type: "string";
                                                };
                                                readonly description: {
                                                    readonly type: "string";
                                                };
                                                readonly priority: {
                                                    readonly enum: readonly ["now", "soon", "later", "never"];
                                                };
                                                readonly defaultPriority: {
                                                    readonly enum: readonly ["now", "soon", "later", "never"];
                                                };
                                                readonly reason: {
                                                    readonly type: "string";
                                                };
                                                readonly requiresClientDecision: {
                                                    readonly type: "boolean";
                                                };
                                                readonly dependencies: {
                                                    readonly type: "array";
                                                    readonly items: {
                                                        readonly type: "string";
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                            readonly questions: {
                                readonly type: "array";
                                readonly items: {
                                    readonly type: "string";
                                };
                            };
                            readonly trace: {
                                readonly type: "array";
                                readonly items: {
                                    readonly type: "string";
                                };
                            };
                        };
                    };
                };
            };
        };
    };
    export function getRecommendImplementationsOutput(context: mls.msg.ExecutionContext): RecommendImplementationsOutput;
}
declare module "_102020_/l2/agents/agentAddLanguage" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        i18n: string;
        fileReference: string;
    };
}
declare module "_102020_/l2/agents/agentRemoveLanguage" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        i18n: string;
        fileReference: string;
    };
}
declare module "_102020_/l2/agents/molecules/agentImproveMolecule" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: TClarification;
    } | {
        type: "flexible";
        result: IDataPrompt;
    };
    export interface TClarification {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
    interface IDataPrompt {
        page: string;
        prompt: string;
    }
}
declare module "_102020_/l2/agents/molecules/agentImproveMoleculeDefs" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference?: string;
        group: string;
        skillMd: string;
    }
}
declare module "_102020_/l2/agents/molecules/agentImproveMoleculeMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        ts: string;
        needsPlayground: boolean;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102020_/l2/agents/molecules/agentIndexGroupPage" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        ts: string;
        html: string;
    };
}
declare module "_102020_/l2/agents/molecules/agentNewMolecule" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function createAgent(): {
        agentName: string;
        agentProject: number;
        agentFolder: string;
        agentDescription: string;
        visibility: string;
        beforePromptImplicit: typeof beforePromptImplicit;
        afterPromptStep: typeof afterPromptStep;
    };
    function beforePromptImplicit(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
    function afterPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export type Output = {
        type: "flexible";
        result: {
            group: string;
            prompt: string;
        };
    } | {
        type: "result";
        result: string;
    };
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculeDefs" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateDefs(skill: string, fileReference: string, group: string): Promise<void>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        group: string;
        skillMd: string;
    }
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculeFix" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        ts: string;
    };
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculeMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        ts: string;
    };
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculePlanner" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: TClarification;
    };
    export interface TClarification {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculePlannerClarification" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export interface ClarificationData {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
    export class AgentNewMoleculePlannerClarification102020 extends StateLitElement {
        private msg;
        data: ClarificationData;
        private _editingField;
        private _editingIndex;
        private _tempValue;
        private _expandedSections;
        private _startEdit;
        private _cancelEdit;
        private _saveEdit;
        private _dispatchChange;
        private _toggleSection;
        private _addRequirement;
        private _removeRequirement;
        private _handleKeydown;
        private _renderEditableField;
        private _renderRequirementsList;
        render(): any;
        private onAction;
    }
}
declare module "_102020_/l2/agents/molecules/agentNewMoleculePlayground" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getSource(file: mls.stor.IFileInfo): Promise<string>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        examples: IExamples[];
        html: string;
    }
    interface IExamples {
        name: string;
        props: [
            {
                name: string;
                value: string;
            }
        ];
        state: {
            stateName: string;
            value: any;
        }[];
    }
}
declare module "_102020_/l2/agents/newModule/agentCreatePersistence" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            srcFile: string;
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentInitializeMock" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            srcFile: string;
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentInitializeModule" {
    import { IAgentAsync, IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output1 = {
        type: "clarification";
        json: Clarification1;
    } | {
        type: "result";
        result: string;
    };
    export interface Clarification1 {
        userLanguage: string;
        title: "Clarification 1/2";
        userPrompt: string;
        questions: {
            roles: Question;
            publicTarget: Question;
            tone: Question;
            languages: Question;
            moduleName: Question;
            visualStyle: Question;
            openQuestion1: Question;
            openQuestion2: Question;
            openQuestion3: Question;
        };
        legends: [
            "This is the first clarification ",
            "before creating somethings"
        ];
    }
    export interface Question {
        type: "open";
        question: string;
        answer: string;
    }
    export function getPayload1(agent: IAgentMeta, context: mls.msg.ExecutionContext): Clarification1;
}
declare module "_102020_/l2/agents/newModule/agentInterfaceOntology" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            outputPath: string;
            srcFile: string;
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: OutputParse;
    };
    export type OutputParse = {
        path: string;
        itens: any;
    };
}
declare module "_102020_/l2/agents/newModule/agentMaterializeContract" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            path: string;
            id: string;
            outputPath: string;
            interfaceOutputPath: string;
            srcFile: string;
            interfaceFile: string;
            routers: {
                router: string;
                funcName: string;
            }[];
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentMaterializePageLit" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            path: string;
            id: string;
            outputPath: string;
            srcFile: string;
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentMaterializeSharedPage" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            path: string;
            id: string;
            outputPath: string;
            srcFile: string;
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentMoleculeMapper" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            path: string;
            map: Array<{
                elementDescription: string;
                group: string;
                variant: string;
                reason: string;
            }>;
            usedGroups: string[];
        };
    };
}
declare module "_102020_/l2/agents/newModule/agentMoleculeRewriter" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            path: string;
            srcFile: string;
        };
    };
}
declare module "_102027_/l2/defsAST" {
    export function parseDefsFile(source: string): {
        asis: mls.defs.AsIs;
        history: mls.defs.ChangeHistoryItem[];
        skill: string;
    };
    export function getAsis(source: string): mls.defs.AsIs;
    export function updateAsis(source: string, patch: DeepPartial<mls.defs.AsIs>): string;
    export function replaceAsis(source: string, value: mls.defs.AsIs): string;
    export function getHistory(source: string): mls.defs.ChangeHistoryItem[];
    export function addHistoryItem(source: string, item: mls.defs.ChangeHistoryItem): string;
    export function updateHistoryItem(source: string, version: number, patch: Partial<mls.defs.ChangeHistoryItem>): string;
    export function replaceHistory(source: string, value: mls.defs.ChangeHistoryItem[]): string;
    export function getSkill(source: string): string;
    export function updateSkill(source: string, value: string): string;
    type DeepPartial<T> = {
        [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
    };
    export function getMaterializeIndex(source: string): mls.defs.MaterializeIndex;
    export function replaceMaterializeIndex(source: string, value: mls.defs.MaterializeIndex): string;
    export function addMaterializeItem(source: string, item: mls.defs.MaterializeEntry): string;
    export function updateMaterializeItem(source: string, id: string, patch: Partial<mls.defs.MaterializeEntry>): string;
    export function removeMaterializeItem(source: string, id: string): string;
    export function getVariableText(source: string, varName: string): string;
    export function updateVariableText(source: string, varName: string, value: string): string;
    export function getVariableJson<T = unknown>(source: string, varName: string): T;
    export function updateVariableJson(source: string, varName: string, value: unknown): string;
}
declare module "_102020_/l2/agents/newModule/agentOntologyGapCheck" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: GapCheckResult;
    };
    export type GapCheckResult = {
        hasGaps: false;
        summary: string;
    } | {
        hasGaps: true;
        summary: string;
        newEntities: Record<string, EntityDefinition>;
    };
    export interface EntityDefinition {
        description?: string;
        fields: Record<string, EntityField>;
        rules?: string[];
    }
    export interface EntityField {
        type: string;
        required?: boolean;
        values?: string[];
        constraints?: string;
    }
}
declare module "_102020_/l2/agents/newModule/agentToBeConceptual" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export const outputPrompt = "\n## Output format\nYou must return the object strictly as JSON\n[[OutputSection]]\n\n[[Defs1]]\n";
    export type Output = {
        type: "flexible";
        result: ModuleToBe;
    } | {
        type: "result";
        result: string;
    };
    export interface ModuleToBe {
        meta: {
            userLanguage: string;
            moduleName: string;
            userPromptOriginal: string;
            userPromptFinal: string;
        };
        ui: {
            visualStyle: string;
        };
        ontology?: OntologyDefinition;
        rules?: RulesRegistry;
        capabilities?: CapabilityMap;
    }
    export interface OntologyDefinition {
        entities: Record<string, EntityDefinition>;
    }
    export interface EntityDefinition {
        description?: string;
        fields: Record<string, EntityField>;
        rules?: string[];
    }
    export interface EntityField {
        type: string;
        required?: boolean;
        values?: string[];
        constraints?: string;
    }
    export interface RulesRegistry {
        [ruleId: string]: RuleDefinition;
    }
    export interface RuleDefinition {
        kind: "domain" | "platform" | "policy";
        description: string;
        scope?: string[];
        acceptanceCriteria?: string[];
    }
    export interface CapabilityMap {
        [capabilityId: string]: CapabilityDefinition;
    }
    export interface CapabilityDefinition {
        description?: string;
        usesRules?: string[];
        isOptional?: boolean;
        actions?: CapabilityAction[];
    }
    export interface CapabilityAction {
        actionId: string;
        description?: string;
    }
}
declare module "_102020_/l2/agents/newModule/agentToBeConceptual2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output3 = {
        type: "clarification";
        json: Suggestions;
    };
    export interface Suggestions {
        suggestions: Suggestion[];
    }
    export interface Suggestion {
        suggestion: string;
        customerPerception: string;
        businessImpact: string[];
        requiresConfiguration: boolean;
        yagni: "now" | "soon" | "later" | "no" | "unknown";
    }
}
declare module "_102020_/l2/agents/newModule/agentToBeConceptual2Clarification" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { Suggestion } from '_102020_/l2/agents/newModule/agentToBeConceptual2';
    import { ModuleToBe, RulesRegistry, EntityDefinition, CapabilityDefinition } from '_102020_/l2/agents/newModule/agentToBeConceptual';
    export class AgentToBeConceptual2Clarification extends CollabLitElement {
        entitiesCount: number;
        rulesCount: number;
        capabilitiesCount: number;
        suggestions: Suggestion[];
        toBe?: ModuleToBe;
        rules?: RulesRegistry;
        capabilities?: CapabilityDefinition;
        entities?: Record<string, EntityDefinition> | undefined;
        get suggestionsCount(): number;
        private editorEntities?;
        private editorRules?;
        private editorCapabilities?;
        private badgePop;
        private suggestionState;
        private isAdding;
        private activeTab;
        private editors;
        private renderedTabs;
        firstUpdated(changed: Map<string, any>): void;
        updated(changed: Map<string, any>): void;
        private getValue;
        private setTab;
        private triggerBadgePop;
        private renderTabButton;
        private getEditorEl;
        private createEditor;
        private setInitialEditorValue;
        private createOrGetModel;
        private getUri;
        private renderPanel;
        private renderTabContent;
        render(): any;
        private renderContentEntities;
        private renderContentRules;
        private renderContentCapabilities;
        private renderContentSuggestions;
        private onAction;
        private toggleSuggestion;
        private renderSuggestionCard;
        private addSuggestion;
        private removeSuggestion;
        private renderAddSuggestion;
    }
}
declare module "_102020_/l2/agents/newModule/agentToBeConceptual3" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { ModuleToBe } from '_102020_/l2/agents/newModule/agentToBeConceptual';
    export function createAgent(): IAgentAsync;
    export function getPayloadToBeConceptual3(context: mls.msg.ExecutionContext): ModuleToBe | undefined;
}
declare module "_102020_/l2/agents/newModule/agentToBeExperienceModel" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: ExperienceModel;
    };
    export interface ExperienceModel {
        screens: ExperienceScreen[];
        journeys: Journey[];
    }
    export interface ExperienceScreen {
        screenId: string;
        actor: "customer" | "staff" | "admin";
        screenType: "page" | "dashboard" | "login" | "editor" | "settings";
        isEntryPoint?: boolean;
        purpose: string;
        supportsCapabilities: string[];
        rulesApplied: string[];
    }
    export interface Journey {
        journeyId: string;
        actor: "customer" | "staff" | "admin";
        supportsCapabilities: string[];
        steps: JourneyStep[];
    }
    export interface JourneyStep {
        screenId: string;
        params?: string[];
    }
}
declare module "_102020_/l2/agents/newModule/agentToBePage" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: ToBePages;
    };
    export interface ToBePages {
        pages: Page[];
    }
    export interface Page {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: Section[];
        /** Page-level action states (loading, saving, error) */
        actionStates: ActionStateDef[];
        /** Page-level temporary states (filters, selections, toggles) */
        tempStates: TempStateDef[];
    }
    export interface Section {
        sectionName: string;
        mode: "stack" | "exclusive";
        organisms: Organism[];
    }
    export interface Organism {
        organismName: string;
        purpose: string;
        rulesApplied: string[];
        /**
         * How this organism receives data from BFF.
         * Determines stateKey structure.
         */
        dataShape: DataShapeDef;
        /** Temporary states owned by this organism */
        tempStates: TempStateDef[];
        /** Computed fields derived from other data */
        computedFields: ComputedFieldDef[];
        /** Navigation actions triggered from this organism */
        navigationFields: NavigationFieldDef[];
        /** Events emitted by this organism */
        emits: EmitDef[];
    }
    export type DataShapeDef = DataShapeFields | DataShapeObject | DataShapeCollection;
    /**
     * Flat fields — each field is an independent state.
     * Use when: simple entity display/edit with few fields.
     * stateKey per field: db.[entity].[field]
     */
    export interface DataShapeFields {
        shape: 'fields';
        entityFields: EntityFieldRef[];
    }
    /**
     * Single object — the entire response is one state.
     * Use when: BFF returns a projected object, or entity has
     * nested sub-objects that must stay together.
     * stateKey: db.[entity] or db.[pageName].[routineAlias]
     * sourceRoutine: [moduleName].[pageName].[routineName]
     */
    export interface DataShapeObject {
        shape: 'object';
        stateKey: string;
        sourceRoutine: string;
        fields: ObjectFieldRef[];
        params: DataShapeParam[];
    }
    /**
     * Collection — array of objects, each with same structure.
     * Use when: lists, tables, grids, sub-entity arrays (addresses).
     * stateKey: db.[entity][] or db.[pageName].[alias][]
     * sourceRoutine: [moduleName].[pageName].[routineName]
     */
    export interface DataShapeCollection {
        shape: 'collection';
        stateKey: string;
        sourceRoutine: string;
        itemFields: ObjectFieldRef[];
        /** Does the collection support inline editing? */
        params: DataShapeParam[];
        editable: boolean;
    }
    /**
     * Parameter needed to call the sourceRoutine.
     * Declares WHERE the value comes from at runtime.
     */
    export interface DataShapeParam {
        /** Param name as expected by the BFF routine */
        paramName: string;
        /** Type of the param value */
        type: string;
        /** Where the value comes from at runtime */
        source: ParamSource;
    }
    export type ParamSource = {
        from: 'route';
        routeParam: string;
    } | {
        from: 'state';
        stateKey: string;
    } | {
        from: 'context';
        contextKey: string;
    } | {
        from: 'config';
        configKey: string;
    } | {
        from: 'parent';
        parentStateKey: string;
    } | {
        from: 'fixed';
        value: string | number | boolean;
    };
    /**
     * A field inside an object or collection item.
     * No individual stateKey — accessed via parent.
     */
    export interface ObjectFieldRef {
        entityField: string;
        entity: string;
        priority: FieldPriority;
        usage: 'display' | 'edit' | 'filter' | 'sort' | 'group';
        /** Marks array sub-fields: addresses[].street */
        isNested?: boolean;
        /** For nested sub-arrays within an item */
        nestedCollection?: {
            stateKeySuffix: string;
            itemFields: ObjectFieldRef[];
        };
        priorityReason?: string;
    }
    export type FieldPriority = 'required' | 'recommended' | 'optional' | 'future';
    export interface EntityFieldRef {
        entity: string;
        entityField: string;
        stateKey: string;
        priority: FieldPriority;
        /** How this field is used in the organism */
        usage: 'display' | 'edit' | 'filter' | 'sort' | 'group';
        /** Brief note on why this priority was chosen */
        priorityReason?: string;
    }
    export interface ActionStateDef {
        stateKey: string;
        description: string;
        /** Values ​​according to the state, e.g.: Possible values ​​— typically 'idle' | 'loading' | 'success' | 'error' */
        values: string[];
    }
    export interface TempStateDef {
        stateKey: string;
        type: string;
        description: string;
        priority: FieldPriority;
        /** Initial value expression */
        initialValue?: string;
    }
    export interface ComputedFieldDef {
        fieldId: string;
        derivedFrom: string[];
        description: string;
        priority: FieldPriority;
    }
    export interface NavigationFieldDef {
        fieldId: string;
        target: string;
        params: string[];
        priority: FieldPriority;
        /** 'internal' = route change, 'external' = new tab/whatsapp/etc */
        navigationType: 'internal' | 'external';
    }
    export interface EmitDef {
        event: string;
        payload: string;
        writesState?: string;
    }
}
declare module "_102020_/l2/agents/newModule/agentToBePages" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getPayloadToBePages(context: mls.msg.ExecutionContext): ToBePages | undefined;
    export const systemExperienceConstraints = "\n## Experience Constraints\n[[ExperienceConstraints]]\n";
    export type Output = {
        type: "flexible";
        result: ToBePages;
    };
    export interface ToBePages {
        pages: Page[];
    }
    export interface Page {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: Section[];
        visualStyle?: string;
    }
    export interface Section {
        sectionName: string;
        mode: "stack" | "exclusive";
        organisms: Organism[];
    }
    export interface Organism {
        organismName: string;
        purpose: string;
        rulesApplied: string[];
    }
}
declare module "_102020_/l2/agents/newModule/agentToBeUserJourney" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: UserJourneyMap;
    };
    export interface UserJourneyMap {
        journeys: Journey[];
        considerations: string[];
        suggestions: Suggestion[];
    }
    export interface Journey {
        persona: string;
        goal: string;
        journey: string[];
    }
    export interface Suggestion {
        suggestion: string;
        customerPerception: string;
        businessImpact?: ("customer_experience" | "revenue" | "operational_efficiency" | "maintainability" | "scalability" | string)[];
        confidence?: number;
        requiresConfiguration: boolean;
        yagni: "now" | "soon" | "later" | "no" | "unknown";
    }
}
declare module "_102020_/l2/agents/newModule/catalog" {
    export const skill = "\n# Molecule Catalog \u2014 mls-102040\n28 groups \u00B7 71 components\n\nTag convention: {groupname}--{variant}  (ex: groupentertext--ml-cpf-input)\nImport convention: /_102040_/l2/molecules/{groupname}/{variant}.js\n\n## Enter (22 components)\n- groupenterboolean: ml-checkbox-preference, ml-toggle-switch\n- groupenterdate: ml-compact-calendar, ml-date-picker\n- groupenterdateinterval: ml-date-interval-drag, ml-date-range-dual-calendar\n- groupenterdatetime: ml-datetime-picker, ml-enter-datetime-masked-input\n- groupenterdatetimeinterval: ml-datetime-interval-timeline, ml-enter-datetime-interval\n- groupentermoney: ml-enter-money-br, ml-enter-money-display, ml-enter-money-minimal\n- groupenternumber: ml-number-input, ml-number-stepper\n- groupentertext: ml-cpf-input, ml-floating-text-input, ml-multiline-text\n- groupentertime: ml-clock-time-picker, ml-time-scroll-picker\n- groupentertimeinterval: ml-time-interval-selector, ml-time-interval-slider\n\n## Select (18 components)\n- groupselectone: ml-card-selector, ml-combobox, ml-dial-select, ml-discrete-slider, ml-listbox-sidebar-select, ml-radio-group, ml-segmented-control, ml-select-dropdown-img, ml-select-dropdown, ml-select-one-autocomplete, ml-select\n- groupselectmany: ml-dual-list-select, ml-multi-checkbox-list, ml-multi-select-dropdown, ml-popover-multi-select\n- groupselectfileforupload: ml-file-upload-dropzone, ml-file-upload-preview, ml-user-photo-upload\n\n## View (14 components)\n- groupviewcard: ml-view-card-horizontal\n- groupviewchart: ml-area-chart, ml-bar-chart, ml-line-chart, ml-pie-chart\n- groupviewdata: ml-card-grid\n- groupviewhierarchy: ml-hierarchy-orgchart, ml-hierarchy-tree-diagram, ml-hierarchy-tree\n- groupviewmetric: ml-metric-big-number, ml-metric-gauge\n- groupviewtable: ml-data-table-minimal, ml-data-table, ml-view-table\n\n## Navigate (4 components)\n- groupnavigatemain: ml-sidebar-nav\n- groupnavigatesection: ml-tabs\n- groupnavigatesteps: ml-horizontal-stepper, ml-vertical-stepper\n\n## Other (13 components)\n- groupexpandcontent: ml-accordion\n- groupnotifyuser: ml-notify-banner, ml-toast-notification\n- groupplaymedia: ml-video-player\n- grouprateitem: ml-emoji-mood-scale, ml-numeric-rating-nps, ml-qualitative-feedback-tags, ml-rating-slider, ml-star-rating, ml-thumbs-rating\n- groupscancode: ml-scan-code\n- groupsearchcontent: ml-search-bar, ml-search-history\n";
}
declare module "_102020_/l2/agents/newModule/materializeOrchestrator" {
    export function getMaterializeOrchestrator(defPath: string): MaterializeOrchestrator;
    export class MaterializeOrchestrator {
        private jsonPath;
        private items;
        private completedIds;
        onAllCompleted: (() => void) | null;
        constructor(jsonPath: string);
        loadItems(): Promise<void>;
        getToExecuteOnlyMaterialize(id: string): Promise<mls.defs.MaterializeEntry | undefined>;
        isAllCompleted(): boolean;
        process(trigger: OrchestratorTrigger): Promise<mls.defs.MaterializeEntry[]>;
        getStatus(): OrchestratorStatus;
        reset(): void;
        getSkill(path: string): Promise<string>;
        private processTemplate;
        getModuleByBuild(path: string): Promise<any>;
        processGroup(trigger: OrchestratorTrigger): Promise<GroupedByAgent>;
        groupByAgent(tasks: mls.defs.MaterializeEntry[]): GroupedByAgent;
        getVarOld(path: string, variable: string): Promise<string>;
        createStorFile(fileRef: string, src: string): Promise<mls.stor.IFileInfo>;
        getVar(path: string, variable: string): Promise<string>;
        private buildAndExtract;
    }
    export interface OrchestratorStatus {
        total: number;
        completed: number;
        pending: number;
        completedIds: string[];
        pendingIds: string[];
        isAllCompleted: boolean;
    }
    type GroupedByAgent = Record<string, mls.defs.MaterializeEntry[]>;
    export type OrchestratorTrigger = 'init' | string;
}
declare module "_102020_/l2/agents/newModule/skills/genContract" {
    export const skill = "\n\nYou generate two TypeScript files from a pages JSON and an ontology: an interface file and a contract file.\nYou are a mechanical transformer. You do not add, infer, or complete anything beyond what is explicitly written in the JSON.\n\n##Your only job\nRead the JSON. Extract specific values. Place them into specific templates. Stop.\nYou do NOT:\n\nAdd fields not listed in the JSON\nRename anything\nAdd convenience types, helper types, or utility types\nAdd comments explaining the domain\nComplete \"obvious\" missing fields\nGuess what a field \"should\" be\n\n---\n\nYour task is to generate the content of `l1/{moduleName}/layer_2_controllers/{pageName}.ts`\nwhere `{pageName}` comes from `definition.pages[0].pageName` and `{moduleName}` is `{humun prompt}`.\n\n---\n\n## CRITICAL: Repository API contract\n\nThe table repository returned by `ctx.data.moduleData.getTable<T>(tableName)` exposes **only** these four methods:\n\n```typescript\ninterface ITableRepository<T> {\n  findMany(opts?: { orderBy?: { field: keyof T; direction: 'asc' | 'desc' } }): Promise<T[]>;\n  findOne(opts: { where: Partial<T> }): Promise<T | undefined>;\n  upsert(opts: { record: T }): Promise<void>;          // returns void \u2014 NOT the saved record\n  delete(opts: { where: Partial<T> }): Promise<void>;\n}\n```\n\n**Forbidden** \u2014 these methods do NOT exist and must never appear in generated code:\n- `.list()`\n- `.update()`\n- `.save()`\n- `.create()`\n- `.patch()`\n\n---\n\n## CRITICAL: Write action patterns \u2014 three distinct patterns\n\nBecause `upsert()` returns `void`, you must build the merged object yourself and return it.\n**Which pattern to use depends on the action name suffix** (see \"How to classify write actions\" below).\n\n### Pattern A \u2014 Save / Upsert (no throw)\nUse when the action name starts with: `save`, `salvar`, `upsert`, or is not clearly an explicit update or create.\nIf the record exists \u2192 merge and overwrite. If it does NOT exist \u2192 create it. Never throw NOT_FOUND.\n\n```typescript\nexport async function saveFoo(ctx: RequestContext, input: PrefixUpdateFooParams): Promise<PrefixFoo> {\n  const repo = await getFooRepository(ctx);\n  const existing = await repo.findOne({ where: { id: input.id } });\n  let record: PrefixFoo;\n  if (existing) {\n    record = {\n      ...existing,\n      ...(input.field1 !== undefined ? { field1: input.field1 } : {}),\n      // repeat for every optional field in input\n    };\n  } else {\n    record = {\n      id: input.id,\n      field1: input.field1 ?? defaultValue,\n      // repeat for every required field \u2014 fill required fields from input or a safe default\n    };\n  }\n  await repo.upsert({ record });\n  return record;\n}\n```\n\n### Pattern B \u2014 Explicit Update (throw if not found)\nUse ONLY when the action name starts with: `update`, `atualizar`, `editar`, `edit`, `patch`.\n\n```typescript\nexport async function updateFoo(ctx: RequestContext, input: PrefixUpdateFooParams): Promise<PrefixFoo> {\n  const repo = await getFooRepository(ctx);\n  const existing = await repo.findOne({ where: { id: input.id } });\n  if (!existing) throw new AppError('NOT_FOUND', 'Foo not found', 404);\n  const merged: PrefixFoo = {\n    ...existing,\n    ...(input.field1 !== undefined ? { field1: input.field1 } : {}),\n    // repeat for every optional field in input\n  };\n  await repo.upsert({ record: merged });\n  return merged;\n}\n```\n\n### Pattern C \u2014 Explicit Create (throw if already exists)\nUse ONLY when the action name starts with: `create`, `criar`, `add`, `adicionar`, `insert`.\n\n```typescript\nexport async function createFoo(ctx: RequestContext, input: PrefixUpdateFooParams): Promise<PrefixFoo> {\n  const repo = await getFooRepository(ctx);\n  const existing = await repo.findOne({ where: { id: input.id } });\n  if (existing) throw new AppError('ALREADY_EXISTS', 'Foo already exists', 409);\n  const record: PrefixFoo = {\n    id: input.id,\n    field1: input.field1 ?? defaultValue,\n    // all required fields\n  };\n  await repo.upsert({ record });\n  return record;\n}\n```\n\n---\n\n## CRITICAL: How to classify write actions\n\nFor each entry in `definition.pages[0].actionStates[]`, look at the suffix (part after the last `.` of `stateKey`, e.g. `saveVeiculo`, `updateCliente`, `addLocacao`):\n\n| Suffix starts with | Pattern to use |\n|---|---|\n| `save`, `salvar`, `upsert` | **Pattern A** \u2014 no throw |\n| `update`, `atualizar`, `editar`, `edit`, `patch` | **Pattern B** \u2014 throw NOT_FOUND |\n| `create`, `criar`, `add`, `adicionar`, `insert` | **Pattern C** \u2014 throw ALREADY_EXISTS |\n| anything else | **Pattern A** \u2014 safe default, no throw |\n\nOnly use Pattern B or C when the definition **explicitly names the action as update-only or create-only**.\nWhen in doubt, use Pattern A.\n\n---\n\n## CRITICAL: AppError signature\n\n`AppError` **always** requires at least two arguments:\n\n```typescript\n// CORRECT\nthrow new AppError('NOT_FOUND', 'Record not found', 404);\nthrow new AppError('VALIDATION_ERROR', 'filtro must be a string', 400);\n\n// WRONG \u2014 missing second argument\nthrow new AppError('NOT_FOUND');\n```\n\nSignature: `new AppError(code: string, message: string, statusCode?: number, details?: unknown)`\n\n---\n\n## CRITICAL: Typed lambda parameters\n\nEvery callback parameter in `.filter()`, `.map()`, `.find()`, `.forEach()`, `.reduce()` etc.\nmust have an **explicit type annotation**. Never leave a lambda param implicitly `any`:\n\n```typescript\n// CORRECT\nconst found = rows.filter((item: PrefixEntity) => item.nome.includes(filtro));\n\n// WRONG \u2014 implicit any\nconst found = rows.filter(item => item.nome.includes(filtro));\n```\n\n---\n\n## Two files to generate\n\n### File 1 \u2014 Interface file (`interfaceFile`)\n\nContains all TypeScript interfaces and types the contract file needs.\n\nStructure:\n1. **MLS file header**\n   ```\n   /// <mls fileReference=\"{interfaceOutputPath without leading /}\" enhancement=\"_blank\" />\n   ```\n   Use the exact `interfaceOutputPath` value from **User info** (strip the leading `/`).\n\n2. **Entity interfaces** \u2014 one per entity that exists in `ontology.entities` AND is referenced by the page definition.\n\n   **CRITICAL rules:**\n   - Include ONLY entities from `ontology.entities` \u2014 do NOT invent or add entities not present there\n   - Map ONLY the fields listed in `ontology.entities[Entity].fields` \u2014 do NOT add, rename, or infer fields\n   - All interface names MUST be prefixed with the module name in PascalCase (e.g. if moduleName is `pizzaria`, prefix is `Pizzaria`):\n     - Main interface: `{ModuleName}{EntityName}Response` (e.g. `PizzariaClienteResponse`)\n     - Update params: `{ModuleName}Update{EntityName}Request` (e.g. `PizzariaUpdateClienteRequest`)\n   - Field mapping rules (from ontology field definition):\n     - `type: \"string\"` \u2192 `string`\n     - `type: \"number\"` \u2192 `number`\n     - `type: \"boolean\"` \u2192 `boolean`\n     - Field with `values` array \u2192 union literal type: `'val1' | 'val2' | ...`\n     - Field with `required: false` \u2192 optional property: `fieldName?: type`\n     - All other fields \u2192 required: `fieldName: type`\n   - Update params rules:\n     - The `id` field (or first field if none named `id`) is **required**\n     - All other fields are **optional**\n     - Fields with union types reference the main interface: `{ModuleName}{Entity}['fieldName']`\n     - Always append `author?: string;` at the end\n\n3. **No imports** \u2014 this file is self-contained; do not import from anywhere.\n\n---\n\n### File 2 \u2014 Contract file (`srcFile`)\n\nThe BFF handler file. Must follow this structure (in order):\n\n1. **MLS file header**\n   ```\n   /// <mls fileReference=\"_{projectId}_/l1/{moduleName}/layer_2_controllers/{pageName}.ts\" enhancement=\"_blank\" />\n   ```\n\n2. **Imports**\n   - Import only the entity interfaces actually used \u2014 from `{interfaceOutputPath with .ts \u2192 .js}` (the interface file generated above)\n   - Import `AppError, ok, type BffHandler, type RequestContext` from `/_102034_/l1/server/layer_2_controllers/contracts.js`\n   - Do NOT import AuditLogService or StatusHistoryService unless there is a write action that changes status\n   - Import `USE_MOCK` and one named mock function per unique entity getter from `\"./mock.js\"`. Mock function name pattern: `getMock{EntityName}Repository` where EntityName is the ontology entity name verbatim (e.g., entity `Caixa` \u2192 `getMockCaixaRepository`, entity `MovimentoCaixa` \u2192 `getMockMovimentoCaixaRepository`). Collect all entity names that have a getter in this file and produce a single import line: `import { USE_MOCK, getMock{A}Repository, getMock{B}Repository } from \"./mock.js\";`\n\n3. **Repository getter functions** (one per unique entity touched by any routine)\n   Pattern:\n   ```typescript\n   async function get{Entity}Repository(ctx: RequestContext) {\n     if (USE_MOCK) return getMock{Entity}Repository();\n     return ctx.data.moduleData.getTable<{Prefix}{Entity}>('{prefix}{Entity}');\n   }\n   ```\n   - Table name = moduleName + EntityName with first letter lowercase (e.g. `pizzariaCliente`)\n   - `getMock{Entity}Repository` uses the EntityName verbatim (same casing as the interface, e.g. `getMockCaixaRepository`, `getMockMovimentoCaixaRepository`)\n\n4. **Usecase functions** (one per routine identified below)\n   - For **read routines** (from `dataShape.sourceRoutine`): call `repo.findMany()` then filter in-memory if params present; every filter/map callback param must be explicitly typed\n   - For **write/action routines** (from `actionStates`): follow the update pattern above \u2014 findOne \u2192 merge \u2192 upsert \u2192 return merged\n   - Function signature: `export async function {routineSuffix}(ctx: RequestContext, input?: {...}): Promise<...>`\n   - Params come from the organism's `dataShape.params` for read routines\n   - For write routines use the `{ModuleName}Update{Entity}Params` interface from the interface file generated above\n\n5. **BFF handler constants** (one per routine)\n   [RoutineSuffix] with the first letter capitalized.\n   Pattern:\n   ```typescript\n   export const {pageName}{RoutineSuffix}Handler: BffHandler = async ({ request, ctx }) => {\n     const params = (request.params ?? {}) as Record<string, unknown>;\n     return ok(await {routineSuffix}(ctx, {\n       param1: typeof params.param1 === 'string' ? params.param1 : undefined,\n       // repeat for each param\n     }));\n   };\n   ```\n\n---\n\n## How to extract routines from the definition\n\n### Read routines\nFor each organism in `definition.pages[0].sections[].organisms[]`:\n- Take `organism.dataShape.sourceRoutine` (e.g. `registroPedido.listClientes`)\n- The suffix after the last `.` is the usecase function name (e.g. `listClientes`)\n- The full string is the BFF routine key\n- Params for the usecase come from `organism.dataShape.params[]`\n- Entities used come from `organism.dataShape.itemFields[].entity` or `organism.dataShape.fields[].entity`\n\n### Write/action routines\nFor each entry in `definition.pages[0].actionStates[]`:\n- Take the part after the last `.` of `stateKey` as the suffix (e.g. `salvarPedido`, `confirmarPedido`)\n- Skip entries whose suffix is one of `idle`, `loading`, `success`, `error` \u2014 those are UI states, not routines\n- The BFF routine key is `{pageName}.{suffix}`\n- Infer the entity and params from context (which entities the page works with)\n- **Classify the action** using the table in \"How to classify write actions\" above to choose Pattern A, B, or C\n\n---\n\n## Output format rules (both files)\n- No markdown fences, no explanations, no inline comments\n- 2-space indentation\n- One blank line between top-level declarations\n- Handlers must be exported named constants, not default exports\n- Both `srcFile` and `interfaceFile` must be single-line JSON strings with all special characters escaped:\n  - newlines \u2192 \\n\n  - tabs \u2192 \\t\n  - double quotes \u2192 \\\"\n  - backslashes \u2192 \\\\\n\n## How to populate routers[]\n\nFor every `export const *Handler: BffHandler` constant you generate in `srcFile`, add one entry to `routers`:\n\n- `funcName`: the exact constant name (e.g. `veiculosCadastroSaveHandler`)\n- `router`: the BFF route key \u2014 ALWAYS in the format `{moduleName}.{pageName}.{routineSuffix}`\n  - `moduleName` = the module name from User info (e.g. `locadora`)\n  - `pageName` = `definition.pages[0].pageName` (e.g. `veiculosCadastro`)\n  - `routineSuffix` = the suffix used when building the handler (e.g. `saveVeiculo`, `getStatusVeiculoOptions`)\n\nExample:\n```json\n\"routers\": [\n  { \"router\": \"locadora.veiculosCadastro.getStatusVeiculoOptions\", \"funcName\": \"veiculosCadastroGetStatusVeiculoOptionsHandler\" },\n  { \"router\": \"locadora.veiculosCadastro.saveVeiculo\", \"funcName\": \"veiculosCadastroSaveHandler\" }\n]\n```\n\nInclude ALL handlers \u2014 one entry per handler constant, no omissions.\n\n---\n\n";
}
declare module "_102020_/l2/agents/newModule/skills/genPageDS" {
    export const skill = "\n# SKILL: Lit WebComponent Render Design\n\n## Design freedom \u2014 Tailwind CSS\n\nYou have **full creative freedom** over the visual layout and design. Use Tailwind CSS utility classes to craft a UI that best fits the purpose of this page (read from `definition.pages[0].purpose`).\n\nDesign principles to follow:\n- Create a UI that feels purpose-built for the page's context and audience (`definition.pages[0].actor`)\n- Each organism should have a distinct visual section \u2014 choose the layout (sidebar, tabs, stacked panels, split view, etc.) that makes the most sense for the data\n- Use spacing, typography hierarchy, color, and borders expressively \u2014 not just structurally\n- Interactive elements (search, filter, selection) should feel obvious and responsive\n- Status and feedback text (`this.status`) should be visible and contextual\n- Collection organisms with many items benefit from compact rows rather than large cards if there are many fields\n- Object organisms (summaries, drafts) benefit from structured panels with clear field labels\n- Action controls (forms, confirm buttons) should be visually prominent and placed near the data they affect\n";
}
declare module "_102020_/l2/agents/newModule/skills/genPageRender" {
    export const skill = "\n# SKILL: Lit WebComponent Render Generator\n\nYou generate the **WebComponent** TypeScript file \u2014 the pure visual layer of a Lit feature.\nYou extend a Shared base class and your only job is to generate the `render()` method.\nAll state, logic, enums, and methods live in the Shared. You never redeclare or invent any of them.\n\n---\n\n## Architecture of the file to generate\n\nThe file has exactly four parts (in this order):\n\n### 1. MLS file header\nThe enhancement is always `_102027_/l2/enhancementLit.ts` (NOT `_blank`):\n```\n/// <mls fileReference=\"_{projectId}_/l2/{moduleName}/web/desktop/page11/{pageName}.ts\" enhancement=\"_102027_/l2/enhancementLit.ts\" />\n```\n\n### 2. Imports\n```typescript\nimport { html } from 'lit';\nimport { {Prefix}{PageName}Base } from '/_{projectId}_/l2/{moduleName}/web/shared/{pageName}';\n```\n- Import **only** what is used in the render body\n- If the shared file exports helper functions (e.g. `formatPrice`), import them only when referenced in render\n- Do NOT import entity interfaces \u2014 they are already available through the base class\n\n### 3. Component class\n```typescript\n@customElement('{module-name}--web--desktop--page11--{page-name}-{projectId}')\nexport class {ModuleName}WebDesktop{PageName}Page extends {ModuleName}{PageName}Base {\n  render() {\n    return html`\n      <!-- full page markup here -->\n    `;\n  }\n}\n```\n- Tag name: both `{module-name}` and `{page-name}` in kebab-case\n  - e.g. `moduleName=pizzaria`, `pageName=registroPedido` \u2192 `pizzaria--web--desktop--page11--registro-pedido-102003`\n\n---\n\n## CRITICAL: Only use what the base class exposes\n\nRead the shared source carefully. You may ONLY reference:\n- Reactive properties declared with `declare` (e.g. `this.items`, `this.status`)\n- Non-reactive properties initialised in the class body (e.g. `this.editorAuthor`)\n- The `this.msg` object and its keys\n- Methods defined in the shared class (e.g. `this.loadListClientes`, `this.handleSalvarPedidoSubmit`)\n- Any named exports from the shared file (e.g. helper functions like `formatPrice`)\n\nDo NOT invent state, methods, or msg keys that do not exist in the shared source.\n\n---\n\n## Render structure \u2014 how to map organisms to markup and base Class\n\nAlways use the fields that exist in the base class; if they don't exist, don't create or add them.\n\nFor each organism in `definition.pages[0].sections[].organisms[]`:\n\n### Collection organism (`dataShape.shape === 'collection'`)\nRender as a searchable list or card grid:\n- If the organism has `dataShape.params[]` with a `filtro` param: add an `<input>` that calls the corresponding load method\n- If the organism has `dataShape.params[]` with a `categoria` param: add filter buttons, one per unique value from the entity's category field\n- Iterate with `.map()` over the corresponding base-class array property\n- Each card/row shows the `itemFields[]` whose `usage` is `display` or `filter`\n- Fields with `priority: 'optional'` may be shown conditionally with `??` or `?.xxx`\n- If the organism has `emits[]` with a `writesState` that selects an item (e.g. `clienteSelecionado`): add a clickable row/button that calls the load method or sets state\n\n### Object organism (`dataShape.shape === 'object'`)\nRender as a summary card:\n- Show each field in `fields[]` with `usage: 'display'`\n- If the organism has `navigationFields[]`: add a back/nav button\n- If the organism is associated with an `actionStates` entry (same page context): add a `<form>` calling the corresponding handler, or action buttons\n\n---\n\n## Render structure \u2014 how to map actionStates to controls\n\nFor each entry in `definition.pages[0].actionStates[]` whose suffix is NOT `idle/loading/success/error`:\n- If the action is a save/create: render a `<form @submit=${this.handle{Suffix}Submit}>` with hidden inputs for required fields and a submit button\n- If the action is a confirm/approve: render a `<button @click=${() => this.handle{Suffix}Click({...params})}`\n- Place these controls near the organism whose data they affect (e.g. a \"Salvar Pedido\" form goes in the resumo section)\n\n---\n\n## Design freedom \u2014 Tailwind CSS\n\nYou have **full creative freedom** over the visual layout and design. Use Tailwind CSS utility classes to craft a UI that best fits the purpose of this page (read from `definition.pages[0].purpose`).\n\nDesign principles to follow:\n- Create a UI that feels purpose-built for the page's context and audience (`definition.pages[0].actor`)\n- Each organism should have a distinct visual section \u2014 choose the layout (sidebar, tabs, stacked panels, split view, etc.) that makes the most sense for the data\n- Use spacing, typography hierarchy, color, and borders expressively \u2014 not just structurally\n- Interactive elements (search, filter, selection) should feel obvious and responsive\n- Status and feedback text (`this.status`) should be visible and contextual\n- Collection organisms with many items benefit from compact rows rather than large cards if there are many fields\n- Object organisms (summaries, drafts) benefit from structured panels with clear field labels\n- Action controls (forms, confirm buttons) should be visually prominent and placed near the data they affect\n\nTechnical constraints that must still be respected:\n- All text must come from `this.msg.xxx` \u2014 never hardcode strings\n- Event bindings must use the exact Lit syntax: `@event=${handler}` for methods, `@event=${(e: Event) => ...}` for inline\n- Property bindings use `.property=${value}`\n- Iterate collections with `.map(item => html`...`)` \u2014 always alias type if needed\n- Use `??` guards on nullable reactive properties (`this.someList ?? []`, `this.someObject?.field ?? ''`)\n\n---\n\n## Output format rules\n- Return **only** the TypeScript source\n- No markdown fences, no explanations, no inline comments\n- 2-space indentation inside the class; the html template may use 6-space indentation for readability\n- One blank line between top-level declarations\n\n---\n";
}
declare module "_102020_/l2/agents/newModule/skills/genPageShared" {
    export const skill = "\n# Lit Base Component \u2014 Shared File Generator\n\nYou generate a **Shared** TypeScript file: a headless Lit 3 base class that holds all reactive state and communicates with the backend via `execBff`. It never renders, never registers a custom element, never declares any enum, and never dispatches events.\n\n---\n\nYour task is to generate the content of `l2/{moduleName}/web/shared/{pageName}.ts`\nwhere `{pageName}` comes from `definition.pages[0].pageName` and `{moduleName}` is {humun prompt}`.\n\n---\n\n## CRITICAL: MLS mock pattern for every BFF call\n\nEvery call to `execBff` must be wrapped with an MLS environment check:\n\n```typescript\nif ((window as any).mls) {\n  // Provide stub/mock data directly \u2014 no network call\n  this.someList = [{ id: '1', field: 'mock value', ... }];\n  this.status = `${this.someList.length} ${this.msg.itemsAvailable}`;\n} else {\n  const response = await execBff<ReturnType>('routine.key', params, options);\n  if (!response.ok || !response.data) {\n    if (options?.mode === 'blocking') {\n      throw (response.error ?? {\n        code: 'UNEXPECTED_ERROR',\n        message: this.msg.couldNotLoad,\n      }) satisfies AuraNormalizedError;\n    }\n    this.status = this.msg.couldNotLoad;\n    this.someList = [];\n    return;\n  }\n  this.someList = response.data ?? [];\n  this.status = `${this.someList.length} ${this.msg.itemsAvailable}`;\n}\n```\n\nRules for mock data:\n- Provide 2\u20133 stub records per entity list; provide a sensible single object for object shapes\n- Use realistic-looking Portuguese values for name/label fields (e.g. `'Jo\u00E3o Silva'`, `'Margherita'`)\n- Match every required field from the entity interface \u2014 optional fields may be omitted\n- For write/action routines, the mock branch should log the params to the console and resolve successfully\n  ```typescript\n  if ((window as any).mls) {\n    console.log('[mls mock] routine.key', params);\n    this.status = this.msg.savedSuccessfully;\n    return;\n  }\n  ```\n\n---\n\n## Architecture of the file to generate\n\nThe file must follow this structure (in order):\n\n### 1. MLS file header\n```\n/// <mls fileReference=\"_{projectId}_/l2/{moduleName}/web/shared/{pageName}.ts\" enhancement=\"_102027_/l2/enhancementLit.ts\" />\n```\n\n### 2. Imports\n```typescript\nimport { CollabLitElement } from '_102029_/l2/collabLitElement';\nimport { property } from 'lit/decorators';\nimport type { AuraNormalizedError } from '_102029_/l2/contracts/bootstrap';\nimport type { BffClientOptions } from '_102029_/l2/bffClient';\nimport { execBff } from '_102029_/l2/bffClient';\nimport {\n  bindExpectedNavigationLoad,\n  consumeExpectedNavigationLoad,\n  runBlockingUiAction,\n} from '_102029_/l2/interactionRuntime';\nimport { subscribe, unsubscribe, getState, setState, initState } from '_102029_/l2/collabState';\nimport type { {ModuleName}EntityA, {ModuleName}EntityB } from '_{projectId}_/l2/{moduleName}/web/contracts/{pageName}';\n```\n- Import only entity interfaces that are actually referenced in the class body\n- Determine which entities are used by reading `organism.dataShape.itemFields[].entity` and `organism.dataShape.fields[].entity` across all organisms\n\n### 3. i18n block\nWrap with `/// **collab_i18n_start**` and `/// **collab_i18n_end**`:\n\n```typescript\n/// **collab_i18n_start**\nconst message_pt = {\n  // all fixed text in Portuguese (no accents \u2014 use plain ASCII)\n};\nconst message_en = {\n  // same keys in English\n};\ntype MessageType = typeof message_en;\nconst messages: { [key: string]: MessageType } = { en: message_en, pt: message_pt };\n/// **collab_i18n_end**\n```\n\nRequired i18n keys (add more as needed by the page content):\n- `brand` \u2014 module display name (e.g. `'Pizzaria'`)\n- `pageTitle`, `pageSubtitle` \u2014 from `definition.pages[0].pageName` / `purpose`\n- One loading/status label per read routine (e.g. `loadingClientes`, `loadingCardapio`)\n- `couldNotLoad` \u2014 generic data load error\n- One error label per write routine (e.g. `couldNotSave`, `couldNotConfirm`)\n- One success label per write routine (e.g. `savedSuccessfully`, `confirmedSuccessfully`)\n- Labels for form fields visible in the page (infer from entity fields)\n- `reload`, `save`, `saving`, `confirm`, `confirming` as applicable\n- Never types \"const message_pt = { *** } as const\"\n\n### 4. Base class\n```typescript\nexport class {ModuleName}{PageName}Base extends CollabLitElement {\n\n  private readonly _stateKeys = [\n    'db.entity.field',          // one entry per observed stateKey (see collabState section)\n    'ui.pageName.actionName',\n    // ...\n  ] as const;\n\n  property() someList: SomeEntity[];\n  property() someObject: SomeEntity | undefined;\n  property() status: string;\n  // reactive properties for actionStates (type: 'idle'|'loading'|'success'|'error')\n  // reactive properties for tempStates\n  // reactive properties for shape-'fields' individual fields\n\n  protected msg: MessageType = messages['en'];\n\n  createRenderRoot() { return this; }\n\n  connectedCallback() {\n    super.connectedCallback();\n    const pendingLoad = consumeExpectedNavigationLoad();\n    const task = this.loadInitialData(undefined, {\n      // mode: pendingLoad ? 'blocking' : 'silent',\n      mode: 'silent',\n      signal: pendingLoad?.signal,\n    });\n    bindExpectedNavigationLoad(pendingLoad, task);\n    void task.catch(() => undefined);\n\n    const lang: string = this.getMessageKey(messages);\n    this.msg = messages[lang] || messages['en'];\n\n    // initState for tempStates with initialValue\n    // initState('ui.{pageName}.someKey', defaultValue);\n\n    // subscribe to all observed state keys\n    subscribe(this._stateKeys as unknown as string[], this);\n\n    // read current values from global state\n    (this._stateKeys as unknown as string[]).forEach(key => {\n      const v = getState(key);\n      if (v !== undefined) this.handleIcaStateChange(key, v);\n    });\n  }\n\n  disconnectedCallback() {\n    super.disconnectedCallback();\n    unsubscribe(this._stateKeys as unknown as string[], this);\n  }\n\n  handleIcaStateChange(key: string, value: any): void {\n    switch (key) {\n      // one case per stateKey in _stateKeys\n    }\n  }\n\n  // \u2500\u2500 load methods (one per read routine) \u2500\u2500\n  // \u2500\u2500 action methods (one per write routine) \u2500\u2500\n  // \u2500\u2500 form submit handlers (one per write routine that originates from a form) \u2500\u2500\n}\n```\n\nNote: \n1- Always implement loadInitialData.\n2- Always verify that all necessary fields and states are correlated and free of programming errors.\n\n---\n\n## How to derive reactive state\n\nFor each organism in `definition.pages[0].sections[].organisms[]`:\n- `dataShape.shape === 'collection'` \u2192 declare `{stateKeyLastSegment}: {Prefix}{Entity}[]` (initialize to `[]`)\n- `dataShape.shape === 'object'` \u2192 declare `{stateKeyLastSegment}: {Prefix}{Entity} | undefined` (initialize to `undefined`)\n- The state field name = last segment of `dataShape.stateKey` after stripping `[]` (e.g. `db.cliente[]` \u2192 `cliente`)\n\nAlways include a `status: string` reactive property.\n\n---\n\n## How to generate load methods\n\nFor each organism with a `dataShape.sourceRoutine`:\n- Method name: `load{Suffix}()` where Suffix is the routine suffix in PascalCase (e.g. `listClientes` \u2192 `loadListClientes`)\n- The first load method is called from `connectedCallback`; subsequent ones may be called on demand\n- Params come from `organism.dataShape.params[]` \u2014 accept them as an optional object arg\n- Apply the MLS mock pattern described above\n- For a collection shape: set the corresponding array state field\n- For an object shape: set the corresponding object state field\n\n---\n\n## How to generate action methods\n\nFor each entry in `definition.pages[0].actionStates[]` whose suffix is NOT `idle/loading/success/error`:\n- Method name: `{suffix}(params, signal?)` (e.g. `salvarPedido`, `confirmarPedido`)\n- Infer the params type from the `Update{Entity}Params` interface in module.ts for the primary entity of the page\n- Apply the MLS mock pattern (mock branch: console.log + set success status; else branch: execBff + handle response)\n- After a successful write, re-run the relevant load method to refresh state\n\nFor each action method, also generate a `handle{Suffix}Submit(event: SubmitEvent)` or `handle{Suffix}Click()` helper that calls `runBlockingUiAction`.\n\n---\n\n## How to integrate collabState (state observation)\n\nThe shared class MUST subscribe to the global state on connect and unsubscribe on disconnect.\nIt MUST implement `handleIcaStateChange` to react when external code changes any observed key.\nIt MUST publish state via `setState` after loading from BFF or after mutations.\n\n### Collect all state keys to observe\n\nGather every `stateKey` from the definition in this order:\n\n1. **dataShape \u2014 shape 'fields'**: all `organism.dataShape.entityFields[].stateKey` (e.g. `db.veiculo.placa`)\n2. **dataShape \u2014 shape 'object' or 'collection'**: `organism.dataShape.stateKey` (e.g. `config.locadora.statusVeiculoOptions`, strip trailing `[]`)\n3. **tempStates** (both organism-level and page-level): all `tempStates[].stateKey`\n4. **actionStates**: all `actionStates[].stateKey`\n\nCollect them all into a single `private readonly _stateKeys` tuple constant inside the class.\n\n### Mapping stateKey \u2192 local property name\n\n- Last segment of the stateKey (split by `.`, strip `[]`) is the base name.\n- If two keys share the same last segment, use the last **two** segments joined in camelCase (e.g. `form.errors` \u2192 `formErrors`).\n- Use this same rule that was already applied when declaring the reactive properties.\n\n### connectedCallback \u2014 subscribe and read initial state\n\nAfter the existing super call and pendingLoad logic, add:\n\n```typescript\n// initState for tempStates that have initialValue\ninitState('ui.{pageName}.someKey', defaultValue);\n\n// subscribe to all state keys (use '*' prefix for exclusive subscription)\nsubscribe(this._stateKeys, this);\n\n// read current values from global state\nthis._stateKeys.forEach(key => {\n  const v = getState(key);\n  if (v !== undefined) this.handleIcaStateChange(key, v);\n});\n```\n\nRules:\n- Only call `initState` for keys that have an `initialValue` in their tempState definition \u2014 parse the JSON initialValue as the default.\n- Use `'*' + stateKey` (exclusive) when subscribing if you want to ensure only one active subscription exists. Prefer exclusive subscriptions for action state keys.\n- Read initial values AFTER subscribing, so any setState triggered during init is properly handled.\n\n### disconnectedCallback\n\n```typescript\ndisconnectedCallback() {\n  super.disconnectedCallback();\n  unsubscribe(this._stateKeys, this);\n}\n```\n\n### handleIcaStateChange\n\n```typescript\nhandleIcaStateChange(key: string, value: any): void {\n  switch (key) {\n    case 'db.veiculo.placa': this.placa = value ?? ''; break;\n    case 'db.veiculo.modelo': this.modelo = value ?? ''; break;\n    case 'config.locadora.statusVeiculoOptions': this.statusVeiculoOptions = value ?? []; break;\n    case 'ui.veiculosCadastro.saveVeiculo': this.saveVeiculoState = value ?? 'idle'; break;\n    case 'ui.veiculosCadastro.form.errors': this.formErrors = value ?? {}; break;\n    // ... one case per observed stateKey\n  }\n}\n```\n\nRules:\n- Cover EVERY key in `_stateKeys`.\n- Use a sensible empty/default value (empty string, `[]`, `{}`, `undefined`, `'idle'`) as fallback when value is null/undefined.\n- Do NOT call `setState` inside `handleIcaStateChange` \u2014 this method only syncs external \u2192 local.\n\n### setState calls after load/action methods\n\nAfter every successful BFF call (or mock branch) that produces data:\n\n- **shape 'object' or 'collection'**: call `setState(organism.dataShape.stateKey, loadedData)` immediately after setting the local property.\n- **shape 'fields'**: nothing extra needed in load \u2014 fields are written individually by the UI.\n- **actionStates**: set the action state key around the async operation:\n  ```typescript\n  setState('ui.{pageName}.{actionName}', 'loading');\n  try {\n    // ... BFF call\n    setState('ui.{pageName}.{actionName}', 'success');\n  } catch (e) {\n    setState('ui.{pageName}.{actionName}', 'error');\n    throw e;\n  }\n  ```\n- **tempStates mutations**: whenever the shared class updates a tempState property locally (e.g. formErrors), also call `setState(stateKey, value)`.\n\n---\n\n### CRITICAL: runBlockingUiAction signature\n\n`runBlockingUiAction` accepts **exactly 2 arguments** \u2014 no `this` as first parameter:\n\n```typescript\n// CORRECT \u2014 2 args, signal typed as AbortSignal\nvoid runBlockingUiAction(\n  async (signal: AbortSignal) => { await this.salvarPedido(params, signal); },\n  {\n    busyLabel: this.msg.saving,\n    errorTitle: this.msg.couldNotSave,\n    retry: () => this.salvarPedido(params),\n  },\n);\n\n// WRONG \u2014 do NOT pass this as first argument\nvoid runBlockingUiAction(this, async (signal) => { ... }, { ... });\n// WRONG \u2014 signal must be typed AbortSignal, never left implicit\nvoid runBlockingUiAction(async (signal) => { ... }, { ... });\n```\n\nThe callback parameter `signal` **must always** be annotated as `AbortSignal`.\n\n---\n";
}
declare module "_102020_/l2/molecules/index" {
    export type SkillCategory = 'dataEntry' | 'dataDiscovery' | 'dataDisplay' | 'actions' | 'navigation' | 'feedback' | 'identity';
    export interface MutationGroupEntry {
        name: string;
        category: SkillCategory;
        icon: string;
        label: string;
        shortDescription: string;
        demo: string;
    }
    export interface MutationWidget {
        name: string;
        tag: string;
        label: string;
        description: string;
    }
    export interface MutationGroup {
        widgets: MutationWidget[];
        demo: string;
        state: Record<string, any>;
    }
    export const mutationGroups: MutationGroupEntry[];
    export function getGroupByFolder(folder: string): MutationGroupEntry | undefined;
    export function getEnrichedGroups(): {
        description: any;
        skillReference: any;
        name: string;
        category: SkillCategory;
        icon: string;
        label: string;
        shortDescription: string;
        demo: string;
    }[];
    export function renderIcon(icon: string, size?: number): string;
}
declare module "_102020_/l2/newModule/astIndex" {
    export interface NavEntry {
        label: string;
        href: string;
    }
    export interface PageEntry {
        path: string;
        title: string;
        tagName: string;
        loader: string;
    }
    export function parseCollab(source: string): {
        navigation: NavEntry[];
        pages: PageEntry[];
    };
    export function getNavigation(source: string): NavEntry[];
    export function hasNav(source: string, href: string): boolean;
    /**
     * Adiciona uma entrada de navigation.
     * - Se `href` já existe, retorna source intacto (ou lança se throwIfExists=true).
     */
    export function addNav(source: string, entry: NavEntry, { throwIfExists }?: {
        throwIfExists?: boolean;
    }): string;
    /**
     * Remove uma entrada de navigation pelo href.
     */
    export function removeNav(source: string, href: string): string;
    export function getPages(source: string): PageEntry[];
    export function hasPage(source: string, path: string): boolean;
    /**
     * Adiciona uma entrada de pages.
     * - Se `path` já existe, retorna source intacto (ou lança se throwIfExists=true).
     */
    export function addPage(source: string, entry: PageEntry, { throwIfExists }?: {
        throwIfExists?: boolean;
    }): string;
    /**
     * Remove uma entrada de pages pelo path.
     */
    export function removePage(source: string, path: string): string;
}
declare module "_102020_/l2/newModule/astModuleFront" {
    export interface ModuleNavEntry {
        id: string;
        label: string;
        href: string;
        description: string;
    }
    export interface ModuleRouteEntry {
        path: string;
        aliases: string[];
        entrypoint: string;
        tag: string;
        title: string;
    }
    export function parseModule(source: string): {
        navigation: ModuleNavEntry[];
        routes: ModuleRouteEntry[];
    };
    export function getModuleNavigation(source: string): ModuleNavEntry[];
    export function hasModuleNav(source: string, id: string): boolean;
    export function addModuleNav(source: string, entry: ModuleNavEntry, { throwIfExists }?: {
        throwIfExists?: boolean;
    }): string;
    export function removeModuleNav(source: string, id: string): string;
    export function getModuleRoutes(source: string): ModuleRouteEntry[];
    export function hasModuleRoute(source: string, path: string): boolean;
    export function addModuleRoute(source: string, entry: ModuleRouteEntry, { throwIfExists }?: {
        throwIfExists?: boolean;
    }): string;
    export function removeModuleRoute(source: string, path: string): string;
}
declare module "_102020_/l2/newModule/astRouter" {
    export interface ImportEntry {
        /** 'import type' or 'import' */
        kind: 'type' | 'value';
        /** named imports */
        names: string[];
        /** caminho do módulo */
        from: string;
    }
    export interface RouteEntry {
        /** chave do Map: 'pizzaria.getCustomer' */
        key: string;
        /** nome do handler: 'customerEditorGetCustomerHandler' */
        handler: string;
    }
    export function parseRouter(source: string): {
        mlsComment: string | null;
        imports: ImportEntry[];
        routes: RouteEntry[];
    };
    export function getMlsComment(source: string): string | null;
    export function getImports(source: string): ImportEntry[];
    export function hasImport(source: string, from: string): boolean;
    /**
     * Adiciona um import.
     * - Se já existe um import do mesmo `from`, faz merge dos `names`.
     * - Caso contrário, insere antes da primeira linha `export`.
     */
    export function addImport(source: string, imp: ImportEntry): string;
    /**
     * Remove o import inteiro cujo `from` bate com o argumento.
     */
    export function removeImport(source: string, from: string): string;
    /**
     * Remove um nome específico de um import.
     * Se for o único nome, remove o import inteiro.
     */
    export function removeImportName(source: string, from: string, name: string): string;
    export function getRoutes(source: string): RouteEntry[];
    export function hasRoute(source: string, key: string): boolean;
    /**
     * Adiciona uma rota ao Map, depois da última entrada existente.
     * Suporta Map vazio: new Map([]) ou new Map<...>([]).
     *
     * @param throwIfExists - se true, lança erro quando a rota já existe. Default: false.
     */
    export function addRoute(source: string, key: string, handler: string, throwIfExists?: boolean): string;
    /**
     * Remove uma rota do Map pela chave.
     */
    export function removeRoute(source: string, key: string): string;
    /**
     * Troca o handler de uma rota existente (substituição por posição).
     */
    export function updateRoute(source: string, key: string, newHandler: string): string;
    type RouteHandlerPair = [routeKey: string, handlerName: string];
    export function extractRouteHandlers(definition: {
        pages: any[];
    }, moduleName: string): RouteHandlerPair[];
}
declare module "_102020_/l2/newModule/widgetModuleDashboard" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class WidgetModuleDashboard102020 extends StateLitElement {
        private _loading;
        private _modules;
        private _running;
        private _error;
        connectedCallback(): Promise<void>;
        render(): TemplateResult;
        private _renderModule;
        private _renderPage;
        private _renderDraftPage;
        private _renderMaterializedPage;
        private _scan;
        private _parseSteps;
        private _defaultSteps;
        private _getThread;
        private _generateAll;
        private _generateStep;
    }
}
declare module "_102020_/l2/plugins/markdownViewer" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PluginMarkdownViewer extends StateLitElement {
        text: string;
        private _editing;
        private _editText;
        private get msg();
        connectedCallback(): void;
        createRenderRoot(): this;
        updated(): void;
        private _resizeTextarea;
        render(): any;
        private _renderView;
        private _renderEdit;
        private _save;
    }
}
declare module "_102020_/l2/plugins/navHeader" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PluginNavHeader extends StateLitElement {
        fixedLabel: string;
        itemName: string;
        desc: string;
        value: number;
        min: number;
        max: number;
        createRenderRoot(): this;
        render(): any;
        private _iconFirst;
        private _iconPrev;
        private _iconNext;
        private _iconLast;
        private _dispatch;
    }
}
declare module "_102020_/l2/plugins/selectAssetsComponents" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectAssetsComponents extends StateLitElement {
        selectedModule: IModule | null;
        device: number | null;
        private _selected;
        private _filterCategory;
        private _search;
        private _viewMode;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _filteredGroups();
        private get _activeCategories();
        createRenderRoot(): this;
        render(): any;
        private _renderToolbar;
        private _renderViewToggle;
        private _renderCategoryFilter;
        private _renderContent;
        private _renderListShort;
        private _renderListPreview;
        private _renderGrid;
        private _renderGroupCard;
        private _onGroupClick;
        private findIndex;
        private _svgList;
        private _svgListPreview;
        private _svgGrid;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectAssetsMedia" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectAssetsMedia extends StateLitElement {
        selectedModule: IModule | null;
        device: number | null;
        private _files;
        private _loading;
        private _search;
        private _viewMode;
        private _activeCategory;
        private _uploadFile;
        private _uploadLoading;
        private _uploadPreviewUrl;
        private _deleteConfirm;
        willUpdate(changed: Map<string, unknown>): void;
        disconnectedCallback(): void;
        private get msg();
        private _loadFiles;
        private get _filtered();
        private get _counts();
        createRenderRoot(): this;
        render(): any;
        private _renderToolbar;
        private _renderViewToggle;
        private _renderUploadArea;
        private _renderCategoryTabs;
        private _renderContent;
        private _renderListShort;
        private _renderListPreview;
        private _renderGrid;
        private _renderDeleteBtn;
        private _renderExtBadge;
        private _openFilePicker;
        private _onFileSelected;
        private _handleUpload;
        private _handleDeleteClick;
        private _handleDelete;
        private _clearUpload;
        private _revokePreview;
        private _formatSize;
        private _svgCategoryIcon;
        private _svgPlus;
        private _svgTrash;
        private _svgX;
        private _svgList;
        private _svgListPreview;
        private _svgGrid;
        private _svgSpinner;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectAssetsPlugins" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectAssetsPlugins extends StateLitElement {
        selectedModule: IModule | null;
        device: number | null;
        private get msg();
        createRenderRoot(): this;
        render(): any;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectDesignSystem" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    export class PluginSelectDesignSystem extends StateLitElement {
        projectId: number | null;
        value: number | null;
        private _entries;
        private _loading;
        connectedCallback(): void;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _customKey();
        private get _isAll();
        private get _isCustom();
        private get _selectedEntry();
        private _loadDsConfig;
        private _dispatchConfig;
        createRenderRoot(): this;
        render(): any;
        private _renderNeedsProject;
        private _renderLoading;
        private _renderAll;
        private _renderSelected;
        private _renderCustom;
        private _renderDsCard;
        private _renderHeader;
        private _renderNotice;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectDevice" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectDevice extends StateLitElement {
        value: number | null;
        selectedModule: IModule | null;
        private _genome;
        private _routeCountByDevice;
        willUpdate(changed: Map<string, unknown>): void;
        private _loadModuleData;
        private get msg();
        createRenderRoot(): this;
        render(): any;
        private _checkDeviceExists;
        private _renderDeviceCard;
        private _renderDeviceStatus;
        private _dispatchSelect;
    }
}
declare module "_102027_/l2/collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
        country: string;
        svg: string;
    }
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        private lastKey;
        firstUpdated(): void;
        update(changedProperties: any): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private replayForSupport;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private createModel;
        private updateEditorContent;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewRaw extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private resizeObserver;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private observeEditorHost;
        private createModel;
        private updateEditorContent;
        private layoutEditor;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderTaskModeDetails;
        private renderTaskInfo;
        private renderlLongMemory;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesTaskPreviewAgent";
    import "_102025_/l2/collabMessagesTaskPreviewClarification";
    import "_102025_/l2/collabMessagesTaskPreviewFlexible";
    import "_102025_/l2/collabMessagesTaskPreviewTools";
    import "_102025_/l2/collabMessagesTaskPreviewResult";
    import "_102025_/l2/collabMessagesTaskPreviewRaw";
    export class CollabMessagesTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        father: HTMLElement | undefined;
        initialStep: string;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        private lastStepId;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        renderStepDetails(step: any | undefined): any;
        renderBreadcrumb(): any;
        renderRaw(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        renderWorkflow(step: {
            stepId: number;
            type: string;
            workflowName?: string;
            status?: string;
            nextSteps?: any[];
        }): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private tryNext;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PluginTaskLogPreview100554 extends StateLitElement {
        currentStepId: number;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        father: HTMLElement | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const threadSyncMap: Map<string, boolean>;
    type NotificationTarget = {
        threadId: string;
        sourceThreadId: string;
        taskId?: string;
    };
    export function removeThreadFromSync(threadId: string): void;
    export function clearThreadNotification(threadId: string): void;
    export function clearTaskNotification(taskId: string): void;
    export function refreshNotificationIndicator(): Promise<void>;
    export function markThreadReadLocally(threadId: string, lastMessageReadTime?: string, notificationTarget?: NotificationTarget): Promise<msg.ThreadPerformanceCache | undefined>;
    export function hasThreadNotificationPending(threadId: string): boolean;
    export function hasTaskNotificationPending(taskId: string): boolean;
    export function getPendingTaskNotificationsForThread(threadId: string): string[];
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IChatPreferences, IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        currentUser: msg.User | undefined;
        userId: string | undefined;
        toolbarHighlighted: boolean;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        openedFollowupActionsMessageId?: string;
        followupActionTarget?: HTMLElement;
        followupActionAnchor?: DOMRect;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        private isEditingMessage;
        private editContent;
        private showEditHistory;
        onTaskClick?: Function;
        private msg;
        private readonly documentClickHandler;
        private readonly documentScrollHandler;
        private readonly reactionEmojis;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private renderMessageContentByLanguage;
        private renderModerationNotice;
        private renderEditMessageForm;
        private renderEditHistory;
        private renderHistoryToggle;
        private hasMessageHistory;
        private hasReadConfirmationHistory;
        private renderAttachments;
        private renderAttachment;
        private renderDeleteAttachmentButton;
        private openAttachment;
        private refreshAttachmentImage;
        private loadAttachmentUrl;
        private onDeleteAttachmentClick;
        private canDeleteAttachment;
        private canWriteThread;
        private canModerateThread;
        private isMessageContentHidden;
        private canDeleteMessage;
        private canModerateMessage;
        private canEditMessage;
        private parseCompactDate;
        private getUserName;
        private formatFileSize;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderReadConfirmations;
        private renderExecutionFollowup;
        private getReadConfirmationStatusByUser;
        private getReadConfirmationKind;
        private getActiveExecutionFollowup;
        private getFollowupStatusItems;
        private hasExecutionFollowup;
        private isFollowupReaction;
        private getFollowupReactionForUser;
        private renderFollowupIcon;
        private getFollowupLabel;
        private renderUserLabel;
        private formatLocalDateTime;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private onMentionClick;
        private positionModalByTarget;
        private isCurrentThreadDirectMessage;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private getEmojiReactionListItems;
        private getFollowupReactionListItems;
        private getReactionListItems;
        private getReactionSummaryItems;
        private getReadConfirmationSummaryItems;
        private getReadConfirmationReactionListItems;
        private getActiveReadConfirmationStatuses;
        private getReactionIcon;
        private getReactionLabel;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderSideAction;
        private renderFollowupQuickActions;
        private getFollowupActions;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private onReadConfirmationPickerClick;
        private onFollowupActionClick;
        private openFollowupActionMenu;
        private closeFollowupActionMenu;
        private onDocumentClick;
        private isPopupInteractionTarget;
        private closeLocalPopups;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private positionFollowupActionMenu;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private onCopyTextClick;
        private onCopyLinkClick;
        private getMessageLink;
        private onMarkUnreadClick;
        private onForwardClick;
        private onEditClick;
        private onEditCancelClick;
        private onEditSaveClick;
        private onViewHistoryClick;
        private onHistoryToggleClick;
        private onPinClick;
        private onFavoriteClick;
        private onReadConfirmationClick;
        private onFollowupActionsMenuClick;
        private onMessageActionClick;
        private isPinned;
        private isFavorite;
        private getMentionedUserIds;
        private hasReadConfirmation;
        private hasPendingReadConfirmation;
        private hasAllReadConfirmationsConfirmed;
        private canCancelReadConfirmation;
        private closeAllPopups;
        private updateMessageMenuPlacement;
        private getMessageOrderAt;
        private normalizeMessageId;
    }
}
declare module "_102025_/l2/collabMessagesTaskRoom" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesPrompt";
    export class CollabMessagesTaskRoom extends StateLitElement {
        task: msg.TaskData | undefined;
        message: msg.Message | undefined;
        userId: string | undefined;
        private roomThread;
        private roomUsers;
        private messages;
        private loading;
        private error;
        private showScrollToBottom;
        private messagesContainer?;
        private ensuredKey;
        private lastRenderedMessageCount;
        private didInitialScroll;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onMessagesScroll;
        private scrollToBottom;
        private scrollMessagesToBottom;
        private ensureRoom;
        private ensureRoomOnServer;
        private openKnownRoom;
        private syncMessages;
        private loadLocalMessages;
        private markRoomReadLocally;
        private sendMessage;
        private cacheRoomThread;
        private getLastOrderAt;
        private getResponseLastOrderAt;
        private onThreadChange;
        private onMessageChange;
        private getUserId;
        private getParentThreadId;
        private getEnsureKey;
        private canUseTaskRoom;
        private toMessageView;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTaskDetails";
    import "_102025_/l2/collabMessagesTaskPreview";
    import "_102025_/l2/collabMessagesTaskLogPreview";
    import "_102025_/l2/collabMessagesTaskRoom";
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private contentPluginStyle;
        private forceViewRaw;
        private hasTodo;
        private currentStepId;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        isTest: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(): any;
        renderTabContent(activeTab: 'workflow' | 'step' | 'raw' | 'todo' | 'chat'): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderChat(): any;
        renderDirectClarification(): any;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private canUseTaskRoom;
        private onTaskChange;
        private normalizeServiceDetailContainer;
        private restoreServiceDetailContainer;
    }
}
declare module "_102020_/l2/plugins/selectLanguage" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export class PluginSelectLanguage extends StateLitElement {
        selectedProject: IProject | null;
        value: number | null;
        private _languages;
        private _loading;
        private _search;
        private _addSearch;
        private _addSelected;
        private _dropdownOpen;
        config: mls.l5_common.ProjectConfig | undefined;
        private _unsubTasks;
        private threadCache;
        private _taskInfoByKey;
        connectedCallback(): void;
        disconnectedCallback(): void;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _isCustom();
        private get _selectedLang();
        createRenderRoot(): this;
        render(): any;
        private _loadLanguages;
        private _executeRemoveLanguage;
        private executeAgent;
        private _executeAddLanguage;
        private _renderNeedsProject;
        private _renderLoading;
        private _renderSelected;
        private _renderAll;
        private _renderCustom;
        private _renderSpinner;
        private _renderHeader;
        private _renderNotice;
        private _renderLangCard;
        private _dispatchConfig;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectLayout" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    export class PluginSelectLayout extends StateLitElement {
        value: number | null;
        pageFile: mls.stor.IFileInfo | null;
        private _layoutOptions;
        private _designSystems;
        private _saving;
        private _saveError;
        connectedCallback(): void;
        willUpdate(changed: Map<string, unknown>): void;
        private _loadProjectConfig;
        private _loadGenome;
        private get msg();
        private _getLayoutLabel;
        private _getLayoutDesc;
        createRenderRoot(): this;
        render(): any;
        private _isConfiguredLayout;
        private _renderLayoutCard;
        private _renderNotCreatedBanner;
        private _renderDiagram;
        private _addLayoutToGenome;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectModule" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectModule extends StateLitElement {
        modules: IModule[];
        value: number | null;
        private _search;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _isCustom();
        private get _selectedModule();
        private _doSelectModule;
        createRenderRoot(): this;
        render(): any;
        private _renderSelected;
        private _renderModuleDetail;
        private _renderAll;
        private _renderCustom;
        private _renderModuleCard;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectMolecule" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IMoleculeFile {
        shortName: string;
        folder: string;
        extension: string;
        [key: string]: any;
    }
    export class PluginSelectMolecule extends StateLitElement {
        group: string;
        description: string;
        files: IMoleculeFile[];
        value: number | null;
        replaceMode: 'selected' | 'all';
        error: string;
        private get msg();
        createRenderRoot(): this;
        render(): any;
        private _renderNoMolecule;
        private _renderMolecules;
        private _renderHeader;
        private _renderReplaceModeToggle;
        private _renderVariantCard;
        private _svgMolecule;
        private _dispatchSelect;
        private _dispatchReplaceMode;
    }
}
declare module "_102020_/l2/plugins/selectOrganization" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/markdownViewer.js';
    import '/_102020_/l2/plugins/navHeader.js';
    interface IProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    interface IOrg {
        name: string;
        created_at: string;
        description: string;
        key: string;
        index: number;
        projects: IProject[];
    }
    export class PluginSelectOrganization extends StateLitElement {
        orgs: IOrg[];
        value: number | null;
        private _search;
        private readonly _descriptions;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _isCustom();
        private get _selectedOrg();
        createRenderRoot(): this;
        render(): any;
        private _renderSelected;
        private _renderSelectedOrgDetail;
        private _renderAll;
        private _renderCustom;
        private _renderOrgCard;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectPage" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectPage extends StateLitElement {
        selectedModule: IModule | null;
        value: number | null;
        reloadToken: number;
        private _pages;
        private _search;
        private _activeDevice;
        connectedCallback(): void;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _isCustom();
        private get _selectedPage();
        private get _modulePath();
        private _loadPages;
        private _dispatchConfig;
        createRenderRoot(): this;
        render(): any;
        private _renderNoModule;
        private _renderHeader;
        private _renderSelected;
        private _renderPageDetail;
        private _renderAll;
        private _renderCustom;
        private _renderPageCard;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectProject" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    interface IOrg {
        name: string;
        created_at: string;
        description: string;
        key: string;
        index: number;
        projects: IProject[];
    }
    export class PluginSelectProject extends StateLitElement {
        selectedOrg: IOrg | null;
        value: number | null;
        private _search;
        private _pluginsByCategory;
        private _openCategories;
        private _pluginsLoading;
        private _selectedPlugin;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _isCustom();
        private get _selectedProject();
        createRenderRoot(): this;
        render(): any;
        private _loadPlugins;
        private _toggleCategory;
        private _renderNeedsOrg;
        private _renderSelected;
        private _renderSelectedProjectDetail;
        private _renderPluginPanels;
        private _renderCategoryPanel;
        private _renderPluginItem;
        private _onPluginItemClick;
        private _renderAll;
        private _renderCustom;
        private _renderHeader;
        private _renderNotice;
        private _renderProjectCard;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/plugins/selectRule" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import '/_102020_/l2/plugins/navHeader.js';
    interface IModule {
        name: string;
        path: string;
    }
    export class PluginSelectRule extends StateLitElement {
        selectedModule: IModule | null;
        value: number | null;
        private _rules;
        private _search;
        private _kindFilter;
        connectedCallback(): void;
        willUpdate(changed: Map<string, unknown>): void;
        private get msg();
        private get _isAll();
        private get _selectedRule();
        private get _kinds();
        private _loadRules;
        private _dispatchConfig;
        createRenderRoot(): this;
        private get _modulePath();
        render(): any;
        private _renderNoModule;
        private _renderHeader;
        private _renderAll;
        private _renderSelected;
        private _renderRuleCard;
        private _renderRuleDetail;
        private _dispatchSelect;
    }
}
declare module "_102020_/l2/skills/aura/design" {
    export const skill = "\n\n---\nname: interface-design\ndescription: Interface design for organism and molecules implemented using Lit Web Components and Tailwind CSS.\n---\n\n# Tailwind Ui\n\n## Identity\n\nYou are a Tailwind CSS expert. You understand utility-first CSS, responsive\ndesign patterns, dark mode implementation, and how to build consistent,\nmaintainable component styles.\n\nYour core principles:\n1. Utility-first - compose styles from utilities, extract components when patterns repeat\n2. Responsive mobile-first - start with mobile, add breakpoint modifiers\n3. Design system consistency - use the theme, extend don't override\n4. Performance - purge unused styles, avoid arbitrary values when possible\n5. Accessibility - proper contrast, focus states, reduced motion\n\n# Implementation Stack\n\nAll interfaces must be implemented using:\n\n- **Lit 3.0 Web Components**\n- **Tailwind CSS**\n- **Semantic tokens mapped in Tailwind config**\n\n# Designing Frontend\n\n## Workflow\n\n1. **Conceptualize**\n   - Identify purpose and user context\n   - Choose a bold aesthetic direction (brutally minimal, maximalist, retro-futuristic, organic, luxury, brutalist, etc.)\n   - Define the one unforgettable element\n   - Note technical constraints (framework, performance, accessibility)\n\n2. **Implement**\n   - Write production-grade code (HTML/CSS/JS.)\n   - Apply aesthetic guidelines below\n\n3. **Verify**\n   - Check visual hierarchy and cohesion\n   - Test interactions and animations\n   - Validate accessibility requirements\n   - Confirm no generic patterns emerged\n\n4. **Iterate**\n   - Refine details based on verification\n   - Enhance distinctiveness where needed\n\n## Aesthetic Guidelines\n\n**Typography**\n- Use distinctive, characterful fonts (avoid Inter, Roboto, Arial, system fonts)\n- Pair expressive display fonts with refined body fonts\n\n**Color & Theme**\n- Build cohesive palettes with CSS variables\n- Use dominant colors with sharp accents, not evenly-distributed schemes\n- Avoid clich\u00E9d combinations (purple gradients on white)\n\n**Motion**\n- Create high-impact moments with orchestrated page loads and staggered reveals\n- Use CSS animations for HTML; Motion library for React\n- Add surprising hover states and scroll-triggered effects\n\n**Spatial Composition**\n- Break from grid conventions: asymmetry, overlap, diagonal flow\n- Use generous negative space OR intentional density\n\n**Backgrounds & Visual Effects**\n- Layer gradient meshes, noise textures, geometric patterns\n- Apply contextual effects: layered transparencies, dramatic shadows, decorative borders\n- Add atmosphere through depth and texture\n\n## Implementation Principles\n\n- **Match complexity to vision**: Maximalist designs require elaborate code; minimalist designs demand precision in spacing and typography\n- **Vary every design**: Different fonts, themes, aesthetics for each project\n- **Never converge**: Avoid repeated choices (Space Grotesk, common layouts)\n- **Context-specific**: Design should feel genuinely crafted for its purpose\n\n## Every Choice Must Be A Choice\n\nFor every decision, you must be able to explain WHY.\n\n- Why this layout and not another?\n- Why this color temperature?\n- Why this typeface?\n- Why this spacing scale?\n- Why this information hierarchy?\n\nIf your answer is \"it's common\" or \"it's clean\" or \"it works\" \u2014 you haven't chosen. You've defaulted. Defaults are invisible. Invisible choices compound into generic output.\n\n**The test:** If you swapped your choices for the most common alternatives and the design didn't feel meaningfully different, you never made real choices.\n";
}
declare module "_102020_/l2/skills/aura/language" {
    export const skill = " \n\nPara definir o bloco i18n no sistema collab codes, deve seguir o padr\u00E3o:\n\n```typescript\n\n/// **collab_i18n_start**\n\nconst message_en: Record<string, string> = {\n    text1: 'value1'\n}\n\ntype MessageType = typeof message_en;\nconst messages: { [key: string]: MessageType } = { en: message_en };\n\n/// **collab_i18n_end**\n\n```\n\nPara cada nova linguagem deve ser adicionado um novo objeto com keys values das languages.\n\n";
}
declare module "_102020_/l2/skills/aura/moleculeGeneration2" {
    export const skill = "# Molecule Generation Skill\n\n> Skill for generating UI Molecule components in the Collab system.\n\n---\n\n\n## 1. Metadata\n\n| Field       | Value                                                           |\n|-------------|-----------------------------------------------------------------|\n| **Name**    | moleculeGeneration                                              |\n| **Version** | 2.6.0                                                           |\n| **Category**| ui-generation                                                   |\n\n---\n\n## 2. Core Principles\n\nMolecules are **UI-first** components that follow these rules:\n\n| Principle              | Description                                                      |\n|------------------------|------------------------------------------------------------------|\n| **No Business Logic**  | Molecules do NOT contain business logic                          |\n| **No Shadow DOM**      | Molecules do NOT use Shadow Root                                 |\n| **Independence**       | Molecules must function independently                            |\n| **Data Flow**          | Data flows DOWN from Organisms via properties; events flow UP    |\n| **Slot Tags**          | Use Slot Tags (unknown HTML elements) for internal structure     |\n| **Contract-Based**     | Each molecule belongs to a Skill Group with a defined contract   |\n| **Interchangeable**    | Molecules in the same group can be swapped without breaking      |\n\n---\n\n## 3. Naming Conventions\n\n\n### Class Name\n```\nPascalCase + Molecule\n```\n**Example:** `SelectMolecule`\n\n---\n\n## 4. Import Structure\n\n```typescript\n\nimport { html, ...} from 'lit';\nimport { customElement, ... } from 'lit/decorators';\n\n// Data Binding decorators\nimport { propertyDataSource, propertyCompositeDataSource } from '_102029_/l2/collabDecorators';\n\n// Base Class\nimport { MoleculeAuraElement } from '_102033_/l2/moleculeBase';\n```\n\n\n> **Note:** Do NOT import `classMap`. Use template strings for CSS classes instead (see Section 7).\n\n---\n\n\n## 5. Property Decorators\n\n### `@propertyDataSource`\nBinds the property to a **single dynamic state**.\n\n```typescript\n@propertyDataSource({ type: String }) \nvalue: string | undefined;\n```\n**Binding:** `{{page1.selectedId}}`\n\n---\n\n### `@propertyCompositeDataSource`\nBinds the property to **multiple composed states**.\n\n```typescript\n@propertyCompositeDataSource({ type: String }) \nlabel: string = '';\n```\n**Binding:** `Hello {{page1.userId}} - {{page1.userName}}`\n\n### Attribute mapping (important for non-string types)\n\nAll properties with **camelCase names** (more than one word) and type `Boolean`, `Number`, or `Object` **must** declare the `attribute` explicitly in kebab-case to ensure correct attribute reflection across all environments.\n\n```typescript\n@propertyDataSource({ type: Boolean, attribute: 'is-editing' })\nisEditing: boolean = false;\n\n@propertyDataSource({ type: Number, attribute: 'max-length' })\nmaxLength: number | null = null;\n\n@propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })\nminDurationMinutes: number = 0;\n```\n\nRule: `camelCase` property name \u2192 `kebab-case` attribute name, always.\n\nSingle-word properties of any type can omit the `attribute` field.\n\n---\n\n### `@@state`\nStandard Lit state for ** local UI state**.\n\n```typescript\n@state({ type: Boolean }) \nloading = false;\n```\n\n---\n\n### `@state`\n**Internal** reactive state (not exposed as an attribute).\n\n```typescript\n@state() \nprivate isOpen = false;\n```\n\n---\n\n## 6. Slot Tags\n\n### What are Slot Tags?\n\nSlot Tags are **unknown HTML elements** that define the molecule's internal structure. The user writes them declaratively, and the molecule reads and interprets them.\n\n```html\n<molecules--ml-example attr1=\"a\">\n  <SlotTagExampe></SlotTagExampe>\n  <SlotTagExampe2></SlotTagExampe2>\n  \n</molecules--ml-example>\n```\n\n### Defining Slot Tags\nEach molecule must declare which Slot Tags it uses. Use ONLY the tags defined in the group contract. Do NOT create new tags.\n\n```typescript\nslotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n```\n\nThe base class automatically hides these tags so they don't appear on screen.\n\n### Reading Slot Tags\n\nUse the helper methods from `MoleculeAuraElement`:\n\n| Method | Returns | Description |\n|--------|---------|-------------|\n| `getSlot(tag)` | `Element \\| null` | Single slot tag element |\n| `getSlots(tag)` | `Element[]` | All elements of a slot tag |\n| `getSlotAttr(tag, attr)` | `string \\| null` | Attribute value from a slot tag |\n| `getSlotContent(tag)` | `string` | innerHTML of a slot tag |\n| `hasSlot(tag)` | `boolean` | Check if slot tag exists |\n\n---\n\n## 7. Naming Rules\n\n### Do NOT use `protected` or `override` in herdeded functions\n\nAll methods and properties should be `private` or without access modifier:\n\n```typescript\n// \u274C WRONG\nprotected firstUpdated() { }\nprotected override updated() { }\n\n// \u2705 CORRECT\n\nfirstUpdated() {\n  // ...\n}\n\nprivate handleSelect(value: string) {\n  // ...\n}\n```\n\n### Reserved Method Names - Do NOT Use\n\nThese names are used by Lit internally. Using them for other purposes will cause errors:\n\n| Reserved Name | Reason |\n|---------------|--------|\n| `renderOptions` | Lit internal |\n| `renderRoot` | Lit internal |\n| `createRenderRoot` | Lit internal |\n| `connectedCallback` | Lifecycle (use only for override) |\n| `disconnectedCallback` | Lifecycle (use only for override) |\n| `attributeChangedCallback` | Lifecycle (use only for override) |\n| `requestUpdate` | Lit internal |\n| `performUpdate` | Lit internal |\n| `shouldUpdate` | Lit internal |\n| `willUpdate` | Lit internal |\n| `update` | Lit internal |\n| `updated` | Lifecycle (use only for override) |\n| `firstUpdated` | Lifecycle (use only for override) |\n\n### Use descriptive prefixes for custom methods\n\n```typescript\n// \u274C WRONG - may conflict with Lit\nrenderOptions() { }\nupdateValue() { }\n\n// \u2705 CORRECT - clear custom method names\nrenderItemList() { }\nrenderDropdownContent() { }\nrenderTriggerButton() { }\nhandleValueChange() { }\nonItemSelect() { }\n```\n\n---\n\n## 8. CSS Classes Pattern\n\n### Do NOT use `classMap` with multiple classes\n\nThe `classMap` directive expects **one class per key**. Using multiple classes as a key causes errors:\n\n```typescript\n// \u274C WRONG - causes DOMTokenList error\nclassMap({\n  'border-slate-300 bg-white': !isSelected,  // Multiple classes as key\n})\n\n// \u274C WRONG - same problem with variable\nconst base = 'w-full rounded-md px-3 py-2';\nclassMap({\n  [base]: true,  // Multiple classes as key\n})\n```\n\n### Use template strings instead\n\nBuild CSS classes using arrays and `join()`:\n\n```typescript\n// \u2705 CORRECT - template strings\nconst classes = [\n  // Base classes (always applied)\n  'w-full rounded-md px-3 py-2 text-sm border transition',\n  // Conditional classes\n  isSelected ? 'border-sky-500 bg-sky-50 text-sky-900' : 'border-slate-200 bg-white hover:bg-slate-50',\n  // State classes\n  disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',\n].join(' ');\n\nreturn html\\`<button class=\\${classes}>...</button>\\`;\n```\n\n### Pattern for complex states\n\n```typescript\nprivate getItemClasses(item: ParsedItem, isSelected: boolean): string {\n  return [\n    // Base\n    'w-full rounded-md px-3 py-2 text-sm border transition',\n    // Selection state\n    isSelected \n      ? 'border-sky-500 bg-sky-50 text-sky-900' \n      : 'border-slate-200 bg-white text-slate-900',\n    // Hover (only when not disabled)\n    !item.disabled && !isSelected ? 'hover:bg-slate-50' : '',\n    // Disabled state\n    item.disabled ? 'opacity-50 cursor-not-allowed' : '',\n    // Focus state\n    !item.disabled ? 'focus:outline-none focus:ring-2 focus:ring-sky-500' : '',\n  ].filter(Boolean).join(' ');\n}\n\n```\n\n---\n## 9. Using `nothing` Correctly\n\n### Understanding Lit's `nothing`\n\nThe `nothing` sentinel from Lit is **NOT** a `TemplateResult`. It has its own type: `typeof nothing`.\n\n**Type definitions:**\n- `TemplateResult` \u2014 returned by `html` tagged template\n- `typeof nothing` \u2014 the type of the `nothing` constant\n\n### Do NOT return `nothing` directly from methods typed as `TemplateResult`\n\nSolution 1: Wrap`nothing` in `html` template\n\n\n---\n\n## 10. Rendering Slot Tag Content\n\nSlot Tag content may contain HTML. To render it properly, use `unsafeHTML` directive.\n\n### Do NOT use dynamic template strings\n\n```typescript\n// \u274C WRONG - causes \"invalid template strings array\" error\nhtml([content] as unknown as TemplateStringsArray)\n\n// \u274C WRONG - same error\nhtml(content)\n\n// \u274C WRONG - HTML will be escaped, not rendered\nconst content = '<strong>Bold</strong>';\nhtml\\`\\${content}\\`  // Outputs: \"<strong>Bold</strong>\" as text\n```\n\n### Use `unsafeHTML` for Slot Tag content\n\n```typescript\n\n// \u2705 CORRECT - HTML is rendered properly\nprivate renderItem(item: ParsedItem): TemplateResult {\n  return html\\`\n    <div class=\"item\">\n      \\${unsafeHTML(item.label)}\n    </div>\n  \\`;\n}\n\n// \u2705 CORRECT - with fallback\nprivate renderEmpty(): TemplateResult {\n  const content = this.getSlotContent('Empty') || this.msg.noResults;\n  return html\\`\n    <div class=\"text-slate-500 dark:text-slate-400\">\n      \\${unsafeHTML(content)}\n    </div>\n  \\`;\n}\n```\n\n### When to use each approach\n\n| Content Type | Approach | Example |\n|--------------|----------|---------|\n| Plain text (i18n messages) | Direct interpolation | `\\${this.msg.loading}` |\n| Slot Tag content (may have HTML) | `unsafeHTML` | `\\${unsafeHTML(item.label)}` |\n| User input (untrusted) | Never render as HTML | Always escape |\n\n> **Note:** Slot Tag content comes from the developer (trusted), so `unsafeHTML` is safe to use.\n\n```typescript\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n  pt: {\n    placeholder: 'Selecione uma op\u00E7\u00E3o',\n    noResults: 'Nenhum resultado encontrado',\n    loading: 'Carregando...',\n  },\n};\n/// **collab_i18n_end**\n```\n\n### Usage\n```typescript\nrender() {\n  const lang = this.getMessageKey(messages);\n  this.msg = messages[lang];\n  \n  return html\\`\\${this.msg.placeholder}\\`;\n}\n```\n\n---\n\n## 11. Derived State and `handleIcaStateChange`\n\n### The Problem\n\nWhen a property is bound to a state via `@propertyDataSource`, and you have a **derived value** (a value computed from that property), the derived value won't automatically update when the state changes externally.\n\n**Example:** In an `enter-money` component:\n- `value` is bound to state: `value=\"{{playground.basic.value}}\"`\n- `rawValue` is derived from `value`: `this.rawValue = this.formatNumberToRaw(this.value)`\n- When state changes externally, `value` updates but `rawValue` does NOT recalculate\n\n### Why It Happens\n\nThe `@propertyDataSource` decorator updates the property value when state changes, but it doesn't trigger Lit's `willUpdate` or `updated` lifecycle hooks automatically.\n\n### The Solution: `handleIcaStateChange`\n\nOverride `handleIcaStateChange` to recalculate derived values when state changes:\n\n```typescript\n// ===========================================================================\n// STATE CHANGE HANDLER\n// ===========================================================================\n\nhandleIcaStateChange(key: string, value: any) {\n  // Check if this state key is bound to 'value' property\n  const valueAttr = this.getAttribute('value');\n  if (valueAttr === \\`{{\\${key}}}\\`) {\n    // Recalculate derived value\n    this.rawValue = this.formatNumberToRaw(value);\n  }\n  \n  // Always request update to re-render\n  this.requestUpdate();\n}\n```\n\n### When to Use\n\nUse `handleIcaStateChange` when your molecule has:\n\n| Situation | Example | Action |\n|-----------|---------|--------|\n| Derived/computed values | `rawValue` from `value` | Recalculate in handler |\n| Formatted display values | `displayText` from `value` | Recalculate in handler |\n| Internal state that depends on props | `isOpen` based on `value` | Update in handler |\n\n### When NOT to Use\n\nDo NOT use `handleIcaStateChange` for:\n\n| Situation | Why |\n|-----------|-----|\n| Simple property \u2192 render | Lit handles this automatically |\n| No derived values | No need for the handler |\n| Business logic | Molecules should NOT have business logic |\n\n### Complete Example\n\n```typescript\n@customElement('groupxxxyyy--enter-money')\nexport class EnterMoneyMolecule extends MoleculeAuraElement {\n\n  // Property bound to state\n  @propertyDataSource({ type: Number }) \n  value: number | null = null;\n\n  // Derived value (formatted for input display)\n  @state()\n  private rawValue: string = '';\n\n  // ===========================================================================\n  // STATE CHANGE HANDLER\n  // ===========================================================================\n\n  handleIcaStateChange(key: string, value: any) {\n    // Check if 'value' property changed\n    const valueAttr = this.getAttribute('value');\n    if (valueAttr === \\`{{\\${key}}}\\`) {\n      this.rawValue = this.formatNumberToRaw(value);\n    }\n    \n    this.requestUpdate();\n  }\n\n  // ===========================================================================\n  // HELPER METHODS\n  // ===========================================================================\n\n  private formatNumberToRaw(num: number | null): string {\n    if (num === null || num === undefined) return '';\n    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2 });\n  }\n\n  private parseRawToNumber(raw: string): number | null {\n    const cleaned = raw.replace(/\\./g, '').replace(',', '.');\n    const num = parseFloat(cleaned);\n    return isNaN(num) ? null : num;\n  }\n\n  // ===========================================================================\n  // RENDER\n  // ===========================================================================\n\n  render() {\n    return html\\`\n      <input \n        type=\"text\"\n        .value=\\${this.rawValue}\n        @input=\\${this.handleInput}\n      />\n    \\`;\n  }\n\n  private handleInput(e: Event) {\n    const input = e.target as HTMLInputElement;\n    this.rawValue = input.value;\n    this.value = this.parseRawToNumber(input.value);\n  }\n}\n```\n\n### Multiple Derived Values\n\nIf you have multiple properties with derived values:\n\n```typescript\nhandleIcaStateChange(key: string, value: any) {\n  // Check each property that might have derived values\n  const valueAttr = this.getAttribute('value');\n  const minAttr = this.getAttribute('min');\n  const maxAttr = this.getAttribute('max');\n  \n  if (valueAttr === \\`{{\\${key}}}\\`) {\n    this.rawValue = this.formatNumberToRaw(value);\n  }\n  \n  if (minAttr === \\`{{\\${key}}}\\`) {\n    this.minDisplay = this.formatNumberToRaw(value);\n  }\n  \n  if (maxAttr === \\`{{\\${key}}}\\`) {\n    this.maxDisplay = this.formatNumberToRaw(value);\n  }\n  \n  this.requestUpdate();\n}\n```\n\n---\n\n## 12. Dark Mode\n\nMolecules MUST support dark mode using Tailwind's `dark:` variant classes. The platform toggles dark mode via the `dark` class on a parent element (class-based strategy).\n\n### Rules\n\n- **Never use hardcoded light-only colors.** Every color class (`bg-*`, `text-*`, `border-*`, `ring-*`, `shadow-*`) MUST have a `dark:` counterpart.\n- **Do not use inline styles** for colors \u2014 only Tailwind classes so dark mode variants work.\n- Follow the **semantic color pairing** table below consistently across all molecules.\n\n### Semantic Color Pairing\n\n| Role | Light | Dark |\n|------|-------|------|\n| Surface (default) | `bg-white` | `dark:bg-slate-800` |\n| Surface (sunken/input bg) | `bg-slate-50` | `dark:bg-slate-900` |\n| Surface (overlay/dropdown) | `bg-white` | `dark:bg-slate-800` |\n| Border (default) | `border-slate-200` | `dark:border-slate-700` |\n| Border (focus) | `border-sky-500` | `dark:border-sky-400` |\n| Border (error) | `border-red-500` | `dark:border-red-400` |\n| Text (primary) | `text-slate-900` | `dark:text-slate-100` |\n| Text (secondary/label) | `text-slate-600` | `dark:text-slate-400` |\n| Text (placeholder) | `text-slate-400` | `dark:text-slate-500` |\n| Text (disabled) | `text-slate-400` | `dark:text-slate-600` |\n| Text (error) | `text-red-600` | `dark:text-red-400` |\n| Text (helper) | `text-slate-500` | `dark:text-slate-400` |\n| Accent (selected bg) | `bg-sky-50` | `dark:bg-sky-900/40` |\n| Accent (selected text) | `text-sky-700` | `dark:text-sky-300` |\n| Accent (selected border) | `border-sky-500` | `dark:border-sky-400` |\n| Hover (item) | `hover:bg-slate-50` | `dark:hover:bg-slate-700` |\n| Focus ring | `focus:ring-sky-500` | `dark:focus:ring-sky-400` |\n| Disabled overlay | `opacity-50` | `opacity-50` (same) |\n\n### Example \u2014 input field with dark mode\n\n```typescript\nprivate getInputClasses(): string {\n  return [\n    'w-full rounded-lg px-3 py-2 text-sm border transition',\n    'bg-white dark:bg-slate-900',\n    'text-slate-900 dark:text-slate-100',\n    'placeholder:text-slate-400 dark:placeholder:text-slate-500',\n    this.error\n      ? 'border-red-500 dark:border-red-400'\n      : 'border-slate-200 dark:border-slate-700',\n    'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',\n    this.disabled ? 'opacity-50 cursor-not-allowed' : '',\n  ].filter(Boolean).join(' ');\n}\n```\n\n### Example \u2014 dropdown item list with dark mode\n\n```typescript\nprivate getItemClasses(item: ParsedItem, isSelected: boolean): string {\n  return [\n    'w-full rounded-md px-3 py-2 text-sm transition cursor-pointer',\n    isSelected\n      ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-500 dark:border-sky-400'\n      : 'text-slate-900 dark:text-slate-100 border border-transparent',\n    !item.disabled && !isSelected\n      ? 'hover:bg-slate-50 dark:hover:bg-slate-700'\n      : '',\n    item.disabled ? 'opacity-50 cursor-not-allowed' : '',\n  ].filter(Boolean).join(' ');\n}\n```\n\n### Example \u2014 error and helper text\n\n```typescript\nprivate renderFeedback(): TemplateResult {\n  if (this.error) {\n    return html\\`<p class=\"mt-1 text-xs text-red-600 dark:text-red-400\">\\${unsafeHTML(String(this.error))}</p>\\`;\n  }\n  if (this.hasSlot('Helper')) {\n    return html\\`<p class=\"mt-1 text-xs text-slate-500 dark:text-slate-400\">\\${unsafeHTML(this.getSlotContent('Helper'))}</p>\\`;\n  }\n  return html\\`\\`;\n}\n```\n\n---\n\n13. ## SVG Rendering\n\nWhen rendering SVG elements inside a Lit template, use the `svg` tagged template for all elements **inside** the `<svg>` tag. The outer `<svg>` element stays inside `html`.\n\n### Import\n\n```typescript\nimport { html, svg, TemplateResult, unsafeHTML } from 'lit';\n```\n\n### Usage\n\n```typescript\n// \u274C WRONG \u2014 SVG children inside html`` are created in HTML namespace\nrender() {\n  return html`\n    <svg viewBox=\"0 0 100 100\">\n      ${items.map(item => html`\n        <circle cx=\"${item.x}\" cy=\"${item.y}\" r=\"5\" fill=\"${item.color}\"></circle>\n      `)}\n    </svg>\n  `;\n}\n\n// \u2705 CORRECT \u2014 SVG children use svg`` for proper SVG namespace\nrender() {\n  return html`\n    <svg viewBox=\"0 0 100 100\">\n      ${items.map(item => svg`\n        <circle cx=\"${item.x}\" cy=\"${item.y}\" r=\"5\" fill=\"${item.color}\"></circle>\n      `)}\n    </svg>\n  `;\n}\n```\n\n### Rule\n\n- `html``` \u2192 for the outer `<svg>` and all non-SVG elements\n- `svg``` \u2192 for everything **inside** the `<svg>` (path, g, circle, text, rect, line, etc.)\n- Without this, the browser creates HTMLUnknownElement instead of SVGElement and nothing renders visually\n\n## 14. Component Template\n\n```typescript\n/// <mls fileReference=\"[file-reference]\" enhancement=\"_102020_/l2/enhancementAura\"/>\n\n// =============================================================================\n// [COMPONENT NAME] MOLECULE\n// =============================================================================\n// Skill Group: [group-name] (e.g., select + one)\n// This molecule does NOT contain business logic.\n\nimport { html, ...(anothers if need) } from 'lit';\nimport { customElement ...(anothers if need) } from 'lit/decorators';\nimport { propertyDataSource } from '_102029_/l2/collabDecorators';\nimport { MoleculeAuraElement } from '_102033_/l2/moleculeBase';\n\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n};\n/// **collab_i18n_end**\n\n@customElement('groupname--[component-name]')\nexport class [ComponentName]Molecule extends MoleculeAuraElement {\n\n  private msg: MessageType = messages.en;\n\n  // ===========================================================================\n  // SLOT TAGS\n  // ===========================================================================\n\n  slotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n\n  // ===========================================================================\n  // PROPERTIES \u2014 From Contract\n  // ===========================================================================\n  \n  @propertyDataSource({ type: String }) \n  value: string | null = null;\n\n  @property({ type: Boolean }) \n  disabled = false;\n\n  @property({ type: Boolean }) \n  readonly = false;\n\n  @property({ type: Boolean }) \n  loading = false;\n\n  @property({ type: Boolean }) \n  required = false;\n\n  @property({ type: String }) \n  error: string | boolean = false;\n\n  @property({ type: String }) \n  name = '';\n\n  // ===========================================================================\n  // INTERNAL STATE\n  // ===========================================================================\n  \n  @state() \n  private isOpen = false;\n\n  // ===========================================================================\n  // STATE CHANGE HANDLER (if needed for derived values)\n  // ===========================================================================\n\n  // handleIcaStateChange(key: string, value: any) {\n  //   const valueAttr = this.getAttribute('value');\n  //   if (valueAttr === \\`{{\\${key}}}\\`) {\n  //     // Recalculate derived values here\n  //   }\n  //   this.requestUpdate();\n  // }\n\n  // ===========================================================================\n  // EVENT HANDLERS\n  // ===========================================================================\n  \n  private handleSelect(value: string) {\n    if (this.disabled || this.readonly) return;\n\n    this.value = value;\n    this.isOpen = false;\n    \n    this.dispatchEvent(new CustomEvent('change', {\n      bubbles: true,\n      composed: true,\n      detail: { value }\n    }));\n  }\n\n  private handleBlur() {\n    this.dispatchEvent(new CustomEvent('blur', {\n      bubbles: true,\n      composed: true,\n    }));\n  }\n\n  // ===========================================================================\n  // RENDER\n  // ===========================================================================\n  \n  render() {\n    const lang = this.getMessageKey(messages);\n    this.msg = messages[lang];\n\n    if (this.loading) {\n      return html\\`<div class=\"loading\">\\${this.msg.loading}</div>\\`;\n    }\n\n    const placeholder = this.getSlotAttr('Value', 'placeholder') || this.msg.placeholder;\n\n    return html\\`\n        /// Implementation here\n    \\`;\n  }\n}\n```\n\n---\n\n## 15. Skill Groups\n\nEach molecule belongs to a **Skill Group** that defines its contract:\n\nThe contract defines:\n- **Properties** (value, disabled, etc.)\n- **Events** (change, blur, etc.)\n- **Slot Tags** (Trigger, Content, Item, etc.)\n- **Validation Rules**\n\n---\n\n\n## 16. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 03/23/2026 | Initial skill definition |\n| 2.0.0 | 04/01/2026 | Added Slot Tags system, contracts, interchangeability |\n| 2.1.0 | 04/02/2026 | Replaced classMap with template strings pattern for CSS classes |\n| 2.2.0 | 04/02/2026 | Added unsafeHTML for rendering Slot Tag content |\n| 2.3.0 | 04/02/2026 | Added naming rules: no protected/override, reserved method names |\n| 2.4.0 | 04/13/2026 | Added section 9: correct usage of `nothing` with proper return types |\n| 2.5.0 | 04/16/2026 | Added section 11: handleIcaStateChange for derived values |\n| 2.6.0 | 04/22/2026 | Added section 12: dark mode \u2014 semantic color pairs and required dark: variants |\n";
}
declare module "_102020_/l2/skills/aura/overview" {
    export const skill = "\n## Skill \u2014 Frontend Architecture \u2014 Collab Aura\n\nThis document defines the official frontend architecture, design principles, and responsibilities for building applications using Collab Aura.\nAll components, pages, and integrations MUST follow these rules.\n\n## Core Architecture Principles\n### Atomic Design Structure\nThe frontend follows Atomic Design, with the following hierarchy:\n- Page \u2192 Top-level screen and orchestration layer\n- Organism \u2192 Complex UI sections composed of molecules and plugins\n- Molecule \u2192 Reusable UI components, presentation-only\n- Plugin \u2192 Integration components that communicate with external services\nEach level has a strict responsibility and separation of concerns.\n\n### Technology Stack\n- Use Lit 3 to build Web Components\n- Do NOT use Shadow DOM\n- Use Tailwind CSS for styling\n- Use SPA (Single Page Application) architecture\n- Each page corresponds to a URL entry point\n\n### Backend Communication Model\nFollow the BFF (Backend for Frontend) pattern.\nFrontend MUST communicate with backend routines using the BFF abstraction layer.\nAll backend communication MUST go through the frontend backend gateway (beInvoke or equivalent).\nDirect backend calls outside this abstraction are NOT allowed.\n\n### Data Fetching Strategy\nUse Stale-While-Revalidate (SWR) strategy for optimal perceived performance.\nThis means:\n- First attempt to load data from local IndexedDB (fast response)\n- Mark data consistency as \"stale\"\n- Then fetch fresh data from backend\n- Update state and IndexedDB when backend responds\n- Mark data consistency as \"fresh\"\nThis improves performance and user experience.\n\n## State Management\nGlobal state is used by pages and organisms.\nState naming:\nui.[pageName].[stateName]\nExamples:\nui.productDetail.product  \nui.productDetail.productConsistency  \nui.productDetail.onLoadMore  \nState types:\n- Data state \u2192 holds UI data\n- Event state \u2192 triggers actions (example: onUpdateUser)\nRules:\n- Pages MUST NOT pass data to organisms via properties, prefer states.\n- Molecules MUST NOT access global state.\n\n## Page Definitions\nA Page is a Web Component responsible for orchestrating the entire screen.\nResponsibilities:\n- Entry point of the user interface\n- Each page corresponds to a URL\n- Render the overall layout\n- Render organisms and plugins\n- Own business logic\n- Communicate with backend using BFF\n- Manage state lifecycle\n- Define state contracts for child organisms\n- Implement data fetching using SWR pattern\nPages MUST:\n- Follow business rules\n- Render SPA-compatible HTML\n- Render organisms and sections inside a root <div>\n- Orchestrate tabs and conditional content if needed\n- Update state based on backend responses\nPages MUST NOT:\n- Contain reusable UI logic that belongs in organisms\n- Contain reusable UI components that belong in molecules\nTesting:\nEach page MUST have a corresponding test file:\npageName.test.ts\nTests MUST verify:\n- Business logic\n- State transitions\n- Backend communication behavior\n\n## Organism Definitions\nOrganisms are Web Components responsible for rendering complex UI sections.\nResponsibilities:\n- Render layout sections\n- Combine molecules and plugins\n- Receive data via global states\n- Emit events via state updates\nOrganisms MUST:\n- Follow defined property contracts\n- Be reusable within the project\nOrganisms MUST NOT:\n- Communicate directly with backend\n- Own business logic\n- Fetch data\nTesting:\nEach organism MUST have:\norganismName.test.ts\nTests MUST verify:\n- Layout rendering\n- Property handling\n- State-driven rendering behavior\n\n## Molecule Definitions\nMolecules are reusable UI components.\nResponsibilities:\n- Render UI elements\n- Be highly reusable\n- Be presentation-only\nMolecules MUST:\n- Receive data only via properties\n- Be stateless regarding global application state\nMolecules MUST NOT:\n- Access global state\n- Communicate with backend\n- Contain business logic\n\n## Plugin Definitions\nPlugins are Web Components responsible for integrating with external services.\nExamples:\n- Payment platforms\n- External APIs\n- Third-party integrations\n- Analytics services\nPlugins MAY:\n- Communicate with external services\n- Provide integration functionality\nPlugins MUST NOT:\n- Contain core business logic of the application\n- Own application state\n\n## Folder and File Organization\nAll frontend files MUST follow this structure:\n_[projectId]_/l2/[moduleName]/[componentName].[extension]\nDefinitions:\n- projectId \u2192 numeric project identifier (example: 100111)\n- l2 \u2192 frontend layer\n- moduleName \u2192 module name or folder\n- componentName \u2192 component name using camelCase\n- extension \u2192 file type (ts, test.ts, defs.ts, css, etc.)\nImport rules:\n- Always use absolute project-based imports \nExample:\nimport \"/_100111_/l2/user/userProfileOrganism.js\";\n\nAll generated frontend code MUST strictly follow this architecture.\n";
}
declare module "_102020_/l2/skills/design/glassmorphism" {
    export const skill = "\n\n# Skill: Glassmorphism\n\n## Philosophy\n> \"Depth through transparency. Light caught in layers.\"\n\nComponents float above a dark gradient canvas, simulating frosted glass. The background bleeds through every surface. Hierarchy is built with opacity and blur, not color or shadow.\n\n---\n\n## Canvas\n\nThis skill is **dark only**. Components must always render over a dark gradient canvas.\n\nThe canvas color palette is **free** \u2014 chosen by the implementer. What is required is the structure:\n\n```html\n<!-- Required canvas structure -->\n<div class=\"bg-gradient-to-br from-[your-color-950] via-[your-color-950] to-[your-color-950]\">\n\n  <!-- Ambient orbs: optional but recommended for depth -->\n  <div class=\"absolute w-96 h-96 rounded-full blur-3xl pointer-events-none bg-[--your-color]/20\" />\n  <div class=\"absolute w-80 h-80 rounded-full blur-3xl pointer-events-none bg-[your-color]/20\" />\n\n</div>\n```\n\n## Canvas rules\n- Background must be **dark** (`*-900` to `*-950` range)\n- Gradient must have **at least 2 stops** for depth\n- Ambient orbs use the same hue family as the gradient, at low opacity (`/15` to `/25`)\n- Orbs must be `pointer-events-none` and positioned absolutely\n\n> Components rendered without a dark canvas will lose their visual effect entirely.\n\n---\n\n## Tokens\n\n### Glass Surface (Moderate \u2014 default)\n| Token | Value |\n|---|---|\n| Background | `bg-white/10` |\n| Backdrop blur | `backdrop-blur-md` |\n| Border | `border border-white/20` |\n| Border highlight | `border-t-white/30` (top edge only) |\n| Inner glow | `shadow-inner shadow-white/5` |\n\n> **Intensity scale for reference:**\n> - Subtle: `bg-white/5` + `backdrop-blur-sm` + `border-white/10`\n> - **Moderate: `bg-white/10` + `backdrop-blur-md` + `border-white/20`** \u2190 default\n> - Intense: `bg-white/15` + `backdrop-blur-xl` + `border-white/30`\n\n### Color\n| Token | Value |\n|---|---|\n| Text Primary | `white` |\n| Text Secondary | `white/60` |\n| Text Muted | `white/40` |\n| Accent | inherits from canvas palette |\n| Danger | inherits from implementer |\n| Success | inherits from implementer |\n\n> All semantic colors are defined by the implementer. Use `*-300` or `*-400` lightness range to ensure legibility on dark backgrounds.\n\n### Typography\n| Token | Value |\n|---|---|\n| Font family | `font-sans` |\n| Body size | `text-base` |\n| Label size | `text-sm` |\n| Heading size | `text-xl` |\n| Body weight | `font-normal` |\n| Heading weight | `font-semibold` |\n| Heading tracking | `tracking-wide` |\n| Text rendering | `antialiased` |\n\n### Spacing\n| Token | Value |\n|---|---|\n| Component padding | `p-6` |\n| Element gap | `gap-4` |\n| Section gap | `gap-8` |\n\n### Shape\n| Token | Value |\n|---|---|\n| Border radius | `rounded-2xl` |\n| Border width | `border` (1px) |\n| Outer glow | `shadow-lg shadow-black/30` |\n\n### Interaction\n| State | Value |\n|---|---|\n| Hover (surface) | `hover:bg-white/15` |\n| Hover (border) | `hover:border-white/30` |\n| Focus ring | `focus-visible:ring-1 focus-visible:ring-white/50 focus-visible:ring-offset-0` |\n| Transition | `transition-all duration-200` |\n| Active | `active:bg-white/20` |\n\n> `ring-offset-0` is intentional \u2014 offset creates visual glitching on glass surfaces.\n\n---\n\n## Layering System\n\nGlass components gain depth through stacking. Use opacity to signal hierarchy:\n\n| Layer | bg | blur | border |\n|---|---|---|---|\n| Base (canvas) | gradient | \u2014 | \u2014 |\n| Card / Panel | `white/10` | `backdrop-blur-md` | `white/20` |\n| Elevated (modal, popover) | `white/15` | `backdrop-blur-lg` | `white/25` |\n| Tooltip / Badge | `white/20` | `backdrop-blur-sm` | `white/30` |\n\n---\n\n## Rules\n\n### \u2705 Do\n- Always render over a dark gradient canvas\n- Use `border-t-white/30` on the top edge to simulate light hitting glass\n- Use ambient orbs (`blur-3xl`) behind key components to add depth\n- Keep text `white` or `white/60` \u2014 never dark text on glass\n- Use `rounded-2xl` consistently\n- Prefer `transition-all` for smooth glass state changes\n- Use `pointer-events-none` on all decorative elements\n- Derive accent color from the canvas palette\n\n### \u274C Never\n- Render components on a white or light background\n- Use opaque backgrounds (`bg-zinc-900`, `bg-slate-800`, etc.)\n- Use colored borders \u2014 only `white/*` opacity borders\n- Use `ring-offset` on focus states\n- Use `font-bold` \u2014 weight feels heavy against transparent surfaces\n- Stack more than 3 glass layers\n- Use drop shadows with color \u2014 only `shadow-black/*`\n\n---\n\n## Iconography\n- Style: **outline / stroke**\n- Stroke width: `1.5`\n- Size: `size-5`\n- Color: `text-white/70` default, accent color for emphasis\n\n---\n\n## Tone\nEthereal. Expensive. Cinematic.  \nLight passes through every surface. The canvas is always part of the component.\n\n";
}
declare module "_102020_/l2/skills/design/minimalist" {
    export const skill = "\n# Skill: Minimalist\n\n## Philosophy\n\n> \"The component exists. Nothing more.\"\n\nEverything that doesn't communicate is removed.  \nNo decorative shadows, no gradients, no unnecessary borders.  \nWhite space is not empty \u2014 it is the design itself.\n\n---\n\n## Tokens\n\n### Color\n\n| Token            | Light    | Dark     |\n|------------------|----------|----------|\n| Background       | zinc-50  | zinc-950 |\n| Surface          | white    | zinc-900 |\n| Border           | zinc-200 | zinc-800 |\n| Text Primary     | zinc-900 | zinc-50  |\n| Text Secondary   | zinc-500 | zinc-400 |\n| Accent           | zinc-900 | zinc-50  |\n\n**Note:**  \nAccent is the text itself. No separate accent color.\n\n---\n\n### Typography\n\n| Token             | Value                  |\n|-------------------|------------------------|\n| Font family       | font-sans (system-ui)  |\n| Body size         | text-base              |\n| Label size        | text-sm                |\n| Heading size      | text-lg                |\n| Body weight       | font-normal            |\n| Emphasis weight   | font-medium            |\n| Heading tracking  | tracking-tight         |\n\n**Rule:**  \nNever use `font-bold` or `font-semibold`.\n\n---\n\n### Spacing\n\n| Token             | Value                |\n|-------------------|----------------------|\n| Component padding | p-6 or p-8           |\n| Element gap       | gap-4 or gap-6       |\n| Section gap       | gap-8 or gap-12      |\n\n**Rule:**  \nWhen in doubt, add more space.\n\n---\n\n### Shape\n\n| Token         | Value                                      |\n|---------------|--------------------------------------------|\n| Border radius | rounded-none or rounded-sm                 |\n| Border width  | border (1px)                               |\n| Border color  | border-zinc-200 / dark:border-zinc-800     |\n| Shadow        | none                                       |\n\n---\n\n### Interaction\n\n| State        | Value                                                                 |\n|--------------|-----------------------------------------------------------------------|\n| Hover (bg)   | hover:bg-zinc-100 / dark:hover:bg-zinc-800                           |\n| Hover (text) | hover:text-zinc-600                                                  |\n| Focus ring   | focus-visible:ring-1 focus-visible:ring-zinc-900 focus-visible:ring-offset-2 |\n| Transition   | transition-colors duration-150                                       |\n| Active       | active:bg-zinc-200                                                   |\n\n**Rule:**  \nNo scale, translate, or transform effects.\n\n---\n\n## Rules\n\n### \u2705 Do\n\n- Use generous white space as a design element  \n- Use zinc scale exclusively for neutrals  \n- Separate sections with space, not dividers  \n- Use line-style icons (stroke, not fill)  \n- Keep a single level of visual hierarchy per component  \n- Prefer border over shadows for surface separation  \n\n### \u274C Never\n\n- Decorative shadows (`shadow-*`)  \n- Gradients (`bg-gradient-*`)  \n- Vibrant or saturated colors  \n- Large border radius (`rounded-lg` or above)  \n- `font-bold` or `font-semibold`  \n- Filled or colorful icons  \n- Animations beyond `transition-colors`  \n- More than 2 font sizes in a single component  \n\n---\n\n## Iconography\n\n- **Style:** outline / stroke  \n- **Stroke width:** 1 or 1.5 (never 2+)  \n- **Size:** size-4 or size-5  \n- **Color:** inherits from text (`currentColor`)  \n\n---\n\n## Tone\n\nCold. Precise. Confident through restraint.  \nThe absence of decoration is the statement.\n";
}
declare module "_102020_/l2/skills/layout/bento" {
    export const skill = "\n\n# Bento Design System Skill\n\n## Purpose\n\nThe \u201CBento\u201D design model is a visual composition system based on asymmetric grid layouts composed of modular cards.\n\nThe main goal of Bento layouts is to create modern, organized, visually dynamic interfaces using different sizes, proportions, and visual importance levels between elements.\n\nThe layout should communicate:\n\n- organization\n- modularity\n- visual hierarchy\n- premium aesthetics\n- modern interface design\n- scan-friendly structure\n\n---\n\n# Core Concept\n\nA Bento Grid behaves like a modular mosaic of cards.\n\nUnlike traditional layouts where all elements share the same size, Bento layouts intentionally mix:\n\n- large cards\n- small cards\n- wide cards\n- tall cards\n- featured areas\n- controlled asymmetry\n\nThe final composition should feel fluid, balanced, and visually intentional.\n\n---\n\n# Layout Structure\n\nA Bento layout should always be based on:\n\n- CSS Grid\n- multiple columns\n- consistent spacing\n- row and column spans\n\nConceptual example:\n\n```txt\n[ HERO LARGE     ][ SMALL ]\n[ HERO LARGE     ][ SMALL ]\n[ MEDIUM ][ MEDIUM ][ TALL ]\n```\n\n---\n\n# Mandatory Characteristics\n\n## 1. Asymmetry\n\nThe layout should NEVER look perfectly uniform.\n\nAvoid:\n\n```txt\n[ ][ ][ ]\n[ ][ ][ ]\n```\n\nPrefer:\n\n```txt\n[ LARGE ][ SMALL ]\n[ LARGE ][ SMALL ]\n[ MEDIUM ][ TALL ]\n```\n\n---\n\n## 2. Primary Featured Card\n\nEvery Bento layout should contain at least one dominant card.\n\nThis card should:\n\n- occupy more space\n- attract visual attention\n- act as the primary focal point\n\nCommon uses:\n\n- hero section\n- main feature\n- featured dashboard widget\n- product highlight\n- primary CTA\n\n---\n\n## 3. Modularity\n\nEach card should work independently.\n\nCards may contain:\n\n- images\n- text\n- charts\n- statistics\n- previews\n- buttons\n- videos\n- icons\n- features\n- testimonials\n- lists\n\n---\n\n## 4. Visual Hierarchy\n\nThe layout must clearly communicate importance levels.\n\nExample:\n\n| Priority | Visual Weight |\n|---|---|\n| High | Large |\n| Medium | Medium |\n| Low | Small |\n\n---\n\n## 5. Spacing\n\nBento layouts rely heavily on spacing consistency.\n\nUse:\n\n- balanced gaps\n- generous padding\n- visual breathing room\n\nAvoid cramped compositions.\n\n---\n\n# Recommended Structure\n\n```txt\nSECTION\n \u251C\u2500\u2500 Header\n \u2514\u2500\u2500 Bento Grid\n      \u251C\u2500\u2500 Hero Card\n      \u251C\u2500\u2500 Feature Card\n      \u251C\u2500\u2500 Stats Card\n      \u251C\u2500\u2500 Media Card\n      \u251C\u2500\u2500 CTA Card\n      \u2514\u2500\u2500 Support Cards\n```\n\n---\n\n# Responsiveness\n\n## Desktop\n\n- rich asymmetric compositions\n- multiple columns\n- large featured areas\n\n## Tablet\n\n- partial vertical reorganization\n- reduced spans\n- simplified composition\n\n## Mobile\n\n- preferably single-column stacking\n- maintain hierarchy order\n- preserve spacing and readability\n\n---\n\n# Composition Rules\n\n## Use:\n\n- varied card sizes\n- horizontal blocks\n- vertical blocks\n- mixed content density\n- featured areas\n- large media\n- bold typography\n- visually distinct cards\n\n## Avoid:\n\n- fully symmetrical grids\n- identical card sizes\n- excessive information density\n- inconsistent alignment\n- irregular spacing\n- overcrowded layouts\n\n---\n\n# Card Types\n\n## Hero Card\n\nThe main visual element.\n\nCharacteristics:\n\n- large visual impact\n- strong headline\n- prominent placement\n\n---\n\n## Feature Card\n\nUsed to present features or benefits.\n\nMay contain:\n\n- icon\n- short description\n- mini preview\n\n---\n\n## Stats Card\n\nDisplays metrics or numbers.\n\nExamples:\n\n- analytics\n- revenue\n- users\n- performance\n- KPIs\n\n---\n\n## Media Card\n\nFocused on:\n\n- screenshots\n- videos\n- imagery\n- visual previews\n\n---\n\n## CTA Card\n\nConversion-focused block.\n\nPurpose:\n\n- encourage actions\n- display buttons\n- emphasize interaction\n\n---\n\n# Visual Style\n\nBento layouts commonly use:\n\n- rounded corners\n- soft shadows\n- layered surfaces\n- subtle gradients\n- depth effects\n- light glassmorphism\n- premium spacing\n- clean typography\n\n---\n\n# Mental Model\n\nA Bento layout should feel like a combination of:\n\n- editorial dashboard\n- modular showcase\n- smart widget system\n- modern product presentation\n\n---\n\n# Visual Rhythm\n\nThe layout should alternate between:\n\n- large and small blocks\n- dense and lightweight areas\n- text-heavy and media-heavy cards\n\nThis rhythm creates movement and improves content scanning.\n\n---\n\n# Recommended Proportions\n\nCommon examples:\n\n| Type | Span |\n|---|---|\n| Hero | 6x2 |\n| Medium | 3x1 |\n| Tall | 2x2 |\n| Small | 2x1 |\n\n---\n\n# Recommended Semantic Structure\n\nEach item may define:\n\n\\json\n{\n  \"type\": \"hero\",\n  \"importance\": \"high\",\n  \"colSpan\": 6,\n  \"rowSpan\": 2\n}\n\\\n---\n\n# Expected Visual Feeling\n\nThe design should communicate:\n\n- sophistication\n- modernity\n- clarity\n- organization\n- technology\n- premium quality\n- fluidity\n\n---\n---\n\n# Summary\n\nBento Design is a composition system based on:\n\n- asymmetric grids\n- modular cards\n- strong visual hierarchy\n- varied proportions\n- dynamic composition\n- premium organization\n- responsive adaptability\n\nThe primary goal is to transform content into a modular, visually engaging, highly scannable experience.\n\n";
}
declare module "_102020_/l2/skills/layout/compact" {
    export const skill = "\n\n# Compact Design System Skill\n\n## Purpose\n\nThe \"Compact\" design model is a visual composition system optimized for dense information display within a condensed layout.\n\nThe main goal of Compact layouts is to maximize information density without sacrificing readability, creating efficient interfaces where users can scan and access large amounts of data quickly.\n\nThe layout should communicate:\n\n- efficiency\n- information density\n- organized complexity\n- data-driven design\n- professional utility\n- rapid scanning\n\n---\n\n# Core Concept\n\nA Compact Layout prioritizes showing the maximum amount of relevant information in the minimum amount of space.\n\nUnlike spacious layouts that use generous whitespace, Compact layouts intentionally optimize:\n\n- reduced spacing between elements\n- smaller typography scales\n- tighter padding and margins\n- multi-column data presentation\n- collapsed or collapsible sections\n- abbreviated content displays\n\nThe final composition should feel efficient, organized, and functionally dense without becoming cluttered or unreadable.\n\n---\n\n# Layout Structure\n\nA Compact layout should always be based on:\n\n- tight grid systems\n- reduced vertical and horizontal spacing\n- multi-column arrangements\n- collapsible sections\n- condensed header and navigation\n\nConceptual example:\n\n```txt\n[ HEADER (slim)                       ]\n[ METRIC ][ METRIC ][ METRIC ][ METRIC ]\n[ TABLE / LIST DATA                   ]\n[ TABLE / LIST DATA                   ]\n[ SUMMARY ][ ACTIONS ][ STATUS        ]\n```\n\n---\n\n# Mandatory Characteristics\n\n## 1. Reduced Spacing\n\nAll spacing should be intentionally tighter than standard layouts.\n\nGuidelines:\n\n- section gaps reduced by 40\u201360% compared to standard\n- card padding kept to minimum viable whitespace\n- line heights tighter but still legible\n- margins condensed without touching\n- gutters narrow but consistent\n\nKey: reduce spacing, never eliminate it.\n\n---\n\n## 2. Smaller Typography Scale\n\nTypography should be scaled down to support density.\n\nRecommendations:\n\n- base body text: 13px\u201314px\n- secondary text: 11px\u201312px\n- headings: 16px\u201320px (avoid large display headings)\n- monospace fonts for data-heavy areas\n- shorter line lengths within multi-column layouts\n\n---\n\n## 3. Multi-Column Data Presentation\n\nCompact layouts should use horizontal space aggressively.\n\nTechniques:\n\n- 3\u20136 column grids for metrics\n- side-by-side data panels\n- multi-column lists\n- horizontal key-value pairs\n- table-based data displays\n\n---\n\n## 4. Collapsible and Progressive Content\n\nNot all information needs to be visible at once.\n\nPatterns:\n\n- accordion sections\n- expand/collapse toggles\n- show more / show less\n- tooltip-based details\n- hover-reveal information\n- tabbed sub-sections\n\n---\n\n## 5. Information Hierarchy Through Density\n\nImportance is communicated through density variation.\n\n| Priority | Treatment |\n|---|---|\n| Critical | Visible, bold, color-highlighted |\n| Important | Visible, normal weight |\n| Secondary | Collapsed, smaller text, muted color |\n| Tertiary | Hidden, accessible on hover or click |\n\n---\n\n# Recommended Structure\n\n```txt\nPAGE\n \u251C\u2500\u2500 Slim Header\n \u2502    \u251C\u2500\u2500 Logo (compact)\n \u2502    \u251C\u2500\u2500 Navigation (icon-based or abbreviated)\n \u2502    \u2514\u2500\u2500 Quick Actions\n \u251C\u2500\u2500 Metrics Bar\n \u2502    \u251C\u2500\u2500 KPI Card\n \u2502    \u251C\u2500\u2500 KPI Card\n \u2502    \u251C\u2500\u2500 KPI Card\n \u2502    \u2514\u2500\u2500 KPI Card\n \u251C\u2500\u2500 Primary Data Area\n \u2502    \u251C\u2500\u2500 Data Table or List\n \u2502    \u251C\u2500\u2500 Filters / Controls (inline)\n \u2502    \u2514\u2500\u2500 Pagination\n \u251C\u2500\u2500 Secondary Panels\n \u2502    \u251C\u2500\u2500 Summary Panel\n \u2502    \u251C\u2500\u2500 Activity Feed\n \u2502    \u2514\u2500\u2500 Quick Actions\n \u2514\u2500\u2500 Minimal Footer\n```\n\n---\n\n# Responsiveness\n\n## Desktop\n\n- full multi-column density\n- maximum information visible\n- hover interactions for secondary data\n- side-by-side panels and tables\n- minimal wasted space\n\n## Tablet\n\n- reduce columns from 4\u20136 to 2\u20133\n- stack secondary panels below primary\n- maintain data tables with horizontal scroll\n- keep metrics bar visible\n\n## Mobile\n\n- single-column stacking\n- collapsible sections by default\n- swipeable panels\n- sticky filters or controls\n- prioritize critical data, hide tertiary\n- touch-friendly targets (minimum 44px)\n\n---\n\n# Composition Rules\n\n## Use:\n\n- tight consistent spacing\n- small but legible typography\n- data tables and lists\n- inline filters and controls\n- icon-based navigation\n- color coding for status\n- badges and tags for categorization\n- truncated text with tooltips\n- horizontal key-value pairs\n- condensed card layouts\n\n## Avoid:\n\n- large hero sections\n- excessive whitespace\n- decorative imagery\n- large display typography\n- spacious card layouts\n- full-width single-content sections\n- unnecessary visual embellishments\n- empty state areas without purpose\n\n---\n\n# Component Types\n\n## Metrics Bar\n\nA horizontal strip of key performance indicators.\n\nCharacteristics:\n\n- 3\u20136 metrics displayed inline\n- number + label format\n- optional trend indicators (arrows, sparklines)\n- color-coded status\n- compact card or borderless style\n\n---\n\n## Data Table\n\nThe primary content display for Compact layouts.\n\nFeatures:\n\n- dense rows with reduced row height\n- sortable columns\n- inline actions\n- row hover highlights\n- fixed headers on scroll\n- optional column resizing\n- pagination or virtual scrolling\n\n---\n\n## Condensed Card\n\nSmaller cards optimized for scanning.\n\nContains:\n\n- minimal padding\n- title + 1\u20132 data points\n- status indicator\n- compact action buttons\n- truncated descriptions\n\n---\n\n## Filter Bar\n\nInline filtering and search.\n\nFeatures:\n\n- horizontal layout\n- dropdown filters\n- search input\n- active filter tags\n- clear all option\n- results count\n\n---\n\n## Activity Feed\n\nCompact list of recent events.\n\nContains:\n\n- timestamp + action + actor\n- icon indicators\n- truncated descriptions\n- link to full details\n- grouped by time period\n\n---\n\n## Summary Panel\n\nAggregated data display.\n\nFeatures:\n\n- key-value pairs\n- mini charts (sparklines, progress bars)\n- status indicators\n- compact spacing\n\n---\n\n# Visual Style\n\nCompact layouts commonly use:\n\n- monospace or condensed typefaces for data\n- subtle borders for separation (not spacing)\n- muted color palette with accent highlights\n- minimal shadows\n- thin dividers between rows\n- icon-heavy navigation\n- badge and tag systems\n- status color coding (green, yellow, red, blue)\n- hover states for additional context\n- minimal border-radius\n- flat or very subtle depth\n\n---\n\n# Mental Model\n\nA Compact layout should feel like a combination of:\n\n- analytics dashboard\n- admin panel\n- data management tool\n- monitoring console\n- professional back-office interface\n- IDE or developer tool\n\n---\n\n# Visual Rhythm\n\nThe layout should alternate between:\n\n- dense data sections and summary sections\n- tabular data and metric cards\n- active controls and passive displays\n- structured grids and flexible lists\n\nThis rhythm maintains usability despite high density.\n\n---\n\n# Recommended Proportions\n\nCommon examples:\n\n| Element | Specification |\n|---|---|\n| Header height | 40px\u201352px |\n| Row height (table) | 32px\u201340px |\n| Card padding | 8px\u201316px |\n| Section gap | 8px\u201316px |\n| Metric card width | 150px\u2013250px |\n| Typography base | 13px\u201314px |\n\n---\n\n# Recommended Semantic Structure\n\nEach element may define:\n\n\\json\n{\n  \"type\": \"metric\",\n  \"importance\": \"critical\",\n  \"collapsible\": false,\n  \"density\": \"high\"\n}\n\\\n---\n\n# Expected Visual Feeling\n\nThe design should communicate:\n\n- efficiency\n- productivity\n- data mastery\n- professional utility\n- organized complexity\n- operational control\n- functional precision\n\n---\n---\n\n# Summary\n\nCompact Design is a composition system based on:\n\n- reduced spacing and tight grids\n- high information density\n- smaller typography scales\n- multi-column data presentation\n- collapsible progressive content\n- status-driven color coding\n- responsive density adaptation\n\nThe primary goal is to maximize information visibility and scanning efficiency within a condensed, organized, and functional interface.\n\n";
}
declare module "_102020_/l2/skills/layout/sidebar" {
    export const skill = "\n\n# Sidebar Design System Skill\n\n## Purpose\n\nThe \"Sidebar\" design model is a visual composition system based on a persistent lateral navigation panel alongside a main content area.\n\nThe main goal of Sidebar layouts is to provide constant access to navigation, tools, or contextual information while keeping the main content area focused and uninterrupted.\n\nThe layout should communicate:\n\n- persistent navigation\n- application structure\n- workspace efficiency\n- hierarchical organization\n- professional tool interface\n- contextual access\n\n---\n\n# Core Concept\n\nA Sidebar Layout splits the viewport into two primary zones: a fixed lateral navigation panel and a flexible main content area.\n\nUnlike top-navigation layouts where navigation competes with content, Sidebar layouts intentionally:\n\n- separate navigation from content spatially\n- provide persistent access to all sections\n- support deep navigation hierarchies\n- maximize vertical content space\n- create an application-like experience\n\nThe final composition should feel structured, navigable, and workspace-oriented.\n\n---\n\n# Layout Structure\n\nA Sidebar layout should always be based on:\n\n- a fixed or sticky sidebar on the left (or right)\n- a flexible main content area\n- optional top bar within the content area\n- clear visual separation between sidebar and content\n\nConceptual example:\n\n```txt\n[SIDEBAR][ TOP BAR / BREADCRUMB           ]\n[       ][                                 ]\n[ NAV   ][ MAIN CONTENT                   ]\n[ NAV   ][ MAIN CONTENT                   ]\n[ NAV   ][ MAIN CONTENT                   ]\n[       ][                                 ]\n[BOTTOM ][ FOOTER (optional)              ]\n```\n\n---\n\n# Mandatory Characteristics\n\n## 1. Persistent Sidebar Panel\n\nThe sidebar must remain accessible at all times.\n\nThe sidebar should:\n\n- occupy a fixed width on the left side (most common)\n- remain visible or easily toggleable\n- span the full height of the viewport\n- contain primary navigation items\n- support collapsed/expanded states\n\nCommon sidebar behaviors:\n\n- always visible (desktop default)\n- collapsible to icons only (mini sidebar)\n- overlay mode (slides over content on mobile)\n- hidden by default with toggle (mobile)\n\n---\n\n## 2. Clear Navigation Hierarchy\n\nThe sidebar should organize navigation in a structured hierarchy.\n\nStructure:\n\n- primary sections at the top level\n- sub-navigation nested under primary items\n- expandable/collapsible groups\n- clear visual nesting indicators (indentation, icons, lines)\n- active item clearly highlighted\n\n---\n\n## 3. Spatial Separation\n\nSidebar and content must be visually distinct.\n\nTechniques:\n\n- different background colors (sidebar darker or tinted)\n- subtle border or shadow between zones\n- clear width boundary\n- independent scrolling (sidebar and content scroll separately)\n- elevation difference (sidebar slightly raised or recessed)\n\n---\n\n## 4. Content Area Independence\n\nThe main content area should function as a complete view.\n\nRequirements:\n\n- own scroll context\n- optional top bar with breadcrumbs, search, or actions\n- full-width or max-width content within the area\n- no dependency on sidebar visibility for content comprehension\n- support for any content type (tables, forms, cards, text)\n\n---\n\n## 5. Sidebar State Management\n\nThe sidebar should support multiple states gracefully.\n\nStates:\n\n- expanded (full labels + icons)\n- collapsed (icons only, mini mode)\n- hidden (completely off-screen)\n- overlay (floating over content)\n\nTransitions between states should be smooth and predictable.\n\n---\n\n# Recommended Structure\n\n```txt\nAPP SHELL\n \u251C\u2500\u2500 Sidebar\n \u2502    \u251C\u2500\u2500 Logo / Brand\n \u2502    \u251C\u2500\u2500 Primary Navigation\n \u2502    \u2502    \u251C\u2500\u2500 Nav Item 1 (active)\n \u2502    \u2502    \u251C\u2500\u2500 Nav Item 2\n \u2502    \u2502    \u2502    \u251C\u2500\u2500 Sub Item A\n \u2502    \u2502    \u2502    \u2514\u2500\u2500 Sub Item B\n \u2502    \u2502    \u251C\u2500\u2500 Nav Item 3\n \u2502    \u2502    \u2514\u2500\u2500 Nav Item 4\n \u2502    \u251C\u2500\u2500 Section Divider\n \u2502    \u251C\u2500\u2500 Secondary Navigation\n \u2502    \u2502    \u251C\u2500\u2500 Settings\n \u2502    \u2502    \u2514\u2500\u2500 Help\n \u2502    \u2514\u2500\u2500 User Profile / Footer\n \u2514\u2500\u2500 Main Area\n      \u251C\u2500\u2500 Top Bar (optional)\n      \u2502    \u251C\u2500\u2500 Breadcrumb\n      \u2502    \u251C\u2500\u2500 Search\n      \u2502    \u2514\u2500\u2500 Actions / Profile\n      \u2514\u2500\u2500 Content\n           \u251C\u2500\u2500 Page Header\n           \u251C\u2500\u2500 Content Sections\n           \u2514\u2500\u2500 Footer (optional)\n```\n\n---\n\n# Responsiveness\n\n## Desktop\n\n- sidebar always visible (expanded or collapsed)\n- content area uses remaining width\n- hover to expand collapsed sidebar (optional)\n- independent scrolling zones\n- wide content layouts\n\n## Tablet\n\n- sidebar collapsed to icon-only by default\n- expand on click/tap\n- content area uses most of the width\n- optional overlay mode\n\n## Mobile\n\n- sidebar hidden by default\n- hamburger menu toggle to reveal\n- overlay sidebar (slides from left)\n- backdrop overlay on content when sidebar is open\n- full-width content area\n- swipe gesture to open/close\n\n---\n\n# Sidebar Composition Rules\n\n## Use:\n\n- clear icon + label navigation items\n- grouped navigation sections with dividers\n- active item highlight (background, border, or indicator)\n- consistent item height and padding\n- hover states for interactive feedback\n- nested items with indentation\n- badge/counter for notifications\n- user profile or avatar at the bottom\n- logo at the top\n- collapse/expand toggle button\n\n## Avoid:\n\n- more than 2 levels of nesting visible at once\n- sidebar wider than 280px (expanded) or 64px (collapsed)\n- navigation items without icons (icons aid collapsed state)\n- inconsistent item spacing\n- scrollable sidebar without scroll indicators\n- competing navigation between sidebar and content top bar\n- decorative elements that reduce navigation space\n\n---\n\n# Sidebar Variants\n\n## Full Sidebar\n\nAlways expanded with icons and labels.\n\nCharacteristics:\n\n- 220px\u2013280px width\n- icon + label for each item\n- grouped sections\n- best for desktop-first applications\n- clear at a glance\n\n---\n\n## Mini / Collapsed Sidebar\n\nIcons only with tooltip labels.\n\nCharacteristics:\n\n- 56px\u201372px width\n- icon-only display\n- tooltip on hover showing full label\n- expand on hover or click\n- maximizes content area\n\n---\n\n## Overlay Sidebar\n\nFloats over content.\n\nCharacteristics:\n\n- hidden by default\n- slides in from the left\n- backdrop darkens content area\n- dismiss on outside click or swipe\n- primary pattern for mobile\n\n---\n\n## Dual Sidebar\n\nTwo-level navigation.\n\nCharacteristics:\n\n- thin primary sidebar with section icons\n- secondary panel expands with sub-navigation\n- content area to the right\n- suits complex applications (email, project management)\n- enterprise pattern\n\n---\n\n# Content Area Components\n\n## Top Bar\n\nHorizontal bar within the content area.\n\nContains:\n\n- breadcrumb navigation\n- page title\n- search input\n- action buttons\n- user profile / notifications\n- sidebar toggle button (mobile)\n\n---\n\n## Page Header\n\nContent page introduction.\n\nContains:\n\n- page title\n- description or subtitle\n- page-level actions (create, export, filter)\n- tab navigation (if page has sub-sections)\n\n---\n\n## Content Body\n\nThe main working area.\n\nSupports:\n\n- data tables\n- form layouts\n- card grids\n- rich text\n- dashboards\n- media galleries\n- any content type\n\n---\n\n## Detail Panel (optional)\n\nA secondary panel on the right side.\n\nUse for:\n\n- item detail view (select from list, see details)\n- context panels\n- chat or activity feeds\n- property editors\n- inspector panels\n\n---\n\n# Visual Style\n\nSidebar layouts commonly use:\n\n- darker or tinted sidebar background\n- lighter content area background\n- icon-based navigation with labels\n- subtle dividers between nav groups\n- active state with accent color or left border indicator\n- smooth collapse/expand transitions\n- minimal shadow or border between zones\n- consistent iconography system\n- user avatar in sidebar footer\n- logo in sidebar header\n- clean sans-serif typography\n- status badges and counters\n\n---\n\n# Mental Model\n\nA Sidebar layout should feel like a combination of:\n\n- desktop application\n- admin dashboard\n- email client\n- project management tool\n- IDE or code editor\n- settings management interface\n- SaaS application shell\n\n---\n\n# Visual Rhythm\n\nThe layout should provide rhythm through:\n\n- consistent sidebar as the structural anchor\n- varied content layouts per page/section\n- navigation hierarchy depth\n- active state drawing the eye\n- content area breathing room contrasting sidebar density\n\nThis rhythm creates a workspace feel with clear spatial orientation.\n\n---\n\n# Recommended Proportions\n\nCommon examples:\n\n| Element | Specification |\n|---|---|\n| Sidebar width (expanded) | 220px\u2013280px |\n| Sidebar width (collapsed) | 56px\u201372px |\n| Nav item height | 40px\u201348px |\n| Nav item padding | 12px\u201316px horizontal |\n| Top bar height | 48px\u201364px |\n| Content padding | 24px\u201332px |\n| Active indicator | 3px left border or full background |\n\n---\n\n# Recommended Semantic Structure\n\nEach navigation item may define:\n\n\\json\n{\n  \"type\": \"nav-item\",\n  \"label\": \"Dashboard\",\n  \"icon\": \"chart-bar\",\n  \"active\": true,\n  \"badge\": 5,\n  \"children\": [\n    { \"label\": \"Analytics\", \"icon\": \"trending-up\" },\n    { \"label\": \"Reports\", \"icon\": \"file-text\" }\n  ]\n}\n\\\n---\n\n# Expected Visual Feeling\n\nThe design should communicate:\n\n- application structure\n- workspace control\n- navigational clarity\n- persistent orientation\n- professional tooling\n- hierarchical organization\n- operational readiness\n\n---\n---\n\n# Summary\n\nSidebar Design is a composition system based on:\n\n- persistent lateral navigation panel\n- flexible main content area\n- clear spatial separation\n- hierarchical navigation structure\n- multiple sidebar states (expanded, collapsed, overlay)\n- independent scrolling zones\n- responsive sidebar behavior\n\nThe primary goal is to provide constant, structured navigation access while keeping the main content area focused, creating an application-like workspace experience.\n\n";
}
declare module "_102020_/l2/skills/layout/standard" {
    export const skill = "\n\n# Standard Design System Skill\n\n## Purpose\n\nThe \"Standard\" design model is a visual composition system based on a top header with a full-width content area below.\n\nThe main goal of Standard layouts is to create clean, professional, and familiar interfaces where content takes center stage with clear top-level navigation.\n\nThe layout should communicate:\n\n- clarity\n- professionalism\n- familiarity\n- content-first design\n- straightforward navigation\n- wide readability\n\n---\n\n# Core Concept\n\nA Standard Layout follows the most widely adopted web composition pattern: a persistent top header followed by a full-width content area.\n\nUnlike complex multi-panel layouts, Standard layouts prioritize:\n\n- maximum content width\n- clear top-level navigation\n- linear reading flow\n- minimal cognitive overhead\n- broad content flexibility\n\nThe final composition should feel clean, professional, and immediately understandable.\n\n---\n\n# Layout Structure\n\nA Standard layout should always be based on:\n\n- a fixed or sticky top header\n- a full-width content area below\n- optional footer at the bottom\n- vertical stacking of sections\n\nConceptual example:\n\n```txt\n[        HEADER / NAVBAR              ]\n[                                     ]\n[        HERO / BANNER                ]\n[                                     ]\n[        CONTENT SECTION 1            ]\n[                                     ]\n[        CONTENT SECTION 2            ]\n[                                     ]\n[        FOOTER                       ]\n```\n\n---\n\n# Mandatory Characteristics\n\n## 1. Persistent Top Header\n\nThe header must always be visible or easily accessible.\n\nThe header should:\n\n- span the full width of the viewport\n- contain the logo or brand identity on the left\n- contain primary navigation links\n- optionally include utility actions on the right (search, profile, CTA)\n- maintain a consistent height\n\nCommon header patterns:\n\n- fixed at the top (remains visible on scroll)\n- sticky (becomes fixed after scrolling past it)\n- static (scrolls with the page)\n\n---\n\n## 2. Full-Width Content Area\n\nThe content area below the header should utilize the full available width.\n\nThis area should:\n\n- use a max-width container for readability\n- center content horizontally\n- allow flexible section layouts within it\n- support hero banners, grids, text blocks, media, and cards\n\n---\n\n## 3. Linear Vertical Flow\n\nContent should stack vertically in a logical reading order.\n\nThe page should read top-to-bottom with clear:\n\n- section breaks\n- visual separators (spacing, background changes, or dividers)\n- content grouping\n- progressive disclosure of information\n\n---\n\n## 4. Visual Hierarchy Through Sections\n\nEach section should have a distinct visual identity.\n\nTechniques:\n\n- alternating background colors\n- varying content density\n- different section heights\n- typographic scale changes\n- whitespace variation between sections\n\n---\n\n## 5. Consistent Spacing\n\nStandard layouts rely on rhythm and repetition.\n\nUse:\n\n- consistent vertical spacing between sections\n- uniform horizontal padding\n- aligned content within the max-width container\n- predictable gutters\n\nAvoid irregular or inconsistent spacing between sections.\n\n---\n\n# Recommended Structure\n\n```txt\nPAGE\n \u251C\u2500\u2500 Header\n \u2502    \u251C\u2500\u2500 Logo\n \u2502    \u251C\u2500\u2500 Navigation\n \u2502    \u2514\u2500\u2500 Utility Actions\n \u251C\u2500\u2500 Hero Section\n \u251C\u2500\u2500 Content Section (features, cards, text)\n \u251C\u2500\u2500 Content Section (testimonials, stats)\n \u251C\u2500\u2500 Content Section (CTA, newsletter)\n \u2514\u2500\u2500 Footer\n      \u251C\u2500\u2500 Links\n      \u251C\u2500\u2500 Social\n      \u2514\u2500\u2500 Legal\n```\n\n---\n\n# Responsiveness\n\n## Desktop\n\n- full-width header with horizontal navigation\n- centered content container (max-width 1200px\u20131440px)\n- multi-column content sections where appropriate\n- generous whitespace\n\n## Tablet\n\n- header may collapse navigation into a hamburger menu\n- content sections reduce columns\n- maintain readable line lengths\n- adjust section padding\n\n## Mobile\n\n- hamburger or drawer navigation\n- single-column content stacking\n- full-width sections\n- touch-friendly tap targets\n- reduced padding but maintained spacing rhythm\n\n---\n\n# Header Composition Rules\n\n## Use:\n\n- clear brand placement (logo left)\n- horizontal navigation links (desktop)\n- utility actions grouped on the right\n- subtle bottom border or shadow for separation\n- consistent height (56px\u201380px)\n- high contrast for readability\n\n## Avoid:\n\n- overcrowded headers with too many items\n- multiple navigation rows (keep it single-level)\n- excessive decoration or heavy backgrounds\n- navigation that competes with content\n- inconsistent alignment between header elements\n\n---\n\n# Content Section Types\n\n## Hero Section\n\nThe first visual element below the header.\n\nCharacteristics:\n\n- large visual impact\n- strong headline and subheadline\n- primary CTA button\n- optional background image or gradient\n- full-width or contained within max-width\n\n---\n\n## Feature Section\n\nPresents key features or benefits.\n\nMay contain:\n\n- icon + title + description cards\n- 2\u20134 column grid\n- alternating icon-text layouts\n\n---\n\n## Stats Section\n\nDisplays metrics or social proof.\n\nExamples:\n\n- numbers with labels\n- animated counters\n- comparison data\n- achievement highlights\n\n---\n\n## Testimonial Section\n\nSocial proof through user feedback.\n\nMay contain:\n\n- quote cards\n- avatar + name + role\n- carousel or grid layout\n\n---\n\n## CTA Section\n\nConversion-focused block.\n\nPurpose:\n\n- drive specific user action\n- prominent button(s)\n- clear value proposition\n- contrasting background for emphasis\n\n---\n\n## Footer\n\nClosing section of the page.\n\nContains:\n\n- navigation links (grouped by category)\n- social media icons\n- legal information (copyright, privacy, terms)\n- optional newsletter signup\n- brand logo repetition\n\n---\n\n# Visual Style\n\nStandard layouts commonly use:\n\n- clean sans-serif typography\n- generous line heights\n- subtle section dividers\n- consistent color palette\n- high-contrast text\n- balanced whitespace\n- minimal decorative elements\n- professional photography or illustrations\n- clear button styles\n- predictable interaction patterns\n\n---\n\n# Mental Model\n\nA Standard layout should feel like a combination of:\n\n- corporate website\n- product landing page\n- professional blog\n- SaaS homepage\n- editorial publication\n\n---\n\n# Visual Rhythm\n\nThe layout should alternate between:\n\n- dense and airy sections\n- light and dark backgrounds\n- text-heavy and media-heavy sections\n- wide and constrained content areas\n\nThis rhythm creates flow and prevents monotony.\n\n---\n\n# Recommended Proportions\n\nCommon examples:\n\n| Element | Specification |\n|---|---|\n| Header height | 56px\u201380px |\n| Max content width | 1200px\u20131440px |\n| Section vertical padding | 64px\u2013120px |\n| Hero height | 400px\u2013600px or viewport-relative |\n| Footer height | flexible, 200px\u2013400px |\n\n---\n\n# Recommended Semantic Structure\n\nEach section may define:\n\n\\json\n{\n  \"type\": \"hero\",\n  \"importance\": \"high\",\n  \"fullWidth\": true,\n  \"background\": \"gradient\"\n}\n\\\n---\n\n# Expected Visual Feeling\n\nThe design should communicate:\n\n- professionalism\n- trustworthiness\n- clarity\n- accessibility\n- content-focused\n- modern simplicity\n- institutional quality\n\n---\n---\n\n# Summary\n\nStandard Design is a composition system based on:\n\n- persistent top header navigation\n- full-width content areas\n- linear vertical flow\n- clear section separation\n- consistent spacing rhythm\n- professional visual hierarchy\n- responsive adaptability\n\nThe primary goal is to create a clean, familiar, content-first experience that users can navigate effortlessly.\n\n";
}
declare module "_102020_/l2/skills/layout/tabs" {
    export const skill = "\n\n# Tabs Design System Skill\n\n## Purpose\n\nThe \"Tabs\" design model is a visual composition system based on tab navigation that separates content into distinct, switchable sections.\n\nThe main goal of Tabs layouts is to organize large amounts of related content into logical groups, allowing users to navigate between sections without leaving the page.\n\nThe layout should communicate:\n\n- organization\n- content segmentation\n- contextual navigation\n- structured exploration\n- focused attention\n- efficient space usage\n\n---\n\n# Core Concept\n\nA Tabs Layout divides content into multiple panels, each accessible through a tab control.\n\nUnlike single-flow layouts where all content is visible at once, Tabs layouts intentionally:\n\n- segment content into logical categories\n- show only one section at a time\n- provide persistent navigation between sections\n- reduce page length and scrolling\n- maintain user context within a single view\n\nThe final composition should feel organized, focused, and navigable without losing user orientation.\n\n---\n\n# Layout Structure\n\nA Tabs layout should always be based on:\n\n- a persistent tab bar (horizontal or vertical)\n- distinct content panels per tab\n- a clear active/inactive tab state\n- optional header above tabs for page-level context\n\nConceptual example:\n\n```txt\n[        HEADER / PAGE TITLE          ]\n[ TAB 1 ][ TAB 2 ][ TAB 3 ][ TAB 4  ]\n[                                     ]\n[        ACTIVE TAB CONTENT           ]\n[        ACTIVE TAB CONTENT           ]\n[        ACTIVE TAB CONTENT           ]\n[                                     ]\n```\n\n---\n\n# Mandatory Characteristics\n\n## 1. Clear Tab Navigation\n\nThe tab bar must be immediately recognizable as navigation.\n\nThe tab bar should:\n\n- clearly indicate which tab is active\n- use visual differentiation (color, border, background, underline)\n- maintain consistent tab sizing or proportional sizing\n- be horizontally scrollable if tabs overflow (mobile)\n- stay visible while interacting with content\n\nCommon tab styles:\n\n- underline indicator (minimal)\n- filled background (bold)\n- bordered/boxed tabs (classic)\n- pill-shaped tabs (modern)\n\n---\n\n## 2. Content Isolation\n\nEach tab panel should be self-contained.\n\nRequirements:\n\n- content within a tab should make sense independently\n- no critical dependencies between tabs (user should not need Tab 1 to understand Tab 3)\n- each panel can have its own internal layout\n- switching tabs should not lose user input (preserve state)\n- transitions between tabs should feel instant\n\n---\n\n## 3. Logical Content Grouping\n\nTabs should represent meaningful categories.\n\nGood tab grouping:\n\n- related content clusters (Overview, Details, Reviews)\n- workflow stages (Draft, Review, Published)\n- data views (Table, Chart, Map)\n- user roles (Admin, User, Guest)\n- time periods (Daily, Weekly, Monthly)\n\nBad tab grouping:\n\n- arbitrary splits of a single narrative\n- too many tabs (more than 7)\n- tabs with wildly different content volumes\n- single-item tabs (one paragraph only)\n\n---\n\n## 4. Active State Clarity\n\nThe user must always know which tab is selected.\n\nActive tab indicators:\n\n- bold or different color text\n- underline or bottom border\n- filled background\n- elevated or raised appearance\n- connected to content area (no visual gap)\n\nInactive tab indicators:\n\n- muted text color\n- no underline or border\n- transparent or subtle background\n- hover state for interactivity cue\n\n---\n\n## 5. Consistent Tab Bar Position\n\nThe tab bar should remain in a predictable position.\n\nOptions:\n\n- directly below the page header (most common)\n- at the top of a card or panel\n- sticky at the top during scroll (for long content)\n- left-aligned vertical tabs (for many categories)\n\nNever place tabs at the bottom of content or in unpredictable locations.\n\n---\n\n# Recommended Structure\n\n```txt\nPAGE\n \u251C\u2500\u2500 Header\n \u2502    \u251C\u2500\u2500 Page Title\n \u2502    \u251C\u2500\u2500 Description (optional)\n \u2502    \u2514\u2500\u2500 Page-Level Actions (optional)\n \u251C\u2500\u2500 Tab Bar\n \u2502    \u251C\u2500\u2500 Tab 1 (active)\n \u2502    \u251C\u2500\u2500 Tab 2\n \u2502    \u251C\u2500\u2500 Tab 3\n \u2502    \u2514\u2500\u2500 Tab 4\n \u2514\u2500\u2500 Tab Content Area\n      \u251C\u2500\u2500 Panel 1 (visible when Tab 1 active)\n      \u2502    \u251C\u2500\u2500 Section A\n      \u2502    \u251C\u2500\u2500 Section B\n      \u2502    \u2514\u2500\u2500 Section C\n      \u251C\u2500\u2500 Panel 2 (hidden)\n      \u251C\u2500\u2500 Panel 3 (hidden)\n      \u2514\u2500\u2500 Panel 4 (hidden)\n```\n\n---\n\n# Responsiveness\n\n## Desktop\n\n- full horizontal tab bar\n- all tabs visible without scrolling (up to 7)\n- content panel uses full available width\n- optional vertical tab variant for many categories\n\n## Tablet\n\n- horizontal tabs may truncate labels\n- scrollable tab bar if needed\n- content panel adapts to reduced width\n- maintain active state visibility\n\n## Mobile\n\n- horizontally scrollable tab bar\n- abbreviated or icon-only tabs\n- full-width content panel\n- swipe gesture support between tabs\n- consider converting to dropdown selector for 5+ tabs\n- sticky tab bar during scroll\n\n---\n\n# Tab Bar Composition Rules\n\n## Use:\n\n- clear active/inactive visual distinction\n- consistent tab height and alignment\n- readable labels (1\u20133 words per tab)\n- optional icons paired with labels\n- optional badge/counter on tabs (e.g., \"Messages (3)\")\n- subtle hover states on inactive tabs\n- smooth transition on tab switch\n\n## Avoid:\n\n- more than 7 tabs in a single bar\n- multi-line tab labels\n- tabs with no content\n- mixing tab styles (underline + filled)\n- tab bars that compete with page navigation\n- deep nesting (tabs within tabs within tabs)\n- inconsistent tab widths that cause layout shifts\n\n---\n\n# Tab Variants\n\n## Horizontal Underline Tabs\n\nThe most common pattern.\n\nCharacteristics:\n\n- tabs aligned horizontally\n- active tab indicated by bottom border/underline\n- minimal visual weight\n- suits 2\u20135 tabs\n\n---\n\n## Horizontal Filled Tabs\n\nBolder visual presence.\n\nCharacteristics:\n\n- active tab has filled background\n- inactive tabs are transparent\n- suits dashboard and app interfaces\n- stronger visual separation\n\n---\n\n## Pill / Segmented Tabs\n\nModern rounded style.\n\nCharacteristics:\n\n- rounded pill-shaped active indicator\n- often used in toggle-like contexts\n- suits 2\u20134 options\n- compact and modern feel\n\n---\n\n## Vertical Tabs\n\nSide-aligned navigation for many categories.\n\nCharacteristics:\n\n- tabs stacked vertically on the left\n- content area to the right\n- supports many categories (10+)\n- label + optional icon\n- suits settings, documentation, admin panels\n\n---\n\n# Content Panel Types\n\n## Overview Panel\n\nSummary or dashboard view.\n\nContains:\n\n- key metrics\n- summary cards\n- quick links to other tabs\n- recent activity\n\n---\n\n## Detail Panel\n\nIn-depth information display.\n\nContains:\n\n- form fields\n- rich text content\n- detailed data tables\n- media galleries\n\n---\n\n## List/Table Panel\n\nData-centric content.\n\nContains:\n\n- sortable/filterable tables\n- list views with actions\n- pagination\n- bulk operations\n\n---\n\n## Settings Panel\n\nConfiguration and preferences.\n\nContains:\n\n- form controls (toggles, dropdowns, inputs)\n- grouped settings sections\n- save/cancel actions\n- validation feedback\n\n---\n\n## Activity/History Panel\n\nChronological event display.\n\nContains:\n\n- timeline of events\n- user actions log\n- status changes\n- date-grouped entries\n\n---\n\n# Visual Style\n\nTabs layouts commonly use:\n\n- clean typography with clear hierarchy\n- subtle color for active tab indication\n- consistent content panel backgrounds\n- smooth transitions between tabs (fade or slide)\n- minimal decorative elements within tab bar\n- clear separation between tab bar and content\n- consistent internal padding within panels\n- neutral backgrounds with accent colors for active states\n\n---\n\n# Mental Model\n\nA Tabs layout should feel like a combination of:\n\n- browser tabs\n- settings panel\n- multi-section form\n- documentation viewer\n- dashboard with multiple views\n- content management interface\n\n---\n\n# Visual Rhythm\n\nThe layout should provide rhythm through:\n\n- consistent tab bar as the anchor point\n- varied content density per panel\n- clear panel boundaries\n- predictable content start position\n- internal section variation within panels\n\nThis rhythm maintains orientation while allowing content diversity.\n\n---\n\n# Recommended Proportions\n\nCommon examples:\n\n| Element | Specification |\n|---|---|\n| Tab bar height | 44px\u201356px |\n| Tab padding | 12px\u201324px horizontal |\n| Active indicator | 2px\u20133px underline or full background |\n| Content panel padding | 24px\u201332px |\n| Max tabs (horizontal) | 5\u20137 |\n| Max tabs (vertical) | 10\u201315 visible |\n\n---\n\n# Recommended Semantic Structure\n\nEach tab may define:\n\n\\json\n{\n  \"type\": \"tab\",\n  \"label\": \"Overview\",\n  \"icon\": \"chart\",\n  \"badge\": 3,\n  \"active\": true,\n  \"panelContent\": \"overview\"\n}\n\\\n---\n\n# Expected Visual Feeling\n\nThe design should communicate:\n\n- order\n- categorization\n- focused content\n- navigable structure\n- efficient organization\n- clean segmentation\n- contextual awareness\n\n---\n---\n\n# Summary\n\nTabs Design is a composition system based on:\n\n- tab navigation for content segmentation\n- distinct content panels per category\n- clear active/inactive tab states\n- logical content grouping\n- persistent tab bar positioning\n- smooth transitions between sections\n- responsive tab adaptations\n\nThe primary goal is to organize complex content into navigable, focused sections that users can switch between effortlessly while maintaining context and orientation.\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewData" {
    export const skill = "\n# Skill: view + data\n\n## Metadata\n\n- **Name:** viewData\n- **Version:** 1.1.0\n- **Category:** Data Display\n- **Last Updated:** 13/04/2026\n\n---\n\n## Short Description\n\n> **view + data**: Adaptive visualization of data collection. Display multiple records with defined fields and rich content. The component implementation decides the best presentation format.\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize a collection of data**. The group defines the data structure (columns, rows, cells), and each component implementation decides how to render it.\n\n### When to Use\n\n- Display collection of records\n- Multiple fields per record\n- Rich content in cells (badges, actions, composed layouts)\n- When you need a standardized data structure\n\n### When NOT to Use\n\n- Single metrics \u2192 use **view + metric**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Charts/graphs \u2192 use **view + chart**\n\n### Possible Implementations\n\n- Data Table\n- Card Grid\n- List View\n- Responsive View (adapts to viewport)\n- Compact Table\n- Kanban Board\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `selectable` | `boolean` | `false` | | `@property` | Enables row/item selection |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight on hover |\n\n> **Note:** Additional properties may be added by specific implementations (e.g., `striped`, `bordered` for table implementations).\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, data: Element }` | Fired when a row/item is clicked |\n| `selection-change` | `{ selected: number[] }` | Fired when selection changes |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n**Important:** Use ONLY the tags defined below. Do NOT create custom tags.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<Columns>` | \u2713 | Container for column definitions |\n| `<Column>` | \u2713 (min. 1) | Defines a column/field |\n| `<Rows>` | \u2713 | Container for data rows |\n| `<Row>` | \u2713 (min. 1) | A data row/item |\n| `<Cell>` | \u2713 | A data cell |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n---\n\n### `<Columns>`\n\nContainer for column definitions. **Required.**\n\n**Accepts:** `<Column>`\n\n```html\n<Columns>\n  <Column field=\"id\" header=\"ID\" />\n  <Column field=\"name\" header=\"Name\" />\n</Columns>\n```\n\n---\n\n### `<Column>`\n\nDefines a column/field. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `field` | `string` | \u2713 | Field identifier (for reference) |\n| `header` | `string` | \u2713 | Header/label text |\n| `width` | `string` | | Suggested width (e.g., \"100px\", \"20%\") |\n| `align` | `'left' | 'center' | 'right'` | | Content alignment |\n| `hidden` | `boolean` | | Hides the column |\n\n**Accepts:** None (self-closing)\n\n```html\n<Column field=\"id\" header=\"Order ID\" width=\"120px\" />\n<Column field=\"status\" header=\"Status\" align=\"center\" />\n<Column field=\"internal\" header=\"Internal\" hidden />\n```\n\n---\n\n### `<Rows>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<Row>`\n\n```html\n<Rows>\n  <Row>...</Row>\n  <Row>...</Row>\n</Rows>\n```\n\n---\n\n### `<Row>`\n\nA data row/item. **Required** (minimum 1 for non-empty state).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `selected` | `boolean` | | Marks row as selected |\n| `disabled` | `boolean` | | Disables row interaction |\n\n**Accepts:** `<Cell>`\n\n```html\n<Row>\n  <Cell>Value 1</Cell>\n  <Cell>Value 2</Cell>\n</Row>\n\n<Row selected>\n  <Cell>Selected Row</Cell>\n</Row>\n\n<Row disabled>\n  <Cell>Disabled Row</Cell>\n</Row>\n```\n\n---\n\n### `<Cell>`\n\nA data cell. **Required** (should match number of Columns).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n\n**Accepts:** Any content (text, elements, components)\n\n```html\n<!-- Simple text -->\n<Cell>John Doe</Cell>\n\n<!-- Composed content -->\n<Cell>\n  <div class=\"font-medium\">William Little</div>\n  <div class=\"text-sm text-slate-500\">william@email.com</div>\n</Cell>\n\n<!-- Badge -->\n<Cell>\n  <span class=\"badge badge-success\">Active</span>\n</Cell>\n\n<!-- Actions -->\n<Cell>\n  <div class=\"flex gap-2\">\n    <button>Edit</button>\n    <button>Delete</button>\n  </div>\n</Cell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <div class=\"text-center py-8\">\n    <span class=\"text-4xl\">\uD83D\uDCED</span>\n    <p class=\"mt-2 text-slate-500\">No records found</p>\n  </div>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when `loading` property is true.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <div class=\"text-center py-8\">\n    <Spinner />\n    <p class=\"mt-2\">Loading...</p>\n  </div>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Columns>\n\u2502   \u2514\u2500\u2500 <Column>\n\u251C\u2500\u2500 <Rows>\n\u2502   \u2514\u2500\u2500 <Row>\n\u2502       \u2514\u2500\u2500 <Cell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Columns>` | root |\n| `<Column>` | `<Columns>` |\n| `<Rows>` | root |\n| `<Row>` | `<Rows>` |\n| `<Cell>` | `<Row>` |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<Columns>` missing | error | `Missing required slot <Columns>` |\n| `<Rows>` missing | error | `Missing required slot <Rows>` |\n| No `<Column>` in Columns | error | `At least 1 <Column> is required inside <Columns>` |\n| `<Column>` without `field` | error | `<Column> requires attribute \"field\"` |\n| `<Column>` without `header` | error | `<Column> requires attribute \"header\"` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n\n---\n\n## Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal state |\n| **hover** | Mouse over (if hoverable) |\n| **selected** | Row is selected |\n| **disabled** | Row interaction disabled |\n\n---\n\n## Accessibility (Recommended)\n\n| Attribute | Application |\n|-----------|-------------|\n| `aria-busy` | When loading is true |\n| `aria-selected` | On selected rows |\n| `aria-disabled` | On disabled rows |\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 13/04/2026 | Initial contract definition |\n| 1.1.0 | 13/04/2026 | Removed view-specific properties. Focus on data structure only |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewTable" {
    export const skill = "\n\n# Skill: view + table\n\n## Metadata\n\n- **Name:** viewTable\n- **Version:** 1.0.0\n- **Category:** Data Display\n- **Last Updated:** 04/02/2026\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize structured data** in tabular format.\n\n### When to Use\n\n- Display list of records\n- Compare data across columns\n- Show structured information\n- CRUD interfaces\n\n### When NOT to Use\n\n- Few items with visual identity \u2192 use **view + cards**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Single metrics \u2192 use **view + metric**\n\n### Possible Implementations\n\n- Data Table (full-featured)\n- Table (simple display)\n- Editable Grid\n- Virtualized Table\n- Tree Table\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `striped` | `boolean` | `false` | | `@property` | Zebra-striped rows |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight row on hover |\n| `bordered` | `boolean` | `false` | | `@property` | Borders on all cells |\n| `compact` | `boolean` | `false` | | `@property` | Reduced padding |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| `@property` | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, row: Element }` | Fired when a row is clicked |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<TableHeader>` | \u2713 | Header section container |\n| `<TableBody>` | \u2713 | Body section container |\n| `<TableRow>` | \u2713 | A table row |\n| `<TableHead>` | \u2713 | Header cell |\n| `<TableCell>` | \u2713 | Data cell |\n| `<TableFooter>` | | Footer section container |\n| `<Caption>` | | Table caption/title |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n\n### `<Caption>`\n\nTable caption or title. Usually displayed above the table.\n\n**Accepts:** Any content (text, elements)\n\n```html\n<Caption>List of Users</Caption>\n```\n\n---\n\n### `<TableHeader>`\n\nContainer for header rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableHeader>\n  <TableRow>\n    <TableHead>Name</TableHead>\n    <TableHead>Email</TableHead>\n  </TableRow>\n</TableHeader>\n```\n\n---\n\n### `<TableBody>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableBody>\n  <TableRow>\n    <TableCell>John Doe</TableCell>\n    <TableCell>john@email.com</TableCell>\n  </TableRow>\n</TableBody>\n```\n\n---\n\n### `<TableFooter>`\n\nContainer for footer rows.\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableFooter>\n  <TableRow>\n    <TableCell colspan=\"2\">Total: 100 records</TableCell>\n  </TableRow>\n</TableFooter>\n```\n\n---\n\n### `<TableRow>`\n\nA table row. **Required** (minimum 1 in header and body).\n\n**Accepts:** `<TableHead>` (inside TableHeader) or `<TableCell>` (inside TableBody/TableFooter)\n\n```html\n<TableRow>\n  <TableCell>Data 1</TableCell>\n  <TableCell>Data 2</TableCell>\n</TableRow>\n```\n\n---\n\n### `<TableHead>`\n\nA header cell. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, icons, sort indicators)\n\n```html\n<TableHead>Name</TableHead>\n<TableHead colspan=\"2\">Contact Info</TableHead>\n```\n\n---\n\n### `<TableCell>`\n\nA data cell. **Required** (minimum 1 per row).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, badges, buttons, etc.)\n\n```html\n<TableCell>John Doe</TableCell>\n<TableCell>\n  <Badge>Active</Badge>\n</TableCell>\n<TableCell>\n  <Button size=\"sm\">Edit</Button>\n</TableCell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows in the table.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <Icon name=\"inbox\" />\n  <span>No records found</span>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when the table is in loading state.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <Spinner />\n  <span>Loading data...</span>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u2502\u2500\u2500 <Caption>\n\u2502\u2500\u2500 <TableHeader>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableHead>\n\u2502\u2500\u2500 <TableBody>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableCell>\n\u2502\u2500\u2500 <TableFooter>\n\u2502       \u2514\u2500\u2500 <TableRow>\n\u2502           \u2514\u2500\u2500 <TableCell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Caption>` | `<Table>` |\n| `<TableHeader>` | `<Table>` |\n| `<TableBody>` | `<Table>` |\n| `<TableFooter>` | `<Table>` |\n| `<TableRow>` | `<TableHeader>`, `<TableBody>`, `<TableFooter>` |\n| `<TableHead>` | `<TableRow>` (inside TableHeader) |\n| `<TableCell>` | `<TableRow>` (inside TableBody or TableFooter) |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n### Slot Validation\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<TableHeader>` missing | error | `Missing required slot <TableHeader>` |\n| `<TableBody>` missing | error | `Missing required slot <TableBody>` |\n| No `<TableRow>` in header | error | `At least 1 <TableRow> is required inside <TableHeader>` |\n| No `<TableHead>` in header row | error | `At least 1 <TableHead> is required inside header <TableRow>` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n| Tag in invalid position | warning | `<TagName> is not valid inside <ParentTag>, ignored` |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Normal display | Shows table with data |\n| **loading** | Loading data | Shows loading indicator, hides body |\n| **empty** | No data | Shows empty state message |\n| **striped** | Zebra rows | Alternating row background colors |\n| **hoverable** | Row hover | Highlight row on mouse over |\n\n### Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal row |\n| **hover** | Mouse over row |\n| **selected** | Row is selected (if selection enabled) |\n\n### Cell States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal cell |\n| **truncated** | Content overflow with ellipsis |\n\n---\n\n## Accessibility (Recommended)\n\n### Semantic Structure\n\n| Element | Renders As |\n|---------|------------|\n| `<Caption>` | `<caption>` |\n| `<TableHeader>` | `<thead>` |\n| `<TableBody>` | `<tbody>` |\n| `<TableFooter>` | `<tfoot>` |\n| `<TableRow>` | `<tr>` |\n| `<TableHead>` | `<th scope=\"col\">` |\n| `<TableCell>` | `<td>` |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| `role=\"table\"` | Applied automatically via semantic HTML |\n| `aria-busy` | When loading is true |\n| `aria-rowcount` | Total number of rows (if known) |\n| `aria-colcount` | Total number of columns |\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| `Tab` | Move between interactive elements in cells |\n| `Arrow Keys` | Navigate between cells (if cell navigation enabled) |\n\n---\n\nEach implementation decides internally:\n- Visual styling (spacing, borders, colors)\n- Additional features (sorting, filtering, pagination)\n- How it renders each slot tag\n\nThe contract ensures **structural compatibility** across all implementations in the group.\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 04/02/2026 | Initial contract definition |\n";
}
declare module "_102020_/l2/skills/molecules/index" {
    export const skills: {
        name: string;
        description: string;
        skillReference: string;
        skillUsageReference: string;
    }[];
}
declare module "_102020_/l2/skills/molecules/indexGroupPage" {
    export const skill = "# Metadata\n- Files: l2/molecules/{groupname}/index.ts  +  l2/molecules/{groupname}/index.html\n- CustomElement: molecules--{groupname}--index-{actualProjectId}\n- ClassName: Group{GroupName}Index\n- {groupname} is ALWAYS the group name in lowercase (e.g. groupEnterBoolean \u2192 groupenterboolean).\n  Apply lowercase in: imports, custom element tag names in the template, and fileReference path in the triple-slash header.\n\n# Objective\nCreate a visual showcase page for a molecule group that presents every component in the group with live interactive examples and a quick-reference decision table. The page serves as both documentation and a live playground, helping developers pick the right component for their context.\n\n# Structure\n\n## index.ts\nA Lit Web Component extending StateLitElement, composed of three mandatory sections each implemented as a private method returning TemplateResult.\n\n## index.html\nA single line containing only the custom element tag:\n<molecules--{groupname}--index-{actualProjectId}></molecules--{groupname}--index-{actualProjectId}>\n\n# Section layouts (follow exactly \u2014 do not invent alternative structures)\n\n## renderHero()\n\n```html\n<header class=\"bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-8 py-20 text-center\">\n  <span class=\"inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 rounded-full text-xs font-semibold uppercase tracking-widest mb-6\">\n    {groupname in camelCase}\n  </span>\n  <h1 class=\"text-5xl font-bold text-slate-900 dark:text-slate-50 mb-5 tracking-tight\">\n    {Short human label, e.g. \"Enter Boolean\"}\n  </h1>\n  <p class=\"text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed\">\n    {1\u20132 sentence subtitle describing the shared problem space and available implementations}\n  </p>\n</header>\n```\n\n## renderShowcaseCards()\n\n```html\n<section class=\"bg-slate-50 dark:bg-slate-950 px-8 py-12 border-b border-slate-200 dark:border-slate-700\">\n  <div class=\"max-w-2xl mx-auto flex flex-col gap-5\">\n\n    <!-- Repeat this block for each card: -->\n    <div class=\"bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm\">\n      <div class=\"h-1 bg-{color}-500 rounded-t-2xl\"></div>\n      <div class=\"p-6\">\n        <div class=\"flex items-center justify-between mb-1\">\n          <p class=\"text-sm font-bold text-slate-900 dark:text-slate-50\">Display Name</p>\n          <code class=\"text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded\">tag-name</code>\n        </div>\n        <p class=\"text-xs text-slate-400 mb-5\">One-line context description</p>\n        <{groupname}--{component} name=\"card-{x}\" .value=${this.cardX} .isEditing=${true}\n          @change=${(e: CustomEvent) => { this.cardX = e.detail.value; }}>\n          <!-- Populate all available slot tags with realistic content (Label, Helper, Item, etc.) -->\n        </{groupname}--{component}>\n      </div>\n    </div>\n\n  </div>\n</section>\n```\n\nAccent bar colors rotate through: violet, emerald, amber, rose, sky, indigo, purple, teal, orange, pink \u2014 one distinct color per card.\nA group may show the same component more than once when different configurations deserve separate illustration.\n\n## renderReferenceTable()\n\n```html\n<section class=\"bg-slate-100 dark:bg-slate-950 px-8 py-20 border-t border-slate-200 dark:border-slate-700\">\n  <div class=\"max-w-5xl mx-auto\">\n    <h2 class=\"text-2xl font-bold text-slate-900 dark:text-slate-50 mb-2\">Quick reference</h2>\n    <p class=\"text-sm text-slate-500 dark:text-slate-400 mb-8\">{subtitle tailored to this group's decision \u2014 NOT a fixed string}</p>\n    <div class=\"bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm\">\n      <table class=\"w-full text-sm\">\n        <thead>\n          <tr class=\"bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700\">\n            <th class=\"text-left px-5 py-3.5 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide w-3/4\">Scenario</th>\n            ${headers.map(h => html`\n              <th class=\"px-4 py-3.5 text-xs font-semibold uppercase tracking-wide ${h.cls}\">${h.label}</th>\n            `)}\n          </tr>\n        </thead>\n        <tbody>\n          ${rows.map((row, i) => html`\n            <tr class=\"${i % 2 !== 0 ? 'bg-slate-50/60 dark:bg-slate-900/40' : ''} border-b border-slate-100 dark:border-slate-700/60 last:border-0\">\n              <td class=\"px-5 py-3.5 text-slate-700 dark:text-slate-300\">${row.scenario}</td>\n              ${([row.componentA, row.componentB] as boolean[]).map(ok => html`\n                <td class=\"px-4 py-3.5 text-center\">\n                  ${ok\n                    ? html`<span class=\"inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 text-xs font-bold\">\u2713</span>`\n                    : html`<span class=\"text-slate-200 dark:text-slate-700 text-sm\">\u2014</span>`}\n                </td>\n              `)}\n            </tr>\n          `)}\n        </tbody>\n      </table>\n    </div>\n  </div>\n</section>\n```\n\nImplement the `rows` and `headers` arrays at the top of renderReferenceTable(), before the return statement:\n\n```ts\nconst rows: Array<{ scenario: string; componentA: boolean; componentB: boolean }> = [\n  { scenario: '...', componentA: true,  componentB: false },\n  { scenario: '...', componentA: false, componentB: true  },\n];\nconst headers = [\n  { label: 'Component A', cls: 'text-{colorA}-600 dark:text-{colorA}-400' },\n  { label: 'Component B', cls: 'text-{colorB}-600 dark:text-{colorB}-400' },\n];\n```\n\nAdapt the field names (componentA, componentB, ...) to the actual component names of the group.\nEvery distinct component in the group must appear as a column.\n\n# Responsibilities\n- Declare the custom element with @customElement('molecules--{groupname}--index-{actualProjectId}')\n- Name the class Group{GroupName}Index (PascalCase, e.g. GroupEnterBooleanIndex)\n- Always include these three imports at the top of index.ts, in this order:\n  import { html, TemplateResult } from 'lit';\n  import { customElement, state } from 'lit/decorators';\n  import { StateLitElement } from '_102029_/l2/stateLitElement';\n- Import each component module from its canonical path before using it in the template:\n  import '/_actualProjectId_/l2/molecules/{groupname}/{component-name}';\n  (groupname is lowercase in the import path)\n- Declare one @state() property per showcase card with a sensible default for the value type:\n  boolean \u2192 false, string \u2192 '', number \u2192 0 (unless a non-empty default better illustrates the component)\n- Group all showcase state declarations under the comment: // \u2500\u2500 Showcase card states \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n- Bind the value to the component correctly by type:\n  - String values: attribute binding   value=\"${this.cardX}\"\n  - Boolean / number / null values: property binding   .value=${this.cardX}\n- Separate sections with 80-char section banners: // =========================================================================== SECTION NAME\n- Compose all three sections in render() inside a single <div class=\"font-sans min-h-screen\">\n\n# Constraints\n- index.ts file header: /// <mls fileReference=\"_actualProjectId_/l2/molecules/{groupname}/index.ts\" enhancement=\"_102020_/l2/enhancementAura\"/>\n  (groupname is lowercase in the fileReference path)\n- All three sections (Hero, Showcase Cards, Reference Table) are mandatory; none may be omitted\n- Every live showcase instance must receive .isEditing=${true} and have realistic slot content for all available slot tags\n- Do not hardcode hex colors; use only Tailwind utility classes\n\n# Notes\n- Group descriptions (name, purpose, available implementations) are defined in _102020_/l2/skills/molecules/index.ts \u2014 use the corresponding entry's `description` field as the primary source for the hero subtitle and the reference table subtitle.\n";
}
declare module "_102020_/l2/skills/molecules/playgroundGenerator" {
    export const skill = "\n# Skill \u2014 Molecule Playground Generator\n> Gera p\u00E1ginas HTML interativas de demonstra\u00E7\u00E3o para Molecules do sistema Collab Aura.\n\n---\n## 1. Metadata\n\n| Field       | Value                              |\n|-------------|------------------------------------|\n| **Name**    | `moleculePlaygroundGenerator`    |\n| **Version** | `2.6.0`                          |\n\n---\n\n## 2. Tag Name \u2014 CRITICAL RULE\n\n**Extract the component tag name MUST be copied verbatim from the `@customElement(...)` decorator in the `.ts` file.**\nUse same tag in playground example\n\n### Rules\n\n- **Never derive** the tag name from the file name, class name, or folder path\n- **Never reconstruct** the tag name using the naming convention formula\n- **Always read** the `@customElement(...)` value from the `.ts` source\n- Opening tag and closing tag MUST be **identical strings**\n\n### Why\n\nThe naming convention formula (`kebab-case(folder)--kebab-case(component)-(projectId)`) is used when **creating** a new molecule. When **generating a playground** for an existing molecule, the tag already exists in the `.ts` \u2014 use it directly.\n\n---\n\n## 3. Property Analysis (was \u00A72)\n\n### 2.1 Classifica\u00E7\u00E3o por Decorator\n\n| Decorator | Vai no State? | Binding |\n|-----------|---------------|---------|\n| `@propertyDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@propertyCompositeDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@property` | \u2717 N\u00C3O | Valor direto |\n| `@state` | \u2717 N\u00C3O | N\u00E3o aparece |\n\n## Attribute Names in HTML (non-string properties)\n\nProperties decorated with `@propertyDataSource` that have type `Boolean`, `Number`, or `Object` and a camelCase name **must use the kebab-case `attribute` name in HTML**, not the TypeScript property name.\n\nAlways check the decorator in the `.ts` file to find the correct attribute name:\n\n```typescript\n// Declared in the .ts\n@propertyDataSource({ type: Boolean, attribute: 'is-editing' })\nisEditing: boolean = false;\n\n@propertyDataSource({ type: Number, attribute: 'max-length' })\nmaxLength: number | null = null;\n```\n\n```html\n<!-- \u274C WRONG \u2014 TypeScript property name used as HTML attribute -->\n<molecules--my-component isEditing=\"true\" maxLength=\"100\">\n\n<!-- \u2705 CORRECT \u2014 kebab-case attribute name from the decorator -->\n<molecules--my-component is-editing=\"true\" max-length=\"100\">\n```\n\nThis applies to all HTML in the playground: `<demo>` element and `<template>` block.\n\n---\n\n## 4. State\n\n### 3.1 Formato\n\n```html\n<widget-playground-state-102020 state='playgroundDinamicState'></widget-playground-state-102020> // playgroundDinamicState will be replaced after, dont change\n```\n\n### 3.2 Posi\u00E7\u00E3o no HTML\n\nO `widget-playground-state-102020` DEVE vir ANTES de qualquer demo no HTML.\n\n### 3.3 Valores Default por Tipo\n\n| Tipo | Default |\n|------|---------|\n| string | `\"\"` |\n| number | `0` |\n| boolean | `false` |\n\n---\n\n## 5. Property Editors\n\n### 4.1 Widget por Tipo\n\n| Tipo da Propriedade | Widget |\n|---------------------|--------|\n| string | `widget-playground-state-text-102020` |\n| string | null | `widget-playground-state-text-102020` |\n| number | `widget-playground-state-number-102020` |\n| number | null | `widget-playground-state-number-102020` |\n| boolean | `widget-playground-state-boolean-102020` |\n\n### 4.2 Exemplos\n\n**String:**\n```html\n<widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n```\n\n**Number:**\n```html\n<widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n```\n\n**Boolean:**\n```html\n<widget-playground-state-boolean-102020 label=\"showIcon\" value=\"{{playground.basic.showIcon}}\"></widget-playground-state-boolean-102020>\n```\n\n---\n\n## 6. Styling (Tailwind)\n\nAll elements MUST include `dark:` variants so the playground renders correctly in both light and dark themes.\n\n| Elemento | Classes |\n|----------|---------|\n| Page root | `bg-white dark:bg-slate-900 min-h-screen` |\n| Container | `mx-auto p-8 font-sans` |\n| Header | `text-center mb-12` |\n| Title | `text-3xl font-semibold text-slate-800 dark:text-slate-100 mb-2` |\n| Badge | `inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 rounded-full text-sm font-medium` |\n| Grid | `grid grid-cols-1 md:grid-cols-2 gap-6 mb-12` |\n| Card | `bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6` |\n| Card Title | `text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4` |\n| Details | `mt-4` |\n| Summary | `cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400` |\n| Details Content | `mt-2 p-4 border border-slate-200 dark:border-slate-700 rounded-lg dark:bg-slate-900` |\n\n---\n\n## 7. HTML Structure\n\n### 6.1 Ordem dos Elementos\n\n1. Container\n2. Header\n3. `widget-playground-state-102020` (SEMPRE antes das demos)\n4. Section com demos\n\n### 6.2 Demo Card\n\n```html\n<div class=\"bg-white dark:bg-slate-900 min-h-screen\">\n<div class=\"mx-auto p-8 font-sans\">\n\n  <header class=\"text-center mb-12\">\n    <h1 class=\"text-3xl font-semibold text-slate-800 dark:text-slate-100 mb-2\">Component Name</h1>\n    <span class=\"inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 rounded-full text-sm font-medium\">skill group</span>\n  </header>\n\n  <widget-playground-state-102020 state='playgroundDinamicState'>\n  </widget-playground-state-102020>\n\n  <section class=\"grid grid-cols-1 md:grid-cols-2 gap-6 mb-12\">\n    <article class=\"bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6\">\n      <h3 class=\"text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4\">Basic</h3>\n      <demo id=\"demo-basic\">\n        <molecules--ml-component \n          value=\"{{playground.basic.value}}\"\n          error=\"{{playground.basic.error}}\"\n          disabled=\"false\"\n          is-editing=\"true\">\n          <Label>Field</Label>\n        </molecules--ml-component>\n      </demo>\n      <details class=\"mt-4\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400\">Properties</summary>\n        <div class=\"mt-2 p-4 border border-slate-200 dark:border-slate-700 rounded-lg dark:bg-slate-900\">\n          <widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n          <widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n        </div>\n      </details>\n      <details class=\"mt-2\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400\">HTML</summary>\n        <div class=\"mt-2\">\n          <widget-playground-state-preview-code-102020 target=\"demo-basic\">\n            <template>\n<molecules--ml-component \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\"\n  disabled=\"false\"\n  is-editing=\"true\">\n  <Label>Field</Label>\n</molecules--ml-component>\n            </template>\n          </widget-playground-state-preview-code-102020>\n        </div>\n      </details>\n    </article>\n  </section>\n\n</div>\n</div>\n```\n\n### 6.3 Demo Element\n\nO elemento `<demo>` DEVE:\n- Ter um `id` \u00FAnico (ex: demo-basic, demo-disabled)\n- Conter o HTML do componente (funciona independente do editor)\n\n```html\n<demo id=\"demo-basic\">\n  <molecules--ml-component \n    value=\"{{playground.basic.value}}\"\n    error=\"{{playground.basic.error}}\">\n    <Label>Field</Label>\n  </molecules--ml-component>\n</demo>\n```\n\n### 6.4 HTML Editor Widget\n\nO `widget-playground-state-preview-code-102020` recebe:\n- `target`: id do elemento demo (para atualizar ao editar)\n- `<template>`: c\u00F3digo HTML fonte (para exibir formatado no editor)\n\n**IMPORTANTE:** O HTML deve estar duplicado - no `<demo>` E no `<template>`.\n\n```html\n<widget-playground-state-preview-code-102020 target=\"demo-basic\">\n  <template>\n<molecules--ml-component \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\">\n  <Label>Field</Label>\n</molecules--ml-component>\n  </template>\n</widget-playground-state-preview-code-102020>\n```\n\nO widget:\n1. L\u00EA o HTML do `<template>` (c\u00F3digo fonte, n\u00E3o compilado)\n2. Exibe formatado no editor com syntax highlighting\n3. Ao editar, atualiza o innerHTML do `<demo>` target em tempo real\n\n---\n\n## 8. Checklist\n\n- [ ] Tag name copied verbatim from `@customElement(...)` in the `.ts` file\n- [ ] Opening tag and closing tag are identical strings\n- [ ] widget-playground-state-102020 vem ANTES das demos\n- [ ] Cada demo tem namespace pr\u00F3prio\n- [ ] Cada `<demo>` tem id \u00FAnico e cont\u00E9m o HTML do componente\n- [ ] string \u2192 widget-playground-state-text-102020\n- [ ] number \u2192 widget-playground-state-number-102020\n- [ ] boolean \u2192 widget-playground-state-boolean-102020\n- [ ] HTML duplicado: no `<demo>` E no `<template>` do editor\n- [ ] `<demo>` sem class/style\n- [ ] Page root tem `dark:bg-slate-900`\n- [ ] Todos os elementos de cor t\u00EAm variante `dark:`\n\n---\n\n## 9. Changelog\n\n| Version | Date       | Description |\n|---------|------------|-------------|\n| 2.1.0   | 2026-04-15 | Using dedicated widgets with -102020 suffix |\n| 2.2.0   | 2026-04-16 | Added HTML editor widget for live code editing |\n| 2.3.0   | 2026-04-16 | HTML editor uses template element for source code |\n| 2.4.0   | 2026-04-16 | HTML duplicated in demo AND template - demo works independently |\n| 2.5.0   | 2026-04-17 | Added \u00A72 explicit rule: tag name must be copied from @customElement, never derived |\n| 2.6.0   | 2026-04-22 | Added dark mode: dark: variants on all styling elements, page root wrapper, updated Demo Card example and checklist |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterBoolean/creation" {
    export const skill = "# groupEnterBoolean \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterBoolean** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterBoolean` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `boolean` | `false` | `@propertyDataSource` | Current boolean value. Starts as `false` until the user changes it |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled \u2014 no interaction possible |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **JavaScript boolean** (`true` or `false`)\n- Default is `false` \u2014 the component always has a defined value\n- `true` means the positive choice is active\n- `false` means the negative choice is active (or the field has not been interacted with)\n\n### View Mode\n\n- If `value` is `true`: display `\"Yes\"`\n- If `value` is `false`: display `\"No\"`\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: boolean }` | \u2713 | Value changed by user interaction |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders the interactive boolean control |\n| **View** | `false` | Renders the current value as static text |\n\n- In view mode: no interaction, no events, no error, no helper\n- In view mode with `value=true`: render `\"Yes\"`\n- In view mode with `value=false`: render `\"No\"`\n\n---\n\n## 7. Interaction Behavior Rules\n\n### Toggle / Switch\n\n- Clicking the toggle flips the value: `false \u2192 true`, `true \u2192 false`\n- Emits `change` on each toggle\n- When `disabled`: click is ignored\n\n### Checkbox\n\n- Unchecked maps to `false`; checked maps to `true`\n- Clicking flips the value and emits `change`\n- When `disabled`: click is ignored\n\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error is never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **True** | True/positive option visually active |\n| **False** | False/negative option visually inactive |\n| **Focused** | Focus ring visible on the active control element |\n| **Disabled** | Reduced opacity, pointer-events none, no interaction |\n| **Error** | Error border or highlight, error message visible below |\n| **View Mode** | Static text: \"Yes\" or \"No\" |\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Toggle/Switch | `role=\"switch\"`, `aria-checked=\"true\"` / `\"false\"` |\n| Checkbox | `<input type=\"checkbox\">` with `checked` property |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Disabled | `aria-disabled=\"true\"` and `disabled` on interactive elements |\n| Keyboard | `Space` flips the value (applies to both implementations) |\n\n---\n\n## 11. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Toggle / Switch** | Sliding switch, typically used for on/off settings |\n| **Checkbox** | Standard HTML checkbox |\n\nAll implementations share the same slot tag contract (`Label`, `Helper`), the same properties, and the same events \u2014 they are fully interchangeable. Swapping one for the other requires only changing the component tag.\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-05-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterBoolean/usage" {
    export const skill = "\n# enter + boolean \u2014 Usage\n\n> Quick reference for using molecules in the **enter + boolean** group.\n> Use this when you need the user to provide a **true/false decision**.\n> Value is always `boolean` \u2014 starts as `false` until the user changes it.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `boolean` | `false` | Current boolean value. Starts as `false` until the user changes it |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `isEditing` | `boolean` | `true` | `true` = interactive control, `false` = read-only display |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: boolean }` | Fired when the user changes the selection |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is always a native **JavaScript boolean** (`true` or `false`)\n- Default is `false` \u2014 the component always has a defined value\n- In view mode: `true` \u2192 \"Yes\"; `false` \u2192 \"No\"\n\n---\n\n## Examples\n\n### Simple toggle (on/off setting)\n\n```html\n<molecules--toggle-102020\n  value=\"{{ui.settings.notifications}}\"\n  error=\"{{ui.settings.notificationsError}}\">\n  <Label>Enable notifications</Label>\n</molecules--toggle-102020>\n```\n\n### Checkbox with terms acceptance\n\n```html\n<molecules--checkbox-102020\n  value=\"{{ui.form.acceptTerms}}\"\n  error=\"{{ui.form.acceptTermsError}}\">\n  <Label>I accept the terms and conditions</Label>\n  <Helper>You must accept to continue</Helper>\n</molecules--checkbox-102020>\n```\n\n### Interchangeability \u2014 swapping toggle for checkbox\n\nBoth components share the same contract. Only the tag changes:\n\n```html\n<molecules--toggle-102020\n  value=\"{{ui.form.acceptTerms}}\"\n  error=\"{{ui.form.acceptTermsError}}\">\n  <Label>I accept the terms and conditions</Label>\n  <Helper>You must accept to continue</Helper>\n</molecules--toggle-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/creation" {
    export const skill = "\n\n# groupEnterDate \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterDate** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterDate` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | ISO 8601 date string (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `minDate` | `string` | `''` | `@propertyDataSource` | Minimum allowed date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | `@propertyDataSource` | Maximum allowed date (`\"YYYY-MM-DD\"`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n| `firstDayOfWeek` | `number` | `0` | `@propertyDataSource` | First day of week: 0=Sunday, 1=Monday |\n| `showWeekNumbers` | `boolean` | `false` | `@propertyDataSource` | Show week numbers in the calendar |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Calendar panel is open |\n| `viewMonth` | `number` | current | `@state` | Month currently displayed in calendar |\n| `viewYear` | `number` | current | `@state` | Year currently displayed in calendar |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored as **ISO 8601 date**: `\"YYYY-MM-DD\"`\n- **No time component** \u2014 never store or emit time information\n- `null` represents no value selected\n\n### Display Format\n\n| Locale | Stored | Displayed |\n|--------|--------|-----------|\n| `en-US` | `\"2026-04-17\"` | `04/17/2026` |\n| `pt-BR` | `\"2026-04-17\"` | `17/04/2026` |\n| `de-DE` | `\"2026-04-17\"` | `17.04.2026` |\n| `en-GB` | `\"2026-04-17\"` | `17/04/2026` |\n\n### View Mode\n\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | User selected or cleared a date |\n| `monthChange` | `{ year: number, month: number }` | \u2713 | Calendar navigated to a different month |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"2026-04-17\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input trigger + calendar panel |\n| **View** | `false` | Renders formatted date as static text |\n\n- In view mode: no input, no calendar, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Open** | Calendar panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no calendar |\n\n---\n\n## 9. Value Handling\n\n### Parsing\n\n- Calendar day selection \u2192 `\"YYYY-MM-DD\"` string\n- Never derive or append a time component\n\n### minDate / maxDate\n\n- Disable calendar days that fall outside the allowed range\n- Prevent navigation to months entirely before `minDate` or after `maxDate`\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Calendar dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n| Month heading | `aria-live=\"polite\"` |\n\n---\n\n## 11. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Date Picker** | Input trigger + calendar popup |\n| **Date Input** | Masked text input (`MM/DD/YYYY`) |\n| **Calendar Inline** | Always-visible calendar, no popup |\n| **Month Picker** | Select month + year only, no day |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/usage" {
    export const skill = "\n\n# enter + date \u2014 Usage\n\n> Quick reference for using molecules in the **enter + date** group.\n> Use this when you need the user to provide a **date only (no time)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `minDate` | `string` | `''` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `firstDayOfWeek` | `number` | `0` | First day of week: `0` = Sunday, `1` = Monday |\n| `showWeekNumbers` | `boolean` | `false` | Show week numbers in the calendar |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user selects or clears a date |\n| `monthChange` | `{ year: number, month: number }` | Fired when the calendar navigates to a different month |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted as **ISO 8601 date**: `\"YYYY-MM-DD\"`\n- `null` when no value is selected\n- No time component is ever stored or emitted\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--date-input-102020\n  value=\"{{ui.form.birthDate}}\"\n  error=\"{{ui.form.birthDateError}}\"\n  locale=\"en-US\"\n  required>\n  <Label>Date of Birth</Label>\n</molecules--date-input-102020>\n```\n\n### With min/max and helper\n\n```html\n<molecules--date-input-102020\n  value=\"{{ui.form.dueDate}}\"\n  error=\"{{ui.form.dueDateError}}\"\n  locale=\"pt-BR\"\n  minDate=\"2026-01-01\"\n  maxDate=\"2026-12-31\"\n  required>\n  <Label>Due Date</Label>\n  <Helper>Select a date within the current year</Helper>\n</molecules--date-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/creation" {
    export const skill = "\n# groupEnterDateInterval \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterDateInterval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterDateInterval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start date input |\n| `LabelEnd` | No | Label for the end date input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startDate` | `string | null` | `null` | `@propertyDataSource` | Start date (`\"YYYY-MM-DD\"`) |\n| `endDate` | `string | null` | `null` | `@propertyDataSource` | End date (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `minDate` | `string` | `''` | `@propertyDataSource` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | `@propertyDataSource` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `minRangeDays` | `number` | `0` | `@propertyDataSource` | Minimum range in days (0 = no minimum) |\n| `maxRangeDays` | `number` | `0` | `@propertyDataSource` | Maximum range in days (0 = no maximum) |\n| `firstDayOfWeek` | `number` | `0` | `@propertyDataSource` | First day of week: 0=Sunday, 1=Monday |\n| `allowSameDay` | `boolean` | `true` | `@propertyDataSource` | Allow start and end on the same day |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both dates are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Calendar panel is open |\n| `selectingEnd` | `boolean` | `false` | `@state` | Currently in end-date selection phase |\n| `hoverDate` | `string | null` | `null` | `@state` | Date being hovered during range selection |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `startDate` and `endDate` are always ISO 8601 date strings: `\"YYYY-MM-DD\"`\n- **No time component** \u2014 never store or emit time information\n- `null` means the date has not been selected yet\n- `endDate` must always be \u2265 `startDate` (enforced by the component)\n\n### Display Format\n\n| Locale | Range | Displayed |\n|--------|-------|-----------|\n| `en-US` | `\"2026-04-01\"` \u2192 `\"2026-04-30\"` | `04/01/2026 \u2013 04/30/2026` |\n| `pt-BR` | `\"2026-04-01\"` \u2192 `\"2026-04-30\"` | `01/04/2026 \u2013 30/04/2026` |\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startDate` is set: display `\"startDate \u2013 \u2014\"`\n- If both are set: display full formatted range\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startDate: string | null, endDate: string | null }` | \u2713 | Both dates confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start date changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End date changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\n// Emit individual change\nthis.dispatchEvent(new CustomEvent('startChange', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.startDate }\n}));\n\n// Emit consolidated change when both are confirmed\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { startDate: this.startDate, endDate: this.endDate }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two date inputs + range calendar |\n| **View** | `false` | Renders formatted date range as static text |\n\n- In view mode: no inputs, no calendar, no events, no error, no helper\n\n---\n\n## 7. Selection Flow\n\n```\n1. User clicks/focuses the trigger\n2. Calendar opens \u2014 selectingEnd = false\n3. User clicks start date:\n   - startDate is set\n   - endDate = null\n   - selectingEnd = true\n   - emit startChange\n4. User hovers dates \u2192 range preview highlighted (startDate to hoverDate)\n5. User clicks end date:\n   - IF clicked date >= startDate: set endDate, emit endChange + change\n   - IF clicked date < startDate: swap \u2014 new startDate = clicked, endDate = old startDate\n   - selectingEnd = false\n   - close calendar\n```\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Selecting** | Start selected, range preview on hover |\n| **Complete** | Both dates set, range highlighted |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 10. Value Handling\n\n### Range Validation\n\n| Rule | Behavior |\n|------|----------|\n| `endDate < startDate` | Swap the two values |\n| `allowSameDay=false` and same day selected | Prevent selection, keep selectingEnd=true |\n| Range < `minRangeDays` | Visually grey out invalid end dates |\n| Range > `maxRangeDays` | Visually grey out dates beyond maximum |\n\n### minDate / maxDate\n\n- Disable calendar days outside the allowed bounds\n- Prevent navigation to months entirely outside the allowed range\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Calendar dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Date Range Picker** | Two inputs + dual-month calendar popup |\n| **Date Range Inline** | Always-visible dual calendar |\n| **Date Range with Presets** | Quick options (Last 7 days, This month) + custom range |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/usage" {
    export const skill = "\n# enter + date-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + date-interval** group.\n> Use this when you need the user to provide a **date range (start and end date, no time)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start date input |\n| `LabelEnd` | Label shown above the end date input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startDate` | `string | null` | `null` | Start date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `endDate` | `string | null` | `null` | End date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `minDate` | `string` | `''` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `minRangeDays` | `number` | `0` | Minimum number of days the range must span (0 = no minimum) |\n| `maxRangeDays` | `number` | `0` | Maximum number of days the range can span (0 = no maximum) |\n| `firstDayOfWeek` | `number` | `0` | First day of week: `0` = Sunday, `1` = Monday |\n| `allowSameDay` | `boolean` | `true` | Allow start and end on the same day |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both dates as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startDate: string | null, endDate: string | null }` | Fired when both dates are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start date changes |\n| `endChange` | `{ value: string | null }` | Fired when end date changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both `startDate` and `endDate` are ISO 8601 date strings: `\"YYYY-MM-DD\"`\n- `null` means not yet selected\n- No time component is ever stored or emitted\n- `endDate` is always \u2265 `startDate`\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--date-interval-102020\n  startDate=\"{{ui.form.vacationStart}}\"\n  endDate=\"{{ui.form.vacationEnd}}\"\n  error=\"{{ui.form.vacationError}}\"\n  locale=\"pt-BR\"\n  required>\n  <Label>Vacation Period</Label>\n  <LabelStart>From</LabelStart>\n  <LabelEnd>To</LabelEnd>\n</molecules--date-interval-102020>\n```\n\n### With range constraints and helper\n\n```html\n<molecules--date-interval-102020\n  startDate=\"{{ui.report.startDate}}\"\n  endDate=\"{{ui.report.endDate}}\"\n  error=\"{{ui.report.dateError}}\"\n  locale=\"en-US\"\n  minDate=\"2026-01-01\"\n  maxDate=\"2026-12-31\"\n  maxRangeDays=\"90\">\n  <Label>Report Period</Label>\n  <Helper>Maximum range is 90 days</Helper>\n</molecules--date-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/creation" {
    export const skill = "\n\n# groupEnterDateTime \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterDateTime** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterDateTime` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | ISO 8601 datetime string (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g., `'en-US'`, `'pt-BR'`) |\n| `timezone` | `string` | `''` | `@propertyDataSource` | IANA timezone. Empty = local |\n| `minDatetime` | `string` | `''` | `@propertyDataSource` | Minimum allowed datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | `@propertyDataSource` | Maximum allowed datetime (ISO 8601) |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in time picker |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Picker panel is open |\n| `isFocused` | `boolean` | `false` | `@state` | Field has focus |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- Time is always stored in **24-hour format**, regardless of display locale\n- `null` represents no value selected\n\n### Display Format\n\nDisplay is locale-aware. The molecule formats `value` for display only \u2014 never modifies the stored value.\n\n| Locale | Stored value | Displayed |\n|--------|-------------|-----------|\n| `en-US` | `\"2026-04-17T14:30:00\"` | `04/17/2026 02:30 PM` |\n| `pt-BR` | `\"2026-04-17T14:30:00\"` | `17/04/2026 14:30` |\n| `de-DE` | `\"2026-04-17T14:30:00\"` | `17.04.2026 14:30` |\n\n### Derived State\n\n`value` is bound via `@propertyDataSource`. If your implementation maintains derived state (e.g., a formatted display string), use `handleIcaStateChange` to recalculate when `value` changes externally. See `molecule-generation2.md` section 11.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | User confirmed a datetime selection |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"2026-04-17T14:30:00\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input trigger + picker panel |\n| **View** | `false` | Renders formatted datetime as static text |\n\n### View Mode Rules\n\n- Format `value` using `locale` and display as text\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n- No input, no picker, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message below input, apply error visual state |\n\n- Error is never shown in view mode (`isEditing === false`)\n- The molecule displays the error; the **Page/Organism** is responsible for setting it\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Open** | Picker panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no picker |\n\n---\n\n## 9. Value Handling\n\n### Parsing Input to Value\n\nWhen the user selects date and time in the picker:\n\n```\ndate part  \u2192 \"YYYY-MM-DD\"  (from calendar selection)\ntime part  \u2192 \"HH:mm\"       (from time columns, always 24h)\ncombined   \u2192 \"YYYY-MM-DDTHH:mm:00\"\n```\n\n### Applying minDatetime / maxDatetime\n\n- Disable calendar days entirely outside the allowed range\n- For the boundary day: disable time options that fall outside the boundary\n\n### minuteStep\n\n- Only show minutes that are multiples of `minuteStep`\n- Example: `minuteStep=15` \u2192 show 00, 15, 30, 45\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Picker dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Current value | `aria-label` on trigger with formatted datetime |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 11. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **DateTime Picker** | Input trigger + calendar + clock panel (popup) |\n| **DateTime Input** | Masked text input with format validation |\n| **DateTime Inline** | Always-visible calendar + clock, no popup |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/usage" {
    export const skill = "\n\n# enter + datetime \u2014 Usage\n\n> Quick reference for using molecules in the **enter + datetime** group.\n> Use this when you need the user to provide a **date and time together**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `timezone` | `string` | `''` | IANA timezone, e.g. `'America/Sao_Paulo'`. Empty = local |\n| `minDatetime` | `string` | `''` | Minimum selectable datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | Maximum selectable datetime (ISO 8601) |\n| `minuteStep` | `number` | `1` | Minutes increment in the time picker (e.g. 5, 15, 30) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user confirms a datetime selection |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- `null` when no value is selected\n- Time is always in **24-hour format** internally, regardless of display locale\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.form.scheduledAt}}\"\n  error=\"{{ui.form.scheduledAtError}}\"\n  locale=\"en-US\"\n  required>\n  <Label>Scheduled At</Label>\n</molecules--datetime-input-102020>\n```\n\n### With helper and minute step\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.meeting.startsAt}}\"\n  error=\"{{ui.meeting.startsAtError}}\"\n  locale=\"pt-BR\"\n  minuteStep=\"15\"\n  minDatetime=\"2026-01-01T00:00:00\"\n  required>\n  <Label>Meeting Start</Label>\n  <Helper>Select a date and time at least 15 minutes from now</Helper>\n</molecules--datetime-input-102020>\n```\n\n### View mode (read-only display)\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.order.confirmedAt}}\"\n  isEditing=\"false\"\n  locale=\"en-US\">\n  <Label>Confirmed At</Label>\n</molecules--datetime-input-102020>\n```\n\n### Disabled\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.form.lockedAt}}\"\n  disabled=\"true\"\n  locale=\"en-US\">\n  <Label>Locked At</Label>\n</molecules--datetime-input-102020>\n```\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/creation" {
    export const skill = "\n# groupEnterDateTimeInterval \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterDateTimeInterval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterDateTimeInterval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start datetime input |\n| `LabelEnd` | No | Label for the end datetime input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startDatetime` | `string | null` | `null` | `@propertyDataSource` | Start datetime (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `endDatetime` | `string | null` | `null` | `@propertyDataSource` | End datetime (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `timezone` | `string` | `''` | `@propertyDataSource` | IANA timezone. Empty = local |\n| `minDatetime` | `string` | `''` | `@propertyDataSource` | Minimum allowed datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | `@propertyDataSource` | Maximum allowed datetime (ISO 8601) |\n| `minDurationMinutes` | `number` | `0` | `@propertyDataSource` | Minimum duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | `@propertyDataSource` | Maximum duration in minutes (0 = no maximum) |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in time picker |\n| `allowSameInstant` | `boolean` | `false` | `@propertyDataSource` | Allow start and end at the same datetime |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both datetimes are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `activeField` | `string | null` | `null` | `@state` | Which picker is open: `'start'`, `'end'`, or `null` |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Both values stored as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- Time always stored in **24-hour format**\n- `null` means not yet selected\n- `endDatetime` must be > `startDatetime` (unless `allowSameInstant=true`)\n\n### Display Format\n\n| Locale | Same day range | Displayed |\n|--------|---------------|-----------|\n| `en-US` | same day | `04/17/2026 09:00 AM \u2013 10:30 AM` |\n| `en-US` | different days | `04/17/2026 09:00 AM \u2013 04/18/2026 08:00 AM` |\n| `pt-BR` | same day | `17/04/2026 09:00 \u2013 10:30` |\n\nWhen start and end are on the same day, the date can be shown once with only the times for brevity.\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startDatetime` is set: display `\"startDatetime \u2013 \u2014\"`\n- If both set: display full formatted range\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startDatetime: string | null, endDatetime: string | null }` | \u2713 | Both datetimes confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start datetime changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End datetime changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: {\n    startDatetime: this.startDatetime, // \"2026-04-17T09:00:00\"\n    endDatetime: this.endDatetime      // \"2026-04-17T10:30:00\"\n  }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two datetime inputs + pickers |\n| **View** | `false` | Renders formatted datetime range as static text |\n\n- In view mode: no inputs, no pickers, no events, no error, no helper\n\n---\n\n## 7. Selection Flow\n\n```\n1. User clicks start input \u2192 activeField = 'start'\n2. Start picker opens (calendar + time)\n3. User confirms start:\n   - startDatetime is set\n   - emit startChange\n   - IF endDatetime is null: activeField = 'end' (auto-advance)\n   - ELSE: activeField = null, close\n4. User clicks end input \u2192 activeField = 'end'\n5. End picker opens:\n   - Calendar: disable dates before startDatetime date\n   - Time: if same day, disable times \u2264 startDatetime time\n6. User confirms end:\n   - endDatetime is set\n   - emit endChange + change\n   - activeField = null, close picker\n```\n\n---\n\n## 8. Duration Validation\n\n| Rule | Behavior |\n|------|----------|\n| `endDatetime \u2264 startDatetime` | Prevent selection (unless `allowSameInstant=true`) |\n| Duration < `minDurationMinutes` | Grey out end times/dates that would be too short |\n| Duration > `maxDurationMinutes` | Grey out end times/dates that would be too long |\n\nThe molecule enforces these rules visually during selection. The Page/Organism sets the `error` message after the fact if needed.\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Active (start)** | Start picker open |\n| **Active (end)** | End picker open |\n| **Complete** | Both datetimes selected |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Picker dialogs | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **DateTime Range Picker** | Two inputs + separate calendar+time panels |\n| **Event Scheduler** | Side-by-side pickers optimized for meeting booking |\n| **Booking Widget** | Compact check-in/check-out with duration display |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/usage" {
    export const skill = "\n\n# enter + datetime-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + datetime-interval** group.\n> Use this when you need the user to provide a **date+time range (start and end datetime)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start datetime input |\n| `LabelEnd` | Label shown above the end datetime input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startDatetime` | `string | null` | `null` | Start datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `endDatetime` | `string | null` | `null` | End datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `timezone` | `string` | `''` | IANA timezone, e.g. `'America/Sao_Paulo'`. Empty = local |\n| `minDatetime` | `string` | `''` | Minimum selectable datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | Maximum selectable datetime (ISO 8601) |\n| `minDurationMinutes` | `number` | `0` | Minimum duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | Maximum duration in minutes (0 = no maximum) |\n| `minuteStep` | `number` | `1` | Minutes increment in the time picker (e.g. 15, 30) |\n| `allowSameInstant` | `boolean` | `false` | Allow start and end at the exact same datetime |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both datetimes as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startDatetime: string | null, endDatetime: string | null }` | Fired when both datetimes are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start datetime changes |\n| `endChange` | `{ value: string | null }` | Fired when end datetime changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both values are ISO 8601 datetime strings: `\"YYYY-MM-DDTHH:mm:ss\"`\n- `null` when not yet selected\n- Time is always stored in **24-hour format** internally\n- `endDatetime` is always > `startDatetime` (unless `allowSameInstant=true`)\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--datetime-interval-102020\n  startDatetime=\"{{ui.form.meetingStart}}\"\n  endDatetime=\"{{ui.form.meetingEnd}}\"\n  error=\"{{ui.form.meetingError}}\"\n  locale=\"en-US\"\n  minuteStep=\"15\"\n  required>\n  <Label>Meeting Period</Label>\n  <LabelStart>Start</LabelStart>\n  <LabelEnd>End</LabelEnd>\n</molecules--datetime-interval-102020>\n```\n\n### With duration constraints\n\n```html\n<molecules--datetime-interval-102020\n  startDatetime=\"{{ui.booking.checkIn}}\"\n  endDatetime=\"{{ui.booking.checkOut}}\"\n  error=\"{{ui.booking.periodError}}\"\n  locale=\"pt-BR\"\n  minDurationMinutes=\"60\"\n  maxDurationMinutes=\"480\">\n  <Label>Reservation</Label>\n  <LabelStart>Check-in</LabelStart>\n  <LabelEnd>Check-out</LabelEnd>\n  <Helper>Reservations between 1 and 8 hours</Helper>\n</molecules--datetime-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/creation" {
    export const skill = "\n# groupEnterMoney \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterMoney** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterMoney` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Monetary value as a plain number (e.g. `1500.50`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `currency` | `string` | `'USD'` | `@propertyDataSource` | ISO 4217 currency code (e.g. `'USD'`, `'BRL'`, `'EUR'`) |\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g. `'en-US'`, `'pt-BR'`) |\n| `decimals` | `number` | `2` | `@propertyDataSource` | Decimal places (use `0` for currencies without cents, e.g. JPY) |\n| `min` | `number | null` | `null` | `@propertyDataSource` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | `@propertyDataSource` | Maximum allowed value (null = no maximum) |\n| `showSymbol` | `boolean` | `true` | `@propertyDataSource` | Display currency symbol alongside the field |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder when value is null |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `rawValue` | `string` | `''` | `@state` | Locale-formatted string currently shown in the input (derived from `value`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **JavaScript number** representing the monetary amount\n- `null` means not yet provided\n- **Never** store currency symbols or thousand separators \u2014 those are display only\n- `decimals` defines precision (default 2 for cents-based currencies; 0 for e.g. JPY)\n\n### Parsing Rules\n\nInput typed by the user must be parsed according to the active locale:\n\n| Locale | Thousand sep | Decimal sep | Input `\"1.500,50\"` \u2192 value |\n|--------|-------------|-------------|---------------------------|\n| `pt-BR` | `.` | `,` | `1500.50` |\n| `en-US` | `,` | `.` | `1500.50` |\n| `''` | (none) | `.` | `1500.50` |\n\nParsing algorithm:\n1. Remove all characters that are not digits, the locale decimal separator, or a minus sign\n2. Replace the locale decimal separator with `.`\n3. Parse as `parseFloat`\n\n### Display Format\n\n| `locale` | `currency` | `showSymbol` | Value | Displayed |\n|----------|-----------|-------------|-------|-----------|\n| `'en-US'` | `'USD'` | `true` | `1500.50` | `$1,500.50` |\n| `'pt-BR'` | `'BRL'` | `true` | `1500.50` | `R$ 1.500,50` |\n| `'en-US'` | `'EUR'` | `false` | `1500.50` | `1,500.50` |\n\n### View Mode\n\n- If value is `null`: display `\"\u2014\"`\n- Otherwise: display value formatted with `Intl.NumberFormat` using `currency` and `locale`\n- Currency symbol position follows the locale convention\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Value confirmed on blur |\n| `input` | `{ value: number | null }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders locale-formatted text input |\n| **View** | `false` | Renders fully formatted currency string as static text |\n\n- In view mode: no input, no events, no error, no helper\n\n---\n\n## 7. Input Interaction\n\n```\nON FOCUS:\n  - Select all input content for easy replacement\n  - Emit `focus` event\n\nON INPUT (each keystroke):\n  - Store raw string in rawValue\n  - Attempt to parse: value = parseLocaleNumber(rawValue)\n  - Emit `input` event with current parsed value (may be null if unparseable)\n\nON BLUR:\n  - If rawValue is empty: set value = null\n  - Else: parse rawValue \u2192 value\n  - Clamp to min/max if applicable\n  - Reformat: rawValue = formatToRaw(value)  \u2190 normalize display\n  - Emit `change` event\n  - Emit `blur` event\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| Value < `min` | Clamp to `min` on blur |\n| Value > `max` | Clamp to `max` on blur |\n| Non-numeric input | Clear on blur, value = null |\n| `required` and `null` | Error state until a value is entered |\n| Negative value when `min >= 0` | Clamp to `min` on blur |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted, content selected |\n| **Filled** | Value present, formatted |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Fully formatted currency string, no input |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Currency context | `aria-label` includes currency code when symbol alone is ambiguous |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Currency Input** | Locale-aware text input with currency symbol |\n| **Price Field** | Compact input for product pricing, always positive |\n| **Money Input** | General purpose, supports negative values (credits/debits) |\n| **Currency Converter** | Two linked money inputs with exchange rate display |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/usage" {
    export const skill = "\n# enter + money \u2014 Usage\n\n> Quick reference for using molecules in the **enter + money** group.\n> Use this when you need the user to provide a **monetary value** with locale-aware formatting.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Monetary value as a plain number (e.g. `1500.50`). `null` = not yet provided |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `currency` | `string` | `'USD'` | ISO 4217 currency code, e.g. `'USD'`, `'BRL'`, `'EUR'` |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `decimals` | `number` | `2` | Decimal places (use `0` for currencies without cents, e.g. JPY) |\n| `min` | `number | null` | `null` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | Maximum allowed value (null = no maximum) |\n| `showSymbol` | `boolean` | `true` | Display currency symbol alongside the input |\n| `placeholder` | `string` | `''` | Placeholder when value is null |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = formatted read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when value is confirmed on blur |\n| `input` | `{ value: number | null }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value stored and emitted as a plain JavaScript **number** (e.g. `1500.50`)\n- `null` when not yet provided\n- **Never** includes currency symbols or thousand separators \u2014 those are display only\n- Display formatting respects `locale`, `currency`, and `decimals`\n\n---\n\n## Examples\n\n### Product price (USD)\n\n```html\n<molecules--currency-input-102020\n  value=\"{{ui.product.price}}\"\n  error=\"{{ui.product.priceError}}\"\n  currency=\"USD\"\n  locale=\"en-US\"\n  min=\"0\"\n  required>\n  <Label>Price</Label>\n</molecules--currency-input-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/creation" {
    export const skill = "\n# groupEnterNumber \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterNumber** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterNumber` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Prefix` | No | Content rendered before the input (e.g. unit symbol) |\n| `Suffix` | No | Content rendered after the input (e.g. unit label) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Current numeric value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `min` | `number | null` | `null` | `@propertyDataSource` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | `@propertyDataSource` | Maximum allowed value (null = no maximum) |\n| `step` | `number` | `1` | `@propertyDataSource` | Increment/decrement step for stepper and slider |\n| `decimals` | `number` | `0` | `@propertyDataSource` | Number of decimal places allowed |\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g. `'en-US'`, `'pt-BR'`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text when value is null |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `rawValue` | `string` | `''` | `@state` | Formatted string currently shown in the input (derived from `value`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **JavaScript number**\n- `null` means not yet provided\n- Decimal precision controlled by `decimals` property\n- Display format respects `locale` and `decimals`; stored value is always a plain number\n- When `decimals = 0`, only integers are accepted\n\n### Display Format\n\n| `locale` | `decimals` | Value | Displayed |\n|----------|------------|-------|-----------|\n| `'en-US'` | `0` | `1500` | `1,500` |\n| `'pt-BR'` | `2` | `1500.5` | `1.500,50` |\n| `''` | `2` | `1500.5` | `1500.50` (browser default) |\n\n### View Mode\n\n- If value is `null`: display `\"\u2014\"`\n- Otherwise: display value formatted with `locale` and `decimals`\n- Prefix/Suffix slots are rendered in view mode\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Value confirmed (on blur or stepper click) |\n| `input` | `{ value: number | null }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders numeric input (with optional stepper or slider) |\n| **View** | `false` | Renders formatted number as static text |\n\n- In view mode: no input, no stepper, no events, no error, no helper\n\n---\n\n## 7. Stepper Logic\n\nWhen the implementation uses a stepper (+/\u2212 buttons):\n\n```typescript\nprivate increment() {\n  const current = this.value ?? 0;\n  const next = current + this.step;\n  if (this.max !== null && next > this.max) return;\n  this.value = this.roundToDecimals(next);\n  this.rawValue = this.formatToDisplay(this.value);\n  this.emitChange();\n}\n\nprivate decrement() {\n  const current = this.value ?? 0;\n  const next = current - this.step;\n  if (this.min !== null && next < this.min) return;\n  this.value = this.roundToDecimals(next);\n  this.rawValue = this.formatToDisplay(this.value);\n  this.emitChange();\n}\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| Value < `min` | Clamp to `min` on blur |\n| Value > `max` | Clamp to `max` on blur |\n| Non-numeric input | Ignored on keydown; cleared on blur |\n| Decimals > `decimals` | Truncate or round on blur |\n| `required` and `null` | Error state until a value is entered |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted |\n| **Filled** | Value present |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Stepper buttons | `aria-label=\"Increment\"` / `aria-label=\"Decrement\"` |\n| Min/Max | `aria-valuemin` / `aria-valuemax` on slider implementations |\n| Current value | `aria-valuenow` on slider implementations |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Number Input** | Plain text input accepting numeric values |\n| **Stepper** | Input flanked by \u2212 and + buttons |\n| **Slider** | Horizontal range slider for bounded values |\n| **Percentage Input** | Number input locked to 0\u2013100 with `%` suffix |\n| **Quantity Selector** | Stepper with compact visual for cart-style quantities |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/usage" {
    export const skill = "\n# enter + number \u2014 Usage\n\n> Quick reference for using molecules in the **enter + number** group.\n> Use this when you need the user to provide a **numeric value**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Prefix` | Content rendered before the input (e.g. `#`, `km`) |\n| `Suffix` | Content rendered after the input (e.g. `kg`, `%`) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Current numeric value. `null` = not yet provided |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `min` | `number | null` | `null` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | Maximum allowed value (null = no maximum) |\n| `step` | `number` | `1` | Increment/decrement step for stepper and slider |\n| `decimals` | `number` | `0` | Number of decimal places |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `placeholder` | `string` | `''` | Placeholder text when value is null |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when value is confirmed (blur or stepper click) |\n| `input` | `{ value: number | null }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value stored and emitted as a plain JavaScript **number**\n- `null` when not yet provided\n- Display respects `locale` and `decimals`; stored value is always a raw number\n\n---\n\n## Examples\n\n### Basic quantity\n\n```html\n<molecules--number-stepper-102020\n  value=\"{{ui.order.quantity}}\"\n  error=\"{{ui.order.quantityError}}\"\n  min=\"1\"\n  max=\"99\"\n  step=\"1\"\n  required>\n  <Label>Quantity</Label>\n</molecules--number-stepper-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterText/creation" {
    export const skill = "\n# groupEnterText \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterText** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterText` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Prefix` | No | Content rendered before the input (e.g. icon, static text) |\n| `Suffix` | No | Content rendered after the input (e.g. icon, action button) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string` | `''` | `@propertyDataSource` | Current text value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text when value is empty |\n| `maxLength` | `number | null` | `null` | `@propertyDataSource` | Maximum number of characters (null = no limit) |\n| `minLength` | `number | null` | `null` | `@propertyDataSource` | Minimum number of characters (null = no minimum) |\n| `rows` | `number` | `1` | `@propertyDataSource` | Number of visible rows (>1 renders a textarea) |\n| `autocomplete` | `string` | `''` | `@propertyDataSource` | HTML autocomplete attribute value (e.g. `'email'`, `'name'`, `'off'`) |\n| `inputType` | `string` | `'text'` | `@propertyDataSource` | HTML input type: `'text'`, `'email'`, `'password'`, `'search'`, `'url'`, `'tel'` |\n| `mask` | `string` | `''` | `@propertyDataSource` | Input mask pattern (e.g. `'(##) #####-####'` for phone). `#` = digit, `A` = letter, `*` = any |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a plain **string**\n- Empty string `''` means no value entered\n- When `mask` is set, `value` always stores the **raw unmasked string** \u2014 the mask is display only\n- When `inputType='password'`, value is never displayed back to the user\n\n### View Mode\n\n- If value is `''`: display `\"\u2014\"`\n- If `inputType='password'`: display `\"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\"` regardless of value length\n- Otherwise: display value as plain text\n- Prefix/Suffix slots are rendered in view mode\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string }` | \u2713 | Value confirmed on blur |\n| `input` | `{ value: string }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input or textarea |\n| **View** | `false` | Renders value as static text |\n\n- In view mode: no input, no events, no error, no helper\n\n---\n\n## 7. Input vs Textarea\n\n| Condition | Element rendered |\n|-----------|-----------------|\n| `rows = 1` | `<input>` |\n| `rows > 1` | `<textarea>` |\n\n- `<textarea>` does not support `inputType` or `mask`\n- When `rows > 1` and `maxLength` is set: display a character counter below the field (e.g. `42 / 200`)\n\n---\n\n## 8. Mask Logic\n\nWhen `mask` is set:\n\n- Apply mask on every `@input` event before updating `value`\n- `value` stores only the raw digits/letters extracted from the masked string\n- Display shows the formatted mask string in `rawDisplay`\n- Mask characters: `#` = digit only, `A` = letter only, `*` = any character\n- Literal characters in the mask (e.g. `(`, `)`, `-`, space) are inserted automatically\n\n```\nExample: mask=\"(##) #####-####\"\nUser types: \"11987654321\"\nrawDisplay:  \"(11) 98765-4321\"\nvalue:       \"11987654321\"\n```\n\n---\n\n## 9. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `value.length < minLength` | Error state; Page sets the error message |\n| `value.length > maxLength` | Block input beyond the limit |\n| `required` and `value === ''` | Error state until text is entered |\n| `inputType='email'` | Page is responsible for format validation |\n\n---\n\n## 10. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 11. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted |\n| **Filled** | Value present |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Plain text only |\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Password | Never `aria-label` the actual value |\n| Character counter | `aria-live=\"polite\"` so screen readers announce remaining characters |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Text Input** | Single-line plain text field |\n| **Textarea** | Multi-line text field with optional character counter |\n| **Password Input** | Single-line input with show/hide toggle |\n| **Masked Input** | Input with automatic formatting (phone, CPF, ZIP) |\n| **Search Input** | Input with search icon and clear button |\n| **Tag Input** | Input that converts entries into removable tags |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterText/usage" {
    export const skill = "\n\n# enter + text \u2014 Usage\n\n> Quick reference for using molecules in the **enter + text** group.\n> Use this when you need the user to provide **free-form text**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Prefix` | Content rendered before the input (e.g. icon, static text) |\n| `Suffix` | Content rendered after the input (e.g. icon, action button) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string` | `''` | Current text value |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Placeholder text when value is empty |\n| `maxLength` | `number | null` | `null` | Maximum number of characters (null = no limit) |\n| `minLength` | `number | null` | `null` | Minimum number of characters (null = no minimum) |\n| `rows` | `number` | `1` | Number of visible rows. `1` = input, `>1` = textarea |\n| `autocomplete` | `string` | `''` | HTML autocomplete value (e.g. `'email'`, `'name'`, `'off'`) |\n| `inputType` | `string` | `'text'` | Input type: `'text'`, `'email'`, `'password'`, `'search'`, `'url'`, `'tel'` |\n| `mask` | `string` | `''` | Mask pattern. `#` = digit, `A` = letter, `*` = any. Literals inserted automatically |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string }` | Fired when value is confirmed on blur |\n| `input` | `{ value: string }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is always a plain **string**\n- Empty string `''` when not yet provided\n- When `mask` is set, `value` contains the **raw unmasked string** \u2014 the formatted display is handled internally\n- When `inputType='password'`, view mode renders `\"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\"` regardless of value\n\n---\n\n## Examples\n\n### Simple text field\n\n```html\n<molecules--text-input-102020\n  value=\"{{ui.form.firstName}}\"\n  error=\"{{ui.form.firstNameError}}\"\n  placeholder=\"John\"\n  maxLength=\"200\"\n  required>\n  <Label>First Name</Label>\n</molecules--text-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/creation" {
    export const skill = "\n# groupEnterTime \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterTime** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterTime` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Time string in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `hour12` | `boolean` | `false` | `@propertyDataSource` | Display in 12-hour format (AM/PM) |\n| `showSeconds` | `boolean` | `false` | `@propertyDataSource` | Include seconds in input and stored value |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in picker |\n| `minTime` | `string` | `''` | `@propertyDataSource` | Minimum allowed time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | `@propertyDataSource` | Maximum allowed time (`\"HH:mm\"`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Time picker panel is open |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored in **24-hour format**: `\"HH:mm\"`\n- When `showSeconds=true`: `\"HH:mm:ss\"`\n- **No date component** \u2014 never store or emit date information\n- `null` represents no value selected\n\n### Display Format\n\nDisplay respects `hour12` and `locale`. The stored value is never modified.\n\n| `hour12` | Stored | Displayed |\n|----------|--------|-----------|\n| `false` | `\"14:30\"` | `14:30` |\n| `true` | `\"14:30\"` | `02:30 PM` |\n| `false` | `\"08:05:30\"` | `08:05:30` |\n| `true` | `\"08:05:30\"` | `08:05:30 AM` |\n\n### View Mode\n\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Time confirmed or cleared |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"14:30\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders time input + picker panel |\n| **View** | `false` | Renders formatted time as static text |\n\n- In view mode: no input, no picker, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Open** | Time picker panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no picker |\n\n---\n\n## 9. Value Handling\n\n### minuteStep\n\n- Only render minutes that are multiples of `minuteStep`\n- Example: `minuteStep=15` \u2192 show 00, 15, 30, 45\n\n### minTime / maxTime\n\n- Disable hours/minutes outside the allowed range\n- For boundary hours: disable only the out-of-range minutes\n\n### showSeconds\n\n- When `false`: store `\"HH:mm\"`, hide seconds column\n- When `true`: store `\"HH:mm:ss\"`, show seconds column (always step 1)\n\n### hour12\n\n- Display only \u2014 never affects stored format\n- Internally always convert to/from 24h\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Picker dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Current value | `aria-label` on trigger with formatted time |\n\n---\n\n## 11. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Time Picker** | Input + scrollable columns panel |\n| **Time Input** | Masked text input `HH:mm` |\n| **Time Spinner** | Up/down arrows per segment |\n| **Clock Face** | Analog clock for hour + minute selection |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/usage" {
    export const skill = "\n\n# enter + time \u2014 Usage\n\n> Quick reference for using molecules in the **enter + time** group.\n> Use this when you need the user to provide a **time only (no date)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `hour12` | `boolean` | `false` | Display in 12-hour format with AM/PM |\n| `showSeconds` | `boolean` | `false` | Include seconds in the input |\n| `minuteStep` | `number` | `1` | Minutes increment in picker (e.g. 5, 15, 30) |\n| `minTime` | `string` | `''` | Minimum selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | Maximum selectable time (`\"HH:mm\"`) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user confirms a time selection |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted in **24-hour format**: `\"HH:mm\"` or `\"HH:mm:ss\"` when `showSeconds=true`\n- `null` when no value is selected\n- Display format respects `hour12` and `locale`, but stored value is always 24h\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--time-input-102020\n  value=\"{{ui.form.openingTime}}\"\n  error=\"{{ui.form.openingTimeError}}\"\n  required>\n  <Label>Opening Time</Label>\n</molecules--time-input-102020>\n```\n\n### With 15-minute step and AM/PM display\n\n```html\n<molecules--time-input-102020\n  value=\"{{ui.schedule.alarmTime}}\"\n  error=\"{{ui.schedule.alarmTimeError}}\"\n  locale=\"en-US\"\n  hour12=\"true\"\n  minuteStep=\"15\"\n  minTime=\"06:00\"\n  maxTime=\"22:00\">\n  <Label>Alarm Time</Label>\n  <Helper>Choose a time between 6:00 AM and 10:00 PM</Helper>\n</molecules--time-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/creation" {
    export const skill = "\n# groupEnterTimeInterval \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupEnterTimeInterval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupEnterTimeInterval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start time input |\n| `LabelEnd` | No | Label for the end time input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startTime` | `string | null` | `null` | `@propertyDataSource` | Start time in 24h: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `endTime` | `string | null` | `null` | `@propertyDataSource` | End time in 24h: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `hour12` | `boolean` | `false` | `@propertyDataSource` | Display in 12-hour format (AM/PM) |\n| `showSeconds` | `boolean` | `false` | `@propertyDataSource` | Include seconds in input and stored value |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in picker |\n| `minTime` | `string` | `''` | `@propertyDataSource` | Earliest selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | `@propertyDataSource` | Latest selectable time (`\"HH:mm\"`) |\n| `minDurationMinutes` | `number` | `0` | `@propertyDataSource` | Minimum interval duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | `@propertyDataSource` | Maximum interval duration in minutes (0 = no maximum) |\n| `allowOvernight` | `boolean` | `false` | `@propertyDataSource` | Allow end time before start time (crosses midnight) |\n| `allowSameTime` | `boolean` | `false` | `@propertyDataSource` | Allow start and end at same time |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both times are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `activeField` | `string | null` | `null` | `@state` | Which picker is open: `'start'`, `'end'`, or `null` |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Both values stored in **24-hour format**: `\"HH:mm\"`\n- When `showSeconds=true`: `\"HH:mm:ss\"`\n- **No date component** \u2014 never store or emit date information\n- `null` means not yet selected\n\n### Overnight Interval\n\n- When `allowOvernight=true` and `endTime < startTime`, the interval is valid and crosses midnight\n- Duration calculation: `(24 * 60) - toMinutes(startTime) + toMinutes(endTime)`\n- Display: append `(+1)` or `(next day)` indicator to end time\n\n### Display Format\n\n| `hour12` | Range | Displayed |\n|----------|-------|-----------|\n| `false` | `\"08:00\"` \u2192 `\"17:30\"` | `08:00 \u2013 17:30` |\n| `true` | `\"08:00\"` \u2192 `\"17:30\"` | `08:00 AM \u2013 05:30 PM` |\n| `false` (overnight) | `\"22:00\"` \u2192 `\"06:00\"` | `22:00 \u2013 06:00 (+1)` |\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startTime` is set: display `\"startTime \u2013 \u2014\"`\n- If both set: display full formatted range with overnight indicator if applicable\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startTime: string | null, endTime: string | null }` | \u2713 | Both times confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start time changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End time changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: {\n    startTime: this.startTime, // \"08:00\"\n    endTime: this.endTime      // \"17:30\"\n  }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two time inputs + pickers |\n| **View** | `false` | Renders formatted time range as static text |\n\n- In view mode: no inputs, no pickers, no events, no error, no helper\n\n---\n\n## 7. Duration Calculation\n\n```typescript\n// Standard (no overnight)\nfunction calcDurationMinutes(startTime: string, endTime: string): number {\n  return toMinutes(endTime) - toMinutes(startTime);\n}\n\n// Overnight\nfunction calcDurationMinutesOvernight(startTime: string, endTime: string): number {\n  return (24 * 60) - toMinutes(startTime) + toMinutes(endTime);\n}\n\nfunction toMinutes(time: string): number {\n  const [h, m] = time.split(':').map(Number);\n  return h * 60 + m;\n}\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `endTime \u2264 startTime` (no overnight) | Prevent selection or show error |\n| `allowOvernight=true` and `endTime < startTime` | Valid \u2014 treat as overnight interval |\n| Duration < `minDurationMinutes` | Grey out invalid end times |\n| Duration > `maxDurationMinutes` | Grey out end times beyond maximum |\n| Outside `minTime` / `maxTime` | Disable times in picker |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Active (start)** | Start time picker open |\n| **Active (end)** | End time picker open |\n| **Complete** | Both times selected |\n| **Overnight** | End time indicator shows `(+1)` |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Picker dialogs | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Overnight indicator | `aria-label` describing the next-day context |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Time Range Picker** | Two inputs + scrollable column panels |\n| **Time Range Slider** | Dual-handle slider on a 24h timeline |\n| **Business Hours** | Compact start+end per weekday row |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/usage" {
    export const skill = "\n\n# enter + time-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + time-interval** group.\n> Use this when you need the user to provide a **time range (start and end time, no date)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start time input |\n| `LabelEnd` | Label shown above the end time input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startTime` | `string | null` | `null` | Start time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `endTime` | `string | null` | `null` | End time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `hour12` | `boolean` | `false` | Display in 12-hour format with AM/PM |\n| `showSeconds` | `boolean` | `false` | Include seconds in the input |\n| `minuteStep` | `number` | `1` | Minutes increment in the picker (e.g. 5, 15, 30) |\n| `minTime` | `string` | `''` | Earliest selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | Latest selectable time (`\"HH:mm\"`) |\n| `minDurationMinutes` | `number` | `0` | Minimum interval duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | Maximum interval duration in minutes (0 = no maximum) |\n| `allowOvernight` | `boolean` | `false` | Allow end time before start time (crosses midnight) |\n| `allowSameTime` | `boolean` | `false` | Allow start and end at the same time |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both times as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startTime: string | null, endTime: string | null }` | Fired when both times are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start time changes |\n| `endChange` | `{ value: string | null }` | Fired when end time changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both values stored and emitted in **24-hour format**: `\"HH:mm\"` or `\"HH:mm:ss\"` when `showSeconds=true`\n- `null` when not yet selected\n- Display format respects `hour12` and `locale`, stored value is always 24h\n- When `allowOvernight=true` and `endTime < startTime`, the interval crosses midnight\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--time-interval-102020\n  startTime=\"{{ui.form.shiftStart}}\"\n  endTime=\"{{ui.form.shiftEnd}}\"\n  error=\"{{ui.form.shiftError}}\"\n  minuteStep=\"30\"\n  required>\n  <Label>Work Shift</Label>\n  <LabelStart>From</LabelStart>\n  <LabelEnd>To</LabelEnd>\n</molecules--time-interval-102020>\n```\n\n### With overnight support and AM/PM display\n\n```html\n<molecules--time-interval-102020\n  startTime=\"{{ui.config.openTime}}\"\n  endTime=\"{{ui.config.closeTime}}\"\n  error=\"{{ui.config.hoursError}}\"\n  locale=\"en-US\"\n  hour12=\"true\"\n  minuteStep=\"15\"\n  allowOvernight=\"true\"\n  minDurationMinutes=\"60\">\n  <Label>Business Hours</Label>\n  <LabelStart>Opens</LabelStart>\n  <LabelEnd>Closes</LabelEnd>\n  <Helper>Minimum 1 hour. Overnight hours allowed</Helper>\n</molecules--time-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupExpandContent/creation" {
    export const skill = "\n\n# groupExpandContent \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupExpandContent** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupExpandContent` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Title displayed above the component |\n| `Section` | Yes | One expandable section. Attributes: `title` (required), `disabled`, `expanded` |\n\n```typescript\nslotTags = ['Label', 'Section'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u2514\u2500\u2500 <Section title=\"...\" expanded disabled>\n      ...content...\n    </Section>\n```\n\n### Section Attributes\n\n| Attribute | Type | Description |\n|-----------|------|-------------|\n| `title` | `string` | Header text displayed in the trigger area |\n| `expanded` | `boolean` (presence) | Section starts expanded |\n| `disabled` | `boolean` (presence) | Section cannot be toggled |\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `multiple` | `boolean` | `true` | `@propertyDataSource` | Allow multiple sections open simultaneously. `false` = only one at a time (accordion) |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all sections |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show loading placeholder |\n\n### 3.3 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `openSections` | `Set<number>` | from `expanded` attrs | `@state` | Indices of currently open sections |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a layout/interaction component. Open/closed state is managed internally.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `toggle` | `{ index: number, title: string, expanded: boolean }` | \u2713 | Fired when a section is expanded or collapsed |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('toggle', {\n  bubbles: true,\n  composed: true,\n  detail: { index: 0, title: 'FAQ 1', expanded: true }\n}));\n```\n\n---\n\n## 6. Reading Sections\n\nRead sections inline using `getSlots`:\n\n```typescript\nconst sections = this.getSlots('Section').map((el, index) => ({\n  index,\n  title: el.getAttribute('title') || '',\n  disabled: el.hasAttribute('disabled'),\n  expanded: this.openSections.has(index),\n}));\n```\n\nInitialize `openSections` from `expanded` attributes in `firstUpdated`:\n\n```typescript\nfirstUpdated() {\n  this.getSlots('Section').forEach((el, index) => {\n    if (el.hasAttribute('expanded')) {\n      this.openSections.add(index);\n    }\n  });\n  this.requestUpdate();\n}\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Collapsed** | Only section header visible |\n| **Expanded** | Header + content visible, with expand animation |\n| **Disabled (section)** | Individual section dimmed, cannot toggle |\n| **Disabled (component)** | All sections dimmed, no interaction |\n| **Loading** | Placeholder instead of sections |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Section header | `role=\"button\"`, `tabindex=\"0\"`, `aria-expanded` |\n| Section content | `role=\"region\"`, `aria-labelledby` pointing to header |\n| Disabled | `aria-disabled=\"true\"` on header |\n| Keyboard | `Enter`/`Space` toggles section; `ArrowDown`/`ArrowUp` navigate between headers |\n\n---\n\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupExpandContent/usage" {
    export const skill = "\n# expand + content \u2014 Usage\n\n> Quick reference for using molecules in the **expand + content** group.\n> Use this when the user needs to **expand or collapse content** to see more or less details.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Title displayed above the component |\n| `Section` | One expandable section. Attributes: `title` (required), `disabled` (presence), `expanded` (presence). Content = the collapsible body |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `multiple` | `boolean` | `true` | Allow multiple sections open at once. `false` = only one (accordion mode) |\n| `disabled` | `boolean` | `false` | Disables all sections |\n| `loading` | `boolean` | `false` | Shows a loading placeholder |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `toggle` | `{ index: number, title: string, expanded: boolean }` | Fired when a section is expanded or collapsed |\n\n---\n\n## Examples\n\n### FAQ accordion (one at a time)\n\n```html\n<molecules--accordion-102020\n  multiple=\"false\">\n  <Label>Frequently Asked Questions</Label>\n  <Section title=\"How do I reset my password?\">\n    Go to Settings > Security > Reset Password and follow the instructions.\n  </Section>\n  <Section title=\"Can I change my plan?\">\n    Yes, you can upgrade or downgrade at any time from the Billing page.\n  </Section>\n  <Section title=\"How do I contact support?\">\n    Use the chat widget or email support@example.com.\n  </Section>\n</molecules--accordion-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/creation" {
    export const skill = "\n\n# groupLocatePosition \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupLocatePosition** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupLocatePosition` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the geolocation button |\n| `Suggestions` | No | Container for address suggestion items, populated by the page |\n| `Item` | No | One suggestion inside `<Suggestions>`. Attribute: `value` = `\"lat,lng\"`. Content = address label |\n| `Empty` | No | Content shown when no location is selected or no suggestions available |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Suggestions', 'Item', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Suggestions>\n\u2502   \u2514\u2500\u2500 <Item value=\"lat,lng\">\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Selected coordinates as `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`) or `null` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text for the search input |\n| `showMap` | `boolean` | `false` | `@propertyDataSource` | Show an embedded map preview of the selected location |\n| `allowGeolocation` | `boolean` | `false` | `@propertyDataSource` | Show a button to use the browser's geolocation API |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A location is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (e.g. fetching suggestions or resolving geolocation) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `searchQuery` | `string` | `''` | `@state` | Current text in the search input |\n| `isOpen` | `boolean` | `false` | `@state` | Whether the suggestions panel is open |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is a plain **string** in the format `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`)\n- `null` means no location selected\n- Parsing:\n\n```typescript\nprivate parseValue(): { lat: number; lng: number } | null {\n  if (!this.value) return null;\n  const [lat, lng] = this.value.split(',').map(Number);\n  return isNaN(lat) || isNaN(lng) ? null : { lat, lng };\n}\n```\n\n### Suggestions via Slot Tags\n\nSuggestions are provided by the page as `<Item>` elements inside `<Suggestions>`:\n\n```html\n<Suggestions>\n  <Item value=\"-23.55,-46.63\">S\u00E3o Paulo, SP - Brazil</Item>\n  <Item value=\"-22.90,-43.17\">Rio de Janeiro, RJ - Brazil</Item>\n</Suggestions>\n```\n\nRead suggestions inline using `getSlots`:\n\n```typescript\nconst suggestionsContainer = this.getSlot('Suggestions');\nconst items = suggestionsContainer\n  ? Array.from(suggestionsContainer.querySelectorAll('Item')).map(el => ({\n      value: el.getAttribute('value') || '',\n      label: el.innerHTML,\n    }))\n  : [];\n```\n\nThe page updates `<Suggestions>` content in response to the `search` event.\n\n### View Mode\n\n- If `value` is `null`: render Empty slot content or `\"\u2014\"`\n- Otherwise: find the matching `<Item>` label for the current value, or display the raw coordinates\n- If `showMap=true`: render map preview with pin at the parsed lat/lng\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Location confirmed \u2014 value is `\"lat,lng\"` or null |\n| `search` | `{ query: string }` | \u2713 | User typed in search input \u2014 page should update `<Suggestions>` items |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Search Flow\n\n```\nUser types in search input\n  \u2192 emit `search` with { query }\n  \u2192 Page calls BFF, updates <Suggestions> slot with <Item> elements\n  \u2192 Component re-renders suggestion list\n  \u2192 User selects a suggestion\n  \u2192 Component sets value = item.value (\"lat,lng\"), emits `change`\n  \u2192 isOpen = false, searchQuery = selected item label\n```\n\n### Geolocation Flow\n\n```\nUser clicks geolocation button\n  \u2192 browser navigator.geolocation.getCurrentPosition()\n  \u2192 on success: set value = \"lat,lng\", emit `change`\n  \u2192 emit `search` with { query: \"lat,lng\" } so page can resolve address\n  \u2192 page updates <Suggestions> with resolved address\n```\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n\nthis.dispatchEvent(new CustomEvent('search', {\n  bubbles: true,\n  composed: true,\n  detail: { query: this.searchQuery }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders search input, suggestions panel, optional map |\n| **View** | `false` | Renders address as static text, optional map |\n\n- In view mode: no input, no suggestions, no search events, no error, no helper\n\n---\n\n## 7. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until a location is selected |\n| No `<Item>` inside `<Suggestions>` | Render Empty slot or default \"No results\" message |\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Search input border highlighted |\n| **Open** | Suggestions panel visible |\n| **Selected** | Address displayed in input, map pin updated |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator; suggestions panel disabled |\n| **View Mode** | Address as plain text, optional map |\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Search input | `role=\"combobox\"`, `aria-expanded`, `aria-autocomplete=\"list\"` |\n| Suggestions panel | `role=\"listbox\"` |\n| Suggestion items | `role=\"option\"`, `aria-selected` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Geolocation button | `aria-label=\"Use current location\"` |\n\n---\n\n## 11. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Suggestions via Slot Tags; value simplified to \"lat,lng\" string |\n";
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/usage" {
    export const skill = "\n\n# locate + position \u2014 Usage\n\n> Quick reference for using molecules in the **locate + position** group.\n> Use this when you need the user to **inform or visualize a geographic location**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom label for the geolocation button |\n| `Suggestions` | Container for suggestion items, populated by the page |\n| `Item` | One suggestion inside `<Suggestions>`. Attribute: `value` = `\"lat,lng\"`. Content = address label |\n| `Empty` | Content shown when no location is selected or no suggestions found |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Coordinates as `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`) or `null` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Placeholder text for the search input |\n| `show-map` | `boolean` | `false` | Show an embedded map preview of the selected location |\n| `allow-geolocation` | `boolean` | `false` | Show a button to capture the user's current position |\n| `is-editing` | `boolean` | `true` | `true` = interactive input, `false` = read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a location as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator (e.g. while fetching suggestions) |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when a location is selected. Value is `\"lat,lng\"` or null |\n| `search` | `{ query: string }` | Fired when the user types. Page must update `<Suggestions>` items in response |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- `value` is a plain **string** in `\"lat,lng\"` format (e.g. `\"-23.55,-46.63\"`)\n- `null` when nothing is selected\n- Suggestions are provided via `<Item>` elements inside the `<Suggestions>` slot tag\n\n---\n\n## Search Flow\n\nThe molecule does **not** call any API directly. The page is responsible for fetching suggestions:\n\n```\n1. User types \u2192 molecule emits `search` with { query }\n2. Page calls BFF, receives address list\n3. Page updates <Suggestions> slot with <Item> elements\n4. Molecule renders the suggestion list\n5. User selects \u2192 molecule sets value = item.value, emits `change`\n```\n\n---\n\n## Examples\n\n### Address autocomplete\n\n```html\n<molecules--address-autocomplete-102020\n  value=\"{{ui.order.deliveryCoords}}\"\n  error=\"{{ui.order.addressError}}\"\n  placeholder=\"Search address...\"\n  required>\n  <Label>Delivery Address</Label>\n  <Suggestions>\n    <Item value=\"-23.55,-46.63\">S\u00E3o Paulo, SP</Item>\n    <Item value=\"-22.90,-43.17\">Rio de Janeiro, RJ</Item>\n  </Suggestions>\n</molecules--address-autocomplete-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupNavigateSection/creation" {
    export const skill = "\n# groupNavigateSection \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupNavigateSection** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupNavigateSection` |\n| **Category** | Navigation |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Title displayed above the navigation |\n| `Tab` | Yes | Defines one section. Attributes: `value` (required), `title` (required), `disabled`, `icon`. Content = the section body |\n\n```typescript\nslotTags = ['Label', 'Tab'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u2514\u2500\u2500 <Tab value=\"...\" title=\"...\" icon=\"...\" disabled>\n      ...section content (text, HTML, web components)...\n    </Tab>\n```\n\n### Tab Attributes\n\n| Attribute | Type | Description |\n|-----------|------|-------------|\n| `value` | `string` | Unique identifier for the section |\n| `title` | `string` | Display text for the tab |\n| `icon` | `string` (optional) | Icon content (emoji, text) displayed alongside the title |\n| `disabled` | `boolean` (presence) | Tab cannot be selected |\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Value of the currently active tab. `null` = first tab is active |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all navigation |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show loading state |\n\n---\n\n## 4. Value Contract\n\n- `value` is a **string** matching the `value` attribute of the active `<Tab>`\n- `null` means no explicit selection \u2014 default to the first non-disabled tab\n- When the user clicks a tab, `value` is updated and `change` is emitted\n- The component renders only the content of the active tab \u2014 other tabs' content is hidden\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string, title: string }` | \u2713 | Fired when the active tab changes |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value, title: 'Settings' }\n}));\n```\n\n---\n\n## 6. Reading Tabs\n\nRead tabs inline using `getSlots`:\n\n```typescript\nconst tabs = this.getSlots('Tab').map(el => ({\n  value: el.getAttribute('value') || '',\n  title: el.getAttribute('title') || '',\n  icon: el.getAttribute('icon') || '',\n  disabled: el.hasAttribute('disabled'),\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Active** | Selected tab highlighted |\n| **Inactive** | Default/unselected appearance |\n| **Disabled (tab)** | Individual tab dimmed, not clickable |\n| **Disabled (component)** | All tabs dimmed, no interaction |\n| **Loading** | Loading placeholder |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"tablist\"` |\n| Tab | `role=\"tab\"`, `aria-selected`, `aria-disabled`, `aria-controls` pointing to panel |\n| Content panel | `role=\"tabpanel\"`, `aria-labelledby` pointing to active tab |\n| Label | `aria-label` from Label slot |\n| Keyboard | `ArrowLeft`/`ArrowRight` navigate tabs; `Enter`/`Space` selects |\n\n---\n\n## 9. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Tabs** | Horizontal tab bar with underline indicator |\n| **Pills / Segmented Control** | Compact inline button group |\n| **Navigation Menu** | Vertical or horizontal nav links |\n| **Bottom Navigation** | Mobile bottom bar with icons and labels |\n| **Pagination** | Numbered page navigation |\n\nAll implementations share the same slot tag contract.\n\n---\n\n## 10. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Tab content rendered by component; section body inside Tab slot |\n";
}
declare module "_102020_/l2/skills/molecules/groupNavigateSection/usage" {
    export const skill = "\n# groupNavigateSection \u2014 Usage\n\n> Quick reference for using molecules in the **groupNavigateSection** group.\n> Use this when the user needs to **switch between sections** within the same context.\n> The component renders both the tab indicators and the active section's content.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Title displayed above the navigation |\n| `Tab` | One section. Attributes: `value` (required, unique identifier), `title` (required), `icon` (optional), `disabled` (presence). Content = the section body (text, HTML, web components) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Value of the active tab. `null` = first non-disabled tab |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `disabled` | `boolean` | `false` | Disables all navigation |\n| `loading` | `boolean` | `false` | Shows loading state |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string, title: string }` | Fired when the active tab changes |\n\n---\n\n## Value Format\n\n- `value` is a **string** matching a `<Tab>` value attribute\n- `null` defaults to first non-disabled tab\n- The component renders only the content of the active tab\n\n---\n\n## Examples\n\n### Product detail tabs\n\n```html\n<molecules--tabs-102020\n  value=\"{{ui.product.activeTab}}\">\n  <Tab value=\"overview\" title=\"Overview\">\n    <p>Full product description and images here...</p>\n  </Tab>\n  <Tab value=\"specs\" title=\"Specifications\">\n    <molecules--data-table-102020>\n      ...specs table...\n    </molecules--data-table-102020>\n  </Tab>\n  <Tab value=\"reviews\" title=\"Reviews\">\n    <p>Customer reviews list here...</p>\n  </Tab>\n  <Tab value=\"support\" title=\"Support\" disabled></Tab>\n</molecules--tabs-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupNavigateSteps/creation" {
    export const skill = "\n# groupNavigateSteps \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupNavigateSteps** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupNavigateSteps` |\n| **Category** | Navigation |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Title displayed above the stepper |\n| `Step` | Yes | Defines one step in the process. Attributes: `title` (required), `description`, `disabled`, `completed` |\n\n```typescript\nslotTags = ['Label', 'Step'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u2514\u2500\u2500 <Step title=\"...\" description=\"...\" completed disabled>\n```\n\n### Step Attributes\n\n| Attribute | Type | Description |\n|-----------|------|-------------|\n| `title` | `string` | Step name displayed in the indicator |\n| `description` | `string` (optional) | Short description below the title |\n| `completed` | `boolean` (presence) | Step is marked as completed |\n| `disabled` | `boolean` (presence) | Step cannot be navigated to |\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number` | `0` | `@propertyDataSource` | Index of the current active step (0-based) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `linear` | `boolean` | `true` | `@propertyDataSource` | Must complete steps in order. `false` = can jump to any non-disabled step |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all navigation |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show loading state |\n\n---\n\n## 4. Value Contract\n\n- `value` is a **number** representing the index (0-based) of the current active step\n- Default is `0` (first step)\n- When the user navigates, `value` is updated and `change` is emitted\n- The page reads `value` to know which step content to display\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number, title: string }` | \u2713 | Fired when the active step changes |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value, title: 'Payment' }\n}));\n```\n\n---\n\n## 6. Navigation Rules\n\n### Linear Mode (`linear=true`)\n- User can only go to the next step if the current step has `completed`\n- User can always go back to previous completed steps\n- Steps ahead of the current that are not completed are not clickable\n\n### Free Mode (`linear=false`)\n- User can click any step that is not `disabled`\n- `completed` is visual only \u2014 does not gate navigation\n\n### General\n- Clicking a step: update `value`, emit `change`\n- `disabled` steps are never clickable regardless of mode\n- Component-level `disabled` blocks all navigation\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Pending** | Step not yet reached \u2014 default/inactive style |\n| **Active** | Current step \u2014 highlighted |\n| **Completed** | Step done \u2014 checkmark or completed style |\n| **Disabled** | Step dimmed, not clickable |\n| **Loading** | Loading indicator on the component |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"tablist\"`, `aria-label` from Label slot |\n| Step indicator | `role=\"tab\"`, `aria-selected` for active step |\n| Completed | `aria-label` includes \"completed\" |\n| Disabled | `aria-disabled=\"true\"` |\n| Keyboard | `ArrowLeft`/`ArrowRight` navigate between steps; `Enter` selects |\n\n---\n\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupNavigateSteps/usage" {
    export const skill = "\n# navigate + steps \u2014 Usage\n\n> Quick reference for using molecules in the **navigate + steps** group.\n> Use this when the user needs to **advance through a sequential multi-step process**.\n> The component renders the step indicators; the page is responsible for displaying each step's content.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Title displayed above the stepper |\n| `Step` | One step in the process. Attributes: `title` (required), `description` (optional), `completed` (presence), `disabled` (presence) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number` | `0` | Index of the current active step (0-based) |\n| `linear` | `boolean` | `true` | Steps must be completed in order. `false` = can jump freely |\n| `disabled` | `boolean` | `false` | Disables all navigation |\n| `loading` | `boolean` | `false` | Shows loading state |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number, title: string }` | Fired when the active step changes |\n\n---\n\n## Value Format\n\n- `value` is a **number** (0-based index) of the current step\n- The page reads `value` to decide which content to show\n- Navigation updates `value` and emits `change`\n\n---\n\n## Examples\n\n### Checkout process (linear)\n\n```html\n<molecules--stepper-102020\n  value=\"{{ui.checkout.currentStep}}\"\n  linear=\"true\">\n  <Label>Checkout</Label>\n  <Step title=\"Cart\" completed></Step>\n  <Step title=\"Shipping\" completed></Step>\n  <Step title=\"Payment\"></Step>\n  <Step title=\"Confirmation\"></Step>\n</molecules--stepper-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupNotifyUser/creation" {
    export const skill = "\n# groupNotifyUser \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupNotifyUser** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupNotifyUser` |\n| **Category** | Feedback |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Title` | No | Notification title/heading |\n| `Message` | Yes | Notification body content |\n| `Action` | No | Actionable element (button, link) inside the notification |\n| `Icon` | No | Custom icon content |\n\n```typescript\nslotTags = ['Title', 'Message', 'Action', 'Icon'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Icon>\n\u251C\u2500\u2500 <Title>\n\u251C\u2500\u2500 <Message>\n\u2514\u2500\u2500 <Action>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `type` | `string` | `'info'` | `@propertyDataSource` | Notification type: `'info'`, `'success'`, `'warning'`, `'error'` |\n| `visible` | `boolean` | `false` | `@propertyDataSource` | Controls whether the notification is shown |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `dismissible` | `boolean` | `true` | `@propertyDataSource` | Show a close/dismiss button |\n| `duration` | `number` | `0` | `@propertyDataSource` | Auto-dismiss after N milliseconds (0 = no auto-dismiss) |\n| `position` | `string` | `''` | `@propertyDataSource` | Positioning hint: `'top'`, `'bottom'`, `'top-right'`, `'bottom-right'`, etc. Empty = inline |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a feedback/display component controlled by the `visible` property.\n\n- Page sets `visible=true` to show the notification\n- Page sets `visible=false` or user dismisses to hide it\n- When `duration > 0`, the component auto-sets `visible=false` after the timeout\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `dismiss` | `{}` | \u2713 | Fired when the notification is dismissed (by user or auto-timeout) |\n| `action` | `{}` | \u2713 | Fired when the Action slot content is clicked |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('dismiss', {\n  bubbles: true,\n  composed: true,\n  detail: {}\n}));\n```\n\n---\n\n## 6. Auto-Dismiss Logic\n\nWhen `duration > 0` and `visible=true`:\n\n- Start a timer on render\n- After `duration` ms: set `visible=false`, emit `dismiss`\n- If user dismisses manually before timeout: clear the timer\n- If `visible` changes to `false` externally: clear the timer\n\n---\n\n## 7. Type Semantics\n\n| Type | Usage |\n|------|-------|\n| `info` | General information, neutral |\n| `success` | Action completed successfully |\n| `warning` | Attention needed, non-critical |\n| `error` | Something failed, requires attention |\n\nThe type drives the visual styling (colors, default icon). The component does not define specific colors \u2014 those are handled via Tailwind classes per type.\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Hidden** | `visible=false` \u2014 nothing rendered |\n| **Visible** | Notification displayed with enter animation |\n| **Dismissing** | Exit animation, then hidden |\n\n---\n\n## 9. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"alert\"` for error/warning, `role=\"status\"` for info/success |\n| Live region | `aria-live=\"assertive\"` for error, `aria-live=\"polite\"` for others |\n| Dismiss button | `aria-label=\"Dismiss notification\"` |\n| Action | Inherits a11y from the content inside Action slot |\n\n---\n\n\n## 10. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupNotifyUser/usage" {
    export const skill = "\n# notify + user \u2014 Usage\n\n> Quick reference for using molecules in the **notify + user** group.\n> Use this when the system needs to **inform the user** about an event, status, or result.\n> Controlled via the `visible` property \u2014 page sets it to show/hide.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Title` | Notification title/heading |\n| `Message` | Notification body content |\n| `Action` | Actionable element (button, link) inside the notification |\n| `Icon` | Custom icon content |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `type` | `string` | `'info'` | Notification type: `'info'`, `'success'`, `'warning'`, `'error'` |\n| `visible` | `boolean` | `false` | Show or hide the notification |\n| `dismissible` | `boolean` | `true` | Show a close/dismiss button |\n| `duration` | `number` | `0` | Auto-dismiss after N ms (0 = manual dismiss only) |\n| `position` | `string` | `''` | Position hint: `'top'`, `'bottom'`, `'top-right'`, etc. Empty = inline |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `dismiss` | `{}` | Fired when the notification is dismissed |\n| `action` | `{}` | Fired when the Action slot is clicked |\n\n---\n\n## Examples\n\n### Warning banner with action\n\n```html\n<molecules--banner-102020\n  type=\"warning\"\n  visible=\"{{ui.system.showUpdateBanner}}\"\n  position=\"top\"\n  dismissible=\"true\">\n  <Icon>\u26A0\uFE0F</Icon>\n  <Message>A new version is available.</Message>\n  <Action>\n    <button>Update Now</button>\n  </Action>\n</molecules--banner-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupPlayMedia/creation" {
    export const skill = "\n# groupPlayMedia \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupPlayMedia** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupPlayMedia` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Title or description displayed alongside the player |\n| `Source` | Yes | Media source. Attributes: `src` (required), `type` (e.g. `\"video/mp4\"`, `\"audio/mpeg\"`) |\n| `Track` | No | Subtitle/caption track. Attributes: `src`, `kind` (`\"subtitles\"`, `\"captions\"`), `lang`, `label` |\n\n```typescript\nslotTags = ['Label', 'Source', 'Track'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Source src=\"...\" type=\"...\" />\n\u251C\u2500\u2500 <Source src=\"...\" type=\"...\" />\n\u2514\u2500\u2500 <Track src=\"...\" kind=\"...\" lang=\"...\" label=\"...\" />\n```\n\n### Multiple Sources\n\nMultiple `<Source>` tags allow fallback formats. The browser picks the first supported type:\n\n```html\n<Source src=\"video.webm\" type=\"video/webm\" />\n<Source src=\"video.mp4\" type=\"video/mp4\" />\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `poster` | `string` | `''` | `@propertyDataSource` | Thumbnail image URL (used by video implementations, ignored by audio) |\n| `autoplay` | `boolean` | `false` | `@propertyDataSource` | Start playback automatically |\n| `loop` | `boolean` | `false` | `@propertyDataSource` | Restart playback when ended |\n| `muted` | `boolean` | `false` | `@propertyDataSource` | Start muted |\n| `preload` | `string` | `'metadata'` | `@propertyDataSource` | Preload strategy: `'none'`, `'metadata'`, `'auto'` |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all controls |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show loading indicator (e.g. while buffering) |\n\n### 3.3 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isPlaying` | `boolean` | `false` | `@state` | Whether media is currently playing |\n| `currentTime` | `number` | `0` | `@state` | Current playback position in seconds |\n| `duration` | `number` | `0` | `@state` | Total duration in seconds |\n| `volume` | `number` | `1` | `@state` | Current volume (0\u20131) |\n| `isMuted` | `boolean` | `false` | `@state` | Whether audio is muted |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a display/playback component. Media sources come from slot tags.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `play` | `{}` | \u2713 | Playback started |\n| `pause` | `{}` | \u2713 | Playback paused |\n| `ended` | `{}` | \u2713 | Playback reached the end |\n| `timeUpdate` | `{ currentTime: number, duration: number }` | \u2713 | Playback position changed |\n| `error` | `{ message: string }` | \u2713 | Media failed to load or play |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('play', {\n  bubbles: true,\n  composed: true,\n  detail: {}\n}));\n\nthis.dispatchEvent(new CustomEvent('timeUpdate', {\n  bubbles: true,\n  composed: true,\n  detail: { currentTime: this.currentTime, duration: this.duration }\n}));\n```\n\n---\n\n## 6. Reading Sources\n\nRead sources and tracks inline using `getSlots`:\n\n```typescript\nconst sources = this.getSlots('Source').map(el => ({\n  src: el.getAttribute('src') || '',\n  type: el.getAttribute('type') || '',\n}));\n\nconst tracks = this.getSlots('Track').map(el => ({\n  src: el.getAttribute('src') || '',\n  kind: el.getAttribute('kind') || 'subtitles',\n  lang: el.getAttribute('lang') || '',\n  label: el.getAttribute('label') || '',\n}));\n```\n\n---\n\n## 7. Playback Controls\n\nThe component must expose internal methods for controlling playback\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Idle** | Poster shown (video) or default state (audio), controls visible |\n| **Playing** | Media playing, progress bar advancing |\n| **Paused** | Media paused, play button visible |\n| **Buffering** | Loading indicator over the player |\n| **Ended** | Replay button visible |\n| **Disabled** | Controls dimmed, no interaction |\n| **Error** | Error message displayed, controls hidden |\n\n---\n\n## 9. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-label` from Label slot content |\n| Play/Pause | `aria-label=\"Play\"` / `aria-label=\"Pause\"` |\n| Progress bar | `role=\"slider\"`, `aria-valuenow`, `aria-valuemin=\"0\"`, `aria-valuemax=duration` |\n| Volume | `role=\"slider\"`, `aria-valuenow`, `aria-valuemin=\"0\"`, `aria-valuemax=\"1\"` |\n| Mute | `aria-label=\"Mute\"` / `aria-label=\"Unmute\"` |\n| Keyboard | `Space` toggle play/pause, `ArrowLeft`/`ArrowRight` seek, `ArrowUp`/`ArrowDown` volume |\n\n---\n\n\n## 10. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupPlayMedia/usage" {
    export const skill = "\n# play + media \u2014 Usage\n\n> Quick reference for using molecules in the **play + media** group.\n> Use this when the user needs to **play audio or video content**.\n> All implementations share the same slot tag contract \u2014 swap the tag for a different player style.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Title or description displayed alongside the player |\n| `Source` | Media source. Attributes: `src` (required), `type` (e.g. `\"video/mp4\"`, `\"audio/mpeg\"`). Multiple allowed for fallback formats |\n| `Track` | Subtitle/caption track. Attributes: `src`, `kind` (`\"subtitles\"`, `\"captions\"`), `lang`, `label` |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `poster` | `string` | `''` | Thumbnail image URL (video only, ignored by audio) |\n| `autoplay` | `boolean` | `false` | Start playback automatically |\n| `loop` | `boolean` | `false` | Restart playback when ended |\n| `muted` | `boolean` | `false` | Start muted |\n| `preload` | `string` | `'metadata'` | Preload strategy: `'none'`, `'metadata'`, `'auto'` |\n| `disabled` | `boolean` | `false` | Disables all controls |\n| `loading` | `boolean` | `false` | Shows a loading indicator |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `play` | `{}` | Playback started |\n| `pause` | `{}` | Playback paused |\n| `ended` | `{}` | Playback reached the end |\n| `timeUpdate` | `{ currentTime: number, duration: number }` | Playback position changed |\n| `error` | `{ message: string }` | Media failed to load or play |\n\n---\n\n## Examples\n\n\n```html\n<molecules--video-player-102020\n  poster=\"thumbnail.jpg\"\n  preload=\"metadata\">\n  <Label>Product Demo</Label>\n  <Source src=\"demo.webm\" type=\"video/webm\" />\n  <Source src=\"demo.mp4\" type=\"video/mp4\" />\n  <Track src=\"subs-en.vtt\" kind=\"subtitles\" lang=\"en\" label=\"English\" />\n  <Track src=\"subs-pt.vtt\" kind=\"subtitles\" lang=\"pt\" label=\"Portugu\u00EAs\" />\n</molecules--video-player-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupRateItem/creation" {
    export const skill = "\n# groupRateItem \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupRateItem** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupRateItem` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Item` | No | Defines one selectable rating option. Attribute: `value` (required). Content = visual label (emoji, icon, text) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Item'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Item value=\"...\">\n\u2514\u2500\u2500 <Helper>\n```\n\n### Item vs Auto-generate\n\n- **If `<Item>` slots exist:** render only the declared items. `min`, `max`, `step` are ignored\n- **If no `<Item>` slots:** auto-generate options from `min` to `max` with `step` increments, using the implementation's default visual (stars, dots, numbers, etc.)\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Currently selected rating value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `min` | `number` | `0` | `@propertyDataSource` | Minimum rating value (used when no `<Item>` slots) |\n| `max` | `number` | `5` | `@propertyDataSource` | Maximum rating value (used when no `<Item>` slots) |\n| `step` | `number` | `1` | `@propertyDataSource` | Increment between values (used when no `<Item>` slots) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A rating is required |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `hoverValue` | `number | null` | `null` | `@state` | Value being hovered (for visual preview before selection) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **number**\n- `null` means no rating selected\n- When using `<Item>` slots, value matches the `value` attribute of the selected item (parsed as number)\n- When auto-generated, value is a number in the `min`\u2013`max` range\n\n### View Mode\n\n- If `value` is `null`: display `\"\u2014\"`\n- Otherwise: display the selected rating visually (filled stars, highlighted emoji, etc.)\n- No hover effect, no interaction\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Rating selected |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders interactive rating options |\n| **View** | `false` | Renders selected value as static visual |\n\n- In view mode: no interaction, no hover, no events, no error, no helper\n\n---\n\n## 7. Hover Behavior\n\nWhen editing and not disabled/readonly:\n\n- On mouse enter over an option: set `hoverValue` to that option's value\n- All options up to `hoverValue` are visually highlighted (for cumulative implementations like stars)\n- For discrete implementations (emoji, thumbs): only the hovered option is highlighted\n- On mouse leave: reset `hoverValue` to `null`, visual returns to reflect `value`\n- On click: set `value` = clicked option's value, emit `change`\n\n---\n\n## 8. Reading Items\n\nWhen `<Item>` slots are present, read them inline using `getSlots`:\n\n```typescript\nconst items = this.getSlots('Item').map(el => ({\n  value: Number(el.getAttribute('value')),\n  label: el.innerHTML,\n}));\n```\n\nWhen no `<Item>` slots, generate options:\n\n```typescript\nconst items = [];\nfor (let v = this.min; v <= this.max; v += this.step) {\n  items.push({ value: v, label: '' });\n}\n```\n\n---\n\n## 9. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until a rating is selected |\n\n---\n\n## 10. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 11. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance, no selection |\n| **Hovered** | Preview highlight on the hovered option |\n| **Selected** | Selected value visually active |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No interaction, selected value visible |\n| **Error** | Error border/style, error message visible |\n| **View Mode** | Static visual of selected value |\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"radiogroup\"` |\n| Each option | `role=\"radio\"`, `aria-checked`, `aria-label` with the value |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Keyboard | `ArrowLeft`/`ArrowRight` navigate options; `Enter`/`Space` selects |\n\n---\n\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupRateItem/usage" {
    export const skill = "\n# rate + item \u2014 Usage\n\n> Quick reference for using molecules in the **rate + item** group.\n> Use this when you need the user to **rate or score an item**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Item` | One rating option. Attribute: `value` (required). Content = visual label (emoji, icon, text). When no `<Item>` is declared, options are auto-generated from `min`/`max`/`step` |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Selected rating value. `null` = no rating |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `min` | `number` | `0` | Minimum value (ignored when `<Item>` slots are present) |\n| `max` | `number` | `5` | Maximum value (ignored when `<Item>` slots are present) |\n| `step` | `number` | `1` | Increment between values (ignored when `<Item>` slots are present) |\n| `is-editing` | `boolean` | `true` | `true` = interactive, `false` = read-only visual |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents selection but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a rating as required |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when a rating is selected |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is a plain **number** representing the selected rating\n- `null` when no rating is selected\n- When using `<Item>` slots, `value` matches the item's `value` attribute (parsed as number)\n- When auto-generated, `value` is in the `min`\u2013`max` range\n\n\n---\n\n## Examples\n\n### Star rating (auto-generated, 1\u20135)\n\n```html\n<molecules--star-rating-102020\n  value=\"{{ui.review.rating}}\"\n  error=\"{{ui.review.ratingError}}\"\n  min=\"1\"\n  max=\"5\"\n  required>\n  <Label>Rate this product</Label>\n</molecules--star-rating-102020>\n```\n\n### Thumbs up/down\n\n```html\n<molecules--thumbs-102020\n  value=\"{{ui.comment.vote}}\">\n  <Item value=\"0\">\uD83D\uDC4E</Item>\n  <Item value=\"1\">\uD83D\uDC4D</Item>\n</molecules--thumbs-102020>\n```\n\n\n```\n";
}
declare module "_102020_/l2/skills/molecules/groupScanCode/creation" {
    export const skill = "\n# groupScanCode \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupScanCode** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupScanCode` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above the scanner area |\n| `Helper` | No | Help text displayed below the scanner |\n| `Trigger` | No | Custom content for the button that opens the camera |\n| `Result` | No | Custom content for displaying the decoded result |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Result'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Result>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Decoded result set by the page after processing |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `facing` | `string` | `'environment'` | `@propertyDataSource` | Camera facing: `'environment'` (rear) or `'user'` (front) |\n| `autoCapture` | `boolean` | `false` | `@propertyDataSource` | Continuously capture frames while camera is open (for real-time scanning) |\n| `captureInterval` | `number` | `500` | `@propertyDataSource` | Interval in ms between auto captures (used when `autoCapture=true`) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables the scanner |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (e.g. page is processing a captured frame) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Whether the camera viewfinder is active |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is a plain **string** containing the decoded result (text from QR, barcode number, OCR text, etc.)\n- `null` means no result yet\n- The **page** is responsible for decoding \u2014 the component only captures and emits image data\n- When the page finishes processing, it sets `value` with the decoded text\n\n### Capture Flow\n\n```\n1. User opens the camera (click trigger or auto-open)\n2. Component activates camera via navigator.mediaDevices.getUserMedia()\n3. User frames the target OR autoCapture sends frames periodically\n4. Component captures frame as base64 image \u2192 emits `capture` event\n5. Page receives image, processes via BFF (QR decode, barcode read, OCR)\n6. Page sets `value` with the decoded result\n7. Component displays the result (via Result slot or default display)\n8. Camera closes (manual or auto on successful decode)\n```\n\n### View After Capture\n\n- If `value` is set: display decoded result text\n- If `hasSlot('Result')`: use custom result layout\n- Camera viewfinder is replaced by the result display\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `capture` | `{ image: string }` | \u2713 | Frame captured \u2014 `image` is a base64 data URL |\n| `open` | `{}` | \u2713 | Camera opened |\n| `close` | `{}` | \u2713 | Camera closed |\n| `change` | `{ value: string | null }` | \u2713 | Value changed (result set by page) |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('capture', {\n  bubbles: true,\n  composed: true,\n  detail: { image: base64DataUrl }\n}));\n```\n\n---\n\n## 6. Camera Management\n\n- Open camera via `navigator.mediaDevices.getUserMedia({ video: { facingMode: this.facing } })`\n- Stream is rendered to a `<video>` element inside the component\n- Capture a frame by drawing the video to an offscreen `<canvas>` and calling `canvas.toDataURL()`\n- On close: stop all tracks via `stream.getTracks().forEach(t => t.stop())`\n- Handle permission denied gracefully \u2014 set `error` with appropriate message\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Idle** | Trigger button visible, no camera |\n| **Open** | Camera viewfinder active, capture button visible |\n| **Capturing** | Flash or pulse animation on capture |\n| **Loading** | Processing indicator while page decodes |\n| **Result** | Decoded value displayed, camera closed |\n| **Disabled** | Trigger dimmed, no interaction |\n| **Error** | Error message (permission denied, camera unavailable, decode failed) |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Trigger | `role=\"button\"`, `aria-label=\"Open camera scanner\"` |\n| Video | `aria-hidden=\"true\"` (visual-only element) |\n| Capture button | `aria-label=\"Capture\"` |\n| Result | `aria-live=\"polite\"` to announce decoded result |\n| Error | `aria-describedby` pointing to error element |\n| Keyboard | `Enter`/`Space` on trigger opens camera; `Escape` closes |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupScanCode/usage" {
    export const skill = "\n\n# scan + code \u2014 Usage\n\n> Quick reference for using molecules in the **scan + code** group.\n> Use this when the user needs to **capture information via camera** (QR code, barcode, document).\n> The component captures image frames; the page is responsible for decoding via BFF.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above the scanner area |\n| `Helper` | Descriptive text shown below the scanner |\n| `Trigger` | Custom content for the button that opens the camera |\n| `Result` | Custom content for displaying the decoded result |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Decoded result, set by the page after processing |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `facing` | `string` | `'environment'` | Camera facing: `'environment'` (rear) or `'user'` (front) |\n| `auto-capture` | `boolean` | `false` | Continuously capture frames for real-time scanning |\n| `capture-interval` | `number` | `500` | Interval in ms between auto captures |\n| `disabled` | `boolean` | `false` | Disables the scanner |\n| `loading` | `boolean` | `false` | Shows processing indicator while page decodes |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `capture` | `{ image: string }` | Frame captured \u2014 image is a base64 data URL |\n| `open` | `{}` | Camera opened |\n| `close` | `{}` | Camera closed |\n| `change` | `{ value: string | null }` | Value changed (result set by page) |\n\n---\n\n## Capture Flow\n\n```\n1. User clicks trigger \u2192 camera opens \u2192 emits `open`\n2. Component captures frame \u2192 emits `capture` with { image: base64 }\n3. Page processes image via BFF \u2192 sets `value` with decoded text\n4. Component displays result \u2192 camera closes \u2192 emits `close`\n```\n\n---\n\n## Examples\n\n### QR code scanner\n\n```html\n<molecules--qr-scanner-102020\n  value=\"{{ui.payment.qrResult}}\"\n  error=\"{{ui.payment.scanError}}\"\n  loading=\"{{ui.payment.isDecoding}}\"\n  auto-capture=\"true\"\n  capture-interval=\"300\">\n  <Label>Scan QR Code</Label>\n  <Trigger>\uD83D\uDCF7 Open Camera</Trigger>\n  <Helper>Point at a QR code to scan automatically</Helper>\n</molecules--qr-scanner-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSearchContent/creation" {
    export const skill = "\n# groupSearchContent \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupSearchContent** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupSearchContent` |\n| **Category** | Data Discovery |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above the search field |\n| `Helper` | No | Help text displayed below the search field |\n| `Suggestion` | No | One search suggestion. Attributes: `value` (required). Content = display label |\n| `Empty` | No | Content shown when no suggestions match |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Suggestion', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Suggestion value=\"...\">...label...</Suggestion>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Confirmed value \u2014 either a suggestion's `value` or the raw typed text |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text for the search input |\n| `debounce` | `number` | `300` | `@propertyDataSource` | Debounce time in ms before emitting `search` event |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables the search field |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Shows loading indicator (e.g. while fetching suggestions) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `query` | `string` | `''` | `@state` | Current text in the search input |\n| `isOpen` | `boolean` | `false` | `@state` | Whether the suggestions panel is open |\n\n---\n\n## 4. Value Contract\n\n### Confirmation Logic\n\n- **User selects a suggestion:** `value` = suggestion's `value` attribute, `query` = suggestion's label\n- **User presses Enter without selecting:** `value` = raw `query` text\n- **User clears the input:** `value` = `null`, `query` = `''`\n\n### Search Flow\n\n```\n1. User types \u2192 update query, debounce, emit `search` with { query }\n2. Page calls BFF, updates <Suggestion> slot tags\n3. Component renders suggestion list\n4. User selects suggestion \u2192 value = suggestion.value, emit `change`\n   OR user presses Enter \u2192 value = query text, emit `change`\n5. Suggestions panel closes\n```\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `search` | `{ query: string }` | \u2713 | Fired (debounced) when user types \u2014 page should update suggestions |\n| `change` | `{ value: string | null }` | \u2713 | Fired when a value is confirmed (suggestion selected or Enter pressed) |\n| `clear` | `{}` | \u2713 | Fired when the user clears the search |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('search', {\n  bubbles: true,\n  composed: true,\n  detail: { query: this.query }\n}));\n\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. Reading Suggestions\n\nRead suggestions inline using `getSlots`:\n\n```typescript\nconst suggestions = this.getSlots('Suggestion').map(el => ({\n  value: el.getAttribute('value') || '',\n  label: el.innerHTML,\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Empty** | Placeholder visible, no suggestions |\n| **Typing** | Input active, suggestions panel may open |\n| **Open** | Suggestions panel visible |\n| **Loading** | Loading indicator inside the suggestions area |\n| **Selected** | Value confirmed, input shows selected label or query |\n| **Disabled** | Dimmed, no interaction |\n| **Error** | Error border/style, error message visible |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Input | `role=\"combobox\"`, `aria-expanded`, `aria-autocomplete=\"list\"` |\n| Suggestions panel | `role=\"listbox\"` |\n| Suggestion items | `role=\"option\"`, `aria-selected` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Clear button | `aria-label=\"Clear search\"` |\n| Keyboard | `ArrowDown`/`ArrowUp` navigate suggestions; `Enter` confirms; `Escape` closes panel |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupSearchContent/usage" {
    export const skill = "\n# search + content \u2014 Usage\n\n> Quick reference for using molecules in the **search + content** group.\n> Use this when the user needs to **find content using text search**.\n> The component emits `search` events; the page provides suggestions via slot tags.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above the search field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Suggestion` | One search result. Attributes: `value` (required). Content = display label |\n| `Empty` | Content shown when no suggestions match |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Confirmed value \u2014 suggestion value or typed text. `null` = nothing confirmed |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Placeholder text for the search input |\n| `debounce` | `number` | `300` | Debounce time in ms before emitting `search` event |\n| `disabled` | `boolean` | `false` | Disables the field |\n| `loading` | `boolean` | `false` | Shows loading indicator while fetching suggestions |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `search` | `{ query: string }` | Fired (debounced) when user types. Page should update suggestions |\n| `change` | `{ value: string | null }` | Fired when value is confirmed (suggestion selected or Enter pressed) |\n| `clear` | `{}` | Fired when the user clears the search |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- `value` is a **string** \u2014 either the selected suggestion's `value` attribute or the raw typed text\n- `null` when nothing is confirmed\n- User selects suggestion \u2192 `value` = suggestion value\n- User presses Enter \u2192 `value` = typed text\n\n---\n\n## Examples\n\n### Product search with suggestions\n\n```html\n<molecules--search-field-102020\n  value=\"{{ui.catalog.selectedProduct}}\"\n  error=\"{{ui.catalog.searchError}}\"\n  loading=\"{{ui.catalog.isSearching}}\"\n  placeholder=\"Search products...\"\n  debounce=\"300\">\n  <Label>Product Search</Label>\n  <Suggestion value=\"prod-001\">Wireless Headphones</Suggestion>\n  <Suggestion value=\"prod-002\">Bluetooth Speaker</Suggestion>\n  <Suggestion value=\"prod-003\">USB-C Cable</Suggestion>\n  <Empty>No products found</Empty>\n</molecules--search-field-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/creation" {
    export const skill = "\n# groupSelectFileForUpload \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupSelectFileForUpload** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupSelectFileForUpload` |\n| **Category** | Data Entry |\n| **Version** | `1.0.1` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the file selection button or drop zone |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `File[]` | `[]` | `@propertyDataSource` | Currently selected files |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `multiple` | `boolean` | `false` | `@propertyDataSource` | Allow selecting more than one file |\n| `accept` | `string` | `''` | `@propertyDataSource` | Accepted file types (e.g. `'image/*'`, `'.pdf,.docx'`) |\n| `maxSizeKb` | `number` | `0` | `@propertyDataSource` | Maximum file size in KB per file (0 = no limit) |\n| `maxFiles` | `number` | `0` | `@propertyDataSource` | Maximum number of files when `multiple=true` (0 = no limit) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (e.g. upload in progress, controlled by page) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isDragging` | `boolean` | `false` | `@state` | Whether a file is being dragged over the drop zone |\n\n---\n\n## 4. Value Contract\n\n- `value` holds the current `File[]` bound to the global state via `@propertyDataSource`\n- Default is `[]` (empty array)\n- When the user selects or drops files, they are validated and merged into `value`\n- When the user removes a file, it is removed from `value`\n- The page reads `value` from the state and is responsible for uploading via BFF\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `reject` | `{ files: File[], reason: 'size' | 'type' | 'count' }` | \u2713 | Fired when files are rejected due to validation |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('reject', {\n  bubbles: true,\n  composed: true,\n  detail: { files: rejectedFiles, reason: 'size' }\n}));\n```\n\n---\n\n## 6. File Validation\n\nValidation happens before adding files to `value`. Invalid files are emitted via `reject`.\n\n| Rule | Condition | Reject reason |\n|------|-----------|---------------|\n| File type | `accept` is set and file type does not match | `'type'` |\n| File size | `maxSizeKb > 0` and file size exceeds limit | `'size'` |\n| File count | `maxFiles > 0` and total count would exceed limit | `'count'` |\n\n- Valid files are merged into `value`\n- Invalid files are emitted via `reject` event\n- If all files are invalid, `value` remains unchanged\n\n---\n\n## 7. Drag and Drop\n\nWhen the implementation supports drag and drop:\n\n```\n@dragover: preventDefault(), set isDragging = true\n@dragleave: set isDragging = false\n@drop: preventDefault(), set isDragging = false\n        extract files from event.dataTransfer.files\n        run validation, add valid files to value, emit reject for invalid\n```\n\n- `isDragging` drives the visual highlight of the drop zone\n- Drop zone must call `event.preventDefault()` on `dragover` to allow dropping\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Page/Organism is responsible for setting the error message\n- Validation rejections are surfaced via the `reject` event \u2014 page decides how to display them\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Dragging** | Drop zone highlighted, visual feedback |\n| **Disabled** | Reduced opacity, no interaction, drag ignored |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, interaction blocked |\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Input | `<input type=\"file\">` always present (visually hidden) |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Drop zone | `role=\"button\"`, `tabindex=\"0\"`, `aria-label` describing action |\n| Keyboard | `Enter`/`Space` on drop zone triggers file picker |\n\n---\n\n## 11. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/usage" {
    export const skill = "\n# select + fileForUpload \u2014 Usage\n\n> Quick reference for using molecules in the **select + fileForUpload** group.\n> Use this when you need the user to **select files to be uploaded**.\n\n---\n\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom content for the file selection button or drop zone |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `File[]` | `[]` | Currently selected files, bound to state |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `multiple` | `boolean` | `false` | Allow selecting more than one file |\n| `accept` | `string` | `''` | Accepted file types (e.g. `'image/*'`, `'.pdf,.docx'`) |\n| `max-size-kb` | `number` | `0` | Maximum file size in KB per file (0 = no limit) |\n| `max-files` | `number` | `0` | Maximum number of files when `multiple=true` (0 = no limit) |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `loading` | `boolean` | `false` | Shows a loading indicator (e.g. upload in progress) |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `reject` | `{ files: File[], reason: 'size' | 'type' | 'count' }` | Fired when files are rejected due to validation |\n\n---\n\n## Value Contract\n\n- `value` holds the current `File[]` bound to the global state\n- Files are added on selection/drop and removed via the file list UI\n- The page reads `value` from state and is responsible for uploading via BFF\n- Use the `loading` property to block interaction while an upload is in progress\n\n\n---\n\n## Examples\n\n### Simple file button\n\n```html\n<molecules--file-button-102020\n  value=\"{{ui.form.attachments}}\"\n  accept=\".pdf,.docx\"\n  error=\"{{ui.form.attachmentError}}\">\n  <Label>Attachment</Label>\n  <Helper>PDF or Word, up to 5MB</Helper>\n</molecules--file-button-102020>\n```\n\n### Multi-file drag-drop zone\n\n```html\n<molecules--dropzone-102020\n  value=\"{{ui.upload.files}}\"\n  multiple=\"true\"\n  accept=\"image/*\"\n  max-size-kb=\"2048\"\n  max-files=\"5\"\n  loading=\"{{ui.upload.loading}}\"\n  error=\"{{ui.upload.error}}\">\n  <Label>Product Images</Label>\n  <Trigger>Drop images here or click to browse</Trigger>\n  <Helper>Up to 5 images, max 2MB each</Helper>\n</molecules--dropzone-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectMany/creation" {
    export const skill = "\n# groupSelectMany \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupSelectMany** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupSelectMany` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the trigger button (for dropdown implementations) |\n| `Item` | Yes | Defines one selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | No | Groups items under a named heading. Attribute: `label` |\n| `Empty` | No | Content shown when no items are available |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Group>\n\u2502   \u2514\u2500\u2500 <Item value=\"...\" disabled>\n\u251C\u2500\u2500 <Item>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string` | `''` | `@propertyDataSource` | Comma-separated selected values (e.g. `\"tag1,tag2,tag3\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Text shown when no items are selected (fallback when no `Trigger` slot) |\n| `searchable` | `boolean` | `false` | `@propertyDataSource` | Show a search input to filter items |\n| `minSelection` | `number` | `0` | `@propertyDataSource` | Minimum number of selected items (0 = no minimum) |\n| `maxSelection` | `number` | `0` | `@propertyDataSource` | Maximum number of selected items (0 = no limit) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | At least one selection is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (items not yet available) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Whether the selector panel is currently open (for dropdown implementations) |\n| `searchQuery` | `string` | `''` | `@state` | Current search filter text (used when `searchable=true`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored as a **comma-separated string** of selected item values\n- Empty string `''` means no items selected\n- Example: `\"apple,banana,grape\"`\n- Item values **must not contain commas**\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string }` | \u2713 | Selection changed \u2014 value is comma-separated string |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders interactive multi-select |\n| **View** | `false` | Renders selected labels as static text or tags |\n\n- In view mode: no trigger, no panel, no events, no error, no helper\n\n---\n\n\n## 7. Open/Close Behavior (dropdown implementations)\n\n- Clicking the trigger toggles `isOpen`\n- Selecting an item toggles its value but **does not close** the panel (user may select more)\n- Pressing `Escape` closes the panel\n- Clicking outside the component closes the panel\n- When `disabled` or `readonly`: trigger click is ignored, panel never opens\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === ''` | Error state until at least one item is selected |\n| Selected count < `minSelection` | Error state |\n| Selected count >= `maxSelection` | Additional items cannot be selected (disabled visually) |\n| Item with `disabled` attribute | Rendered but not selectable |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Open** | Selector panel visible (dropdown implementations) |\n| **Partial** | Some items selected \u2014 trigger shows count or tags |\n| **Full** | `maxSelection` reached \u2014 unselected items visually disabled |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No interaction, selected items visible |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator; panel does not open |\n| **View Mode** | Selected labels as plain text or tags |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container (checkbox/chips) | `role=\"group\"` |\n| Container (dropdown) | `role=\"combobox\"`, `aria-expanded`, `aria-haspopup=\"listbox\"` |\n| Panel (dropdown) | `role=\"listbox\"`, `aria-multiselectable=\"true\"` |\n| Items | `role=\"option\"`, `aria-selected`, `aria-disabled` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Keyboard | `ArrowDown`/`ArrowUp` navigate; `Space` toggles; `Escape` closes |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectMany/usage" {
    export const skill = "\n# select + many \u2014 Usage\n\n> Quick reference for using molecules in the **select + many** group.\n> Use this when you need the user to **choose one or more options** from a list.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom content for the trigger button (dropdown implementations) |\n| `Item` | One selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | Groups items under a named heading. Attribute: `label` |\n| `Empty` | Content shown when no items are available |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string` | `''` | Comma-separated selected values (e.g. `\"apple,banana,grape\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Text shown when no items are selected |\n| `searchable` | `boolean` | `false` | Show a search input to filter items |\n| `min-selection` | `number` | `0` | Minimum selected items (0 = no minimum) |\n| `max-selection` | `number` | `0` | Maximum selected items (0 = no limit) |\n| `is-editing` | `boolean` | `true` | `true` = interactive selector, `false` = read-only labels |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents selection but keeps the field focusable |\n| `required` | `boolean` | `false` | At least one selection is required |\n| `loading` | `boolean` | `false` | Shows a loading indicator; panel does not open |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string }` | Fired when selection changes. Value is comma-separated string |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Comma-separated **string** of selected item values\n- Empty string `''` when nothing is selected\n- Example: `\"read,write,execute\"`\n- Item values must not contain commas\n\n---\n\n## Examples\n\n### Checkbox group \u2014 permissions\n\n```html\n<molecules--checkbox-group-102020\n  value=\"{{ui.user.permissions}}\"\n  error=\"{{ui.user.permissionsError}}\"\n  required>\n  <Label>Permissions</Label>\n  <Item value=\"read\">Read</Item>\n  <Item value=\"write\">Write</Item>\n  <Item value=\"execute\">Execute</Item>\n  <Item value=\"admin\" disabled>Admin (restricted)</Item>\n</molecules--checkbox-group-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/creation" {
    export const skill = "# groupSelectOne \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupSelectOne** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupSelectOne` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the trigger button. When no item is selected, this content acts as the placeholder |\n| `Item` | Yes | Defines one selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | No | Groups items under a named heading. Attribute: `label` |\n| `Empty` | No | Content shown when no items are available |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Group label=\"...\">\n\u2502   \u2514\u2500\u2500 <Item value=\"...\">\n\u251C\u2500\u2500 <Item value=\"...\">\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Value of the currently selected item |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Text shown when no item is selected (fallback when no `Trigger` slot) |\n| `searchable` | `boolean` | `false` | `@propertyDataSource` | Show a search input inside the selector to filter items |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A selection is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (items not yet available) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Whether the selector panel is currently open |\n| `searchQuery` | `string` | `''` | `@state` | Current search filter text (used when `searchable=true`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a plain **string** matching the `value` attribute of the selected `<Item>`\n- `null` means no item selected\n- The label displayed in the trigger is read from the selected `<Item>` inner content \u2014 never stored\n\n### View Mode\n\n- If value is `null`: display placeholder or `\"\u2014\"`\n- Otherwise: display the label of the selected item as plain text\n- Label is obtained via `this.findItem(this.value)?.label`\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Selection confirmed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders trigger button + selector panel |\n| **View** | `false` | Renders selected item label as static text |\n\n- In view mode: no trigger, no panel, no events, no error, no helper\n\n---\n\n## 7. Open/Close Behavior\n\n- Clicking the trigger toggles `isOpen`\n- Selecting an item sets `value`, closes the panel (`isOpen = false`), emits `change`\n- Pressing `Escape` closes the panel without changing value\n- Clicking outside the component closes the panel (use a `@click` listener on `document` in `connectedCallback`, remove in `disconnectedCallback`)\n- When `disabled` or `readonly`: trigger click is ignored, panel never opens\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until an item is selected |\n| Item with `disabled` attribute | Rendered but not selectable; clicking it is ignored |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Open** | Selector panel visible |\n| **Selected** | Trigger shows selected item label |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No interaction, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator in trigger; panel does not open |\n| **View Mode** | Selected label as plain text |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Trigger | `role=\"combobox\"`, `aria-expanded`, `aria-haspopup=\"listbox\"` |\n| Panel | `role=\"listbox\"` |\n| Items | `role=\"option\"`, `aria-selected`, `aria-disabled` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Keyboard | `ArrowDown`/`ArrowUp` navigate items; `Enter` selects; `Escape` closes |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n| 1.1.0 | 2026-04-20 | Removed item parsing helpers; inline pattern in Rendering Logic |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/usage" {
    export const skill = "\n# select + one \u2014 Usage\n\n> Quick reference for using molecules in the **select + one** group.\n> Use this when you need the user to **choose exactly one option** from a list.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom content for the trigger button. When no item is selected, this content acts as the placeholder |\n| `Item` | One selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | Groups items under a named heading. Attribute: `label` |\n| `Empty` | Content shown when no items are available |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Value of the selected item. `null` = nothing selected |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Text shown when no item is selected |\n| `searchable` | `boolean` | `false` | Show a search input to filter items |\n| `isEditing` | `boolean` | `true` | `true` = interactive selector, `false` = read-only label |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents selection but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a selection as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator; panel does not open |\n\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when an item is selected |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is a plain **string** matching the `value` attribute of the selected `<Item>`\n- `null` when nothing is selected\n- The displayed label comes from the `<Item>` inner content \u2014 not stored in `value`\n\n---\n\n## Examples\n\n### Simple dropdown\n\n```html\n<molecules--dropdown-102020\n  value=\"{{ui.form.country}}\"\n  error=\"{{ui.form.countryError}}\"\n  required>\n  <Label>Country</Label>\n  <Trigger>Select a country...</Trigger>\n  <Item value=\"br\">Brazil</Item>\n  <Item value=\"us\">United States</Item>\n  <Item value=\"de\">Germany</Item>\n</molecules--dropdown-102020>\n```\n\n### Grouped options\n\n```html\n<molecules--dropdown-102020\n  value=\"{{ui.form.category}}\"\n  error=\"{{ui.form.categoryError}}\">\n  <Label>Category</Label>\n  <Trigger>Select a category...</Trigger>\n  <Group label=\"Electronics\">\n    <Item value=\"phones\">Phones</Item>\n    <Item value=\"laptops\">Laptops</Item>\n  </Group>\n  <Group label=\"Clothing\">\n    <Item value=\"shirts\">Shirts</Item>\n    <Item value=\"shoes\">Shoes</Item>\n  </Group>\n  <Empty>No categories available</Empty>\n</molecules--dropdown-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/creation" {
    export const skill = "\n# groupShowProgress \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupShowProgress** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupShowProgress` |\n| **Category** | Feedback |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\nThis component has **no slot tags**. It is a visual primitive designed to be composed inside other components (e.g. button with spinner, upload zone with progress bar).\n\n```typescript\nslotTags = [];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Progress percentage 0\u2013100. `null` = indeterminate mode |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `size` | `string` | `'md'` | `@propertyDataSource` | Visual size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `label` | `string` | `''` | `@propertyDataSource` | Accessible label describing what is loading |\n| `showValue` | `boolean` | `false` | `@propertyDataSource` | Display the numeric percentage alongside the indicator |\n\n---\n\n## 4. Value Contract\n\n### Determinate Mode (`value` is a number)\n\n- `value` is clamped to `0\u2013100` before rendering\n- Represents the completion percentage of the operation\n- When `showValue=true`, display formatted as `\"42%\"`\n\n### Indeterminate Mode (`value` is `null`)\n\n- Renders an animated indicator with no specific progress\n- `showValue` is ignored \u2014 no percentage to display\n- Used when the total duration or size is unknown\n\n---\n\n## 5. Events\n\nThis component emits **no events**. It is purely visual.\n\n---\n\n## 6. Visual States\n\n| State | Condition | Behavior |\n|-------|-----------|----------|\n| **Indeterminate** | `value === null` | Animated loop (spinning, pulsing, or sliding) |\n| **Progress** | `value >= 0 && value < 100` | Partial fill reflecting the percentage |\n| **Complete** | `value === 100` | Full fill, animation stops |\n\n---\n\n## 7. Size Mapping\n\n| Size | Typical dimension |\n|------|-------------------|\n| `xs` | 12\u201316px (inline with text) |\n| `sm` | 20\u201324px (inside buttons) |\n| `md` | 32\u201340px (standalone) |\n| `lg` | 48\u201364px (prominent, page-level) |\n\nExact dimensions are implementation-specific (bar height, ring diameter, spinner size).\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Role | `role=\"progressbar\"` |\n| Label | `aria-label` from `label` prop |\n| Determinate | `aria-valuenow`, `aria-valuemin=\"0\"`, `aria-valuemax=\"100\"` |\n| Indeterminate | Omit `aria-valuenow` (screen readers announce as indeterminate) |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/usage" {
    export const skill = "\n# show + progress \u2014 Usage\n\n> Quick reference for using molecules in the **show + progress** group.\n> Use this when the system needs to **indicate the progress of an operation**.\n> This is a visual primitive \u2014 designed to be composed inside other components.\n\n---\n\n\n## Slot Tags\n\nNone. This component has no slot tags.\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Progress 0\u2013100. `null` = indeterminate (unknown duration) |\n| `size` | `string` | `'md'` | Visual size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `label` | `string` | `''` | Accessible label describing what is loading |\n| `show-value` | `boolean` | `false` | Display the percentage number alongside the indicator |\n\n---\n\n## Events\n\nNone. This component is purely visual.\n\n---\n\n## Value Format\n\n- `number` (0\u2013100): determinate progress, renders a fill at that percentage\n- `null`: indeterminate, renders an animated loop (spinner, pulse, sliding bar)\n\n---\n\n## Examples\n\n### Spinner inside a button (indeterminate)\n\n```html\n<molecules--spinner-102020\n  size=\"sm\"\n  label=\"Saving...\">\n</molecules--spinner-102020>\n```\n\n\n### Determinate ring with percentage\n\n```html\n<molecules--progress-ring-102020\n  value=\"{{ui.report.progress}}\"\n  size=\"md\"\n  show-value=\"true\"\n  label=\"Generating report\">\n</molecules--progress-ring-102020>\n```\n";
}
declare module "_102020_/l2/skills/molecules/groupTriggerAction/creation" {
    export const skill = "\n# groupTriggerAction \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupTriggerAction** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupTriggerAction` |\n| **Category** | Actions |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Button text content |\n| `Icon` | No | Icon content (SVG, emoji, HTML) displayed alongside or instead of the label |\n\n```typescript\nslotTags = ['Label', 'Icon'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Icon>\n\u2514\u2500\u2500 <Label>\n```\n\n### Flexible Composition\n\n- `Label` only: text button\n- `Icon` only: icon button\n- `Icon` + `Label`: button with icon and text\n- Neither: component uses i18n default or renders empty\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `size` | `string` | `'md'` | `@propertyDataSource` | Button size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `type` | `string` | `'button'` | `@propertyDataSource` | HTML button type: `'button'`, `'submit'`, `'reset'` |\n| `iconPosition` | `string` | `'start'` | `@propertyDataSource` | Icon placement: `'start'` (before label) or `'end'` (after label) |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Button is disabled |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Shows loading indicator, disables interaction |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is an action trigger.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `action` | `{}` | \u2713 | Fired when the button is clicked (not fired when disabled or loading) |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('action', {\n  bubbles: true,\n  composed: true,\n  detail: {}\n}));\n```\n\n---\n\n## 6. Size Mapping\n\n| Size | Description |\n|------|-------------|\n| `xs` | Compact, inline with text |\n| `sm` | Small, for dense layouts |\n| `md` | Default size |\n| `lg` | Large, prominent action |\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Hover** | Subtle highlight |\n| **Active** | Pressed/depressed visual feedback |\n| **Focused** | Focus ring for keyboard navigation |\n| **Disabled** | Reduced opacity, no interaction |\n| **Loading** | Loading indicator replaces icon or label, interaction blocked |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Element | Native `<button>` element |\n| Label | `aria-label` from Label slot content when icon-only |\n| Disabled | `disabled` attribute on `<button>` |\n| Loading | `aria-busy=\"true\"`, `aria-disabled=\"true\"` |\n| Keyboard | `Enter`/`Space` triggers action |\n\n---\n\n## 9. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Button** | Standard button with size options |\n| **Icon Button** | Compact button with icon only |\n| **FAB (Floating Action Button)** | Fixed-position circular action button |\n| **Split Button** | Primary action + dropdown for secondary actions |\n| **Button Group** | Row of related action buttons |\n\nAll implementations share the same slot tag contract.\n\n---\n\n## 10. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupTriggerAction/usage" {
    export const skill = "\n# trigger + action \u2014 Usage\n\n> Quick reference for using molecules in the **trigger + action** group.\n> Use this when the user needs to **execute an action or command**.\n> All implementations share the same slot tag contract.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Button text content |\n| `Icon` | Icon content (SVG, emoji, HTML) displayed alongside or instead of the label |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `size` | `string` | `'md'` | Button size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `type` | `string` | `'button'` | HTML button type: `'button'`, `'submit'`, `'reset'` |\n| `icon-position` | `string` | `'start'` | Icon placement: `'start'` or `'end'` |\n| `disabled` | `boolean` | `false` | Disables the button |\n| `loading` | `boolean` | `false` | Shows loading indicator, blocks interaction |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `action` | `{}` | Fired when the button is clicked |\n\n---\n\n## Examples\n\n### Primary button\n\n```html\n<molecules--button-102020\n  size=\"md\">\n  <Label>Save Changes</Label>\n</molecules--button-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewCard/creation" {
    export const skill = "\n# groupViewCard \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewCard** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewCard` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `CardHeader` | No | Top section of the card, typically contains title and description |\n| `CardTitle` | No | Main title text inside the header |\n| `CardDescription` | No | Secondary text inside the header |\n| `CardContent` | No | Main body area of the card |\n| `CardFooter` | No | Bottom section of the card |\n| `CardAction` | No | Actionable element (button, link) inside the card |\n\n```typescript\nslotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <CardHeader>\n\u2502   \u251C\u2500\u2500 <CardTitle>\n\u2502   \u2514\u2500\u2500 <CardDescription>\n\u251C\u2500\u2500 <CardContent>\n\u251C\u2500\u2500 <CardFooter>\n\u2514\u2500\u2500 <CardAction>\n```\n\n### Flexible Composition\n\nAll slots are optional. The card renders only the slots that are present:\n\n- Header only: quick info card\n- Content only: media card\n- Header + Content + Footer: full structured card\n- Any combination is valid\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `clickable` | `boolean` | `false` | `@propertyDataSource` | Entire card is clickable (adds hover effect and cursor pointer) |\n| `selected` | `boolean` | `false` | `@propertyDataSource` | Card is visually selected/highlighted |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Card is dimmed and non-interactive |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show skeleton placeholder instead of content |\n| `isEditing` | `boolean` | `false` | `@propertyDataSource` | Change all children web components, atribute is-editing  |\n\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a visual composition primitive. The page or organism that contains the card is responsible for data and state.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `cardClick` | `{}` | \u2713 | Fired when the card is clicked (only when `clickable=true`) |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('cardClick', {\n  bubbles: true,\n  composed: true,\n  detail: {}\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Hover** | Subtle hover effect (only when `clickable=true`) |\n| **Selected** | Highlighted border or background |\n| **Disabled** | Reduced opacity, no interaction |\n| **Loading** | Skeleton placeholder matching the card layout |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Clickable card | `role=\"button\"`, `tabindex=\"0\"` |\n| Keyboard | `Enter`/`Space` triggers `cardClick` when clickable |\n| Disabled | `aria-disabled=\"true\"` |\n| Selected | `aria-selected=\"true\"` |\n| Non-clickable | No role needed, renders as plain `<div>` |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewCard/usage" {
    export const skill = "\n\n# view + card \u2014 Usage\n\n> Quick reference for using molecules in the **view + card** group.\n> Use this when you need to **display an item as an independent visual unit**.\n> This is a composition primitive \u2014 the page or organism arranges cards in grids, lists, carousels, etc.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `CardHeader` | Top section, typically contains title and description |\n| `CardTitle` | Main title text inside the header |\n| `CardDescription` | Secondary text inside the header |\n| `CardContent` | Main body area |\n| `CardFooter` | Bottom section |\n| `CardAction` | Actionable element (button, link) |\n\nAll slots are optional. The card renders only what is present.\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `clickable` | `boolean` | `false` | Entire card is clickable |\n| `selected` | `boolean` | `false` | Card is visually highlighted |\n| `disabled` | `boolean` | `false` | Card is dimmed and non-interactive |\n| `loading` | `boolean` | `false` | Show skeleton placeholder instead of content |\n| `isEditing` | `boolean` | `false` | `@propertyDataSource` | Change all children web components, atribute is-editing  |\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `cardClick` | `{}` | Fired when the card is clicked (only when `clickable=true`) |\n\n---\n\n## Examples\n\n### Basic product card\n\n```html\n<molecules--card-102020>\n  <CardHeader>\n    <CardTitle>Wireless Headphones</CardTitle>\n    <CardDescription>Noise cancelling, 30h battery</CardDescription>\n  </CardHeader>\n  <CardContent>\n    <img src=\"headphones.jpg\" alt=\"Headphones\" />\n  </CardContent>\n  <CardFooter>$299.00</CardFooter>\n</molecules--card-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewChart/creation" {
    export const skill = "\n# groupViewChart \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewChart** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewChart` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Chart title displayed above the chart |\n| `Series` | No | Named data series. Attributes: `name` (required), `color`. Contains `<Point>` children |\n| `Point` | Yes | Single data point. Attributes: `label` (required), `value` (required), `color` |\n| `Empty` | No | Content shown when no data is provided |\n\n```typescript\nslotTags = ['Label', 'Series', 'Point', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Series name=\"...\" color=\"...\">\n\u2502   \u2514\u2500\u2500 <Point label=\"...\" value=\"...\" />\n\u251C\u2500\u2500 <Point label=\"...\" value=\"...\" color=\"...\" />\n\u2514\u2500\u2500 <Empty>\n```\n\n### Single Series vs Multi Series\n\n- **Multi series:** `<Point>` inside `<Series>`. Each series has its own `name` and `color`\n- **Single series:** `<Point>` directly in the root (no `<Series>` wrapper). Used for Pie, Donut, Funnel, and simple charts. Each Point can have its own `color`\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `showLegend` | `boolean` | `true` | `@propertyDataSource` | Display the legend |\n| `showValues` | `boolean` | `false` | `@propertyDataSource` | Display numeric values on data points |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state \u2014 show placeholder instead of chart |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a display-only component. Data comes entirely from slot tags.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `pointClick` | `{ label: string, value: number, series?: string }` | \u2713 | Fired when the user clicks a data point |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('pointClick', {\n  bubbles: true,\n  composed: true,\n  detail: { label: 'Jan', value: 1200, series: '2024' }\n}));\n```\n\n---\n\n## 6. Reading Data\n\n- **Multi series:** read `<Series>` elements, each containing nested `<Point>` elements. Series has `name` and `color` attributes. Points have `label` and `value`\n- **Standalone points:** read root-level `<Point>` elements (not inside a `<Series>`). Each has `label`, `value`, and optional `color`\n- Use `getSlots` from the base class to read slot tag elements from the template\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Chart rendered with data |\n| **Loading** | Placeholder or skeleton instead of chart |\n| **Empty** | No points provided \u2014 render empty state message |\n| **Hover** | Tooltip with point details on hover |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"img\"` with `aria-label` from Label slot content |\n| Data table | Provide a visually hidden `<table>` with the raw data as alternative |\n| Interactive points | `role=\"button\"`, `aria-label` with label + value |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Removed animate, width, height props; added Empty slot; removed implementation code |\n";
}
declare module "_102020_/l2/skills/molecules/groupViewChart/usage" {
    export const skill = "# view + chart \u2014 Usage\n\n> Quick reference for using molecules in the **view + chart** group.\n> Use this when the system needs to **display data through a chart**.\n> All chart implementations share the same slot tag contract \u2014 swap the tag to change the visualization.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Chart title displayed above the chart |\n| `Series` | Named data series. Attributes: `name` (required), `color`. Contains `<Point>` children |\n| `Point` | Single data point. Attributes: `label` (required), `value` (required), `color` |\n| `Empty` | Content shown when no data is provided |\n\n### When to use Series vs standalone Points\n\n- **Multi series** (Line, Bar, Area, Radar, Scatter): wrap `<Point>` inside `<Series>`\n- **Single series** (Pie, Donut, Funnel): put `<Point>` directly in the root, each with its own `color`\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `show-legend` | `boolean` | `true` | Display the legend |\n| `show-values` | `boolean` | `false` | Display numeric values on data points |\n| `loading` | `boolean` | `false` | Show loading placeholder instead of chart |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `pointClick` | `{ label: string, value: number, series?: string }` | Fired when the user clicks a data point |\n\n---\n\n## Examples\n\n### Bar chart \u2014 monthly revenue comparison\n\n```html\n<molecules--bar-chart-102020\n  show-values=\"true\">\n  <Label>Monthly Revenue</Label>\n  <Series name=\"2024\" color=\"#3b82f6\">\n    <Point label=\"Jan\" value=\"1200\" />\n    <Point label=\"Feb\" value=\"1800\" />\n    <Point label=\"Mar\" value=\"950\" />\n  </Series>\n  <Series name=\"2025\" color=\"#10b981\">\n    <Point label=\"Jan\" value=\"1500\" />\n    <Point label=\"Feb\" value=\"2100\" />\n    <Point label=\"Mar\" value=\"1300\" />\n  </Series>\n</molecules--bar-chart-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewData/creation" {
    export const skill = "# groupViewData \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewData** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewData` |\n| **Category** | Data Display |\n| **Version** | `1.1.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Columns` | \u2713 | Container for column definitions |\n| `Column` | \u2713 (min. 1) | Defines a column/field |\n| `Rows` | \u2713 | Container for data rows |\n| `Row` | \u2713 (min. 1) | A data row/item |\n| `Cell` | \u2713 | A data cell \u2014 accepts any content |\n| `Empty` | No | Displayed when there are no rows |\n| `Loading` | No | Displayed when `loading` is true |\n\n```typescript\nslotTags = ['Columns', 'Column', 'Rows', 'Row', 'Cell', 'Empty', 'Loading'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Columns>\n\u2502   \u2514\u2500\u2500 <Column>\n\u251C\u2500\u2500 <Rows>\n\u2502   \u2514\u2500\u2500 <Row>\n\u2502       \u2514\u2500\u2500 <Cell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parent |\n|-----|-------------|\n| `Columns` | root |\n| `Column` | `Columns` |\n| `Rows` | root |\n| `Row` | `Rows` |\n| `Cell` | `Row` |\n| `Empty` | root |\n| `Loading` | root |\n\n### Column attributes\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `field` | `string` | \u2713 | Field identifier |\n| `header` | `string` | \u2713 | Header/label text |\n| `width` | `string` | | Suggested width (e.g., `\"120px\"`, `\"20%\"`) |\n| `align` | `'left' | 'center' | 'right'` | | Content alignment |\n| `hidden` | `boolean` | | Hides the column |\n\n### Row attributes\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `selected` | `boolean` | | Marks row as selected |\n| `disabled` | `boolean` | | Disables row interaction |\n\n### Cell attributes\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n\n---\n\n## 3. Properties\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Shows loading state \u2014 renders `<Loading>` slot if present |\n| `selectable` | `boolean` | `false` | `@propertyDataSource` | Enables row/item selection |\n| `hoverable` | `boolean` | `true` | `@propertyDataSource` | Highlights row/item on hover |\n\n> Additional properties may be added by specific implementations (e.g., `striped`, `bordered` for table implementations).\n\n---\n\n## 4. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `row-click` | `{ index: number, data: Element }` | \u2713 | Fired when a row/item is clicked |\n| `selection-change` | `{ selected: number[] }` | \u2713 | Fired when the selection changes |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('row-click', {\n  bubbles: true,\n  composed: true,\n  detail: { index: rowIndex, data: rowElement }\n}));\n```\n\n---\n\n## 5. Validation Rules\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<Columns>` missing | error | `Missing required slot <Columns>` |\n| `<Rows>` missing | error | `Missing required slot <Rows>` |\n| No `<Column>` inside Columns | error | `At least 1 <Column> is required inside <Columns>` |\n| `<Column>` without `field` | error | `<Column> requires attribute \"field\"` |\n| `<Column>` without `header` | error | `<Column> requires attribute \"header\"` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n\n---\n\n## 6. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Default** | Normal row/item appearance |\n| **Hover** | Subtle highlight on row/item (when `hoverable=true`) |\n| **Selected** | Row/item visually marked as selected |\n| **Disabled** | Row/item at reduced opacity, no interaction |\n| **Loading** | Renders `<Loading>` slot content; hides rows |\n| **Empty** | Renders `<Empty>` slot content when no rows exist |\n\n---\n\n## 7. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Busy state | `aria-busy=\"true\"` when `loading` is true |\n| Selected rows | `aria-selected=\"true\"` on selected rows/items |\n| Disabled rows | `aria-disabled=\"true\"` on disabled rows/items |\n\n---\n\n## 8. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Data Table** | Traditional tabular layout with header row and data rows |\n| **Card Grid** | Each row rendered as a card in a responsive grid |\n| **List View** | Compact vertical list, one row per item |\n| **Responsive View** | Adapts between table and card based on viewport width |\n| **Compact Table** | Dense table for high-information-density contexts |\n| **Kanban Board** | Rows grouped by a status column into lanes |\n\nAll implementations share the same slot tag contract and events \u2014 they are fully interchangeable by swapping the component tag.\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-13 | Initial contract definition |\n| 1.1.0 | 2026-04-13 | Removed view-specific properties; focus on data structure only |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewData/usage" {
    export const skill = "\n# view + data \u2014 Usage\n\n> Quick reference for using molecules in the **view + data** group.\n> Use this when you need to display a collection of records with defined fields.\n> All implementations share the same slot tag contract \u2014 swap the component tag to change the visualization.\n\n---\n\n## Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Columns` | \u2713 | Container for column definitions |\n| `Column` | \u2713 (min. 1) | Defines a column \u2014 attributes: `field`, `header`, `width`, `align`, `hidden` |\n| `Rows` | \u2713 | Container for data rows |\n| `Row` | \u2713 (min. 1) | A data row \u2014 attributes: `selected`, `disabled` |\n| `Cell` | \u2713 | A data cell \u2014 accepts any content; attribute: `colspan` |\n| `Empty` | No | Content shown when there are no rows |\n| `Loading` | No | Content shown when `loading` is true |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `loading` | `boolean` | `false` | Shows loading state |\n| `selectable` | `boolean` | `false` | Enables row/item selection |\n| `hoverable` | `boolean` | `true` | Highlights row/item on hover |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `row-click` | `{ index: number, data: Element }` | Fired when a row/item is clicked |\n| `selection-change` | `{ selected: number[] }` | Fired when the selection changes |\n\n---\n\n## Examples\n\n### Simple data table\n\n```html\n<molecules--data-table-102020 .hoverable=${true}>\n  <Columns>\n    <Column field=\"name\" header=\"Name\" />\n    <Column field=\"email\" header=\"Email\" />\n    <Column field=\"status\" header=\"Status\" align=\"center\" width=\"120px\" />\n  </Columns>\n  <Rows>\n    <Row>\n      <Cell>Alice Souza</Cell>\n      <Cell>alice@example.com</Cell>\n      <Cell>Active</Cell>\n    </Row>\n    <Row>\n      <Cell>Bruno Lima</Cell>\n      <Cell>bruno@example.com</Cell>\n      <Cell>Inactive</Cell>\n    </Row>\n  </Rows>\n  <Empty>\n    <div class=\"text-center py-8 text-slate-500\">No records found</div>\n  </Empty>\n</molecules--data-table-102020>\n```\n\n### Selectable rows\n\n```html\n<molecules--data-table-102020\n  .selectable=${true}\n  @selection-change=${(e) => { this.selectedRows = e.detail.selected; }}>\n  <Columns>\n    <Column field=\"id\" header=\"ID\" width=\"80px\" />\n    <Column field=\"product\" header=\"Product\" />\n    <Column field=\"price\" header=\"Price\" align=\"right\" />\n  </Columns>\n  <Rows>\n    <Row>\n      <Cell>001</Cell>\n      <Cell>Widget Pro</Cell>\n      <Cell>R$ 199,00</Cell>\n    </Row>\n    <Row selected>\n      <Cell>002</Cell>\n      <Cell>Gadget Plus</Cell>\n      <Cell>R$ 349,00</Cell>\n    </Row>\n    <Row disabled>\n      <Cell>003</Cell>\n      <Cell>Legacy Item</Cell>\n      <Cell>R$ 59,00</Cell>\n    </Row>\n  </Rows>\n</molecules--data-table-102020>\n```\n\n### Rich cell content\n\n```html\n<molecules--data-table-102020>\n  <Columns>\n    <Column field=\"user\" header=\"User\" />\n    <Column field=\"role\" header=\"Role\" align=\"center\" />\n    <Column field=\"actions\" header=\"\" width=\"100px\" align=\"right\" />\n  </Columns>\n  <Rows>\n    <Row>\n      <Cell>\n        <div class=\"font-medium\">William Little</div>\n        <div class=\"text-sm text-slate-500\">william@email.com</div>\n      </Cell>\n      <Cell>\n        <span class=\"px-2 py-0.5 rounded-full text-xs bg-sky-100 text-sky-700\">Admin</span>\n      </Cell>\n      <Cell>\n        <div class=\"flex gap-2 justify-end\">\n          <button>Edit</button>\n          <button>Delete</button>\n        </div>\n      </Cell>\n    </Row>\n  </Rows>\n</molecules--data-table-102020>\n```\n\n### Loading state\n\n```html\n<molecules--data-table-102020 .loading=${true}>\n  <Columns>\n    <Column field=\"name\" header=\"Name\" />\n    <Column field=\"status\" header=\"Status\" />\n  </Columns>\n  <Rows></Rows>\n  <Loading>\n    <div class=\"text-center py-10 text-slate-400\">Loading records...</div>\n  </Loading>\n</molecules--data-table-102020>\n```\n\n### Card grid \u2014 same contract, different component\n\n```html\n<molecules--card-grid-102020 .hoverable=${true} @row-click=${this.onCardClick}>\n  <Columns>\n    <Column field=\"title\" header=\"Title\" />\n    <Column field=\"description\" header=\"Description\" />\n    <Column field=\"category\" header=\"Category\" />\n  </Columns>\n  <Rows>\n    <Row>\n      <Cell>Annual Report 2025</Cell>\n      <Cell>Summary of key financial metrics for the fiscal year</Cell>\n      <Cell>Finance</Cell>\n    </Row>\n    <Row>\n      <Cell>Q1 Marketing Plan</Cell>\n      <Cell>Campaign strategy and budget allocation for Q1</Cell>\n      <Cell>Marketing</Cell>\n    </Row>\n  </Rows>\n  <Empty>\n    <div class=\"text-center py-12 text-slate-400\">No items to display</div>\n  </Empty>\n</molecules--card-grid-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewHierarchy/creation" {
    export const skill = "\n\n# groupViewHierarchy \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewHierarchy** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewHierarchy` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Title displayed above the hierarchy |\n| `Node` | Yes | A hierarchy node. Can contain free content (text, icons, HTML, web components) and nested `<Node>` children |\n| `Empty` | No | Content shown when no nodes exist |\n\n```typescript\nslotTags = ['Label', 'Node', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Node>\n\u2502   \u251C\u2500\u2500 ...free content...\n\u2502   \u251C\u2500\u2500 <Node>\n\u2502   \u2502   \u251C\u2500\u2500 ...free content...\n\u2502   \u2502   \u2514\u2500\u2500 <Node>\n\u2502   \u2502       \u2514\u2500\u2500 ...free content...\n\u2502   \u2514\u2500\u2500 <Node>\n\u2502       \u2514\u2500\u2500 ...free content...\n\u251C\u2500\u2500 <Node>\n\u2502   \u2514\u2500\u2500 <Node>\n\u2514\u2500\u2500 <Empty>\n```\n\n### Node Attributes\n\n| Attribute | Type | Description |\n|-----------|------|-------------|\n| `value` | `string` (optional) | Identifier for the node, emitted on `nodeClick` |\n| `expanded` | `boolean` (presence) | Node starts expanded |\n| `disabled` | `boolean` (presence) | Node cannot be toggled or clicked |\n\n### Node Content\n\nThe direct content of a `<Node>` (excluding nested `<Node>` children) is the node's visual label. It can be free HTML:\n\n```html\n<Node>\n  <img src=\"icon.png\" /> Engineering Department\n  <Node>Frontend</Node>\n  <Node>Backend</Node>\n</Node>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `multiple` | `boolean` | `true` | `@propertyDataSource` | Allow multiple nodes open simultaneously. `false` = only one per level |\n| `expandAll` | `boolean` | `false` | `@propertyDataSource` | Start with all nodes expanded |\n\n### 3.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all expand/collapse interaction |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show loading placeholder |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. It is a display-only component with expand/collapse interaction.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `nodeClick` | `{ value: string | null }` | \u2713 | Fired when a node is clicked |\n| `toggle` | `{ value: string | null, expanded: boolean }` | \u2713 | Fired when a node is expanded or collapsed |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('nodeClick', {\n  bubbles: true,\n  composed: true,\n  detail: { value: 'frontend' }\n}));\n\nthis.dispatchEvent(new CustomEvent('toggle', {\n  bubbles: true,\n  composed: true,\n  detail: { value: 'eng', expanded: true }\n}));\n```\n\n---\n\n## 6. Expand/Collapse Behavior\n\n- Nodes that have nested `<Node>` children are expandable\n- Nodes without children (leaf nodes) have no toggle\n- Clicking a node's toggle area expands/collapses its children\n- When `multiple=false`: expanding a node at a given level collapses siblings at that same level\n- When `expandAll=true`: all nodes start expanded, overriding individual `expanded` attributes\n- When `disabled` (component or individual node): toggle is blocked\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Collapsed** | Only node content visible, children hidden |\n| **Expanded** | Node content + children visible, with indent |\n| **Leaf** | No toggle icon, no expand/collapse |\n| **Disabled (node)** | Individual node dimmed, cannot toggle |\n| **Disabled (component)** | All nodes dimmed, no interaction |\n| **Loading** | Placeholder instead of hierarchy |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"tree\"` |\n| Node with children | `role=\"treeitem\"`, `aria-expanded` |\n| Leaf node | `role=\"treeitem\"` (no `aria-expanded`) |\n| Children group | `role=\"group\"` |\n| Disabled | `aria-disabled=\"true\"` |\n| Keyboard | `ArrowDown`/`ArrowUp` navigate nodes; `ArrowRight` expands; `ArrowLeft` collapses; `Enter` toggles |\n\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Added value attribute on Node and nodeClick event |\n";
}
declare module "_102020_/l2/skills/molecules/groupViewHierarchy/usage" {
    export const skill = "\n# view + hierarchy \u2014 Usage\n\n> Quick reference for using molecules in the **view + hierarchy** group.\n> Use this when the user needs to **visualize hierarchical data structures**.\n> All implementations share the same slot tag contract.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Title displayed above the hierarchy |\n| `Node` | A hierarchy node. Free content (text, icons, HTML). Nest `<Node>` inside `<Node>` for children. Attributes: `expanded` (presence), `disabled` (presence) |\n| `Empty` | Content shown when no nodes exist |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `multiple` | `boolean` | `true` | Allow multiple nodes open at once. `false` = one per level |\n| `expand-all` | `boolean` | `false` | Start with all nodes expanded |\n| `disabled` | `boolean` | `false` | Disables all interaction |\n| `loading` | `boolean` | `false` | Shows loading placeholder |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `toggle` | `{ expanded: boolean }` | Fired when a node is expanded or collapsed |\n| `nodeClick` | `{ value: string | null }` | Fired when a node is clicked |\n---\n\n## Examples\n\n### Folder structure (tree view)\n\n```html\n<molecules--tree-view-102020>\n  <Label>Project Files</Label>\n  <Node>\n    \uD83D\uDCC1 src\n    <Node>\n      \uD83D\uDCC1 components\n      <Node>\uD83D\uDCC4 Header.tsx</Node>\n      <Node>\uD83D\uDCC4 Footer.tsx</Node>\n    </Node>\n    <Node>\n      \uD83D\uDCC1 pages\n      <Node>\uD83D\uDCC4 Home.tsx</Node>\n      <Node>\uD83D\uDCC4 About.tsx</Node>\n    </Node>\n  </Node>\n  <Node>\n    \uD83D\uDCC1 public\n    <Node>\uD83D\uDCC4 index.html</Node>\n  </Node>\n  <Node>\uD83D\uDCC4 package.json</Node>\n</molecules--tree-view-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewMetric/creation" {
    export const skill = "\n# groupViewMetric \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewMetric** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewMetric` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Metric name/title |\n| `Value` | Yes | The main metric value (text, formatted number, HTML) |\n| `Icon` | No | Icon displayed alongside the metric |\n| `Trend` | No | Trend indicator content (arrow, percentage, text). Attributes: `direction` (`'up'`, `'down'`, `'neutral'`) |\n| `Helper` | No | Supporting text below the metric (e.g. period, comparison) |\n\n```typescript\nslotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Icon>\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Value>\n\u251C\u2500\u2500 <Trend direction=\"up|down|neutral\">\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show skeleton placeholder instead of metric |\n\n---\n\n## 4. Value Contract\n\nThis component has **no `value` property**. The metric data is provided entirely via slot tags. The `<Value>` slot contains the main number/text to display.\n\nThis allows full flexibility \u2014 the page formats the number, adds currency symbols, percentages, etc. directly in the slot content.\n\n---\n\n## 5. Events\n\nThis component emits **no events**. It is purely visual.\n\n---\n\n## 6. Trend Attribute\n\nThe `<Trend>` slot tag has an optional `direction` attribute:\n\n| Direction | Meaning |\n|-----------|---------|\n| `up` | Positive trend \u2014 typically styled green |\n| `down` | Negative trend \u2014 typically styled red |\n| `neutral` | No change \u2014 typically styled grey |\n\nThe content inside `<Trend>` is free (arrow emoji, percentage text, SVG icon).\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Metric displayed with all available slots |\n| **Loading** | Skeleton placeholder matching the metric layout |\n\n---\n\n## 8. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"figure\"`, `aria-label` from Label slot content |\n| Value | `aria-live=\"polite\"` to announce updates |\n| Trend | `aria-label` describing the direction (e.g. \"Trend: up\") |\n\n---\n\n## 9. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewMetric/usage" {
    export const skill = "\n\n# groupviewMetric \u2014 Usage\n\n> Quick reference for using molecules in the **view + metric** group.\n> Use this when the user needs to **view a highlighted indicator or metric**.\n> Purely visual \u2014 all data provided via slot tags.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Metric name/title |\n| `Value` | The main metric value (formatted number, text, HTML) |\n| `Icon` | Icon displayed alongside the metric |\n| `Trend` | Trend indicator. Attribute: `direction` (`'up'`, `'down'`, `'neutral'`). Content = free (arrow, percentage, text) |\n| `Helper` | Supporting text below (period, comparison, context) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `loading` | `boolean` | `false` | Show skeleton placeholder instead of metric |\n\n---\n\n## Events\n\nNone. This component is purely visual.\n\n---\n\n## Examples\n\n### Big number \u2014 monthly revenue\n\n```html\n<molecules--big-number-102020>\n  <Label>Monthly Revenue</Label>\n  <Value>$127,450</Value>\n  <Trend direction=\"up\">\u2191 12.5%</Trend>\n  <Helper>vs last month</Helper>\n</molecules--big-number-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewTable/creation" {
    export const skill = "\n# groupViewTable \u2014 Creation\n\n> Implementation reference for creating molecules in the **groupViewTable** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `groupViewTable` |\n| **Category** | Data Display |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Caption` | No | Table caption/title |\n| `TableHeader` | Yes | Header section container |\n| `TableBody` | Yes | Body section container |\n| `TableRow` | Yes | A table row (used inside TableHeader, TableBody, TableFooter) |\n| `TableHead` | Yes | Header cell. Attributes: `key` (required, column identifier), `sortable` (presence) |\n| `TableCell` | Yes | Data cell. May contain text or web components |\n| `TableFooter` | No | Footer section container |\n| `Empty` | No | Content shown when TableBody has no rows |\n| `Loading` | No | Content shown during loading state |\n\n```typescript\nslotTags = ['Caption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell', 'TableFooter', 'Empty', 'Loading'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Caption>\n\u251C\u2500\u2500 <TableHeader>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableHead key=\"...\" sortable>\n\u251C\u2500\u2500 <TableBody>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableCell>\n\u251C\u2500\u2500 <TableFooter>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableCell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n### TableHead Attributes\n\n| Attribute | Type | Description |\n|-----------|------|-------------|\n| `key` | `string` | Column identifier, used for sorting |\n| `sortable` | `boolean` (presence) | Column can be sorted |\n\n---\n\n## 3. Properties\n\n### 3.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `selectable` | `boolean` | `false` | `@propertyDataSource` | Enable row selection with checkboxes |\n| `isEditing` | `boolean` | `false` | `@propertyDataSource` | Propagates `is-editing` attribute to all web components inside cells |\n| `page` | `number` | `1` | `@propertyDataSource` | Current page number (1-based) |\n| `pageSize` | `number` | `0` | `@propertyDataSource` | Rows per page (0 = no pagination, show all) |\n| `totalItems` | `number` | `0` | `@propertyDataSource` | Total number of items (for calculating total pages) |\n\n### 3.2 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string` | `''` | `@propertyDataSource` | Comma-separated selected row indices (e.g. `\"0,2,5\"`) when `selectable=true` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Disables all interaction |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Show Loading slot content or default skeleton |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `sortKey` | `string | null` | `null` | `@state` | Currently sorted column key |\n| `sortDirection` | `string` | `'asc'` | `@state` | Sort direction: `'asc'` or `'desc'` |\n\n---\n\n## 4. Value Contract\n\n- `value` is a **comma-separated string** of selected row indices when `selectable=true`\n- Empty string `''` means no rows selected\n- Example: `\"0,2,5\"` means rows at index 0, 2, and 5 are selected\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string }` | \u2713 | Selection changed (comma-separated row indices) |\n| `sort` | `{ key: string, direction: string }` | \u2713 | Column sort triggered |\n| `pageChange` | `{ page: number }` | \u2713 | Page navigation triggered |\n| `rowClick` | `{ index: number }` | \u2713 | Row clicked (not from checkbox selection) |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('sort', {\n  bubbles: true,\n  composed: true,\n  detail: { key: this.sortKey, direction: this.sortDirection }\n}));\n\nthis.dispatchEvent(new CustomEvent('pageChange', {\n  bubbles: true,\n  composed: true,\n  detail: { page: 2 }\n}));\n```\n\n---\n\n## 6. isEditing Propagation\n\nWhen `isEditing` changes, the table must propagate the `is-editing` attribute to all web components (custom elements) found inside `<TableCell>` elements. This ensures child components switch between view and edit mode automatically.\n\n- Propagate on first render and whenever `isEditing` changes\n- Only target custom elements (tags containing a hyphen)\n- Set `is-editing=\"true\"` or `is-editing=\"false\"`\n\n---\n\n## 7. Sorting\n\n- The component handles sorting internally by reordering `<TableRow>` elements inside `<TableBody>`\n- Clicking a sortable `<TableHead>` toggles between ascending and descending order\n- Sort is based on the text content of the cell at the matching column index\n- After sorting, emit `sort` event with `{ key, direction }`\n\n---\n\n## 8. Selection\n\nWhen `selectable=true`:\n\n- Each row renders a checkbox\n- A \"select all\" checkbox appears in the header\n- Clicking a row checkbox toggles that row index in `value`\n- Clicking \"select all\" toggles all row indices in `value`\n- After each change, emit `change` event with the updated comma-separated string\n\n---\n\n## 9. Pagination\n\nWhen `pageSize > 0`:\n\n- Calculate total pages: `Math.ceil(totalItems / pageSize)`\n- Render pagination controls below the table (prev, page numbers, next)\n- On page click: update `page`, emit `pageChange`\n- The page listens to `pageChange` and updates the `<TableBody>` content via BFF\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Table rendered with data |\n| **Loading** | Loading slot content or default skeleton rows |\n| **Empty** | Empty slot content or default message |\n| **Sorted** | Sort indicator on active column header |\n| **Selected** | Highlighted rows with checkboxes checked |\n| **Editing** | Child components inside cells in edit mode |\n| **Disabled** | All interaction blocked, dimmed |\n| **Error** | Error message below the table |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Table | `role=\"table\"` or native `<table>` |\n| Caption | `<caption>` or `aria-label` |\n| Header | `role=\"rowgroup\"` |\n| Header cells | `role=\"columnheader\"`, `aria-sort` when sortable |\n| Body | `role=\"rowgroup\"` |\n| Rows | `role=\"row\"` |\n| Cells | `role=\"cell\"` |\n| Select all | `aria-label=\"Select all rows\"` |\n| Row checkbox | `aria-label=\"Select row N\"` |\n| Pagination | `role=\"navigation\"`, `aria-label=\"Table pagination\"` |\n| Keyboard | `ArrowUp`/`ArrowDown` navigate rows; `Space` toggles selection; `Enter` on header sorts |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Removed implementation code; skill defines contract only |\n";
}
declare module "_102020_/l2/skills/molecules/groupViewTable/usage" {
    export const skill = "\n# view + table \u2014 Usage\n\n> Quick reference for using molecules in the **view + table** group.\n> Use this when the user needs to **visualize structured data in tabular format**.\n> All implementations share the same slot tag contract.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Caption` | Table caption/title |\n| `TableHeader` | Header section container |\n| `TableBody` | Body section container |\n| `TableRow` | A table row (inside TableHeader, TableBody, TableFooter) |\n| `TableHead` | Header cell. Attributes: `key` (required), `sortable` (presence) |\n| `TableCell` | Data cell. May contain text or web components |\n| `TableFooter` | Footer section container |\n| `Empty` | Content shown when no rows exist |\n| `Loading` | Content shown during loading state |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string` | `''` | Comma-separated selected row indices (e.g. `\"0,2,5\"`) when selectable |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `selectable` | `boolean` | `false` | Enable row selection with checkboxes |\n| `is-editing` | `boolean` | `false` | Propagates `is-editing` attribute to web components inside cells |\n| `page` | `number` | `1` | Current page number (1-based) |\n| `page-size` | `number` | `0` | Rows per page (0 = no pagination) |\n| `total-items` | `number` | `0` | Total number of items for pagination |\n| `disabled` | `boolean` | `false` | Disables all interaction |\n| `loading` | `boolean` | `false` | Shows loading state |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string }` | Selection changed (comma-separated row indices) |\n| `sort` | `{ key: string, direction: string }` | Column sort triggered |\n| `pageChange` | `{ page: number }` | Page navigation triggered |\n| `rowClick` | `{ index: number }` | Row clicked |\n\n---\n\n## Examples\n\n### Simple data table with sorting\n\n```html\n<molecules--data-table-102020>\n  <Caption>Order List</Caption>\n  <TableHeader>\n    <TableRow>\n      <TableHead key=\"id\" sortable>ID</TableHead>\n      <TableHead key=\"customer\" sortable>Customer</TableHead>\n      <TableHead key=\"total\" sortable>Total</TableHead>\n      <TableHead key=\"status\">Status</TableHead>\n    </TableRow>\n  </TableHeader>\n  <TableBody>\n    <TableRow>\n      <TableCell>#001</TableCell>\n      <TableCell>John Doe</TableCell>\n      <TableCell>$150.00</TableCell>\n      <TableCell>Completed</TableCell>\n    </TableRow>\n    <TableRow>\n      <TableCell>#002</TableCell>\n      <TableCell>Jane Smith</TableCell>\n      <TableCell>$89.50</TableCell>\n      <TableCell>Pending</TableCell>\n    </TableRow>\n  </TableBody>\n  <Empty>No orders found</Empty>\n</molecules--data-table-102020>\n```\n\n";
}
