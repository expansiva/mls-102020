/// <mls shortName="collabAuraLiveView" project="102020" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { DISTFOLDER } from './_102020_build';
import { getProjectConfig } from './_100554_libCommom';
import './_100554_collabNav4Menu';
/// **collab_i18n_start**
const message_pt = {
    newTab: 'Nova aba',
};
const message_en = {
    newTab: 'new Tab',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabAuraLiveView102020 = class CollabAuraLiveView102020 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-aura-live-view-102020{display:block}collab-aura-live-view-102020 .liveview-container{height:100%}collab-aura-live-view-102020 iframe.closed{display:none !important}collab-aura-live-view-102020 iframe{display:block;width:100%;height:100%;overflow:hidden}collab-aura-live-view-102020 .liveview-container.loading{pointer-events:none;opacity:.3;position:relative;height:100%}collab-aura-live-view-102020 .liveview-container.loading::after{content:'';position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);width:35px;aspect-ratio:1;background:no-repeat radial-gradient(circle closest-side, #000 90%, #0000) 0 0,no-repeat radial-gradient(circle closest-side, #000 90%, #0000) 0 100%,no-repeat radial-gradient(circle closest-side, #000 90%, #0000) 100% 100%;background-size:40% 40%;animation:l11 1s infinite linear}@keyframes l11{25%{background-position:100% 0,0 100%,100% 100%}50%{background-position:100% 0,0 0,100% 100%}75%{background-position:100% 0,0 0,0 100%}100%{background-position:100% 100%,0 0,0 100%}}`);
        this.msg = messages['en'];
        this.mode = 'develpoment';
        this.actualTab = 0;
        this.tabsMenu = [];
        this.lastInit = 0;
        this.tabs = [];
        this.liveViewReady = false;
        this.APP_ID = 'app';
    }
    get iframe() {
        return this.querySelector(`iframe[tab-index="${this.actualTab}"]`);
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.setEvents();
    }
    connectedCallback() {
        super.connectedCallback();
        this.setEvents();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
			<div class="liveview-container" key=${this.lastInit}>
                <collab-nav4-menu-100554
                    mode="full"
                    .selectedIndex=${this.actualTab} 
                    .options=${this.tabsMenu}
                    @tab-selected=${this.onTabSelected}
                    @tab-closed=${this.onTabClosed}
                    ></collab-nav4-menu-100554>
                ${repeat(this.tabs, ((tab, index) => index), // chave única (pode usar um ID se tiver)
        ((tab, index) => html `
				<iframe
					tab-index=${index}
					style="width:100%; height:calc(100% - 47px); border:none; display:none;"
					class="${this.actualTab === index ? '' : 'closed'}"
					src="/_100554_servicePreview"
					@load=${this.load}>
				</iframe>
			`))}
                
			</div>
    `;
    }
    async init(project, shortName, folder) {
        this.tabs = [...[]];
        this.lastInit = Date.now();
        await this.updateComplete;
        await this.setInitialTabInfos(project, shortName, folder);
    }
    setEvents() {
        window.top?.addEventListener('message', async (event) => {
            const { type, target, project, moduleName, pageName, modulePath } = event.data;
            if (type !== 'loadPage')
                return;
            if (!this.liveViewReady)
                return;
            try {
                this.checkToLoadPage(pageName, moduleName, modulePath, project, target);
            }
            catch (err) {
                console.error('Erro ao carregar página no LiveView:', err);
            }
        });
    }
    onTabSelected(e) {
        const tabIndex = e.detail?.index;
        this.actualTab = tabIndex;
    }
    onTabClosed(e) {
        const tabIndex = e.detail?.index;
        this.closeTab(tabIndex);
    }
    async checkToLoadPage(pageName, moduleName, modulePath, project, target) {
        let tabActual = this.tabs[this.actualTab];
        const _target = !target ? moduleName : target;
        if (!_target) {
            tabActual = this.tabs[0];
            this.actualTab = 0;
            await this.openTab();
        }
        const oldProject = tabActual.project;
        if (tabActual.project !== project || tabActual.moduleName !== moduleName) {
            this.toogleLoading(true);
            // await buildModule(project, moduleName);
            await this.setActualTabInfos(project, pageName, modulePath, moduleName, _target);
        }
        else if (_target !== '') {
            await this.setActualTabInfos(project, pageName, modulePath, moduleName, _target);
        }
        if (oldProject !== project) {
            await this.injectGlobalStyle(true);
            await this.injectScriptRunTime(true);
        }
        this.toogleLoading(false);
        this.loadPage(pageName);
    }
    async setInitialTabInfos(project, pageInitial, modulePath) {
        const moduleProject = await getProjectConfig(project);
        if (!moduleProject)
            return;
        const moduleConfig = moduleProject.modules.find((item) => item.path === modulePath);
        if (!moduleConfig)
            return;
        this.tabs = [{
                actualPage: '',
                moduleName: moduleConfig.name,
                modulePath: moduleConfig.path,
                pageInitial,
                project: project,
                icon: moduleConfig.icon,
                target: moduleConfig.name
            }];
        this.tabsMenu = [
            { text: this.tabs[0].moduleName, icon: this.tabs[0].icon, allowClose: false }
        ];
        this.tabs = [...this.tabs];
        this.tabsMenu = [...this.tabsMenu];
        await this.requestUpdate();
    }
    async setActualTabInfos(project, pageInitial, modulePath, moduleName, target) {
        const _target = !target ? moduleName : target;
        if (_target !== '') {
            const tabIndex = this.tabs.findIndex((tab) => tab.target === _target);
            if (tabIndex > -1) {
                this.actualTab = tabIndex;
                await this.openTab();
            }
            else
                this.addTab(pageInitial, '', moduleName, modulePath, project, _target);
        }
        const tabActual = this.tabs[this.actualTab];
        const moduleProject = await getProjectConfig(project);
        if (!moduleProject)
            return;
        const moduleConfig = moduleProject.modules.find((item) => item.path === modulePath);
        if (!moduleConfig)
            return;
        tabActual.actualPage = pageInitial;
        tabActual.project = project;
        tabActual.moduleName = moduleConfig.name;
        tabActual.modulePath = modulePath;
        tabActual.icon = moduleConfig.icon;
        tabActual.pageInitial = pageInitial;
        this.tabs = [...this.tabs];
        this.tabsMenu[this.actualTab].icon = tabActual.icon;
        this.tabsMenu = [...this.tabsMenu];
        await this.requestUpdate();
    }
    async openTab() {
        this.tabs = [...this.tabs];
        await this.requestUpdate();
    }
    async closeTab(index) {
        if (!this.tabs[index])
            return;
        this.tabs.splice(index, 1);
        this.tabs = [...this.tabs];
        this.actualTab = index - 1;
        await this.requestUpdate();
    }
    async addTab(actualPage, icon, moduleName, modulePath, project, target) {
        const defaultTab = {
            actualPage,
            icon,
            moduleName,
            modulePath,
            pageInitial: actualPage,
            project,
            target: target || moduleName
        };
        this.tabs.push({ ...defaultTab });
        this.tabsMenu.push({ text: defaultTab.target, icon: defaultTab.icon, allowClose: true });
        this.actualTab = this.tabs.length - 1;
        this.tabs = [...this.tabs];
        this.tabsMenu = [...this.tabsMenu];
        await this.requestUpdate();
    }
    async load() {
        const tabActual = this.tabs[this.actualTab];
        if (!this.iframe)
            return;
        const doc = this.iframe?.contentDocument;
        if (!doc)
            return;
        const head = doc.querySelector('head') || doc.createElement('head');
        if (!head.parentElement)
            doc.documentElement.appendChild(head);
        const base = doc.createElement('base');
        base.href = document.baseURI;
        head.appendChild(base);
        let body = doc.querySelector('body');
        if (!body) {
            body = doc.createElement('body');
            doc.documentElement.appendChild(body);
        }
        if (!doc.getElementById('app')) {
            const app = doc.createElement('div');
            app.id = 'app';
            body.appendChild(app);
        }
        const pre = doc.body.querySelector('pre');
        if (pre)
            pre.remove();
        const meta = this.iframe.contentDocument?.querySelector('meta[name="color-scheme"]');
        if (meta)
            meta.remove();
        this.addScript();
        this.addStyleApp();
        this.iframe.style.display = '';
        try {
            this.toogleLoading(true);
            // const needBuild = await buildModule(tabActual.project, tabActual.moduleName);
            await this.injectGlobalStyle();
            await this.injectScriptRunTime();
            this.liveViewReady = true;
            if (!tabActual.actualPage && tabActual.pageInitial) {
                this.loadPage(tabActual.pageInitial);
            }
        }
        catch (err) {
            console.info(err);
            // this.setError(err.message);
        }
        finally {
            this.toogleLoading(false);
        }
    }
    toogleLoading(show) {
        const divApp = this.container;
        if (!divApp)
            return;
        if (show)
            divApp.classList.add('loading');
        else
            divApp.classList.remove('loading');
    }
    async loadPage(pageName) {
        if (!this.iframe?.contentWindow) {
            console.warn('[LiveView] iframe ainda não disponível.');
            return;
        }
        if (this.mode === 'develpoment') {
            this.loadInDevelopment(pageName);
        }
        if (this.mode === 'production') {
            this.loadInProduction(pageName);
        }
    }
    async loadInProduction(pageName) {
        const tabActual = this.tabs[this.actualTab];
        try {
            this.toogleLoading(true);
            const htmlUrl = `/ ${tabActual.modulePath} /${pageName}.html`;
            const jsUrl = `/${tabActual.modulePath}/${pageName}.js`;
            this.clearOldPageScripts();
            await Promise.all([
                this.injectHTML(htmlUrl),
                this.injectJS(jsUrl)
            ]);
            if (this.iframe) {
                this.iframe.style.display = '';
            }
            this.toogleLoading(false);
        }
        catch (err) {
            // this.setError(err.message);
            console.info(err);
            this.toogleLoading(false);
        }
    }
    async loadInDevelopment(pageName) {
        const tabActual = this.tabs[this.actualTab];
        const folder = DISTFOLDER + '/' + tabActual.modulePath;
        const keyStorFileHTML = mls.stor.getKeyToFiles(tabActual.project, 2, pageName, folder, '.html');
        const keyStorFileJs = mls.stor.getKeyToFiles(tabActual.project, 2, pageName, folder, '.js');
        const storFileHTML = mls.stor.files[keyStorFileHTML];
        const storFileJs = mls.stor.files[keyStorFileJs];
        const versionHtml = storFileHTML?.versionRef || '0';
        const versionJs = storFileJs?.versionRef || '0';
        try {
            this.toogleLoading(true);
            await mls.stor.cache.clearObsoleteCache();
            const cacheJs = await mls.stor.cache.getFileFromCache(tabActual.project, folder, pageName, '.js', versionJs);
            const cacheHtml = await mls.stor.cache.getFileFromCache(tabActual.project, folder, pageName, '.html', versionHtml);
            if (!cacheHtml) {
                const contentHtml = await storFileHTML.getContent();
                if (contentHtml && typeof contentHtml === 'string') {
                    await mls.stor.cache.addIfNeed({
                        project: tabActual.project,
                        folder: folder,
                        content: contentHtml,
                        extension: '.html',
                        shortName: pageName,
                        version: versionHtml,
                        contentType: 'text/plain'
                    });
                }
            }
            if (!cacheJs) {
                const contentJs = await storFileJs.getContent();
                if (contentJs && typeof contentJs === 'string') {
                    await mls.stor.cache.addIfNeed({
                        project: tabActual.project,
                        folder: folder,
                        content: contentJs,
                        extension: '.js',
                        shortName: pageName,
                        version: versionJs,
                        contentType: 'application/javascript'
                    });
                }
            }
            const htmlUrl = `/local/_${tabActual.project}_wwwroot/${tabActual.modulePath}/${pageName}.html?v=${versionHtml}`;
            const jsUrl = `/local/_${tabActual.project}_wwwroot/${tabActual.modulePath}/${pageName}.js?v=${versionJs}`;
            this.clearOldPageScripts();
            await Promise.all([
                this.injectHTML(htmlUrl),
                this.injectJS(jsUrl)
            ]);
            if (this.iframe) {
                this.iframe.style.display = '';
            }
            this.toogleLoading(false);
        }
        catch (err) {
            // this.setError(err.message);
            console.info(err);
            this.toogleLoading(false);
        }
    }
    clearOldPageScripts() {
        if (!this.iframe || !this.iframe.contentDocument || !this.iframe.contentDocument.body)
            return;
        const oldScript = this.iframe.contentDocument.body.querySelector('#liveview-page-script');
        if (oldScript)
            oldScript.remove();
    }
    async injectHTML(htmlUrl) {
        if (!this.iframe || !this.iframe.contentDocument)
            return;
        const html = await fetch(htmlUrl).then(res => res.text());
        const app = this.iframe.contentDocument.getElementById(this.APP_ID);
        if (app)
            app.innerHTML = html;
    }
    async injectJS(jsUrl) {
        if (!this.iframe || !this.iframe.contentDocument)
            return;
        const script = this.iframe.contentDocument.createElement('script');
        script.type = 'module';
        script.src = jsUrl;
        script.id = 'liveview-page-script';
        this.iframe.contentDocument.body.appendChild(script);
    }
    async injectScriptRunTime(forceRecompile = false) {
        if (!this.iframe || !this.iframe.contentDocument)
            return;
        const tabActual = this.tabs[this.actualTab];
        const doc = this.iframe.contentDocument;
        const body = doc.body;
        const url = `/local/_${tabActual.project}_wwwroot/collabRunTime`;
        let scriptRunTime = doc.getElementById('collab-runtime-script');
        if (forceRecompile && scriptRunTime) {
            scriptRunTime.remove();
            scriptRunTime = null;
        }
        if (!scriptRunTime) {
            const script = doc.createElement('script');
            script.id = 'collab-runtime-script';
            script.src = `${url}`;
            script.type = 'module';
            script.defer = true;
            body.appendChild(script);
            await new Promise((resolve, reject) => {
                script.onload = () => resolve(true);
                script.onerror = (e) => reject(e);
            });
        }
    }
    async injectGlobalStyle(forceRecompile = false) {
        if (!this.iframe || !this.iframe.contentDocument)
            return;
        const tabActual = this.tabs[this.actualTab];
        const shortName = 'globalStyle';
        const keyStorFile = mls.stor.getKeyToFiles(tabActual.project, 2, shortName, DISTFOLDER, '.css');
        const storFile = mls.stor.files[keyStorFile];
        const version = storFile?.versionRef || '0';
        const url = `/local/_${tabActual.project}_wwwroot/${shortName}.css?v=${version}`;
        const res = await fetch(url);
        const cssText = await res.text();
        let styleGlobalEl = this.iframe.contentDocument.getElementById('styleGlobal');
        if (forceRecompile && styleGlobalEl) {
            styleGlobalEl.remove();
            styleGlobalEl = null;
        }
        if (!styleGlobalEl) {
            const styleG = document.createElement('style');
            styleG.id = 'styleGlobal';
            styleG.textContent = cssText;
            this.iframe.contentDocument.head.appendChild(styleG);
        }
    }
    functionReplaceAnchor(e) {
        e.stopPropagation();
        e.preventDefault();
        let anchor = e.target;
        if (!anchor.getAttribute('href')) {
            anchor = e.target.closest('a');
        }
        const href = anchor.href;
        let pageName = href ? href.replace(window.location.href, '') : '';
        this.loadPage(pageName);
    }
    addStyleApp() {
        const style = document.createElement('style');
        style.id = 'iframe-style';
        style.textContent = `
        html, body {
            height: 100%;
        }`;
        this.iframe?.contentDocument?.head.appendChild(style);
    }
    addScript() {
        if (!this.iframe || !this.iframe.contentDocument || !this.iframe.contentWindow)
            return;
        const s = document.createElement('script');
        s.textContent = `
        document.addEventListener('click', (e) => {
            const a = e.target.closest('a');
            if (a) {
                functionReplaceAnchor(e);
            }
        });`;
        this.iframe.contentDocument.body?.appendChild(s);
        this.iframe.contentWindow.functionReplaceAnchor = this.functionReplaceAnchor.bind(this);
    }
};
__decorate([
    property()
], CollabAuraLiveView102020.prototype, "mode", void 0);
__decorate([
    state()
], CollabAuraLiveView102020.prototype, "actualTab", void 0);
__decorate([
    state()
], CollabAuraLiveView102020.prototype, "tabsMenu", void 0);
__decorate([
    state()
], CollabAuraLiveView102020.prototype, "lastInit", void 0);
__decorate([
    query('.liveview-container')
], CollabAuraLiveView102020.prototype, "container", void 0);
CollabAuraLiveView102020 = __decorate([
    customElement('collab-aura-live-view-102020')
], CollabAuraLiveView102020);
export { CollabAuraLiveView102020 };
