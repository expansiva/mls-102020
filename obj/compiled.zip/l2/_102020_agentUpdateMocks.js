/// <mls shortName="agentUpdateMocks" project="102020" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { createAllModels } from './_100554_collabLibModel';
import { collabImport } from './_100554_collabImport';
import { appendLongTermMemory, getNextPendingStepByAgentName, getNextInProgressStepByAgentName, getNextFlexiblePendingStep, updateTaskTitle, notifyTaskChange, updateStepStatus, getNextPendentStep } from "./_100554_aiAgentHelper";
import { startNewInteractionInAiTask, startNewAiTask, executeNextStep, addNewStep } from "./_100554_aiAgentOrchestration";
const agentName = "agentUpdateMocks";
const projectAgent = 102020;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Prototype-level organism update agent to mockup organism.",
        visibility: "public",
        scope: [],
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
    };
}
const _beforePrompt = async (context) => {
    if (!context || !context.message)
        throw new Error(`[${agentName}](_beforePrompt) Invalid context`);
    const data = getParamsFromPrompt(context);
    if (!context.task) {
        await initTask(data, context);
        return;
    }
    await continueTask(context);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    context = await updateFile(context);
    notifyTaskChange(context);
    if (!context.task)
        throw new Error("Invalid context task");
    const organismRemaing = JSON.parse(context.task?.iaCompressed?.longMemory['actions_remaing'] || '[]');
    if (!organismRemaing || organismRemaing.length === 0) {
        context.task = await updateTaskTitle(context.task, "Ok, all actions executed created, see result");
        await executeNextStep(context);
        return;
    }
    const stepPendent = getNextPendentStep(context.task);
    if (!stepPendent)
        throw new Error(`[${agentName}](afterPrompt) Invalid next stepPendent`);
    const newStep = {
        agentName: 'agentUpdateMocks',
        prompt: '',
        status: 'pending',
        stepId: stepPendent.stepId + 1,
        interaction: null,
        nextSteps: null,
        rags: null,
        type: 'agent'
    };
    await addNewStep(context, stepPendent.stepId, [newStep]);
};
async function getPrompts(context, action, moduleProject, modulePath) {
    const iPath = mls.l2.getPath(`_${moduleProject}_${modulePath}/${action.pageOrOrganismName}`);
    const organismData = await getOrganismsContents(iPath);
    const moduleDefs = await getModuleDefs(context, moduleProject, modulePath);
    const dataForReplace = {
        typescript: organismData.ts,
        moduleEndPoints: moduleDefs,
        action: JSON.stringify(action)
    };
    console.info({ dataForReplace, iPath });
    const prompts = await getPromptByHtml({ project: projectAgent, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
async function getOrganismsContents(file) {
    const contentTs = await getContentByExtension(file, 'ts');
    const contentDefs = await getContentByExtension(file, 'defs');
    return {
        ts: typeof contentTs === 'string' ? contentTs : '',
        defs: typeof contentDefs === 'string' ? contentDefs : '',
    };
}
async function getModuleDefs(context, moduleProject, modulePath) {
    if (!moduleProject || !modulePath)
        throw new Error(`[${agentName}] getModuleDefs: Invalid module file.`);
    const content = await getContentByExtension({ folder: modulePath, project: +moduleProject, shortName: 'module' }, 'defs');
    if (typeof content !== 'string')
        throw new Error(`[${agentName}] getModuleDefs: Invalid typeof module file, must be string.`);
    return content;
}
async function continueTask(context) {
    if (!context.task)
        throw new Error(`[${agentName}](continueTask) No task found for this agent.`);
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}](beforePrompt) No pending step found for this agent.`);
    const actionsRemaing = JSON.parse(context.task?.iaCompressed?.longMemory['actions_remaing'] || '[]');
    const project = context.task?.iaCompressed?.longMemory['project'];
    const modulePath = context.task?.iaCompressed?.longMemory['module_path'];
    const actualAction = actionsRemaing?.pop();
    if (!actualAction)
        return;
    await appendLongTermMemory(context, { "actions_remaing": JSON.stringify(actionsRemaing), "file_name": actualAction.pageOrOrganismName });
    const inputs = await getPrompts(context, actualAction, project, modulePath);
    const taskTitle = `Executing actions`;
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
}
async function initTask(data, context) {
    try {
        const allActions = await getAllActions(+data.project, data.modulePath);
        if (!allActions || allActions.length === 0) {
            return;
        }
        const actualAction = allActions?.pop();
        if (!actualAction)
            return;
        const inputs = await getPrompts(context, actualAction, data.project, data.modulePath);
        const title = `Executing actions`;
        await startNewAiTask(agentName, title, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt, {
            'module_path': `${data.modulePath}`,
            'project': `${data.project}`,
            "file_name": actualAction.pageOrOrganismName,
            'actions_remaing': `${JSON.stringify(allActions)}`
        }).catch((err) => {
            throw new Error(err.message);
        });
    }
    catch (err) {
        throw new Error(err.message);
    }
}
function getParamsFromPrompt(context) {
    let messageReplace = context.message.content
        .replace(`@@ ${agentName}`, '')
        .replace(`@@${agentName}`, '').trim()
        .replace(`@@UpdateMocks`, '');
    let data;
    data = mls.common.safeParseArgs(messageReplace);
    if (!('modulePath' in data) || !('project' in data))
        throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure missing modulePath or project`);
    return data;
}
async function getContentByExtension(info, modelType) {
    try {
        let models = getModel(info);
        if (!models) {
            const keyToStorFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.ts');
            const stotFile = mls.stor.files[keyToStorFile];
            if (!stotFile)
                throw new Error(`[${agentName}][getContentByExtension]: Invalid storFile`);
            models = await createAllModels(stotFile);
        }
        if (!models)
            throw new Error(`[${agentName}][getContentByExtension]:Not found models for file:` + info.shortName);
        if (!models[modelType])
            return '';
        return models[modelType]?.model.getValue();
    }
    catch (e) {
        throw new Error(`[${agentName}][getContentByExtension]: ${e.message}`);
    }
}
function getModel(info) {
    const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
    return mls.editor.models[key];
}
async function updateFile(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] updateFile: Not found context`);
    const step = getNextFlexiblePendingStep(context.task);
    if (!step || step.type !== 'flexible')
        throw new Error(`[${agentName}] updateFile: Invalid step in updateFile`);
    const result = step.result;
    if (!result)
        throw new Error(`[${agentName}] updateFile: Not found "result"`);
    console.info(result.logs);
    console.info(result.moduleEndPoints);
    console.info(result.typescript);
    if (context.modeSingleStep) {
        return context;
    }
    const projectMemory = context.task?.iaCompressed?.longMemory['project'];
    const folderMemory = context.task?.iaCompressed?.longMemory['module_path'];
    const fileNameMemory = context.task?.iaCompressed?.longMemory['file_name'];
    if (!folderMemory || !projectMemory || !fileNameMemory)
        throw new Error(`[${agentName}] updateFile: Invalid task memory arguments`);
    const models = getModel({ folder: folderMemory || '', project: +projectMemory, shortName: 'module' });
    if (!models || !models.defs)
        throw new Error(`[${agentName}] updateFile: Not found models`);
    models.defs.model?.setValue(result.moduleEndPoints);
    const modelsTs = getModel({ folder: folderMemory || '', project: +projectMemory, shortName: fileNameMemory });
    if (!modelsTs || !modelsTs.ts)
        throw new Error(`[${agentName}] updateFile: Not found models typescript`);
    modelsTs.ts.model?.setValue(result.typescript);
    return context;
}
async function getAllActions(project, modulePath) {
    const moduleDefs = await collabImport({ folder: modulePath, project, shortName: 'module', extension: '.defs.ts' });
    if (!moduleDefs || !moduleDefs.temporaryEndpoints)
        throw new Error(`[${agentName}] getAllActions: Not found module endpoints`);
    const temporaryEndpoints = moduleDefs.temporaryEndpoints;
    const allActions = temporaryEndpoints.map((endPoint) => {
        return endPoint.actions.map((action) => {
            const refEndPoint = endPoint.endpoints.find((end) => end.name === action.endPoint);
            const rc = {
                ...action,
                refEndPoint
            };
            return rc;
        });
    }).flat();
    //const rc = allActions.filter((item) => item.pageOrOrganismName === 'loyaltyDashboard');
    return allActions;
}
