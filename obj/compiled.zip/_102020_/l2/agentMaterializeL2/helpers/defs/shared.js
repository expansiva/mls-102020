/// <mls fileReference="_102020_/l2/agentMaterializeL2/helpers/defs/shared.ts" enhancement="_blank"/>
export function parseL2Shared(source) {
    const match = /^\/\/\/ <mls fileReference="_(\d+)_\/l2\/([a-z][A-Za-z0-9]*)\/web\/shared\/([a-z][A-Za-z0-9_]*)\.defs\.ts" enhancement="_blank"\/>\r?\n\r?\nexport const definition = ([\s\S]+) as const;\r?\n?$/u.exec(source);
    if (!match)
        throw new Error('L2_SHARED_SOURCE_SHAPE');
    let parsed;
    try {
        parsed = JSON.parse(match[4]);
    }
    catch {
        throw new Error('L2_SHARED_SOURCE_JSON');
    }
    return { location: { project: Number(match[1]), module: match[2], pageId: match[3] }, definition: buildL2Shared(parsed) };
}
export function buildL2Shared(value) {
    const root = exact(value, ['entry', 'forms', 'requests', 'states', 'functions', 'journeys', 'rules', 'access'], 'L2_SHARED_KEYS');
    const params = {};
    for (const [id, raw] of Object.entries(object(exact(root.entry, ['params'], 'L2_SHARED_ENTRY').params, 'L2_SHARED_PARAMS'))) {
        const row = exact(raw, ['type', 'sources', 'effect', 'persist'], `L2_SHARED_PARAM: ${id}`);
        if (typeof row.type !== 'string' || typeof row.effect !== 'string' || typeof row.persist !== 'boolean')
            throw new Error(`L2_SHARED_PARAM: ${id}`);
        if (!Array.isArray(row.sources) || !row.sources.every(item => item === 'url' || item === 'localStorage'))
            throw new Error(`L2_SHARED_PARAM_SOURCES: ${id}`);
        params[id] = { type: row.type, sources: row.sources, effect: row.effect, persist: row.persist };
    }
    const forms = {};
    for (const [id, raw] of Object.entries(object(root.forms, 'L2_SHARED_FORMS'))) {
        const row = exact(raw, ['organism', 'submit'], `L2_SHARED_FORM: ${id}`);
        if (typeof row.organism !== 'string' || typeof row.submit !== 'string')
            throw new Error(`L2_SHARED_FORM: ${id}`);
        forms[id] = { organism: row.organism, submit: row.submit };
    }
    const requests = {};
    for (const [id, raw] of Object.entries(object(root.requests, 'L2_SHARED_REQUESTS'))) {
        const row = object(raw, `L2_SHARED_REQUEST: ${id}`);
        if (row.kind !== 'qry' && row.kind !== 'cmd')
            throw new Error(`L2_SHARED_REQUEST_KIND: ${id}`);
        if (typeof row.trigger !== 'string' || !Array.isArray(row.returns) || !row.returns.every(item => typeof item === 'string'))
            throw new Error(`L2_SHARED_REQUEST: ${id}`);
        requests[id] = { kind: row.kind, trigger: row.trigger, returns: row.returns, ...(typeof row.writes === 'string' ? { writes: row.writes } : {}) };
    }
    const states = {};
    for (const [id, raw] of Object.entries(object(root.states, 'L2_SHARED_STATES'))) {
        // `organisms` (the organisms the state feeds) is required by agentDefsL2 since d2_80 (05/10/2026); defs
        // rendered before that have no such field, so it is optional here.
        const row = exact(raw, ['source', 'description'], `L2_SHARED_STATE: ${id}`, ['organisms']);
        if (typeof row.source !== 'string' || typeof row.description !== 'string')
            throw new Error(`L2_SHARED_STATE: ${id}`);
        if ('organisms' in row && (!Array.isArray(row.organisms) || !row.organisms.every(item => typeof item === 'string')))
            throw new Error(`L2_SHARED_STATE_ORGANISMS: ${id}`);
        states[id] = { source: row.source, description: row.description, ...(Array.isArray(row.organisms) ? { organisms: row.organisms } : {}) };
    }
    const functions = {};
    for (const [id, raw] of Object.entries(object(root.functions, 'L2_SHARED_FUNCTIONS'))) {
        const row = object(raw, `L2_SHARED_FUNCTION: ${id}`);
        if (typeof row.description !== 'string')
            throw new Error(`L2_SHARED_FUNCTION: ${id}`);
        functions[id] = {
            description: row.description,
            ...(typeof row.calls === 'string' ? { calls: row.calls } : {}),
            ...(typeof row.sets === 'string' ? { sets: row.sets } : {}),
            ...(Array.isArray(row.updates) ? { updates: row.updates.map(String) } : {}),
            ...(typeof row.navigate === 'string' ? { navigate: row.navigate } : {}),
            ...(row.carries && typeof row.carries === 'object' && !Array.isArray(row.carries) ? { carries: row.carries } : {}),
        };
    }
    if (!Array.isArray(root.journeys))
        throw new Error('L2_SHARED_JOURNEYS');
    const journeys = root.journeys.map((raw, index) => {
        const row = object(raw, `L2_SHARED_JOURNEY: ${index}`);
        if (typeof row.step !== 'string' || !Array.isArray(row.organisms) || !Array.isArray(row.functions))
            throw new Error(`L2_SHARED_JOURNEY: ${index}`);
        return { step: row.step, organisms: row.organisms.map(String), functions: row.functions.map(String), ...(typeof row.continuesIn === 'string' ? { continuesIn: row.continuesIn } : {}) };
    });
    const rules = {};
    for (const [id, raw] of Object.entries(object(root.rules, 'L2_SHARED_RULES'))) {
        if (!Array.isArray(raw) || !raw.every(item => typeof item === 'string'))
            throw new Error(`L2_SHARED_RULES: ${id}`);
        rules[id] = raw;
    }
    const access = exact(root.access, ['actors', 'grants'], 'L2_SHARED_ACCESS');
    if (!Array.isArray(access.actors) || !Array.isArray(access.grants))
        throw new Error('L2_SHARED_ACCESS');
    return { entry: { params }, forms, requests, states, functions, journeys, rules, access: { actors: access.actors.map(String), grants: access.grants.map(String) } };
}
export function classifyL2StateSource(stateId, source, definition) {
    if (source.startsWith('entry.params.')) {
        const param = source.slice('entry.params.'.length);
        return param && !param.includes('.') && definition.entry.params[param] ? { kind: 'entryParam', param } : { kind: 'invalid' };
    }
    const dot = source.indexOf('.');
    if (dot > 0) {
        const request = source.slice(0, dot);
        const tail = source.slice(dot + 1);
        const row = definition.requests[request];
        if (!row || !tail || tail.includes('.'))
            return { kind: 'invalid' };
        if (tail === 'input')
            return row.kind === 'cmd' ? { kind: 'requestInput', request } : { kind: 'invalid' };
        return row.returns.includes(tail) ? { kind: 'requestReturn', request, key: tail } : { kind: 'invalid' };
    }
    if (definition.states[source])
        return { kind: 'state', state: source };
    if (definition.functions[source]?.sets === stateId)
        return { kind: 'function', fn: source };
    return { kind: 'invalid' };
}
function object(value, code) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error(code);
    return value;
}
function exact(value, allowed, code, optional = []) {
    const row = object(value, code);
    for (const key of Object.keys(row))
        if (!allowed.includes(key) && !optional.includes(key))
            throw new Error(`${code}: forbidden field ${key}`);
    for (const key of allowed)
        if (!(key in row))
            throw new Error(`${code}: missing field ${key}`);
    return row;
}
