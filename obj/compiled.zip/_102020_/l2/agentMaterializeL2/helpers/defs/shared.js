/// <mls fileReference="_102020_/l2/agentMaterializeL2/helpers/defs/shared.ts" enhancement="_blank"/>
// Reader of the public shared defs (web/shared/<pageId>.defs.ts). Grammar only, no policy.
// The format is the official one, `_102020_/l2/helpers/sharedV2/format.ts`, frozen by Wagner on 13/10/2026 ("o defs
// deve ter a intenção, do que deve ser feito, sem amarrar a LLM materializador"): entry.params (with `required`),
// requests, states (with the organisms they feed), journeys (step, organisms, continuesIn), rules (one list) and
// access. No `forms` and no `functions`: what each request does comes from the contract route comment, and who
// starts it from its trigger and from the page11 intents. Imported, not copied (13/10/2026), so this agent reads
// exactly what agentDefsL2 writes. The private copy it replaced also read `forms` and `functions`.
import { buildD2SharedV2, parseD2SharedV2 } from '/_102020_/l2/helpers/sharedV2/format.js';
/** The official parser, after normalizing CRLF (the Studio may save the file with it) and the final newline. */
export function parseL2Shared(source) {
    return parseD2SharedV2(`${source.replace(/\r\n/gu, '\n').replace(/\n*$/u, '')}\n`);
}
export function buildL2Shared(value) {
    return buildD2SharedV2(value);
}
export function classifyL2StateSource(source, definition) {
    if (source.startsWith('entry.params.')) {
        const param = source.slice('entry.params.'.length);
        return param && !param.includes('.') && definition.entry.params[param] ? { kind: 'entryParam', param } : { kind: 'invalid' };
    }
    const dot = source.indexOf('.');
    if (dot > 0) {
        const request = source.slice(0, dot);
        const tail = source.slice(dot + 1);
        const row = definition.requests[request];
        if (!row || !tail || tail.includes('.'))
            return { kind: 'invalid' };
        if (tail === 'input')
            return row.kind === 'cmd' ? { kind: 'requestInput', request } : { kind: 'invalid' };
        return row.returns.includes(tail) ? { kind: 'requestReturn', request, key: tail } : { kind: 'invalid' };
    }
    if (definition.states[source])
        return { kind: 'state', state: source };
    return { kind: 'invalid' };
}
