/// <mls fileReference="_102020_/l2/agentMaterializeL2/helpers/defs/page11.ts" enhancement="_blank"/>
const ID = /^[a-z][A-Za-z0-9]*$/u;
const PAGE_ID = /^[a-z][A-Za-z0-9_]*$/u;
const TAG = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*--[a-z][a-z0-9-]*$/u;
/** Parses the exact renderer grammar as JSON, with no eval, import or code execution. */
export function parseL2Page11(source) {
    const match = /^\/\/\/ <mls fileReference="_(\d+)_\/l2\/([a-z][A-Za-z0-9]*)\/web\/(desktop|mobile)\/page11\/([a-z][A-Za-z0-9_]*)\.defs\.ts" enhancement="_blank"\/>\r?\n\r?\nexport const definition = ([\s\S]+) as const;\r?\n?$/u.exec(source);
    if (!match)
        throw new Error('L2_PAGE11_SOURCE_SHAPE');
    let parsed;
    try {
        parsed = JSON.parse(match[5]);
    }
    catch {
        throw new Error('L2_PAGE11_SOURCE_JSON');
    }
    const location = { project: Number(match[1]), module: match[2], device: match[3], pageId: match[4] };
    return { location, definition: buildL2Page11(parsed) };
}
export function buildL2Page11(value) {
    const root = exactObject(value, ['template', 'intent', 'sections', 'organisms'], ['molecules'], 'L2_PAGE11_KEYS');
    const template = exactObject(root.template, ['category', 'experience'], [], 'L2_PAGE11_TEMPLATE_KEYS');
    const intent = requiredText(root.intent, 'L2_PAGE11_INTENT');
    if (!Array.isArray(root.sections) || !root.sections.length)
        throw new Error('L2_PAGE11_SECTIONS');
    const sections = root.sections.map((raw, index) => {
        const row = exactObject(raw, ['id', 'priority', 'purpose', 'organisms'], [], `L2_PAGE11_SECTION_KEYS: ${index}`);
        const id = requiredId(row.id, 'L2_PAGE11_SECTION_ID');
        if (row.priority !== 'primary' && row.priority !== 'main' && row.priority !== 'secondary')
            throw new Error(`L2_PAGE11_SECTION_PRIORITY: ${id}`);
        if (!Array.isArray(row.organisms) || !row.organisms.length)
            throw new Error(`L2_PAGE11_SECTION_EMPTY: ${id}`);
        return { id, priority: row.priority, purpose: requiredText(row.purpose, 'L2_PAGE11_SECTION_PURPOSE'), organisms: row.organisms.map(item => requiredId(item, 'L2_PAGE11_SECTION_ORGANISM_ID')) };
    });
    const organisms = {};
    for (const [id, raw] of Object.entries(object(root.organisms, 'L2_PAGE11_ORGANISMS'))) {
        requiredId(id, 'L2_PAGE11_ORGANISM_ID');
        const row = exactObject(raw, ['kind', 'text', 'intents'], [], `L2_PAGE11_ORGANISM_KEYS: ${id}`);
        if (!Array.isArray(row.intents))
            throw new Error(`L2_PAGE11_INTENTS: ${id}`);
        const intents = row.intents.map((rawIntent, index) => {
            const intentRow = exactObject(rawIntent, ['id', 'kind'], ['to'], `L2_PAGE11_INTENT_KEYS: ${id}/${index}`);
            const intentId = requiredId(intentRow.id, 'L2_PAGE11_INTENT_ID');
            if (intentRow.kind !== 'submit' && intentRow.kind !== 'navigate')
                throw new Error(`L2_PAGE11_INTENT_KIND: ${intentId}`);
            const to = intentRow.to === undefined ? '' : text(intentRow.to, 'L2_PAGE11_INTENT_TO');
            if (intentRow.kind === 'navigate' && !PAGE_ID.test(to))
                throw new Error(`L2_PAGE11_NAVIGATE_TO: ${intentId}`);
            return { id: intentId, kind: intentRow.kind, ...(to ? { to } : {}) };
        });
        organisms[id] = { kind: requiredText(row.kind, 'L2_PAGE11_ORGANISM_KIND'), text: requiredText(row.text, 'L2_PAGE11_ORGANISM_TEXT'), intents };
    }
    if (!Object.keys(organisms).length)
        throw new Error('L2_PAGE11_ORGANISMS_EMPTY');
    const molecules = {};
    // Optional: without a recommendation the page is built with no molecules (controleEstoque test, 02/10/2026).
    for (const [id, raw] of Object.entries(root.molecules === undefined ? {} : object(root.molecules, 'L2_PAGE11_MOLECULES'))) {
        if (!Array.isArray(raw) || !raw.length)
            throw new Error(`L2_PAGE11_MOLECULE_LIST: ${id}`);
        molecules[id] = raw.map((item, index) => {
            const row = exactObject(item, ['role', 'preferred'], ['alternative'], `L2_PAGE11_MOLECULE_KEYS: ${id}/${index}`);
            const preferred = requiredText(row.preferred, 'L2_PAGE11_MOLECULE_PREFERRED');
            const alternative = row.alternative === undefined ? '' : text(row.alternative, 'L2_PAGE11_MOLECULE_ALTERNATIVE');
            if (!TAG.test(preferred) || (alternative && !TAG.test(alternative)))
                throw new Error(`L2_PAGE11_MOLECULE_TAG: ${id}/${index}`);
            return { role: requiredText(row.role, 'L2_PAGE11_MOLECULE_ROLE'), preferred, ...(alternative ? { alternative } : {}) };
        });
    }
    return {
        template: { category: requiredText(template.category, 'L2_PAGE11_CATEGORY'), experience: requiredText(template.experience, 'L2_PAGE11_EXPERIENCE') },
        intent, sections, organisms, molecules,
    };
}
/** `groupviewtable--ml-data-table` → `groupviewtable`, the folder of the molecule index in _102040_. */
export function moleculeGroupFolder(tag) {
    return tag.slice(0, tag.indexOf('--'));
}
function exactObject(value, required, optional, code) {
    const row = object(value, code);
    for (const key of Object.keys(row))
        if (!required.includes(key) && !optional.includes(key))
            throw new Error(`${code}: forbidden field ${key}`);
    for (const key of required)
        if (!(key in row))
            throw new Error(`${code}: missing field ${key}`);
    return row;
}
function object(value, code) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error(code);
    return value;
}
function text(value, code) { if (typeof value !== 'string')
    throw new Error(code); return value; }
function requiredText(value, code) { const result = text(value, code); if (!result.trim())
    throw new Error(code); return result; }
function requiredId(value, code) { const result = requiredText(value, code); if (!ID.test(result))
    throw new Error(`${code}: ${result}`); return result; }
