/// <mls fileReference="_102020_/l2/agentMaterializeL2/helpers/core.ts" enhancement="_blank"/>
import { readStorText, storTextExists, writeStorText } from '/_102020_/l2/agentMaterializeL2/helpers/storText.js';
/** JSON through helpers/storText, which also reads a file created moments ago. */
async function readJson(info) {
    if (!storTextExists(info))
        return null;
    try {
        const text = await readStorText(info);
        return text.trim() ? JSON.parse(text) : null;
    }
    catch {
        return null;
    }
}
async function writeJson(info, value) {
    await writeStorText(info, `${JSON.stringify(value, null, 2)}
`);
}
export const M4_AGENT_NAME = 'agentMaterializeL2';
export const M4_ENTRY_AGENT_NAME = 'agentM4Entry';
export const M4_INPUT_AGENT_NAME = 'agentM4Input';
export const M4_SHARED_AGENT_NAME = 'agentM4Shared';
export const M4_SHARED_PAGE_AGENT_NAME = 'agentM4SharedPage';
/** The group step of one page: hosts that page's chain (shared, pages, reviews) as its children. */
export const M4_CHAIN_PAGE_AGENT_NAME = 'agentM4ChainPage';
export const M4_PAGES_AGENT_NAME = 'agentM4Pages';
export const M4_PAGES_PAGE_AGENT_NAME = 'agentM4PagesPage';
export const M4_REVIEW_AGENT_NAME = 'agentM4Review';
export const M4_REVIEW_PAGE_AGENT_NAME = 'agentM4ReviewPage';
export const M4_FLOW_ID = 'agentMaterializeL2';
export const M4_PIPELINE_VERSION = '2026-10-05-materialize-l2-v4-pipeline-v1';
/** Implemented steps, in order. review55 is planned only with --review. tests60 and finalize70 join as they are built. */
export const M4_FLOW_STEP_IDS = ['entry10', 'input20', 'shared40', 'pages50', 'review55'];
export const M4_STEP_DEPENDS_ON = {
    entry10: [],
    input20: ['entry10-done'],
    shared40: ['input20-done'],
    pages50: ['shared40-done'],
    review55: ['pages50-done'],
};
export const M4_STEP_AGENTS = {
    entry10: M4_ENTRY_AGENT_NAME,
    input20: M4_INPUT_AGENT_NAME,
    shared40: M4_SHARED_AGENT_NAME,
    pages50: M4_PAGES_AGENT_NAME,
    review55: M4_REVIEW_AGENT_NAME,
};
export const M4_STEP_TITLES = {
    entry10: 'Start L2 materialization',
    input20: 'Validate L2 definitions and read the L4 context',
    shared40: 'Generate shared classes and pages (one chain per page)',
    pages50: 'Check desktop and mobile pages',
    review55: 'Check the page reviews',
};
/** The steps a run plans: review55 only on --review (Guilherme, 05/10/2026: off by default). */
export function m4PlannedStepIds(scope = {}) {
    return M4_FLOW_STEP_IDS.filter(stepId => stepId !== 'review55' || scope.review === true);
}
const AGENT_PREFIXES = [/@@\s*_102020_\/l2\/agentMaterializeL2/giu, /@@\s*agentMaterializeL2/giu];
const USAGE = 'Usage: @@agentMaterializeL2 <lowerCamel module> [--page <pageId>[,<pageId>…]] [--device desktop|mobile] [--force] [--review].';
const PAGE_ID = /^[a-z][A-Za-z0-9_]{0,59}$/u;
/** The pages of `accepted` this run works on: all of them, or the `--page` ones (in their accepted order). */
export function m4ScopePages(accepted, scope) {
    return scope?.pages?.length ? accepted.filter(pageId => scope.pages.includes(pageId)) : [...accepted];
}
/** The devices this run works on. */
export function m4ScopeDevices(scope) {
    return scope?.device ? [scope.device] : ['desktop', 'mobile'];
}
/** One line for the step trace: `pages mesas, fechamento; device mobile; force`, or `whole module`. */
export function m4ScopeLabel(scope) {
    const parts = [scope?.pages?.length ? `pages ${scope.pages.join(', ')}` : '', scope?.device ? `device ${scope.device}` : '', scope?.force ? 'force' : '', scope?.review ? 'review' : ''].filter(Boolean);
    return parts.length ? parts.join('; ') : 'whole module';
}
function validScope(value) {
    if (value === undefined)
        return {};
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return 'Step scope must be an object.';
    const raw = value;
    const unknown = Object.keys(raw).find(key => key !== 'pages' && key !== 'device' && key !== 'force' && key !== 'review');
    if (unknown)
        return `Unknown scope key: ${unknown}.`;
    if (raw.pages !== undefined && (!Array.isArray(raw.pages) || !raw.pages.every(item => typeof item === 'string' && PAGE_ID.test(item))))
        return 'Scope pages must be page ids.';
    if (raw.device !== undefined && raw.device !== 'desktop' && raw.device !== 'mobile')
        return 'Scope device must be desktop or mobile.';
    if (raw.force !== undefined && typeof raw.force !== 'boolean')
        return 'Scope force must be a boolean.';
    if (raw.review !== undefined && typeof raw.review !== 'boolean')
        return 'Scope review must be a boolean.';
    return {
        ...(Array.isArray(raw.pages) && raw.pages.length ? { pages: raw.pages } : {}),
        ...(raw.device ? { device: raw.device } : {}),
        ...(raw.force ? { force: true } : {}),
        ...(raw.review ? { review: true } : {}),
    };
}
export function currentM4Project() {
    return Number(mls.actualProject || 0);
}
export function moduleTokenOk(value) {
    return /^[a-z][A-Za-z0-9]{0,59}$/u.test(value);
}
export function parseM4MessageInvocation(value, project = currentM4Project()) {
    let raw = String(value || '');
    for (const prefix of AGENT_PREFIXES)
        raw = raw.replace(prefix, ' ');
    const tokens = raw.trim().split(/\s+/u).filter(Boolean);
    if (tokens.length === 1 && (tokens[0].toLowerCase() === '/help' || tokens[0].toLowerCase() === '--help'))
        return { kind: 'help' };
    const positional = [];
    const scope = {};
    for (let i = 0; i < tokens.length; i += 1) {
        const token = tokens[i];
        const [name, inline] = token.includes('=') ? [token.slice(0, token.indexOf('=')), token.slice(token.indexOf('=') + 1)] : [token, undefined];
        if (name === '--page') {
            const value = inline ?? tokens[++i];
            const pages = String(value ?? '').split(',').map(item => item.trim()).filter(Boolean);
            if (!pages.length || !pages.every(item => PAGE_ID.test(item)))
                return { kind: 'refusal', diagnostic: `--page needs one or more page ids, separated by commas. ${USAGE}` };
            scope.pages = [...new Set([...(scope.pages ?? []), ...pages])];
        }
        else if (name === '--device') {
            const value = inline ?? tokens[++i];
            if (value !== 'desktop' && value !== 'mobile')
                return { kind: 'refusal', diagnostic: `--device must be desktop or mobile. ${USAGE}` };
            scope.device = value;
        }
        else if (name === '--force') {
            scope.force = true;
        }
        else if (name === '--review') {
            scope.review = true;
        }
        else if (token.startsWith('-') || token.startsWith('/')) {
            return { kind: 'refusal', diagnostic: `Unknown option: ${token}. ${USAGE}` };
        }
        else {
            positional.push(token);
        }
    }
    if (positional.length !== 1)
        return { kind: 'refusal', diagnostic: USAGE };
    if (!Number.isSafeInteger(project) || project <= 0)
        return { kind: 'refusal', diagnostic: 'The current project is unavailable.' };
    if (!moduleTokenOk(positional[0]))
        return { kind: 'refusal', diagnostic: 'Module name must be lowerCamel and must not contain a path.' };
    return { kind: 'run', project, module: positional[0], scope };
}
export function parseM4StepInvocation(value, currentProject = currentM4Project()) {
    let parsed;
    try {
        parsed = JSON.parse(String(value || '{}'));
    }
    catch {
        return { kind: 'refusal', diagnostic: 'agentMaterializeL2 step args must be JSON.' };
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        return { kind: 'refusal', diagnostic: 'agentMaterializeL2 step args must be an object.' };
    const raw = parsed;
    const unknown = Object.keys(raw).find(key => key !== 'project' && key !== 'module' && key !== 'scope');
    if (unknown)
        return { kind: 'refusal', diagnostic: `Unknown step arg: ${unknown}.` };
    const project = typeof raw.project === 'number' ? raw.project : Number.NaN;
    const module = typeof raw.module === 'string' ? raw.module.trim() : '';
    if (!Number.isSafeInteger(project) || project <= 0)
        return { kind: 'refusal', diagnostic: 'Step args require a positive integer project.' };
    if (project !== currentProject)
        return { kind: 'refusal', diagnostic: `Step project ${project} does not match the current project ${currentProject}.` };
    if (!moduleTokenOk(module))
        return { kind: 'refusal', diagnostic: 'Step module must be lowerCamel and must not contain a path.' };
    const scope = validScope(raw.scope);
    if (typeof scope === 'string')
        return { kind: 'refusal', diagnostic: scope };
    return { kind: 'run', project, module, scope };
}
export function m4StepIdOf(step) {
    const planId = String(step.planning?.planId || '');
    return M4_FLOW_STEP_IDS.includes(planId) ? planId : '';
}
export function createM4AgentStep(stepId, identity, scope = {}) {
    const dependsOn = [...M4_STEP_DEPENDS_ON[stepId]];
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: M4_STEP_TITLES[stepId],
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: M4_STEP_AGENTS[stepId],
        prompt: JSON.stringify({ project: identity.project, module: identity.module, ...(Object.keys(scope).length ? { scope } : {}) }),
        rags: [],
        planning: { planId: stepId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
export function buildM4PlannedSteps(identity, scope = {}) {
    return m4PlannedStepIds(scope).map(stepId => createM4AgentStep(stepId, identity, scope));
}
/** Everything this agent owns in a module lives under l2/<module>/pipeline/agentMaterializeL2/. */
export function m4OwnedFile(identity, shortName) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentMaterializeL2`, shortName, extension: '.json' };
}
export async function readM4Pipeline(identity) {
    return readJson(m4OwnedFile(identity, 'pipeline'));
}
export function createM4Pipeline(identity, now, scope = {}) {
    const updatedAt = now.toISOString();
    return {
        schemaVersion: M4_PIPELINE_VERSION, flowId: M4_FLOW_ID, project: identity.project, module: identity.module,
        status: 'inProgress', steps: { entry10: { status: 'approved', updatedAt } }, ...(Object.keys(scope).length ? { scope } : {}), createdAt: updatedAt, updatedAt,
    };
}
/** A new run always starts a fresh pipeline; an older format is replaced, not migrated. */
export async function initializeM4Pipeline(identity, scope = {}, now = new Date()) {
    const pipeline = createM4Pipeline(identity, now, scope);
    await writeJson(m4OwnedFile(identity, 'pipeline'), pipeline);
    return pipeline;
}
export async function markM4Step(identity, stepId, state) {
    const pipeline = await readM4Pipeline(identity);
    if (!pipeline)
        throw new Error('agentMaterializeL2 pipeline is missing; entry10 must run first.');
    const updatedAt = new Date().toISOString();
    const steps = { ...pipeline.steps, [stepId]: { ...state, updatedAt } };
    const planned = m4PlannedStepIds(pipeline.scope);
    const last = stepId === planned[planned.length - 1];
    const status = state.status === 'failed' ? 'failed' : last ? 'complete' : 'inProgress';
    await writeJson(m4OwnedFile(identity, 'pipeline'), { ...pipeline, status, steps, updatedAt });
}
export const M4_HELP = [
    USAGE,
    'The module is explicit and the project comes from the current context.',
    'Options: --page <id>[,<id>…] works on those pages only; --device desktop|mobile generates only that device',
    '(the shared is common to both); --force regenerates the units in scope even when nothing changed;',
    '--review adds review55, a second LLM that reviews each page against its template (report only).',
    'input20 always gates the whole module.',
    'Steps: entry10, input20 (validates the defs of every page and reads the L4 context of each one) and',
    'shared40 (one shared class per accepted page, compiled in the Studio, plus its declaration and findings).',
    'pages50 (desktop and mobile page per accepted page, compiled in the Studio). tests60 and finalize70',
    'are planned (TASK-102020-agent-materialize-l2-v4).',
].join('\n');
