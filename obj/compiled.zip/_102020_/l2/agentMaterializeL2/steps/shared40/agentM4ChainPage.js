/// <mls fileReference="_102020_/l2/agentMaterializeL2/steps/shared40/agentM4ChainPage.ts" enhancement="_blank"/>
import { M4_CHAIN_PAGE_AGENT_NAME, moduleTokenOk } from '/_102020_/l2/agentMaterializeL2/helpers/core.js';
import { addAgentStep, updateAgentStatus } from '/_102020_/l2/agentMaterializeL2/helpers/intents.js';
export function createAgent() {
    return { agentName: M4_CHAIN_PAGE_AGENT_NAME, agentProject: 102020, agentFolder: 'agentMaterializeL2/steps/shared40', agentDescription: 'Group the shared, pages and reviews of one page', visibility: 'private', beforePromptStep };
}
export function chainPageStep(args) {
    return {
        type: 'agent', stepId: 0, interaction: null, stepTitle: args.pageId, status: 'waiting_human_input', nextSteps: [],
        agentName: M4_CHAIN_PAGE_AGENT_NAME, prompt: JSON.stringify(args), rags: [],
        planning: { planId: `chain40-${args.pageId}`, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
    };
}
export function parseChainPageArgs(raw) {
    let value;
    try {
        value = JSON.parse(raw);
    }
    catch {
        throw new Error('M4_CHAIN_ARGS_INVALID');
    }
    const args = value;
    if (!args || !Number.isSafeInteger(args.project) || args.project <= 0 || !moduleTokenOk(args.module) || !/^[a-z][A-Za-z0-9_]*$/u.test(args.pageId) || !Array.isArray(args.units))
        throw new Error('M4_CHAIN_ARGS_INVALID');
    return args;
}
/** The intents of a group: its units under itself first, then in_progress, never completed (the engine completes it). */
export function chainPageIntents(context, parentStep, step, hookSequential, args) {
    if (!args.units.length)
        return [updateAgentStatus(context, parentStep, step, hookSequential, 'completed', `Page ${args.pageId}: nothing pending.`)];
    return [
        ...args.units.map(unit => addAgentStep(context, step.stepId, unit)),
        updateAgentStatus(context, parentStep, step, hookSequential, 'in_progress', `Page ${args.pageId}: ${args.units.map(unit => unit.stepTitle).join(', ')}.`),
    ];
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential) {
    try {
        return chainPageIntents(context, parentStep, step, hookSequential, parseChainPageArgs(step.prompt || ''));
    }
    catch (error) {
        return [updateAgentStatus(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
