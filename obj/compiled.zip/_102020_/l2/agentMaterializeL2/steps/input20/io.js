/// <mls fileReference="_102020_/l2/agentMaterializeL2/steps/input20/io.ts" enhancement="_blank"/>
// Studio IO of input20: page discovery, reading the four defs of every page, the existence checks the
// gate needs (collabux template, molecule index) and the L4 files. Everything runs in the browser over mls.stor.
import { fileExists, readJson, readSourceText } from '/_102035_/l2/solution/fs.js';
import { M4_INPUT_KINDS } from '/_102020_/l2/agentMaterializeL2/steps/input20/gate.js';
import { moleculeGroupFolder } from '/_102020_/l2/agentMaterializeL2/helpers/defs/page11.js';
export const studioInputPort = {
    listDefs(project, folder, level = 2) {
        return Object.values(mls.stor.files)
            .filter(file => file.project === project && file.level === level && file.folder === folder && file.extension === '.defs.ts' && file.status !== 'deleted')
            .map(file => file.shortName);
    },
    exists: fileExists,
    read: readSourceText,
    readJson,
};
export function m4DefsFolder(identity, kind) {
    return kind === 'contract' ? `${identity.module}/web/contracts`
        : kind === 'shared' ? `${identity.module}/web/shared`
            : `${identity.module}/web/${kind}/page11`;
}
export function m4DefsInfo(identity, kind, pageId) {
    return { project: identity.project, level: 2, folder: m4DefsFolder(identity, kind), shortName: pageId, extension: '.defs.ts' };
}
/** A page exists when any of its four defs exists; the gate then refuses the ones that are incomplete. */
export function discoverM4Pages(identity, port) {
    const ids = new Set();
    for (const kind of M4_INPUT_KINDS)
        for (const shortName of port.listDefs(identity.project, m4DefsFolder(identity, kind)))
            ids.add(shortName);
    return [...ids].sort();
}
export async function readM4PageSources(identity, pageId, port) {
    const sources = {};
    for (const kind of M4_INPUT_KINDS) {
        const info = m4DefsInfo(identity, kind, pageId);
        sources[kind] = port.exists(info) ? await port.read(info) : null;
    }
    return sources;
}
export async function readDefsPipelineStatus(identity, port) {
    const pipeline = await port.readJson({ project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2`, shortName: 'pipeline', extension: '.json' });
    return pipeline ? String(pipeline.status ?? '') : null;
}
/** `_102020_/l4/collabux/templates/inventoryControl/page21.md` → its file info, or null when it is not such a path. */
export function templateInfo(category) {
    const match = /^_(\d+)_\/l(\d)\/(.+)\/([^/]+)(\.[a-z]+)$/u.exec(category);
    return match ? { project: Number(match[1]), level: Number(match[2]), folder: match[3], shortName: match[4], extension: match[5] } : null;
}
export function moleculeIndexInfo(tag) {
    return { project: 102040, level: 2, folder: `molecules/${moleculeGroupFolder(tag)}`, shortName: 'index', extension: '.defs.ts' };
}
/** Reads every molecule group index once and answers whether a tag is listed in it. */
export async function loadMoleculeCatalog(tags, port) {
    const indexes = new Map();
    for (const tag of tags) {
        const info = moleculeIndexInfo(tag);
        if (indexes.has(info.folder))
            continue;
        indexes.set(info.folder, port.exists(info) ? await port.read(info) : '');
    }
    return tag => (indexes.get(moleculeIndexInfo(tag).folder) ?? '').includes(`tag: '${tag}'`);
}
