/// <mls fileReference="_102020_/l2/agentMaterializeL2/steps/review55/run.ts" enhancement="_blank"/>
// review55, one page × device: a second LLM reviews the generated page against the template and the intent of
// the page, and returns findings with a severity. REPORT ONLY (Guilherme, 05/10/2026): nothing is rewritten and
// nothing is refused; the findings go to the receipt (and to the module report). A later version may let
// blocker/major findings drive one repair round of pages50.
// The review is reused while the page file and its context are unchanged.
import { displayPath } from '/_102035_/l2/solution/fs.js';
import { sha256Text } from '/_102020_/l2/agentMaterializeL2/helpers/hash.js';
import { parseL2Page11 } from '/_102020_/l2/agentMaterializeL2/helpers/defs/page11.js';
import { readL4Module, renderL4Slice, resolveL4Refs } from '/_102020_/l2/agentMaterializeL2/helpers/l4/context.js';
import { m4DefsInfo, templateInfo } from '/_102020_/l2/agentMaterializeL2/steps/input20/io.js';
import { M4_REUSE_FINGERPRINT, deleteGeneratedFile, readM4Snapshot, sharedDeclarationInfo, storedHash } from '/_102020_/l2/agentMaterializeL2/steps/shared40/run.js';
import { pageReceiptInfo, pageSourceInfo, studioPagePort } from '/_102020_/l2/agentMaterializeL2/steps/pages50/run.js';
export const M4_REVIEW_VERSION = '2026-10-05-materialize-l2-v4-review-v1';
export const M4_REVIEW_TOOL = 'submitPageReview';
export const M4_REVIEW_SEVERITIES = ['blocker', 'major', 'minor'];
export const reviewPromptInfo = { project: 102020, level: 2, folder: 'agentMaterializeL2/steps/review55', shortName: 'prompt', extension: '.md' };
export function reviewReceiptInfo(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentMaterializeL2/review55`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' };
}
/** The page must exist with a pages50 receipt: the review reads what pages50 approved, nothing else. */
export async function buildM4ReviewContext(identity, pageId, device, port = studioPagePort, snapshot) {
    const snap = snapshot ?? await readM4Snapshot(identity, port);
    const page = snap.pages.find(item => item.pageId === pageId && item.status === 'accepted');
    if (!page)
        throw new Error(`M4_REVIEW_PAGE_NOT_ACCEPTED: ${pageId}`);
    const sourceInfo = pageSourceInfo(identity, pageId, device);
    if (!port.exists(sourceInfo))
        throw new Error(`M4_REVIEW_PAGE_MISSING: ${displayPath(sourceInfo)}; pages50 must generate it first.`);
    const receipt = await port.readJson(pageReceiptInfo(identity, pageId, device));
    const source = await port.read(sourceInfo);
    const page11Source = await port.read(m4DefsInfo(identity, device, pageId));
    const page11 = parseL2Page11(page11Source).definition;
    const template = templateInfo(page11.template.category);
    const templateText = template && port.exists(template) ? await port.read(template) : '';
    const declarationInfo = sharedDeclarationInfo(identity, pageId);
    const declaration = port.exists(declarationInfo) ? await port.read(declarationInfo) : '';
    const l4Context = page.l4 ? await readL4Module(identity.project, identity.module, { listDefs: (project, folder) => port.listDefs(project, folder, 4), exists: port.exists, read: port.read }) : null;
    const l4 = l4Context && page.l4 ? renderL4Slice(resolveL4Refs(l4Context, page.l4)) : '';
    const prompt = await port.read(reviewPromptInfo);
    const parts = [
        '# Page under review',
        `- module: ${identity.module}; page: ${pageId}; device: ${device}`,
        `- file: ${displayPath(sourceInfo)}`,
        '',
        '# The page file',
        '```ts', source.trim(), '```',
        '',
        '# The design answer its author gave',
        '```json', JSON.stringify(receipt?.design ?? null, null, 2), '```',
        '',
        `# Page definition — web/${device}/page11/${pageId}.defs.ts (intent, sections, organisms)`,
        '```ts', page11Source.trim(), '```',
        '',
        `# Template — ${page11.template.category}`,
        templateText.trim() || '(template not found)',
        '',
        '# Business context (L4)',
        l4 || '(the module has no L4 context)',
        '',
        `# Shared declaration — what the page can read and call`,
        '```ts', declaration.trim() || '(not found)', '```',
    ];
    const humanPrompt = parts.join('\n');
    // Only DATA decides reuse (22/10/2026): the reviewed page, its page11 unit and the shared declaration; never the prompt,
    // the template or how the L4 is written.
    const unitHash = page.units.find(item => item.kind === device)?.inputHash ?? '';
    const dataHash = await sha256Text([await storedHash(source), unitHash, await storedHash(declaration)].join('\n'));
    return { identity, pageId, device, prompt, humanPrompt, contextHash: await sha256Text(`${prompt}\n---\n${humanPrompt}`), dataHash };
}
export function buildM4ReviewPrompt(context) {
    return { systemPrompt: context.prompt, humanPrompt: context.humanPrompt };
}
/** Records the review. Malformed rows are dropped; a missing answer is recorded as such (report only, never a failure). */
export async function recordM4Review(context, answer, port = studioPagePort) {
    const receipt = {
        schemaVersion: M4_REVIEW_VERSION, ...context.identity, pageId: context.pageId, device: context.device,
        contextHash: context.contextHash, dataHash: context.dataHash, fingerprint: M4_REUSE_FINGERPRINT, pagePath: displayPath(pageSourceInfo(context.identity, context.pageId, context.device)),
        summary: answer.summary, findings: answer.findings, ...(answer.failed ? { failed: answer.failed } : {}),
    };
    await port.writeJson(reviewReceiptInfo(context.identity, context.pageId, context.device), receipt);
    return receipt;
}
/**
 * settled: a review receipt exists (done or failed): the step may finish.
 * reusable: settled and not failed: the next run does not review it again.
 * The page file and its hashes do not decide. Generating the page deletes this receipt.
 */
export async function m4ReviewState(identity, pageId, device, port = studioPagePort, snapshot) {
    void snapshot;
    const info = reviewReceiptInfo(identity, pageId, device);
    if (!port.exists(info))
        return { settled: false, reusable: false };
    const receipt = await port.readJson(info);
    if (!receipt || receipt.schemaVersion !== M4_REVIEW_VERSION)
        return { settled: false, reusable: false };
    return { settled: true, reusable: !receipt.failed };
}
/** A failed review from an older run still exists. Drop it before dispatching, so this run's chain stays open until a new receipt is written. */
export async function dropFailedM4Review(identity, pageId, device, port = studioPagePort) {
    const info = reviewReceiptInfo(identity, pageId, device);
    if (!port.exists(info))
        return;
    const receipt = await port.readJson(info);
    if (!receipt?.failed)
        return;
    const remove = port.deleteText ?? deleteGeneratedFile;
    await remove(info);
}
/** One line per finding, worst first, for the step trace. */
export function formatM4Review(receipt) {
    const rank = (item) => M4_REVIEW_SEVERITIES.indexOf(item.severity);
    const rows = [...receipt.findings].sort((a, b) => rank(a) - rank(b)).map(item => `${item.severity} [${item.area}] ${item.message} — fix: ${item.fix}`);
    const count = (severity) => receipt.findings.filter(item => item.severity === severity).length;
    if (receipt.failed)
        return `Review ${receipt.pageId}/${receipt.device} failed: ${receipt.failed}`;
    return [`Review ${receipt.pageId}/${receipt.device}: ${count('blocker')} blocker, ${count('major')} major, ${count('minor')} minor. ${receipt.summary}`, ...rows].join('\n');
}
/** The tool answer: well-formed findings only. */
export function m4ReviewToolAnswer(payload) {
    const root = payload && typeof payload === 'object' ? payload : {};
    const result = root.type === 'flexible' ? root.result : undefined;
    if (result && result.toolName !== M4_REVIEW_TOOL)
        throw new Error(`M4_REVIEW_TOOL_MISMATCH: expected ${M4_REVIEW_TOOL}.`);
    let args = result ? result.arguments : root.arguments ?? root.payload ?? root;
    if (typeof args === 'string') {
        try {
            args = JSON.parse(args);
        }
        catch {
            throw new Error('M4_REVIEW_TOOL_JSON: the tool arguments are not JSON.');
        }
    }
    const value = args && typeof args === 'object' ? args : {};
    const text = (field) => typeof field === 'string' ? field : '';
    const findings = (Array.isArray(value.findings) ? value.findings : []).flatMap((row) => {
        const item = row && typeof row === 'object' ? row : {};
        const severity = item.severity;
        if (!M4_REVIEW_SEVERITIES.includes(severity) || !text(item.message))
            return [];
        return [{ severity, area: text(item.area), message: text(item.message), basis: text(item.basis), where: text(item.where), fix: text(item.fix) }];
    });
    return { summary: text(value.summary), findings };
}
export const m4ReviewToolSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['summary', 'findings'],
    properties: {
        summary: { type: 'string', description: 'Two or three sentences: does the page serve its intent and follow its template on this device?' },
        findings: {
            type: 'array',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['severity', 'area', 'message', 'basis', 'where', 'fix'],
                properties: {
                    severity: { type: 'string', enum: [...M4_REVIEW_SEVERITIES] },
                    area: { type: 'string', description: 'template, intent, journey, hierarchy, titles, states, mobile, accessibility, text, data…' },
                    message: { type: 'string' },
                    basis: { type: 'string', description: 'The quoted line of the template, the page intent, a section purpose or the L4 the finding rests on.' },
                    where: { type: 'string', description: 'A render method, an organism id or a short quote of the page.' },
                    fix: { type: 'string', description: 'One sentence.' },
                },
            },
        },
    },
};
