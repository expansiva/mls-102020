/// <mls fileReference="_102020_/l2/agentMaterializeL2/steps/review55/agentM4Review.ts" enhancement="_blank"/>
import { M4_REVIEW_AGENT_NAME, M4_REVIEW_PAGE_AGENT_NAME, m4ScopeDevices, m4ScopeLabel, m4ScopePages, markM4Step, parseM4StepInvocation, } from '/_102020_/l2/agentMaterializeL2/helpers/core.js';
import { addAgentStep, agentResult, updateAgentStatus } from '/_102020_/l2/agentMaterializeL2/helpers/intents.js';
import { displayPath } from '/_102035_/l2/solution/fs.js';
import { readM4Snapshot } from '/_102020_/l2/agentMaterializeL2/steps/shared40/run.js';
import { studioPagePort } from '/_102020_/l2/agentMaterializeL2/steps/pages50/run.js';
import { dropFailedM4Review, m4ReviewState, reviewReceiptInfo } from '/_102020_/l2/agentMaterializeL2/steps/review55/run.js';
export function createAgent() {
    return { agentName: M4_REVIEW_AGENT_NAME, agentProject: 102020, agentFolder: 'agentMaterializeL2/steps/review55', agentDescription: 'Dispatch one review worker per generated page and device', visibility: 'private', beforePromptStep };
}
export function reviewWorkerStep(args) {
    return {
        type: 'agent', stepId: 0, interaction: null, stepTitle: `Review ${args.chain ? '' : `${args.pageId} `}${args.device}`, status: 'waiting_human_input', nextSteps: [],
        agentName: M4_REVIEW_PAGE_AGENT_NAME, prompt: JSON.stringify(args), rags: [],
        planning: { planId: `review55-${args.pageId}-${args.device}`, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
    };
}
/** Emits review55-done once every unit in scope has a review of its current page (done or failed); null otherwise. */
export async function m4ReviewDoneIntent(context, parentStep, identity, scope = {}) {
    const snapshot = await readM4Snapshot(identity, studioPagePort);
    const pages = m4ScopePages(snapshot.accepted, scope);
    const devices = m4ScopeDevices(scope);
    for (const pageId of pages)
        for (const device of devices)
            if (!(await m4ReviewState(identity, pageId, device, studioPagePort, snapshot)).settled)
                return null;
    const counts = { blocker: 0, major: 0, minor: 0, failed: 0 };
    for (const pageId of pages)
        for (const device of devices) {
            const receipt = await studioPagePort.readJson(reviewReceiptInfo(identity, pageId, device));
            if (receipt?.failed)
                counts.failed += 1;
            for (const item of receipt?.findings ?? [])
                counts[item.severity] += 1;
        }
    const receipts = pages.flatMap(pageId => devices.map(device => displayPath(reviewReceiptInfo(identity, pageId, device))));
    await markM4Step(identity, 'review55', { status: 'approved', artifactPaths: receipts, snapshotHash: snapshot.snapshotHash });
    return addAgentStep(context, parentStep.stepId, agentResult('Review ready', JSON.stringify({ ...identity, completedStep: 'review55', pages, devices, findings: counts, scope: m4ScopeLabel(scope) }), 'review55-done'));
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const invocation = parseM4StepInvocation(args || step.prompt || '');
    if (invocation.kind === 'refusal')
        return [updateAgentStatus(context, parentStep, step, hookSequential, 'failed', invocation.diagnostic)];
    const identity = { project: invocation.project, module: invocation.module };
    const scope = invocation.scope;
    try {
        const snapshot = await readM4Snapshot(identity, studioPagePort);
        const pages = m4ScopePages(snapshot.accepted, scope);
        const devices = m4ScopeDevices(scope);
        const pending = [];
        for (const pageId of pages)
            for (const device of devices) {
                if ((await m4ReviewState(identity, pageId, device, studioPagePort, snapshot)).reusable)
                    continue;
                await dropFailedM4Review(identity, pageId, device, studioPagePort);
                pending.push({ pageId, device });
            }
        const total = pages.length * devices.length;
        if (!pending.length) {
            const done = await m4ReviewDoneIntent(context, parentStep, identity, scope);
            return [...(done ? [done] : []), updateAgentStatus(context, parentStep, step, hookSequential, 'completed', `review55 reused ${total} review(s) without an LLM call (${m4ScopeLabel(scope)}).`)];
        }
        const workers = pending.map(unit => addAgentStep(context, parentStep.stepId, reviewWorkerStep({ ...identity, ...unit, scope })));
        return [...workers, updateAgentStatus(context, parentStep, step, hookSequential, 'completed', `Dispatched ${pending.length} review worker(s) [${pending.map(unit => `${unit.pageId}/${unit.device}`).join(', ')}]; ${total - pending.length} reused (${m4ScopeLabel(scope)}).`)];
    }
    catch (error) {
        const diagnostic = error instanceof Error ? error.message : String(error);
        try {
            await markM4Step(identity, 'review55', { status: 'failed', diagnostic });
        }
        catch { /* pipeline missing */ }
        return [updateAgentStatus(context, parentStep, step, hookSequential, 'failed', diagnostic)];
    }
}
