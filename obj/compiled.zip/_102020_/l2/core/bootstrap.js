export async function bootstrapCollabApp(_app) {
    await import('/_102020_/l2/shared/bootstrap.js');
}
