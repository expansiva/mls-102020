export async function execBff(routine, params) {
    const response = await fetch('/execBff', {
        method: 'POST',
        headers: {
            'content-type': 'application/json',
        },
        body: JSON.stringify({
            routine,
            params,
            meta: {
                source: 'http',
            },
        }),
    });
    return response.json();
}
