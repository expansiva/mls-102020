/// <mls fileReference="_102020_/l2/molecules/groupSelectOne/singleOptionPicker.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// SINGLE OPTION PICKER MOLECULE
// =============================================================================
// Skill Group: select + one (groupSelectOne)
// This molecule does NOT contain business logic.
// - No Shadow DOM
// - Presentation-only
// - Options provided via Slot Tags (<Content><Item ...>)
// - Accessible + keyboard navigation
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, unsafeHTML } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from '/_100554_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    label: 'Choose one',
    placeholder: 'Select an option',
    loading: 'Loading...',
    noOptions: 'No options available',
    requiredHint: 'Required',
    invalid: 'Invalid',
};
const messages = {
    en: message_en,
    pt: {
        label: 'Escolha uma opção',
        placeholder: 'Selecione uma opção',
        loading: 'Carregando...',
        noOptions: 'Nenhuma opção disponível',
        requiredHint: 'Obrigatório',
        invalid: 'Inválido',
    },
};
/// **collab_i18n_end**
let SingleOptionPickerMolecule = class SingleOptionPickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Hint', 'Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];
        // ==========================================================================
        // PROPERTIES — Contract (select + one)
        // ==========================================================================
        this.value = null;
        this.disabled = false;
        this.readonly = false;
        this.loading = false;
        this.required = false;
        this.error = false;
        this.name = '';
        // Optional label/placeholder via properties (supports i18n binding)
        this.label = '';
        this.placeholder = '';
        // Presentation variant
        // - list: vertical list
        // - segmented: horizontal segmented control
        this.variant = 'list';
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.activeIndex = -1;
    }
    // ==========================================================================
    // GETTERS
    // ==========================================================================
    get isBlocked() {
        return this.disabled || this.readonly || this.loading;
    }
    get items() {
        return this.getItems();
    }
    get selectedIndex() {
        if (this.value == null)
            return -1;
        return this.items.findIndex(i => String(i.value) === String(this.value));
    }
    get hasError() {
        return Boolean(this.error);
    }
    get errorMessage() {
        if (typeof this.error === 'string')
            return this.error;
        return '';
    }
    get ariaLabels() {
        const fromProp = (this.label || '').trim();
        const fromSlot = (this.getSlotContent('Label') || '').trim();
        // Slot content can contain HTML; we still need plain-text for aria-label.
        const slotText = fromSlot
            .replace(/<[^>]*>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        return fromProp || slotText || this.msg.label;
    }
    get computedPlaceholder() {
        const fromProp = (this.placeholder || '').trim();
        const fromTriggerAttr = (this.getSlotAttr('Trigger', 'placeholder') || '').trim();
        const fromValueAttr = (this.getSlotAttr('Value', 'placeholder') || '').trim();
        return fromProp || fromTriggerAttr || fromValueAttr || this.msg.placeholder;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    updated(changed) {
        super.updated?.(changed);
        // Keep activeIndex aligned when value changes externally.
        if (changed.has('value')) {
            const idx = this.selectedIndex;
            this.activeIndex = idx >= 0 ? idx : this.getFirstEnabledIndex();
        }
        // If items change (slot content), ensure indexes are in range.
        if (changed.has('loading') || changed.has('disabled') || changed.has('readonly')) {
            if (this.activeIndex < 0)
                this.activeIndex = this.getFirstEnabledIndex();
        }
    }
    // ==========================================================================
    // EVENTS
    // ==========================================================================
    emitChange(nextValue, option) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: {
                value: nextValue,
                option,
            },
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ==========================================================================
    // INTERACTION
    // ==========================================================================
    trySelectIndex(index) {
        if (this.isBlocked)
            return;
        const item = this.items[index];
        if (!item || item.disabled)
            return;
        const nextValue = String(item.value);
        if (String(this.value ?? '') === nextValue) {
            // No-op selection; still keep focus/active.
            this.activeIndex = index;
            return;
        }
        this.value = nextValue;
        this.activeIndex = index;
        this.emitChange(nextValue, item);
    }
    getFirstEnabledIndex() {
        const idx = this.items.findIndex(i => !i.disabled);
        return idx;
    }
    getLastEnabledIndex() {
        for (let i = this.items.length - 1; i >= 0; i -= 1) {
            if (!this.items[i].disabled)
                return i;
        }
        return -1;
    }
    getNextEnabledIndex(from, direction) {
        const total = this.items.length;
        if (total === 0)
            return -1;
        let i = from;
        for (let step = 0; step < total; step += 1) {
            i = i + direction;
            if (i < 0)
                i = total - 1;
            if (i >= total)
                i = 0;
            if (!this.items[i]?.disabled)
                return i;
        }
        return -1;
    }
    focusItem(index) {
        const el = this.renderRoot?.querySelector(`[data-option-index="${index}"]`);
        el?.focus();
    }
    handleOptionClick(index) {
        this.trySelectIndex(index);
    }
    handleOptionFocus(index) {
        this.activeIndex = index;
    }
    handleKeyDown(e) {
        const key = e.key;
        // Let Tab flow naturally; we only manage focus within when using arrows.
        if (key === 'Tab')
            return;
        const items = this.items;
        if (items.length === 0)
            return;
        const isHorizontal = this.variant === 'segmented';
        const isPrevKey = key === 'ArrowUp' || (isHorizontal && key === 'ArrowLeft');
        const isNextKey = key === 'ArrowDown' || (isHorizontal && key === 'ArrowRight');
        const current = this.activeIndex >= 0 ? this.activeIndex : (this.selectedIndex >= 0 ? this.selectedIndex : this.getFirstEnabledIndex());
        if (isPrevKey || isNextKey) {
            e.preventDefault();
            if (this.isBlocked)
                return;
            const next = this.getNextEnabledIndex(current, (isPrevKey ? -1 : 1));
            if (next >= 0) {
                this.activeIndex = next;
                this.focusItem(next);
            }
            return;
        }
        if (key === 'Home') {
            e.preventDefault();
            if (this.isBlocked)
                return;
            const first = this.getFirstEnabledIndex();
            if (first >= 0) {
                this.activeIndex = first;
                this.focusItem(first);
            }
            return;
        }
        if (key === 'End') {
            e.preventDefault();
            if (this.isBlocked)
                return;
            const last = this.getLastEnabledIndex();
            if (last >= 0) {
                this.activeIndex = last;
                this.focusItem(last);
            }
            return;
        }
        if (key === 'Enter' || key === ' ') {
            e.preventDefault();
            if (this.isBlocked)
                return;
            const idx = this.activeIndex >= 0 ? this.activeIndex : current;
            if (idx >= 0)
                this.trySelectIndex(idx);
            return;
        }
        if (key === 'Escape') {
            // No dropdown to close; keep as no-op (avoid preventing default).
            return;
        }
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    getRootClasses() {
        return [
            'w-full',
            'rounded-lg',
            'border',
            'bg-white',
            'p-3',
            'transition',
            this.hasError ? 'border-rose-500' : 'border-slate-200',
            !this.isBlocked ? 'hover:border-slate-300' : 'opacity-60',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getLabelClasses() {
        return ['mb-2', 'text-sm', 'font-medium', 'text-slate-900', 'flex', 'items-center', 'gap-2']
            .filter(Boolean)
            .join(' ');
    }
    getHintClasses() {
        return ['mt-2', 'text-xs', this.hasError ? 'text-rose-600' : 'text-slate-500'].join(' ');
    }
    getOptionsWrapperClasses() {
        const base = ['mt-2', 'outline-none'];
        if (this.variant === 'segmented') {
            base.push('flex', 'flex-wrap', 'gap-2');
        }
        else {
            base.push('flex', 'flex-col', 'gap-2');
        }
        return base.join(' ');
    }
    getOptionClasses(item, index) {
        const isSelected = String(item.value) === String(this.value ?? '');
        const isActive = index === this.activeIndex;
        return [
            'w-full',
            this.variant === 'segmented' ? 'w-auto min-w-[3rem]' : '',
            'rounded-md',
            'border',
            'px-3',
            'py-2',
            'text-sm',
            'text-left',
            'transition',
            'focus:outline-none',
            'focus:ring-2',
            'focus:ring-sky-500',
            isSelected ? 'border-sky-500 bg-sky-50 text-sky-900' : 'border-slate-200 bg-white text-slate-900',
            !item.disabled && !this.isBlocked && !isSelected ? 'hover:bg-slate-50 hover:border-slate-300' : '',
            item.disabled ? 'opacity-50 cursor-not-allowed' : this.isBlocked ? 'cursor-not-allowed' : 'cursor-pointer',
            isActive && !this.isBlocked ? 'ring-1 ring-sky-200' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderLabelBlock() {
        const hasLabelProp = (this.label || '').trim().length > 0;
        const hasLabelSlot = (this.getSlotContent('Label') || '').trim().length > 0;
        if (!hasLabelProp && !hasLabelSlot && !this.required)
            return html `${nothing}`;
        return html `
      <div class=${this.getLabelClasses()}>
        <div class="flex-1">
          ${hasLabelProp ? html `${this.label}` : nothing}
          ${!hasLabelProp && hasLabelSlot ? html `${unsafeHTML(this.getSlotContent('Label'))}` : nothing}
        </div>
        ${this.required
            ? html `<span class="text-[11px] text-slate-500 border border-slate-200 rounded px-1.5 py-0.5">${this.msg.requiredHint}</span>`
            : nothing}
      </div>
    `;
    }
    renderHintBlock() {
        const hintSlot = (this.getSlotContent('Hint') || '').trim();
        const msg = this.errorMessage;
        if (!this.hasError && !hintSlot)
            return html `${nothing}`;
        return html `
      <div class=${this.getHintClasses()} aria-live="polite">
        ${this.hasError
            ? html `${msg ? msg : this.msg.invalid}`
            : html `${unsafeHTML(hintSlot)}`}
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class="mt-2 flex items-center gap-2 text-sm text-slate-600" aria-live="polite">
        <div class="h-4 w-4 rounded-full border-2 border-slate-300 border-t-slate-600 animate-spin"></div>
        <div>${this.msg.loading}</div>
      </div>
    `;
    }
    renderEmpty() {
        const content = (this.getSlotContent('Empty') || '').trim();
        return html `
      <div class="mt-2 text-sm text-slate-500">
        ${content ? unsafeHTML(content) : html `${this.msg.noOptions}`}
      </div>
    `;
    }
    renderOptions2() {
        const items = this.items;
        if (items.length === 0)
            return this.renderEmpty();
        // Roving tabindex:
        // - selected index gets 0, otherwise activeIndex, otherwise first enabled.
        const selectedIdx = this.selectedIndex;
        const fallbackIdx = this.getFirstEnabledIndex();
        const focusIdx = selectedIdx >= 0 ? selectedIdx : (this.activeIndex >= 0 ? this.activeIndex : fallbackIdx);
        return html `
      <div
        class=${this.getOptionsWrapperClasses()}
        role="radiogroup"
        aria-label=${this.ariaLabels}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        aria-invalid=${this.hasError ? 'true' : 'false'}
        @keydown=${this.handleKeyDown}
      >
        ${items.map((item, index) => {
            const isSelected = String(item.value) === String(this.value ?? '');
            const isDisabled = this.isBlocked || item.disabled;
            const tabIndex = index === focusIdx && !isDisabled ? 0 : -1;
            return html `
            <button
              type="button"
              class=${this.getOptionClasses(item, index)}
              role="radio"
              aria-checked=${isSelected ? 'true' : 'false'}
              aria-disabled=${isDisabled ? 'true' : 'false'}
              data-option-index=${String(index)}
              tabindex=${String(tabIndex)}
              ?disabled=${isDisabled}
              @click=${() => this.handleOptionClick(index)}
              @focus=${() => this.handleOptionFocus(index)}
              @blur=${this.emitBlur}
            >
              <span class="flex items-center gap-2">
                <span
                  class=${[
                'inline-flex',
                'h-4',
                'w-4',
                'rounded-full',
                'border',
                isSelected ? 'border-sky-600' : 'border-slate-300',
                'items-center',
                'justify-center',
                'shrink-0',
            ].join(' ')}
                  aria-hidden="true"
                >
                  <span
                    class=${[
                'h-2',
                'w-2',
                'rounded-full',
                isSelected ? 'bg-sky-600' : 'bg-transparent',
            ].join(' ')}
                  ></span>
                </span>

                <span class="flex-1">
                  ${unsafeHTML(item.label || this.computedPlaceholder)}
                </span>
              </span>
            </button>
          `;
        })}
      </div>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] ?? messages.en;
        return html `
      <div class=${this.getRootClasses()}>
        ${this.renderLabelBlock()}

        ${this.loading ? this.renderLoading() : nothing}

        ${this.renderOptions2()}

        ${this.renderHintBlock()}

        ${this.name
            ? html `<input type="hidden" name=${this.name} .value=${String(this.value ?? '')} />`
            : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], SingleOptionPickerMolecule.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], SingleOptionPickerMolecule.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], SingleOptionPickerMolecule.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], SingleOptionPickerMolecule.prototype, "loading", void 0);
__decorate([
    property({ type: Boolean })
], SingleOptionPickerMolecule.prototype, "required", void 0);
__decorate([
    property({ type: String })
], SingleOptionPickerMolecule.prototype, "error", void 0);
__decorate([
    property({ type: String })
], SingleOptionPickerMolecule.prototype, "name", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], SingleOptionPickerMolecule.prototype, "label", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], SingleOptionPickerMolecule.prototype, "placeholder", void 0);
__decorate([
    property({ type: String, attribute: 'variant' })
], SingleOptionPickerMolecule.prototype, "variant", void 0);
__decorate([
    state()
], SingleOptionPickerMolecule.prototype, "activeIndex", void 0);
SingleOptionPickerMolecule = __decorate([
    customElement('molecules--group-select-one--single-option-picker-102020')
], SingleOptionPickerMolecule);
export { SingleOptionPickerMolecule };
