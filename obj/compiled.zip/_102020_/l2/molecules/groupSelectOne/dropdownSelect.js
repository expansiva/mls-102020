/// <mls fileReference="_102020_/l2/molecules/groupSelectOne/dropdownSelect.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// DROPDOWN SELECT (SELECT + ONE) MOLECULE
// =============================================================================
// Skill Group: groupSelectOne (select + one)
// Presentation-only. No backend calls. No global state.
// - No Shadow DOM
// - Slot Tags: Trigger, Value, Content, Group, Item, Empty
// - Full mouse + keyboard interaction
// - Click-outside to close
// =============================================================================
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_100554_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    empty: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        empty: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
/// **collab_i18n_end**
let DropdownSelectMolecule = class DropdownSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];
        // ===========================================================================
        // PROPERTIES — Contract (select + one)
        // ===========================================================================
        this.value = null;
        this.disabled = false;
        this.readonly = false;
        this.loading = false;
        this.required = false;
        this.name = '';
        this.error = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        /** Active option value used for keyboard navigation */
        this.activeValue = null;
        this.onDocumentPointerDownBound = (ev) => this.onDocumentPointerDown(ev);
        this.onTriggerBlur = (e) => {
            // Only emit blur when focus truly leaves the component.
            const next = e.relatedTarget;
            if (next && this.contains(next))
                return;
            this.emitBlur();
        };
        this.onTriggerClick = () => {
            if (this.interactiveBlocked)
                return;
            this.toggle();
        };
        this.onTriggerKeyDown = (e) => {
            if (this.interactiveBlocked)
                return;
            const key = e.key;
            // Open behaviors
            if (!this.isOpen) {
                if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Enter' || key === ' ') {
                    e.preventDefault();
                    this.open();
                    // When opening with ArrowUp, set active to last enabled
                    if (key === 'ArrowUp') {
                        const enabled = this.getEnabledItems();
                        this.activeValue = enabled.length ? enabled[enabled.length - 1].value : null;
                    }
                    return;
                }
                return;
            }
            // When open: navigation + selection
            if (key === 'Escape') {
                e.preventDefault();
                this.close(false);
                return;
            }
            if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Home' || key === 'End') {
                e.preventDefault();
                this.moveActive(key);
                return;
            }
            if (key === 'Enter') {
                e.preventDefault();
                if (this.activeValue) {
                    this.trySelect(this.activeValue);
                }
                return;
            }
        };
        this.onItemPointerDown = (e) => {
            // Prevent focus leaving trigger (which would produce blur) before we handle selection
            // Only do this when open and interactive.
            if (!this.isOpen || this.interactiveBlocked)
                return;
            e.preventDefault();
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('pointerdown', this.onDocumentPointerDownBound, { capture: true });
    }
    disconnectedCallback() {
        document.removeEventListener('pointerdown', this.onDocumentPointerDownBound, { capture: true });
        super.disconnectedCallback();
    }
    updated(changed) {
        // If options change while open, ensure activeValue remains valid.
        if (changed.has('isOpen') || changed.has('value')) {
            // no-op here; open handler sets active
        }
        if (this.isOpen) {
            const items = this.getEnabledItems();
            if (items.length === 0) {
                this.activeValue = null;
                return;
            }
            // Keep activeValue valid
            const activeIsEnabled = this.activeValue
                ? items.some(i => i.value === this.activeValue)
                : false;
            if (!activeIsEnabled) {
                this.activeValue = this.getInitialActiveValue();
            }
            // Ensure active item is visible when navigating
            queueMicrotask(() => this.scrollActiveIntoView());
        }
    }
    // ===========================================================================
    // DERIVED / HELPERS
    // ===========================================================================
    get interactiveBlocked() {
        return this.disabled || this.readonly || this.loading;
    }
    get allItemsFlat() {
        // Includes group + standalone items, in DOM order (Content > Item, Content > Group > Item)
        return this.getItems();
    }
    getEnabledItems() {
        return this.allItemsFlat.filter(i => !i.disabled);
    }
    getInitialActiveValue() {
        const enabled = this.getEnabledItems();
        if (enabled.length === 0)
            return null;
        // Prefer selected (if enabled), else first enabled
        if (this.value) {
            const selectedEnabled = enabled.find(i => i.value === this.value);
            if (selectedEnabled)
                return selectedEnabled.value;
        }
        return enabled[0].value;
    }
    isError() {
        return !!this.error;
    }
    getPlaceholder() {
        // Contract allows placeholder at Trigger or Value
        return (this.getSlotAttr('Value', 'placeholder') ||
            this.getSlotAttr('Trigger', 'placeholder') ||
            this.msg.placeholder);
    }
    getSelectedLabel() {
        const selected = this.findItem(this.value);
        return selected?.label ?? '';
    }
    getTriggerId() {
        // Stable enough for aria-controls
        const base = this.name?.trim() ? this.name.trim() : 'dropdown';
        return `dds-${base}-trigger`;
    }
    getListboxId() {
        const base = this.name?.trim() ? this.name.trim() : 'dropdown';
        return `dds-${base}-listbox`;
    }
    getOptionDomId(value) {
        // Basic escape: keep deterministic id
        const safe = value.replace(/[^a-zA-Z0-9_-]/g, '_');
        const base = this.name?.trim() ? this.name.trim() : 'dropdown';
        return `dds-${base}-opt-${safe}`;
    }
    getTriggerClasses() {
        const base = [
            'w-full',
            'flex items-center justify-between gap-3',
            'rounded-lg border',
            'px-3 py-2',
            'text-sm',
            'transition',
            'select-none',
            'bg-white',
        ];
        const states = [
            this.interactiveBlocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer',
            this.isOpen ? 'ring-2 ring-sky-500 border-sky-500' : 'hover:bg-slate-50',
            this.isError() ? 'border-rose-500 ring-rose-200' : 'border-slate-300',
        ];
        return [...base, ...states].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'absolute z-50 mt-1 w-full',
            'rounded-lg border border-slate-200 bg-white shadow-lg',
            'max-h-64 overflow-auto',
            'p-1',
        ].join(' ');
    }
    getGroupLabelClasses() {
        return ['px-2 py-1 text-xs font-semibold text-slate-500'].join(' ');
    }
    getOptionClasses(item, isSelected, isActive) {
        const base = [
            'w-full',
            'text-left',
            'rounded-md',
            'px-2 py-2',
            'text-sm',
            'transition',
            'flex items-center gap-2',
        ];
        // Visual distinction:
        // - selected: persistent highlight (sky)
        // - active: keyboard focus highlight (amber) distinct from selected
        // If both, keep selected background but add an outline to indicate active.
        const selectedStyles = isSelected ? 'bg-sky-50 text-sky-900' : 'text-slate-900';
        const activeStyles = isActive
            ? (isSelected
                ? 'ring-2 ring-amber-400'
                : 'bg-amber-50 text-slate-900 ring-2 ring-amber-300')
            : '';
        const hoverStyles = !item.disabled && !this.interactiveBlocked ? 'hover:bg-slate-50' : '';
        const disabledStyles = item.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer';
        return [...base, selectedStyles, activeStyles, hoverStyles, disabledStyles].filter(Boolean).join(' ');
    }
    scrollActiveIntoView() {
        if (!this.isOpen || !this.activeValue)
            return;
        const id = this.getOptionDomId(this.activeValue);
        const el = this.querySelector(`#${CSS.escape(id)}`);
        el?.scrollIntoView({ block: 'nearest' });
    }
    // ===========================================================================
    // OPEN / CLOSE
    // ===========================================================================
    open() {
        if (this.interactiveBlocked)
            return;
        if (this.isOpen)
            return;
        this.isOpen = true;
        this.activeValue = this.getInitialActiveValue();
        // Keep focus on trigger (combobox pattern)
        queueMicrotask(() => {
            const trigger = this.getTriggerEl();
            trigger?.focus();
            this.scrollActiveIntoView();
        });
    }
    close(emitBlur = false) {
        if (!this.isOpen)
            return;
        this.isOpen = false;
        // Do not clear activeValue; keep it for re-open heuristics if needed.
        if (emitBlur)
            this.emitBlur();
    }
    toggle() {
        if (this.isOpen)
            this.close(false);
        else
            this.open();
    }
    // ===========================================================================
    // EVENTS
    // ===========================================================================
    emitChange(nextValue) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: nextValue },
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    getTriggerEl() {
        return this.querySelector('button[data-trigger="true"]');
    }
    moveActive(key) {
        const enabled = this.getEnabledItems();
        if (enabled.length === 0) {
            this.activeValue = null;
            return;
        }
        if (key === 'Home') {
            this.activeValue = enabled[0].value;
            return;
        }
        if (key === 'End') {
            this.activeValue = enabled[enabled.length - 1].value;
            return;
        }
        const currentIndex = this.activeValue
            ? enabled.findIndex(i => i.value === this.activeValue)
            : -1;
        let nextIndex = currentIndex;
        if (key === 'ArrowDown') {
            nextIndex = currentIndex < 0 ? 0 : Math.min(enabled.length - 1, currentIndex + 1);
        }
        else {
            nextIndex = currentIndex < 0 ? enabled.length - 1 : Math.max(0, currentIndex - 1);
        }
        this.activeValue = enabled[nextIndex]?.value ?? enabled[0].value;
    }
    trySelect(value) {
        if (this.interactiveBlocked)
            return;
        const item = this.allItemsFlat.find(i => i.value === value);
        if (!item || item.disabled)
            return;
        // Only fire change on user action selection
        this.value = value;
        this.emitChange(value);
        this.close(false);
        // Keep focus on trigger after selection
        queueMicrotask(() => this.getTriggerEl()?.focus());
    }
    onItemClick(value, disabled) {
        if (disabled)
            return;
        this.trySelect(value);
    }
    onDocumentPointerDown(ev) {
        if (!this.isOpen)
            return;
        const target = ev.target;
        if (!target)
            return;
        if (this.contains(target))
            return;
        this.close(false);
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderTriggerContent() {
        const selectedLabel = this.getSelectedLabel();
        const placeholder = this.getPlaceholder();
        const hasSelection = !!selectedLabel;
        // If user provided <Trigger> content, we render it (minus the hidden slot tags).
        // Otherwise render a default trigger UI.
        const hasCustomTrigger = this.hasSlot('Trigger');
        const labelClasses = [
            'min-w-0 flex-1 truncate',
            hasSelection ? 'text-slate-900' : 'text-slate-500',
        ].join(' ');
        const chevronClasses = [
            'shrink-0',
            'text-slate-400',
            this.isOpen ? 'rotate-180 transition-transform' : 'transition-transform',
        ].join(' ');
        if (hasCustomTrigger) {
            // Contract: <Value/> placeholder is in slot tags, but we still must show selected/placeholder.
            // We render the custom Trigger innerHTML as plain content, but ensure the value text exists.
            // Approach: render a default value label and let custom trigger provide extra adornments.
            const customHtml = this.getSlotContent('Trigger');
            return html `
        <span class=${labelClasses}>${hasSelection ? selectedLabel : placeholder}</span>
        <span class=${chevronClasses} aria-hidden="true">▾</span>
        ${customHtml ? html `<span class="hidden">${nothing}</span>` : nothing}
      `;
        }
        return html `
      <span class=${labelClasses}>${hasSelection ? selectedLabel : placeholder}</span>
      <span class=${chevronClasses} aria-hidden="true">▾</span>
    `;
    }
    renderEmpty() {
        const emptyContent = this.getSlotContent('Empty');
        const text = emptyContent?.trim() ? nothing : html `<span>${this.msg.empty}</span>`;
        return html `
      <div class="px-2 py-2 text-sm text-slate-500">
        ${emptyContent?.trim() ? html `${emptyContent}` : text}
      </div>
    `;
    }
    renderOptions2() {
        const groups = this.getGroups();
        const standalone = this.getStandaloneItems();
        const anyItems = this.allItemsFlat.length > 0;
        if (!anyItems)
            return this.renderEmpty();
        const renderItem = (item) => {
            const isSelected = item.value === this.value;
            const isActive = item.value === this.activeValue;
            const optionId = this.getOptionDomId(item.value);
            return html `
        <div
          id=${optionId}
          role="option"
          aria-selected=${isSelected ? 'true' : 'false'}
          aria-disabled=${item.disabled ? 'true' : 'false'}
          class=${this.getOptionClasses(item, isSelected, isActive)}
          @pointerdown=${this.onItemPointerDown}
          @click=${() => this.onItemClick(item.value, item.disabled)}
        >
          <span class="min-w-0 flex-1 truncate">${html `${item.label}`}</span>
          ${isSelected
                ? html `<span class="shrink-0 text-sky-600" aria-hidden="true">✓</span>`
                : nothing}
        </div>
      `;
        };
        return html `
      ${standalone.length
            ? html `<div class="space-y-1">${standalone.map(renderItem)}</div>`
            : nothing}

      ${groups.map(group => html `
        <div class="mt-1">
          ${group.label
            ? html `<div class=${this.getGroupLabelClasses()}>${group.label}</div>`
            : nothing}
          <div class="space-y-1">
            ${group.items.map(renderItem)}
          </div>
        </div>
      `)}
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] ?? messages.en;
        const triggerId = this.getTriggerId();
        const listboxId = this.getListboxId();
        const selected = this.findItem(this.value);
        const activeOptionId = this.isOpen && this.activeValue ? this.getOptionDomId(this.activeValue) : undefined;
        // Loading state blocks interaction and shows message
        if (this.loading) {
            return html `
        <div class="w-full">
          <button
            type="button"
            data-trigger="true"
            class=${this.getTriggerClasses()}
            disabled
            aria-busy="true"
          >
            <span class="min-w-0 flex-1 truncate text-slate-500">${this.msg.loading}</span>
            <span class="shrink-0 text-slate-400" aria-hidden="true">⏳</span>
          </button>
        </div>
      `;
        }
        return html `
      <div class="relative w-full">
        <button
          id=${triggerId}
          type="button"
          data-trigger="true"
          class=${this.getTriggerClasses()}
          ?disabled=${this.disabled}
          aria-haspopup="listbox"
          aria-controls=${listboxId}
          aria-expanded=${this.isOpen ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : 'false'}
          aria-readonly=${this.readonly ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          aria-invalid=${this.isError() ? 'true' : 'false'}
          aria-activedescendant=${activeOptionId ?? nothing}
          @click=${this.onTriggerClick}
          @keydown=${this.onTriggerKeyDown}
          @blur=${this.onTriggerBlur}
        >
          ${this.renderTriggerContent()}
        </button>

        ${this.isOpen
            ? html `
              <div
                id=${listboxId}
                class=${this.getPanelClasses()}
                role="listbox"
                aria-labelledby=${triggerId}
              >
                ${this.renderOptions2()}
              </div>
            `
            : nothing}

        ${this.isError() && typeof this.error === 'string' && this.error.trim()
            ? html `<div class="mt-1 text-xs text-rose-600">${this.error}</div>`
            : nothing}

        ${this.name
            ? html `<input type="hidden" name=${this.name} value=${selected?.value ?? ''} />`
            : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], DropdownSelectMolecule.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], DropdownSelectMolecule.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], DropdownSelectMolecule.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], DropdownSelectMolecule.prototype, "loading", void 0);
__decorate([
    property({ type: Boolean })
], DropdownSelectMolecule.prototype, "required", void 0);
__decorate([
    property({ type: String })
], DropdownSelectMolecule.prototype, "name", void 0);
__decorate([
    property({ type: String })
], DropdownSelectMolecule.prototype, "error", void 0);
__decorate([
    state()
], DropdownSelectMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], DropdownSelectMolecule.prototype, "activeValue", void 0);
DropdownSelectMolecule = __decorate([
    customElement('molecules--group-select-one--dropdown-select-102020')
], DropdownSelectMolecule);
export { DropdownSelectMolecule };
