/// <mls fileReference="_102020_/l2/dsMatch/filterVariants.ts" enhancement="_blank" />
export function filterCompatibleVariants(group, dsRules, configuredAxes, catalog) {
    // Pass 1 — drop variants that contradict a configured axis they declare.
    let candidates = catalog.filter(m => {
        if (m.group !== group)
            return false;
        for (const [axis, value] of Object.entries(m.layoutConfig)) {
            if (configuredAxes.has(axis) && dsRules[axis] !== value)
                return false;
        }
        return true;
    });
    // Pass 2 — per configured axis (sorted for determinism): explicit match beats wildcard.
    for (const axis of [...configuredAxes].sort()) {
        const declaring = candidates.filter(m => axis in m.layoutConfig);
        if (declaring.length > 0 && declaring.length < candidates.length)
            candidates = declaring;
    }
    return candidates;
}
