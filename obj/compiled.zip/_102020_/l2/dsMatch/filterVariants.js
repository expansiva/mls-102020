/// <mls fileReference="_102020_/l2/dsMatch/filterVariants.ts" enhancement="_blank" />
export function filterCompatibleVariants(group, dsRules, configuredAxes, catalog) {
    return catalog.filter(m => {
        if (m.group !== group)
            return false;
        for (const [axis, value] of Object.entries(m.layoutConfig)) {
            if (configuredAxes.has(axis) && dsRules[axis] !== value)
                return false;
        }
        return true;
    });
}
