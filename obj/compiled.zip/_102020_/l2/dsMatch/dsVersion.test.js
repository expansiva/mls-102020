/// <mls fileReference="_102020_/l2/dsMatch/dsVersion.test.ts" enhancement="_blank" />
// Tests for the pure parts of dsVersion. No mls runtime. Exposes `runDsVersionTests()`.
import { effectiveRulesSignature, moleculeContentSignature, parseUsedMolecules, decidePageDsStatus, renderDsVersionExport, } from '/_102020_/l2/dsMatch/dsVersion.js';
function assert(cond, msg) { if (!cond)
    throw new Error(`[dsVersion.test] FAIL: ${msg}`); }
function mol(project, group, tag, layoutConfig = {}, description = `desc-${tag}`) {
    return { project, group, tag, variant: tag, layoutConfig, objective: '', description, usagePath: '' };
}
function ds(rules) { return rules; }
export function runDsVersionTests() {
    let passed = 0;
    // ── effectiveRulesSignature ──────────────────────────────────────────────
    {
        assert(effectiveRulesSignature({ boolean: 'toggle', recordsView: 'table' }) ===
            effectiveRulesSignature({ recordsView: 'table', boolean: 'toggle' }), 'rules signature should be order-independent');
        assert(effectiveRulesSignature({ recordsView: 'table' }) !== effectiveRulesSignature({ recordsView: 'grid' }), 'value change should change hash');
        assert(effectiveRulesSignature({}) === effectiveRulesSignature({}), 'empty rules should be stable');
        passed++;
    }
    // ── moleculeContentSignature (definition / description) ───────────────────
    {
        const a = moleculeContentSignature(mol(102040, 'g', 'ml-x', {}, 'same'));
        const b = moleculeContentSignature(mol(102040, 'g', 'ml-x', {}, 'same'));
        const c = moleculeContentSignature(mol(102040, 'g', 'ml-x', {}, 'changed'));
        assert(a === b, 'same description → same signature');
        assert(a !== c, 'changed description → changed signature');
        passed++;
    }
    // ── parseUsedMolecules ────────────────────────────────────────────────────
    {
        const src = `export const moleculeAssignments = ${JSON.stringify([
            { organismName: 'A', molecules: [{ project: 102040, group: 'g1', tag: 'ml-toast' }] },
            { organismName: 'B', molecules: [{ project: 102040, group: 'g1', tag: 'ml-toast' }, { project: 102041, group: 'g2', tag: 'ml-grid' }] },
        ], null, 2)} as const;`;
        assert(parseUsedMolecules(src).length === 2, 'should flatten + dedupe to 2 molecules');
        assert(parseUsedMolecules('nothing here').length === 0, 'missing export → empty');
        passed++;
    }
    // ── decidePageDsStatus ────────────────────────────────────────────────────
    const catalog = [
        mol(102040, 'groupNotifyUser', 'ml-toast', { feedback: 'toast' }, 'v1'),
        mol(102041, 'groupViewData', 'ml-grid', { recordsView: 'grid' }, 'v1'), // different source project
    ];
    const used = [{ project: 102040, tag: 'ml-toast' }];
    const rules = ds({ feedback: 'toast' });
    const configuredAxes = new Set(['feedback']);
    const freshStamp = {
        ds: 2, dsName: 'X', rulesHash: effectiveRulesSignature({ feedback: 'toast' }),
        moleculesSeen: { '102040|ml-toast': moleculeContentSignature(catalog[0]) }, generatedAt: 't',
    };
    const base = { used, catalog, rules, configuredAxes, currentRulesHash: effectiveRulesSignature({ feedback: 'toast' }) };
    // 4. No stamp → stale.
    {
        assert(decidePageDsStatus({ ...base, stamp: null }) === 'stale', 'no stamp → stale');
        passed++;
    }
    // 5. Everything matches → fresh.
    {
        assert(decidePageDsStatus({ ...base, stamp: freshStamp }) === 'fresh', 'all unchanged → fresh');
        passed++;
    }
    // 6. Rules changed → stale.
    {
        assert(decidePageDsStatus({ ...base, stamp: { ...freshStamp, rulesHash: 'different' } }) === 'stale', 'rules change → stale');
        passed++;
    }
    // 7. Used molecule removed → stale.
    {
        assert(decidePageDsStatus({ ...base, catalog: [catalog[1]], stamp: freshStamp }) === 'stale', 'removed used molecule → stale');
        passed++;
    }
    // 8. Used molecule no longer compatible (DS now wants feedback=banner) → stale.
    {
        const rules2 = ds({ feedback: 'banner' });
        const status = decidePageDsStatus({
            ...base, rules: rules2, currentRulesHash: effectiveRulesSignature({ feedback: 'banner' }),
            stamp: { ...freshStamp, rulesHash: effectiveRulesSignature({ feedback: 'banner' }) },
        });
        assert(status === 'stale', 'incompatible used molecule → stale');
        passed++;
    }
    // 9. Unrelated molecule (other project, not used) changed → still fresh.
    {
        const catalog2 = [catalog[0], mol(102041, 'groupViewData', 'ml-grid', { recordsView: 'grid' }, 'v2-changed')];
        assert(decidePageDsStatus({ ...base, catalog: catalog2, stamp: freshStamp }) === 'fresh', 'unrelated change → fresh');
        passed++;
    }
    // 10. Used molecule changed (still present + compatible) → review.
    {
        const catalog2 = [mol(102040, 'groupNotifyUser', 'ml-toast', { feedback: 'toast' }, 'v2-changed'), catalog[1]];
        assert(decidePageDsStatus({ ...base, catalog: catalog2, stamp: freshStamp }) === 'review', 'used molecule changed → review');
        passed++;
    }
    // ── renderDsVersionExport ─────────────────────────────────────────────────
    {
        const stamp = { ds: 2, dsName: 'Collab design', rulesHash: 'ab12cd34', moleculesSeen: { '102040|ml-toast': '9f2a' }, generatedAt: '2026-06-22T10:00:00Z' };
        const src = renderDsVersionExport(stamp);
        assert(src.startsWith('export const dsVersion = ') && src.trimEnd().endsWith('as const;'), 'valid as-const export');
        assert(src.includes('"moleculesSeen"'), 'should carry moleculesSeen');
        passed++;
    }
    return { passed };
}
