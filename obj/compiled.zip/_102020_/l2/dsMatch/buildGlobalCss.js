/// <mls fileReference="_102020_/l2/dsMatch/buildGlobalCss.ts" enhancement="_blank" />
// Color role → CSS var name (most roles map 1:1; `background` shortens to `bg`).
const COLOR_VAR_ALIAS = { background: 'bg' };
const colorVar = (role) => `--ds-${COLOR_VAR_ALIAS[role] ?? role}`;
// Semantic radius scale → concrete length (mirrors Tailwind's rounded-* values).
const RADIUS_LENGTH = {
    none: '0',
    sm: '0.25rem',
    md: '0.375rem',
    lg: '0.5rem',
    full: '9999px',
};
function borderWidthLength(value) {
    if (value == null)
        return null;
    const v = String(value).trim();
    if (!v)
        return null;
    return /^\d+$/.test(v) ? `${v}px` : v;
}
/**
 * Every `--ds-*` var this DS emits (color roles + font roles + shape). Used by the
 * reconciliation agent (as the target vocabulary) and to validate its output.
 */
export function dsVarNames(tokens) {
    const names = [];
    for (const role of Object.keys(tokens.color ?? {}))
        names.push(colorVar(role));
    const fonts = tokens.typography?.fonts;
    if (Array.isArray(fonts) && fonts.length) {
        for (const f of fonts)
            if (f?.name)
                names.push(`--ds-font-${f.name}`);
    }
    else {
        if (tokens.typography?.fontDisplay)
            names.push('--ds-font-display');
        if (tokens.typography?.fontBody)
            names.push('--ds-font-body');
    }
    if (tokens.shape?.radius && RADIUS_LENGTH[tokens.shape.radius] != null)
        names.push('--ds-radius');
    if (borderWidthLength(tokens.shape?.borderWidth))
        names.push('--ds-border-w');
    return [...new Set(names)];
}
