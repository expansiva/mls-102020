/// <mls fileReference="_102020_/l2/dsMatch/resolveRulesForPage.ts" enhancement="_blank" />
// G1 — DS rule cascade: project → module → page (per page file).
// All three live centrally in project.json under designSystems[ds]:
//   rules           (project, today)
//   moduleOverrides : { [module]: Partial<rules> }
//   pageOverrides   : { ["{module}/{pageName}"]: Partial<rules> }
//
// The more specific level wins. A value of "unset" at any level REMOVES the axis from the
// configured set (relaxing it — the filter then imposes no constraint on that axis).
// Only valid axis values survive (invalid ones are ignored, like readDsRules).
//
// `resolveRulesForPage` returns { rules, configuredAxes } in one pass — drop-in for the
// project-level readDsRules + readConfiguredAxisKeys used by Agent2 (filterCompatibleVariants).
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { dsDefaults, isValidAxisValue } from '/_102020_/l2/designSystemAuraBase.js';
/** Sentinel value that removes an inherited rule (relax the axis). Not a valid axis value. */
export const UNSET = 'unset';
/** Walk the levels (project → module → page) tracking each axis's final value + origin. */
function cascade(levels) {
    const effective = {};
    const unset = new Set();
    for (const { source, rules } of levels) {
        if (!rules || typeof rules !== 'object')
            continue;
        for (const [axis, value] of Object.entries(rules)) {
            if (typeof value !== 'string')
                continue;
            if (value === UNSET) {
                delete effective[axis];
                unset.add(axis);
                continue;
            }
            if (!isValidAxisValue(axis, value))
                continue; // ignore invalid (vocabulary-checked)
            effective[axis] = { value, source };
            unset.delete(axis); // a later concrete value cancels an earlier unset
        }
    }
    return { effective, unset };
}
/** Pure: merge the 3 levels into the configured axis→value map (post-unset). */
export function mergeRuleLevels(projectRules, moduleOverride, pageOverride) {
    const { effective } = cascade([
        { source: 'project', rules: projectRules },
        { source: 'module', rules: moduleOverride },
        { source: 'page', rules: pageOverride },
    ]);
    const out = {};
    for (const [axis, p] of Object.entries(effective))
        out[axis] = p.value;
    return out;
}
/** Pure: fill every unset axis with the vocabulary default → full ResolvedDs. */
export function toResolvedDs(configured) {
    const resolved = dsDefaults();
    for (const [axis, value] of Object.entries(configured))
        resolved[axis] = value;
    return resolved;
}
/**
 * Pure: per-axis provenance (value + which level set it) + the set of axes explicitly
 * `unset` at some level. Used by the scope-aware plugin (G3) to show inherited vs overridden.
 */
export function effectiveRulesProvenance(projectRules, moduleOverride, pageOverride) {
    return cascade([
        { source: 'project', rules: projectRules },
        { source: 'module', rules: moduleOverride },
        { source: 'page', rules: pageOverride },
    ]);
}
// ─── runtime ────────────────────────────────────────────────────────────────
/** Read the project/module/page buckets of a DS from project.json. */
async function readDsBuckets(project, dsIndex, module, page) {
    const config = await getConfigProject(project);
    const ds = config?.designSystems?.[String(dsIndex)];
    if (!ds)
        throw new Error(`[resolveRulesForPage] designSystem '${dsIndex}' not found in project ${project}`);
    return {
        projectRules: (ds.rules && typeof ds.rules === 'object') ? ds.rules : {},
        moduleOverride: ds.moduleOverrides?.[module],
        pageOverride: ds.pageOverrides?.[`${module}/${page}`],
    };
}
/** Resolve the effective DS rules + configured axes for a specific page (cascade). */
export async function resolveRulesForPage(project, module, page, dsIndex) {
    const { projectRules, moduleOverride, pageOverride } = await readDsBuckets(project, dsIndex, module, page);
    const configured = mergeRuleLevels(projectRules, moduleOverride, pageOverride);
    return { rules: toResolvedDs(configured), configuredAxes: new Set(Object.keys(configured)) };
}
