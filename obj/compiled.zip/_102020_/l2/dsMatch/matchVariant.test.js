/// <mls fileReference="_102020_/l2/dsMatch/matchVariant.test.ts" enhancement="_blank" />
// Tests for matchVariant (Fase A3). matchVariant is pure, so it runs without the
// `mls` runtime. There is no test framework in the repo: this exports
// `runMatchVariantTests()`, which throws on failure and returns the case count on success.
import { matchVariant } from '/_102020_/l2/dsMatch/matchVariant.js';
function entry(group, variant, layoutConfig) {
    return { project: 102040, group, variant, tag: `${group.toLowerCase()}--${variant}`, layoutConfig, objective: '', usagePath: '' };
}
function ds(rules) {
    return rules;
}
function assert(cond, msg) {
    if (!cond)
        throw new Error(`[matchVariant.test] FAIL: ${msg}`);
}
function tag(r) {
    return r ? r.entry.variant : '<null>';
}
export function runMatchVariantTests() {
    let passed = 0;
    // Sample catalog — ORDER matters (it is the tie-break).
    const catalog = [
        entry('groupEnterText', 'ml-enter-text', {}), // wildcard
        entry('groupEnterText', 'ml-floating-text-input', { labelPlacement: 'floating' }),
        entry('groupEnterText', 'ml-floating-alt', { labelPlacement: 'floating' }), // ties with the previous
        entry('groupEnterText', 'ml-compact-floating', { labelPlacement: 'floating', density: 'compact' }),
        entry('groupNotifyUser', 'ml-toast', { feedback: 'toast' }),
        entry('groupNotifyUser', 'ml-banner', { feedback: 'banner' }),
    ];
    // 1. Simple match on a single axis.
    {
        const r = matchVariant('groupNotifyUser', ds({ feedback: 'toast' }), catalog);
        assert(tag(r) === 'ml-toast', `simple match expected ml-toast, got ${tag(r)}`);
        assert(r.matched && r.specificity === 1, 'simple match should be matched=true, spec=1');
        passed++;
    }
    // 2. Specificity: the 2-axis one beats the 1-axis one and the wildcard.
    {
        const r = matchVariant('groupEnterText', ds({ labelPlacement: 'floating', density: 'compact' }), catalog);
        assert(tag(r) === 'ml-compact-floating', `specificity expected ml-compact-floating, got ${tag(r)}`);
        assert(r.specificity === 2, 'specificity should be 2');
        passed++;
    }
    // 3. Tie (same specificity) → first in catalog order.
    {
        // density != compact, so ml-compact-floating is eliminated; two spec-1 remain.
        const r = matchVariant('groupEnterText', ds({ labelPlacement: 'floating', density: 'comfortable' }), catalog);
        assert(tag(r) === 'ml-floating-text-input', `tie expected the first (ml-floating-text-input), got ${tag(r)}`);
        passed++;
    }
    // 4. Wildcard wins when no specific one matches (labelPlacement=top).
    {
        const r = matchVariant('groupEnterText', ds({ labelPlacement: 'top' }), catalog);
        assert(tag(r) === 'ml-enter-text', `wildcard expected ml-enter-text, got ${tag(r)}`);
        assert(r.matched === true && r.specificity === 0, 'wildcard should be matched=true, spec=0');
        passed++;
    }
    // 5. Fallback: a group where nothing matches AND there is no wildcard.
    {
        const r = matchVariant('groupNotifyUser', ds({ feedback: 'inline' }), catalog);
        assert(tag(r) === 'ml-toast', `fallback expected the group's first (ml-toast), got ${tag(r)}`);
        assert(r.matched === false, 'fallback should be matched=false');
        passed++;
    }
    // 6. Non-existent group → null.
    {
        const r = matchVariant('groupDoesNotExist', ds({}), catalog);
        assert(r === null, 'non-existent group should return null');
        passed++;
    }
    // 7. Determinism: two identical calls → same result (cross-page consistency).
    {
        const a = matchVariant('groupEnterText', ds({ labelPlacement: 'floating', density: 'comfortable' }), catalog);
        const b = matchVariant('groupEnterText', ds({ labelPlacement: 'floating', density: 'comfortable' }), catalog);
        assert(tag(a) === tag(b), 'same input should yield the same molecule');
        passed++;
    }
    console.log(`[matchVariant.test] OK — ${passed} cases`);
    return { passed };
}
