/// <mls fileReference="_102020_/l2/agentNewReleaseL2/helpers/steps.ts" enhancement="_blank"/>
import { checkAfterDefs, snapshotOf } from '/_102020_/l2/agentNewReleaseL2/helpers/guard.js';
import { collectExactModuleFiles, displayPath, fileExists, moduleFile, moduleFolder, readJson, readSourceText, writeJson, } from '/_102035_/l2/solution/fs.js';
export const NR_AGENT_NAME = 'agentNewReleaseL2';
export const NR_HELP = 'Usage: @@agentNewReleaseL2 <module>';
export const NR_DEFS_AGENT = 'agentDefsL2';
export const NR_DEFS_PLAN = 'defs';
export const NR_DEFS_SCOPE = 'all';
export const NR_CHECK_PLAN = 'check';
export const NR_MATERIALIZE_AGENT = 'agentMaterializeL2';
export const NR_MATERIALIZE_PLAN = 'materialize';
export const NR_CLOSE_PLAN = 'close';
export const NR_MARKS_DIFFER = 'planner conversation not run or marks differ';
export const NR_NOTHING_TO_APPLY = 'nothing to apply';
export function statusKind(message) {
    if (message === NR_HELP || message === NR_NOTHING_TO_APPLY)
        return 'done';
    return 'refused';
}
export function statusText(message, kind = statusKind(message)) {
    const prefix = `${kind}: `;
    return message.startsWith(prefix) ? message : `${prefix}${message}`;
}
/** Short motive. The full text stays in the step result. Both start with the same prefix. */
export function statusStepTitle(message) {
    const compact = message.replace(/\s+/gu, ' ').trim();
    return compact.length <= 72 ? compact : `${compact.slice(0, 69)}...`;
}
export function statusIntents(agentName, threadId, userMessage, message, kind) {
    const text = statusText(message, kind);
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName,
            inputAI: [
                { type: 'system', content: text },
                { type: 'human', content: text },
            ],
            taskTitle: NR_AGENT_NAME,
            threadId,
            userMessage,
            longTermMemory: {
                taskName: NR_AGENT_NAME,
                flowName: NR_AGENT_NAME,
                statusOnly: 'true',
                notice: text,
            },
        },
    };
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: statusStepTitle(text),
        result: text,
        planning: { planId: 'status', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    };
    const step = {
        type: 'add-step',
        messageId: '',
        threadId,
        taskId: '',
        parentStepId: 1,
        step: result,
    };
    return [addMessage, step];
}
export function parseNrInvocation(value) {
    const raw = String(value || '').replace(/^@@agentNewReleaseL2\b/i, ' ').trim();
    const tokens = raw.split(/\s+/u).filter(Boolean);
    if (tokens.length !== 1)
        return { ok: false, help: NR_HELP };
    return { ok: true, module: tokens[0] };
}
export function currentProjectNumber() {
    return Number(mls.actualProject || 0);
}
export function changeEffortInfo(moduleName) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: base.level,
        folder: `${base.folder}/pool/l4`,
        shortName: 'changeEffort',
        extension: '.json',
    };
}
export async function readChangeEffort(moduleName) {
    const info = changeEffortInfo(moduleName);
    const path = displayPath(info);
    if (!fileExists(info))
        return { ok: false, reason: `changeEffort.json is missing at ${path}` };
    const effort = await readJson(info);
    if (effort === null)
        return { ok: false, reason: `changeEffort.json at ${path} is not valid JSON` };
    return { ok: true, effort };
}
export function materializePrompt(project, moduleName) {
    return JSON.stringify({ project, module: moduleName, scope: {} });
}
export function defsPrompt(project, moduleName, bffPages) {
    return JSON.stringify({ project, module: moduleName, scope: NR_DEFS_SCOPE, bffPages: [...bffPages] });
}
function listedPath(file) {
    return displayPath({
        project: Number(file.project || 0),
        level: Number(file.level || 0),
        folder: String(file.folder || ''),
        shortName: String(file.shortName || ''),
        extension: String(file.extension || ''),
    });
}
function isLiveListed(file) {
    return file.status !== 'deleted' && Number(file.level) === 2 && Number(file.project) === currentProjectNumber();
}
/**
 * Generated files of one page that are in the current project index.
 * `<pageId>.ts` under each device/genome folder that exists, always.
 * Shared `.ts` and shared `Dts.txt` only when `pageId` is in `sharedPages`.
 * A `.defs.ts` is never included.
 */
export function generatedFilesOf(moduleName, pageId, existing, sharedPages) {
    const web = `${moduleFolder(moduleName)}/web`;
    const slots = new Set();
    for (const file of existing) {
        if (!isLiveListed(file))
            continue;
        const rest = String(file.folder || '').slice(web.length + 1);
        if (!String(file.folder || '').startsWith(`${web}/`))
            continue;
        const parts = rest.split('/');
        if (parts.length !== 2 || parts[0] === 'shared' || parts[0] === 'contracts')
            continue;
        slots.add(`${parts[0]}/${parts[1]}`);
    }
    const wanted = new Set();
    if (sharedPages.includes(pageId)) {
        wanted.add(`l2/${web}/shared/${pageId}.ts`);
        wanted.add(`l2/${web}/shared/${pageId}Dts.txt`);
    }
    for (const slot of [...slots].sort())
        wanted.add(`l2/${web}/${slot}/${pageId}.ts`);
    const found = [];
    const seen = new Set();
    for (const file of existing) {
        if (!isLiveListed(file) || file.extension === '.defs.ts')
            continue;
        const path = listedPath(file);
        if (!wanted.has(path) || seen.has(path))
            continue;
        seen.add(path);
        found.push(file);
    }
    return [...found].sort((left, right) => listedPath(left).localeCompare(listedPath(right)));
}
/** Deletes the generated files of the effort pages. The first failure stops and names that path. */
export async function deleteGeneratedFiles(moduleName, pageIds, existing, remove, sharedPages) {
    const paths = [];
    for (const pageId of pageIds) {
        for (const file of generatedFilesOf(moduleName, pageId, existing, sharedPages)) {
            const path = listedPath(file);
            try {
                await remove(file);
            }
            catch (error) {
                const detail = error instanceof Error ? error.message : String(error);
                return { ok: false, message: `failed to delete ${path}: ${detail}` };
            }
            paths.push(path);
        }
    }
    return { ok: true, paths };
}
/** Pages whose generated files are deleted before the whole module is materialized. */
export function releasePages(pages, materializeOnly) {
    const seen = new Set(pages);
    const combined = [...pages];
    for (const id of materializeOnly) {
        if (seen.has(id))
            continue;
        seen.add(id);
        combined.push(id);
    }
    return combined;
}
export function poolEffortInfo(moduleName) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: base.level,
        folder: `${base.folder}/pool/l2/web`,
        shortName: 'effort',
        extension: '.json',
    };
}
export function snapshotInfo(moduleName) {
    return {
        project: currentProjectNumber(),
        level: 2,
        folder: `${moduleFolder(moduleName)}/pipeline/${NR_AGENT_NAME}`,
        shortName: 'snapshot',
        extension: '.json',
    };
}
/** `l2/<module>/pipeline/agentNewReleaseL2/run.json` — each write is one host trace line. */
export function runInfo(moduleName) {
    return { ...snapshotInfo(moduleName), shortName: 'run' };
}
export async function recordPhase(moduleName, phase, status, note, lists) {
    const info = runInfo(moduleName);
    const line = { phase, status, note };
    if (phase === 'plan' && lists && 'bffPages' in lists) {
        line.bffPages = [...lists.bffPages];
        line.sharedPages = [...lists.sharedPages];
    }
    if (phase === 'steps' && lists && 'deleted' in lists) {
        line.deleted = [...lists.deleted];
    }
    if (phase === 'effort-read') {
        await writeJson(info, { phases: [line] });
        return;
    }
    const current = await readJson(info);
    const phases = Array.isArray(current?.phases) ? [...current.phases] : [];
    phases.push(line);
    await writeJson(info, { phases });
}
/** `toCreate` and `toUpdate` page ids from the L2 pool effort. Anything else counts as unmarked. */
export function markedPageIds(effort) {
    if (!effort || typeof effort !== 'object')
        return [];
    const screens = effort.screens;
    if (!Array.isArray(screens))
        return [];
    const ids = [];
    for (const row of screens) {
        if (!row || typeof row !== 'object')
            continue;
        const pageId = String(row.pageId || '').trim();
        const status = String(row.status || '');
        if (!pageId || (status !== 'toCreate' && status !== 'toUpdate'))
            continue;
        ids.push(pageId);
    }
    return ids;
}
/** Null when the two sets are the same. Otherwise the refusal, with both lists. */
export function marksDifferMessage(marked, planned) {
    const left = [...marked].sort();
    const right = [...planned].sort();
    if (left.length === right.length && left.every((id, index) => id === right[index]))
        return null;
    return `${NR_MARKS_DIFFER}: marked [${left.join(', ')}]; planned [${right.join(', ')}]`;
}
export async function readPoolEffort(moduleName) {
    const info = poolEffortInfo(moduleName);
    if (!fileExists(info))
        return null;
    return readJson(info);
}
export async function readProductSnapshot(moduleName) {
    const files = [];
    for (const file of collectExactModuleFiles(moduleName, [2])) {
        if (file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        files.push({ path: displayPath(file), bytes: await readSourceText(file) });
    }
    return snapshotOf(files);
}
export async function writeReleaseSnapshot(moduleName, snapshot) {
    await writeJson(snapshotInfo(moduleName), snapshot);
}
export async function readReleaseSnapshot(moduleName) {
    const info = snapshotInfo(moduleName);
    if (!fileExists(info))
        return null;
    const value = await readJson(info);
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return null;
    const snapshot = {};
    for (const [path, hash] of Object.entries(value)) {
        if (typeof hash === 'string')
            snapshot[path] = hash;
    }
    return snapshot;
}
export async function guardAfterDefs(moduleName, pages) {
    const before = await readReleaseSnapshot(moduleName);
    if (!before)
        return null;
    const after = await readProductSnapshot(moduleName);
    return checkAfterDefs(before, after, pages);
}
function agentStep(agentName, planId, dependsOn, stepTitle, prompt) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName,
        prompt,
        rags: [],
        planning: {
            planId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
/** Defs generator first (`scope: all`), then this agent's check step. The check waits on the defs plan id. */
export function buildRegenerateSteps(project, moduleName, bffPages) {
    return [
        {
            ...agentStep(NR_DEFS_AGENT, NR_DEFS_PLAN, [], 'Regenerate page defs', defsPrompt(project, moduleName, bffPages)),
            onFailure: 'continue',
        },
        agentStep(NR_AGENT_NAME, NR_CHECK_PLAN, [NR_DEFS_PLAN], 'Check defs guard', JSON.stringify({ planId: NR_CHECK_PLAN })),
    ];
}
/** Materializer for the whole module, then this agent's close step. The close step waits on the materializer plan id. */
export function buildApplySteps(project, moduleName, deleted = [], commands = [], degrees = {}) {
    return [
        {
            ...agentStep(NR_MATERIALIZE_AGENT, NR_MATERIALIZE_PLAN, [], 'Materialize module', materializePrompt(project, moduleName)),
            onFailure: 'continue',
        },
        agentStep(NR_AGENT_NAME, NR_CLOSE_PLAN, [NR_MATERIALIZE_PLAN], 'Close release', JSON.stringify({ planId: NR_CLOSE_PLAN, deleted, commands, degrees })),
    ];
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string');
}
export function deletedPaths(prompt) {
    const parsed = JSON.parse(prompt || '{}');
    return stringList(parsed.deleted);
}
export function commandLines(prompt) {
    const parsed = JSON.parse(prompt || '{}');
    return stringList(parsed.commands);
}
/** Close text: refused pages first, then the materializer message, the deleted files, one cost line per planned page, then one line per command when it completed. */
export function closeNotice(materializerMessage, deleted, commands = [], completed = true, costLines = [], refused = []) {
    const listed = deleted.length ? deleted.join(', ') : 'none';
    const parts = [
        ...refused.map(item => `refused: ${item.page}: ${item.code}`),
        `${materializerMessage}; deleted: ${listed}`,
    ];
    if (costLines.length > 0)
        parts.push(costLines.join('\n'));
    if (completed && commands.length > 0)
        parts.push(commands.join('\n'));
    return parts.join('\n');
}
export function degreesOf(prompt) {
    const parsed = JSON.parse(prompt || '{}');
    return degreeRecord(parsed.degrees);
}
export function degreesFromMemory(value) {
    if (value === undefined || value === '')
        return {};
    return degreeRecord(JSON.parse(String(value)));
}
function degreeRecord(value) {
    if (value === undefined)
        return {};
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('degrees is not a page map');
    const degrees = {};
    for (const [pageId, degree] of Object.entries(value)) {
        if (!Number.isInteger(degree))
            throw new Error('degrees is not a page map');
        degrees[pageId] = degree;
    }
    return degrees;
}
const PAGE11_AGENT = 'agentD2PagesPage';
const BFF_AGENT = 'agentD2BffPage';
const CHAIN_AGENT = 'agentM4ChainPage';
function traceMicros(step) {
    const micros = [];
    for (const line of step.interaction?.trace ?? []) {
        for (const match of line.matchAll(/cost:\$([0-9]+(?:\.[0-9]+)?)/gu)) {
            micros.push(Math.round(Number(match[1]) * 10000));
        }
    }
    return micros;
}
function callKind(title) {
    if (title.startsWith('Page11 '))
        return 'page11';
    if (title.startsWith('BFF '))
        return 'bff';
    if (title.startsWith('Shared'))
        return 'shared';
    if (title.startsWith('Page desktop'))
        return 'desktop';
    if (title.startsWith('Page mobile'))
        return 'mobile';
    return null;
}
function pageOf(step, chainPage) {
    const title = step.stepTitle || '';
    const kind = callKind(title);
    if (!kind)
        return null;
    if (step.agentName === PAGE11_AGENT && kind === 'page11')
        return { pageId: title.slice('Page11 '.length).trim(), kind };
    if (step.agentName === BFF_AGENT && kind === 'bff')
        return { pageId: title.slice('BFF '.length).trim(), kind };
    if (chainPage && (kind === 'shared' || kind === 'desktop' || kind === 'mobile'))
        return { pageId: chainPage, kind };
    return null;
}
/**
 * One line per planned page, alphabetical.
 * A repair is a title containing `(repair`, the second cost line of the same step, or the second call of the same agent, page, and device.
 * Costs are summed in micro-dollars and rounded to cents once per page.
 */
export function screenCostLines(roots, degrees) {
    const totals = new Map();
    const seen = new Map();
    const visit = (steps, chainPage) => {
        for (const step of steps) {
            const nextChain = step.agentName === CHAIN_AGENT ? (step.stepTitle || '').trim() : chainPage;
            const named = pageOf(step, chainPage);
            if (named && Object.hasOwn(degrees, named.pageId)) {
                const key = `${step.agentName}|${named.pageId}|${named.kind}`;
                const titleRepair = (step.stepTitle || '').includes('(repair');
                const row = totals.get(named.pageId) ?? { calls: 0, repairs: 0, micros: 0 };
                let ordinal = seen.get(key) ?? 0;
                for (const micros of traceMicros(step)) {
                    ordinal += 1;
                    row.calls += 1;
                    row.micros += micros;
                    if (titleRepair || ordinal >= 2)
                        row.repairs += 1;
                }
                seen.set(key, ordinal);
                totals.set(named.pageId, row);
            }
            if (step.nextSteps?.length)
                visit(step.nextSteps, nextChain);
        }
    };
    visit(roots ?? [], null);
    return Object.keys(degrees).sort((left, right) => left.localeCompare(right)).map(pageId => {
        const row = totals.get(pageId) ?? { calls: 0, repairs: 0, micros: 0 };
        const cost = (Math.round(row.micros / 100) / 100).toFixed(2);
        return `${pageId} degrau ${degrees[pageId]}: ${row.calls} calls (${row.repairs} repair), ${cost} USD`;
    });
}
export function stepsPhaseNote(count, commands) {
    const base = `${count} steps`;
    return commands.length === 0 ? base : `${base}; ${commands.join('\n')}`;
}
/** Names each effort page whose generated files were not in the index. Empty when every page had one. */
export function stepsDeletedNote(base, missing) {
    if (missing.length === 0)
        return base;
    return `${base}; deleted: none for ${missing.join(', ')}`;
}
export function planIdOf(step) {
    return step.planning?.planId || '';
}
function namedOutcome(step, label) {
    if (!step)
        return { status: 'failed', message: `${label} step is missing` };
    const traces = step.interaction?.trace?.map(line => line.trim()).filter(Boolean) ?? [];
    const nested = (step.nextSteps || []).find(item => item.type === 'result');
    const resultText = nested && nested.type === 'result' ? String(nested.result || '').trim() : '';
    const message = traces[traces.length - 1] || resultText || `${label} ${step.status}`;
    return { status: step.status === 'completed' ? 'completed' : 'failed', message };
}
function payloadLines(step) {
    const lines = [];
    const visit = (item) => {
        for (const line of item.interaction?.trace ?? []) {
            for (const part of line.split('\n')) {
                const trimmed = part.trim();
                if (trimmed)
                    lines.push(trimmed);
            }
        }
        if (item.type === 'result') {
            for (const line of String(item.result || '').split('\n')) {
                const trimmed = line.trim();
                if (trimmed)
                    lines.push(trimmed);
            }
        }
        for (const child of item.nextSteps || [])
            visit(child);
    };
    visit(step);
    return lines;
}
const REFUSED_PAGES = /\d+\s+refused\s+\[([^\]]*)\]\./u;
const ERROR_PAGE = /^error\s+(\S+)\s+\[([^\]]+)\](.*)$/u;
const D2_CODE = /D2_[A-Z0-9_]+/u;
/** Pages the materializer refused, with the first D2_ code on that error line, else the error token. */
export function refusedPages(materialize) {
    if (!materialize)
        return [];
    const lines = payloadLines(materialize);
    const pages = [];
    const seen = new Set();
    for (const line of lines) {
        const match = line.match(REFUSED_PAGES);
        if (!match)
            continue;
        for (const page of match[1].split(',').map(item => item.trim()).filter(Boolean)) {
            if (seen.has(page))
                continue;
            seen.add(page);
            pages.push(page);
        }
    }
    return pages.map(page => {
        const errorLine = lines.find(line => {
            const match = line.match(ERROR_PAGE);
            return match ? match[2].trim() === page : false;
        });
        const match = errorLine?.match(ERROR_PAGE);
        if (!match)
            return { page, code: '' };
        const d2 = `${match[1]}${match[3]}`.match(D2_CODE);
        return { page, code: d2 ? d2[0] : match[1] };
    });
}
export function materializerOutcome(step) {
    return namedOutcome(step, NR_MATERIALIZE_AGENT);
}
export function defsOutcome(step) {
    return namedOutcome(step, NR_DEFS_AGENT);
}
/** Failed defs or any `outside` path stops the release. A clean guard is the only case that adds the materializer. */
export function reviewDefsRun(defs, guard) {
    if (!defs || defs.status !== 'completed') {
        return { status: 'failed', message: defs?.message || `${NR_DEFS_AGENT} step is missing`, addMaterialize: false };
    }
    if (guard.outside.length > 0) {
        return { status: 'failed', message: `outside: ${guard.outside.join(', ')}`, addMaterialize: false };
    }
    return { status: 'completed', message: 'defs stayed inside the planned pages', addMaterialize: true };
}
