/// <mls fileReference="_102020_/l2/agentNewReleaseL2/helpers/plan.ts" enhancement="_blank"/>
import { validateChangeEffort } from '/_102035_/l2/solution/gates/changeEffort/gate.js';
import { EFFORT_UNIT_KINDS } from '/_102035_/l2/solution/poolPlan.js';
const PAGE_KIND = EFFORT_UNIT_KINDS.find(kind => kind === 'page');
const DEFS_KINDS = new Set(['page', 'contract', 'shared']);
function outOfStep(answer) {
    const reasons = [];
    if (answer.status === 'abend')
        reasons.push(`abend: ${answer.abend?.reason ?? ''}`);
    if (answer.remove.length > 0)
        reasons.push('remove');
    if (answer.create.some(unit => unit.kind !== PAGE_KIND))
        reasons.push('create');
    if (answer.regenerateDefs.some(unit => !DEFS_KINDS.has(unit.kind)))
        reasons.push('regenerateDefs');
    return reasons;
}
function addPage(pages, seen, id) {
    if (seen.has(id))
        return;
    seen.add(id);
    pages.push(id);
}
function addCommand(commands, seen, command) {
    if (!command || seen.has(command))
        return;
    seen.add(command);
    commands.push(command);
}
function collectNamedPages(answer, sharedPages, seenShared, bffPages, seenBff) {
    for (const unit of answer.regenerateDefs) {
        if (unit.kind === 'shared')
            addPage(sharedPages, seenShared, unit.id);
        if (unit.kind === 'contract') {
            addPage(bffPages, seenBff, unit.id);
            addPage(sharedPages, seenShared, unit.id);
        }
    }
    for (const unit of answer.materialize) {
        if (unit.kind === 'shared')
            addPage(sharedPages, seenShared, unit.id);
    }
    for (const unit of answer.create) {
        if (unit.kind === PAGE_KIND)
            addPage(bffPages, seenBff, unit.id);
    }
}
function raiseDegree(degrees, id, value) {
    degrees.set(id, Math.max(degrees.get(id) ?? 0, value));
}
/** Per master answer, the highest degree of each page it names. */
function scoreDegrees(answer, degrees) {
    const contractPages = new Set(answer.regenerateDefs.filter(unit => unit.kind === 'contract').map(unit => unit.id));
    for (const unit of answer.create) {
        if (unit.kind === PAGE_KIND)
            raiseDegree(degrees, unit.id, 5);
    }
    for (const unit of answer.regenerateDefs) {
        if (unit.kind === 'contract')
            raiseDegree(degrees, unit.id, answer.contract === 'change' ? 6 : 3);
        if ((unit.kind === 'page' || unit.kind === 'shared') && !contractPages.has(unit.id))
            raiseDegree(degrees, unit.id, 4);
    }
    for (const unit of answer.materialize) {
        if (unit.kind === PAGE_KIND)
            raiseDegree(degrees, unit.id, 2);
    }
}
function citesDefs(answer) {
    return answer.contract === 'change'
        || answer.create.some(unit => unit.kind === PAGE_KIND)
        || answer.regenerateDefs.some(unit => DEFS_KINDS.has(unit.kind));
}
function addCitedPages(pages, seen, answer) {
    for (const unit of answer.regenerateDefs) {
        if (DEFS_KINDS.has(unit.kind))
            addPage(pages, seen, unit.id);
    }
    for (const unit of answer.create) {
        if (unit.kind === PAGE_KIND)
            addPage(pages, seen, unit.id);
    }
    if (answer.contract !== 'change')
        return;
    for (const unit of answer.materialize) {
        if (unit.kind === PAGE_KIND)
            addPage(pages, seen, unit.id);
    }
}
/** Pages of this master to materialize, or to rebuild with the defs generator. Other masters are ignored. */
export function planNewReleaseL2(effort, masterProject) {
    const checked = validateChangeEffort(effort);
    if (!checked.ok) {
        const detail = checked.issues.map(issue => `${issue.code}:${issue.path}`).join(', ');
        return { ok: false, reason: `changeEffort rejected by gate: ${detail}` };
    }
    const blocks = [];
    const materialize = [];
    const regenerate = [];
    const seenMaterialize = new Set();
    const seenRegenerate = new Set();
    const commands = [];
    const seenCommands = new Set();
    const sharedPages = [];
    const seenShared = new Set();
    const bffPages = [];
    const seenBff = new Set();
    const degreeByPage = new Map();
    let rebuild = false;
    let sawMaster = false;
    for (const row of checked.file.perItem) {
        for (const answer of row.answers) {
            if (answer.master.project !== masterProject)
                continue;
            sawMaster = true;
            for (const agent of answer.runAgents)
                addCommand(commands, seenCommands, agent.command);
            collectNamedPages(answer, sharedPages, seenShared, bffPages, seenBff);
            scoreDegrees(answer, degreeByPage);
            for (const reason of outOfStep(answer))
                blocks.push(`${answer.item} ${reason}`);
            if (citesDefs(answer)) {
                rebuild = true;
                addCitedPages(regenerate, seenRegenerate, answer);
                continue;
            }
            for (const unit of answer.materialize) {
                if (unit.kind !== PAGE_KIND)
                    continue;
                addPage(materialize, seenMaterialize, unit.id);
            }
        }
    }
    if (blocks.length > 0)
        return { ok: false, reason: `not in this release step: ${blocks.join('; ')}` };
    if (!sawMaster)
        return { ok: false, reason: `change effort has no answer from master ${masterProject}` };
    const pages = rebuild ? regenerate : materialize;
    if (pages.length === 0)
        return { ok: false, reason: 'nothing to apply' };
    const materializeOnly = rebuild ? materialize.filter(id => !seenRegenerate.has(id)) : [];
    const degrees = {};
    for (const id of [...pages, ...materializeOnly])
        degrees[id] = degreeByPage.get(id) ?? 2;
    return { ok: true, mode: rebuild ? 'regenerate' : 'materialize', pages, materializeOnly, commands, sharedPages, bffPages, degrees };
}
