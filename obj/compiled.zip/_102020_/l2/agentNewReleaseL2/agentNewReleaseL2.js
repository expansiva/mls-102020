/// <mls fileReference="_102020_/l2/agentNewReleaseL2/agentNewReleaseL2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { deleteFile } from '/_102027_/l2/libStor.js';
import { planNewReleaseL2 } from '/_102020_/l2/agentNewReleaseL2/helpers/plan.js';
import { NR_AGENT_NAME, NR_CHECK_PLAN, NR_CLOSE_PLAN, NR_DEFS_PLAN, NR_MATERIALIZE_PLAN, buildApplySteps, buildRegenerateSteps, closeNotice, commandLines, currentProjectNumber, degreesFromMemory, degreesOf, deletedPaths, defsOutcome, deleteGeneratedFiles, guardAfterDefs, markedPageIds, marksDifferMessage, materializerOutcome, parseNrInvocation, planIdOf, readChangeEffort, readPoolEffort, readProductSnapshot, recordPhase, releasePages, screenCostLines, reviewDefsRun, statusIntents, statusText, stepsPhaseNote, writeReleaseSnapshot, } from '/_102020_/l2/agentNewReleaseL2/helpers/steps.js';
export function createAgent() {
    return {
        agentName: NR_AGENT_NAME,
        agentProject: 102020,
        agentFolder: 'agentNewReleaseL2',
        agentDescription: 'Applies a frontend change-effort by regenerating the marked pages or materializing them.',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    let moduleName = '';
    let phase = 'effort-read';
    try {
        const invocation = parseNrInvocation(userPrompt || context.message.content || '');
        if (!invocation.ok)
            return statusMessage(agent, context, invocation.help);
        moduleName = invocation.module;
        const project = currentProjectNumber();
        if (!Number.isSafeInteger(project) || project <= 0) {
            return statusMessage(agent, context, 'The current project is unavailable.');
        }
        phase = 'effort-read';
        const loaded = await readChangeEffort(moduleName);
        if (!loaded.ok)
            return refuse(agent, context, moduleName, phase, loaded.reason);
        await recordPhase(moduleName, phase, 'ok', 'read');
        phase = 'plan';
        const plan = planNewReleaseL2(loaded.effort, String(agent.agentProject));
        if (!plan.ok)
            return refuse(agent, context, moduleName, phase, plan.reason);
        await recordPhase(moduleName, phase, 'ok', `${plan.mode} ${plan.pages.join(',')}`, {
            bffPages: plan.bffPages,
            sharedPages: plan.sharedPages,
        });
        if (plan.mode === 'materialize') {
            phase = 'steps';
            const prepared = await prepareMaterialize(project, moduleName, plan.pages, plan.materializeOnly, plan.commands, plan.sharedPages, plan.degrees);
            if (!prepared.ok)
                return refuse(agent, context, moduleName, phase, prepared.message);
            await recordPhase(moduleName, phase, 'ok', stepsPhaseNote(prepared.steps.length, plan.commands));
            const steps = prepared.steps.map(step => addStepIntent(context, step, 1, false));
            return [openMessage(agent, context, moduleName, project, { nrDegrees: JSON.stringify(plan.degrees) }), ...steps];
        }
        phase = 'marks';
        const marked = markedPageIds(await readPoolEffort(moduleName));
        const differ = marksDifferMessage(marked, plan.pages);
        if (differ)
            return refuse(agent, context, moduleName, phase, differ);
        await recordPhase(moduleName, phase, 'ok', 'match');
        phase = 'snapshot';
        await writeReleaseSnapshot(moduleName, await readProductSnapshot(moduleName));
        await recordPhase(moduleName, phase, 'ok', 'written');
        phase = 'steps';
        const built = buildRegenerateSteps(project, moduleName, plan.bffPages);
        await recordPhase(moduleName, phase, 'ok', stepsPhaseNote(built.length, plan.commands));
        const steps = built.map(step => addStepIntent(context, step, 1, false));
        return [openMessage(agent, context, moduleName, project, {
                nrPages: plan.pages.join(','),
                nrMaterializeOnly: plan.materializeOnly.join(','),
                nrCommands: JSON.stringify(plan.commands),
                nrSharedPages: plan.sharedPages.join(','),
                nrDegrees: JSON.stringify(plan.degrees),
            }), ...steps];
    }
    catch (error) {
        const message = error instanceof Error && error.message ? error.message : String(error);
        let note = message;
        if (moduleName) {
            try {
                await recordPhase(moduleName, phase, 'failed', message);
            }
            catch (writeError) {
                const extra = writeError instanceof Error && writeError.message ? writeError.message : String(writeError);
                note = `${message}; run log: ${extra}`;
            }
        }
        return statusMessage(agent, context, note, 'failed');
    }
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential) {
    const planId = planIdOf(step);
    if (planId === NR_CHECK_PLAN)
        return reviewCheck(context, parentStep, step, hookSequential);
    if (planId !== NR_CLOSE_PLAN) {
        const notice = context.task?.iaCompressed?.longMemory?.notice || 'Deterministic message bootstrap completed.';
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', notice)];
    }
    const materialize = getAllSteps(context.task?.iaCompressed?.nextSteps).find(item => planIdOf(item) === NR_MATERIALIZE_PLAN);
    const outcome = materializerOutcome(materialize);
    const completed = outcome.status === 'completed';
    const prompt = step.prompt || '';
    const degrees = degreesOf(prompt);
    const body = closeNotice(outcome.message, deletedPaths(prompt), commandLines(prompt), completed, screenCostLines(context.task?.iaCompressed?.nextSteps, degrees));
    const notice = statusText(body, completed ? 'done' : 'failed');
    return [updateStatus(context, parentStep, step, hookSequential, outcome.status, notice)];
}
async function reviewCheck(context, parentStep, step, hookSequential) {
    const memory = context.task?.iaCompressed?.longMemory;
    const moduleName = String(memory?.moduleName || '');
    const pages = String(memory?.nrPages || '').split(',').map(id => id.trim()).filter(Boolean);
    const materializeOnly = String(memory?.nrMaterializeOnly || '').split(',').map(id => id.trim()).filter(Boolean);
    const sharedPages = String(memory?.nrSharedPages || '').split(',').map(id => id.trim()).filter(Boolean);
    const commands = commandsFromMemory(memory?.nrCommands);
    const degrees = degreesFromMemory(memory?.nrDegrees);
    const defs = getAllSteps(context.task?.iaCompressed?.nextSteps).find(item => planIdOf(item) === NR_DEFS_PLAN);
    const defsResult = defsOutcome(defs);
    const guard = defsResult.status === 'completed' ? await guardAfterDefs(moduleName, pages) : null;
    if (defsResult.status === 'completed' && !guard) {
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', 'release snapshot is missing')];
    }
    const review = reviewDefsRun(defsResult, guard || { created: [], changed: [], deleted: [], outside: [] });
    if (!review.addMaterialize) {
        return [updateStatus(context, parentStep, step, hookSequential, review.status, review.message)];
    }
    const project = currentProjectNumber();
    const prepared = await prepareMaterialize(project, moduleName, pages, materializeOnly, commands, sharedPages, degrees);
    if (!prepared.ok) {
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', prepared.message)];
    }
    const added = prepared.steps.map(item => addStepIntent(context, item, step.stepId, true));
    return [
        ...added,
        updateStatus(context, parentStep, step, hookSequential, 'completed', statusText(review.message, 'done')),
    ];
}
function currentStorFiles() {
    return Object.values(mls.stor.files).filter((file) => !!file);
}
/** Deletes the generated files of the effort pages, then builds the whole-module materializer. */
function commandsFromMemory(value) {
    if (value === undefined || value === '')
        return [];
    const parsed = JSON.parse(String(value));
    if (!Array.isArray(parsed) || parsed.some(item => typeof item !== 'string')) {
        throw new Error('nrCommands is not a list of strings');
    }
    return parsed;
}
async function prepareMaterialize(project, moduleName, pages, materializeOnly, commands, sharedPages, degrees) {
    const removed = await deleteGeneratedFiles(moduleName, releasePages(pages, materializeOnly), currentStorFiles(), deleteFile, sharedPages);
    if (!removed.ok)
        return removed;
    return { ok: true, steps: buildApplySteps(project, moduleName, removed.paths, commands, degrees) };
}
function openMessage(agent, context, moduleName, project, extra) {
    return {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentNewReleaseL2 deterministic bootstrap. The root model is disabled.' },
                { type: 'human', content: moduleName },
            ],
            taskTitle: `release ${moduleName}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: NR_AGENT_NAME,
                flowName: NR_AGENT_NAME,
                moduleName,
                project: String(project),
                ...extra,
            },
        },
    };
}
function statusMessage(agent, context, message, kind) {
    return statusIntents(agent.agentName, context.message.threadId, context.message.content, message, kind);
}
async function refuse(agent, context, moduleName, phase, message) {
    await recordPhase(moduleName, phase, 'refused', message);
    return statusMessage(agent, context, message, 'refused');
}
function addStepIntent(context, step, parentStepId, bound) {
    return {
        type: 'add-step',
        messageId: bound ? context.message.orderAt : '',
        threadId: context.message.threadId,
        taskId: bound ? context.task?.PK || '' : '',
        parentStepId,
        step,
    };
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
