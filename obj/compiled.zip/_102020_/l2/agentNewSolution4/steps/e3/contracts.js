/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e3/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_ACCESS_MATRIX_SCHEMA_VERSION = '2026-08-09-ns4-access-matrix-v2';
export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION = '2026-08-10-ns4-access-matrix-v3';
export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION = '2026-08-13-ns4-access-matrix-v4';
export function normalizeNs4E3Review(value, fallbackModule = '') {
    const root = record(value);
    return {
        planId: 'e3-access-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Access matrix',
        reviewRound: positiveInteger(root.reviewRound, 1),
        profiles: array(root.profiles).map(item => {
            const profile = record(item);
            return {
                profileId: text(profile.profileId),
                title: text(profile.title),
                kind: profile.kind === 'external' ? 'external' : 'internal',
                description: text(profile.description),
                actorRefs: strings(profile.actorRefs),
                landingIntent: text(profile.landingIntent),
            };
        }),
        authorities: array(root.authorities).map(item => {
            const authority = record(item);
            return {
                authorityRef: text(authority.authorityRef),
                title: text(authority.title),
                description: text(authority.description),
                journeyStepRefs: strings(authority.journeyStepRefs),
                informationNeeds: strings(authority.informationNeeds),
            };
        }),
        grants: array(root.grants).map(item => {
            const grant = record(item);
            const dataScope = record(grant.dataScope);
            const disclosure = record(grant.disclosure);
            return {
                profileRef: text(grant.profileRef),
                authorityRef: text(grant.authorityRef),
                reason: text(grant.reason),
                dataScope: {
                    mode: scopeMode(dataScope.mode),
                    description: text(dataScope.description),
                },
                disclosure: {
                    mode: disclosureMode(disclosure.mode),
                    description: text(disclosure.description),
                    allowedInformation: strings(disclosure.allowedInformation),
                    deniedInformation: strings(disclosure.deniedInformation),
                },
                useRules: strings(grant.useRules),
            };
        }),
        changeSummary: strings(root.changeSummary),
    };
}
export async function buildNs4AccessMatrixArtifact(review, approvedBy, approvedAt) {
    const accessContract = {
        profiles: review.profiles,
        authorities: review.authorities,
        grants: review.grants,
    };
    const accessHash = await sha256Ns4(accessContract);
    return {
        schemaVersion: NS4_ACCESS_MATRIX_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        title: review.title,
        ...accessContract,
        accessHash,
        approvedBy,
        approvedAt,
        realization: {
            status: 'pending',
            compiledFromAccessHash: accessHash,
            operationAuthorityRefs: [],
        },
    };
}
function scopeMode(value) {
    if (value === 'organization' || value === 'assigned' || value === 'own'
        || value === 'related' || value === 'public')
        return value;
    return 'custom';
}
function disclosureMode(value) {
    if (value === 'fullRecord' || value === 'summaryOnly' || value === 'aggregateOnly')
        return value;
    return 'fieldsOnly';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) {
    return Array.isArray(value) ? value : [];
}
function strings(value) {
    return array(value).map(text).filter(Boolean);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
