import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_E10_VALIDATION_REPORT_VERSION = '2026-08-13-ns4-e10-validation-report-v1';
export const NS4_L5_TODO_FRONTEND_VERSION = '2026-08-13-ns4-todo-frontend-v1';
export const NS4_L5_TODO_BACKEND_VERSION = '2026-08-13-ns4-todo-backend-v1';
export const NS4_L5_PROCESS_VERSION = '2026-08-13-ns4-process-v1';
export const NS4_E10_MENU_LIMIT = 7;
export function compileNs4L5ModuleNavigation(sources) {
    const workspaceById = new Map(sources.workspaces.map(workspace => [workspace.workspaceId, workspace]));
    const routes = new Map(sources.navigation.routes.map(route => [`${route.workspaceId}\u0000${route.scenarioId}`, route]));
    const features = new Map(sources.journeys.features.map(feature => [feature.featureId, new Set(feature.journeyStepRefs || [])]));
    const grants = new Map();
    sources.access.grants.forEach(grant => grants.set(grant.profileRef, new Set([...(grants.get(grant.profileRef) || []), grant.authorityRef])));
    const navigation = [];
    sources.workspaceIndex.menu.sections.forEach(section => section.items.forEach((item, itemIndex) => {
        const workspace = workspaceById.get(item.workspaceId);
        if (!workspace)
            return;
        const featureSteps = features.get(section.featureRef) || new Set();
        const matching = workspace.scenarios.filter(scenario => scenario.stepRefs.some(stepRef => featureSteps.has(stepRef)));
        const candidates = item.hub ? (matching.filter(scenario => scenario.kind !== 'collection').length
            ? matching.filter(scenario => scenario.kind !== 'collection') : workspace.scenarios.filter(scenario => scenario.kind !== 'collection')) : matching;
        const scenario = [...(candidates.length ? candidates : workspace.scenarios)].sort((left, right) => scenarioRank(left.kind, !!item.hub) - scenarioRank(right.kind, !!item.hub)
            || left.scenarioId.localeCompare(right.scenarioId))[0];
        if (!scenario)
            return;
        const route = routes.get(`${workspace.workspaceId}\u0000${scenario.scenarioId}`);
        if (!route)
            return;
        const actors = workspace.profileRefs.filter(profile => scenario.authorityRefs.length
            ? scenario.authorityRefs.some(authority => grants.get(profile)?.has(authority))
            : workspace.scenarios.some(candidate => candidate.authorityRefs.some(authority => grants.get(profile)?.has(authority)))).sort();
        const id = stableId(section.items.length > 1 ? `${section.sectionId}-${workspace.workspaceId}-${itemIndex + 1}` : section.sectionId);
        navigation.push({ id, label: section.label, href: route.routePattern, description: workspace.description, actors,
            workspaceId: workspace.workspaceId, scenarioId: scenario.scenarioId, sectionId: section.sectionId,
            ...(item.hub ? { hub: lowerCamel(item.hub) } : {}) });
    }));
    const stableNavigation = uniqueBy(navigation, item => item.id);
    const headerLinks = [];
    for (const hub of sources.workspaceIndex.hubs) {
        const route = sources.navigation.routes.find(item => item.workspaceId === hub.workspaceId && item.scenarioId === 'collection')
            || sources.navigation.routes.find(item => item.workspaceId === hub.workspaceId);
        const workspace = workspaceById.get(hub.workspaceId);
        if (!route || !workspace)
            continue;
        headerLinks.push({ id: stableId(hub.hubId), label: workspace.title, href: route.routePattern,
            actors: authorizedProfiles(workspace, grants), manageable: true, hub: lowerCamel(hub.anchorEntity) });
    }
    for (const item of stableNavigation.filter(entry => !entry.hub))
        headerLinks.push({
            id: item.id, label: item.label, href: item.href, actors: item.actors, manageable: true,
        });
    return { moduleId: sources.workspaceIndex.moduleName, basePath: `/${lowerCamel(sources.workspaceIndex.moduleName)}`,
        userLanguage: sources.workspaceIndex.userLanguage, navigation: stableNavigation, headerLinks: uniqueBy(headerLinks, item => item.id) };
}
export async function compileNs4E10Delivery(sources, report, existingConfig, projectId) {
    if (report.finalStatus !== 'passed')
        throw new Error('E10 L5 delivery requires a passed validation report.');
    const moduleNavigation = report.menuPreview;
    const todoFrontend = {
        schemaVersion: NS4_L5_TODO_FRONTEND_VERSION, layer: 'frontend', moduleName: sources.workspaceIndex.moduleName,
        owners: [
            ...sources.workspaces.map(workspace => ({ ownerType: 'workspace', ownerId: workspace.workspaceId, workspaceId: workspace.workspaceId, statusFrontend: 'toCreate' })),
            ...sources.contracts.map(contract => ({ ownerType: 'contract', ownerId: contract.operationRef, workspaceId: contract.workspaceId, statusFrontend: 'toCreate' })),
        ].sort((left, right) => `${left.ownerType}:${left.ownerId}`.localeCompare(`${right.ownerType}:${right.ownerId}`)),
    };
    const todoBackend = {
        schemaVersion: NS4_L5_TODO_BACKEND_VERSION, layer: 'backend', moduleName: sources.workspaceIndex.moduleName,
        owners: sources.useCases.map(useCase => ({ ownerType: 'useCase', ownerId: useCase.useCaseId, statusBackend: 'toCreate' }))
            .sort((left, right) => left.ownerId.localeCompare(right.ownerId)),
    };
    const processValue = {
        schemaVersion: NS4_L5_PROCESS_VERSION, moduleName: sources.workspaceIndex.moduleName,
        sourceHashes: report.sourceHashes, counts: report.counts,
        validation: { status: 'passed', reportPath: `l4/${sources.workspaceIndex.moduleName}/pipeline/e10-validation-report.json`,
            reportHash: report.reportHash, warningCount: report.warnings.length, registrarCount: report.registrars.length },
        next: { frontend: 'todoFrontend', backend: 'todoBackend' },
    };
    const process = { ...processValue, processHash: await sha256Ns4(processValue) };
    return { config: mergeNs4L5Config(existingConfig, projectId, moduleNavigation), moduleNavigation, todoFrontend, todoBackend, process };
}
export function mergeNs4L5Config(existing, projectId, moduleNavigation) {
    const config = isRecord(existing) ? clone(existing) : {};
    const modulePatch = { moduleId: moduleNavigation.moduleId, basePath: moduleNavigation.basePath,
        navigation: moduleNavigation.navigation, headerLinks: moduleNavigation.headerLinks };
    if (isRecord(config.projects)) {
        const projects = config.projects;
        const requested = projects[String(projectId)];
        const clientKey = isRecord(requested) ? String(projectId) : Object.keys(projects).find(key => isRecord(projects[key]) && projects[key].type === 'client');
        if (clientKey) {
            const client = isRecord(projects[clientKey]) ? projects[clientKey] : {};
            client.modules = mergeModuleList(client.modules, modulePatch);
            projects[clientKey] = client;
            config.projects = projects;
            return config;
        }
    }
    config.modules = mergeModuleList(config.modules, modulePatch);
    return config;
}
function mergeModuleList(value, patch) {
    const modules = Array.isArray(value) ? value.filter(isRecord).map(clone) : [];
    const index = modules.findIndex(item => item.moduleId === patch.moduleId);
    if (index >= 0)
        modules[index] = { ...modules[index], ...patch };
    else
        modules.push(patch);
    return modules;
}
function authorizedProfiles(workspace, grants) {
    return workspace.profileRefs.filter(profile => workspace.scenarios.some(scenario => scenario.authorityRefs.some(authority => grants.get(profile)?.has(authority)))).sort();
}
function scenarioRank(kind, insideHub = false) {
    return (insideHub
        ? { record: 0, list: 1, detail: 2, queue: 3, review: 4, form: 5, collection: 8 }
        : { collection: 0, record: 1, list: 2, detail: 3, queue: 4, review: 5, form: 6 })[kind] ?? 9;
}
function stableId(value) { const clean = value.replace(/[^A-Za-z0-9]+(.)/g, (_match, char) => char.toUpperCase()); return lowerCamel(clean || 'item'); }
function lowerCamel(value) { return value ? value.slice(0, 1).toLowerCase() + value.slice(1) : 'module'; }
function uniqueBy(values, key) { return [...new Map(values.map(value => [key(value), value])).values()].sort((left, right) => key(left).localeCompare(key(right))); }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
