import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_E10_VALIDATION_REPORT_VERSION = '2026-08-13-ns4-e10-validation-report-v1';
export const NS4_L5_TODO_FRONTEND_VERSION = '2026-08-13-ns4-todo-frontend-v1';
export const NS4_L5_TODO_BACKEND_VERSION = '2026-08-13-ns4-todo-backend-v1';
export const NS4_L5_PROCESS_VERSION = '2026-08-13-ns4-process-v1';
export const NS4_E10_MENU_LIMIT = 7;
/**
 * The L5 menu preview. The frontend builds the real navigation itself from workspaces/*.defs.ts plus
 * the site map landings (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this
 * mirrors that derivation so the report shows the menu the module will actually have.
 */
export function compileNs4L5ModuleNavigation(sources) {
    const workspaceById = new Map(sources.model.workspaces.map(workspace => [workspace.workspaceId, workspace]));
    const landingIds = new Set(sources.model.landings.map(landing => landing.workspaceId));
    const navigation = sources.model.menu.map(entry => {
        const workspace = workspaceById.get(entry.workspaceId);
        return {
            id: stableId(entry.workspaceId), label: entry.label, href: `/${sources.moduleName}/${entry.workspaceId}`,
            description: workspace?.purpose || entry.label, actors: [...(workspace?.actors || [])].sort(),
            workspaceId: entry.workspaceId, scenarioId: workspace?.sections[0]?.sectionId || '', sectionId: entry.featureRef || entry.tier,
            ...(entry.tier === 'hub' ? { hub: workspace?.entity } : {}),
        };
    });
    const headerLinks = sources.model.menu
        .filter(entry => entry.tier === 'hub' || landingIds.has(entry.workspaceId))
        .map(entry => ({
        id: stableId(`header-${entry.workspaceId}`), label: entry.label,
        href: `/${sources.moduleName}/${entry.workspaceId}`,
        actors: [...(workspaceById.get(entry.workspaceId)?.actors || [])].sort(), manageable: true,
        ...(entry.tier === 'hub' ? { hub: workspaceById.get(entry.workspaceId)?.entity } : {}),
    }));
    return {
        moduleId: sources.moduleName, basePath: `/${sources.moduleName}`, userLanguage: sources.userLanguage,
        navigation: navigation.slice(0, NS4_E10_MENU_LIMIT * NS4_E10_MENU_LIMIT), headerLinks,
    };
}
export async function compileNs4E10Delivery(sources, report, existingConfig, projectId) {
    if (report.finalStatus !== 'passed')
        throw new Error('E10 L5 delivery requires a passed validation report.');
    const moduleNavigation = report.menuPreview;
    const todoFrontend = {
        schemaVersion: NS4_L5_TODO_FRONTEND_VERSION, layer: 'frontend', moduleName: sources.moduleName,
        owners: [
            ...sources.saved.workspaces.map(workspace => ({ ownerType: 'workspace', ownerId: workspace.workspaceId, workspaceId: workspace.workspaceId, statusFrontend: 'toCreate' })),
            ...sources.saved.contracts.map(contract => ({ ownerType: 'contract', ownerId: contract.route, workspaceId: contract.workspaceId, statusFrontend: 'toCreate' })),
        ].sort((left, right) => `${left.ownerType}:${left.ownerId}`.localeCompare(`${right.ownerType}:${right.ownerId}`)),
    };
    const todoBackend = {
        schemaVersion: NS4_L5_TODO_BACKEND_VERSION, layer: 'backend', moduleName: sources.moduleName,
        owners: sources.model.operations.map(operation => ({ ownerType: 'useCase', ownerId: operation.operationId, statusBackend: 'toCreate' }))
            .sort((left, right) => left.ownerId.localeCompare(right.ownerId)),
    };
    const processValue = {
        schemaVersion: NS4_L5_PROCESS_VERSION, moduleName: sources.moduleName,
        sourceHashes: report.sourceHashes, counts: report.counts,
        validation: { status: 'passed', reportPath: `l4/${sources.moduleName}/pipeline/e10-validation-report.json`,
            reportHash: report.reportHash, warningCount: report.warnings.length, registrarCount: report.registrars.length },
        next: { frontend: 'todoFrontend', backend: 'todoBackend' },
    };
    const process = { ...processValue, processHash: await sha256Ns4(processValue) };
    return { config: mergeNs4L5Config(existingConfig, projectId, moduleNavigation), moduleNavigation, todoFrontend, todoBackend, process };
}
export function mergeNs4L5Config(existing, projectId, moduleNavigation) {
    const config = isRecord(existing) ? clone(existing) : {};
    const modulePatch = { moduleId: moduleNavigation.moduleId, basePath: moduleNavigation.basePath,
        navigation: moduleNavigation.navigation, headerLinks: moduleNavigation.headerLinks };
    if (isRecord(config.projects)) {
        const projects = config.projects;
        const requested = projects[String(projectId)];
        const clientKey = isRecord(requested) ? String(projectId) : Object.keys(projects).find(key => isRecord(projects[key]) && projects[key].type === 'client');
        if (clientKey) {
            const client = isRecord(projects[clientKey]) ? projects[clientKey] : {};
            client.modules = mergeModuleList(client.modules, modulePatch);
            projects[clientKey] = client;
            config.projects = projects;
            return config;
        }
    }
    config.modules = mergeModuleList(config.modules, modulePatch);
    return config;
}
function mergeModuleList(value, patch) {
    const modules = Array.isArray(value) ? value.filter(isRecord).map(clone) : [];
    const index = modules.findIndex(item => item.moduleId === patch.moduleId);
    if (index >= 0)
        modules[index] = { ...modules[index], ...patch };
    else
        modules.push(patch);
    return modules;
}
function stableId(value) { const clean = value.replace(/[^A-Za-z0-9]+(.)/g, (_match, char) => char.toUpperCase()); return lowerCamel(clean || 'item'); }
function lowerCamel(value) { return value ? value.slice(0, 1).toLowerCase() + value.slice(1) : 'module'; }
function uniqueBy(values, key) { return [...new Map(values.map(value => [key(value), value])).values()].sort((left, right) => key(left).localeCompare(key(right))); }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
