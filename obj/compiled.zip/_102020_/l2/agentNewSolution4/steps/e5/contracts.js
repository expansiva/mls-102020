/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e5/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_RULE_SCHEMA_VERSION = '2026-08-06-ns4-rule-v1';
export const NS4_RULE_INDEX_SCHEMA_VERSION = '2026-08-09-ns4-rule-index-v2';
export function normalizeNs4E5Review(value, fallbackModule = '') {
    const root = record(value);
    return {
        planId: 'e5-rules-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business rules',
        reviewRound: positiveInteger(root.reviewRound, 1),
        rules: array(root.rules).map(normalizeRule),
        routedStatements: array(root.routedStatements).map(item => {
            const route = record(item);
            return {
                sourceRef: text(route.sourceRef), statement: text(route.statement),
                destination: destination(route.destination), reason: text(route.reason),
                ...(text(route.ruleRef) ? { ruleRef: text(route.ruleRef) } : {}),
            };
        }),
        coverage: array(root.coverage).map(item => {
            const coverage = record(item);
            return {
                sourceRef: text(coverage.sourceRef), sourceType: sourceType(coverage.sourceType),
                disposition: coverage.disposition === 'routed' ? 'routed' : 'compiled',
                targetRef: text(coverage.targetRef),
            };
        }),
        knownGaps: array(root.knownGaps).map(normalizeUpstreamGap),
        changeSummary: strings(root.changeSummary),
    };
}
export function normalizeNs4E5PlanDraft(value, fallbackModule = '') {
    const root = record(value);
    const normalized = normalizeNs4E5Review({
        ...root,
        rules: array(root.rulePlans),
    }, fallbackModule);
    return {
        planId: 'e5-rules-plan',
        moduleName: normalized.moduleName,
        userLanguage: normalized.userLanguage,
        title: normalized.title,
        reviewRound: normalized.reviewRound,
        rulePlans: normalized.rules.map(({ trigger, condition, enforcement, acceptanceCases, ...rule }) => rule),
        routedStatements: normalized.routedStatements,
        coverage: normalized.coverage,
        upstreamGaps: array(root.upstreamGaps).map(normalizeUpstreamGap),
        changeSummary: normalized.changeSummary,
    };
}
export function normalizeNs4E5RuleDraft(value, moduleName, reviewRound, ruleId) {
    const root = record(value);
    const rawRule = record(root.rule);
    const rule = normalizeNs4E5Review({ rules: [{ ...rawRule, ruleId }] }, moduleName).rules[0];
    return { planId: 'e5-rule-detail', moduleName, reviewRound, ruleId, rule };
}
export function assembleNs4E5Review(plan, details) {
    const byRule = new Map(details.map(detail => [detail.ruleId, detail.rule]));
    return normalizeNs4E5Review({
        planId: 'e5-rules-review', moduleName: plan.moduleName, userLanguage: plan.userLanguage,
        title: plan.title, reviewRound: plan.reviewRound,
        rules: plan.rulePlans.map(rule => byRule.get(rule.ruleId)).filter(Boolean),
        routedStatements: plan.routedStatements, coverage: plan.coverage,
        knownGaps: plan.upstreamGaps, changeSummary: plan.changeSummary,
    }, plan.moduleName);
}
export async function buildNs4RuleArtifacts(review, approvedBy, approvedAt) {
    const rulesHash = await sha256Ns4({
        rules: review.rules, routedStatements: review.routedStatements,
        coverage: review.coverage, knownGaps: review.knownGaps,
    });
    const rules = review.rules.map(rule => ({
        schemaVersion: NS4_RULE_SCHEMA_VERSION, moduleName: review.moduleName, userLanguage: review.userLanguage,
        ...rule, rulesHash, approvedBy, approvedAt,
    }));
    return {
        rules,
        index: {
            schemaVersion: NS4_RULE_INDEX_SCHEMA_VERSION, moduleName: review.moduleName,
            userLanguage: review.userLanguage, title: review.title, rulesHash,
            rules: review.rules.map(rule => ({
                ruleId: rule.ruleId, title: rule.title, kind: rule.kind, layer: rule.layer,
                criticality: rule.criticality, definitionRef: `l4/${review.moduleName}/rules/${rule.ruleId}.defs.ts`,
            })),
            routedStatements: review.routedStatements, coverage: review.coverage,
            knownGaps: review.knownGaps, approvedBy, approvedAt,
            realization: { status: 'pending', compiledFromRulesHash: rulesHash, operationRefs: [] },
        },
    };
}
function normalizeRule(value) {
    const rule = record(value);
    const scope = record(rule.scope);
    const trigger = record(rule.trigger);
    const condition = record(rule.condition);
    const enforcement = record(rule.enforcement);
    const backend = record(enforcement.backend);
    const frontend = record(enforcement.frontend);
    return {
        ruleId: text(rule.ruleId), title: text(rule.title), statement: text(rule.statement),
        kind: ruleKind(rule.kind), layer: ruleLayer(rule.layer),
        criticality: rule.criticality === 'warning' ? 'warning' : 'blocking',
        scope: {
            entityRefs: strings(scope.entityRefs), fieldRefs: strings(scope.fieldRefs),
            relationshipRefs: strings(scope.relationshipRefs), journeyRefs: strings(scope.journeyRefs),
            journeyStepRefs: strings(scope.journeyStepRefs), actorRefs: strings(scope.actorRefs),
            authorityRefs: strings(scope.authorityRefs),
        },
        trigger: { type: triggerType(trigger.type), description: text(trigger.description) },
        condition: { expression: text(condition.expression), facts: strings(condition.facts) },
        enforcement: {
            backend: {
                required: backend.required === true, effect: backendEffect(backend.effect),
                ...(text(backend.errorCode) ? { errorCode: text(backend.errorCode) } : {}),
            },
            frontend: { behavior: frontendBehavior(frontend.behavior), ...(text(frontend.message) ? { message: text(frontend.message) } : {}) },
        },
        acceptanceCases: array(rule.acceptanceCases).map(item => {
            const testCase = record(item);
            return { caseId: text(testCase.caseId), given: strings(testCase.given), when: text(testCase.when), then: text(testCase.then), expected: expected(testCase.expected) };
        }),
        sourceRefs: strings(rule.sourceRefs),
    };
}
function ruleKind(value) {
    if (value === 'validation' || value === 'transitionGuard' || value === 'calculation' || value === 'temporal'
        || value === 'authorization' || value === 'visibility' || value === 'conditionalRequirement')
        return value;
    return 'invariant';
}
function ruleLayer(value) { return value === 'application' || value === 'access' ? value : 'domain'; }
function triggerType(value) {
    if (value === 'update' || value === 'delete' || value === 'transition' || value === 'read' || value === 'calculate' || value === 'schedule')
        return value;
    return 'create';
}
function backendEffect(value) {
    if (value === 'calculate' || value === 'filter' || value === 'authorize' || value === 'notify')
        return value;
    return 'reject';
}
function frontendBehavior(value) {
    if (value === 'warn' || value === 'hide' || value === 'disable' || value === 'calculate' || value === 'none')
        return value;
    return 'block';
}
function expected(value) {
    if (value === 'accept' || value === 'calculate' || value === 'filter')
        return value;
    return 'reject';
}
function destination(value) {
    if (value === 'e4-fieldConstraint' || value === 'e4-entityInvariant' || value === 'e6-workflow' || value === 'documentation')
        return value;
    return 'e5-rule';
}
function sourceType(value) {
    if (value === 'ontologyInvariant' || value === 'ontologyLifecyclePredicate'
        || value === 'accessConstraint' || value === 'declaredConstraint')
        return value;
    return 'journeyRule';
}
function normalizeUpstreamGap(value) {
    const gap = record(value);
    return {
        gapId: text(gap.gapId), sourceRefs: strings(gap.sourceRefs),
        missingContract: text(gap.missingContract), reason: text(gap.reason),
    };
}
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) { return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback; }
