/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e8/hubComposition.ts" enhancement="_blank"/>
/**
 * The one place E8 asks an LLM for judgement: how the hub record page is composed. The catalogue it
 * receives is closed — code already decided WHAT may appear. The call may only order, promote and
 * name; it can never add, drop or rename a structural id, and an invalid answer falls back to the
 * score order with a recorded decision instead of failing the run.
 */
import { resolveNs4Findings } from '/_102020_/l2/agentNewSolution4/helpers/ns4Resolve.js';
/** Score order, primary actions first: what the page looks like when nobody composes it. */
export function defaultNs4HubComposition(workspace) {
    const items = workspace.hubCatalogue?.items || [];
    return {
        workspaceId: workspace.workspaceId,
        title: workspace.title,
        tileOrder: items.map(item => item.itemId),
        primaryActionIds: items.filter(item => item.kind === 'action').slice(0, 2).map(item => item.itemId),
        labels: items.map(item => ({ itemId: item.itemId, label: item.label })),
        menuGroups: [],
    };
}
export function normalizeNs4HubComposition(value, workspaceId, fallbackTitle) {
    const root = record(value);
    return {
        workspaceId: text(root.workspaceId) || workspaceId,
        title: text(root.title) || fallbackTitle,
        tileOrder: strings(root.tileOrder),
        primaryActionIds: strings(root.primaryActionIds),
        labels: array(root.labels).flatMap(item => {
            const entry = record(item);
            const itemId = text(entry.itemId);
            const label = text(entry.label);
            return itemId && label ? [{ itemId, label }] : [];
        }),
        menuGroups: array(root.menuGroups).flatMap(item => {
            const group = record(item);
            const groupId = text(group.groupId);
            return groupId ? [{ groupId, label: text(group.label) || groupId, itemIds: strings(group.itemIds) }] : [];
        }),
    };
}
export function validateNs4HubComposition(catalogue, composition) {
    const issues = [];
    const add = (code, path, message) => issues.push({ code, path, message });
    const known = new Set(catalogue.items.map(item => item.itemId));
    const actions = new Set(catalogue.items.filter(item => item.kind === 'action').map(item => item.itemId));
    if (!composition.title)
        add('NS4_E8_HUB_LABEL', 'title', 'The hub page needs a localized title.');
    const ordered = new Set(composition.tileOrder);
    if (ordered.size !== composition.tileOrder.length)
        add('NS4_E8_HUB_ORDER_DUPLICATE', 'tileOrder', 'A catalogue item cannot appear twice in the order.');
    composition.tileOrder.forEach(itemId => {
        if (!known.has(itemId))
            add('NS4_E8_HUB_UNKNOWN_ITEM', 'tileOrder', `Unknown catalogue item ${itemId}; the composition may only order what code derived.`);
    });
    known.forEach(itemId => {
        if (!ordered.has(itemId))
            add('NS4_E8_HUB_MISSING_ITEM', 'tileOrder', `Catalogue item ${itemId} was dropped; the composition may not remove an item.`);
    });
    composition.primaryActionIds.forEach(itemId => {
        if (!actions.has(itemId))
            add('NS4_E8_HUB_PRIMARY_ACTION', 'primaryActionIds', `${itemId} is not an action of the catalogue.`);
    });
    composition.labels.forEach(entry => {
        if (!known.has(entry.itemId))
            add('NS4_E8_HUB_UNKNOWN_ITEM', 'labels', `Unknown catalogue item ${entry.itemId}.`);
    });
    composition.menuGroups.forEach((group, index) => {
        group.itemIds.forEach(itemId => {
            if (!known.has(itemId))
                add('NS4_E8_HUB_UNKNOWN_ITEM', `menuGroups[${index}]`, `Unknown catalogue item ${itemId}.`);
        });
    });
    return { ok: !issues.length, issues };
}
/** Applies a composition over the derived catalogue: order, promotion and labels — nothing else. */
export function applyNs4HubComposition(workspace, composition) {
    const catalogue = workspace.hubCatalogue;
    if (!catalogue)
        return workspace;
    const labels = new Map(composition.labels.map(entry => [entry.itemId, entry.label]));
    const rank = new Map(composition.tileOrder.map((itemId, index) => [itemId, index]));
    const primary = new Set(composition.primaryActionIds);
    const items = [...catalogue.items]
        .map(item => ({ ...item, ...(labels.get(item.itemId) ? { label: labels.get(item.itemId) } : {}) }))
        .sort((left, right) => (rank.get(left.itemId) ?? Number.MAX_SAFE_INTEGER) - (rank.get(right.itemId) ?? Number.MAX_SAFE_INTEGER));
    const recordSection = workspace.sections.find(section => section.sectionId === 'record');
    const sections = workspace.sections.map(section => section !== recordSection ? section : {
        ...section,
        organisms: items.map(item => item.kind === 'action'
            ? { role: primary.has(item.itemId) ? 'primarySurface' : 'contextualAction', action: item.targetRef }
            : { role: 'detailPanel', dataSource: item.targetRef }),
    });
    return { ...workspace, title: composition.title || workspace.title, hubCatalogue: { ...catalogue, items }, sections };
}
/**
 * The bounded resolution: an invalid composition after its single repair is never a run failure —
 * the deterministic score order wins and the choice is recorded.
 */
export function resolveNs4HubCompositionFindings(workspace, issues, portuguese) {
    if (!issues.length)
        return { artifact: workspace, systemDecisions: [], unresolved: [] };
    return resolveNs4Findings(workspace, [{
            classification: 'C',
            decisionId: `hubComposition${upperCamel(workspace.workspaceId)}`,
            findingRef: `NS4_E8_HUB_COMPOSITION:${workspace.workspaceId}`,
            stage: 'e8-workspaces',
            question: portuguese
                ? `A composição proposta para o painel de ${workspace.title} não respeitou o catálogo; usar a ordem padrão?`
                : `The proposed composition for the ${workspace.title} dashboard did not respect the catalogue; use the default order?`,
            deterministicChoice: 'keepDerivedComposition',
            alternatives: ['reviewDashboardComposition'],
            changeHint: portuguese
                ? `Revisar a ordem e os destaques do painel de ${workspace.title} no próximo round.`
                : `Review the order and highlights of the ${workspace.title} dashboard in the next round.`,
            apply: artifact => applyNs4HubComposition(artifact, defaultNs4HubComposition(artifact)),
        }]);
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function upperCamel(value) { return value ? value.slice(0, 1).toUpperCase() + value.slice(1) : ''; }
