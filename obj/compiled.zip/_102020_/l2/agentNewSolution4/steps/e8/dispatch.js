export function ns4E8DetailsPlanId(reviewRound, repairRound = 0) {
    return `e8-workspaces-round-${reviewRound}-details-${repairRound}`;
}
export function hasNs4E8DetailsDispatch(steps, reviewRound, repairRound = 0) {
    const planId = ns4E8DetailsPlanId(reviewRound, repairRound);
    return steps.some(step => step.planning?.planId === planId);
}
export function isNs4E8PresentationRepairPlanId(planId) {
    return /^e8-workspaces-presentation-repair-[1-9]\d*-[1-9]\d*$/.test(planId);
}
export function isNs4E8ImplementedPlanId(planId) {
    return planId.startsWith('e8-workspaces-round-')
        || planId.startsWith('e8-workspaces-finalize-')
        || isNs4E8PresentationRepairPlanId(planId);
}
