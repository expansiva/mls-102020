export function ns4E8DetailsPlanId(reviewRound, repairRound = 0) {
    return `e8-workspaces-round-${reviewRound}-details-${repairRound}`;
}
export function hasNs4E8DetailsDispatch(steps, reviewRound, repairRound = 0) {
    const planId = ns4E8DetailsPlanId(reviewRound, repairRound);
    return steps.some(step => step.planning?.planId === planId);
}
