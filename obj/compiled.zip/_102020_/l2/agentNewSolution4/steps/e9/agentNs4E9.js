import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102020_/l2/agentNewSolution4/helpers/ns4StepTree.js';
import { isNs4Pipeline, markNs4E9Approved, markNs4E9Failed, markNs4E9Running, markNs4ModuleE9Approved, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
import { readNs4ApprovedJourneys, readNs4ApprovedOntology } from '/_102020_/l2/agentNewSolution4/helpers/ns4ApprovedArtifacts.js';
import { ns4AccessMatrixFile, ns4UseCaseFile, ns4UseCaseIndexFile, ns4WorkflowFile, ns4WorkflowIndexFile, ns4WorkspaceFile, ns4WorkspaceIndexFile, readNs4DefsJson, readNs4Module, readNs4Pipeline, writeNs4AccessMatrix, writeNs4BffContract, writeNs4Module, writeNs4NavigationIndex, writeNs4NavigationStore, writeNs4Notifications, writeNs4Pipeline, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Fs.js';
import { compileNs4E9 } from '/_102020_/l2/agentNewSolution4/steps/e9/contracts.js';
import { validateNs4E9 } from '/_102020_/l2/agentNewSolution4/steps/e9/gate.js';
export async function beforeNs4E9PromptStep(_agent, context, parent, step, hookSequential, args) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const pipeline = await requirePipeline(moduleName);
        if (pipeline.steps.e8?.status !== 'approved')
            throw new Error(`E9 requires an approved E8 workspace index for ${moduleName}.`);
        await writeNs4Pipeline(markNs4E9Running(pipeline));
        const sources = await loadSources(moduleName);
        const compilation = await compileNs4E9(sources);
        const gate = validateNs4E9(sources, compilation);
        if (!gate.ok)
            throw new Error(formatGate(gate.issues));
        const artifactPaths = [];
        for (const contract of compilation.contracts)
            artifactPaths.push(await writeNs4BffContract(moduleName, contract));
        artifactPaths.push(await writeNs4NavigationIndex(moduleName, compilation.navigation));
        artifactPaths.push(await writeNs4NavigationStore(moduleName, compilation.store));
        artifactPaths.push(await writeNs4Notifications(moduleName, compilation.notifications));
        artifactPaths.push(await writeNs4AccessMatrix(moduleName, compilation.access));
        const module = await readNs4Module(moduleName);
        if (!module)
            throw new Error(`Module artifact not found for ${moduleName}.`);
        const approvedAt = new Date().toISOString();
        await writeNs4Module(moduleName, markNs4ModuleE9Approved(module, approvedAt));
        await writeNs4Pipeline(markNs4E9Approved(await requirePipeline(moduleName), artifactPaths, approvedAt));
        const mutationParent = resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parent, step);
        return [result(context, mutationParent, {
                moduleName, contractCount: compilation.contracts.length, routeCount: compilation.navigation.routes.length,
                notificationCount: compilation.notifications.entries.length, navigationHash: compilation.navigation.navigationHash,
                artifactPaths,
            }), status(context, mutationParent, step, hookSequential, 'completed', `E9 compiled ${compilation.navigation.routes.length} routes, ${compilation.contracts.length} BFF contracts and ${compilation.notifications.entries.length} notifications.`, 'input_output')];
    }
    catch (error) {
        const message = errorMessage(error);
        if (moduleName)
            await fail(moduleName, message);
        return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function afterNs4E9PromptStep(_agent, context, parent, step, hookSequential) {
    const message = 'E9 is deterministic and must never receive an LLM response.';
    const parsed = resolveArgs(context, step.prompt);
    await fail(parsed.moduleName, message);
    return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
}
async function loadSources(moduleName) {
    const [journeys, ontology, access, workspaceIndex, useCaseIndex, workflowIndex] = await Promise.all([
        readNs4ApprovedJourneys(moduleName), readNs4ApprovedOntology(moduleName),
        readRequired(ns4AccessMatrixFile(moduleName), 'access matrix'),
        readRequired(ns4WorkspaceIndexFile(moduleName), 'workspace index'),
        readRequired(ns4UseCaseIndexFile(moduleName), 'use-case index'),
        readRequired(ns4WorkflowIndexFile(moduleName), 'workflow index'),
    ]);
    const [workspaces, useCases, workflows] = await Promise.all([
        Promise.all(workspaceIndex.workspaces.map(entry => readRequired(ns4WorkspaceFile(moduleName, entry.workspaceId), `workspace ${entry.workspaceId}`))),
        Promise.all(useCaseIndex.useCases.map(entry => readRequired(ns4UseCaseFile(moduleName, entry.useCaseId), `use case ${entry.useCaseId}`))),
        Promise.all(workflowIndex.workflows.map(entry => readRequired(ns4WorkflowFile(moduleName, entry.workflowId), `workflow ${entry.workflowId}`))),
    ]);
    return { journeys, access, ontology, useCases, workflows, workspaceIndex, workspaces };
}
async function readRequired(file, label) {
    let failure = '';
    for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
            const value = await readNs4DefsJson(file, true);
            if (value)
                return value;
        }
        catch (error) {
            failure = errorMessage(error);
        }
    }
    throw new Error(`Unable to read approved ${label}: ${failure || 'invalid artifact'}`);
}
function resolveArgs(context, value) {
    const root = parse(value);
    const moduleName = isRecord(root) && text(root.moduleName) ? text(root.moduleName) : findE8Module(context) || memory(context, 'resumeModule');
    if (!isRecord(root) || root.planId !== 'e9-navigation-compiler' || !moduleName)
        throw new Error('Invalid E9 step arguments or missing E8 module handoff.');
    return { planId: 'e9-navigation-compiler', moduleName };
}
function findE8Module(context) {
    const anchor = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e8-result');
    const value = anchor?.type === 'result' ? parse(anchor.result) : null;
    return isRecord(value) ? text(value.moduleName) : '';
}
async function requirePipeline(moduleName) { const pipeline = await readNs4Pipeline(moduleName); if (!isNs4Pipeline(pipeline))
    throw new Error(`agentNewSolution4 v31 pipeline not found for ${moduleName}.`); return pipeline; }
async function fail(moduleName, message) { try {
    const pipeline = await readNs4Pipeline(moduleName);
    if (isNs4Pipeline(pipeline))
        await writeNs4Pipeline(markNs4E9Failed(pipeline, message));
}
catch { /* task trace remains the fallback */ } }
function result(context, parent, value) { return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, step: { type: 'result', stepId: 0, interaction: null, stepTitle: 'E9 navigation compiled', status: 'completed', nextSteps: [], result: JSON.stringify({ ...value, completedStep: 'e9-navigation-compiler', nextStep: 'e10-validation' }, null, 2), planning: { planId: 'e9-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' } } }; }
function status(context, parent, step, hookSequential, state, traceMsg, cleaner) { return { type: 'update-status', hookSequential, messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, stepId: step.stepId, status: state, traceMsg, cleaner }; }
function formatGate(issues) { return issues.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n'); }
function parse(value) { if (typeof value !== 'string')
    return value; try {
    return JSON.parse(value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
}
catch {
    return value;
} }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function memory(context, key) { const value = context.task?.iaCompressed?.longMemory?.[key]; return typeof value === 'string' ? value.trim() : ''; }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
