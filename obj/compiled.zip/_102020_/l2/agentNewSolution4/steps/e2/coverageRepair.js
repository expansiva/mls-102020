/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e2/coverageRepair.ts" enhancement="_blank"/>
import { normalizeNs4E2Review, } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export function normalizeNs4E2CoveragePatch(value, fallbackModule = '', fallbackRound = 1) {
    const source = record(value);
    const normalized = normalizeNs4E2Review({
        moduleName: text(source.moduleName) || fallbackModule,
        reviewRound: positiveInteger(source.reviewRound, fallbackRound),
        journeys: array(source.journeyUpserts),
        features: array(source.featureUpserts),
    }, fallbackModule);
    return {
        planId: 'e2-coverage-patch',
        moduleName: normalized.moduleName,
        reviewRound: normalized.reviewRound,
        journeyUpserts: normalized.journeys,
        featureUpserts: normalized.features,
    };
}
export function validateNs4E2CoveragePatch(patch, expectedModule, expectedRound, allowNoOp = false) {
    const errors = [];
    if (patch.moduleName !== expectedModule)
        errors.push(`moduleName must be ${expectedModule}.`);
    if (patch.reviewRound !== expectedRound)
        errors.push(`reviewRound must be ${expectedRound}.`);
    if (!allowNoOp && !patch.journeyUpserts.length && !patch.featureUpserts.length) {
        errors.push('At least one journeyUpsert or featureUpsert is required.');
    }
    checkUniqueIds(patch.journeyUpserts.map(item => item.journeyId), 'journeyUpserts', errors);
    checkUniqueIds(patch.featureUpserts.map(item => item.featureId), 'featureUpserts', errors);
    return { ok: errors.length === 0, errors };
}
export function applyNs4E2CoveragePatch(previous, patch) {
    const journeys = upsertById(previous.journeys, patch.journeyUpserts, item => item.journeyId);
    const features = upsertById(previous.features, patch.featureUpserts, item => item.featureId);
    return {
        ...previous,
        moduleName: patch.moduleName,
        reviewRound: patch.reviewRound,
        journeys,
        features,
    };
}
function upsertById(current, upserts, readId) {
    const replacements = new Map(upserts.map(item => [readId(item), item]));
    const merged = current.map(item => {
        const id = readId(item);
        const replacement = replacements.get(id);
        if (replacement)
            replacements.delete(id);
        return replacement || item;
    });
    return [...merged, ...replacements.values()];
}
function checkUniqueIds(ids, path, errors) {
    const seen = new Set();
    ids.forEach((id, index) => {
        if (!id)
            errors.push(`${path}[${index}] must have an id.`);
        if (seen.has(id))
            errors.push(`${path}[${index}] duplicates ${id}.`);
        if (id)
            seen.add(id);
    });
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
