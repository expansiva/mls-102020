/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e2/contracts.ts" enhancement="_blank"/>
export const NS4_JOURNEY_SCHEMA_VERSION = '2026-08-04-ns4-journey-v1';
export const NS4_JOURNEY_INDEX_SCHEMA_VERSION = '2026-08-04-ns4-journey-index-v1';
export function normalizeNs4E2Review(value, fallbackModule = '') {
    const root = record(value);
    const journeys = array(root.journeys).map(normalizeJourney);
    const features = array(root.features).map(item => {
        const feature = record(item);
        return {
            featureId: text(feature.featureId),
            title: text(feature.title),
            priority: featurePriority(feature.priority),
            journeyStepRefs: strings(feature.journeyStepRefs),
        };
    });
    return {
        planId: 'e2-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Review business journeys',
        reviewRound: positiveInteger(root.reviewRound, 1),
        journeys,
        features,
    };
}
export async function buildNs4JourneyArtifacts(review) {
    return Promise.all(review.journeys.map(async (journey) => {
        const businessHash = await sha256Ns4(journey.business);
        return {
            schemaVersion: NS4_JOURNEY_SCHEMA_VERSION,
            journeyId: journey.journeyId,
            revision: 1,
            business: journey.business,
            businessHash,
            resolution: { status: 'pending', contexts: {} },
            realization: { status: 'pending', compiledFromBusinessHash: businessHash, steps: [], transitionRefs: [] },
        };
    }));
}
export function buildNs4JourneyIndex(moduleName, review, artifacts, artifactPaths, approvedBy, approvedAt) {
    return {
        schemaVersion: NS4_JOURNEY_INDEX_SCHEMA_VERSION,
        moduleName,
        approvedAt,
        approvedBy,
        journeys: artifacts.map((artifact, index) => ({
            journeyId: artifact.journeyId,
            actorRef: artifact.business.actorRef,
            title: artifact.business.title,
            goal: artifact.business.goal,
            entryMode: artifact.business.entry.mode,
            businessHash: artifact.businessHash,
            artifactPath: artifactPaths[index],
        })),
        features: review.features,
    };
}
export async function sha256Ns4(value) {
    const bytes = new TextEncoder().encode(stableNs4Stringify(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const hex = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    return `sha256:${hex}`;
}
export function stableNs4Stringify(value) {
    if (Array.isArray(value))
        return `[${value.map(stableNs4Stringify).join(',')}]`;
    if (value && typeof value === 'object') {
        const source = value;
        return `{${Object.keys(source).sort().map(key => `${JSON.stringify(key)}:${stableNs4Stringify(source[key])}`).join(',')}}`;
    }
    return JSON.stringify(value) ?? 'null';
}
function normalizeJourney(value) {
    const source = record(value);
    const business = record(source.business);
    const entry = record(business.entry);
    const outcome = record(business.outcome);
    return {
        journeyId: text(source.journeyId),
        business: {
            actorRef: text(business.actorRef),
            title: text(business.title),
            goal: text(business.goal),
            prerequisites: array(business.prerequisites).map(item => {
                const prerequisite = record(item);
                return {
                    journeyRef: text(prerequisite.journeyRef),
                    reason: text(prerequisite.reason),
                    required: boolean(prerequisite.required, true),
                    providesContext: strings(prerequisite.providesContext),
                };
            }),
            entry: {
                mode: entryMode(entry.mode),
                ...(text(entry.preferredFromJourneyRef) ? { preferredFromJourneyRef: text(entry.preferredFromJourneyRef) } : {}),
                carries: array(entry.carries).map(normalizeContext),
            },
            steps: array(business.steps).map(item => {
                const step = record(item);
                return {
                    stepId: text(step.stepId),
                    kind: stepKind(step.kind),
                    intent: text(step.intent),
                    requiresContext: strings(step.requiresContext),
                    providesContext: array(step.providesContext).map(normalizeContext),
                    result: text(step.result),
                    featureRefs: strings(step.featureRefs),
                };
            }),
            outcome: {
                statement: text(outcome.statement),
                evidence: strings(outcome.evidence),
            },
            businessRules: array(business.businessRules).map(item => {
                const rule = record(item);
                return { journeyRuleId: text(rule.journeyRuleId), statement: text(rule.statement) };
            }),
        },
    };
}
function normalizeContext(value) {
    const source = record(value);
    return {
        contextId: text(source.contextId),
        businessObject: text(source.businessObject),
        cardinality: source.cardinality === 'many' ? 'many' : 'one',
        required: boolean(source.required, true),
        description: text(source.description),
        ...(text(source.stateRequirement) ? { stateRequirement: text(source.stateRequirement) } : {}),
    };
}
function entryMode(value) {
    return value === 'contextRequired' || value === 'contextOrLookup' || value === 'eventDriven' ? value : 'coldStart';
}
function stepKind(value) {
    return value === 'inspect' || value === 'act' || value === 'decide' || value === 'handoff' ? value : 'locate';
}
function featurePriority(value) {
    return value === 'next' || value === 'later' ? value : 'now';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) {
    return Array.isArray(value) ? value : [];
}
function strings(value) {
    return array(value).map(text).filter(Boolean);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function boolean(value, fallback) {
    return typeof value === 'boolean' ? value : fallback;
}
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
