/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e2/widgetNs4Journeys.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Journeys102020 = class WidgetNs4Journeys102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-journeys-102020 {
  display: block;
  color: #18212f;
}
widget-ns4-journeys-102020 * {
  box-sizing: border-box;
}
widget-ns4-journeys-102020 h2,
widget-ns4-journeys-102020 h3,
widget-ns4-journeys-102020 h4,
widget-ns4-journeys-102020 p,
widget-ns4-journeys-102020 dl,
widget-ns4-journeys-102020 dd {
  margin: 0;
}
widget-ns4-journeys-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
widget-ns4-journeys-102020 ul,
widget-ns4-journeys-102020 ol {
  margin: 8px 0 0;
  padding-left: 20px;
}
widget-ns4-journeys-102020 li {
  line-height: 1.45;
  margin: 5px 0;
}
widget-ns4-journeys-102020 .ns4-journeys {
  display: grid;
  gap: 16px;
}
widget-ns4-journeys-102020 header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-journeys-102020 header p {
  color: #64748b;
  margin-top: 6px;
}
widget-ns4-journeys-102020 header > span,
widget-ns4-journeys-102020 .ns4-journey-head > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
}
widget-ns4-journeys-102020 .ns4-feature-list,
widget-ns4-journeys-102020 .ns4-journey,
widget-ns4-journeys-102020 footer {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 14px;
}
widget-ns4-journeys-102020 .ns4-feature-list > div {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 10px;
}
widget-ns4-journeys-102020 .ns4-feature-list article {
  align-items: center;
  background: #f8fafc;
  border-radius: 8px;
  display: flex;
  gap: 8px;
  padding: 8px 10px;
}
widget-ns4-journeys-102020 .ns4-feature-list article span {
  background: #dcfce7;
  border-radius: 999px;
  color: #166534;
  font-size: 11px;
  padding: 3px 6px;
}
widget-ns4-journeys-102020 .ns4-journey-list {
  display: grid;
  gap: 14px;
}
widget-ns4-journeys-102020 .ns4-journey {
  display: grid;
  gap: 14px;
}
widget-ns4-journeys-102020 .ns4-journey-head {
  align-items: start;
  display: flex;
  justify-content: space-between;
}
widget-ns4-journeys-102020 .ns4-journey-head h3 {
  margin-top: 3px;
}
widget-ns4-journeys-102020 dl {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-journeys-102020 dl > div,
widget-ns4-journeys-102020 .ns4-journey section {
  background: #f8fafc;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 dt {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 4px;
}
widget-ns4-journeys-102020 dd,
widget-ns4-journeys-102020 p {
  line-height: 1.45;
}
widget-ns4-journeys-102020 .ns4-steps {
  display: grid;
  gap: 8px;
  list-style-position: inside;
  padding: 0;
}
widget-ns4-journeys-102020 .ns4-steps li {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 9px;
}
widget-ns4-journeys-102020 .ns4-steps li > div {
  align-items: center;
  display: flex;
  gap: 8px;
}
widget-ns4-journeys-102020 .ns4-steps li > div span {
  color: #4338ca;
  font-size: 11px;
  text-transform: uppercase;
}
widget-ns4-journeys-102020 .ns4-steps p,
widget-ns4-journeys-102020 .ns4-steps small {
  color: #52606d;
  display: block;
  margin-top: 5px;
}
widget-ns4-journeys-102020 .ns4-two-columns {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-journeys-102020 footer {
  display: grid;
  gap: 12px;
}
widget-ns4-journeys-102020 footer label,
widget-ns4-journeys-102020 footer label span {
  display: grid;
  gap: 6px;
}
widget-ns4-journeys-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font: inherit;
  min-height: 100px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-journeys-102020 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-journeys-102020 button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  font: inherit;
  padding: 9px 14px;
}
widget-ns4-journeys-102020 button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-journeys-102020 button.secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-journeys-102020 button.primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
@media (max-width: 760px) {
  widget-ns4-journeys-102020 dl,
  widget-ns4-journeys-102020 .ns4-two-columns {
    grid-template-columns: 1fr;
  }
  widget-ns4-journeys-102020 header {
    display: grid;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
    }
    labels() {
        const pt = this.value?.userLanguage?.toLowerCase().startsWith('pt');
        return pt ? {
            subtitle: 'Estas jornadas serão a fonte de verdade permanente do produto.',
            actor: 'Ator', goal: 'Objetivo', entry: 'Entrada', prerequisites: 'Pré-requisitos',
            context: 'Contexto de negócio', steps: 'Passos', requires: 'Requer', provides: 'Produz',
            rules: 'Regras', outcome: 'Resultado e evidências', features: 'Funcionalidades',
            adjustment: 'O que deve mudar?', placeholder: 'Descreva a alteração necessária sem reescrever o que já está correto.',
            requestChanges: 'Pedir mudanças', approve: 'Aprovar jornadas', round: 'Revisão',
            adjustmentRequired: 'Escreva o que precisa mudar antes de solicitar uma nova versão.',
        } : {
            subtitle: 'These journeys will become the permanent source of truth for the product.',
            actor: 'Actor', goal: 'Goal', entry: 'Entry', prerequisites: 'Prerequisites',
            context: 'Business context', steps: 'Steps', requires: 'Requires', provides: 'Provides',
            rules: 'Rules', outcome: 'Outcome and evidence', features: 'Features',
            adjustment: 'What should change?', placeholder: 'Describe the needed change without rewriting what is already correct.',
            requestChanges: 'Request changes', approve: 'Approve journeys', round: 'Review',
            adjustmentRequired: 'Describe what must change before requesting another version.',
        };
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const labels = this.labels();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            window.alert(labels.adjustmentRequired);
            return;
        }
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-journeys-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value },
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        if (!this.value)
            return html `<div class="ns4-empty">No E2 review available.</div>`;
        const labels = this.labels();
        return html `
      <section class="ns4-journeys">
        <header>
          <div>
            <h2>${this.value.title}</h2>
            <p>${labels.subtitle}</p>
          </div>
          <span>${labels.round} ${this.value.reviewRound}</span>
        </header>

        <div class="ns4-feature-list">
          <h3>${labels.features}</h3>
          <div>
            ${this.value.features.map(feature => html `
              <article><strong>${feature.title}</strong><span>${feature.priority}</span><code>${feature.featureId}</code></article>
            `)}
          </div>
        </div>

        <div class="ns4-journey-list">
          ${this.value.journeys.map(journey => html `
            <article class="ns4-journey">
              <div class="ns4-journey-head">
                <div><code>${journey.journeyId}</code><h3>${journey.business.title}</h3></div>
                <span>${journey.business.entry.mode}</span>
              </div>
              <dl>
                <div><dt>${labels.actor}</dt><dd>${journey.business.actorRef}</dd></div>
                <div><dt>${labels.goal}</dt><dd>${journey.business.goal}</dd></div>
              </dl>

              <section>
                <h4>${labels.prerequisites}</h4>
                ${journey.business.prerequisites.length ? html `<ul>${journey.business.prerequisites.map(item => html `
                  <li><code>${item.journeyRef}</code> — ${item.reason}${item.providesContext.length ? html ` → <code>${item.providesContext.join(', ')}</code>` : ''}</li>
                `)}</ul>` : html `<p>—</p>`}
              </section>

              <section>
                <h4>${labels.entry} · ${labels.context}</h4>
                ${journey.business.entry.carries.length ? html `<ul>${journey.business.entry.carries.map(context => html `
                  <li><code>${context.contextId}</code> — ${context.businessObject}: ${context.description}${context.stateRequirement ? html ` (${context.stateRequirement})` : ''}</li>
                `)}</ul>` : html `<p>—</p>`}
              </section>

              <section>
                <h4>${labels.steps}</h4>
                <ol class="ns4-steps">${journey.business.steps.map(step => html `
                  <li>
                    <div><span>${step.kind}</span><strong>${step.intent}</strong><code>${step.stepId}</code></div>
                    <p>${step.result}</p>
                    <small>${labels.requires}: ${step.requiresContext.join(', ') || '—'} · ${labels.provides}: ${step.providesContext.map(item => item.contextId).join(', ') || '—'}</small>
                  </li>
                `)}</ol>
              </section>

              <section class="ns4-two-columns">
                <div><h4>${labels.rules}</h4><ul>${journey.business.businessRules.map(rule => html `<li><code>${rule.journeyRuleId}</code> — ${rule.statement}</li>`)}</ul></div>
                <div><h4>${labels.outcome}</h4><p>${journey.business.outcome.statement}</p><ul>${journey.business.outcome.evidence.map(item => html `<li>${item}</li>`)}</ul></div>
              </section>
            </article>
          `)}
        </div>

        <footer>
          <label><span>${labels.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${labels.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="secondary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('requestChanges')}>${labels.requestChanges}</button>
            <button class="primary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('approve')}>${labels.approve}</button>
          </div>
        </footer>
      </section>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Journeys102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Journeys102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "submitting", void 0);
WidgetNs4Journeys102020 = __decorate([
    customElement('widget-ns4-journeys-102020')
], WidgetNs4Journeys102020);
export { WidgetNs4Journeys102020 };
