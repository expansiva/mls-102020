export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL = 'moduleWithoutDecide';
const STEP_KINDS = ['locate', 'inspect', 'act', 'decide', 'handoff'];
export function analyzeNs4E2MechanicalCoverage(source) {
    const stepKindHistogram = {
        locate: 0,
        inspect: 0,
        act: 0,
        decide: 0,
        handoff: 0,
    };
    source.journeys.forEach(journey => journey.business.steps.forEach(step => {
        if (STEP_KINDS.includes(step.kind)) {
            stepKindHistogram[step.kind] += 1;
        }
    }));
    return {
        stepKindHistogram,
        findings: stepKindHistogram.decide === 0
            ? [{ signalId: NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL }]
            : [],
    };
}
