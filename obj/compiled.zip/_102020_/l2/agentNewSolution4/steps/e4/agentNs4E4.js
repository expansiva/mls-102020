/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e4/agentNs4E4.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102020_/l2/agentNewSolution4/helpers/ns4StepTree.js';
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { showNs4ClarificationError } from '/_102020_/l2/agentNewSolution4/helpers/ns4Clarification.js';
import { readNs4ApprovedAccess, readNs4ApprovedJourneys, readNs4ApprovedOntology, readNs4ApprovedOntologyEntity, } from '/_102020_/l2/agentNewSolution4/helpers/ns4ApprovedArtifacts.js';
import { createNs4E4FinalizeStep, createNs4E4RelationshipBindingStep, createNs4E4RepairStep, createNs4E4Step, plainNs4StepTitle, isNs4Pipeline, markNs4E3Approved, markNs4E4Approved, markNs4E4Failed, markNs4E4Running, markNs4E4WaitingHuman, markNs4ModuleE4Approved, NS4_E4_MAX_PARALLEL, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
import { ns4E4EntityDraftFile, ns4E4PlanDraftFile, readNs4AgentText, readNs4Module, readNs4Pipeline, readNs4Text, writeNs4E4Draft, writeNs4E4EntityDraft, writeNs4E4PlanDraft, writeNs4E4RelationshipBindingsDraft, writeNs4Module, writeNs4OntologyEntity, writeNs4OntologyIndex, writeNs4Pipeline, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Fs.js';
import { normalizeNs4E3Review, } from '/_102020_/l2/agentNewSolution4/steps/e3/contracts.js';
import { assembleNs4E4Review, applyNs4E4RelationshipBindings, buildNs4OntologyArtifacts, normalizeNs4E4EntityDraft, normalizeNs4E4PlanDraft, normalizeNs4E4RelationshipBindings, normalizeNs4E4Review, } from '/_102020_/l2/agentNewSolution4/steps/e4/contracts.js';
import { validateNs4E4EntityDraft, validateNs4E4Plan, validateNs4E4RelationshipBindings, validateNs4E4Review, } from '/_102020_/l2/agentNewSolution4/steps/e4/gate.js';
import { resolveNs4E4HookArgs, resolveNs4E4InvocationArgs } from '/_102020_/l2/agentNewSolution4/steps/e4/hookArgs.js';
const MAX_PLAN_REPAIRS = 1;
const MAX_ENTITY_REPAIR_ROUNDS = 1;
const MAX_RELATIONSHIP_BINDING_REPAIRS = 1;
export async function beforeNs4E4PromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution4:e4] task invalid');
    const hookArgs = resolveNs4E4HookArgs(args, step.prompt);
    const entityId = parseEntitySelector(hookArgs) || parseEntitySelector(step.prompt);
    let moduleName = '';
    try {
        const parsed = resolveE4Args(context, resolveNs4E4InvocationArgs(hookArgs, entityId));
        moduleName = parsed.moduleName;
        if (entityId)
            return [await buildEntityPrompt(context, parentStep, hookSequential, hookArgs, parsed, entityId)];
        if (parsed.stage === 'finalize') {
            return await finalizeOntology(context, parentStep, step, hookSequential, parsed);
        }
        if (parsed.stage === 'bindRelationships') {
            return [await buildRelationshipBindingPrompt(context, parentStep, hookSequential, hookArgs, parsed)];
        }
        if (!parsed.stage && !parsed.adjustment && !parsed.gateFeedback) {
            const resumed = await resumeRelationshipBindingFromValidDrafts(context, parentStep, step, hookSequential, parsed);
            if (resumed)
                return resumed;
        }
        return [await buildPlanPrompt(context, parentStep, hookSequential, hookArgs, parsed)];
    }
    catch (error) {
        const message = errorMessage(error);
        if (entityId) {
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Entity ${entityId} prompt failed; finalizer will repair it. | ${message}`, 'input_output')];
        }
        await recordNs4E4Failure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
async function buildPlanPrompt(context, parentStep, hookSequential, hookArgs, args) {
    const handoff = findE3Handoff(context, args.moduleName);
    const storedPipeline = await readNs4Pipeline(args.moduleName);
    if (!isNs4Pipeline(storedPipeline))
        throw new Error(`E3 approved pipeline not found for ${args.moduleName}.`);
    let pipeline = storedPipeline;
    if (pipeline.steps.e3?.status !== 'approved') {
        if (!handoff)
            throw new Error(`E3 approved pipeline state not found for ${args.moduleName}.`);
        pipeline = markNs4E3Approved(pipeline, handoff.approvedBy, handoff.artifactPath, handoff.approvedAt);
        await writeNs4Pipeline(pipeline);
    }
    const [moduleArtifact, journeys, access, prompt, platform] = await Promise.all([
        readNs4Module(args.moduleName),
        readNs4ApprovedJourneys(args.moduleName),
        handoff?.approvedReview ? Promise.resolve(handoff.approvedReview) : readNs4ApprovedAccess(args.moduleName),
        readNs4AgentText('steps/e4', 'prompt'),
        readNs4AgentText('skills', 'platform'),
    ]);
    if (!moduleArtifact)
        throw new Error(`E3 approved artifacts not found for ${args.moduleName}.`);
    if (moduleArtifact.solutionStrategy.mode !== 'newSolution') {
        throw new Error(`E4 modernization intake is not implemented for strategy ${moduleArtifact.solutionStrategy.mode}.`);
    }
    const reviewRound = args.reviewRound || pipeline.steps.e4?.reviewRound || 1;
    // A plan-gate repair runs before E4 has produced any approved ontology artifact. Its persisted
    // overview is supplied below as previousPlan; only a later human adjustment may read E4 output.
    const previousDraft = args.adjustment ? await readNs4ApprovedOntology(args.moduleName) : null;
    const previousPlan = args.gateFeedback ? await readOptionalPlanDraft(args.moduleName) : null;
    const humanPrompt = [
        '## Explicit delivery mode\nnew solution; new persistence design; no legacy database contract',
        `## Required review round\n${reviewRound}`,
        '## Approved module contract', JSON.stringify(moduleArtifact),
        '## Approved E2 journeys', JSON.stringify(journeys),
        '## Approved E3 access matrix', JSON.stringify(access),
        args.adjustment ? `## Human structural change request\n${args.adjustment}` : '',
        args.gateFeedback ? `## Deterministic gate repair required\n${args.gateFeedback}` : '',
        previousPlan ? `## Current invalid overview; repair it rather than starting over\n${JSON.stringify(previousPlan)}` : '',
        previousDraft ? `## Previous complete E4 review, including direct human edits\n${JSON.stringify(previousDraft)}` : '',
    ].filter(Boolean).join('\n\n');
    return promptReady(context, parentStep, hookSequential, hookArgs, prompt.replace('{{platformSkill}}', platform), humanPrompt);
}
async function resumeRelationshipBindingFromValidDrafts(context, parentStep, step, hookSequential, args) {
    const pipeline = await requirePipeline(args.moduleName);
    if (pipeline.steps.e4?.status !== 'failed')
        return null;
    const plan = await readOptionalPlanDraft(args.moduleName);
    if (!plan || plan.reviewRound !== (pipeline.steps.e4.reviewRound || 1))
        return null;
    const [journeys, access] = await Promise.all([
        readNs4ApprovedJourneys(args.moduleName), readNs4ApprovedAccess(args.moduleName),
    ]);
    if (!validateNs4E4Plan(plan, journeys, access).ok)
        return null;
    const details = [];
    for (const entity of plan.entities) {
        const detail = await readEntityDraft(args.moduleName, entity.entityId);
        if (!detail || !validateNs4E4EntityDraft(plan, detail).ok)
            return null;
        details.push(detail);
    }
    const review = assembleNs4E4Review(plan, details);
    if (!validateNs4E4Review(review, journeys, access, { requireRelationshipRealization: false }).ok)
        return null;
    const runningPipeline = markNs4E4Running(pipeline, plan.reviewRound);
    await writeNs4Pipeline(runningPipeline);
    const mutationParent = findMutableParentStep(context, parentStep);
    if (!review.relationships.length) {
        return openOntologyReview(context, mutationParent, step, hookSequential, review, runningPipeline, journeys, access);
    }
    return [
        addStep(context, mutationParent, createNs4E4RelationshipBindingStep(args.moduleName, plan.reviewRound)),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 resumed from ${details.length} revalidated entity drafts; continuing at relationship binding.`, 'input_output'),
    ];
}
async function buildEntityPrompt(context, parentStep, hookSequential, hookArgs, args, entityId) {
    const plan = await readPlanDraft(args.moduleName);
    const target = plan.entities.find(entity => entity.entityId === entityId);
    if (!target)
        throw new Error(`Entity ${entityId} is not present in the E4 overview.`);
    const [journeys, access, prompt, previousEntity, currentDetail] = await Promise.all([
        readNs4ApprovedJourneys(args.moduleName), readNs4ApprovedAccess(args.moduleName),
        readNs4AgentText('steps/e4', 'promptEntity'), readNs4ApprovedOntologyEntity(args.moduleName, entityId), readEntityDraft(args.moduleName, entityId),
    ]);
    const relatedJourneys = journeys.journeys.filter(journey => target.sourceRefs.journeyIds.includes(journey.journeyId));
    const relatedFeatures = journeys.features.filter(feature => target.sourceRefs.featureIds.includes(feature.featureId));
    const relatedAuthorities = access.authorities.filter(authority => target.sourceRefs.authorityRefs.includes(authority.authorityRef));
    const relatedGrants = access.grants.filter(grant => target.sourceRefs.authorityRefs.includes(grant.authorityRef));
    const touchingRelationships = plan.relationships.filter(rel => rel.fromEntity === entityId || rel.toEntity === entityId);
    const currentGate = currentDetail ? validateNs4E4EntityDraft(plan, currentDetail) : null;
    const upstreamRepairFeedback = memoryString(context, 'resumeFeedback');
    const humanPrompt = [
        '## Frozen target entity overview', JSON.stringify(target),
        '## All valid entity ids and storage targets', JSON.stringify(plan.entities.map(entity => ({ entityId: entity.entityId, storage: entity.storage.target }))),
        '## Relationships touching this entity', JSON.stringify(touchingRelationships),
        '## Related E2 journeys and features', JSON.stringify({ journeys: relatedJourneys, features: relatedFeatures }),
        '## Related E3 authorities and grants', JSON.stringify({ authorities: relatedAuthorities, grants: relatedGrants }),
        previousEntity ? `## Previous human-reviewed entity; preserve unaffected edits\n${JSON.stringify(previousEntity)}` : '',
        currentDetail ? `## Current entity draft\n${JSON.stringify(currentDetail)}` : '',
        currentGate && !currentGate.ok
            ? `## Entity gate repair required\n${formatGate(currentGate.issues)}` : '',
        upstreamRepairFeedback ? `## Downstream E5 contract gaps to resolve where this entity is relevant\n${upstreamRepairFeedback}` : '',
        `## Required identity\nmoduleName=${plan.moduleName}; reviewRound=${plan.reviewRound}; entityId=${entityId}; userLanguage=${plan.userLanguage}`,
    ].filter(Boolean).join('\n\n');
    return promptReady(context, parentStep, hookSequential, hookArgs, prompt, humanPrompt);
}
async function buildRelationshipBindingPrompt(context, parentStep, hookSequential, hookArgs, args) {
    const plan = await readPlanDraft(args.moduleName);
    const details = await readAllEntityDrafts(plan);
    const review = assembleNs4E4Review(plan, details);
    const prompt = await readNs4AgentText('steps/e4', 'promptRelationships');
    const compactEntities = review.entities.map(entity => ({
        entityId: entity.entityId,
        kind: entity.kind,
        storage: entity.storage,
        fields: entity.fields.map(field => ({
            fieldId: field.fieldId, type: field.type, required: field.required, description: field.description,
        })),
    }));
    const humanPrompt = [
        `## Required identity\nmoduleName=${review.moduleName}; reviewRound=${review.reviewRound}`,
        '## Frozen entities and their exact available fields', JSON.stringify(compactEntities),
        '## Frozen semantic relationships to bind', JSON.stringify(review.relationships.map(({ realization: _ignored, ...relationship }) => relationship)),
        args.gateFeedback ? `## Deterministic binding gate repair required\n${args.gateFeedback}` : '',
    ].filter(Boolean).join('\n\n');
    return promptReady(context, parentStep, hookSequential, hookArgs, prompt, humanPrompt);
}
export async function afterNs4E4PromptStep(agent, context, parentStep, step, hookSequential, args) {
    const entityId = parseEntitySelector(args) || parseEntitySelector(step.prompt);
    let moduleName = '';
    try {
        const args = resolveE4Args(context, resolveNs4E4InvocationArgs(String(step.prompt || ''), entityId));
        moduleName = args.moduleName;
        const mutationParent = findMutableParentStep(context, parentStep, entityId ? undefined : step);
        if (entityId)
            return await handleEntityResult(context, mutationParent, step, hookSequential, args, entityId);
        if (args.stage === 'bindRelationships') {
            return await handleRelationshipBindingResult(context, mutationParent, step, hookSequential, args);
        }
        return await handlePlanResult(agent, context, mutationParent, step, hookSequential, args);
    }
    catch (error) {
        const message = errorMessage(error);
        if (entityId) {
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Entity ${entityId} failed; finalizer will repair it. | ${message}`, 'input_output')];
        }
        await recordNs4E4Failure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
async function handlePlanResult(agent, context, mutationParent, step, hookSequential, args) {
    const pipeline = await requirePipeline(args.moduleName);
    const reviewRound = args.reviewRound || pipeline.steps.e4?.reviewRound || 1;
    await writeNs4Pipeline(markNs4E4Running(pipeline, reviewRound));
    const payload = unwrapPayload(step.interaction?.payload?.[0]);
    if (!isRecord(payload))
        throw new Error(readE4FailureMessage(payload));
    const plan = normalizeNs4E4PlanDraft(payload, args.moduleName);
    plan.moduleName = args.moduleName;
    plan.reviewRound = reviewRound;
    const [journeys, access] = await Promise.all([readNs4ApprovedJourneys(args.moduleName), readNs4ApprovedAccess(args.moduleName)]);
    const gate = validateNs4E4Plan(plan, journeys, access);
    if (!gate.ok) {
        const message = formatGate(gate.issues);
        await writeNs4E4PlanDraft(args.moduleName, plan);
        const attempt = args.repairAttempt || args.planRepairAttempt || 0;
        if (attempt < MAX_PLAN_REPAIRS) {
            return [
                addStep(context, mutationParent, createNs4E4RepairStep(args.moduleName, reviewRound, attempt + 1, message, pipeline.presentation.stepTitles['e4-ontology'])),
                gateRepairResultStep(context, mutationParent, args.moduleName, reviewRound, attempt + 1, message),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 overview gate requested repair ${attempt + 1}.`, 'input_output'),
            ];
        }
        await recordNs4E4Failure(args.moduleName, message);
        return [updateStatus(context, mutationParent, step, hookSequential, 'failed', message)];
    }
    await writeNs4E4PlanDraft(args.moduleName, plan);
    const currentPlanId = step.planning?.planId || `e4-ontology-round-${reviewRound}`;
    const planRepairAttempt = args.repairAttempt || args.planRepairAttempt || 0;
    return [
        parallelEntityStep(context, step, agent.agentName, plan, 0),
        addStep(context, mutationParent, createNs4E4FinalizeStep(args.moduleName, reviewRound, [currentPlanId], 0, planRepairAttempt)),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 overview ready; detailing ${plan.entities.length} entities with maxParallel=${NS4_E4_MAX_PARALLEL}.`, 'input_output'),
    ];
}
async function handleEntityResult(context, mutationParent, step, hookSequential, args, entityId) {
    const plan = await readPlanDraft(args.moduleName);
    const payload = unwrapPayload(step.interaction?.payload?.[0]);
    if (!isRecord(payload)) {
        return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} returned no usable payload; finalizer will repair it.`, 'input_output')];
    }
    const detail = normalizeNs4E4EntityDraft(payload, plan.moduleName, plan.reviewRound, entityId);
    await writeNs4E4EntityDraft(plan.moduleName, entityId, detail);
    const gate = validateNs4E4EntityDraft(plan, detail);
    if (!gate.ok) {
        return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} gate failed; finalizer will repair it. | ${formatGate(gate.issues)}`, 'input_output')];
    }
    return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} detail saved.`, 'input_output')];
}
async function handleRelationshipBindingResult(context, mutationParent, step, hookSequential, args) {
    const plan = await readPlanDraft(args.moduleName);
    const details = await readAllEntityDrafts(plan);
    const unboundReview = assembleNs4E4Review(plan, details);
    const payload = unwrapPayload(step.interaction?.payload?.[0]);
    if (!isRecord(payload))
        throw new Error(readE4FailureMessage(payload));
    const bindings = normalizeNs4E4RelationshipBindings(payload, plan.moduleName, plan.reviewRound);
    await writeNs4E4RelationshipBindingsDraft(args.moduleName, bindings);
    const [journeys, access, pipeline] = await Promise.all([
        readNs4ApprovedJourneys(args.moduleName), readNs4ApprovedAccess(args.moduleName), requirePipeline(args.moduleName),
    ]);
    const gate = validateNs4E4RelationshipBindings(unboundReview, bindings, journeys, access);
    if (!gate.ok) {
        const message = formatGate(gate.issues);
        const attempt = args.bindingRepairAttempt || 0;
        if (attempt < MAX_RELATIONSHIP_BINDING_REPAIRS) {
            return [
                addStep(context, mutationParent, createNs4E4RelationshipBindingStep(args.moduleName, plan.reviewRound, attempt + 1, message)),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `Relationship binding gate requested repair ${attempt + 1}.`, 'input_output'),
            ];
        }
        await recordNs4E4Failure(args.moduleName, message);
        return [updateStatus(context, mutationParent, step, hookSequential, 'failed', message, 'input_output')];
    }
    const review = applyNs4E4RelationshipBindings(unboundReview, bindings);
    return openOntologyReview(context, mutationParent, step, hookSequential, review, pipeline, journeys, access);
}
async function readAllEntityDrafts(plan) {
    const details = await Promise.all(plan.entities.map(entity => readEntityDraft(plan.moduleName, entity.entityId)));
    if (details.some(detail => !detail))
        throw new Error('E4 relationship binding cannot start before every entity detail exists.');
    return details;
}
async function finalizeOntology(context, parentStep, step, hookSequential, args) {
    const mutationParent = findMutableParentStep(context, parentStep);
    const [plan, pipeline] = await Promise.all([readPlanDraft(args.moduleName), requirePipeline(args.moduleName)]);
    const details = [];
    const invalid = [];
    for (const entity of plan.entities) {
        const detail = await readEntityDraft(args.moduleName, entity.entityId);
        if (!detail || !validateNs4E4EntityDraft(plan, detail).ok)
            invalid.push(entity.entityId);
        else
            details.push(detail);
    }
    const entityRepairRound = args.entityRepairRound || 0;
    if (invalid.length && entityRepairRound < MAX_ENTITY_REPAIR_ROUNDS) {
        const currentPlanId = step.planning?.planId || `e4-ontology-round-${plan.reviewRound}-finalize-${entityRepairRound}-${args.planRepairAttempt || 0}`;
        return [
            parallelEntityStep(context, step, 'agentNewSolution4', plan, entityRepairRound + 1, invalid),
            addStep(context, mutationParent, createNs4E4FinalizeStep(args.moduleName, plan.reviewRound, [currentPlanId], entityRepairRound + 1, args.planRepairAttempt || 0)),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `${invalid.length} invalid/missing entities; targeted parallel repair started: ${invalid.join(', ')}.`),
        ];
    }
    if (invalid.length) {
        const message = `E4 entities remain invalid after repair: ${invalid.join(', ')}.`;
        await recordNs4E4Failure(args.moduleName, message);
        return [updateStatus(context, mutationParent, step, hookSequential, 'failed', message)];
    }
    const review = assembleNs4E4Review(plan, details);
    const [journeys, access] = await Promise.all([readNs4ApprovedJourneys(args.moduleName), readNs4ApprovedAccess(args.moduleName)]);
    const gate = validateNs4E4Review(review, journeys, access, { requireRelationshipRealization: false });
    if (!gate.ok) {
        const message = formatGate(gate.issues);
        await writeNs4E4Draft(args.moduleName, review);
        const planRepairAttempt = args.planRepairAttempt || 0;
        if (planRepairAttempt < MAX_PLAN_REPAIRS) {
            return [
                addStep(context, mutationParent, createNs4E4RepairStep(args.moduleName, review.reviewRound, planRepairAttempt + 1, message, pipeline.presentation.stepTitles['e4-ontology'])),
                gateRepairResultStep(context, mutationParent, args.moduleName, review.reviewRound, planRepairAttempt + 1, message),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', 'Final aggregate gate requested one overview repair.', 'input_output'),
            ];
        }
        await recordNs4E4Failure(args.moduleName, message);
        return [updateStatus(context, mutationParent, step, hookSequential, 'failed', message)];
    }
    if (!review.relationships.length) {
        return openOntologyReview(context, mutationParent, step, hookSequential, review, pipeline, journeys, access);
    }
    return [
        addStep(context, mutationParent, createNs4E4RelationshipBindingStep(args.moduleName, review.reviewRound)),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 assembled ${review.entities.length} entities; binding ${review.relationships.length} relationships to exact fields.`, 'input_output'),
    ];
}
async function openOntologyReview(context, mutationParent, step, hookSequential, review, pipeline, journeys, access) {
    const gate = validateNs4E4Review(review, journeys, access);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    const draftPath = await writeNs4E4Draft(review.moduleName, review);
    await writeNs4Pipeline(markNs4E4WaitingHuman(await requirePipeline(review.moduleName), review.reviewRound, draftPath));
    if (isFast(context)) {
        const saved = await persistNs4E4(review.moduleName, review, 'auto', journeys, access);
        return [
            resultStep(context, mutationParent, saved, 'E4 ontology auto-approved'),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 auto-approved ${saved.entityCount} entities and ${saved.relationshipCount} bound relationships.`, 'input_output'),
        ];
    }
    return [
        clarificationReviewStep(context, mutationParent, review, pipeline.presentation.stepTitles['e4-ontology']),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E4 assembled ${review.entities.length} entities and bound ${review.relationships.length} relationships; human review opened.`, 'input_output'),
    ];
}
export async function beforeNs4E4ClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const review = normalizeNs4E4Review(parseMaybeJson(json));
    const [journeys, access] = await Promise.all([readNs4ApprovedJourneys(review.moduleName), readNs4ApprovedAccess(review.moduleName)]);
    const gate = validateNs4E4Review(review, journeys, access);
    if (!gate.ok) {
        const message = formatGate(gate.issues);
        await recordNs4E4Failure(review.moduleName, message);
        throw new Error(message);
    }
    await import('/_102020_/l2/agentNewSolution4/widgets/widgetNs4Ontology.js');
    const element = document.createElement('widget-ns4-ontology-102020');
    element.value = review;
    element.addEventListener('ns4-ontology-review', (event) => {
        const detail = event.detail;
        void applyNs4E4Review(context, parentStep, step, hookSequential, detail)
            .catch(error => { showNs4ClarificationError(element, error); console.error(`[${agent.agentName}] ${errorMessage(error)}`); });
    });
    return element;
}
async function applyNs4E4Review(context, parentStep, step, hookSequential, event) {
    if (!context.task)
        throw new Error('[agentNewSolution4:e4] task invalid');
    const mutationParent = findMutableParentStep(context, parentStep);
    if (event.action === 'cancel')
        throw new Error('Cancelamento terminal ainda depende de suporte explícito do collab-messages; esta revisão foi mantida aberta sem alterar o pipeline.');
    const [journeys, access] = await Promise.all([readNs4ApprovedJourneys(event.review.moduleName), readNs4ApprovedAccess(event.review.moduleName)]);
    const gate = validateNs4E4Review(event.review, journeys, access);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    await writeNs4E4Draft(event.review.moduleName, event.review);
    if (event.action === 'approve') {
        const saved = await persistNs4E4(event.review.moduleName, event.review, 'human', journeys, access);
        await applyIntents(context, [
            resultStep(context, mutationParent, saved, 'E4 ontology approved'),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
        ]);
    }
    else {
        if (!event.adjustment.trim())
            throw new Error('Structural change request cannot be empty.');
        const nextRound = event.review.reviewRound + 1;
        await writeNs4Pipeline(markNs4E4Running(await requirePipeline(event.review.moduleName), nextRound));
        await applyIntents(context, [
            addStep(context, mutationParent, createNs4E4Step(event.review.moduleName, nextRound, event.adjustment)),
            adjustmentResultStep(context, mutationParent, event.review.moduleName, event.review.reviewRound, event.adjustment),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
        ]);
    }
    await continuePoolingTask(context);
}
async function persistNs4E4(moduleName, review, approvedBy, journeys, access) {
    const gate = validateNs4E4Review(review, journeys, access);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    const [moduleArtifact, pipeline] = await Promise.all([readNs4Module(moduleName), requirePipeline(moduleName)]);
    if (!moduleArtifact || moduleArtifact.module.moduleName !== moduleName)
        throw new Error(`Invalid module artifact for ${moduleName}.`);
    const approvedAt = new Date().toISOString();
    const artifacts = await buildNs4OntologyArtifacts(review, approvedBy, approvedAt);
    const artifactPaths = [];
    for (const entity of artifacts.entities)
        artifactPaths.push(await writeNs4OntologyEntity(moduleName, entity.entityId, entity));
    artifactPaths.push(await writeNs4OntologyIndex(moduleName, artifacts.index));
    await writeNs4Module(moduleName, markNs4ModuleE4Approved(moduleArtifact, approvedBy, approvedAt));
    await writeNs4Pipeline(markNs4E4Approved(pipeline, approvedBy, artifactPaths, approvedAt, review.reviewRound));
    return { moduleName, solutionMode: 'new', entityCount: review.entities.length, relationshipCount: review.relationships.length, artifactPaths };
}
function parallelEntityStep(context, hostStep, agentName, plan, repairRound, entityIds = plan.entities.map(entity => entity.entityId)) {
    if (!context.task)
        throw new Error('[agentNewSolution4:e4] task invalid');
    if (!entityIds.length)
        throw new Error('E4 entity fan-out cannot be empty.');
    const planId = `e4-ontology-round-${plan.reviewRound}-entities-${repairRound}`;
    return {
        type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task.PK, parentStepId: hostStep.stepId,
        step: {
            type: 'agent', stepId: 0,
            interaction: { input: [{ type: 'system', content: '<!-- modelType: reasoning -->' }], cost: 0,
                trace: [`queued ${entityIds.length} E4 entities with maxParallel=${NS4_E4_MAX_PARALLEL}`], payload: null },
            stepTitle: 'Detailing {{completed}}/{{total}} ontology entities, failed {{failed}}',
            status: 'in_progress', nextSteps: [], agentName, onFailure: 'wait_after_prompt',
            prompt: JSON.stringify({ planId: 'e4-ontology' }), rags: [],
            planning: { planId, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
        },
        executionMode: { type: 'parallel', args: entityIds.map(entityId => `entity:${entityId}`), maxParallel: NS4_E4_MAX_PARALLEL },
    };
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt) {
    return {
        type: 'prompt_ready', args, messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', hookSequential, parentStepId: parentStep.stepId, systemPrompt, humanPrompt,
    };
}
async function readPlanDraft(moduleName) {
    const raw = await readNs4Text(ns4E4PlanDraftFile(moduleName), true);
    const parsed = parseMaybeJson(raw);
    if (!isRecord(parsed))
        throw new Error(`Invalid E4 overview for ${moduleName}.`);
    return normalizeNs4E4PlanDraft(parsed, moduleName);
}
async function readOptionalPlanDraft(moduleName) {
    const raw = await readNs4Text(ns4E4PlanDraftFile(moduleName), false);
    const parsed = parseMaybeJson(raw);
    return isRecord(parsed) ? normalizeNs4E4PlanDraft(parsed, moduleName) : null;
}
async function readEntityDraft(moduleName, entityId) {
    const raw = await readNs4Text(ns4E4EntityDraftFile(moduleName, entityId), false);
    const parsed = parseMaybeJson(raw);
    if (!isRecord(parsed))
        return null;
    const round = typeof parsed.reviewRound === 'number' ? parsed.reviewRound : 1;
    return normalizeNs4E4EntityDraft(parsed, moduleName, round, entityId);
}
async function requirePipeline(moduleName) {
    const pipeline = await readNs4Pipeline(moduleName);
    if (!isNs4Pipeline(pipeline))
        throw new Error(`agentNewSolution4 pipeline not found for ${moduleName}.`);
    return pipeline;
}
async function recordNs4E4Failure(moduleName, failure) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readNs4Pipeline(moduleName);
        if (isNs4Pipeline(pipeline))
            await writeNs4Pipeline(markNs4E4Failed(pipeline, failure));
    }
    catch { /* task trace is the fallback */ }
}
function findMutableParentStep(context, parentStep, phaseStep) {
    return resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parentStep, phaseStep);
}
function addStep(context, parentStep, step) {
    return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId, step };
}
function clarificationReviewStep(context, parentStep, review, title) {
    return addStep(context, parentStep, {
        type: 'clarification', stepId: 0, interaction: null,
        stepTitle: plainNs4StepTitle(title), status: 'pending', nextSteps: [],
        json: JSON.stringify(review),
        planning: { planId: `e4-ontology-review-round-${review.reviewRound}`, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    });
}
function resultStep(context, parentStep, saved, title) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: title, status: 'completed', nextSteps: [],
        result: JSON.stringify({ ...saved, completedStep: 'e4-ontology', nextStep: 'e5-rules' }, null, 2),
        planning: { planId: 'e4-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function adjustmentResultStep(context, parentStep, moduleName, round, adjustment) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: `E4 changes requested after round ${round}`,
        status: 'completed', nextSteps: [], result: JSON.stringify({ moduleName, reviewRound: round, adjustment }, null, 2),
        planning: { planId: `e4-adjustment-request-${Date.now()}`, dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function gateRepairResultStep(context, parentStep, moduleName, round, repairAttempt, gateFeedback) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: `E4 overview repair ${repairAttempt}`,
        status: 'completed', nextSteps: [], result: JSON.stringify({ moduleName, reviewRound: round, repairAttempt, gateFeedback }, null, 2),
        planning: { planId: `e4-gate-repair-${round}-${repairAttempt}-${Date.now()}`, dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return { type: 'update-status', hookSequential, messageId: context.message.orderAt,
        threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
        stepId: step.stepId, status, ...(traceMsg ? { traceMsg } : {}), ...(cleaner ? { cleaner } : {}) };
}
async function applyIntents(context, intents) {
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200)
        throw new Error(response?.msg || 'Error applying E4 intents.');
    const applied = response;
    context.task = applied.task;
    if (applied.message)
        context.message = applied.message;
}
function parseE4Args(value) {
    const parsed = parseMaybeJson(value);
    if (!isRecord(parsed) || parsed.planId !== 'e4-ontology')
        throw new Error('Invalid E4 step arguments.');
    return {
        planId: 'e4-ontology', solutionMode: 'new',
        ...(parsed.stage === 'finalize' || parsed.stage === 'plan' || parsed.stage === 'bindRelationships' ? { stage: parsed.stage } : {}),
        ...(typeof parsed.moduleName === 'string' && parsed.moduleName.trim() ? { moduleName: parsed.moduleName.trim() } : {}),
        ...(typeof parsed.adjustment === 'string' && parsed.adjustment.trim() ? { adjustment: parsed.adjustment.trim() } : {}),
        ...(typeof parsed.reviewRound === 'number' ? { reviewRound: parsed.reviewRound } : {}),
        ...(typeof parsed.repairAttempt === 'number' ? { repairAttempt: parsed.repairAttempt } : {}),
        ...(typeof parsed.entityRepairRound === 'number' ? { entityRepairRound: parsed.entityRepairRound } : {}),
        ...(typeof parsed.planRepairAttempt === 'number' ? { planRepairAttempt: parsed.planRepairAttempt } : {}),
        ...(typeof parsed.bindingRepairAttempt === 'number' ? { bindingRepairAttempt: parsed.bindingRepairAttempt } : {}),
        ...(typeof parsed.gateFeedback === 'string' && parsed.gateFeedback.trim() ? { gateFeedback: parsed.gateFeedback.trim() } : {}),
    };
}
function resolveE4Args(context, value) {
    const parsed = parseE4Args(value);
    const moduleName = parsed.moduleName || findE3ModuleName(context) || memoryString(context, 'resumeModule');
    if (!moduleName)
        throw new Error('E3 module result not found for E4.');
    return { ...parsed, moduleName };
}
function parseEntitySelector(value) {
    if (typeof value !== 'string')
        return '';
    const match = /^entity:([A-Z][A-Za-z0-9]*)$/.exec(value.trim());
    return match?.[1] || '';
}
function findE3ModuleName(context) {
    const result = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e3-result');
    if (!result || result.type !== 'result' || !result.result)
        return '';
    const parsed = parseMaybeJson(result.result);
    return isRecord(parsed) && typeof parsed.moduleName === 'string' ? parsed.moduleName.trim() : '';
}
function findE3Handoff(context, moduleName) {
    const result = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e3-result');
    if (!result || result.type !== 'result' || !result.result)
        return null;
    const parsed = parseMaybeJson(result.result);
    if (!isRecord(parsed) || parsed.moduleName !== moduleName
        || typeof parsed.artifactPath !== 'string' || !parsed.artifactPath.trim()
        || (parsed.approvedBy !== 'human' && parsed.approvedBy !== 'auto')
        || typeof parsed.approvedAt !== 'string' || !parsed.approvedAt.trim())
        return null;
    const approvedReview = isRecord(parsed.approvedReview) ? normalizeNs4E3Review(parsed.approvedReview, moduleName) : undefined;
    return { moduleName, artifactPath: parsed.artifactPath.trim(), approvedBy: parsed.approvedBy,
        approvedAt: parsed.approvedAt.trim(), ...(approvedReview ? { approvedReview } : {}) };
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function unwrapPayload(value) {
    const parsed = parseMaybeJson(value);
    if (isRecord(parsed) && parsed.type === 'flexible')
        return parseMaybeJson(parsed.result);
    if (isRecord(parsed) && parsed.type === 'clarification' && isRecord(parsed.json))
        return parsed.json;
    return parsed;
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function formatGate(issues) {
    return issues.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n');
}
function isFast(context) { return context.task?.iaCompressed?.longMemory?.fastMode === 'true'; }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
function readE4FailureMessage(payload) {
    if (isRecord(payload) && payload.type === 'result' && typeof payload.result === 'string' && payload.result.trim())
        return payload.result.trim();
    return 'E4 returned an invalid ontology payload.';
}
