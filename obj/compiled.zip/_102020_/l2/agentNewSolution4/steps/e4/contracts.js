/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e4/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_ONTOLOGY_SCHEMA_VERSION = '2026-08-08-ns4-ontology-v3';
export function normalizeNs4E4Review(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const entities = array(root.entities).map(item => normalizeEntity(item, moduleName));
    return {
        planId: 'e4-ontology-review',
        moduleName,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business ontology',
        reviewRound: positiveInteger(root.reviewRound, 1),
        solutionMode: 'new',
        businessDomain: text(root.businessDomain),
        entities,
        relationships: array(root.relationships).map(item => {
            const relationship = record(item);
            const fromEntity = text(relationship.fromEntity) || text(relationship.sourceEntity) || text(relationship.from);
            const toEntity = text(relationship.toEntity) || text(relationship.targetEntity) || text(relationship.to);
            return {
                relationshipId: text(relationship.relationshipId),
                fromEntity,
                toEntity,
                type: relationshipType(relationship.type),
                required: relationship.required === true,
                description: text(relationship.description),
                persistence: { mode: relationshipPersistenceMode(entities, fromEntity, toEntity) },
            };
        }),
        changeSummary: strings(root.changeSummary),
    };
}
export function normalizeNs4E4PlanDraft(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const full = normalizeNs4E4Review({
        ...root,
        moduleName,
        entities: array(root.entities).map(item => ({ ...record(item), fields: [], invariants: [] })),
    }, moduleName);
    return {
        planId: 'e4-ontology-plan',
        moduleName,
        userLanguage: full.userLanguage,
        title: full.title,
        reviewRound: full.reviewRound,
        solutionMode: 'new',
        businessDomain: full.businessDomain,
        entities: full.entities.map(({ fields, invariants, ...entity }) => entity),
        relationships: full.relationships,
        changeSummary: full.changeSummary,
    };
}
export function normalizeNs4E4EntityDraft(value, moduleName, reviewRound, entityId) {
    const root = record(value);
    const normalized = normalizeEntity({
        entityId,
        fields: root.fields,
        invariants: root.invariants,
    }, moduleName);
    return {
        planId: 'e4-ontology-entity',
        moduleName,
        reviewRound,
        entityId,
        fields: normalized.fields,
        invariants: normalized.invariants,
    };
}
export function assembleNs4E4Review(plan, details) {
    const byEntity = new Map(details.map(detail => [detail.entityId, detail]));
    return normalizeNs4E4Review({
        ...plan,
        planId: 'e4-ontology-review',
        entities: plan.entities.map(entity => ({
            ...entity,
            fields: byEntity.get(entity.entityId)?.fields || [],
            invariants: byEntity.get(entity.entityId)?.invariants || [],
        })),
    }, plan.moduleName);
}
export async function buildNs4OntologyArtifacts(review, approvedBy, approvedAt) {
    const ontologyHash = await sha256Ns4({
        solutionMode: review.solutionMode,
        businessDomain: review.businessDomain,
        entities: review.entities,
        relationships: review.relationships,
    });
    const entities = review.entities.map(entity => ({
        schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        solutionMode: review.solutionMode,
        ...entity,
        ontologyHash,
        approvedBy,
        approvedAt,
    }));
    return {
        entities,
        index: {
            schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
            moduleName: review.moduleName,
            userLanguage: review.userLanguage,
            solutionMode: review.solutionMode,
            title: review.title,
            businessDomain: review.businessDomain,
            entities: review.entities.map(entity => ({
                entityId: entity.entityId,
                title: entity.title,
                kind: entity.kind,
                storage: {
                    target: entity.storage.target,
                    scope: entity.storage.scope,
                    ...(entity.storage.idField ? { idField: entity.storage.idField } : {}),
                    ...(entity.storage.mdmType ? { mdmType: entity.storage.mdmType } : {}),
                },
                definitionRef: `l4/${review.moduleName}/ontology/${entity.entityId}.defs.ts`,
            })),
            relationships: review.relationships,
            ontologyHash,
            approvedBy,
            approvedAt,
            realization: { status: 'pending', compiledFromOntologyHash: ontologyHash },
        },
    };
}
function normalizeEntity(value, moduleName) {
    const entity = record(value);
    const sourceRefs = record(entity.sourceRefs);
    const storage = record(entity.storage);
    const entityId = text(entity.entityId);
    const kind = entityKind(entity.kind);
    const entityOwnership = ownership(entity.ownership);
    const fields = array(entity.fields).map(item => {
        const field = record(item);
        return {
            fieldId: text(field.fieldId),
            title: text(field.title),
            type: fieldType(field.type),
            required: field.required === true,
            description: text(field.description),
            constraints: array(field.constraints).map(constraintValue => {
                const constraint = record(constraintValue);
                return {
                    constraintId: text(constraint.constraintId),
                    kind: constraintKind(constraint.kind),
                    value: text(constraint.value),
                    description: text(constraint.description),
                    source: constraintSource(constraint.source),
                };
            }),
        };
    });
    const target = storageTarget(storage.target, kind, entityOwnership);
    const idField = text(storage.idField)
        || fields.find(field => field.required && /Id$/.test(field.fieldId))?.fieldId
        || '';
    return {
        entityId,
        title: text(entity.title),
        description: text(entity.description),
        kind,
        ownership: entityOwnership,
        sourceRefs: {
            journeyIds: strings(sourceRefs.journeyIds),
            featureIds: strings(sourceRefs.featureIds),
            authorityRefs: strings(sourceRefs.authorityRefs),
        },
        fields,
        lifecycleStates: strings(entity.lifecycleStates),
        lifecyclePredicates: array(entity.lifecyclePredicates).map(item => {
            const predicate = record(item);
            return {
                predicateId: text(predicate.predicateId),
                description: text(predicate.description),
                stateIds: strings(predicate.stateIds),
                source: constraintSource(predicate.source),
            };
        }),
        invariants: array(entity.invariants).map(item => {
            const invariant = record(item);
            return {
                invariantId: text(invariant.invariantId),
                description: text(invariant.description),
                source: constraintSource(invariant.source),
            };
        }),
        storage: {
            target,
            scope: storageScope(storage.scope, target),
            ...(idField && (target === 'mdm' || target === 'moduleDatabase') ? { idField } : {}),
            ...(target === 'mdm' ? { mdmType: text(storage.mdmType) || `${moduleName}.${entityId}` } : {}),
            notes: text(storage.notes),
        },
    };
}
function storageTarget(value, kind, entityOwnership) {
    if (value === 'mdm' || value === 'moduleDatabase' || value === 'derived'
        || value === 'external' || value === 'embedded')
        return value;
    if (entityOwnership === 'external')
        return 'external';
    if (kind === 'mdm')
        return 'mdm';
    if (kind === 'projection')
        return 'derived';
    if (kind === 'valueObject')
        return 'embedded';
    return 'moduleDatabase';
}
function storageScope(value, target) {
    if (value === 'organization' || value === 'module' || value === 'platform' || value === 'none')
        return value;
    if (target === 'mdm')
        return 'organization';
    if (target === 'moduleDatabase')
        return 'module';
    if (target === 'external')
        return 'platform';
    return 'none';
}
function entityKind(value) {
    if (value === 'event' || value === 'supporting' || value === 'mdm' || value === 'projection' || value === 'valueObject')
        return value;
    return 'core';
}
function ownership(value) {
    if (value === 'external' || value === 'derived')
        return value;
    return 'moduleOwned';
}
function fieldType(value) {
    if (value === 'uuid' || value === 'text' || value === 'number' || value === 'integer' || value === 'boolean'
        || value === 'money' || value === 'date' || value === 'datetime' || value === 'json')
        return value;
    return 'string';
}
function constraintKind(value) {
    if (value === 'min' || value === 'max' || value === 'minLength' || value === 'maxLength'
        || value === 'pattern' || value === 'enum' || value === 'format' || value === 'unique')
        return value;
    return 'custom';
}
function constraintSource(value) {
    if (value === 'database' || value === 'journey' || value === 'user' || value === 'legacyCode')
        return value;
    return 'inferred';
}
function relationshipType(value) {
    if (value === 'oneToOne' || value === 'manyToOne' || value === 'manyToMany')
        return value;
    return 'oneToMany';
}
function relationshipPersistenceMode(entities, fromEntity, toEntity) {
    const from = entities.find(entity => entity.entityId === fromEntity)?.storage.target;
    const to = entities.find(entity => entity.entityId === toEntity)?.storage.target;
    if (from === 'embedded' || to === 'embedded')
        return 'embedded';
    if (from === 'external' || to === 'external')
        return 'externalReference';
    if (from === 'derived' || to === 'derived')
        return 'derivedJoin';
    if (from === 'mdm' && to === 'mdm')
        return 'mdmRelationship';
    if ((from === 'mdm' && to === 'moduleDatabase') || (from === 'moduleDatabase' && to === 'mdm')) {
        return 'crossStoreReference';
    }
    return 'moduleReference';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
