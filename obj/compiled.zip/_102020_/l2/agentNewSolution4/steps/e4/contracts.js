/// <mls fileReference="_102020_/l2/agentNewSolution4/steps/e4/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
export const NS4_ONTOLOGY_SCHEMA_VERSION = '2026-08-05-ns4-ontology-v1';
export function normalizeNs4E4Review(value, fallbackModule = '') {
    const root = record(value);
    return {
        planId: 'e4-ontology-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business ontology',
        reviewRound: positiveInteger(root.reviewRound, 1),
        solutionMode: 'new',
        businessDomain: text(root.businessDomain),
        entities: array(root.entities).map(item => normalizeEntity(item)),
        relationships: array(root.relationships).map(item => {
            const relationship = record(item);
            return {
                relationshipId: text(relationship.relationshipId),
                fromEntity: text(relationship.fromEntity) || text(relationship.sourceEntity) || text(relationship.from),
                toEntity: text(relationship.toEntity) || text(relationship.targetEntity) || text(relationship.to),
                type: relationshipType(relationship.type),
                required: relationship.required === true,
                description: text(relationship.description),
            };
        }),
        changeSummary: strings(root.changeSummary),
    };
}
export async function buildNs4OntologyArtifacts(review, approvedBy, approvedAt) {
    const ontologyHash = await sha256Ns4({
        solutionMode: review.solutionMode,
        businessDomain: review.businessDomain,
        entities: review.entities,
        relationships: review.relationships,
    });
    const entities = review.entities.map(entity => ({
        schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        solutionMode: review.solutionMode,
        ...entity,
        ontologyHash,
        approvedBy,
        approvedAt,
    }));
    return {
        entities,
        index: {
            schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
            moduleName: review.moduleName,
            userLanguage: review.userLanguage,
            solutionMode: review.solutionMode,
            title: review.title,
            businessDomain: review.businessDomain,
            entities: review.entities.map(entity => ({
                entityId: entity.entityId,
                title: entity.title,
                kind: entity.kind,
                definitionRef: `l4/${review.moduleName}/ontology/${entity.entityId}.defs.ts`,
            })),
            relationships: review.relationships,
            ontologyHash,
            approvedBy,
            approvedAt,
            realization: { status: 'pending', compiledFromOntologyHash: ontologyHash },
        },
    };
}
function normalizeEntity(value) {
    const entity = record(value);
    const sourceRefs = record(entity.sourceRefs);
    const storage = record(entity.storage);
    return {
        entityId: text(entity.entityId),
        title: text(entity.title),
        description: text(entity.description),
        kind: entityKind(entity.kind),
        ownership: ownership(entity.ownership),
        sourceRefs: {
            journeyIds: strings(sourceRefs.journeyIds),
            featureIds: strings(sourceRefs.featureIds),
            authorityRefs: strings(sourceRefs.authorityRefs),
        },
        fields: array(entity.fields).map(item => {
            const field = record(item);
            return {
                fieldId: text(field.fieldId),
                title: text(field.title),
                type: fieldType(field.type),
                required: field.required === true,
                description: text(field.description),
                constraints: array(field.constraints).map(constraintValue => {
                    const constraint = record(constraintValue);
                    return {
                        constraintId: text(constraint.constraintId),
                        kind: constraintKind(constraint.kind),
                        value: text(constraint.value),
                        description: text(constraint.description),
                        source: constraintSource(constraint.source),
                    };
                }),
            };
        }),
        lifecycleStates: strings(entity.lifecycleStates),
        invariants: array(entity.invariants).map(item => {
            const invariant = record(item);
            return {
                invariantId: text(invariant.invariantId),
                description: text(invariant.description),
                source: constraintSource(invariant.source),
            };
        }),
        storage: { mode: 'new', notes: text(storage.notes) },
    };
}
function entityKind(value) {
    if (value === 'event' || value === 'supporting' || value === 'mdm' || value === 'projection' || value === 'valueObject')
        return value;
    return 'core';
}
function ownership(value) {
    if (value === 'external' || value === 'derived')
        return value;
    return 'moduleOwned';
}
function fieldType(value) {
    if (value === 'uuid' || value === 'text' || value === 'number' || value === 'integer' || value === 'boolean'
        || value === 'money' || value === 'date' || value === 'datetime' || value === 'json')
        return value;
    return 'string';
}
function constraintKind(value) {
    if (value === 'min' || value === 'max' || value === 'minLength' || value === 'maxLength'
        || value === 'pattern' || value === 'enum' || value === 'format' || value === 'unique')
        return value;
    return 'custom';
}
function constraintSource(value) {
    if (value === 'database' || value === 'journey' || value === 'user' || value === 'legacyCode')
        return value;
    return 'inferred';
}
function relationshipType(value) {
    if (value === 'oneToOne' || value === 'manyToOne' || value === 'manyToMany')
        return value;
    return 'oneToMany';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
