/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4Fs.ts" enhancement="_blank"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { normalizeNs4ModuleName } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
const AGENT_PROJECT = 102020;
const AGENT_FOLDER = 'agentNewSolution4';
export function ns4AgentFile(folder, shortName, extension) {
    return { project: AGENT_PROJECT, level: 2, folder: folder ? `${AGENT_FOLDER}/${folder}` : AGENT_FOLDER, shortName, extension };
}
export function ns4ModuleFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: normalizeNs4ModuleName(moduleName), shortName: 'module', extension: '.defs.ts' };
}
export function ns4PipelineFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'pipeline', extension: '.json' };
}
export function ns4E2DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e2-journeys.draft', extension: '.json' };
}
export function ns4E3DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e3-access-matrix.draft', extension: '.json' };
}
export function ns4AccessMatrixFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/access`, shortName: 'access-matrix', extension: '.defs.ts' };
}
export function ns4JourneyFile(moduleName, journeyId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/journeys`, shortName: journeyId, extension: '.defs.ts' };
}
export function ns4JourneyIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/journeys`, shortName: 'index', extension: '.defs.ts' };
}
export async function readNs4AgentText(folder, shortName) {
    return readNs4Text(ns4AgentFile(folder, shortName, '.md'), true);
}
export async function readNs4Pipeline(moduleName) {
    const raw = await readNs4Text(ns4PipelineFile(moduleName), false);
    if (!raw.trim())
        return null;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
export async function readNs4Module(moduleName) {
    const raw = await readNs4Text(ns4ModuleFile(moduleName), false);
    const json = extractNs4JsonObject(raw);
    if (!json)
        return null;
    try {
        return JSON.parse(json);
    }
    catch {
        return null;
    }
}
export async function writeNs4Pipeline(state) {
    const fileInfo = ns4PipelineFile(state.moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(state, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4Module(moduleName, artifact) {
    const fileInfo = ns4ModuleFile(moduleName);
    const exportName = `${normalizeNs4ModuleName(moduleName)}Module`;
    const source = `/// <mls fileReference="_${fileInfo.project}_/l4/${fileInfo.folder}/module.defs.ts" enhancement="_blank"/>\n\n`
        + `export const ${exportName} = ${JSON.stringify(artifact, null, 2)} as const;\n\n`
        + `export default ${exportName};\n`;
    await writeNs4Text(fileInfo, source);
    return displayPath(fileInfo);
}
export async function writeNs4E2Draft(moduleName, draft) {
    const fileInfo = ns4E2DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E3Draft(moduleName, draft) {
    const fileInfo = ns4E3DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4AccessMatrix(moduleName, artifact) {
    const fileInfo = ns4AccessMatrixFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}AccessMatrix`, artifact);
    return displayPath(fileInfo);
}
export async function writeNs4Journey(moduleName, journeyId, artifact) {
    const fileInfo = ns4JourneyFile(moduleName, journeyId);
    await writeNs4Defs(fileInfo, `${journeyId}Journey`, artifact);
    return displayPath(fileInfo);
}
export async function writeNs4JourneyIndex(moduleName, index) {
    const fileInfo = ns4JourneyIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}JourneyIndex`, index);
    return displayPath(fileInfo);
}
export function ns4FileExists(fileInfo) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    return !!file && file.status !== 'deleted';
}
export function listNs4ModuleFolders() {
    const project = mls.actualProject || 0;
    const modules = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.status === 'deleted' || !file.folder)
            continue;
        if (![1, 2, 4, 5].includes(file.level))
            continue;
        const first = file.folder.split('/')[0];
        if (!first || isGlobalFolder(file.level, first))
            continue;
        modules.add(normalizeNs4ModuleName(first));
    }
    return modules;
}
export async function readNs4Text(fileInfo, required) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted') {
        if (required)
            throw new Error(`[agentNewSolution4] file not found: ${displayPath(fileInfo)}`);
        return '';
    }
    const content = await file.getContent();
    if (typeof content === 'string')
        return content;
    if (fileInfo.extension === '.json' && typeof content === 'object' && content !== null) {
        return `${JSON.stringify(content, null, 2)}\n`;
    }
    if (required)
        throw new Error(`[agentNewSolution4] invalid text file: ${displayPath(fileInfo)}`);
    return '';
}
async function writeNs4Text(fileInfo, content) {
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = mls.stor.files[key];
    if (!file) {
        file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
    }
    else if (file.status === 'deleted') {
        file.status = 'changed';
        file.updatedAt = new Date().toISOString();
    }
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
async function writeNs4Defs(fileInfo, exportName, value) {
    const safeExportName = normalizeNs4ModuleName(exportName);
    const source = `/// <mls fileReference="_${fileInfo.project}_/l${fileInfo.level}/${fileInfo.folder}/${fileInfo.shortName}${fileInfo.extension}" enhancement="_blank"/>\n\n`
        + `export const ${safeExportName} = ${JSON.stringify(value, null, 2)} as const;\n\n`
        + `export default ${safeExportName};\n`;
    await writeNs4Text(fileInfo, source);
}
function extractNs4JsonObject(source) {
    const assignment = source.search(/export\s+const\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=/);
    const start = source.indexOf('{', Math.max(0, assignment));
    if (assignment < 0 || start < 0)
        return '';
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = start; index < source.length; index += 1) {
        const char = source[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"')
            inString = true;
        else if (char === '{')
            depth += 1;
        else if (char === '}' && --depth === 0)
            return source.slice(start, index + 1);
    }
    return '';
}
function displayPath(fileInfo) {
    return `l${fileInfo.level}/${fileInfo.folder ? `${fileInfo.folder}/` : ''}${fileInfo.shortName}${fileInfo.extension}`;
}
function isGlobalFolder(level, folder) {
    return level === 4 && ['actors', 'operations', 'rules', 'trace', 'workflows'].includes(folder);
}
