/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4Fs.ts" enhancement="_blank"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { normalizeNs4ModuleName } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
import { readNs4AvailableContent } from '/_102020_/l2/agentNewSolution4/helpers/ns4ContentRead.js';
import { renderNs4TypedDefsSource } from '/_102020_/l2/agentNewSolution4/helpers/ns4TypedDefs.js';
const AGENT_PROJECT = 102020;
const AGENT_FOLDER = 'agentNewSolution4';
export function ns4AgentFile(folder, shortName, extension) {
    return { project: AGENT_PROJECT, level: 2, folder: folder ? `${AGENT_FOLDER}/${folder}` : AGENT_FOLDER, shortName, extension };
}
export function ns4ModuleFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: normalizeNs4ModuleName(moduleName), shortName: 'module', extension: '.defs.ts' };
}
export function ns4PipelineFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'pipeline', extension: '.json' };
}
export function ns4E2DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e2-journeys.draft', extension: '.json' };
}
export function ns4E2VersionedDraftFile(moduleName, reviewRound) {
    return {
        project: mls.actualProject || 0,
        level: 4,
        folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`,
        shortName: `e2-journeys.draft.v${Math.max(1, Math.floor(reviewRound))}`,
        extension: '.json',
    };
}
export function ns4E2ImpactReportFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e2-impact-report', extension: '.json' };
}
export function ns4E3DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e3-access-matrix.draft', extension: '.json' };
}
export function ns4AccessMatrixFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/access`, shortName: 'access-matrix', extension: '.defs.ts' };
}
export function ns4E4DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e4-ontology.draft', extension: '.json' };
}
export function ns4E4PlanDraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e4-ontology-plan.draft', extension: '.json' };
}
export function ns4E4EntityDraftFile(moduleName, entityId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline/e4-entities`, shortName: `${entityId}.draft`, extension: '.json' };
}
export function ns4E4RelationshipBindingsDraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e4-relationship-bindings.draft', extension: '.json' };
}
export function ns4OntologyEntityFile(moduleName, entityId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/ontology`, shortName: entityId, extension: '.defs.ts' };
}
export function ns4OntologyIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/ontology`, shortName: 'index', extension: '.defs.ts' };
}
export function ns4E5DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e5-rules.draft', extension: '.json' };
}
export function ns4E5ApprovedFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e5-rules.approved', extension: '.json' };
}
export function ns4RulesFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/rules`, shortName: 'rules', extension: '.defs.ts' };
}
export function ns4E6DraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e6-composition.draft', extension: '.json' };
}
export function ns4E6ApprovedFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e6-composition.approved', extension: '.json' };
}
export function ns4CompositionFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/composition`, shortName: 'additional-capabilities', extension: '.defs.ts' };
}
export function ns4E7PlanDraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e7-realization-plan.draft', extension: '.json' };
}
export function ns4E7UseCaseDraftFile(moduleName, useCaseId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline/e7-usecases`, shortName: `${useCaseId}.draft`, extension: '.json' };
}
export function ns4E7ValidationReportFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`,
        shortName: 'e7-validation-report', extension: '.json' };
}
export function ns4UseCaseFile(moduleName, useCaseId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/usecases`, shortName: useCaseId, extension: '.defs.ts' };
}
export function ns4UseCaseIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/usecases`, shortName: 'index', extension: '.defs.ts' };
}
export function ns4WorkflowFile(moduleName, workflowId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/workflows`, shortName: workflowId, extension: '.defs.ts' };
}
export function ns4WorkflowIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/workflows`, shortName: 'index', extension: '.defs.ts' };
}
export function ns4E8SkeletonDraftFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e8-skeleton.draft', extension: '.json' };
}
export function ns4E8WorkspaceDraftFile(moduleName, workspaceId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline/e8-workspaces`, shortName: `${workspaceId}.draft`, extension: '.json' };
}
export function ns4E8ValidationReportFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e8-validation-report', extension: '.json' };
}
export function ns4WorkspaceFile(moduleName, workspaceId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/workspaces`, shortName: workspaceId, extension: '.defs.ts' };
}
export function ns4WorkspaceIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/workspaces`, shortName: 'index', extension: '.defs.ts' };
}
export function ns4NavigationIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/navigation`, shortName: 'index', extension: '.defs.ts' };
}
export function ns4NavigationStoreFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/navigation`, shortName: 'store', extension: '.defs.ts' };
}
export function ns4NotificationsFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/navigation`, shortName: 'notifications', extension: '.defs.ts' };
}
export function ns4BffContractFile(moduleName, workspaceId, functionId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/contracts`, shortName: `${workspaceId}.${functionId}`, extension: '.defs.ts' };
}
export function ns4E10ValidationReportFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/pipeline`, shortName: 'e10-validation-report', extension: '.json' };
}
export function ns4L5ConfigFile() {
    return { project: mls.actualProject || 0, level: 5, folder: '', shortName: 'config', extension: '.json' };
}
export function ns4TodoFrontendFile(moduleName) {
    return { project: mls.actualProject || 0, level: 5, folder: normalizeNs4ModuleName(moduleName), shortName: 'todoFrontend', extension: '.defs.ts' };
}
export function ns4TodoBackendFile(moduleName) {
    return { project: mls.actualProject || 0, level: 5, folder: normalizeNs4ModuleName(moduleName), shortName: 'todoBackend', extension: '.defs.ts' };
}
export function ns4ProcessFile(moduleName) {
    return { project: mls.actualProject || 0, level: 5, folder: normalizeNs4ModuleName(moduleName), shortName: 'process', extension: '.defs.ts' };
}
export function ns4JourneyFile(moduleName, journeyId) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/journeys`, shortName: journeyId, extension: '.defs.ts' };
}
export function ns4JourneyIndexFile(moduleName) {
    return { project: mls.actualProject || 0, level: 4, folder: `${normalizeNs4ModuleName(moduleName)}/journeys`, shortName: 'index', extension: '.defs.ts' };
}
export async function readNs4AgentText(folder, shortName) {
    return readNs4Text(ns4AgentFile(folder, shortName, '.md'), true);
}
export async function readNs4Pipeline(moduleName) {
    const raw = await readNs4Text(ns4PipelineFile(moduleName), false);
    if (!raw.trim())
        return null;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
export async function readNs4Module(moduleName) {
    const raw = await readNs4Text(ns4ModuleFile(moduleName), false);
    const json = extractNs4JsonObject(raw);
    if (!json)
        return null;
    try {
        return JSON.parse(json);
    }
    catch {
        return null;
    }
}
export async function writeNs4Pipeline(state) {
    const fileInfo = ns4PipelineFile(state.moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(state, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4Module(moduleName, artifact) {
    const fileInfo = ns4ModuleFile(moduleName);
    const exportName = `${normalizeNs4ModuleName(moduleName)}Module`;
    await writeNs4Defs(fileInfo, exportName, artifact, 'Ns4ModuleArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4E2Draft(moduleName, draft) {
    const fileInfo = ns4E2DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E2VersionedDraft(moduleName, reviewRound, draft) {
    const fileInfo = ns4E2VersionedDraftFile(moduleName, reviewRound);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E2ImpactReport(moduleName, report) {
    const fileInfo = ns4E2ImpactReportFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(report, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E3Draft(moduleName, draft) {
    const fileInfo = ns4E3DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E4Draft(moduleName, draft) {
    const fileInfo = ns4E4DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E4PlanDraft(moduleName, draft) {
    const fileInfo = ns4E4PlanDraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E4EntityDraft(moduleName, entityId, draft) {
    const fileInfo = ns4E4EntityDraftFile(moduleName, entityId);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E4RelationshipBindingsDraft(moduleName, draft) {
    const fileInfo = ns4E4RelationshipBindingsDraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E5Draft(moduleName, draft) {
    const fileInfo = ns4E5DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E5Approved(moduleName, review) {
    const fileInfo = ns4E5ApprovedFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(review, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E6Draft(moduleName, draft) {
    const fileInfo = ns4E6DraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E6Approved(moduleName, review) {
    const fileInfo = ns4E6ApprovedFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(review, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E7PlanDraft(moduleName, draft) {
    const fileInfo = ns4E7PlanDraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E7UseCaseDraft(moduleName, useCaseId, draft) {
    const fileInfo = ns4E7UseCaseDraftFile(moduleName, useCaseId);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E7ValidationReport(moduleName, report) {
    const fileInfo = ns4E7ValidationReportFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(report, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E8SkeletonDraft(moduleName, draft) {
    const fileInfo = ns4E8SkeletonDraftFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E8WorkspaceDraft(moduleName, workspaceId, draft) {
    const fileInfo = ns4E8WorkspaceDraftFile(moduleName, workspaceId);
    await writeNs4Text(fileInfo, `${JSON.stringify(draft, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4E8ValidationReport(moduleName, report) {
    const fileInfo = ns4E8ValidationReportFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(report, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4AccessMatrix(moduleName, artifact) {
    const fileInfo = ns4AccessMatrixFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}AccessMatrix`, artifact, 'Ns4AccessMatrixArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4OntologyEntity(moduleName, entityId, artifact) {
    const fileInfo = ns4OntologyEntityFile(moduleName, entityId);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}Entity${entityId}`, artifact, 'Ns4OntologyEntityArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4OntologyIndex(moduleName, artifact) {
    const fileInfo = ns4OntologyIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}OntologyIndex`, artifact, 'Ns4OntologyIndexArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4Rules(moduleName, artifact) {
    const fileInfo = ns4RulesFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}Rules`, artifact, 'Ns4RulesArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4Composition(moduleName, artifact) {
    const fileInfo = ns4CompositionFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}AdditionalCapabilities`, artifact, 'Ns4CompositionArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4UseCase(moduleName, useCaseId, artifact) {
    const fileInfo = ns4UseCaseFile(moduleName, useCaseId);
    await writeNs4Defs(fileInfo, `${useCaseId}UseCase`, artifact, 'Ns4UseCaseArtifactV3');
    return displayPath(fileInfo);
}
export async function writeNs4UseCaseIndex(moduleName, artifact) {
    const fileInfo = ns4UseCaseIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}UseCaseIndex`, artifact, 'Ns4UseCaseIndexArtifactV3');
    return displayPath(fileInfo);
}
export async function writeNs4Workflow(moduleName, workflowId, artifact) {
    const fileInfo = ns4WorkflowFile(moduleName, workflowId);
    await writeNs4Defs(fileInfo, `${workflowId}Workflow`, artifact, 'Ns4WorkflowArtifactV2');
    return displayPath(fileInfo);
}
export async function writeNs4WorkflowIndex(moduleName, artifact) {
    const fileInfo = ns4WorkflowIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}WorkflowIndex`, artifact, 'Ns4WorkflowIndexArtifactV3');
    return displayPath(fileInfo);
}
export async function writeNs4Workspace(moduleName, workspaceId, artifact) {
    const fileInfo = ns4WorkspaceFile(moduleName, workspaceId);
    await writeNs4Defs(fileInfo, `${workspaceId}Workspace`, artifact, 'Ns4WorkspaceArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4WorkspaceIndex(moduleName, artifact) {
    const fileInfo = ns4WorkspaceIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}WorkspaceIndex`, artifact, 'Ns4WorkspaceIndex');
    return displayPath(fileInfo);
}
export async function writeNs4NavigationIndex(moduleName, artifact) {
    const fileInfo = ns4NavigationIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}NavigationIndex`, artifact, 'Ns4NavigationIndexArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4NavigationStore(moduleName, artifact) {
    const fileInfo = ns4NavigationStoreFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}NavigationStore`, artifact, 'Ns4NavigationStoreArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4Notifications(moduleName, artifact) {
    const fileInfo = ns4NotificationsFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}Notifications`, artifact, 'Ns4NotificationCatalogArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4BffContract(moduleName, artifact) {
    const fileInfo = ns4BffContractFile(moduleName, artifact.workspaceId, artifact.functionId);
    await writeNs4Defs(fileInfo, `${artifact.workspaceId}${artifact.functionId}Contract`, artifact, 'Ns4BffContractArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4E10ValidationReport(moduleName, report) {
    const fileInfo = ns4E10ValidationReportFile(moduleName);
    await writeNs4Text(fileInfo, `${JSON.stringify(report, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function readNs4L5Config() {
    const raw = await readNs4Text(ns4L5ConfigFile(), false);
    if (!raw.trim())
        return null;
    try {
        const value = JSON.parse(raw);
        if (!value || typeof value !== 'object' || Array.isArray(value))
            throw new Error('root must be an object');
        return value;
    }
    catch (error) {
        throw new Error(`[agentNewSolution4] existing l5/config.json is invalid and was preserved: ${error instanceof Error ? error.message : String(error)}`);
    }
}
export async function writeNs4L5Config(config) {
    const fileInfo = ns4L5ConfigFile();
    await writeNs4Text(fileInfo, `${JSON.stringify(config, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeNs4TodoFrontend(moduleName, artifact) {
    const fileInfo = ns4TodoFrontendFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}TodoFrontend`, artifact, 'Ns4L5TodoFrontendArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4TodoBackend(moduleName, artifact) {
    const fileInfo = ns4TodoBackendFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}TodoBackend`, artifact, 'Ns4L5TodoBackendArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4Process(moduleName, artifact) {
    const fileInfo = ns4ProcessFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}Process`, artifact, 'Ns4L5ProcessArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4Journey(moduleName, journeyId, artifact) {
    const fileInfo = ns4JourneyFile(moduleName, journeyId);
    await writeNs4Defs(fileInfo, `${journeyId}Journey`, artifact, 'Ns4JourneyArtifact');
    return displayPath(fileInfo);
}
export async function writeNs4JourneyIndex(moduleName, index) {
    const fileInfo = ns4JourneyIndexFile(moduleName);
    await writeNs4Defs(fileInfo, `${normalizeNs4ModuleName(moduleName)}JourneyIndex`, index, 'Ns4JourneyIndex');
    return displayPath(fileInfo);
}
export function ns4FileExists(fileInfo) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    return !!file && file.status !== 'deleted';
}
export function listNs4ModuleFolders() {
    const project = mls.actualProject || 0;
    const modules = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.status === 'deleted' || !file.folder)
            continue;
        if (![1, 2, 4, 5].includes(file.level))
            continue;
        const first = file.folder.split('/')[0];
        if (!first || isGlobalFolder(file.level, first))
            continue;
        modules.add(normalizeNs4ModuleName(first));
    }
    return modules;
}
export async function readNs4Text(fileInfo, required) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted') {
        if (required)
            throw new Error(`[agentNewSolution4] file not found: ${displayPath(fileInfo)}`);
        return '';
    }
    // Files created during the current task have versionRef="0" until Studio persists them remotely.
    // Reading that sentinel through the GitHub driver requests /git/blobs/0. Prefer the authoritative
    // local value and fail locally if it is temporarily unavailable; never issue an invalid network read.
    const content = await readNs4AvailableContent(file, fileInfo.extension);
    if (content.unavailableNewFile) {
        if (required)
            throw new Error(`[agentNewSolution4] local content unavailable for new file: ${displayPath(fileInfo)}`);
        return '';
    }
    if (content.text !== null)
        return content.text;
    if (required)
        throw new Error(`[agentNewSolution4] invalid text file: ${displayPath(fileInfo)}`);
    return '';
}
export async function readNs4DefsJson(fileInfo, required = false) {
    const source = await readNs4Text(fileInfo, required);
    const json = extractNs4JsonObject(source);
    if (!json)
        return null;
    try {
        return JSON.parse(json);
    }
    catch {
        if (required)
            throw new Error(`[agentNewSolution4] invalid defs JSON: ${displayPath(fileInfo)}`);
        return null;
    }
}
async function writeNs4Text(fileInfo, content) {
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = mls.stor.files[key];
    if (!file) {
        file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
    }
    else if (file.status === 'deleted') {
        file.status = 'changed';
        file.updatedAt = new Date().toISOString();
    }
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
async function writeNs4Defs(fileInfo, exportName, value, artifactType) {
    await writeNs4Text(fileInfo, renderNs4TypedDefsSource(fileInfo, exportName, value, artifactType));
}
function extractNs4JsonObject(source) {
    const assignment = source.search(/export\s+const\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=/);
    const start = source.indexOf('{', Math.max(0, assignment));
    if (assignment < 0 || start < 0)
        return '';
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = start; index < source.length; index += 1) {
        const char = source[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"')
            inString = true;
        else if (char === '{')
            depth += 1;
        else if (char === '}' && --depth === 0)
            return source.slice(start, index + 1);
    }
    return '';
}
function displayPath(fileInfo) {
    return `l${fileInfo.level}/${fileInfo.folder ? `${fileInfo.folder}/` : ''}${fileInfo.shortName}${fileInfo.extension}`;
}
function isGlobalFolder(level, folder) {
    return level === 4 && ['actors', 'operations', 'rules', 'trace', 'workflows'].includes(folder);
}
