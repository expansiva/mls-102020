/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4ApprovedArtifacts.ts" enhancement="_blank"/>
import { isNs4Pipeline } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
import { ns4AccessMatrixFile, ns4JourneyFile, ns4JourneyIndexFile, ns4OntologyEntityFile, ns4OntologyIndexFile, readNs4DefsJson, readNs4Module, readNs4Pipeline, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Fs.js';
import { isNs4CurrentJourneyBusiness, normalizeNs4E2Review, } from '/_102020_/l2/agentNewSolution4/steps/e2/contracts.js';
import { normalizeNs4E3Review, } from '/_102020_/l2/agentNewSolution4/steps/e3/contracts.js';
import { normalizeNs4E4Review, } from '/_102020_/l2/agentNewSolution4/steps/e4/contracts.js';
export async function readNs4ApprovedJourneys(moduleName) {
    const [module, pipeline, index] = await Promise.all([
        readNs4Module(moduleName),
        readNs4Pipeline(moduleName),
        readRequiredDefs(ns4JourneyIndexFile(moduleName), 'journey index'),
    ]);
    if (!module || !isNs4Pipeline(pipeline) || index.moduleName !== moduleName) {
        throw new Error(`Approved journey ownership is invalid for ${moduleName}.`);
    }
    const artifacts = await mapInBatches(index.journeys, entry => readRequiredDefs(ns4JourneyFile(moduleName, entry.journeyId), `journey ${entry.journeyId}`));
    const byId = new Map(artifacts.map(artifact => [artifact.journeyId, artifact]));
    const journeys = index.journeys.map(entry => {
        const artifact = byId.get(entry.journeyId);
        if (!artifact || artifact.businessHash !== entry.businessHash) {
            throw new Error(`Approved journey artifact mismatch: ${entry.journeyId}.`);
        }
        // A journey of a previous flow version still declares its context graph. Nothing derives from it,
        // so resuming on it would silently produce a contextless skeleton instead of failing.
        if (!isNs4CurrentJourneyBusiness(artifact.business)) {
            throw new Error(`Approved journey ${entry.journeyId} belongs to a previous flow version and is never migrated.`);
        }
        return artifact;
    });
    if (byId.size !== index.journeys.length) {
        throw new Error(`Approved journey index contains duplicate or unexpected artifacts for ${moduleName}.`);
    }
    return normalizeNs4E2Review({
        moduleName,
        userLanguage: module.presentation.userLanguage,
        reviewRound: pipeline.steps.e2?.reviewRound || 1,
        journeys,
        features: index.features,
    }, moduleName);
}
export async function readNs4ApprovedAccess(moduleName) {
    const artifact = await readRequiredDefs(ns4AccessMatrixFile(moduleName), 'access matrix');
    if (artifact.moduleName !== moduleName)
        throw new Error(`Approved access ownership is invalid for ${moduleName}.`);
    return normalizeNs4E3Review(artifact, moduleName);
}
export async function readNs4ApprovedOntology(moduleName) {
    const [pipeline, index] = await Promise.all([
        readNs4Pipeline(moduleName),
        readRequiredDefs(ns4OntologyIndexFile(moduleName), 'ontology index'),
    ]);
    if (!isNs4Pipeline(pipeline) || index.moduleName !== moduleName) {
        throw new Error(`Approved ontology ownership is invalid for ${moduleName}.`);
    }
    const artifacts = await mapInBatches(index.entities, entry => readRequiredDefs(ns4OntologyEntityFile(moduleName, entry.entityId), `ontology entity ${entry.entityId}`));
    const byId = new Map(artifacts.map(artifact => [artifact.entityId, artifact]));
    const entities = index.entities.map(entry => {
        const artifact = byId.get(entry.entityId);
        if (!artifact || artifact.moduleName !== moduleName || artifact.ontologyHash !== index.ontologyHash) {
            throw new Error(`Approved ontology artifact mismatch: ${entry.entityId}.`);
        }
        return artifact;
    });
    if (byId.size !== index.entities.length) {
        throw new Error(`Approved ontology index contains duplicate or unexpected artifacts for ${moduleName}.`);
    }
    return normalizeNs4E4Review({
        moduleName,
        userLanguage: index.userLanguage,
        title: index.title,
        reviewRound: pipeline.steps.e4?.reviewRound || 1,
        solutionMode: index.solutionMode,
        businessDomain: index.businessDomain,
        entities,
        relationships: index.relationships,
        changeSummary: [],
    }, moduleName);
}
export async function readNs4ApprovedOntologyEntity(moduleName, entityId) {
    const artifact = await readOptionalDefs(ns4OntologyEntityFile(moduleName, entityId), `ontology entity ${entityId}`);
    return artifact?.moduleName === moduleName ? artifact : null;
}
async function readRequiredDefs(fileInfo, label) {
    let failure = '';
    for (let attempt = 1; attempt <= 2; attempt += 1) {
        try {
            const artifact = await readNs4DefsJson(fileInfo, true);
            if (artifact)
                return artifact;
            failure = 'storage returned non-parseable content';
        }
        catch (error) {
            failure = error instanceof Error ? error.message : String(error);
        }
    }
    throw new Error(`Unable to read approved ${label} after 2 attempts: ${failure}`);
}
async function readOptionalDefs(fileInfo, label) {
    for (let attempt = 1; attempt <= 2; attempt += 1) {
        try {
            const artifact = await readNs4DefsJson(fileInfo, false);
            if (artifact)
                return artifact;
        }
        catch { /* optional previous artifact */ }
    }
    return null;
}
async function mapInBatches(items, load) {
    const result = [];
    for (let index = 0; index < items.length; index += 5) {
        result.push(...await Promise.all(items.slice(index, index + 5).map(load)));
    }
    return result;
}
