/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4WorkerTools.ts" enhancement="_blank"/>
/**
 * Shared mechanics for strict artifact workers.  Step-specific artifact schemas stay under
 * `schemas/`; this helper only makes their result a payload that collab-messages can schedule.
 */
export function createNs4FlexibleWorkerTool(toolName, description, artifactSchema) {
    const result = { ...artifactSchema };
    const defs = result.$defs;
    delete result.$defs;
    delete result.$id;
    delete result.$schema;
    const parameters = {
        type: 'object',
        additionalProperties: false,
        required: ['type', 'result'],
        properties: {
            type: { type: 'string', const: 'flexible' },
            result,
        },
    };
    if (isRecord(defs))
        parameters.$defs = defs;
    return { type: 'function', function: { name: toolName, description, parameters } };
}
/** Keeps already persisted raw worker payloads resumable while new workers use the envelope. */
export function unwrapNs4FlexibleWorkerPayload(value) {
    const root = parse(value);
    return isRecord(root) && root.type === 'flexible' ? parse(root.result) : root;
}
function parse(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
