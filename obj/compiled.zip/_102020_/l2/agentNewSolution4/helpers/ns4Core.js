/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4Core.ts" enhancement="_blank"/>
export const NS4_FLOW_ID = 'agentNewSolution4';
export const NS4_FLOW_VERSION = '2026-08-05-ns4-flow-v3';
export const NS4_MODULE_SCHEMA_VERSION = '2026-08-05-ns4-module-v2';
export const NS4_PIPELINE_SCHEMA_VERSION = '2026-08-05-ns4-pipeline-v2';
export const NS4_PLAN_IDS = [
    'e1-clarification',
    'e1-compile',
    'e2-journeys',
    'e3-ontology',
    'e4-rules',
    'e5-behaviors',
    'e6-realization',
    'e7-workspaces',
    'e8-navigation-compiler',
    'e9-validation',
];
export function parseNs4Invocation(value) {
    const raw = String(value || '');
    const fast = /(^|\s)\/fast(?=\s|$)/i.test(raw);
    const prompt = raw.replace(/(^|\s)\/fast(?=\s|$)/gi, '$1').replace(/\s+/g, ' ').trim();
    return { fast, prompt };
}
export function createNs4E2Step(moduleName = '', reviewRound = 1, adjustment = '', dependsOn = [], stepTitle = NS4_DEFAULT_TITLES['e2-journeys']) {
    const suffix = adjustment ? ` adjustment ${reviewRound}` : '';
    return createNs4AgentStep(`e2-journeys-round-${reviewRound}`, `${stepTitle}${suffix}`, dependsOn, dependsOn.length ? 'waiting_dependency' : 'waiting_human_input', { planId: 'e2-journeys', ...(moduleName ? { moduleName } : {}), reviewRound, ...(adjustment ? { adjustment } : {}) });
}
export const NS4_DEFAULT_TITLES = {
    'e1-clarification': 'Clarify the module contract',
    'e1-compile': 'Compile the initial module contract',
    'e2-journeys': 'Define and approve business journeys',
    'e3-ontology': 'Define the business ontology',
    'e4-rules': 'Organize actors and business rules',
    'e5-behaviors': 'Define workflows and operations',
    'e6-realization': 'Connect journeys to system behavior',
    'e7-workspaces': 'Design actor workspaces',
    'e8-navigation-compiler': 'Compile navigation and page context',
    'e9-validation': 'Validate the complete L4 specification',
};
export function normalizeNs4RootPlan(payload, sourcePrompt) {
    const parsed = parseMaybeJson(payload);
    const result = asRecord(parsed).type === 'flexible' ? parseMaybeJson(asRecord(parsed).result) : parsed;
    const record = asRecord(result);
    const userPrompt = readString(record.userPrompt) || sourcePrompt.trim();
    const userLanguage = normalizeNs4Languages(record.userLanguage, inferNs4PromptLanguage(userPrompt))[0];
    const rawTitles = asRecord(record.titles);
    const missingTitles = [];
    const stepTitles = {};
    for (const planId of NS4_PLAN_IDS) {
        const title = readString(rawTitles[planId]);
        if (!title || title.length >= 140)
            missingTitles.push(planId);
        stepTitles[planId] = title && title.length < 140 ? title : NS4_DEFAULT_TITLES[planId];
    }
    const validEnvelope = record.validPrompt === true
        && !!readString(record.userPrompt)
        && !!readString(record.userLanguage)
        && missingTitles.length === 0;
    const invalidReason = readString(record.invalidReason)
        || (!validEnvelope ? `Root planner returned an incomplete contract${missingTitles.length ? `; missing titles: ${missingTitles.join(', ')}` : ''}.` : '');
    return {
        validPrompt: validEnvelope && userPrompt.length >= 2,
        ...(invalidReason ? { invalidReason } : {}),
        userPrompt,
        presentation: { userLanguage, stepTitles },
        clarification: normalizeNs4Clarification({
            ...asRecord(record.clarification),
            userLanguage,
            planId: 'e1-clarification',
        }),
    };
}
export function buildNs4PlannedSteps(plan) {
    const title = (planId) => plan.presentation.stepTitles[planId] || NS4_DEFAULT_TITLES[planId];
    return [
        createNs4AgentStep('e1-clarification', title('e1-clarification'), [], 'waiting_human_input', { planId: 'e1-clarification' }),
        createNs4AgentStep('e1-compile', title('e1-compile'), ['e1-clarification-answer'], 'waiting_dependency', { planId: 'e1-compile' }),
        createNs4E2Step('', 1, '', ['e1-result'], title('e2-journeys')),
        createNs4RoadmapStep('e3-ontology', title('e3-ontology'), ['e2-result']),
        createNs4RoadmapStep('e4-rules', title('e4-rules'), ['e3-result']),
        createNs4RoadmapStep('e5-behaviors', title('e5-behaviors'), ['e4-result']),
        createNs4RoadmapStep('e6-realization', title('e6-realization'), ['e5-result']),
        createNs4RoadmapStep('e7-workspaces', title('e7-workspaces'), ['e6-result']),
        createNs4RoadmapStep('e8-navigation-compiler', title('e8-navigation-compiler'), ['e7-result']),
        createNs4RoadmapStep('e9-validation', title('e9-validation'), ['e8-result']),
    ];
}
function createNs4RoadmapStep(planId, stepTitle, dependsOn) {
    const step = createNs4AgentStep(planId, stepTitle, dependsOn, 'waiting_dependency', { planId });
    step.planning = { ...step.planning, executionMode: 'manual_later' };
    return step;
}
function createNs4AgentStep(planningPlanId, stepTitle, dependsOn, status, prompt) {
    return {
        type: 'agent', stepId: 0, interaction: null, stepTitle, status, nextSteps: [],
        agentName: 'agentNewSolution4', prompt: JSON.stringify(prompt), rags: [],
        planning: { planId: planningPlanId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
export function isNs4ModuleToken(value) {
    return /^[a-z][A-Za-z0-9]*$/.test(String(value || '').trim());
}
export function normalizeNs4ModuleName(value, fallback = 'newModule') {
    const raw = readString(value) || fallback;
    const ascii = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const words = ascii.replace(/([a-z0-9])([A-Z])/g, '$1 $2').split(/[^A-Za-z0-9]+/).filter(Boolean);
    if (words.length === 0)
        return 'newModule';
    const first = words[0].toLowerCase();
    const rest = words.slice(1).map(word => word.slice(0, 1).toUpperCase() + word.slice(1).toLowerCase()).join('');
    const candidate = `${first}${rest}`.replace(/^[^a-z]+/, '').slice(0, 60);
    return candidate || 'newModule';
}
export function normalizeNs4Clarification(value) {
    const record = asRecord(value);
    const questionsRecord = asRecord(record.questions);
    const questionIds = ['moduleName', 'productLanguages', 'mainActors', 'mainGoal', 'boundaries'];
    const questions = {};
    for (const id of questionIds) {
        const question = asRecord(questionsRecord[id]);
        questions[id] = {
            type: 'open',
            question: readString(question.question) || id,
            answer: readString(question.answer) || '',
        };
    }
    return {
        planId: 'e1-clarification',
        userLanguage: normalizeNs4Languages(record.userLanguage, 'en')[0],
        title: readString(record.title) || 'Clarification 1',
        legends: Array.isArray(record.legends) ? record.legends.map(readString).filter((item) => !!item) : [],
        questions,
    };
}
export function buildNs4ModuleArtifact(sourcePrompt, clarificationInput, approvedBy, now = new Date().toISOString(), presentation = defaultNs4Presentation(sourcePrompt)) {
    const clarification = normalizeNs4Clarification(clarificationInput);
    const moduleName = normalizeNs4ModuleName(clarification.questions.moduleName.answer, sourcePrompt);
    const mainGoal = clarification.questions.mainGoal.answer.trim() || `Define the ${humanizeNs4ModuleName(moduleName)} business module.`;
    const productLanguages = normalizeNs4Languages(clarification.questions.productLanguages.answer, clarification.userLanguage);
    return {
        schemaVersion: NS4_MODULE_SCHEMA_VERSION,
        presentation,
        module: {
            moduleName,
            title: humanizeNs4ModuleName(moduleName),
            purpose: mainGoal,
            languages: productLanguages,
        },
        designContext: {
            initialPrompt: sourcePrompt.trim() || moduleName,
            clarification: {
                mainActors: clarification.questions.mainActors.answer.trim(),
                mainGoal,
                boundaries: clarification.questions.boundaries.answer.trim(),
            },
        },
        specStatus: {
            flowId: NS4_FLOW_ID,
            flowVersion: NS4_FLOW_VERSION,
            state: 'inProgress',
            artifactCompleteness: 'partial',
            completedSteps: [{ stepId: 'e1', status: 'approved', approvedBy, approvedAt: now }],
            nextStep: 'e2-journeys',
            updatedAt: now,
        },
    };
}
export function normalizeNs4Languages(value, fallback = 'en') {
    const rawValues = Array.isArray(value) ? value : [value];
    const candidates = rawValues.flatMap(item => typeof item === 'string' ? item.split(/[,;\n]+/) : []);
    const languages = [];
    const seen = new Set();
    for (const candidate of candidates) {
        const language = normalizeNs4LanguageTag(candidate);
        const key = language.toLowerCase();
        if (!language || seen.has(key))
            continue;
        seen.add(key);
        languages.push(language);
    }
    if (languages.length)
        return languages;
    const normalizedFallback = normalizeNs4LanguageTag(fallback);
    return [normalizedFallback || 'en'];
}
export function createNs4Pipeline(moduleNameInput, sourcePrompt, now = new Date().toISOString(), presentation = defaultNs4Presentation(sourcePrompt)) {
    const moduleName = normalizeNs4ModuleName(moduleNameInput);
    return {
        schemaVersion: NS4_PIPELINE_SCHEMA_VERSION,
        flowId: NS4_FLOW_ID,
        flowVersion: NS4_FLOW_VERSION,
        moduleName,
        sourcePrompt: sourcePrompt.trim() || moduleName,
        presentation,
        status: 'inProgress',
        steps: { e1: { status: 'running', updatedAt: now } },
        nextStep: 'e2-journeys',
        createdAt: now,
        updatedAt: now,
    };
}
export function markNs4E1Approved(state, approvedBy, artifactPath, now = new Date().toISOString()) {
    return {
        ...state,
        status: 'inProgress',
        steps: {
            ...state.steps,
            e1: { status: 'approved', artifactPath, approvedBy, approvedAt: now, updatedAt: now },
        },
        nextStep: 'e2-journeys',
        updatedAt: now,
    };
}
export function markNs4E2Running(state, reviewRound, now = new Date().toISOString()) {
    return {
        ...state,
        steps: {
            ...state.steps,
            e2: { status: 'running', reviewRound: Math.max(1, reviewRound), updatedAt: now },
        },
        nextStep: 'e2-journeys',
        updatedAt: now,
    };
}
export function markNs4E2WaitingHuman(state, reviewRound, draftPath, now = new Date().toISOString()) {
    return {
        ...state,
        steps: {
            ...state.steps,
            e2: { status: 'waitingHuman', reviewRound: Math.max(1, reviewRound), draftPath, updatedAt: now },
        },
        nextStep: 'e2-journeys',
        updatedAt: now,
    };
}
export function markNs4E2Approved(state, approvedBy, artifactPaths, now = new Date().toISOString()) {
    const reviewRound = state.steps.e2?.reviewRound || 1;
    return {
        ...state,
        steps: {
            ...state.steps,
            e2: {
                ...state.steps.e2,
                status: 'approved',
                reviewRound,
                artifactPaths: [...artifactPaths],
                approvedBy,
                approvedAt: now,
                updatedAt: now,
            },
        },
        nextStep: 'e3-ontology',
        updatedAt: now,
    };
}
export function markNs4ModuleE2Approved(artifact, approvedBy, now = new Date().toISOString()) {
    const completedSteps = artifact.specStatus.completedSteps.filter(step => step.stepId !== 'e2-journeys');
    completedSteps.push({ stepId: 'e2-journeys', status: 'approved', approvedBy, approvedAt: now });
    return {
        ...artifact,
        specStatus: {
            ...artifact.specStatus,
            completedSteps,
            nextStep: 'e3-ontology',
            updatedAt: now,
        },
    };
}
export function resolveNs4ExistingAction(moduleExists, pipeline, moduleArtifactExists) {
    if (!moduleExists)
        return 'new';
    if (!isNs4Pipeline(pipeline))
        return 'collision';
    if (pipeline.steps.e1.status === 'approved' && moduleArtifactExists)
        return 'resume-next';
    return 'resume-e1';
}
export function isNs4Pipeline(value) {
    const record = asRecord(value);
    const steps = asRecord(record.steps);
    const e1 = asRecord(steps.e1);
    return record.flowId === NS4_FLOW_ID
        && typeof record.moduleName === 'string'
        && (e1.status === 'running' || e1.status === 'approved' || e1.status === 'failed');
}
export function humanizeNs4ModuleName(moduleName) {
    const spaced = String(moduleName || '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim();
    return spaced ? spaced.slice(0, 1).toUpperCase() + spaced.slice(1) : 'New module';
}
function asRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value)
        ? value
        : {};
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function inferNs4PromptLanguage(prompt) {
    const text = prompt.toLowerCase();
    if (/\b(pt-br|portugu[eê]s|linguagem\s*:\s*pt)\b/.test(text))
        return 'pt-BR';
    if (/\b(es|español|castellano)\b/.test(text))
        return 'es';
    return 'en';
}
function defaultNs4Presentation(prompt) {
    return {
        userLanguage: inferNs4PromptLanguage(prompt),
        stepTitles: { ...NS4_DEFAULT_TITLES },
    };
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
function normalizeNs4LanguageTag(value) {
    if (typeof value !== 'string')
        return '';
    const raw = value.trim().replace(/_/g, '-');
    if (!/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(raw))
        return '';
    return raw.split('-').map((part, index) => {
        if (index === 0)
            return part.toLowerCase();
        if (/^[A-Za-z]{2}$/.test(part))
            return part.toUpperCase();
        if (/^[A-Za-z]{4}$/.test(part))
            return `${part.slice(0, 1).toUpperCase()}${part.slice(1).toLowerCase()}`;
        return part;
    }).join('-');
}
