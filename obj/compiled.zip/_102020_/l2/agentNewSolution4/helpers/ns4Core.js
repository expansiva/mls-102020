/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4Core.ts" enhancement="_blank"/>
export const NS4_FLOW_ID = 'agentNewSolution4';
export const NS4_FLOW_VERSION = '2026-08-04-ns4-flow-v1';
export const NS4_MODULE_SCHEMA_VERSION = '2026-08-04-ns4-module-v1';
export const NS4_PIPELINE_SCHEMA_VERSION = '2026-08-04-ns4-pipeline-v1';
export function parseNs4Invocation(value) {
    const raw = String(value || '');
    const fast = /(^|\s)\/fast(?=\s|$)/i.test(raw);
    const prompt = raw.replace(/(^|\s)\/fast(?=\s|$)/gi, '$1').replace(/\s+/g, ' ').trim();
    return { fast, prompt };
}
export function createNs4ClarificationSubmitGuard() {
    let submitted = false;
    return () => {
        if (submitted)
            return false;
        submitted = true;
        return true;
    };
}
export function isNs4ModuleToken(value) {
    return /^[a-z][A-Za-z0-9]*$/.test(String(value || '').trim());
}
export function normalizeNs4ModuleName(value, fallback = 'newModule') {
    const raw = readString(value) || fallback;
    const ascii = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const words = ascii.replace(/([a-z0-9])([A-Z])/g, '$1 $2').split(/[^A-Za-z0-9]+/).filter(Boolean);
    if (words.length === 0)
        return 'newModule';
    const first = words[0].toLowerCase();
    const rest = words.slice(1).map(word => word.slice(0, 1).toUpperCase() + word.slice(1).toLowerCase()).join('');
    const candidate = `${first}${rest}`.replace(/^[^a-z]+/, '').slice(0, 60);
    return candidate || 'newModule';
}
export function normalizeNs4Clarification(value) {
    const record = asRecord(value);
    const questionsRecord = asRecord(record.questions);
    const questionIds = ['moduleName', 'mainActors', 'mainGoal', 'boundaries'];
    const questions = {};
    for (const id of questionIds) {
        const question = asRecord(questionsRecord[id]);
        questions[id] = {
            type: 'open',
            question: readString(question.question) || id,
            answer: readString(question.answer) || '',
        };
    }
    return {
        planId: 'e1-clarification',
        userLanguage: readString(record.userLanguage) || 'en',
        title: readString(record.title) || 'Clarification 1',
        legends: Array.isArray(record.legends) ? record.legends.map(readString).filter((item) => !!item) : [],
        questions,
    };
}
export function buildNs4ModuleArtifact(sourcePrompt, clarificationInput, approvedBy, now = new Date().toISOString()) {
    const clarification = normalizeNs4Clarification(clarificationInput);
    const moduleName = normalizeNs4ModuleName(clarification.questions.moduleName.answer, sourcePrompt);
    const mainGoal = clarification.questions.mainGoal.answer.trim() || `Define the ${humanizeNs4ModuleName(moduleName)} business module.`;
    return {
        schemaVersion: NS4_MODULE_SCHEMA_VERSION,
        module: {
            moduleName,
            title: humanizeNs4ModuleName(moduleName),
            purpose: mainGoal,
            languages: [clarification.userLanguage],
        },
        designContext: {
            initialPrompt: sourcePrompt.trim() || moduleName,
            clarification: {
                mainActors: clarification.questions.mainActors.answer.trim(),
                mainGoal,
                boundaries: clarification.questions.boundaries.answer.trim(),
            },
        },
        specStatus: {
            flowId: NS4_FLOW_ID,
            flowVersion: NS4_FLOW_VERSION,
            state: 'inProgress',
            artifactCompleteness: 'partial',
            completedSteps: [{ stepId: 'e1', status: 'approved', approvedBy, approvedAt: now }],
            nextStep: 'e2-journeys',
            updatedAt: now,
        },
    };
}
export function createNs4Pipeline(moduleNameInput, sourcePrompt, now = new Date().toISOString()) {
    const moduleName = normalizeNs4ModuleName(moduleNameInput);
    return {
        schemaVersion: NS4_PIPELINE_SCHEMA_VERSION,
        flowId: NS4_FLOW_ID,
        flowVersion: NS4_FLOW_VERSION,
        moduleName,
        sourcePrompt: sourcePrompt.trim() || moduleName,
        status: 'inProgress',
        steps: { e1: { status: 'running', updatedAt: now } },
        nextStep: 'e2-journeys',
        createdAt: now,
        updatedAt: now,
    };
}
export function markNs4E1Approved(state, approvedBy, artifactPath, now = new Date().toISOString()) {
    return {
        ...state,
        status: 'inProgress',
        steps: {
            ...state.steps,
            e1: { status: 'approved', artifactPath, approvedBy, approvedAt: now, updatedAt: now },
        },
        nextStep: 'e2-journeys',
        updatedAt: now,
    };
}
export function resolveNs4ExistingAction(moduleExists, pipeline, moduleArtifactExists) {
    if (!moduleExists)
        return 'new';
    if (!isNs4Pipeline(pipeline))
        return 'collision';
    if (pipeline.steps.e1.status === 'approved' && moduleArtifactExists)
        return 'resume-next';
    return 'resume-e1';
}
export function isNs4Pipeline(value) {
    const record = asRecord(value);
    const steps = asRecord(record.steps);
    const e1 = asRecord(steps.e1);
    return record.flowId === NS4_FLOW_ID
        && typeof record.moduleName === 'string'
        && (e1.status === 'running' || e1.status === 'approved' || e1.status === 'failed');
}
export function humanizeNs4ModuleName(moduleName) {
    const spaced = String(moduleName || '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim();
    return spaced ? spaced.slice(0, 1).toUpperCase() + spaced.slice(1) : 'New module';
}
function asRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value)
        ? value
        : {};
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
