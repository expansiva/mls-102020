/// <mls fileReference="_102020_/l2/agentNewSolution4/helpers/ns4ForeignKeys.ts" enhancement="_blank"/>
/** Owner entity -> the parents it references, with the field that holds each id. */
export function buildNs4ParentIndex(relationships) {
    const index = new Map();
    for (const relationship of relationships) {
        if (relationship.type !== 'manyToOne' && relationship.type !== 'oneToOne')
            continue;
        // The realization says which side stores the key; only the owner carries the field.
        const owner = relationship.realization?.ownerEntity || relationship.fromEntity;
        if (owner !== relationship.fromEntity)
            continue;
        const fieldId = relationship.realization?.from?.fieldIds?.[0] || '';
        if (!fieldId)
            continue;
        const current = index.get(relationship.fromEntity) || [];
        current.push({ parent: relationship.toEntity, fieldId, required: relationship.required });
        index.set(relationship.fromEntity, current);
    }
    return index;
}
/** The entity a given field of a given entity points at, or null when the field is not a key. */
export function ns4FkParentOf(index, entityId, fieldId) {
    return (index.get(entityId) || []).find(parent => parent.fieldId === fieldId) || null;
}
