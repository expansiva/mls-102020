var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Workspaces102020 = class WidgetNs4Workspaces102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this.adjustment = '';
    }
    render() {
        const review = this.value;
        if (!review)
            return html ``;
        return html `<section class="ns4-workspaces">
      <header><p>👤 E8 — Workspace map</p><h2>${review.title}</h2></header>
      <section><h3>Header</h3><p>${review.menu.headerLinks.join(' · ') || '—'}</p></section>
      <section><h3>Workspaces</h3>${review.workspaces.map(workspace => html `<article><strong>${workspace.title}</strong> <code>${workspace.workspaceId}</code><p>${workspace.kind}${workspace.anchorEntity ? ` · ${workspace.anchorEntity}` : ''} · ${workspace.profileRefs.join(', ') || '—'}</p><p>${workspace.scenarios.map(scenario => scenario.title).join(' · ')}</p></article>`)}</section>
      <section><h3>Menu</h3>${review.menu.sections.map(section => html `<p><strong>${section.label}</strong>: ${section.workspaceIds.join(', ')}</p>`)}</section>
      <section><h3>Context edges</h3>${review.edges.map(edge => html `<p><code>${edge.from} → ${edge.to}</code> (${edge.carries.join(', ')})</p>`)}</section>
      <label>Changes<textarea .value=${this.adjustment} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label>
      <footer><button @click=${() => this.submit('requestChanges')} ?disabled=${!this.adjustment.trim()}>Request changes</button><button @click=${() => this.submit('approve')} ?disabled=${Boolean(this.adjustment.trim())}>Approve map</button></footer>
    </section>`;
    }
    submit(action) {
        if (!this.value || action === 'cancel')
            return;
        this.dispatchEvent(new CustomEvent('ns4-workspaces-review', { detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true }));
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Workspaces102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNs4Workspaces102020.prototype, "adjustment", void 0);
WidgetNs4Workspaces102020 = __decorate([
    customElement('widget-ns4-workspaces-102020')
], WidgetNs4Workspaces102020);
export { WidgetNs4Workspaces102020 };
