/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Workspaces.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { previewNs4E8Routes } from '/_102020_/l2/agentNewSolution4/steps/e8/contracts.js';
let WidgetNs4Workspaces102020 = class WidgetNs4Workspaces102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-workspaces-102020 {
  display: block;
}
widget-ns4-workspaces-102020 .ns4-workspaces {
  display: grid;
  gap: 12px;
}
widget-ns4-workspaces-102020 article {
  padding: 10px;
  border: 1px solid var(--collab-border-color, #ddd);
  border-radius: 6px;
}
widget-ns4-workspaces-102020 .routes {
  margin: 8px 0;
  padding: 8px;
  background: var(--collab-surface-muted, #f6f7f8);
  border-radius: 4px;
}
widget-ns4-workspaces-102020 .routes p {
  margin: 3px 0;
}
widget-ns4-workspaces-102020 .routes span {
  display: inline-block;
  min-width: 78px;
}
widget-ns4-workspaces-102020 .scenario {
  display: grid;
  gap: 3px;
  margin-top: 6px;
}
widget-ns4-workspaces-102020 .scenario small {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
widget-ns4-workspaces-102020 textarea {
  display: block;
  min-height: 80px;
  width: 100%;
}
widget-ns4-workspaces-102020 footer {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}
`);
        this.value = null;
        this.adjustment = '';
        this.submitting = false;
    }
    setSubmitting(value) { this.submitting = value; }
    render() {
        const review = this.value;
        if (!review)
            return html ``;
        return html `<section class="ns4-workspaces">
      <header><p>👤 E8 — Workspace map</p><h2>${review.title}</h2></header>
      <section><h3>Header</h3><p>${review.menu.headerLinks.join(' · ') || '—'}</p></section>
      <section><h3>Workspaces</h3>${review.workspaces.map(workspace => html `<article><strong>${workspace.title}</strong> <code>${workspace.workspaceId}</code>
        <p>${workspace.kind}${workspace.anchorEntity ? ` · ${workspace.anchorEntity}` : ''} · ${workspace.profileRefs.join(', ') || '—'}</p>
        <div class="routes">${previewNs4E8Routes(review, workspace).map(route => html `<p><span>${route.label}</span> <code>${route.url}</code></p>`)}</div>
        ${workspace.pageContext.length ? html `<p><strong>Path:</strong> ${workspace.pageContext.map(context => context.contextId).join(', ')}</p>` : ''}
        ${workspace.scenarios.map(scenario => html `<div class="scenario"><span>${scenario.title}</span>${scenario.selectionContexts.length ? html `<small>${scenario.selectionContexts.map(context => html `<code>${context.contextId}:${context.urlRole}</code>${context.urlRoleJustification ? html ` — ${context.urlRoleJustification}` : ''}`)}</small>` : ''}</div>`)}
      </article>`)}</section>
      ${review.urlRoleDecisions.length ? html `<section><h3>URL choices</h3>${review.urlRoleDecisions.map(decision => html `<p><code>${decision.workspaceId}.${decision.scenarioId}.${decision.contextId}</code> → <strong>${decision.urlRole}</strong>${decision.justification ? ` — ${decision.justification}` : ''} <small>(${decision.decidedBy})</small></p>`)}</section>` : ''}
      ${review.systemDecisions.length ? html `<section><h3>System decisions</h3>${review.systemDecisions.map(decision => html `<p><code>${decision.findingRef}</code> → ${decision.chosen}</p>`)}</section>` : ''}
      <section><h3>Menu</h3>${review.menu.sections.map(section => html `<p><strong>${section.label}</strong>: ${section.workspaceIds.join(', ')}</p>`)}</section>
      <section><h3>Context edges</h3>${review.edges.map(edge => html `<p><code>${edge.from} → ${edge.to}</code> (${edge.carries.join(', ')})</p>`)}</section>
      <label>Changes<textarea .value=${this.adjustment} ?disabled=${this.submitting} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label>
      <footer><button @click=${() => this.submit('requestChanges')} ?disabled=${this.submitting || !this.adjustment.trim()}>Request changes</button><button @click=${() => this.submit('approve')} ?disabled=${this.submitting || Boolean(this.adjustment.trim())}>Approve map</button></footer>
    </section>`;
    }
    submit(action) {
        if (!this.value || this.submitting || action === 'cancel')
            return;
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-workspaces-review', { detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true }));
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Workspaces102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNs4Workspaces102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Workspaces102020.prototype, "submitting", void 0);
WidgetNs4Workspaces102020 = __decorate([
    customElement('widget-ns4-workspaces-102020')
], WidgetNs4Workspaces102020);
export { WidgetNs4Workspaces102020 };
