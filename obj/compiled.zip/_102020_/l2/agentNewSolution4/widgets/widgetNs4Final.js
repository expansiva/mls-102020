/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Final.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const repairSteps = ['e2-journeys', 'e3-access-matrix', 'e4-ontology', 'e5-rules', 'e6-behaviors', 'e7-realization', 'e8-workspaces', 'e9-navigation-compiler'];
let WidgetNs4Final102020 = class WidgetNs4Final102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-final-102020 {
  display: block;
}
widget-ns4-final-102020 .ns4-final {
  display: grid;
  gap: 14px;
}
widget-ns4-final-102020 header {
  display: grid;
  gap: 4px;
}
widget-ns4-final-102020 header p,
widget-ns4-final-102020 header h2 {
  margin: 0;
}
widget-ns4-final-102020 .ok {
  width: fit-content;
  padding: 4px 8px;
  border-radius: 999px;
  color: #176b35;
  background: #e8f7ed;
}
widget-ns4-final-102020 .counts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 8px;
}
widget-ns4-final-102020 .counts article {
  display: grid;
  padding: 10px;
  border: 1px solid var(--collab-border-color, #ddd);
  border-radius: 6px;
}
widget-ns4-final-102020 .counts strong {
  font-size: 1.35rem;
}
widget-ns4-final-102020 .checks {
  display: grid;
  gap: 6px;
}
widget-ns4-final-102020 .checks article {
  display: grid;
  grid-template-columns: minmax(160px, 1fr) auto;
  gap: 3px 10px;
  padding: 8px;
  border-left: 4px solid #2b8a4b;
  background: var(--collab-surface-muted, #f6f7f8);
}
widget-ns4-final-102020 .checks article.reported {
  border-left-color: #c58b16;
}
widget-ns4-final-102020 .checks small {
  grid-column: 1 / -1;
}
widget-ns4-final-102020 details {
  padding: 8px;
  border: 1px solid var(--collab-border-color, #ddd);
  border-radius: 6px;
}
widget-ns4-final-102020 code {
  overflow-wrap: anywhere;
}
widget-ns4-final-102020 .reopen {
  display: grid;
  gap: 7px;
}
widget-ns4-final-102020 select,
widget-ns4-final-102020 textarea {
  width: 100%;
}
widget-ns4-final-102020 textarea {
  min-height: 72px;
}
widget-ns4-final-102020 footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 8px;
}
widget-ns4-final-102020 button.primary {
  font-weight: 600;
}
`);
        this.value = null;
        this.submitting = false;
        this.adjustment = '';
        this.repairStep = 'e8-workspaces';
    }
    setSubmitting(value) { this.submitting = value; }
    render() {
        const report = this.value;
        if (!report)
            return html ``;
        const general = report.menuPreview.navigation.filter(item => !item.hub);
        const hubs = new Map();
        report.menuPreview.navigation.filter(item => item.hub).forEach(item => hubs.set(item.hub, [...(hubs.get(item.hub) || []), item]));
        return html `<section class="ns4-final">
      <header><p>👤 E10 — Validate the finished solution</p><h2>${report.moduleName}</h2><span class="ok">Validation passed</span></header>
      <section class="counts">
        ${this.count('Workspaces', report.counts.workspaces)}${this.count('Scenarios', report.counts.scenarios)}
        ${this.count('Contracts', report.counts.contracts)}${this.count('Notifications', report.counts.notifications)}
      </section>
      <section><h3>Validation</h3><div class="checks">${report.checks.map(check => html `<article class=${check.status}>
        <strong>${check.checkId}</strong><span>${check.status}</span><small>${check.errorCount} errors · ${check.warningCount} warnings · ${check.registrarCount} records</small>
      </article>`)}</div></section>
      ${report.warnings.length ? html `<details><summary>Warnings (${report.warnings.length})</summary>${report.warnings.map(item => html `<p><code>${item.code}</code> ${item.message}</p>`)}</details>` : ''}
      ${report.registrars.length ? html `<details><summary>Registrar findings (${report.registrars.length})</summary>${report.registrars.map(item => html `<p><code>${item.code}</code> ${item.message}</p>`)}</details>` : ''}
      <section><h3>Header links</h3>${report.menuPreview.headerLinks.map(item => html `<p><strong>${item.label}</strong> <code>${item.href}</code> · ${item.actors.join(', ') || '—'} · manageable</p>`)}</section>
      <section><h3>General navigation</h3>${general.length ? general.map(item => this.nav(item)) : html `<p>—</p>`}</section>
      ${[...hubs].map(([hub, items]) => html `<section><h3>Hub · ${hub}</h3>${items.map(item => this.nav(item))}</section>`)}
      <details><summary>Assumed decisions (${report.counts.decisions})</summary>
        ${report.policyDecisions.map(decision => html `<p><code>${decision.decisionId}</code> → ${decision.selectedChoice} <small>(${decision.selectedBy})</small></p>`)}
        ${report.systemDecisions.map(decision => html `<p><code>${decision.findingRef}</code> → ${decision.chosen} <small>(${decision.decidedBy})</small></p>`)}
      </details>
      <section class="reopen"><h3>Reopen a stage</h3><select .value=${this.repairStep} ?disabled=${this.submitting} @change=${(event) => { this.repairStep = event.target.value; }}>${repairSteps.map(item => html `<option value=${item}>${item}</option>`)}</select>
        <textarea .value=${this.adjustment} ?disabled=${this.submitting} placeholder="Reason for reopening" @input=${(event) => { this.adjustment = event.target.value; }}></textarea></section>
      <footer><button @click=${() => this.submit('requestChanges')} ?disabled=${this.submitting || !this.adjustment.trim()}>Reopen selected stage</button><button class="primary" @click=${() => this.submit('approve')} ?disabled=${this.submitting || Boolean(this.adjustment.trim())}>Approve finished solution</button></footer>
    </section>`;
    }
    count(label, value) { return html `<article><strong>${value}</strong><span>${label}</span></article>`; }
    nav(item) { return html `<p><strong>${item.label}</strong> <code>${item.href}</code> · ${item.actors.join(', ') || '—'}</p>`; }
    submit(action) {
        if (!this.value || this.submitting)
            return;
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-final-review', { detail: { action, moduleName: this.value.moduleName,
                ...(action === 'requestChanges' ? { repairStep: this.repairStep } : {}), adjustment: this.adjustment.trim() }, bubbles: true, composed: true }));
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Final102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNs4Final102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Final102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Final102020.prototype, "repairStep", void 0);
WidgetNs4Final102020 = __decorate([
    customElement('widget-ns4-final-102020')
], WidgetNs4Final102020);
export { WidgetNs4Final102020 };
