/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Rules.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Rules102020 = class WidgetNs4Rules102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-rules-102020 {
  color: #172033;
  display: block;
}
widget-ns4-rules-102020 * {
  box-sizing: border-box;
}
widget-ns4-rules-102020 h2,
widget-ns4-rules-102020 h3,
widget-ns4-rules-102020 h4,
widget-ns4-rules-102020 p,
widget-ns4-rules-102020 dl,
widget-ns4-rules-102020 dd {
  margin: 0;
}
widget-ns4-rules-102020 button,
widget-ns4-rules-102020 input,
widget-ns4-rules-102020 select,
widget-ns4-rules-102020 textarea {
  font: inherit;
}
widget-ns4-rules-102020 button:focus-visible,
widget-ns4-rules-102020 input:focus-visible,
widget-ns4-rules-102020 select:focus-visible,
widget-ns4-rules-102020 textarea:focus-visible,
widget-ns4-rules-102020 .ns4-edit:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-rules-102020 button:disabled,
widget-ns4-rules-102020 input:disabled,
widget-ns4-rules-102020 select:disabled,
widget-ns4-rules-102020 textarea:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-rules-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  overflow-wrap: anywhere;
}
widget-ns4-rules-102020 input,
widget-ns4-rules-102020 select,
widget-ns4-rules-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  padding: 8px 9px;
  width: 100%;
}
widget-ns4-rules-102020 textarea {
  min-height: 90px;
  resize: vertical;
}
widget-ns4-rules-102020 .ns4-rules {
  display: grid;
  gap: 16px;
}
widget-ns4-rules-102020 header {
  align-items: flex-start;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding-bottom: 14px;
}
widget-ns4-rules-102020 .ns4-step {
  color: #4f46e5;
  font-size: 12px;
  font-weight: 650;
  margin-bottom: 5px;
}
widget-ns4-rules-102020 header p:last-child {
  color: #64748b;
  margin-top: 5px;
}
widget-ns4-rules-102020 .ns4-header-meta {
  align-items: flex-end;
  display: grid;
  gap: 6px;
  justify-items: end;
}
widget-ns4-rules-102020 .ns4-header-meta span,
widget-ns4-rules-102020 .ns4-header-meta strong {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-rules-102020 .ns4-header-meta strong {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-feedback {
  border: 1px solid;
  border-radius: 10px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-rules-102020 .ns4-feedback strong,
widget-ns4-rules-102020 .ns4-feedback span,
widget-ns4-rules-102020 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-rules-102020 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-rules-102020 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-metrics {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
widget-ns4-rules-102020 .ns4-metrics span {
  align-items: center;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 999px;
  color: #475569;
  display: inline-flex;
  font-size: 12px;
  gap: 6px;
  padding: 5px 9px;
}
widget-ns4-rules-102020 .ns4-metrics strong {
  color: #1e293b;
}
widget-ns4-rules-102020 .ns4-metrics .has-issues {
  background: #fff7ed;
  border-color: #fdba74;
  color: #9a3412;
}
widget-ns4-rules-102020 .ns4-workbench {
  align-items: start;
  display: grid;
  gap: 20px;
  grid-template-columns: minmax(280px, 375px) minmax(0, 1fr);
}
widget-ns4-rules-102020 aside {
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  display: grid;
  gap: 10px;
  max-width: 375px;
  min-width: 0;
  padding: 12px;
  width: 100%;
}
widget-ns4-rules-102020 .ns4-filter-head {
  align-items: center;
  display: flex;
  justify-content: space-between;
}
widget-ns4-rules-102020 .ns4-filter-head h3 {
  font-size: 15px;
}
widget-ns4-rules-102020 .ns4-filter-head span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-rules-102020 .ns4-selects {
  display: grid;
  gap: 8px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-selects label {
  display: grid;
  gap: 4px;
}
widget-ns4-rules-102020 .ns4-selects label span {
  color: #64748b;
  font-size: 11px;
  font-weight: 650;
}
widget-ns4-rules-102020 .ns4-filters {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
widget-ns4-rules-102020 .ns4-filters > summary {
  align-items: center;
  color: #334155;
  cursor: pointer;
  display: flex;
  font-size: 12px;
  font-weight: 700;
  justify-content: space-between;
  list-style: none;
  padding: 9px 10px;
}
widget-ns4-rules-102020 .ns4-filters > summary::-webkit-details-marker {
  display: none;
}
widget-ns4-rules-102020 .ns4-filters > summary::after {
  color: #64748b;
  content: '⌄';
  font-size: 15px;
}
widget-ns4-rules-102020 .ns4-filters[open] > summary {
  border-bottom: 1px solid #e2e8f0;
}
widget-ns4-rules-102020 .ns4-filters[open] > summary::after {
  transform: rotate(180deg);
}
widget-ns4-rules-102020 .ns4-filter-content {
  display: grid;
  gap: 10px;
  padding: 10px;
}
widget-ns4-rules-102020 .ns4-checks {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 7px;
  padding-top: 9px;
}
widget-ns4-rules-102020 .ns4-checks label {
  align-items: center;
  color: #475569;
  display: flex;
  font-size: 12px;
  gap: 7px;
}
widget-ns4-rules-102020 .ns4-checks input {
  accent-color: #4338ca;
  width: 15px;
}
widget-ns4-rules-102020 .ns4-rule-list {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 7px;
  max-height: 680px;
  overflow-y: auto;
  padding-top: 10px;
}
widget-ns4-rules-102020 .ns4-rule-list > p {
  color: #64748b;
  font-size: 13px;
}
widget-ns4-rules-102020 .ns4-rule-item {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  cursor: pointer;
  display: grid;
  gap: 6px;
  padding: 10px;
  text-align: left;
}
widget-ns4-rules-102020 .ns4-rule-item:hover {
  border-color: #a5b4fc;
}
widget-ns4-rules-102020 .ns4-rule-item.selected {
  background: #f5f3ff;
  border-color: #818cf8;
}
widget-ns4-rules-102020 .ns4-rule-item > div {
  display: grid;
  gap: 2px;
}
widget-ns4-rules-102020 .ns4-rule-item strong {
  font-size: 13px;
  line-height: 1.35;
}
widget-ns4-rules-102020 .ns4-rule-item small {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-rules-102020 .ns4-rule-item i {
  font-size: 10px;
  font-style: normal;
}
widget-ns4-rules-102020 .ns4-rule-item i.complete {
  color: #166534;
}
widget-ns4-rules-102020 .ns4-rule-item i.incomplete {
  color: #b45309;
}
widget-ns4-rules-102020 .ns4-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
widget-ns4-rules-102020 .ns4-badges em,
widget-ns4-rules-102020 .ns4-detail-head > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 10px;
  font-style: normal;
  padding: 3px 6px;
}
widget-ns4-rules-102020 .ns4-badges .backend {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-badges .critical,
widget-ns4-rules-102020 .ns4-detail-head > span.critical {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-detail {
  align-content: start;
  display: grid;
  gap: 14px;
  min-width: 0;
}
widget-ns4-rules-102020 .ns4-detail-head {
  align-items: start;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-rules-102020 .ns4-detail-head h3 {
  font-size: 20px;
  margin-top: 3px;
}
widget-ns4-rules-102020 .ns4-edit {
  border-bottom: 1px dashed #a5b4fc;
  cursor: text;
  outline: 0;
}
widget-ns4-rules-102020 .ns4-edit:focus {
  background: #eef2ff;
  border-bottom-color: #4338ca;
}
widget-ns4-rules-102020 .ns4-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 4px;
  overflow-x: auto;
}
widget-ns4-rules-102020 .ns4-tabs button {
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  color: #64748b;
  cursor: pointer;
  padding: 8px 10px;
  white-space: nowrap;
}
widget-ns4-rules-102020 .ns4-tabs button.selected {
  border-bottom-color: #4338ca;
  color: #3730a3;
  font-weight: 650;
}
widget-ns4-rules-102020 .ns4-panel,
widget-ns4-rules-102020 .ns4-application article,
widget-ns4-rules-102020 .ns4-cases article,
widget-ns4-rules-102020 .ns4-coverage article {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  padding: 13px;
}
widget-ns4-rules-102020 .ns4-panel {
  display: grid;
  gap: 12px;
}
widget-ns4-rules-102020 .ns4-panel h4,
widget-ns4-rules-102020 .ns4-application h4,
widget-ns4-rules-102020 .ns4-cases h4,
widget-ns4-rules-102020 .ns4-traceability h4,
widget-ns4-rules-102020 .ns4-coverage h4 {
  font-size: 13px;
}
widget-ns4-rules-102020 .statement {
  color: #334155;
  font-size: 15px;
  line-height: 1.5;
  padding-bottom: 3px;
}
widget-ns4-rules-102020 .ns4-panel dl {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-panel dt,
widget-ns4-rules-102020 .ns4-application dt,
widget-ns4-rules-102020 .ns4-cases dt {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-rules-102020 .ns4-panel dd,
widget-ns4-rules-102020 .ns4-application dd,
widget-ns4-rules-102020 .ns4-cases dd {
  font-size: 13px;
  line-height: 1.4;
  margin-top: 3px;
}
widget-ns4-rules-102020 .ns4-predicate {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  line-height: 1.45;
  padding: 14px;
}
widget-ns4-rules-102020 .ns4-predicate ul {
  display: grid;
  gap: 7px;
  margin: 8px 0 0;
  padding-left: 18px;
}
widget-ns4-rules-102020 .ns4-application {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-application article {
  display: grid;
  gap: 10px;
}
widget-ns4-rules-102020 .ns4-application article > strong {
  color: #166534;
  font-size: 12px;
}
widget-ns4-rules-102020 .ns4-application dl {
  display: grid;
  gap: 8px;
}
widget-ns4-rules-102020 .ns4-application article > p {
  border-top: 1px solid #e2e8f0;
  color: #64748b;
  font-size: 12px;
  line-height: 1.4;
  padding-top: 10px;
}
widget-ns4-rules-102020 .ns4-cases,
widget-ns4-rules-102020 .ns4-coverage {
  display: grid;
  gap: 10px;
}
widget-ns4-rules-102020 .ns4-cases article {
  display: grid;
  gap: 8px;
  position: relative;
}
widget-ns4-rules-102020 .ns4-cases article > div {
  display: grid;
  gap: 3px;
}
widget-ns4-rules-102020 .ns4-cases article > span {
  border-radius: 999px;
  font-size: 11px;
  padding: 4px 7px;
  position: absolute;
  right: 12px;
  top: 12px;
}
widget-ns4-rules-102020 .ns4-cases .reject {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-cases .allow {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-cases article > p {
  color: #475569;
  font-size: 13px;
}
widget-ns4-rules-102020 .ns4-cases dl {
  display: grid;
  gap: 8px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-cases dd {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
widget-ns4-rules-102020 .ns4-cases dd code {
  background: #f8fafc;
  border-radius: 5px;
  padding: 3px 5px;
}
widget-ns4-rules-102020 .ns4-traceability {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-traceability > div {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 6px;
  padding: 11px;
}
widget-ns4-rules-102020 .ns4-traceability code {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 5px;
  padding: 4px 6px;
}
widget-ns4-rules-102020 .ns4-coverage article {
  align-items: start;
  display: grid;
  gap: 5px;
  grid-template-columns: auto auto 1fr;
}
widget-ns4-rules-102020 .ns4-coverage article span {
  border-radius: 999px;
  font-size: 10px;
  padding: 3px 6px;
}
widget-ns4-rules-102020 .status-covered {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .status-routed {
  background: #eff6ff;
  color: #1d4ed8;
}
widget-ns4-rules-102020 .status-missing {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-coverage article p {
  color: #475569;
  font-size: 13px;
}
widget-ns4-rules-102020 footer {
  border-top: 1px solid #c7d2fe;
  display: grid;
  gap: 10px;
  padding-top: 15px;
}
widget-ns4-rules-102020 footer label {
  display: grid;
  gap: 6px;
}
widget-ns4-rules-102020 footer label > span {
  color: #475569;
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-rules-102020 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-rules-102020 footer button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-rules-102020 footer .cancel {
  background: #fff;
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-rules-102020 footer .secondary,
widget-ns4-rules-102020 footer .primary {
  background: #fff;
  color: #334155;
}
widget-ns4-rules-102020 footer .is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-rules-102020 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-rules-102020 .ns4-cancel-dialog {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-rules-102020 .ns4-cancel-dialog p {
  color: #475569;
}
widget-ns4-rules-102020 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-rules-102020 .ns4-cancel-dialog button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-rules-102020 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 700px) {
  widget-ns4-rules-102020 .ns4-workbench,
  widget-ns4-rules-102020 .ns4-application {
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 aside {
    max-width: none;
  }
  widget-ns4-rules-102020 .ns4-rule-list {
    max-height: 360px;
  }
}
@media (max-width: 650px) {
  widget-ns4-rules-102020 header,
  widget-ns4-rules-102020 .ns4-panel dl,
  widget-ns4-rules-102020 .ns4-cases dl,
  widget-ns4-rules-102020 .ns4-traceability {
    display: grid;
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 .ns4-header-meta {
    align-items: start;
    justify-items: start;
  }
  widget-ns4-rules-102020 .ns4-selects {
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 footer > div {
    display: grid;
  }
  widget-ns4-rules-102020 footer .cancel {
    margin-right: 0;
  }
  widget-ns4-rules-102020 .ns4-coverage article {
    grid-template-columns: 1fr;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.msgError = '';
        this.msgOk = '';
        this.search = '';
        this.kind = '';
        this.layer = '';
        this.entity = '';
        this.journey = '';
        this.authority = '';
        this.consumer = '';
        this.onlyCritical = false;
        this.onlyIssues = false;
        this.onlyMissingCoverage = false;
        this.selectedRuleId = '';
        this.activeTab = 'summary';
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return { step: '👤 Etapa 5 de 6 — Regras', review: 'Revisão', rules: 'regras', critical: 'críticas', backend: 'backend obrigatório', issues: 'issues', filters: 'Filtros', search: 'Buscar por texto ou ID', kind: 'Tipo', layer: 'Camada', entity: 'Entidade', journey: 'Jornada', authority: 'Autoridade', consumer: 'Consumidor', all: 'Todos', criticalOnly: 'Somente críticas', issuesOnly: 'Com issue', missingOnly: 'Sem cobertura', summary: 'Resumo', condition: 'Condição', application: 'Aplicação', cases: 'Casos de aceite', traceability: 'Rastreabilidade', coverage: 'Cobertura', trigger: 'Disparo', statement: 'Regra', frontend: 'Frontend', message: 'Mensagem para o usuário', errorCode: 'Código de erro', backendRequired: 'Validação de backend obrigatória', effect: 'Efeito', behavior: 'Comportamento', frontendWarning: 'O frontend antecipa a experiência, mas não substitui a proteção do backend.', source: 'Fonte', routed: 'Statement roteado', noRule: 'Nenhuma regra atende aos filtros.', noSelection: 'Selecione uma regra para revisar.', adjustment: 'O que deve mudar?', placeholder: 'Exemplo: inclua uma regra de visibilidade para o cliente ver apenas o orçamento aprovado.', request: 'Gerar nova proposta', approve: 'Aprovar regras', cancel: 'Cancelar execução', adjustmentRequired: 'Descreva a alteração necessária antes de gerar nova proposta.', processingApproval: 'Validando catálogo de regras…', processingChanges: 'Preparando nova revisão…', processingCancel: 'Cancelando execução…', revise: 'Revise os itens abaixo', cancelTitle: 'Cancelar esta execução?', cancelText: 'O processamento será encerrado. O histórico e os artefatos já aprovados serão preservados.', keepWorking: 'Continuar trabalhando', edit: 'Clique para editar', complete: 'Rastreabilidade completa', incomplete: 'Rastreabilidade incompleta', required: 'Obrigatório', notRequired: 'Não obrigatório' };
        if (language.startsWith('es'))
            return { step: '👤 Paso 5 de 6 — Reglas', review: 'Revisión', rules: 'reglas', critical: 'críticas', backend: 'backend obligatorio', issues: 'issues', filters: 'Filtros', search: 'Buscar texto o ID', kind: 'Tipo', layer: 'Capa', entity: 'Entidad', journey: 'Jornada', authority: 'Autoridad', consumer: 'Consumidor', all: 'Todos', criticalOnly: 'Solo críticas', issuesOnly: 'Con issue', missingOnly: 'Sin cobertura', summary: 'Resumen', condition: 'Condición', application: 'Aplicación', cases: 'Casos de aceptación', traceability: 'Trazabilidad', coverage: 'Cobertura', trigger: 'Disparador', statement: 'Regla', frontend: 'Frontend', message: 'Mensaje para el usuario', errorCode: 'Código de error', backendRequired: 'Validación de backend obligatoria', effect: 'Efecto', behavior: 'Comportamiento', frontendWarning: 'El frontend anticipa la experiencia, pero no reemplaza la protección del backend.', source: 'Fuente', routed: 'Statement encaminado', noRule: 'Ninguna regla cumple los filtros.', noSelection: 'Seleccione una regla para revisar.', adjustment: '¿Qué debe cambiar?', placeholder: 'Ejemplo: incluya una regla de visibilidad para que el cliente vea solo el presupuesto aprobado.', request: 'Generar otra propuesta', approve: 'Aprobar reglas', cancel: 'Cancelar ejecución', adjustmentRequired: 'Describa el cambio necesario antes de generar una propuesta nueva.', processingApproval: 'Validando catálogo de reglas…', processingChanges: 'Preparando una nueva revisión…', processingCancel: 'Cancelando la ejecución…', revise: 'Revise los elementos a continuación', cancelTitle: '¿Cancelar esta ejecución?', cancelText: 'El procesamiento terminará. Se conservarán el historial y los artefactos aprobados.', keepWorking: 'Seguir trabajando', edit: 'Haga clic para editar', complete: 'Trazabilidad completa', incomplete: 'Trazabilidad incompleta', required: 'Obligatorio', notRequired: 'No obligatorio' };
        return { step: '👤 Step 5 of 6 — Rules', review: 'Review', rules: 'rules', critical: 'critical', backend: 'backend required', issues: 'issues', filters: 'Filters', search: 'Search text or ID', kind: 'Kind', layer: 'Layer', entity: 'Entity', journey: 'Journey', authority: 'Authority', consumer: 'Consumer', all: 'All', criticalOnly: 'Critical only', issuesOnly: 'Has issue', missingOnly: 'Missing coverage', summary: 'Summary', condition: 'Condition', application: 'Application', cases: 'Acceptance cases', traceability: 'Traceability', coverage: 'Coverage', trigger: 'Trigger', statement: 'Rule', frontend: 'Frontend', message: 'User message', errorCode: 'Error code', backendRequired: 'Backend enforcement required', effect: 'Effect', behavior: 'Behavior', frontendWarning: 'Frontend feedback improves the experience but does not replace backend protection.', source: 'Source', routed: 'Routed statement', noRule: 'No rules match the filters.', noSelection: 'Select a rule to review.', adjustment: 'What should change?', placeholder: 'Example: add a visibility rule so the client sees only the approved budget.', request: 'Generate another proposal', approve: 'Approve rules', cancel: 'Cancel execution', adjustmentRequired: 'Describe the required change before generating another proposal.', processingApproval: 'Validating rules catalog…', processingChanges: 'Preparing a new review…', processingCancel: 'Cancelling execution…', revise: 'Review the items below', cancelTitle: 'Cancel this execution?', cancelText: 'Processing will end. The history and approved artifacts will be preserved.', keepWorking: 'Keep working', edit: 'Click to edit', complete: 'Complete traceability', incomplete: 'Incomplete traceability', required: 'Required', notRequired: 'Not required' };
    }
    setFeedback(feedback) { this.feedbackIssues = feedback?.issues || []; this.msgError = feedback?.kind === 'error' ? feedback.message : ''; this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : ''; this.feedbackFocusPending = feedback?.kind === 'error'; }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
    }
    hasIssue(rule) { return !rule.sourceRefs.length || (rule.criticality === 'critical' && !rule.enforcement.backend.required); }
    selected() { return this.visibleRules().find(rule => rule.ruleId === this.selectedRuleId) || this.visibleRules()[0] || this.value?.rules[0]; }
    visibleRules() {
        if (!this.value)
            return [];
        const q = this.search.trim().toLowerCase();
        return this.value.rules.filter(rule => {
            const hasMissingCoverage = rule.sourceRefs.some(source => this.value.coverage.find(item => item.sourceRef === source.ref)?.status === 'missing');
            return (!q || `${rule.ruleId} ${rule.title} ${rule.statement}`.toLowerCase().includes(q))
                && (!this.kind || rule.kind === this.kind)
                && (!this.layer || rule.layer === this.layer)
                && (!this.entity || rule.scope.entityRefs.includes(this.entity))
                && (!this.journey || rule.scope.journeyRefs.includes(this.journey))
                && (!this.authority || rule.scope.authorityRefs.includes(this.authority))
                && (!this.consumer || (this.consumer === 'backend' ? rule.enforcement.backend.required : rule.enforcement.frontend.behavior !== 'none'))
                && (!this.onlyCritical || rule.criticality === 'critical')
                && (!this.onlyIssues || this.hasIssue(rule))
                && (!this.onlyMissingCoverage || hasMissingCoverage);
        });
    }
    updateRule(ruleId, patch) { if (!this.value || this.readonly || this.submitting)
        return; this.value = { ...this.value, rules: this.value.rules.map(rule => rule.ruleId === ruleId ? { ...rule, ...patch } : rule) }; }
    updateText(rule, property, event) { this.updateRule(rule.ruleId, { [property]: event.currentTarget.innerText.trim() }); }
    updateFrontendMessage(rule, event) { this.updateRule(rule.ruleId, { enforcement: { ...rule.enforcement, frontend: { ...rule.enforcement.frontend, message: event.currentTarget.innerText.trim() } } }); }
    updateCaseTitle(rule, caseId, event) { this.updateRule(rule.ruleId, { acceptanceCases: rule.acceptanceCases.map(item => item.caseId === caseId ? { ...item, title: event.currentTarget.innerText.trim() } : item) }); }
    finishEdit(event) { if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        event.currentTarget.blur();
    } }
    submit(action) { if (!this.value || this.readonly || this.submitting)
        return; const text = this.text(); if (action === 'requestChanges' && !this.adjustment.trim()) {
        this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
        return;
    } this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges }); this.feedbackScrollPending = true; this.setSubmitting(true); this.dispatchEvent(new CustomEvent('ns4-rules-review', { detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true })); }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) { if (event.key === 'Escape') {
        event.preventDefault();
        this.closeCancel();
        return;
    } if (event.key !== 'Tab')
        return; const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')]; const index = controls.indexOf(document.activeElement); event.preventDefault(); controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus(); }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.noSelection}</div>`;
        const rules = this.visibleRules();
        const selected = this.selected();
        const hasAdjustment = Boolean(this.adjustment.trim());
        const critical = this.value.rules.filter(rule => rule.criticality === 'critical').length;
        const backend = this.value.rules.filter(rule => rule.enforcement.backend.required).length;
        const issues = this.value.rules.filter(rule => this.hasIssue(rule)).length;
        return html `<section class="ns4-rules"><header><div><p class="ns4-step">${text.step}</p><h2>${this.value.title}</h2><p>${this.value.moduleName}</p></div><div class="ns4-header-meta"><span>${text.review} ${this.value.reviewRound}</span><strong>${this.value.rules.length} ${text.rules}</strong></div></header>${this.renderFeedback(text)}
      <section class="ns4-metrics"><span><strong>${critical}</strong>${text.critical}</span><span><strong>${backend}</strong>${text.backend}</span><span class=${issues ? 'has-issues' : ''}><strong>${issues}</strong>${text.issues}</span></section>
      <div class="ns4-workbench"><aside><div class="ns4-filter-head"><h3>${text.rules}</h3><span>${rules.length}/${this.value.rules.length}</span></div>${this.renderFilters(text)}<div class="ns4-rule-list">${rules.length ? rules.map(rule => this.renderRuleItem(rule, selected, text)) : html `<p>${text.noRule}</p>`}</div></aside>${selected ? this.renderDetail(selected, text) : html `<main class="ns4-no-selection">${text.noSelection}</main>`}</div>
      <footer><label><span>${text.adjustment}</span><textarea .value=${this.adjustment} placeholder=${text.placeholder} ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label><div><button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button><button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.request}</button><button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button></div></footer>${this.renderCancelDialog(text)}</section>`;
    }
    refs(key) { return [...new Set(this.value?.rules.flatMap(rule => rule.scope[key]) || [])].sort(); }
    renderFilters(text) {
        return html `<details class="ns4-filters"><summary>${text.filters}</summary><div class="ns4-filter-content"><input aria-label=${text.search} placeholder=${text.search} .value=${this.search} ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.search = event.target.value; }}><div class="ns4-selects">${this.select(text.kind, this.kind, ['invariant', 'validation', 'transitionGuard', 'calculation', 'temporal', 'authorization', 'visibility', 'conditionalRequirement'], value => { this.kind = value; })}${this.select(text.layer, this.layer, ['domain', 'application', 'access'], value => { this.layer = value; })}${this.select(text.entity, this.entity, this.refs('entityRefs'), value => { this.entity = value; })}${this.select(text.journey, this.journey, this.refs('journeyRefs'), value => { this.journey = value; })}${this.select(text.authority, this.authority, this.refs('authorityRefs'), value => { this.authority = value; })}${this.select(text.consumer, this.consumer, ['backend', 'frontend'], value => { this.consumer = value; })}</div><div class="ns4-checks"><label><input type="checkbox" .checked=${this.onlyCritical} @change=${(event) => { this.onlyCritical = event.target.checked; }}>${text.criticalOnly}</label><label><input type="checkbox" .checked=${this.onlyIssues} @change=${(event) => { this.onlyIssues = event.target.checked; }}>${text.issuesOnly}</label><label><input type="checkbox" .checked=${this.onlyMissingCoverage} @change=${(event) => { this.onlyMissingCoverage = event.target.checked; }}>${text.missingOnly}</label></div></div></details>`;
    }
    select(label, value, options, change) { return html `<label><span>${label}</span><select .value=${value} @change=${(event) => change(event.target.value)}><option value="">${this.text().all}</option>${options.map(option => html `<option value=${option}>${option}</option>`)}</select></label>`; }
    renderRuleItem(rule, selected, text) { const complete = rule.sourceRefs.length > 0; return html `<button class="ns4-rule-item ${selected?.ruleId === rule.ruleId ? 'selected' : ''}" @click=${() => { this.selectedRuleId = rule.ruleId; this.activeTab = 'summary'; }}><div><code>${rule.ruleId}</code><strong>${rule.title}</strong></div><span class="ns4-badges"><em>${rule.kind}</em><em>${rule.layer}</em>${rule.enforcement.backend.required ? html `<em class="backend">${text.backend}</em>` : ''}${rule.criticality === 'critical' ? html `<em class="critical">${text.critical}</em>` : ''}</span><small>${rule.scope.entityRefs.slice(0, 2).join(' · ') || rule.scope.journeyRefs.slice(0, 2).join(' · ') || '—'} · ${rule.acceptanceCases.length} ✓</small><i class=${complete ? 'complete' : 'incomplete'}>${complete ? text.complete : text.incomplete}</i></button>`; }
    renderDetail(rule, text) { return html `<main class="ns4-detail"><div class="ns4-detail-head"><div><code>${rule.ruleId}</code><h3 class="ns4-edit" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.edit} @blur=${(event) => this.updateText(rule, 'title', event)} @keydown=${this.finishEdit}>${rule.title}</h3></div><span class=${rule.criticality === 'critical' ? 'critical' : ''}>${rule.kind} · ${rule.layer}</span></div><nav class="ns4-tabs">${['summary', 'condition', 'application', 'cases', 'traceability', 'coverage'].map(tab => html `<button class=${this.activeTab === tab ? 'selected' : ''} @click=${() => { this.activeTab = tab; }}>${text[tab]}</button>`)}</nav>${this.activeTab === 'summary' ? this.summary(rule, text) : ''}${this.activeTab === 'condition' ? this.condition(rule, text) : ''}${this.activeTab === 'application' ? this.application(rule, text) : ''}${this.activeTab === 'cases' ? this.cases(rule, text) : ''}${this.activeTab === 'traceability' ? this.traceability(rule, text) : ''}${this.activeTab === 'coverage' ? this.coverage(rule, text) : ''}</main>`; }
    summary(rule, text) { return html `<section class="ns4-panel"><h4>${text.statement}</h4><p class="ns4-edit statement" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.edit} @blur=${(event) => this.updateText(rule, 'statement', event)} @keydown=${this.finishEdit}>${rule.statement}</p><dl><div><dt>${text.trigger}</dt><dd>${rule.trigger.type} — ${rule.trigger.description}</dd></div><div><dt>${text.kind}</dt><dd>${rule.kind} · ${rule.layer}</dd></div><div><dt>${text.critical}</dt><dd>${rule.criticality}</dd></div></dl></section>`; }
    condition(rule, text) { return html `<section class="ns4-panel"><h4>${text.condition}</h4><div class="ns4-predicate">${this.predicate(rule.predicate)}</div></section>`; }
    predicate(predicate) {
        if (predicate.type === 'manualSpecification')
            return html `<p>${predicate.description}</p>`;
        if (predicate.type === 'all' || predicate.type === 'any')
            return html `<div><strong>${predicate.type === 'all' ? 'ALL' : 'ANY'}</strong><ul>${predicate.conditions.map(item => html `<li>${this.predicate(item)}</li>`)}</ul></div>`;
        if (predicate.type === 'factComparison')
            return html `<code>${predicate.factRef} ${predicate.operator} ${predicate.comparisonFactRef || this.print(predicate.value)}</code>`;
        return '';
    }
    application(rule, text) { return html `<section class="ns4-application"><article><h4>Backend</h4><strong>${rule.enforcement.backend.required ? text.required : text.notRequired}</strong><dl><div><dt>${text.effect}</dt><dd>${rule.enforcement.backend.effect}</dd></div><div><dt>${text.errorCode}</dt><dd><code>${rule.enforcement.backend.errorCode || '—'}</code></dd></div></dl></article><article><h4>${text.frontend}</h4><dl><div><dt>${text.behavior}</dt><dd>${rule.enforcement.frontend.behavior}</dd></div><div><dt>${text.message}</dt><dd class="ns4-edit" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.edit} @blur=${(event) => this.updateFrontendMessage(rule, event)} @keydown=${this.finishEdit}>${rule.enforcement.frontend.message || '—'}</dd></div></dl><p>${text.frontendWarning}</p></article></section>`; }
    cases(rule, text) { return html `<section class="ns4-cases">${rule.acceptanceCases.map(item => html `<article><div><code>${item.caseId}</code><h4 class="ns4-edit" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.edit} @blur=${(event) => this.updateCaseTitle(rule, item.caseId, event)} @keydown=${this.finishEdit}>${item.title}</h4></div><span class=${item.expect === 'reject' ? 'reject' : 'allow'}>${item.expect}</span><p>${item.when || '—'}</p><dl><div><dt>Given</dt><dd>${Object.entries(item.given).map(([key, value]) => html `<code>${key}: ${this.print(value)}</code>`)}</dd></div><div><dt>Expected</dt><dd>${item.expectedValue === undefined ? '—' : this.print(item.expectedValue)} ${item.errorCode ? html `<code>${item.errorCode}</code>` : ''}</dd></div></dl></article>`)}</section>`; }
    traceability(rule, text) {
        const groups = [
            { title: text.entity, refs: rule.scope.entityRefs }, { title: 'Fields', refs: rule.scope.fieldRefs }, { title: 'Relationships', refs: rule.scope.relationshipRefs },
            { title: text.journey, refs: rule.scope.journeyRefs }, { title: 'Journey steps', refs: rule.scope.journeyStepRefs }, { title: 'Actors', refs: rule.scope.actorRefs }, { title: text.authority, refs: rule.scope.authorityRefs },
        ];
        return html `<section class="ns4-traceability">${groups.filter(group => group.refs.length).map(group => this.traceGroup(group.title, group.refs))}<div><h4>${text.source}</h4>${rule.sourceRefs.map(ref => html `<code>${ref.kind}: ${ref.ref}</code>`)}</div></section>`;
    }
    traceGroup(title, refs) { return html `<div><h4>${title}</h4>${refs.map(ref => html `<code>${ref}</code>`)}</div>`; }
    coverage(rule, text) { const refs = new Set(rule.sourceRefs.map(source => source.ref)); const coverage = this.value.coverage.filter(item => refs.has(item.sourceRef)); const routed = this.value.routedStatements.filter(item => refs.has(item.sourceRef)); return html `<section class="ns4-coverage"><h4>${text.coverage}</h4>${coverage.map(item => html `<article><code>${item.sourceRef}</code><span class="status-${item.status}">${item.status}</span><p>${item.coveredBy.join(', ') || '—'}</p></article>`)}${routed.length ? html `<h4>${text.routed}</h4>${routed.map(item => html `<article><code>${item.sourceRef}</code><strong>${item.destination}${item.targetRef ? ` → ${item.targetRef}` : ''}</strong><p>${item.reason}</p></article>`)}` : ''}</section>`; }
    renderFeedback(text) { if (!this.msgError && !this.msgOk)
        return ''; const error = Boolean(this.msgError); return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(item => html `<li>${item.path ? html `<code>${item.path}</code> — ` : ''}${item.message}</li>`)}</ul>` : ''}</section>`; }
    renderCancelDialog(text) { if (!this.cancelOpen)
        return ''; return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-rules-cancel-title" @keydown=${this.trapCancel}><h3 id="ns4-rules-cancel-title">${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`; }
    print(value) { return value === undefined ? '—' : typeof value === 'object' ? JSON.stringify(value) : String(value); }
};
__decorate([
    property({ type: Object })
], WidgetNs4Rules102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Rules102020.prototype, "readonly", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Rules102020.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Rules102020.prototype, "msgOk", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "search", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "kind", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "layer", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "entity", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "journey", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "authority", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "consumer", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "onlyCritical", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "onlyIssues", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "onlyMissingCoverage", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "selectedRuleId", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "activeTab", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "cancelOpen", void 0);
WidgetNs4Rules102020 = __decorate([
    customElement('widget-ns4-rules-102020')
], WidgetNs4Rules102020);
export { WidgetNs4Rules102020 };
