/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Rules.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Rules102020 = class WidgetNs4Rules102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-rules-102020 {
  color: #172033;
  display: block;
}
widget-ns4-rules-102020 * {
  box-sizing: border-box;
}
widget-ns4-rules-102020 h2,
widget-ns4-rules-102020 h3,
widget-ns4-rules-102020 h4,
widget-ns4-rules-102020 p,
widget-ns4-rules-102020 dl,
widget-ns4-rules-102020 dd {
  margin: 0;
}
widget-ns4-rules-102020 button,
widget-ns4-rules-102020 input,
widget-ns4-rules-102020 select,
widget-ns4-rules-102020 textarea {
  font: inherit;
}
widget-ns4-rules-102020 button:focus-visible,
widget-ns4-rules-102020 input:focus-visible,
widget-ns4-rules-102020 select:focus-visible,
widget-ns4-rules-102020 textarea:focus-visible,
widget-ns4-rules-102020 .ns4-edit:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-rules-102020 button:disabled,
widget-ns4-rules-102020 input:disabled,
widget-ns4-rules-102020 select:disabled,
widget-ns4-rules-102020 textarea:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-rules-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  overflow-wrap: anywhere;
}
widget-ns4-rules-102020 input,
widget-ns4-rules-102020 select,
widget-ns4-rules-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  padding: 8px 9px;
  width: 100%;
}
widget-ns4-rules-102020 textarea {
  min-height: 90px;
  resize: vertical;
}
widget-ns4-rules-102020 .ns4-rules {
  display: grid;
  gap: 16px;
}
widget-ns4-rules-102020 header {
  align-items: flex-start;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding-bottom: 14px;
}
widget-ns4-rules-102020 .ns4-step {
  color: #4f46e5;
  font-size: 12px;
  font-weight: 650;
  margin-bottom: 5px;
}
widget-ns4-rules-102020 header p:last-child {
  color: #64748b;
  margin-top: 5px;
}
widget-ns4-rules-102020 .ns4-header-meta {
  align-items: flex-end;
  display: grid;
  gap: 6px;
  justify-items: end;
}
widget-ns4-rules-102020 .ns4-header-meta span,
widget-ns4-rules-102020 .ns4-header-meta strong {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-rules-102020 .ns4-header-meta strong {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-feedback {
  border: 1px solid;
  border-radius: 10px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-rules-102020 .ns4-feedback strong,
widget-ns4-rules-102020 .ns4-feedback span,
widget-ns4-rules-102020 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-rules-102020 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-rules-102020 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-metrics {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
widget-ns4-rules-102020 .ns4-metrics span {
  align-items: center;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 999px;
  color: #475569;
  display: inline-flex;
  font-size: 12px;
  gap: 6px;
  padding: 5px 9px;
}
widget-ns4-rules-102020 .ns4-metrics strong {
  color: #1e293b;
}
widget-ns4-rules-102020 .ns4-metrics .has-issues {
  background: #fff7ed;
  border-color: #fdba74;
  color: #9a3412;
}
widget-ns4-rules-102020 .ns4-workbench {
  align-items: start;
  display: grid;
  gap: 20px;
  grid-template-columns: minmax(280px, 375px) minmax(0, 1fr);
}
widget-ns4-rules-102020 aside {
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  display: grid;
  gap: 10px;
  max-width: 375px;
  min-width: 0;
  padding: 12px;
  width: 100%;
}
widget-ns4-rules-102020 .ns4-filter-head {
  align-items: center;
  display: flex;
  justify-content: space-between;
}
widget-ns4-rules-102020 .ns4-filter-head h3 {
  font-size: 15px;
}
widget-ns4-rules-102020 .ns4-filter-head span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-rules-102020 .ns4-selects {
  display: grid;
  gap: 8px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-selects label {
  display: grid;
  gap: 4px;
}
widget-ns4-rules-102020 .ns4-selects label span {
  color: #64748b;
  font-size: 11px;
  font-weight: 650;
}
widget-ns4-rules-102020 .ns4-filters {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
widget-ns4-rules-102020 .ns4-filters > summary {
  align-items: center;
  color: #334155;
  cursor: pointer;
  display: flex;
  font-size: 12px;
  font-weight: 700;
  justify-content: space-between;
  list-style: none;
  padding: 9px 10px;
}
widget-ns4-rules-102020 .ns4-filters > summary::-webkit-details-marker {
  display: none;
}
widget-ns4-rules-102020 .ns4-filters > summary::after {
  color: #64748b;
  content: '⌄';
  font-size: 15px;
}
widget-ns4-rules-102020 .ns4-filters[open] > summary {
  border-bottom: 1px solid #e2e8f0;
}
widget-ns4-rules-102020 .ns4-filters[open] > summary::after {
  transform: rotate(180deg);
}
widget-ns4-rules-102020 .ns4-filter-content {
  display: grid;
  gap: 10px;
  padding: 10px;
}
widget-ns4-rules-102020 .ns4-checks {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 7px;
  padding-top: 9px;
}
widget-ns4-rules-102020 .ns4-checks label {
  align-items: center;
  color: #475569;
  display: flex;
  font-size: 12px;
  gap: 7px;
}
widget-ns4-rules-102020 .ns4-checks input {
  accent-color: #4338ca;
  width: 15px;
}
widget-ns4-rules-102020 .ns4-rule-list {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 7px;
  max-height: 680px;
  overflow-y: auto;
  padding-top: 10px;
}
widget-ns4-rules-102020 .ns4-rule-list > p {
  color: #64748b;
  font-size: 13px;
}
widget-ns4-rules-102020 .ns4-rule-item {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  cursor: pointer;
  display: grid;
  gap: 6px;
  padding: 10px;
  text-align: left;
}
widget-ns4-rules-102020 .ns4-rule-item:hover {
  border-color: #a5b4fc;
}
widget-ns4-rules-102020 .ns4-rule-item.selected {
  background: #f5f3ff;
  border-color: #818cf8;
}
widget-ns4-rules-102020 .ns4-rule-item > div {
  display: grid;
  gap: 2px;
}
widget-ns4-rules-102020 .ns4-rule-item strong {
  font-size: 13px;
  line-height: 1.35;
}
widget-ns4-rules-102020 .ns4-rule-item small {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-rules-102020 .ns4-rule-item i {
  font-size: 10px;
  font-style: normal;
}
widget-ns4-rules-102020 .ns4-rule-item i.complete {
  color: #166534;
}
widget-ns4-rules-102020 .ns4-rule-item i.incomplete {
  color: #b45309;
}
widget-ns4-rules-102020 .ns4-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
widget-ns4-rules-102020 .ns4-badges em,
widget-ns4-rules-102020 .ns4-detail-head > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 10px;
  font-style: normal;
  padding: 3px 6px;
}
widget-ns4-rules-102020 .ns4-badges .backend {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-badges .critical,
widget-ns4-rules-102020 .ns4-detail-head > span.critical {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-detail {
  align-content: start;
  display: grid;
  gap: 14px;
  min-width: 0;
}
widget-ns4-rules-102020 .ns4-detail-head {
  align-items: start;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-rules-102020 .ns4-detail-head h3 {
  font-size: 20px;
  margin-top: 3px;
}
widget-ns4-rules-102020 .ns4-edit {
  border-bottom: 1px dashed #a5b4fc;
  cursor: text;
  outline: 0;
}
widget-ns4-rules-102020 .ns4-edit:focus {
  background: #eef2ff;
  border-bottom-color: #4338ca;
}
widget-ns4-rules-102020 .ns4-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 4px;
  overflow-x: auto;
}
widget-ns4-rules-102020 .ns4-tabs button {
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  color: #64748b;
  cursor: pointer;
  padding: 8px 10px;
  white-space: nowrap;
}
widget-ns4-rules-102020 .ns4-tabs button.selected {
  border-bottom-color: #4338ca;
  color: #3730a3;
  font-weight: 650;
}
widget-ns4-rules-102020 .ns4-panel,
widget-ns4-rules-102020 .ns4-application article,
widget-ns4-rules-102020 .ns4-cases article,
widget-ns4-rules-102020 .ns4-coverage article {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  padding: 13px;
}
widget-ns4-rules-102020 .ns4-panel {
  display: grid;
  gap: 12px;
}
widget-ns4-rules-102020 .ns4-panel h4,
widget-ns4-rules-102020 .ns4-application h4,
widget-ns4-rules-102020 .ns4-cases h4,
widget-ns4-rules-102020 .ns4-traceability h4,
widget-ns4-rules-102020 .ns4-coverage h4 {
  font-size: 13px;
}
widget-ns4-rules-102020 .statement {
  color: #334155;
  font-size: 15px;
  line-height: 1.5;
  padding-bottom: 3px;
}
widget-ns4-rules-102020 .ns4-panel dl {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-panel dt,
widget-ns4-rules-102020 .ns4-application dt,
widget-ns4-rules-102020 .ns4-cases dt {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-rules-102020 .ns4-panel dd,
widget-ns4-rules-102020 .ns4-application dd,
widget-ns4-rules-102020 .ns4-cases dd {
  font-size: 13px;
  line-height: 1.4;
  margin-top: 3px;
}
widget-ns4-rules-102020 .ns4-predicate {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  line-height: 1.45;
  padding: 14px;
}
widget-ns4-rules-102020 .ns4-predicate ul {
  display: grid;
  gap: 7px;
  margin: 8px 0 0;
  padding-left: 18px;
}
widget-ns4-rules-102020 .ns4-application {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-application article {
  display: grid;
  gap: 10px;
}
widget-ns4-rules-102020 .ns4-application article > strong {
  color: #166534;
  font-size: 12px;
}
widget-ns4-rules-102020 .ns4-application dl {
  display: grid;
  gap: 8px;
}
widget-ns4-rules-102020 .ns4-application article > p {
  border-top: 1px solid #e2e8f0;
  color: #64748b;
  font-size: 12px;
  line-height: 1.4;
  padding-top: 10px;
}
widget-ns4-rules-102020 .ns4-cases,
widget-ns4-rules-102020 .ns4-coverage {
  display: grid;
  gap: 10px;
}
widget-ns4-rules-102020 .ns4-cases article {
  display: grid;
  gap: 8px;
  position: relative;
}
widget-ns4-rules-102020 .ns4-cases article > div {
  display: grid;
  gap: 3px;
}
widget-ns4-rules-102020 .ns4-cases article > span {
  border-radius: 999px;
  font-size: 11px;
  padding: 4px 7px;
  position: absolute;
  right: 12px;
  top: 12px;
}
widget-ns4-rules-102020 .ns4-cases .reject {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-cases .allow {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .ns4-cases article > p {
  color: #475569;
  font-size: 13px;
}
widget-ns4-rules-102020 .ns4-cases dl {
  display: grid;
  gap: 8px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-cases dd {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
widget-ns4-rules-102020 .ns4-cases dd code {
  background: #f8fafc;
  border-radius: 5px;
  padding: 3px 5px;
}
widget-ns4-rules-102020 .ns4-traceability {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-rules-102020 .ns4-traceability > div {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 6px;
  padding: 11px;
}
widget-ns4-rules-102020 .ns4-traceability code {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 5px;
  padding: 4px 6px;
}
widget-ns4-rules-102020 .ns4-coverage article {
  align-items: start;
  display: grid;
  gap: 5px;
  grid-template-columns: auto auto 1fr;
}
widget-ns4-rules-102020 .ns4-coverage article span {
  border-radius: 999px;
  font-size: 10px;
  padding: 3px 6px;
}
widget-ns4-rules-102020 .status-covered {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-rules-102020 .status-routed {
  background: #eff6ff;
  color: #1d4ed8;
}
widget-ns4-rules-102020 .status-missing {
  background: #fff1f2;
  color: #be123c;
}
widget-ns4-rules-102020 .ns4-coverage article p {
  color: #475569;
  font-size: 13px;
}
widget-ns4-rules-102020 footer {
  border-top: 1px solid #c7d2fe;
  display: grid;
  gap: 10px;
  padding-top: 15px;
}
widget-ns4-rules-102020 footer label {
  display: grid;
  gap: 6px;
}
widget-ns4-rules-102020 footer label > span {
  color: #475569;
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-rules-102020 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-rules-102020 footer button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-rules-102020 footer .cancel {
  background: #fff;
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-rules-102020 footer .secondary,
widget-ns4-rules-102020 footer .primary {
  background: #fff;
  color: #334155;
}
widget-ns4-rules-102020 footer .is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-rules-102020 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-rules-102020 .ns4-cancel-dialog {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-rules-102020 .ns4-cancel-dialog p {
  color: #475569;
}
widget-ns4-rules-102020 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-rules-102020 .ns4-cancel-dialog button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-rules-102020 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 700px) {
  widget-ns4-rules-102020 .ns4-workbench,
  widget-ns4-rules-102020 .ns4-application {
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 aside {
    max-width: none;
  }
  widget-ns4-rules-102020 .ns4-rule-list {
    max-height: 360px;
  }
}
@media (max-width: 650px) {
  widget-ns4-rules-102020 header,
  widget-ns4-rules-102020 .ns4-panel dl,
  widget-ns4-rules-102020 .ns4-cases dl,
  widget-ns4-rules-102020 .ns4-traceability {
    display: grid;
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 .ns4-header-meta {
    align-items: start;
    justify-items: start;
  }
  widget-ns4-rules-102020 .ns4-selects {
    grid-template-columns: 1fr;
  }
  widget-ns4-rules-102020 footer > div {
    display: grid;
  }
  widget-ns4-rules-102020 footer .cancel {
    margin-right: 0;
  }
  widget-ns4-rules-102020 .ns4-coverage article {
    grid-template-columns: 1fr;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.msgError = '';
        this.msgOk = '';
        this.search = '';
        this.selectedRuleId = '';
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.cancelOrigin = null;
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return {
                step: '👤 Etapa 5 de 6 — Regras de negócio', review: 'Revisão', rules: 'regras', search: 'Buscar por ID ou descrição',
                noRule: 'Nenhuma regra encontrada.', adjustment: 'O que deve mudar?',
                placeholder: 'Exemplo: altere a regra clientAvailable para permitir somente um cliente ativo por projeto.',
                request: 'Gerar nova proposta', approve: 'Aprovar regras', cancel: 'Cancelar execução',
                adjustmentRequired: 'Descreva a alteração necessária antes de gerar outra proposta.',
                processingApproval: 'Validando regras…', processingChanges: 'Preparando nova revisão…', processingCancel: 'Cancelando execução…',
                revise: 'Revise os itens abaixo', cancelTitle: 'Cancelar esta execução?',
                cancelText: 'O processamento será encerrado. Os artefatos já aprovados serão preservados.', keepWorking: 'Continuar trabalhando',
                hint: 'Cada regra permanente contém somente um ID estável e uma descrição de negócio.', edit: 'Clique para editar a descrição',
            };
        if (language.startsWith('es'))
            return {
                step: '👤 Paso 5 de 6 — Reglas de negocio', review: 'Revisión', rules: 'reglas', search: 'Buscar por ID o descripción',
                noRule: 'No se encontraron reglas.', adjustment: '¿Qué debe cambiar?',
                placeholder: 'Ejemplo: cambie la regla clientAvailable para permitir solo un cliente activo por proyecto.',
                request: 'Generar otra propuesta', approve: 'Aprobar reglas', cancel: 'Cancelar ejecución',
                adjustmentRequired: 'Describa el cambio antes de generar otra propuesta.',
                processingApproval: 'Validando reglas…', processingChanges: 'Preparando otra revisión…', processingCancel: 'Cancelando ejecución…',
                revise: 'Revise los elementos siguientes', cancelTitle: '¿Cancelar esta ejecución?',
                cancelText: 'El procesamiento terminará. Los artefactos aprobados serán preservados.', keepWorking: 'Seguir trabajando',
                hint: 'Cada regla permanente contiene solo un ID estable y una descripción de negocio.', edit: 'Haga clic para editar la descripción',
            };
        return {
            step: '👤 Step 5 of 6 — Business rules', review: 'Review', rules: 'rules', search: 'Search by ID or description',
            noRule: 'No rules found.', adjustment: 'What should change?',
            placeholder: 'Example: change clientAvailable to allow only one active client per project.',
            request: 'Generate another proposal', approve: 'Approve rules', cancel: 'Cancel execution',
            adjustmentRequired: 'Describe the required change before generating another proposal.',
            processingApproval: 'Validating rules…', processingChanges: 'Preparing another review…', processingCancel: 'Cancelling execution…',
            revise: 'Review the items below', cancelTitle: 'Cancel this execution?',
            cancelText: 'Processing will end. Approved artifacts will be preserved.', keepWorking: 'Keep working',
            hint: 'Each permanent rule contains only a stable ID and one business description.', edit: 'Click to edit the description',
        };
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    visibleRules() {
        const query = this.search.trim().toLowerCase();
        return (this.value?.rules || []).filter(rule => !query || `${rule.id} ${rule.description}`.toLowerCase().includes(query));
    }
    selected() {
        const visible = this.visibleRules();
        return visible.find(rule => rule.id === this.selectedRuleId) || visible[0] || this.value?.rules[0];
    }
    updateDescription(ruleId, event) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const description = event.currentTarget.innerText.trim();
        this.value = { ...this.value, rules: this.value.rules.map(rule => rule.id === ruleId ? { id: ruleId, description } : rule) };
    }
    finishEdit(event) {
        if (event.key !== 'Enter' || event.shiftKey)
            return;
        event.preventDefault();
        event.currentTarget.blur();
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-rules-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.noRule}</div>`;
        const rules = this.visibleRules();
        const selected = this.selected();
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `<section class="ns4-rules"><header><div><p class="ns4-step">${text.step}</p><h2>${this.value.title}</h2><p>${text.hint}</p></div><div class="ns4-header-meta"><span>${text.review} ${this.value.reviewRound}</span><strong>${this.value.rules.length} ${text.rules}</strong></div></header>
      ${this.renderFeedback(text)}
      <div class="ns4-workbench"><aside><input aria-label=${text.search} placeholder=${text.search} .value=${this.search}
        ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.search = event.target.value; }}>
        <div class="ns4-rule-list">${rules.length ? rules.map(rule => html `<button class="ns4-rule-item ${selected?.id === rule.id ? 'selected' : ''}"
          @click=${() => { this.selectedRuleId = rule.id; }}><code>${rule.id}</code><small>${rule.description}</small></button>`) : html `<p>${text.noRule}</p>`}</div></aside>
        ${selected ? html `<main class="ns4-detail"><div class="ns4-detail-head"><code>${selected.id}</code></div><p class="ns4-edit statement"
          contenteditable=${this.readonly ? 'false' : 'true'} title=${text.edit}
          @blur=${(event) => this.updateDescription(selected.id, event)} @keydown=${this.finishEdit}>${selected.description}</p></main>` : ''}
      </div>
      <footer><label><span>${text.adjustment}</span><textarea .value=${this.adjustment} placeholder=${text.placeholder}
        ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label><div>
        <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
        <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.request}</button>
        <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
      </div></footer>${this.renderCancelDialog(text)}</section>`;
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true"><h3>${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Rules102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Rules102020.prototype, "readonly", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Rules102020.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Rules102020.prototype, "msgOk", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "search", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "selectedRuleId", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Rules102020.prototype, "cancelOpen", void 0);
WidgetNs4Rules102020 = __decorate([
    customElement('widget-ns4-rules-102020')
], WidgetNs4Rules102020);
export { WidgetNs4Rules102020 };
