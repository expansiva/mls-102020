/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4AccessMatrix.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const labels = {
    en: {
        subtitle: 'Review who may perform each capability and exactly which information may be disclosed.',
        round: 'Review', profiles: 'Access profiles', internal: 'Internal', external: 'External',
        actors: 'E2 actors', landing: 'Starting point', matrix: 'Profile × authority matrix', profileAccess: 'Authorities for this profile',
        authority: 'Authority', noAccess: 'No access', full: 'Full record', limited: 'Limited',
        details: 'Access details', reason: 'Business reason', scope: 'Data scope', disclosure: 'Disclosure boundary',
        allowed: 'May expose', denied: 'Must not expose', constraints: 'Constraints', journeySteps: 'Journey steps',
        informationNeeds: 'Information needs', changes: 'Changes in this round', adjustment: 'What should change?',
        placeholder: 'Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.',
        requestChanges: 'Generate another proposal', approve: 'Approve access matrix',
        adjustmentRequired: 'Describe the required change before generating another proposal.', empty: 'No access matrix available.',
    },
    pt: {
        subtitle: 'Revise quem pode executar cada capacidade e exatamente quais informações podem ser expostas.',
        round: 'Revisão', profiles: 'Perfis de acesso', internal: 'Interno', external: 'Externo',
        actors: 'Atores do E2', landing: 'Ponto de entrada', matrix: 'Matriz perfil × autoridade', profileAccess: 'Autoridades deste perfil',
        authority: 'Autoridade', noAccess: 'Sem acesso', full: 'Registro completo', limited: 'Limitado',
        details: 'Detalhes do acesso', reason: 'Motivo de negócio', scope: 'Escopo dos dados', disclosure: 'Limite de exposição',
        allowed: 'Pode expor', denied: 'Não pode expor', constraints: 'Restrições', journeySteps: 'Passos das jornadas',
        informationNeeds: 'Necessidades de informação', changes: 'Alterações desta revisão', adjustment: 'O que deve mudar?',
        placeholder: 'Exemplo: adicione autoridade para ver orçamentos; alguns clientes podem ver um resumo sem acessar o projeto inteiro.',
        requestChanges: 'Gerar nova proposta', approve: 'Aprovar matriz de acesso',
        adjustmentRequired: 'Descreva a alteração necessária antes de gerar outra proposta.', empty: 'Nenhuma matriz de acesso disponível.',
    },
    es: {
        subtitle: 'Revise quién puede ejecutar cada capacidad y exactamente qué información puede exponerse.',
        round: 'Revisión', profiles: 'Perfiles de acceso', internal: 'Interno', external: 'Externo',
        actors: 'Actores de E2', landing: 'Punto de entrada', matrix: 'Matriz perfil × autoridad', profileAccess: 'Autoridades de este perfil',
        authority: 'Autoridad', noAccess: 'Sin acceso', full: 'Registro completo', limited: 'Limitado',
        details: 'Detalles del acceso', reason: 'Motivo de negocio', scope: 'Alcance de datos', disclosure: 'Límite de exposición',
        allowed: 'Puede exponer', denied: 'No puede exponer', constraints: 'Restricciones', journeySteps: 'Pasos de jornadas',
        informationNeeds: 'Necesidades de información', changes: 'Cambios de esta revisión', adjustment: '¿Qué debe cambiar?',
        placeholder: 'Ejemplo: agregue autoridad para ver presupuestos; algunos clientes pueden ver un resumen sin acceder al proyecto completo.',
        requestChanges: 'Generar otra propuesta', approve: 'Aprobar matriz de acceso',
        adjustmentRequired: 'Describa el cambio necesario antes de generar otra propuesta.', empty: 'No hay matriz de acceso disponible.',
    },
};
let WidgetNs4AccessMatrix102020 = class WidgetNs4AccessMatrix102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-access-matrix-102020 {
  display: block;
  color: #172033;
}
widget-ns4-access-matrix-102020 * {
  box-sizing: border-box;
}
widget-ns4-access-matrix-102020 h2,
widget-ns4-access-matrix-102020 h3,
widget-ns4-access-matrix-102020 h4,
widget-ns4-access-matrix-102020 p,
widget-ns4-access-matrix-102020 dl,
widget-ns4-access-matrix-102020 dd {
  margin: 0;
}
widget-ns4-access-matrix-102020 ul {
  margin: 8px 0 0;
  padding-left: 20px;
}
widget-ns4-access-matrix-102020 li {
  line-height: 1.45;
  margin: 4px 0;
}
widget-ns4-access-matrix-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
widget-ns4-access-matrix-102020 .ns4-access-matrix {
  display: grid;
  gap: 16px;
}
widget-ns4-access-matrix-102020 header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-access-matrix-102020 header p {
  color: #64748b;
  margin-top: 6px;
  max-width: 780px;
}
widget-ns4-access-matrix-102020 header > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-access-matrix-102020 .ns4-changes,
widget-ns4-access-matrix-102020 .ns4-profiles,
widget-ns4-access-matrix-102020 .ns4-matrix-card,
widget-ns4-access-matrix-102020 .ns4-details,
widget-ns4-access-matrix-102020 footer {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 15px;
}
widget-ns4-access-matrix-102020 .ns4-changes {
  background: #f0fdf4;
  border-color: #bbf7d0;
}
widget-ns4-access-matrix-102020 .ns4-changes h3 {
  color: #166534;
}
widget-ns4-access-matrix-102020 .ns4-profiles > div {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  margin-top: 10px;
}
widget-ns4-access-matrix-102020 .ns4-profile {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  cursor: pointer;
  padding: 11px;
  text-align: left;
}
widget-ns4-access-matrix-102020 .ns4-profile:hover {
  border-color: #a5b4fc;
}
widget-ns4-access-matrix-102020 .ns4-profile.selected {
  background: #f5f3ff;
  border-color: #6366f1;
  box-shadow: 0 0 0 1px #6366f1 inset;
}
widget-ns4-access-matrix-102020 .ns4-profile > div {
  align-items: center;
  display: flex;
  gap: 8px;
  justify-content: space-between;
}
widget-ns4-access-matrix-102020 .ns4-profile > div span {
  border-radius: 999px;
  font-size: 11px;
  padding: 3px 7px;
}
widget-ns4-access-matrix-102020 .ns4-profile > div span.internal {
  background: #dbeafe;
  color: #1d4ed8;
}
widget-ns4-access-matrix-102020 .ns4-profile > div span.external {
  background: #ffedd5;
  color: #c2410c;
}
widget-ns4-access-matrix-102020 .ns4-profile > p {
  color: #52606d;
  line-height: 1.4;
  margin-top: 7px;
}
widget-ns4-access-matrix-102020 .ns4-profiles dl {
  display: grid;
  gap: 7px;
  margin-top: 10px;
}
widget-ns4-access-matrix-102020 .ns4-profiles dt {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-access-matrix-102020 .ns4-profiles dd {
  font-size: 13px;
  line-height: 1.35;
  margin-top: 2px;
}
widget-ns4-access-matrix-102020 .ns4-section-head {
  align-items: center;
  display: flex;
  gap: 12px;
  justify-content: space-between;
  margin-bottom: 10px;
}
widget-ns4-access-matrix-102020 .ns4-section-head p {
  color: #64748b;
  font-size: 13px;
  margin-top: 3px;
}
widget-ns4-access-matrix-102020 .ns4-section-head > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 11px;
  padding: 5px 8px;
  white-space: nowrap;
}
widget-ns4-access-matrix-102020 .ns4-authority-list {
  display: grid;
  gap: 8px;
}
widget-ns4-access-matrix-102020 .ns4-authority {
  align-items: center;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  display: flex;
  gap: 16px;
  justify-content: space-between;
  padding: 11px 12px;
  text-align: left;
  width: 100%;
}
widget-ns4-access-matrix-102020 button.ns4-authority {
  cursor: pointer;
}
widget-ns4-access-matrix-102020 button.ns4-authority:hover {
  border-color: #a5b4fc;
}
widget-ns4-access-matrix-102020 .ns4-authority.selected {
  background: #f5f3ff;
  border-color: #6366f1;
  box-shadow: 0 0 0 1px #6366f1 inset;
}
widget-ns4-access-matrix-102020 .ns4-authority.no-access {
  background: #f8fafc;
  color: #64748b;
  opacity: 0.72;
}
widget-ns4-access-matrix-102020 .ns4-authority > div {
  min-width: 0;
}
widget-ns4-access-matrix-102020 .ns4-authority strong,
widget-ns4-access-matrix-102020 .ns4-authority code {
  display: block;
}
widget-ns4-access-matrix-102020 .ns4-authority code {
  margin-top: 3px;
}
widget-ns4-access-matrix-102020 .ns4-authority p {
  color: #64748b;
  display: -webkit-box;
  font-size: 13px;
  line-height: 1.35;
  margin-top: 4px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
widget-ns4-access-matrix-102020 .ns4-authority > span {
  border-radius: 999px;
  flex: 0 0 auto;
  font-size: 11px;
  padding: 6px 9px;
  white-space: nowrap;
}
widget-ns4-access-matrix-102020 .ns4-authority > span.full {
  background: #dcfce7;
  color: #166534;
}
widget-ns4-access-matrix-102020 .ns4-authority > span.limited {
  background: #fef3c7;
  color: #92400e;
}
widget-ns4-access-matrix-102020 .ns4-details {
  display: grid;
  gap: 12px;
}
widget-ns4-access-matrix-102020 .ns4-details-head {
  align-items: center;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-access-matrix-102020 .ns4-details-head p {
  color: #64748b;
  margin-top: 3px;
}
widget-ns4-access-matrix-102020 .ns4-detail-grid,
widget-ns4-access-matrix-102020 .ns4-detail-lists {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-access-matrix-102020 .ns4-detail-grid article,
widget-ns4-access-matrix-102020 .ns4-detail-lists article {
  background: #f8fafc;
  border-radius: 9px;
  padding: 11px;
}
widget-ns4-access-matrix-102020 .ns4-detail-grid h4,
widget-ns4-access-matrix-102020 .ns4-detail-lists h4 {
  color: #475569;
  font-size: 12px;
  margin-bottom: 5px;
}
widget-ns4-access-matrix-102020 .ns4-detail-grid p {
  line-height: 1.4;
  margin-top: 3px;
}
widget-ns4-access-matrix-102020 footer {
  display: grid;
  gap: 12px;
}
widget-ns4-access-matrix-102020 footer label,
widget-ns4-access-matrix-102020 footer label span {
  display: grid;
  gap: 6px;
}
widget-ns4-access-matrix-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font: inherit;
  min-height: 105px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-access-matrix-102020 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-access-matrix-102020 footer button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  font: inherit;
  padding: 9px 14px;
}
widget-ns4-access-matrix-102020 footer button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-access-matrix-102020 footer button.secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-access-matrix-102020 footer button.primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
@media (max-width: 760px) {
  widget-ns4-access-matrix-102020 header,
  widget-ns4-access-matrix-102020 .ns4-details-head,
  widget-ns4-access-matrix-102020 .ns4-section-head,
  widget-ns4-access-matrix-102020 .ns4-authority {
    display: grid;
  }
  widget-ns4-access-matrix-102020 .ns4-detail-grid,
  widget-ns4-access-matrix-102020 .ns4-detail-lists {
    grid-template-columns: 1fr;
  }
  widget-ns4-access-matrix-102020 footer > div {
    display: grid;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedProfileId = '';
        this.selectedGrantKey = '';
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return labels.pt;
        if (language.startsWith('es'))
            return labels.es;
        return labels.en;
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            window.alert(text.adjustmentRequired);
            return;
        }
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-access-matrix-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value },
            bubbles: true,
            composed: true,
        }));
    }
    grantKey(grant) {
        return `${grant.profileRef}\u0000${grant.authorityRef}`;
    }
    selectedGrant() {
        if (!this.value)
            return undefined;
        const profile = this.selectedProfile();
        return this.value.grants.find(grant => this.grantKey(grant) === this.selectedGrantKey)
            || this.value.grants.find(grant => grant.profileRef === profile?.profileId)
            || this.value.grants[0];
    }
    selectedProfile() {
        if (!this.value)
            return undefined;
        return this.value.profiles.find(profile => profile.profileId === this.selectedProfileId) || this.value.profiles[0];
    }
    selectProfile(profileId) {
        this.selectedProfileId = profileId;
        const grant = this.value?.grants.find(item => item.profileRef === profileId);
        this.selectedGrantKey = grant ? this.grantKey(grant) : '';
    }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const profile = this.selectedProfile();
        const selected = this.selectedGrant();
        return html `
      <section class="ns4-access-matrix">
        <header>
          <div><h2>${this.value.title}</h2><p>${text.subtitle}</p></div>
          <span>${text.round} ${this.value.reviewRound}</span>
        </header>

        ${this.value.changeSummary.length ? html `
          <section class="ns4-changes"><h3>${text.changes}</h3><ul>${this.value.changeSummary.map(item => html `<li>${item}</li>`)}</ul></section>
        ` : ''}

        <section class="ns4-profiles">
          <h3>${text.profiles}</h3>
          <div>${this.value.profiles.map(item => html `
            <button class="ns4-profile ${profile === item ? 'selected' : ''}" @click=${() => this.selectProfile(item.profileId)}>
              <div><strong>${item.title}</strong><span class=${item.kind}>${item.kind === 'external' ? text.external : text.internal}</span></div>
              <p>${item.description}</p>
              <dl>
                <div><dt>${text.actors}</dt><dd>${item.actorRefs.map(actorRef => this.actorLabel(actorRef)).join(', ') || '—'}</dd></div>
                <div><dt>${text.landing}</dt><dd>${item.landingIntent}</dd></div>
              </dl>
            </button>
          `)}</div>
        </section>

        ${profile ? this.renderAuthorityList(profile, selected, text) : ''}

        ${selected ? this.renderDetails(selected, text) : ''}

        <footer>
          <label><span>${text.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${text.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="secondary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('requestChanges')}>${text.requestChanges}</button>
            <button class="primary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('approve')}>${text.approve}</button>
          </div>
        </footer>
      </section>
    `;
    }
    renderDetails(grant, text) {
        const profile = this.value.profiles.find(item => item.profileId === grant.profileRef);
        const authority = this.value.authorities.find(item => item.authorityRef === grant.authorityRef);
        return html `
      <section class="ns4-details">
        <div class="ns4-details-head"><div><h3>${text.details}</h3><p>${profile?.title} → ${authority?.title}</p></div><code>${grant.authorityRef}</code></div>
        <div class="ns4-detail-grid">
          <article><h4>${text.reason}</h4><p>${grant.reason}</p></article>
          <article><h4>${text.scope}</h4><strong>${grant.dataScope.mode}</strong><p>${grant.dataScope.description}</p></article>
          <article><h4>${text.disclosure}</h4><strong>${grant.disclosure.mode}</strong><p>${grant.disclosure.description}</p></article>
          <article><h4>${text.journeySteps}</h4><p>${authority?.journeyStepRefs.join(', ') || '—'}</p></article>
        </div>
        <div class="ns4-detail-lists">
          <article><h4>${text.allowed}</h4><ul>${grant.disclosure.allowedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.denied}</h4><ul>${grant.disclosure.deniedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.constraints}</h4><ul>${grant.constraints.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.informationNeeds}</h4><ul>${authority?.informationNeeds.map(item => html `<li>${item}</li>`)}</ul></article>
        </div>
      </section>
    `;
    }
    renderAuthorityList(profile, selected, text) {
        return html `
      <section class="ns4-matrix-card">
        <div class="ns4-section-head"><div><h3>${text.profileAccess}</h3><p>${profile.title}</p></div><span>${this.value.grants.filter(grant => grant.profileRef === profile.profileId).length} ${text.authority.toLowerCase()}</span></div>
        <div class="ns4-authority-list">
          ${this.value.authorities.map(authority => {
            const grant = this.value.grants.find(item => item.profileRef === profile.profileId && item.authorityRef === authority.authorityRef);
            if (!grant)
                return html `
              <article class="ns4-authority no-access"><div><strong>${authority.title}</strong><code>${authority.authorityRef}</code><p>${authority.description}</p></div><span>${text.noAccess}</span></article>
            `;
            const full = grant.disclosure.mode === 'fullRecord';
            const key = this.grantKey(grant);
            return html `
              <button class="ns4-authority ${selected === grant ? 'selected' : ''}" @click=${() => { this.selectedGrantKey = key; }}>
                <div><strong>${authority.title}</strong><code>${authority.authorityRef}</code><p>${authority.description}</p></div>
                <span class=${full ? 'full' : 'limited'}>${full ? text.full : text.limited}</span>
              </button>
            `;
        })}
        </div>
      </section>
    `;
    }
    actorLabel(actorRef) {
        const readable = actorRef.replace(/([a-z])([A-Z])/g, '$1 $2');
        return `${readable.slice(0, 1).toUpperCase()}${readable.slice(1)}`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4AccessMatrix102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4AccessMatrix102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102020.prototype, "selectedProfileId", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102020.prototype, "selectedGrantKey", void 0);
WidgetNs4AccessMatrix102020 = __decorate([
    customElement('widget-ns4-access-matrix-102020')
], WidgetNs4AccessMatrix102020);
export { WidgetNs4AccessMatrix102020 };
