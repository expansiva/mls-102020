/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Journeys.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Journeys102020 = class WidgetNs4Journeys102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-journeys-102020 {
  display: block;
  color: #18212f;
}
widget-ns4-journeys-102020 * {
  box-sizing: border-box;
}
widget-ns4-journeys-102020 h2,
widget-ns4-journeys-102020 h3,
widget-ns4-journeys-102020 h4,
widget-ns4-journeys-102020 p,
widget-ns4-journeys-102020 dl,
widget-ns4-journeys-102020 dd {
  margin: 0;
}
widget-ns4-journeys-102020 h2 {
  font-size: 24px;
  line-height: 1.2;
}
widget-ns4-journeys-102020 h3 {
  font-size: 20px;
  line-height: 1.25;
  margin-top: 4px;
}
widget-ns4-journeys-102020 h4 {
  font-size: 14px;
}
widget-ns4-journeys-102020 p {
  color: #52606d;
  line-height: 1.45;
}
widget-ns4-journeys-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 12px;
}
widget-ns4-journeys-102020 ul {
  margin: 8px 0 0;
  padding-left: 20px;
}
widget-ns4-journeys-102020 li {
  line-height: 1.45;
  margin: 5px 0;
}
widget-ns4-journeys-102020 button,
widget-ns4-journeys-102020 textarea {
  font: inherit;
}
widget-ns4-journeys-102020 button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
}
widget-ns4-journeys-102020 button:disabled {
  cursor: not-allowed;
  opacity: 0.56;
}
widget-ns4-journeys-102020 .ns4-journeys {
  display: grid;
  gap: 16px;
  min-width: 0;
}
widget-ns4-journeys-102020 .ns4-header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-journeys-102020 .ns4-breadcrumb {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 8px;
}
widget-ns4-journeys-102020 .ns4-header p {
  margin-top: 6px;
}
widget-ns4-journeys-102020 .ns4-header-meta {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 148px;
}
widget-ns4-journeys-102020 .ns4-header-meta span,
widget-ns4-journeys-102020 .ns4-header-meta strong,
widget-ns4-journeys-102020 .ns4-pill {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 5px 9px;
}
widget-ns4-journeys-102020 .ns4-header-meta strong {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-journeys-102020 .ns4-filters {
  align-items: center;
  display: grid;
  gap: 12px;
  grid-template-columns: minmax(180px, 1fr) minmax(280px, 2fr);
}
widget-ns4-journeys-102020 .ns4-filters > span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-journeys-102020 .ns4-actor-filter {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
}
widget-ns4-journeys-102020 .ns4-actor-filter button,
widget-ns4-journeys-102020 .ns4-tabs button {
  background: #fff;
  color: #334155;
  padding: 8px 10px;
}
widget-ns4-journeys-102020 .ns4-actor-filter button {
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-actor-filter button.is-active,
widget-ns4-journeys-102020 .ns4-tabs button.is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-journeys-102020 .ns4-actor-map,
widget-ns4-journeys-102020 .ns4-list,
widget-ns4-journeys-102020 .ns4-detail,
widget-ns4-journeys-102020 .ns4-features,
widget-ns4-journeys-102020 .ns4-review {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
widget-ns4-journeys-102020 .ns4-section-title {
  align-items: center;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  padding: 12px 14px;
}
widget-ns4-journeys-102020 .ns4-section-title span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-journeys-102020 .ns4-lanes {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-lane {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 8px;
  min-width: 0;
  padding: 10px;
}
widget-ns4-journeys-102020 .ns4-lane.is-filtered {
  border-color: #6366f1;
  box-shadow: 0 0 0 1px #6366f1 inset;
}
widget-ns4-journeys-102020 .ns4-lane-head {
  align-items: center;
  background: #f8fafc;
  display: grid;
  gap: 8px;
  grid-template-columns: minmax(0, 1fr) auto;
  padding: 8px 10px;
  text-align: left;
}
widget-ns4-journeys-102020 .ns4-lane-head span {
  min-width: 0;
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-lane-items {
  display: grid;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-lane-items button {
  background: #fff;
  overflow: hidden;
  padding: 7px 8px;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}
widget-ns4-journeys-102020 .ns4-lane-items button.is-selected {
  border-color: #4338ca;
  color: #3730a3;
}
widget-ns4-journeys-102020 .ns4-main {
  align-items: start;
  display: grid;
  gap: 16px;
  grid-template-columns: minmax(250px, 0.82fr) minmax(0, 2fr);
}
widget-ns4-journeys-102020 .ns4-list-items {
  display: grid;
  gap: 8px;
  max-height: 760px;
  overflow: auto;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-journey-card {
  background: #fff;
  display: grid;
  gap: 5px;
  padding: 12px;
  text-align: left;
}
widget-ns4-journeys-102020 .ns4-journey-card:hover {
  border-color: #a5b4fc;
}
widget-ns4-journeys-102020 .ns4-journey-card.is-selected {
  background: #f5f3ff;
  border-color: #7c3aed;
}
widget-ns4-journeys-102020 .ns4-journey-card span {
  color: #475569;
  font-size: 12px;
}
widget-ns4-journeys-102020 .ns4-journey-card small {
  color: #64748b;
  display: -webkit-box;
  line-height: 1.35;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
widget-ns4-journeys-102020 .ns4-detail {
  display: grid;
  gap: 16px;
  padding: 16px;
}
widget-ns4-journeys-102020 .ns4-detail-head {
  align-items: flex-start;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-journeys-102020 .ns4-summary,
widget-ns4-journeys-102020 .ns4-context-grid {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-journeys-102020 .ns4-summary > div,
widget-ns4-journeys-102020 .ns4-context-grid > section,
widget-ns4-journeys-102020 .ns4-two-columns > div {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 dt {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 4px;
}
widget-ns4-journeys-102020 dd {
  color: #1f2937;
  line-height: 1.4;
}
widget-ns4-journeys-102020 .ns4-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-tabs button {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom-width: 0;
}
widget-ns4-journeys-102020 .ns4-steps-section {
  display: grid;
  gap: 10px;
}
widget-ns4-journeys-102020 .ns4-steps {
  display: grid;
  gap: 10px;
  list-style: none;
  margin: 0;
  padding: 0;
}
widget-ns4-journeys-102020 .ns4-steps li {
  align-items: start;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 12px;
  grid-template-columns: auto 1fr;
  margin: 0;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-step-index {
  align-items: center;
  background: #4338ca;
  border-radius: 999px;
  color: #fff;
  display: inline-flex;
  font-size: 13px;
  height: 28px;
  justify-content: center;
  width: 28px;
}
widget-ns4-journeys-102020 .ns4-step-title {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
widget-ns4-journeys-102020 .ns4-step-title > span {
  color: #4338ca;
  font-size: 11px;
  text-transform: uppercase;
}
widget-ns4-journeys-102020 .ns4-steps p,
widget-ns4-journeys-102020 .ns4-steps small {
  color: #52606d;
  display: block;
  margin-top: 5px;
}
widget-ns4-journeys-102020 .ns4-rules {
  display: grid;
  gap: 12px;
}
widget-ns4-journeys-102020 .ns4-rules > p {
  font-size: 13px;
}
widget-ns4-journeys-102020 .ns4-rules > ol {
  display: grid;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}
widget-ns4-journeys-102020 .ns4-rules > ol li {
  align-items: start;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 10px;
  grid-template-columns: auto 1fr;
  margin: 0;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 .ns4-outcome {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 .ns4-outcome p {
  margin-top: 6px;
}
widget-ns4-journeys-102020 .ns4-feature-grid {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-feature-grid article {
  align-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: flex;
  gap: 10px;
  justify-content: space-between;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-feature-grid article > div {
  display: grid;
  gap: 4px;
}
widget-ns4-journeys-102020 .ns4-feature-grid article > span {
  background: #ecfdf5;
  border-radius: 999px;
  color: #166534;
  font-size: 11px;
  padding: 4px 8px;
}
widget-ns4-journeys-102020 .ns4-review {
  display: grid;
  gap: 12px;
  padding: 14px;
}
widget-ns4-journeys-102020 .ns4-review label,
widget-ns4-journeys-102020 .ns4-review label span {
  display: grid;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-review label > span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-journeys-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  min-height: 100px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-review > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-journeys-102020 button {
  padding: 9px 14px;
}
widget-ns4-journeys-102020 button.secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-journeys-102020 button.primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
@media (max-width: 760px) {
  widget-ns4-journeys-102020 .ns4-filters,
  widget-ns4-journeys-102020 .ns4-main,
  widget-ns4-journeys-102020 .ns4-summary,
  widget-ns4-journeys-102020 .ns4-context-grid {
    grid-template-columns: 1fr;
  }
  widget-ns4-journeys-102020 .ns4-header {
    display: grid;
  }
  widget-ns4-journeys-102020 .ns4-header-meta {
    align-items: flex-start;
  }
  widget-ns4-journeys-102020 .ns4-actor-filter {
    justify-content: flex-start;
  }
  widget-ns4-journeys-102020 .ns4-list-items {
    max-height: 320px;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedActorRef = 'all';
        this.selectedJourneyId = '';
        this.activeTab = 'overview';
    }
    labels() {
        const pt = this.value?.userLanguage?.toLowerCase().startsWith('pt');
        return pt ? {
            subtitle: 'Estas jornadas serão a fonte de verdade permanente do produto.',
            actor: 'Ator', goal: 'Objetivo', entry: 'Entrada', prerequisites: 'Pré-requisitos',
            context: 'Contexto de negócio', steps: 'Passos', requires: 'Requer', provides: 'Produz',
            rules: 'Regras', outcome: 'Resultado e evidências', features: 'Funcionalidades',
            journeys: 'Jornadas', journeysFound: 'jornadas encontradas', selectJourney: 'Selecione uma jornada para revisar.',
            allActors: 'Todos os atores', actorMap: 'Mapa de jornadas por ator', actors: 'atores', overview: 'Visão geral',
            rulesHelp: 'Regras que devem continuar verdadeiras em toda execução desta jornada.',
            adjustment: 'O que deve mudar?', placeholder: 'Descreva a alteração necessária sem reescrever o que já está correto.',
            requestChanges: 'Pedir mudanças', approve: 'Aprovar jornadas', round: 'Revisão',
            adjustmentRequired: 'Escreva o que precisa mudar antes de solicitar uma nova versão.',
        } : {
            subtitle: 'These journeys will become the permanent source of truth for the product.',
            actor: 'Actor', goal: 'Goal', entry: 'Entry', prerequisites: 'Prerequisites',
            context: 'Business context', steps: 'Steps', requires: 'Requires', provides: 'Provides',
            rules: 'Rules', outcome: 'Outcome and evidence', features: 'Features',
            journeys: 'Journeys', journeysFound: 'journeys found', selectJourney: 'Select a journey to review.',
            allActors: 'All actors', actorMap: 'Journey map by actor', actors: 'actors', overview: 'Overview',
            rulesHelp: 'Rules that must remain true in every execution of this journey.',
            adjustment: 'What should change?', placeholder: 'Describe the needed change without rewriting what is already correct.',
            requestChanges: 'Request changes', approve: 'Approve journeys', round: 'Review',
            adjustmentRequired: 'Describe what must change before requesting another version.',
        };
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const labels = this.labels();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            window.alert(labels.adjustmentRequired);
            return;
        }
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-journeys-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value },
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        if (!this.value)
            return html `<div class="ns4-empty">No E2 review available.</div>`;
        const labels = this.labels();
        const actorRefs = [...new Set(this.value.journeys.map(item => item.business.actorRef))];
        const visibleJourneys = this.value.journeys.filter(item => this.selectedActorRef === 'all' || item.business.actorRef === this.selectedActorRef);
        const journey = visibleJourneys.find(item => item.journeyId === this.selectedJourneyId) || visibleJourneys[0] || this.value.journeys[0];
        if (!journey)
            return html `<div class="ns4-empty">${labels.selectJourney}</div>`;
        return html `
      <section class="ns4-journeys">
        <header class="ns4-header">
          <div>
            <div class="ns4-breadcrumb">E2 · ${labels.journeys}</div>
            <h2>${this.value.title}</h2>
            <p>${labels.subtitle}</p>
          </div>
          <div class="ns4-header-meta">
            <span>${labels.round} ${this.value.reviewRound}</span>
            <strong>${this.value.journeys.length} ${labels.journeysFound}</strong>
          </div>
        </header>

        <section class="ns4-filters">
          <span>${visibleJourneys.length} ${labels.journeysFound}</span>
          <div class="ns4-actor-filter" role="group" aria-label=${labels.actorMap}>
            <button class=${this.selectedActorRef === 'all' ? 'is-active' : ''} @click=${() => this.selectActor('all', this.value?.journeys || [])}>
              ${labels.allActors}
            </button>
            ${actorRefs.map(actorRef => html `
              <button class=${this.selectedActorRef === actorRef ? 'is-active' : ''} @click=${() => this.selectActor(actorRef, this.value?.journeys || [])}>
                ${this.actorLabel(actorRef)}
              </button>
            `)}
          </div>
        </section>

        <section class="ns4-actor-map">
          <div class="ns4-section-title"><strong>${labels.actorMap}</strong><span>${actorRefs.length} ${labels.actors} / ${this.value.journeys.length} ${labels.journeys}</span></div>
          <div class="ns4-lanes">
            ${actorRefs.map(actorRef => {
            const actorJourneys = this.value?.journeys.filter(item => item.business.actorRef === actorRef) || [];
            return html `
                <div class="ns4-lane ${this.selectedActorRef === actorRef ? 'is-filtered' : ''}">
                  <button class="ns4-lane-head" @click=${() => this.selectActor(actorRef, actorJourneys)}><span>${this.actorLabel(actorRef)}</span><strong>${actorJourneys.length}</strong></button>
                  <div class="ns4-lane-items">${actorJourneys.map(item => html `
                    <button class=${item.journeyId === journey.journeyId ? 'is-selected' : ''} @click=${() => this.selectJourney(item.journeyId)}>${item.business.title}</button>
                  `)}</div>
                </div>
              `;
        })}
          </div>
        </section>

        <div class="ns4-main">
          <aside class="ns4-list">
            <div class="ns4-section-title"><strong>${labels.journeys}</strong><span>${visibleJourneys.length} ${labels.journeysFound}</span></div>
            <div class="ns4-list-items">
              ${visibleJourneys.map(item => html `
                <button class="ns4-journey-card ${item.journeyId === journey.journeyId ? 'is-selected' : ''}"
                  @click=${() => this.selectJourney(item.journeyId)}>
                  <code>${item.journeyId}</code>
                  <strong>${item.business.title}</strong>
                  <span>${this.actorLabel(item.business.actorRef)}</span>
                  <small>${item.business.goal}</small>
                </button>
              `)}
            </div>
          </aside>

          <article class="ns4-detail">
            <div class="ns4-detail-head">
              <div><code>${journey.journeyId}</code><h3>${journey.business.title}</h3></div>
              <span class="ns4-pill">${journey.business.entry.mode}</span>
            </div>

            <dl class="ns4-summary">
              <div><dt>${labels.actor}</dt><dd>${this.actorLabel(journey.business.actorRef)}</dd></div>
              <div><dt>${labels.goal}</dt><dd>${journey.business.goal}</dd></div>
              <div><dt>${labels.outcome}</dt><dd>${journey.business.outcome.statement}</dd></div>
            </dl>

            <nav class="ns4-tabs" role="tablist">
              ${this.renderTab('overview', labels.overview)}
              ${this.renderTab('rules', labels.rules)}
            </nav>

            ${this.activeTab === 'overview' ? this.renderOverview(journey, labels) : this.renderRules(journey, labels)}
          </article>
        </div>

        <section class="ns4-features">
          <div class="ns4-section-title"><strong>${labels.features}</strong><span>${this.value.features.length}</span></div>
          <div class="ns4-feature-grid">${this.value.features.map(feature => html `
            <article><div><strong>${feature.title}</strong><code>${feature.featureId}</code></div><span>${feature.priority}</span></article>
          `)}</div>
        </section>

        <footer class="ns4-review">
          <label><span>${labels.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${labels.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="secondary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('requestChanges')}>${labels.requestChanges}</button>
            <button class="primary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('approve')}>${labels.approve}</button>
          </div>
        </footer>
      </section>
    `;
    }
    selectActor(actorRef, journeys) {
        this.selectedActorRef = actorRef;
        this.selectedJourneyId = journeys.find(item => actorRef === 'all' || item.business.actorRef === actorRef)?.journeyId || '';
        this.activeTab = 'overview';
    }
    actorLabel(actorRef) {
        const readable = actorRef.replace(/([a-z])([A-Z])/g, '$1 $2');
        return `${readable.slice(0, 1).toUpperCase()}${readable.slice(1)}`;
    }
    selectJourney(journeyId) {
        this.selectedJourneyId = journeyId;
        this.activeTab = 'overview';
    }
    renderTab(tab, label) {
        return html `<button role="tab" aria-selected=${this.activeTab === tab ? 'true' : 'false'} class=${this.activeTab === tab ? 'is-active' : ''} @click=${() => { this.activeTab = tab; }}>${label}</button>`;
    }
    renderOverview(journey, labels) {
        return html `
      <div class="ns4-context-grid">
        <section>
          <h4>${labels.prerequisites}</h4>
          ${journey.business.prerequisites.length ? html `<ul>${journey.business.prerequisites.map(item => html `
            <li><code>${item.journeyRef}</code> — ${item.reason}${item.providesContext.length ? html ` → <code>${item.providesContext.join(', ')}</code>` : ''}</li>
          `)}</ul>` : html `<p>—</p>`}
        </section>
        <section>
          <h4>${labels.entry} · ${labels.context}</h4>
          ${journey.business.entry.carries.length ? html `<ul>${journey.business.entry.carries.map(context => html `
            <li><code>${context.contextId}</code> — ${context.businessObject}: ${context.description}${context.stateRequirement ? html ` (${context.stateRequirement})` : ''}</li>
          `)}</ul>` : html `<p>—</p>`}
        </section>
      </div>
      <section class="ns4-steps-section">
        <h4>${labels.steps}</h4>
        <ol class="ns4-steps">${journey.business.steps.map((step, index) => html `
          <li>
            <span class="ns4-step-index">${index + 1}</span>
            <div>
              <div class="ns4-step-title"><span>${step.kind}</span><strong>${step.intent}</strong><code>${step.stepId}</code></div>
              <p>${step.result}</p>
              <small>${labels.requires}: ${step.requiresContext.join(', ') || '—'} · ${labels.provides}: ${step.providesContext.map(item => item.contextId).join(', ') || '—'}</small>
            </div>
          </li>
        `)}</ol>
      </section>
    `;
    }
    renderRules(journey, labels) {
        return html `
      <section class="ns4-rules">
        <p>${labels.rulesHelp}</p>
        <ol>${journey.business.businessRules.map(rule => html `<li><code>${rule.journeyRuleId}</code><span>${rule.statement}</span></li>`)}</ol>
        <div class="ns4-outcome"><h4>${labels.outcome}</h4><p>${journey.business.outcome.statement}</p><ul>${journey.business.outcome.evidence.map(item => html `<li>${item}</li>`)}</ul></div>
      </section>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Journeys102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Journeys102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "selectedActorRef", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "selectedJourneyId", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "activeTab", void 0);
WidgetNs4Journeys102020 = __decorate([
    customElement('widget-ns4-journeys-102020')
], WidgetNs4Journeys102020);
export { WidgetNs4Journeys102020 };
