/// <mls fileReference="_102020_/l2/agentNewSolution4/widgets/widgetNs4Ontology.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const storageOrder = ['mdm', 'moduleDatabase', 'derived', 'external', 'embedded'];
const labels = {
    en: {
        subtitle: 'Review the business data, constraints and relationships that frontend and backend will share.',
        round: 'Review', mode: 'New solution', changes: 'Changes in this round', entities: 'Entities',
        fields: 'Fields', relationships: 'Relationships', lifecycle: 'Lifecycle', invariants: 'Local invariants', overview: 'Overview', descriptions: 'Descriptions',
        source: 'Traceability', storage: 'Persistence destination', required: 'Required', optional: 'Optional', constraints: 'Field rules',
        persistenceMap: 'Persistence map', persistenceHint: 'Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.',
        targetMdm: 'MDM · base records', targetModuleDatabase: 'Module database · transactions', targetDerived: 'Derived · no own table',
        targetExternal: 'External · platform owned', targetEmbedded: 'Embedded · owned value', scope: 'Scope', mdmType: 'MDM type', idField: 'Identifier', reason: 'Reason',
        fieldRulesHint: 'Backend enforces these validations; frontend mirrors them for immediate feedback.', crossStore: 'Cross-store',
        direct: 'Direct description edits', directHint: 'Titles and descriptions are safe to edit here. Structural changes use the separate request panel.',
        entityTitle: 'Entity title', entityDescription: 'Entity description', fieldTitle: 'Field title', fieldDescription: 'Field description',
        structural: 'Structural change request', structuralHint: 'Use the LLM for entities, fields, types, relationships, lifecycle or constraints.',
        placeholder: 'Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.',
        request: 'Generate another proposal', approve: 'Approve ontology', requiredAdjustment: 'Describe the structural change first.', empty: 'No ontology proposal available.',
    },
    pt: {
        subtitle: 'Revise os dados de negócio, restrições e relacionamentos compartilhados pelo frontend e backend.',
        round: 'Revisão', mode: 'Solução nova', changes: 'Alterações desta revisão', entities: 'Entidades',
        fields: 'Campos', relationships: 'Relacionamentos', lifecycle: 'Ciclo de vida', invariants: 'Invariantes locais', overview: 'Visão geral', descriptions: 'Descrições',
        source: 'Rastreabilidade', storage: 'Destino da persistência', required: 'Obrigatório', optional: 'Opcional', constraints: 'Regras do campo',
        persistenceMap: 'Mapa de persistência', persistenceHint: 'Confirme onde cada entidade será armazenada antes de aprovar. Selecione uma entidade para ver o motivo e os campos.',
        targetMdm: 'MDM · cadastros base', targetModuleDatabase: 'Banco do módulo · transações', targetDerived: 'Derivado · sem tabela própria',
        targetExternal: 'Externo · mantido pela plataforma', targetEmbedded: 'Embutido · valor do proprietário', scope: 'Escopo', mdmType: 'Tipo MDM', idField: 'Identificador', reason: 'Motivo',
        fieldRulesHint: 'O backend aplica estas validações; o frontend as espelha para resposta imediata.', crossStore: 'Entre armazenamentos',
        direct: 'Edições diretas de descrição', directHint: 'Títulos e descrições podem ser editados aqui. Mudanças estruturais usam o painel separado.',
        entityTitle: 'Título da entidade', entityDescription: 'Descrição da entidade', fieldTitle: 'Título do campo', fieldDescription: 'Descrição do campo',
        structural: 'Solicitação de alteração estrutural', structuralHint: 'Use a LLM para entidades, campos, tipos, relacionamentos, ciclos ou restrições.',
        placeholder: 'Exemplo: adicione uma projeção publicada do uso de materiais para o cliente, relacionada ao projeto e sem custos internos.',
        request: 'Gerar nova proposta', approve: 'Aprovar ontologia', requiredAdjustment: 'Descreva primeiro a alteração estrutural.', empty: 'Nenhuma proposta de ontologia disponível.',
    },
    es: {
        subtitle: 'Revise los datos de negocio, restricciones y relaciones compartidos por frontend y backend.',
        round: 'Revisión', mode: 'Solución nueva', changes: 'Cambios de esta revisión', entities: 'Entidades',
        fields: 'Campos', relationships: 'Relaciones', lifecycle: 'Ciclo de vida', invariants: 'Invariantes locales', overview: 'Resumen', descriptions: 'Descripciones',
        source: 'Trazabilidad', storage: 'Destino de persistencia', required: 'Obligatorio', optional: 'Opcional', constraints: 'Reglas del campo',
        persistenceMap: 'Mapa de persistencia', persistenceHint: 'Confirme dónde vive cada entidad antes de aprobar. Seleccione una entidad para revisar su motivo y campos.',
        targetMdm: 'MDM · datos maestros', targetModuleDatabase: 'Base del módulo · transacciones', targetDerived: 'Derivado · sin tabla propia',
        targetExternal: 'Externo · mantenido por la plataforma', targetEmbedded: 'Embebido · valor del propietario', scope: 'Alcance', mdmType: 'Tipo MDM', idField: 'Identificador', reason: 'Motivo',
        fieldRulesHint: 'El backend aplica estas validaciones; el frontend las refleja para respuesta inmediata.', crossStore: 'Entre almacenamientos',
        direct: 'Ediciones directas de descripción', directHint: 'Títulos y descripciones se editan aquí. Los cambios estructurales usan el panel separado.',
        entityTitle: 'Título de la entidad', entityDescription: 'Descripción de la entidad', fieldTitle: 'Título del campo', fieldDescription: 'Descripción del campo',
        structural: 'Solicitud de cambio estructural', structuralHint: 'Use la LLM para entidades, campos, tipos, relaciones, ciclos o restricciones.',
        placeholder: 'Ejemplo: agregue una proyección publicada del uso de materiales para el cliente, relacionada con el proyecto y sin costos internos.',
        request: 'Generar otra propuesta', approve: 'Aprobar ontología', requiredAdjustment: 'Describa primero el cambio estructural.', empty: 'No hay propuesta de ontología.',
    },
};
let WidgetNs4Ontology102020 = class WidgetNs4Ontology102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-ontology-102020 {
  display: block;
  color: #172033;
}
widget-ns4-ontology-102020 * {
  box-sizing: border-box;
}
widget-ns4-ontology-102020 h2,
widget-ns4-ontology-102020 h3,
widget-ns4-ontology-102020 p,
widget-ns4-ontology-102020 dl,
widget-ns4-ontology-102020 dd {
  margin: 0;
}
widget-ns4-ontology-102020 ul {
  margin: 7px 0 0;
  padding-left: 19px;
}
widget-ns4-ontology-102020 li {
  line-height: 1.45;
  margin: 3px 0;
}
widget-ns4-ontology-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
widget-ns4-ontology-102020 input,
widget-ns4-ontology-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font: inherit;
  padding: 9px;
  width: 100%;
}
widget-ns4-ontology-102020 textarea {
  min-height: 82px;
  resize: vertical;
}
widget-ns4-ontology-102020 button {
  font: inherit;
}
widget-ns4-ontology-102020 .ns4-ontology {
  display: grid;
  gap: 16px;
}
widget-ns4-ontology-102020 header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-ontology-102020 header p,
widget-ns4-ontology-102020 .ns4-change-panel p,
widget-ns4-ontology-102020 .ns4-direct-edits > div p {
  color: #64748b;
  margin-top: 5px;
}
widget-ns4-ontology-102020 .ns4-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: flex-end;
}
widget-ns4-ontology-102020 .ns4-badges span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-ontology-102020 .ns4-changes,
widget-ns4-ontology-102020 .ns4-persistence-map,
widget-ns4-ontology-102020 .ns4-workbench,
widget-ns4-ontology-102020 .ns4-relationships,
widget-ns4-ontology-102020 .ns4-change-panel {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 15px;
}
widget-ns4-ontology-102020 .ns4-changes {
  background: #f0fdf4;
  border-color: #bbf7d0;
}
widget-ns4-ontology-102020 .ns4-changes h3 {
  color: #166534;
}
widget-ns4-ontology-102020 .ns4-section-title p,
widget-ns4-ontology-102020 .ns4-fields > p {
  color: #64748b;
  line-height: 1.4;
  margin-top: 5px;
}
widget-ns4-ontology-102020 .ns4-storage-groups {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  margin-top: 12px;
}
widget-ns4-ontology-102020 .ns4-storage-groups > article {
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  min-width: 0;
  padding: 10px;
}
widget-ns4-ontology-102020 .ns4-storage-groups > article > header {
  align-items: center;
  display: flex;
  gap: 8px;
  justify-content: space-between;
}
widget-ns4-ontology-102020 .ns4-storage-groups > article > header strong {
  font-size: 12px;
}
widget-ns4-ontology-102020 .ns4-storage-groups > article > header span {
  background: rgba(255, 255, 255, 0.75);
  border-radius: 999px;
  font-size: 11px;
  padding: 3px 7px;
}
widget-ns4-ontology-102020 .ns4-storage-groups > article > div {
  display: grid;
  gap: 5px;
  margin-top: 8px;
}
widget-ns4-ontology-102020 .ns4-storage-groups button {
  background: rgba(255, 255, 255, 0.78);
  border: 1px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  display: grid;
  gap: 2px;
  padding: 7px;
  text-align: left;
}
widget-ns4-ontology-102020 .ns4-storage-groups button small {
  color: #64748b;
}
widget-ns4-ontology-102020 .ns4-storage-groups button.selected {
  border-color: #4f46e5;
  box-shadow: 0 0 0 1px rgba(79, 70, 229, 0.12);
}
widget-ns4-ontology-102020 .target-mdm {
  background: #ecfdf5;
  border-color: #86efac !important;
  color: #166534;
}
widget-ns4-ontology-102020 .target-moduleDatabase {
  background: #eff6ff;
  border-color: #93c5fd !important;
  color: #1d4ed8;
}
widget-ns4-ontology-102020 .target-derived {
  background: #faf5ff;
  border-color: #d8b4fe !important;
  color: #7e22ce;
}
widget-ns4-ontology-102020 .target-external {
  background: #fff7ed;
  border-color: #fdba74 !important;
  color: #9a3412;
}
widget-ns4-ontology-102020 .target-embedded {
  background: #f8fafc;
  border-color: #cbd5e1 !important;
  color: #475569;
}
widget-ns4-ontology-102020 .ns4-workbench {
  display: grid;
  gap: 16px;
  grid-template-columns: minmax(190px, 240px) minmax(0, 1fr);
}
widget-ns4-ontology-102020 nav {
  border-right: 1px solid #e2e8f0;
  display: grid;
  align-content: start;
  gap: 7px;
  padding-right: 14px;
}
widget-ns4-ontology-102020 nav h3 {
  margin-bottom: 3px;
}
widget-ns4-ontology-102020 nav button {
  background: #f8fafc;
  border: 1px solid transparent;
  border-radius: 8px;
  cursor: pointer;
  display: grid;
  gap: 3px;
  padding: 9px;
  text-align: left;
}
widget-ns4-ontology-102020 nav button small {
  color: #64748b;
}
widget-ns4-ontology-102020 nav button .ns4-nav-target {
  border-radius: 999px;
  font-size: 10px;
  justify-self: start;
  margin-top: 2px;
  padding: 3px 6px;
}
widget-ns4-ontology-102020 nav button.selected {
  background: #eef2ff;
  border-color: #818cf8;
  color: #3730a3;
}
widget-ns4-ontology-102020 main {
  display: grid;
  gap: 13px;
  min-width: 0;
}
widget-ns4-ontology-102020 .ns4-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 6px;
}
widget-ns4-ontology-102020 .ns4-tabs button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-bottom: 0;
  border-radius: 8px 8px 0 0;
  color: #475569;
  cursor: pointer;
  padding: 8px 11px;
}
widget-ns4-ontology-102020 .ns4-tabs button.selected {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-ontology-102020 .ns4-entity-head {
  display: grid;
  gap: 12px;
  grid-template-columns: minmax(0, 1.2fr) minmax(220px, 0.8fr);
}
widget-ns4-ontology-102020 .ns4-entity-head p {
  color: #52606d;
  line-height: 1.45;
  margin-top: 7px;
}
widget-ns4-ontology-102020 .ns4-target-badge {
  border: 1px solid;
  border-radius: 999px;
  display: inline-block;
  font-size: 11px;
  margin-top: 8px;
  padding: 4px 8px;
}
widget-ns4-ontology-102020 .ns4-entity-head dl {
  background: #f8fafc;
  border-radius: 9px;
  display: grid;
  gap: 9px;
  padding: 11px;
}
widget-ns4-ontology-102020 .ns4-entity-head dt {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-ontology-102020 .ns4-entity-head dd {
  font-size: 13px;
  line-height: 1.4;
  margin-top: 2px;
  overflow-wrap: anywhere;
}
widget-ns4-ontology-102020 .ns4-fields,
widget-ns4-ontology-102020 .ns4-direct-edits,
widget-ns4-ontology-102020 .ns4-entity-details article {
  background: #f8fafc;
  border-radius: 9px;
  padding: 11px;
}
widget-ns4-ontology-102020 .ns4-fields h3 {
  margin-bottom: 0;
}
widget-ns4-ontology-102020 .ns4-table-scroll {
  overflow-x: auto;
}
widget-ns4-ontology-102020 table {
  border-collapse: collapse;
  min-width: 760px;
  width: 100%;
}
widget-ns4-ontology-102020 th,
widget-ns4-ontology-102020 td {
  border-bottom: 1px solid #e2e8f0;
  padding: 8px;
  text-align: left;
  vertical-align: top;
}
widget-ns4-ontology-102020 th {
  color: #475569;
  font-size: 12px;
}
widget-ns4-ontology-102020 td small {
  color: #64748b;
  display: block;
  line-height: 1.35;
  margin-top: 3px;
  max-width: 320px;
}
widget-ns4-ontology-102020 td span {
  background: #e0e7ff;
  border-radius: 999px;
  color: #3730a3;
  display: inline-block;
  font-size: 11px;
  margin: 2px;
  padding: 4px 7px;
}
widget-ns4-ontology-102020 td span em {
  color: #64748b;
  font-style: normal;
  margin-left: 3px;
}
widget-ns4-ontology-102020 .ns4-entity-details {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-ontology-102020 .ns4-entity-details h3 {
  font-size: 13px;
  margin-bottom: 6px;
}
widget-ns4-ontology-102020 .ns4-entity-details em {
  color: #64748b;
  font-size: 11px;
}
widget-ns4-ontology-102020 .ns4-direct-edits {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-ontology-102020 .ns4-direct-edits > div,
widget-ns4-ontology-102020 .ns4-direct-edits .wide,
widget-ns4-ontology-102020 .ns4-field-edit {
  grid-column: 1 / -1;
}
widget-ns4-ontology-102020 label {
  display: grid;
  gap: 5px;
}
widget-ns4-ontology-102020 label span {
  color: #475569;
  font-size: 12px;
}
widget-ns4-ontology-102020 .ns4-field-edit {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 8px;
  grid-template-columns: 130px minmax(140px, 0.6fr) minmax(220px, 1.4fr);
  padding-top: 10px;
}
widget-ns4-ontology-102020 .ns4-field-edit code {
  padding-top: 10px;
}
widget-ns4-ontology-102020 .ns4-relationships > div {
  display: grid;
  gap: 9px;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  margin-top: 10px;
}
widget-ns4-ontology-102020 .ns4-relationships article {
  background: #f8fafc;
  border-radius: 9px;
  padding: 11px;
}
widget-ns4-ontology-102020 .ns4-relationships article code {
  display: block;
  margin-top: 3px;
}
widget-ns4-ontology-102020 .ns4-cross-store {
  background: #fef3c7;
  border-radius: 999px;
  color: #92400e;
  display: inline-block;
  font-size: 10px;
  margin-top: 5px;
  padding: 3px 7px;
}
widget-ns4-ontology-102020 .ns4-relationships article p {
  color: #52606d;
  line-height: 1.4;
  margin-top: 6px;
}
widget-ns4-ontology-102020 .ns4-change-panel {
  border-color: #c7d2fe;
  display: grid;
  gap: 11px;
}
widget-ns4-ontology-102020 .ns4-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-ontology-102020 .ns4-actions button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-ontology-102020 .ns4-actions button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-ontology-102020 .ns4-actions .secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-ontology-102020 .ns4-actions .primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
@media (max-width: 820px) {
  widget-ns4-ontology-102020 header,
  widget-ns4-ontology-102020 .ns4-workbench,
  widget-ns4-ontology-102020 .ns4-entity-head {
    display: grid;
    grid-template-columns: 1fr;
  }
  widget-ns4-ontology-102020 .ns4-badges {
    justify-content: flex-start;
  }
  widget-ns4-ontology-102020 nav {
    border-bottom: 1px solid #e2e8f0;
    border-right: 0;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    padding-bottom: 12px;
    padding-right: 0;
  }
  widget-ns4-ontology-102020 nav h3 {
    grid-column: 1 / -1;
  }
  widget-ns4-ontology-102020 .ns4-field-edit,
  widget-ns4-ontology-102020 .ns4-entity-details {
    grid-template-columns: 1fr;
  }
  widget-ns4-ontology-102020 .ns4-field-edit code {
    padding-top: 0;
  }
  widget-ns4-ontology-102020 .ns4-actions {
    display: grid;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.selectedEntityId = '';
        this.activeTab = 'overview';
        this.adjustment = '';
        this.submitting = false;
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return labels.pt;
        if (language.startsWith('es'))
            return labels.es;
        return labels.en;
    }
    selectedEntity() {
        return this.value?.entities.find(item => item.entityId === this.selectedEntityId) || this.value?.entities[0];
    }
    selectEntity(entityId) {
        this.selectedEntityId = entityId;
        this.activeTab = 'overview';
    }
    storageLabel(target, text) {
        if (target === 'mdm')
            return text.targetMdm;
        if (target === 'moduleDatabase')
            return text.targetModuleDatabase;
        if (target === 'derived')
            return text.targetDerived;
        if (target === 'external')
            return text.targetExternal;
        return text.targetEmbedded;
    }
    updateEntity(patch) {
        const selected = this.selectedEntity();
        if (!this.value || !selected || this.readonly)
            return;
        this.value = { ...this.value, entities: this.value.entities.map(entity => entity.entityId === selected.entityId ? { ...entity, ...patch } : entity) };
    }
    updateField(fieldId, patch) {
        const selected = this.selectedEntity();
        if (!selected)
            return;
        this.updateEntity({ fields: selected.fields.map(field => field.fieldId === fieldId ? { ...field, ...patch } : field) });
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            window.alert(this.text().requiredAdjustment);
            return;
        }
        this.submitting = true;
        this.dispatchEvent(new CustomEvent('ns4-ontology-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true,
        }));
    }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const entity = this.selectedEntity();
        return html `
      <section class="ns4-ontology">
        <header>
          <div><h2>${this.value.title}</h2><p>${text.subtitle}</p></div>
          <div class="ns4-badges"><span>${text.mode}</span><span>${text.round} ${this.value.reviewRound}</span></div>
        </header>

        ${this.value.changeSummary.length ? html `
          <section class="ns4-changes"><h3>${text.changes}</h3><ul>${this.value.changeSummary.map(item => html `<li>${item}</li>`)}</ul></section>
        ` : ''}

        ${this.renderPersistenceMap(text)}

        <div class="ns4-workbench">
          <nav aria-label=${text.entities}>
            <h3>${text.entities}</h3>
            ${this.value.entities.map(item => html `<button class=${entity?.entityId === item.entityId ? 'selected' : ''}
              @click=${() => this.selectEntity(item.entityId)}><strong>${item.title}</strong><small>${item.entityId}</small>
              <span class="ns4-nav-target target-${item.storage.target}">${this.storageLabel(item.storage.target, text)}</span></button>`)}
          </nav>
          ${entity ? this.renderEntity(entity, text) : ''}
        </div>

        <section class="ns4-relationships">
          <h3>${text.relationships}</h3>
          <div>${this.value.relationships.map(relationship => {
            const from = this.value?.entities.find(item => item.entityId === relationship.fromEntity);
            const to = this.value?.entities.find(item => item.entityId === relationship.toEntity);
            const crossStore = !!from && !!to && from.storage.target !== to.storage.target;
            return html `<article>
            <strong>${relationship.fromEntity} → ${relationship.toEntity}</strong>
            <code>${relationship.type} · ${relationship.persistence.mode}</code>${crossStore ? html `<span class="ns4-cross-store">${text.crossStore}</span>` : ''}<p>${relationship.description}</p>
          </article>`;
        })}</div>
        </section>

        <section class="ns4-change-panel">
          <div><h3>${text.structural}</h3><p>${text.structuralHint}</p></div>
          <textarea .value=${this.adjustment} placeholder=${text.placeholder} ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}></textarea>
          <div class="ns4-actions">
            <button class="secondary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('requestChanges')}>${text.request}</button>
            <button class="primary" ?disabled=${this.submitting || this.readonly} @click=${() => this.submit('approve')}>${text.approve}</button>
          </div>
        </section>
      </section>`;
    }
    renderPersistenceMap(text) {
        if (!this.value)
            return '';
        return html `<section class="ns4-persistence-map">
      <div class="ns4-section-title"><h3>${text.persistenceMap}</h3><p>${text.persistenceHint}</p></div>
      <div class="ns4-storage-groups">${storageOrder.map(target => {
            const entities = this.value?.entities.filter(entity => entity.storage.target === target) || [];
            return html `<article class="target-${target}">
          <header><strong>${this.storageLabel(target, text)}</strong><span>${entities.length}</span></header>
          <div>${entities.length ? entities.map(entity => html `<button
            class=${this.selectedEntity()?.entityId === entity.entityId ? 'selected' : ''}
            @click=${() => this.selectEntity(entity.entityId)}>${entity.title}<small>${entity.entityId}</small></button>`)
                : html `<small>—</small>`}</div>
        </article>`;
        })}</div>
    </section>`;
    }
    renderEntity(entity, text) {
        return html `<main>
      <section class="ns4-entity-head">
        <div><h3>${entity.title}</h3><code>${entity.entityId} · ${entity.kind} · ${entity.ownership}</code>
          <span class="ns4-target-badge target-${entity.storage.target}">${this.storageLabel(entity.storage.target, text)}</span><p>${entity.description}</p></div>
        <dl><div><dt>${text.source}</dt><dd>${[...entity.sourceRefs.journeyIds, ...entity.sourceRefs.featureIds, ...entity.sourceRefs.authorityRefs].join(', ')}</dd></div>
        <div><dt>${text.storage}</dt><dd><strong>${this.storageLabel(entity.storage.target, text)}</strong> · ${text.scope}: ${entity.storage.scope}</dd></div>
        ${entity.storage.idField ? html `<div><dt>${text.idField}</dt><dd><code>${entity.storage.idField}</code></dd></div>` : ''}
        ${entity.storage.mdmType ? html `<div><dt>${text.mdmType}</dt><dd><code>${entity.storage.mdmType}</code></dd></div>` : ''}
        <div><dt>${text.reason}</dt><dd>${entity.storage.notes}</dd></div></dl>
      </section>
      <div class="ns4-tabs">
        <button class=${this.activeTab === 'overview' ? 'selected' : ''} @click=${() => { this.activeTab = 'overview'; }}>${text.overview}</button>
        <button class=${this.activeTab === 'descriptions' ? 'selected' : ''} @click=${() => { this.activeTab = 'descriptions'; }}>${text.descriptions}</button>
      </div>
      ${this.activeTab === 'overview' ? this.renderOverview(entity, text) : this.renderDirectEdits(entity, text)}
    </main>`;
    }
    renderOverview(entity, text) {
        return html `<section class="ns4-fields"><h3>${text.fields}</h3><p>${text.fieldRulesHint}</p><div class="ns4-table-scroll"><table>
        <thead><tr><th>Id</th><th>${text.fieldTitle}</th><th>Type</th><th>Mode</th><th>${text.constraints}</th></tr></thead>
        <tbody>${entity.fields.map(field => html `<tr><td><code>${field.fieldId}</code></td><td>${field.title}<small>${field.description}</small></td>
          <td><code>${field.type}</code></td><td>${field.required ? text.required : text.optional}</td>
          <td>${field.constraints.map(constraint => html `<span title=${constraint.description}>${constraint.kind}: ${constraint.value} <em>${constraint.source}</em></span>`)}</td></tr>`)}</tbody>
      </table></div></section>
      <section class="ns4-entity-details">
        <article><h3>${text.lifecycle}</h3><p>${entity.lifecycleStates.join(' → ') || '—'}</p></article>
        <article><h3>${text.invariants}</h3><ul>${entity.invariants.map(item => html `<li>${item.description} <em>${item.source}</em></li>`)}</ul></article>
      </section>`;
    }
    renderDirectEdits(entity, text) {
        return html `<section class="ns4-direct-edits"><div><h3>${text.direct}</h3><p>${text.directHint}</p></div>
        <label><span>${text.entityTitle}</span><input .value=${entity.title} ?disabled=${this.readonly}
          @input=${(event) => this.updateEntity({ title: event.target.value })}></label>
        <label class="wide"><span>${text.entityDescription}</span><textarea .value=${entity.description} ?disabled=${this.readonly}
          @input=${(event) => this.updateEntity({ description: event.target.value })}></textarea></label>
        ${entity.fields.map(field => html `<div class="ns4-field-edit"><code>${field.fieldId}</code>
          <label><span>${text.fieldTitle}</span><input .value=${field.title} ?disabled=${this.readonly}
            @input=${(event) => this.updateField(field.fieldId, { title: event.target.value })}></label>
          <label><span>${text.fieldDescription}</span><input .value=${field.description} ?disabled=${this.readonly}
            @input=${(event) => this.updateField(field.fieldId, { description: event.target.value })}></label></div>`)}
      </section>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Ontology102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Ontology102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "selectedEntityId", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "activeTab", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "submitting", void 0);
WidgetNs4Ontology102020 = __decorate([
    customElement('widget-ns4-ontology-102020')
], WidgetNs4Ontology102020);
export { WidgetNs4Ontology102020 };
