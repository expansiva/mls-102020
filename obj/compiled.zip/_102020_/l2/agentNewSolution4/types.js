/// <mls fileReference="_102020_/l2/agentNewSolution4/types.ts" enhancement="_blank"/>
export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES = [
    'Ns4ModuleArtifact',
    'Ns4JourneyArtifact',
    'Ns4JourneyIndex',
    'Ns4AccessMatrixArtifact',
    'Ns4OntologyEntityArtifact',
    'Ns4OntologyIndexArtifact',
    'Ns4RuleArtifact',
    'Ns4RuleIndexArtifact',
];
