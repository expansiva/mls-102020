/// <mls fileReference="_102020_/l2/agentNewSolution4/types.ts" enhancement="_blank"/>
export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES = [
    'Ns4ModuleArtifact',
    'Ns4JourneyArtifact',
    'Ns4JourneyIndex',
    'Ns4AccessMatrixArtifact',
    'Ns4OntologyEntityArtifact',
    'Ns4OntologyIndexArtifact',
    'Ns4RulesArtifact',
    'Ns4CompositionArtifact',
    'Ns4UseCaseArtifact',
    'Ns4UseCaseArtifactV3',
    'Ns4UseCaseIndexArtifact',
    'Ns4UseCaseIndexArtifactV3',
    'Ns4WorkflowArtifact',
    'Ns4WorkflowArtifactV2',
    'Ns4WorkflowIndexArtifact',
    'Ns4WorkflowIndexArtifactV2',
];
