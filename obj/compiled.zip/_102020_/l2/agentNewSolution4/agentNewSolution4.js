/// <mls fileReference="_102020_/l2/agentNewSolution4/agentNewSolution4.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { buildNs4PlannedSteps, createNs4E2Step, createNs4E3Step, createNs4E4Step, isNs4ModuleToken, isNs4Pipeline, markNs4E3Approved, normalizeNs4RootPlan, parseNs4Invocation, resolveNs4ExistingAction, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Core.js';
import { listNs4ModuleFolders, ns4AccessMatrixFile, ns4FileExists, ns4ModuleFile, readNs4AgentText, readNs4Module, readNs4Pipeline, writeNs4Pipeline, } from '/_102020_/l2/agentNewSolution4/helpers/ns4Fs.js';
import { afterNs4E1PromptStep, beforeNs4E1ClarificationStep, beforeNs4E1PromptStep, loadNs4StatusPrompt, } from '/_102020_/l2/agentNewSolution4/steps/e1/agentNs4E1.js';
import { afterNs4E2PromptStep, beforeNs4E2ClarificationStep, beforeNs4E2PromptStep, } from '/_102020_/l2/agentNewSolution4/steps/e2/agentNs4E2.js';
import { afterNs4E3PromptStep, beforeNs4E3ClarificationStep, beforeNs4E3PromptStep, } from '/_102020_/l2/agentNewSolution4/steps/e3/agentNs4E3.js';
import { afterNs4E4PromptStep, beforeNs4E4ClarificationStep, beforeNs4E4PromptStep, } from '/_102020_/l2/agentNewSolution4/steps/e4/agentNs4E4.js';
export function createAgent() {
    return {
        agentName: 'agentNewSolution4',
        agentProject: 102020,
        agentFolder: 'agentNewSolution4',
        agentDescription: 'L4 v4 product compiler — localized roadmap and permanent business contracts',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep,
    };
}
export const NS4_AGENT_BUILD = 'build-11 (2026-08-05) race-safe E3 to E4 artifact handoff and resume reconciliation';
async function beforePromptImplicit(agent, context, userPrompt) {
    const invocation = parseNs4Invocation(userPrompt || '');
    if (!invocation.prompt) {
        return [await statusTask(agent, context, 'Informe o nome ou a descrição do módulo após @@newSolution4.', 'new Solution 4', true)];
    }
    let sourcePrompt = invocation.prompt;
    let resumeModule = '';
    let resumeTarget = '';
    let resumeRound = '';
    let taskTitle = 'new Solution 4';
    if (isNs4ModuleToken(invocation.prompt) && listNs4ModuleFolders().has(invocation.prompt)) {
        let pipeline = await readNs4Pipeline(invocation.prompt);
        if (isNs4Pipeline(pipeline) && pipeline.steps.e3?.status !== 'approved') {
            const moduleArtifact = await readNs4Module(invocation.prompt);
            const approvedE3 = moduleArtifact?.specStatus.completedSteps
                .find(completed => completed.stepId === 'e3-access-matrix' && completed.status === 'approved');
            if (approvedE3 && ns4FileExists(ns4AccessMatrixFile(invocation.prompt))) {
                pipeline = markNs4E3Approved(pipeline, approvedE3.approvedBy, `l4/${invocation.prompt}/access/access-matrix.defs.ts`, approvedE3.approvedAt);
                await writeNs4Pipeline(pipeline);
            }
        }
        const action = resolveNs4ExistingAction(true, pipeline, ns4FileExists(ns4ModuleFile(invocation.prompt)));
        if (action === 'collision') {
            return [await statusTask(agent, context, `Módulo "${invocation.prompt}" já existe, mas não possui pipeline do agentNewSolution4. Nada foi alterado.`, `plan ${invocation.prompt}`, true)];
        }
        if (action === 'resume-next' && pipeline?.steps.e4?.status === 'approved') {
            return [await statusTask(agent, context, `Módulo "${invocation.prompt}": E1 a E4 já estão aprovados. O próximo passo é e5-rules, ainda não implementado.`, `plan ${invocation.prompt}`)];
        }
        resumeModule = invocation.prompt;
        resumeTarget = action === 'resume-e1' ? 'e1' : action === 'resume-e4' ? 'e4' : action === 'resume-e3' ? 'e3' : 'e2';
        resumeRound = resumeTarget === 'e4'
            ? String(Math.max(1, pipeline?.steps.e4?.reviewRound || 1))
            : resumeTarget === 'e3'
                ? String(Math.max(1, pipeline?.steps.e3?.reviewRound || 1))
                : resumeTarget === 'e2' ? String(Math.max(1, pipeline?.steps.e2?.reviewRound || 1)) : '';
        sourcePrompt = pipeline?.sourcePrompt || invocation.prompt;
        taskTitle = `plan ${invocation.prompt}`;
    }
    const planPrompt = await readNs4AgentText('', 'promptPlan');
    return [{
            type: 'add-message-ai',
            request: {
                action: 'addMessageAI',
                agentName: agent.agentName,
                inputAI: [
                    { type: 'system', content: planPrompt },
                    { type: 'human', content: sourcePrompt },
                ],
                taskTitle,
                threadId: context.message.threadId,
                userMessage: context.message.content,
                longTermMemory: {
                    taskName: 'newSolution4',
                    flowName: 'agentNewSolution4',
                    sourcePrompt,
                    ...(invocation.fast ? { fastMode: 'true' } : {}),
                    ...(resumeModule ? { resumeModule } : {}),
                    ...(resumeTarget ? { resumeTarget } : {}),
                    ...(resumeRound ? { resumeRound } : {}),
                },
            },
        }];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = step.planning?.planId || '';
    if (planId === 'e1-clarification' || planId === 'e1-compile') {
        return beforeNs4E1PromptStep(agent, context, parentStep, step, hookSequential, args);
    }
    if (planId.startsWith('e2-journeys-round-')) {
        return beforeNs4E2PromptStep(agent, context, parentStep, step, hookSequential, args);
    }
    if (planId.startsWith('e3-access-matrix-round-')) {
        return beforeNs4E3PromptStep(agent, context, parentStep, step, hookSequential, args);
    }
    if (planId.startsWith('e4-ontology-round-')) {
        return beforeNs4E4PromptStep(agent, context, parentStep, step, hookSequential, args);
    }
    return [rootStatus(context, parentStep, step, hookSequential, 'failed', `Unsupported implemented step: ${planId || '(missing)'}`)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    const planId = step.planning?.planId || '';
    if (planId === 'e1-clarification') {
        return afterNs4E1PromptStep(agent, context, parentStep, step, hookSequential);
    }
    if (planId.startsWith('e2-journeys-round-')) {
        return afterNs4E2PromptStep(agent, context, parentStep, step, hookSequential);
    }
    if (planId.startsWith('e3-access-matrix-round-')) {
        return afterNs4E3PromptStep(agent, context, parentStep, step, hookSequential);
    }
    if (planId.startsWith('e4-ontology-round-')) {
        return afterNs4E4PromptStep(agent, context, parentStep, step, hookSequential);
    }
    if (memoryString(context, 'statusOnly') === 'true') {
        const failed = memoryString(context, 'statusOutcome') === 'error';
        return [rootStatus(context, parentStep, step, hookSequential, failed ? 'failed' : 'completed', 'Status task completed.')];
    }
    try {
        const plan = getNs4RootPlan(context, step);
        if (!plan.validPrompt) {
            return [rootStatus(context, parentStep, step, hookSequential, 'failed', plan.invalidReason || 'Invalid or insufficient business prompt.')];
        }
        const resumeModule = memoryString(context, 'resumeModule');
        const resumeTarget = memoryString(context, 'resumeTarget');
        const planned = resumeModule && (resumeTarget === 'e2' || resumeTarget === 'e3' || resumeTarget === 'e4')
            ? buildNs4ResumeSteps(plan, resumeModule, resumeTarget, normalizeResumeRound(memoryString(context, 'resumeRound')))
            : buildNs4PlannedSteps(plan);
        return planned.map(plannedStep => ({
            type: 'add-step',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: step.stepId,
            step: plannedStep,
        }));
    }
    catch (error) {
        return [rootStatus(context, parentStep, step, hookSequential, 'failed', errorMessage(error))];
    }
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const parsed = parseHookJson(json);
    if (parsed?.planId === 'e2-review') {
        return beforeNs4E2ClarificationStep(agent, context, parentStep, step, hookSequential, parsed);
    }
    if (parsed?.planId === 'e3-access-review') {
        return beforeNs4E3ClarificationStep(agent, context, parentStep, step, hookSequential, parsed);
    }
    if (parsed?.planId === 'e4-ontology-review') {
        return beforeNs4E4ClarificationStep(agent, context, parentStep, step, hookSequential, parsed);
    }
    return beforeNs4E1ClarificationStep(agent, context, parentStep, step, hookSequential, json);
}
export function getNs4RootPlan(context, rootHint) {
    const root = rootHint || context.task?.iaCompressed?.nextSteps?.[0];
    return normalizeNs4RootPlan(root?.interaction?.payload?.[0], memoryString(context, 'sourcePrompt'));
}
function buildNs4ResumeSteps(plan, moduleName, target, reviewRound) {
    const all = buildNs4PlannedSteps(plan);
    if (target === 'e4') {
        return [
            createNs4E4Step(moduleName, reviewRound, '', [], plan.presentation.stepTitles['e4-ontology']),
            ...all.slice(5),
        ];
    }
    if (target === 'e3') {
        return [
            createNs4E3Step(moduleName, reviewRound, '', [], plan.presentation.stepTitles['e3-access-matrix']),
            ...all.slice(4),
        ];
    }
    return [
        createNs4E2Step(moduleName, reviewRound, '', [], plan.presentation.stepTitles['e2-journeys']),
        ...all.slice(3),
    ];
}
function normalizeResumeRound(value) {
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed > 0 ? parsed : 1;
}
function rootStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status', hookSequential, messageId: context.message.orderAt,
        threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
        stepId: step.stepId, status, traceMsg,
    };
}
function parseHookJson(value) {
    if (value && typeof value === 'object' && !Array.isArray(value))
        return value;
    if (typeof value !== 'string')
        return null;
    try {
        const parsed = JSON.parse(value);
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
    }
    catch {
        return null;
    }
}
async function statusTask(agent, context, message, taskTitle = 'new Solution 4', isError = false) {
    return {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: await loadNs4StatusPrompt(message) },
                { type: 'human', content: message },
            ],
            taskTitle,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'newSolution4', flowName: 'agentNewSolution4', statusOnly: 'true',
                statusOutcome: isError ? 'error' : 'info',
            },
        },
    };
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
