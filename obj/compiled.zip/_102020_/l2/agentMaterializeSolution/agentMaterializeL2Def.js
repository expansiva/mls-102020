/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeL2Def.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { toMlsPath, getFileContent, createDefsFile, listDepLayerPaths, extractToolCallArgs, extractJsonArrayField, loadModuleByBuild, readProjectJson, } from '/_102027_/l2/agentMaterializeSolution/artifactsMaterialize.js';
export function createAgent() {
    return {
        agentName: 'agentMaterializeL2Def',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Create L2 sub-files and L1 controller .defs.ts from a L2 page definition',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
const TOOL_NAME = 'submitL2Files';
const toolSchema = {
    type: 'function',
    function: {
        name: TOOL_NAME,
        description: 'Submit the definitions (extracted from source) and controller dependsFiles for the 4 derived files.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['controllerDefinition', 'contractDefinition', 'sharedDefinition', 'pageDefinition', 'controllerDependsFiles'],
            properties: {
                controllerDefinition: {
                    type: 'object',
                    description: 'Original bffCommands data from the source — copied verbatim, not summarized',
                },
                contractDefinition: {
                    type: 'object',
                    description: 'Original bffCommands contract/interface data — copied verbatim',
                },
                sharedDefinition: {
                    type: 'object',
                    description: 'Original bffCommands + navigationRefs data — copied verbatim',
                },
                pageDefinition: {
                    type: 'object',
                    description: 'UI layout tree derived from pageDefinition sections+organisms and bffCommands. Must contain: pageId, pageName, actor, purpose, capabilities (copied verbatim) plus a "layout" key with a JSON tree of concrete UI elements (sections → children of tables/forms/lists with labels and field names in Portuguese)',
                },
                controllerDependsFiles: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'layer_3_usecases .ts paths (not .defs.ts) that this controller calls — extracted from usecaseRefs in bffCommands',
                },
            },
        },
    },
};
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(_agent, context, parentStep, _step, hookSequential, args) {
    if (!args)
        throw new Error('[agentMaterializeL2Def] missing args');
    const { moduleName, shortName } = JSON.parse(args);
    const project = mls.actualProject || 0;
    const content = await getFileContent(project, 2, moduleName, shortName, '.defs.ts');
    if (!content)
        throw new Error(`[agentMaterializeL2Def] not found: l2/${moduleName}/${shortName}.defs.ts`);
    // Already processed — derived controller .defs.ts exists with pipeline
    const controllerContent = await getFileContent(project, 1, `${moduleName}/layer_2_controllers`, shortName, '.defs.ts');
    if (controllerContent?.includes('export const pipeline')) {
        return [mkStatus(context, parentStep, _step, hookSequential, 'completed', 'already present')];
    }
    // Available layer_3_usecases as .ts paths (LLM picks which ones the controller uses)
    const usecaseDefsPaths = listDepLayerPaths(project, moduleName, 'layer_3_usecases');
    const usecaseTsPaths = usecaseDefsPaths.map(p => p.replace(/\.defs\.ts$/, '.ts'));
    const intent = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(project, moduleName, shortName),
        humanPrompt: buildHumanPrompt(toMlsPath(project, 2, moduleName, shortName, '.defs.ts'), content, usecaseTsPaths),
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: TOOL_NAME } },
    };
    return [intent];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const { moduleName, shortName } = JSON.parse(step.prompt || '{}');
    const project = mls.actualProject || 0;
    const raw = step.interaction?.payload?.[0];
    const out = extractToolCallArgs(raw, TOOL_NAME);
    if (!out) {
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', 'missing tool output')];
    }
    // ── Deterministic output paths ──────────────────────────────────────────────
    const base = `_${project}_`;
    const controllerOutputPath = `${base}/l1/${moduleName}/layer_2_controllers/${shortName}.ts`;
    const contractOutputPath = `${base}/l2/${moduleName}/web/contracts/${shortName}.ts`;
    const sharedOutputPath = `${base}/l2/${moduleName}/web/shared/${shortName}.ts`;
    const pageOutputPath = `${base}/l2/${moduleName}/web/desktop/page11/${shortName}.ts`;
    // ── Deterministic dependsFiles per file ─────────────────────────────────────
    const pageDefsPath = `${base}/l2/${moduleName}/web/desktop/page11/${shortName}.defs.ts`;
    const contractDependsFiles = [];
    const sharedDependsFiles = [contractOutputPath, pageDefsPath];
    const pageDependsFiles = [sharedOutputPath, contractOutputPath];
    // ── Load module.ts and projectJson for skills ────────────────────────────────
    const moduleTs = await loadModuleByBuild(toMlsPath(project, 2, moduleName, 'module', '.ts'));
    const projectJson = await readProjectJson();
    const controllerSkills = await loadModuleSkills(project, moduleName, 'layer2');
    const contractSkills = moduleTs?.skills?.contract?.skillPath ?? [];
    const sharedSkill = moduleTs?.shared?.web?.sharedSkill;
    const sharedSkills = sharedSkill ? [sharedSkill] : [];
    const genome = moduleTs?.moduleGenome?.['web/desktop/page11'];
    const pageSkills = [];
    if (genome?.layout && projectJson) {
        const entry = Object.values(projectJson.layouts ?? {}).find((l) => l.name === genome.layout);
        if (entry?.skill)
            pageSkills.push(entry.skill);
    }
    if (genome?.designSystem && projectJson) {
        const entry = Object.values(projectJson.designSystems ?? {}).find((d) => d.name === genome.designSystem);
        if (entry?.skill)
            pageSkills.push(entry.skill);
    }
    const pageVisualStyle = projectJson?.modules.find(m => m.moduleName === moduleName)?.module?.visualStyle;
    const errors = [];
    // 1. L1 controller
    const controllerRules = extractJsonArrayField(JSON.stringify(out.controllerDefinition), 'rulesApplied');
    const controllerUsecaseRefs = extractJsonArrayField(JSON.stringify(out.controllerDefinition), 'usecaseRefs');
    const controllerDependsFiles = [
        ...controllerUsecaseRefs.map(ref => toMlsPath(project, 1, `${moduleName}/layer_3_usecases`, ref, '.d.ts')),
        contractOutputPath,
    ];
    const controllerRulesPath = controllerRules.length > 0 ? toMlsPath(project, 5, moduleName, 'rules', '.defs.ts') : undefined;
    const ok1 = await createDefsFile(project, 1, `${moduleName}/layer_2_controllers`, shortName, out.controllerDefinition, [mkItem(`${shortName}__layer_2_controllers`, 'layer_2_controllers', controllerOutputPath, project, 1, `${moduleName}/layer_2_controllers`, shortName, controllerDependsFiles, [], controllerRules, {
            skills: controllerSkills,
            afterSaveBackEnd: '_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController',
            rulesPath: controllerRulesPath,
        })]);
    if (!ok1)
        errors.push('controller');
    // 2. L2 contract
    const ok2 = await createDefsFile(project, 2, `${moduleName}/web/contracts`, shortName, out.contractDefinition, [mkItem(`${shortName}__l2_contract`, 'l2_contract', contractOutputPath, project, 2, `${moduleName}/web/contracts`, shortName, contractDependsFiles, [], undefined, { skills: contractSkills })]);
    if (!ok2)
        errors.push('contract');
    // 3. L2 shared
    const sharedRules = extractJsonArrayField(JSON.stringify(out.sharedDefinition), 'rulesApplied');
    const sharedRulesPath = sharedRules.length > 0 ? toMlsPath(project, 5, moduleName, 'rules', '.defs.ts') : undefined;
    const ok3 = await createDefsFile(project, 2, `${moduleName}/web/shared`, shortName, out.sharedDefinition, [mkItem(`${shortName}__l2_shared`, 'l2_shared', sharedOutputPath, project, 2, `${moduleName}/web/shared`, shortName, sharedDependsFiles, [], sharedRules, { skills: sharedSkills, rulesPath: sharedRulesPath })]);
    if (!ok3)
        errors.push('shared');
    // 4. L2 page — path: l2/{module}/web/desktop/page11/{shortName}.defs.ts
    const ok4 = await createDefsFile(project, 2, `${moduleName}/web/desktop/page11`, shortName, out.pageDefinition, [mkItem(`${shortName}__l2_page`, 'l2_page', pageOutputPath, project, 2, `${moduleName}/web/desktop/page11`, shortName, pageDependsFiles, [], undefined, {
            skills: pageSkills,
            afterSaveFrontEnd: '_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage',
            visualStyle: pageVisualStyle,
        })]);
    if (!ok4)
        errors.push('page');
    const failed = errors.length > 0;
    return [mkStatus(context, parentStep, step, hookSequential, failed ? 'failed' : 'completed', failed ? `failed to create: ${errors.join(', ')}` : undefined)];
}
// ─── Helpers ──────────────────────────────────────────────────────────────────
const NEEDS_DEFINITION = new Set(['layer2']);
async function loadModuleSkills(project, moduleName, skillKey) {
    const path = toMlsPath(project, 2, moduleName, 'module', '.ts');
    const mod = await loadModuleByBuild(path);
    if (!mod)
        return [];
    const base = mod.skills?.[skillKey]?.skillPath ?? [];
    if (NEEDS_DEFINITION.has(skillKey)) {
        const defPaths = (mod.skills?.definition?.skillPath ?? []).map((p) => /^_\d+_$/.test(p) ? `${p}.d.ts` : p);
        return [...base, ...defPaths];
    }
    return base;
}
function mkItem(id, type, outputPath, project, level, folder, shortName, dependsFiles, dependsOn, rulesApplied, opts) {
    return {
        id,
        type,
        outputPath,
        defPath: toMlsPath(project, level, folder, shortName, '.defs.ts'),
        dependsFiles,
        dependsOn,
        skills: opts?.skills ?? [],
        ...(opts?.afterSaveBackEnd ? { afterSaveBackEnd: opts.afterSaveBackEnd } : {}),
        ...(opts?.afterSaveFrontEnd ? { afterSaveFrontEnd: opts.afterSaveFrontEnd } : {}),
        ...(opts?.visualStyle ? { visualStyle: opts.visualStyle } : {}),
        ...(opts?.rulesPath ? { rulesPath: opts.rulesPath } : {}),
        ...(rulesApplied && rulesApplied.length > 0 ? { rulesApplied } : {}),
        agent: 'agentMaterializeGen',
    };
}
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner: status === 'completed' ? 'input_output' : undefined,
    };
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
function buildSystemPrompt(project, moduleName, shortName) {
    return `<!-- modelType: codeinstruct2 -->

You extract and organize data from a L2 page .defs.ts to produce definitions for 4 derived files.

IMPORTANT: Copy data verbatim from the source — do NOT summarize or invent content.

Files to produce:
1. controllerDefinition — L1 BFF controller (_${project}_/l1/${moduleName}/layer_2_controllers/${shortName}.defs.ts)
   Content: the bffCommands array from the source, copied verbatim

2. contractDefinition — L2 BFF contract (_${project}_/l2/${moduleName}/web/contracts/${shortName}.defs.ts)
   Content: the bffCommands from the source (contract/interface aspect), copied verbatim

3. sharedDefinition — L2 shared (_${project}_/l2/${moduleName}/web/shared/${shortName}.defs.ts)
   Content: ALL bffCommands + navigationRefs from the source, copied verbatim

4. pageDefinition — L2 page (_${project}_/l2/${moduleName}/web/desktop/page11/${shortName}.defs.ts)
   Content: a UI layout definition derived from the source. DO NOT copy sections/organisms verbatim.
   Build a JSON object with:
   - pageId, pageName, actor, purpose, capabilities — copied verbatim from pageDefinition
   - layout: a JSON tree that describes the actual UI structure, as follows:
     - Each section becomes a node with "title" and "children" array
     - Each organism in that section becomes one or more concrete UI elements in "children":
       * Organisms whose userActions contain "filtrar", "listar", "exibir" → { type:"table", title:"<purpose>", columns:[<output field names from the matching bffCommand>] }
       * Organisms whose userActions contain "criar", "editar", "atualizar", "cadastrar", "registrar" → { type:"form", title:"<purpose>", fields:[<input field names from the matching bffCommand>], submitLabel:"<action label in Portuguese>" }
       * Organisms that combine filter+list → two children: a filter object { type:"filter", fields:[...] } and a table
       * Alert/history organisms → { type:"table", title:"<purpose>", columns:[<output field names>] }
     - Match each organism to its bffCommand via the command whose usecaseRefs overlap with the organism's userActions
     - All labels and text in Portuguese
   Example structure:
   { "pageId":"...", "pageName":"...", "actor":"...", "purpose":"...", "capabilities":[...],
     "layout": { "sections": [
       { "title":"Gestão de cardápio", "children": [
         { "type":"filter", "fields":["categoriaId","disponivel"] },
         { "type":"table", "title":"Itens do cardápio", "columns":["menuItemId","nome","preco","categoriaId","ativo"] },
         { "type":"form", "title":"Cadastro/edição de item", "fields":["nome","preco","categoriaId","ativo"], "submitLabel":"Salvar item" }
       ]}
     ]}
   }

Additionally provide:
- controllerDependsFiles: the layer_3_usecases .ts paths (not .defs.ts) that this controller calls
  Look at usecaseRefs inside each bffCommand and find the matching path from the available list

Call ${TOOL_NAME} with the result.`;
}
function buildHumanPrompt(pageDefPath, content, usecaseTsPaths) {
    return [
        `## Source page definition`,
        `Path: ${pageDefPath}`,
        ``,
        `## Content`,
        '```typescript',
        content,
        '```',
        ``,
        `## Available layer_3_usecases .ts files`,
        usecaseTsPaths.length ? usecaseTsPaths.join('\n') : '(none)',
        ``,
        `Extract controllerDefinition, contractDefinition, sharedDefinition verbatim from the source content.`,
        `For pageDefinition: derive the UI layout tree as instructed in the system prompt (do NOT copy sections/organisms verbatim).`,
        `For controllerDependsFiles: look at usecaseRefs in each bffCommand and match to the available list above.`,
    ].join('\n');
}
