/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeL1.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { toMlsPath, getFileContent, appendPipelineToFile, listDepLayerPaths, extractToolCallArgs, } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentMaterializeL1',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Add export const pipeline to an existing L1 .defs.ts file',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
const TOOL_NAME = 'submitL1Pipeline';
const toolSchema = {
    type: 'function',
    function: {
        name: TOOL_NAME,
        description: 'Submit the pipeline item for this L1 .defs.ts file.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['outputPath', 'dependsFiles'],
            properties: {
                outputPath: {
                    type: 'string',
                    description: 'MLS path of the .ts file to be generated, e.g. _102043_/l1/cafeFlow/layer_4_entities/PedidoEntity.ts',
                },
                dependsFiles: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'MLS .ts paths (already-generated) that the executor needs as context',
                },
            },
        },
    },
};
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error('[agentMaterializeL1] missing args');
    const { moduleName, shortName, layerFolder } = JSON.parse(args);
    const project = mls.actualProject || 0;
    const folder = `${moduleName}/${layerFolder}`;
    const content = await getFileContent(project, 1, folder, shortName, '.defs.ts');
    if (!content)
        throw new Error(`[agentMaterializeL1] file not found: ${folder}/${shortName}.defs.ts`);
    // Already processed — skip
    if (content.includes('export const pipeline')) {
        return [mkDone(context, parentStep, step, hookSequential, 'completed', 'already present')];
    }
    // layer_1_external has no deps — deterministic, no LLM needed
    if (layerFolder === 'layer_1_external') {
        const item = buildItem(shortName, layerFolder, toMlsPath(project, 1, folder, shortName, '.ts'), project, 1, folder, [], []);
        const ok = await appendPipelineToFile(project, 1, folder, shortName, [item]);
        return [mkDone(context, parentStep, step, hookSequential, ok ? 'completed' : 'failed', ok ? undefined : 'append failed')];
    }
    // layer_4_entities → needs layer_1_external .ts files
    // layer_3_usecases → needs layer_4_entities .ts files
    // layer_2_controllers (if ever here) → needs layer_3_usecases .ts files
    const depDefsPaths = listDepLayerPaths(project, moduleName, layerFolder);
    const depTsPaths = depDefsPaths.map(defsToTs);
    const intent = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(layerFolder, depTsPaths),
        humanPrompt: buildHumanPrompt(toMlsPath(project, 1, folder, shortName, '.defs.ts'), layerFolder, content, depTsPaths),
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: TOOL_NAME } },
    };
    return [intent];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const { moduleName, shortName, layerFolder } = JSON.parse(step.prompt || '{}');
    const project = mls.actualProject || 0;
    const folder = `${moduleName}/${layerFolder}`;
    const raw = step.interaction?.payload?.[0];
    const out = extractToolCallArgs(raw, TOOL_NAME);
    if (!out?.outputPath) {
        return [mkDone(context, parentStep, step, hookSequential, 'failed', 'missing tool output')];
    }
    const item = buildItem(shortName, layerFolder, out.outputPath, project, 1, folder, out.dependsFiles || [], []);
    const ok = await appendPipelineToFile(project, 1, folder, shortName, [item]);
    return [mkDone(context, parentStep, step, hookSequential, ok ? 'completed' : 'failed', ok ? undefined : 'append failed', ok ? 'input_output' : undefined)];
}
// ─── Helpers ──────────────────────────────────────────────────────────────────
function buildItem(shortName, layerFolder, outputPath, project, level, folder, dependsFiles, dependsOn) {
    return {
        id: `${shortName}__${layerFolder}`,
        type: layerFolder,
        outputPath,
        defPath: toMlsPath(project, level, folder, shortName, '.defs.ts'),
        dependsFiles,
        dependsOn,
        agent: 'agentMaterializeDef',
    };
}
function mkDone(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
/** _102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs.ts → .ts */
function defsToTs(mlsPath) {
    return mlsPath.replace(/\.defs\.ts$/, '.ts');
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
function buildSystemPrompt(layerFolder, depTsPaths) {
    const depLabel = {
        layer_4_entities: 'layer_1_external (physical table .ts files)',
        layer_3_usecases: 'layer_4_entities (entity .ts files)',
        layer_2_controllers: 'layer_3_usecases (usecase .ts files)',
    };
    return `<!-- modelType: codeinstruct -->

You analyze a ${layerFolder} .defs.ts planning artifact and determine its pipeline item.

Path format: _<project>_/l<level>/<folder>/<FileName><ext>

You must provide:
- outputPath: the .ts file to be generated (derive from materialization/className metadata in the content)
- dependsFiles: .ts files from ${depLabel[layerFolder] || 'dependency layer'} that the executor needs as context
  - Only include files this artifact actually references or uses
  - Use the .ts output path, not .defs.ts

Available dependency .ts files:
${depTsPaths.length ? depTsPaths.map(p => `  ${p}`).join('\n') : '  (none)'}

dependsOn is always [].

Call ${TOOL_NAME} with the result.`;
}
function buildHumanPrompt(defPath, layerFolder, content, depTsPaths) {
    return [
        `## File to process`,
        `Path: ${defPath}`,
        `Layer: ${layerFolder}`,
        ``,
        `## Content`,
        '```typescript',
        content,
        '```',
        ``,
        `## Available dependency .ts files`,
        depTsPaths.length ? depTsPaths.join('\n') : '(none)',
        ``,
        `Determine outputPath (from materialization metadata in the file) and which dependsFiles this artifact needs.`,
    ].join('\n');
}
