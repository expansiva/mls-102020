/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeGen.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { collabImport } from '/_102027_/l2/collabImport.js';
import { getContentByMlsPath, parseDefinitionFromContent, parseMlsPath, saveGeneratedTs, extractToolCallArgs, loadModuleByBuild, } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentMaterializeGen',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Generate a .ts file from a .defs.ts pipeline item using the resolved skill',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
const TOOL_NAME = 'submitGeneratedTs';
const toolSchema = {
    type: 'function',
    function: {
        name: TOOL_NAME,
        description: 'Submit the complete generated TypeScript file content.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['code'],
            properties: {
                code: {
                    type: 'string',
                    description: 'Complete TypeScript file content. Must start with the /// <mls fileReference="..."> header comment.',
                },
            },
        },
    },
};
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(_agent, context, parentStep, _step, hookSequential, args) {
    if (!args)
        throw new Error('[agentMaterializeGen] missing args');
    const { defPath, pipelineItem, skillPaths } = JSON.parse(args);
    // Read .defs.ts and extract definition
    const defsContent = await getContentByMlsPath(defPath);
    if (!defsContent)
        throw new Error(`[agentMaterializeGen] .defs.ts not found: ${defPath}`);
    const definition = parseDefinitionFromContent(defsContent);
    // Load skill content — .ts files export a `skill` string; .md files are read raw
    const skillSections = [];
    for (const sp of skillPaths) {
        const content = await loadSkillContent(sp);
        if (content)
            skillSections.push(`<!-- skill: ${sp} -->\n${content}`);
    }
    // Load dependsFiles as context
    const depSections = [];
    for (const dep of pipelineItem.dependsFiles) {
        const content = await getContentByMlsPath(dep);
        if (content)
            depSections.push(`### ${dep}\n\`\`\`typescript\n${content}\n\`\`\``);
    }
    const intent = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(skillSections, pipelineItem.outputPath),
        humanPrompt: buildHumanPrompt(definition, depSections, pipelineItem.outputPath),
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: TOOL_NAME } },
    };
    return [intent];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const { pipelineItem } = JSON.parse(step.prompt || '{}');
    const raw = step.interaction?.payload?.[0];
    const out = extractToolCallArgs(raw, TOOL_NAME);
    if (!out?.code) {
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', 'missing generated code')];
    }
    const parsed = parseMlsPath(pipelineItem.outputPath);
    if (!parsed) {
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', `invalid outputPath: ${pipelineItem.outputPath}`)];
    }
    // Ensure fileReference header is present
    const header = `/// <mls fileReference="${pipelineItem.outputPath}" enhancement="_blank"/>`;
    const code = out.code.trimStart().startsWith('///')
        ? out.code
        : `${header}\n\n${out.code}`;
    const ok = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, code);
    return [mkStatus(context, parentStep, step, hookSequential, ok ? 'completed' : 'failed', ok ? undefined : 'saveGeneratedTs failed', ok ? 'input_output' : undefined)];
}
// ─── Skill loader ─────────────────────────────────────────────────────────────
async function loadSkillContent(skillPath) {
    const clean = skillPath.startsWith('/') ? skillPath.slice(1) : skillPath;
    if (clean.endsWith('.md')) {
        return await getContentByMlsPath(clean) ?? '';
    }
    // .ts skill: try collabImport → read .skill export
    const f = mls.stor.convertFileReferenceToFile(clean);
    if (!f)
        return '';
    let mod;
    try {
        mod = await collabImport(f);
    }
    catch {
        mod = await loadModuleByBuild(clean);
    }
    if (typeof mod?.skill === 'string')
        return mod.skill;
    // Last resort: raw file content
    return await getContentByMlsPath(clean) ?? '';
}
// ─── Helpers ──────────────────────────────────────────────────────────────────
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
function buildSystemPrompt(skillSections, outputPath) {
    const skills = skillSections.length
        ? skillSections.join('\n\n---\n\n')
        : '<!-- no skill loaded -->';
    return `<!-- modelType: codeinstruct -->

You generate a TypeScript file based on a definition and context files.

Target file: ${outputPath}

The file must start with:
/// <mls fileReference="${outputPath}" enhancement="_blank"/>

Follow the instructions in the skill(s) below exactly.
Use the context files (dependsFiles) as reference for types, imports and logic.

---

${skills}`;
}
function buildHumanPrompt(definition, depSections, outputPath) {
    const lines = ['## Definition', '', definition];
    if (depSections.length) {
        lines.push('', '## Context Files', '');
        lines.push(...depSections);
    }
    lines.push('', `Generate the file \`${outputPath}\` and call ${TOOL_NAME} with the complete code.`);
    return lines.join('\n');
}
