/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeL2.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
export function createAgent() {
    return {
        agentName: 'agentMaterializeL2',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Scan mat1 defs, detect outdated/missing .ts outputs and dispatch agentMaterializeDef',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
// ─── project.json ─────────────────────────────────────────────────────────────
async function readProjectModules(project) {
    const ref = `_${project}_/l5/project.json`;
    const info = mls.stor.convertFileReferenceToFile(ref);
    const key = mls.stor.getKeyToFile(info);
    const sf = mls.stor.files[key];
    if (!sf)
        throw new Error(`[agentMaterializeL2] project.json not found: ${ref}`);
    const content = await sf.getContent();
    const config = JSON.parse(typeof content === 'string' ? content : JSON.stringify(content));
    return (config.modules ?? []).map(m => m.moduleName);
}
// ─── detection ────────────────────────────────────────────────────────────────
function findTasksNeedingMaterialization(moduleNames, project) {
    const files = mls.stor.files;
    const tasks = [];
    for (const moduleName of moduleNames) {
        for (const key of Object.keys(files)) {
            const file = files[key];
            if (file.project !== project || file.extension !== '.defs.ts')
                continue;
            let type = null;
            let outputLevel = 2;
            let outputFolder = '';
            // L1 contract defs: _P_/l1/${module}/layer_2_controllers/${pageId}.defs.ts
            if (file.level === 1 && file.folder === `${moduleName}/layer_2_controllers`) {
                type = 'contract';
                outputFolder = `${moduleName}/web/contracts`;
            }
            // L2 shared defs: _P_/l2/${module}/web/shared/${pageId}.defs.ts
            else if (file.level === 2 && file.folder === `${moduleName}/web/shared`) {
                type = 'shared';
                outputFolder = file.folder;
            }
            // L2 device defs: _P_/l2/${module}/web/${device}/${deviceType}/.../${pageId}.defs.ts
            else if (file.level === 2 && file.folder.startsWith(`${moduleName}/web/`)) {
                type = 'page';
                outputFolder = file.folder;
            }
            if (!type)
                continue;
            const defsPath = `_${project}_/l${file.level}/${file.folder}/${file.shortName}${file.extension}`;
            const defsUpdatedAt = file.updatedAt ?? 0;
            const tsKey = mls.stor.getKeyToFile({
                project, level: outputLevel, folder: outputFolder,
                shortName: file.shortName, extension: '.ts',
            });
            const tsFile = mls.stor.files[tsKey];
            if (!tsFile || defsUpdatedAt > (tsFile.updatedAt ?? 0)) {
                tasks.push({ defsPath, moduleName, type });
            }
        }
    }
    return tasks;
}
// ─── beforePromptImplicit ─────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: JSON.stringify({ project, totalTasks: tasks.length }) },
            ],
            taskTitle: `materialize-l2:project-${project}`,
            threadId: context.message.threadId,
            userMessage: userPrompt || `@@${agent.agentName} project:${project}`,
        },
    };
    return [addMessageAI];
}
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(agent, context, parentStep, _step, hookSequential, args) {
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const promptReady = {
        type: 'prompt_ready',
        args: args || '',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: JSON.stringify({ project, totalTasks: tasks.length }),
        systemPrompt,
    };
    return [promptReady];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName})[afterPromptStep] invalid params`);
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status: 'completed',
    };
    if (tasks.length === 0)
        return [updateStatus];
    const newSteps = tasks.map(task => {
        const pageId = task.defsPath.split('/').pop()?.replace(/\.defs\.ts$/, '') ?? '';
        return {
            type: 'add-step',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: parentStep.stepId,
            stepTitle: `${task.type}:${pageId}`,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: 'agentMaterializeDef',
                prompt: JSON.stringify({ pathDefs: task.defsPath, moduleName: task.moduleName, type: task.type }),
                rags: [],
            },
        };
    });
    return [...newSteps, updateStatus];
}
// ─── system prompt ────────────────────────────────────────────────────────────
const systemPrompt = `
<!-- modelType: nano -->

Echo back the summary.

## Output format
Return ONLY valid JSON, no markdown fences, no prose.

{
  "type": "flexible",
  "result": {
    "project": <echo project>,
    "totalTasks": <echo totalTasks>
  }
}
`;
//#endregion
