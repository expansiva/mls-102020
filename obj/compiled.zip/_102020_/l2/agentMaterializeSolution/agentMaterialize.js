/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterialize.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { getMaterializeOrchestrator } from '/_102020_/l2/agentMaterializeSolution/materializeOrchestrator.js';
import { findPreviousAgentStep } from '/_102027_/l2/aiAgentHelper.js';
export function createAgent() {
    return {
        agentName: "agentMaterialize",
        agentProject: 102020,
        agentFolder: "agentMaterializeSolution",
        agentDescription: "new agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const paths = [];
    const inputs = [{ type: "system", content: system1 }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: '',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const orch = getMaterializeOrchestrator(args);
    const itens = await orch.process('init');
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: JSON.stringify({ path: args, itens }),
        systemPrompt: system1 // tem q remover se for paralelo
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (step.status === 'waiting_after_prompt_with_error') {
        console.info('[' + agent.agentName + '] Chegou com erro:', step);
        return [];
    }
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output, agent, parentStep);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output, agent, parentStep) {
    let module = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!module)
        throw new Error('Not found moduleName:' + agent.agentName);
    const orch = getMaterializeOrchestrator(output.path);
    const group = orch.groupByAgent(output.itens);
    const stepOri = context.task ? (findPreviousAgentStep(context.task, parentStep.stepId))?.stepId : parentStep.stepId;
    const newSteps = [];
    Object.keys(group).forEach((g) => {
        const info = group[g];
        info.forEach((i) => {
            const newStep = {
                type: "add-step",
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: stepOri || parentStep.stepId,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    status: 'waiting_human_input',
                    nextSteps: [],
                    agentName: g,
                    prompt: JSON.stringify({ path: output.path, item: i }),
                    rags: [],
                    onFailure: 'wait_after_prompt'
                }
            };
            newSteps.push(newStep);
        });
    });
    return newSteps;
}
async function reExecute(context, output, agent, parentStep) {
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: agent.agentName,
            prompt: JSON.stringify({ path: output.path, item: '' }),
            rags: [],
            onFailure: 'wait_after_prompt'
        }
    };
    return [newStep];
}
const system1 = `
<!-- modelType: codeinstruct-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

Return same content


## Output format
You must return the object strictly as JSON
export type Output =
  {
    type: "flexible";
    result: OutputParse;
  }

export type OutputParse = {
  path: string // path pass by human
  itens: any // same content
}

`;
//#endregion 
