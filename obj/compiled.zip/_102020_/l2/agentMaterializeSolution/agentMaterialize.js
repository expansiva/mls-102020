/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterialize.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readProjectJson, scanL1DefsFiles, scanL2PageDefsFiles, } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
export function createAgent() {
    return {
        agentName: 'agentMaterialize',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Add pipeline exports to L1 .defs.ts and create L2 sub-files for all modules',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
// ─── Bootstrap ────────────────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, _userPrompt) {
    const project = mls.actualProject || 0;
    const projectJson = await readProjectJson();
    if (!projectJson?.modules?.length) {
        throw new Error(`[agentMaterialize] l5/project.json not found or empty in project ${project}`);
    }
    const summaries = projectJson.modules.map(mod => {
        const l1 = scanL1DefsFiles(project, mod.moduleName);
        const l2 = scanL2PageDefsFiles(project, mod.moduleName);
        return {
            moduleName: mod.moduleName,
            l1Count: l1.length,
            l1Files: l1.map(f => `${f.folder.split('/').pop()}/${f.shortName}`),
            l2Count: l2.length,
            l2Files: l2.map(f => f.shortName),
        };
    });
    for (const moduleName of projectJson.modules.map(m => m.moduleName)) {
        await ensureSingletons(project, moduleName);
    }
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: buildHumanPrompt(summaries) },
            ],
            taskTitle: 'materialize',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'materialize', flowName: 'materialize' },
        },
    };
    return [addMessageAI];
}
// ─── After LLM confirms — create all child steps ──────────────────────────────
async function afterPromptStep(_agent, context, _parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('[agentMaterialize] missing payload');
        if (payload.type === 'result') {
            return [mkFail(context, _parentStep, step, hookSequential, String(payload.result))];
        }
        if (payload.type !== 'flexible' || payload.result?.status === 'failed') {
            const msg = payload.result?.notes?.join('; ') || 'bootstrap failed';
            return [mkFail(context, _parentStep, step, hookSequential, msg)];
        }
        const project = mls.actualProject || 0;
        const projectJson = await readProjectJson();
        if (!projectJson)
            throw new Error('[agentMaterialize] project.json unavailable');
        const intents = [];
        for (const mod of projectJson.modules) {
            const { moduleName } = mod;
            // One step per L1 .defs.ts file (add pipeline)
            for (const file of scanL1DefsFiles(project, moduleName)) {
                const layerFolder = file.folder.split('/').pop() || '';
                const planId = `mat-l1-${safe(moduleName)}-${safe(file.shortName)}-${safe(layerFolder)}`;
                const args = { planId, moduleName, shortName: file.shortName, layerFolder };
                intents.push(mkStep(context, step, planId, `L1 pipeline: ${moduleName}/${layerFolder}/${file.shortName}`, 'agentMaterializeL1Def', args));
            }
            // One step per L2 page .defs.ts file (create sub-files)
            for (const file of scanL2PageDefsFiles(project, moduleName)) {
                const planId = `mat-l2-${safe(moduleName)}-${safe(file.shortName)}`;
                const args = { planId, moduleName, shortName: file.shortName };
                intents.push(mkStep(context, step, planId, `L2 files: ${moduleName}/${file.shortName}`, 'agentMaterializeL2Def', args));
            }
        }
        return intents;
    }
    catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return [mkFail(context, _parentStep, step, hookSequential, msg)];
    }
}
// ─── Builders ─────────────────────────────────────────────────────────────────
function mkStep(context, rootStep, planId, title, agentName, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: rootStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: title,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName,
            prompt: JSON.stringify(args),
            rags: [],
            planning: { planId, dependsOn: [], executionMode: 'parallel_static', executionHost: 'client' },
        },
    };
}
function mkFail(context, parentStep, step, hookSequential, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status: 'failed',
        traceMsg,
    };
}
function safe(name) {
    return name.replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase();
}
// ─── ensure singletons ────────────────────────────────────────────────────────
async function ensureFile(ref, src) {
    const info = mls.stor.convertFileReferenceToFile(ref);
    const key = mls.stor.getKeyToFile(info);
    if (mls.stor.files[key])
        return;
    const param = { ...info, source: src };
    await createStorFile(param, true, true, true);
}
async function ensureSingletons(project, moduleName) {
    await ensureFile(`_${project}_/l2/${moduleName}/module.ts`, buildModuleTs(project, moduleName));
    await ensureFile(`_${project}_/l2/${moduleName}/index.ts`, buildIndexTs(project, moduleName));
    await ensureFile(`_${project}_/l1/${moduleName}/layer_2_controllers/router.ts`, buildRouterTs(project, moduleName));
    await ensureFile(`_${project}_/l1/${moduleName}/layer_1_external/persistence.ts`, buildPersistenceTs(project, moduleName));
}
// ─── templates ────────────────────────────────────────────────────────────────
function buildModuleTs(project, moduleName) {
    return `/// <mls fileReference="_${project}_/l2/${moduleName}/module.ts" enhancement="_blank" />
import type { AuraModuleFrontendDefinition, IPaths, ISkill, IGenomeConfig } from '/_102029_/l2/contracts/bootstrap.js';

export const moduleGenome: Record<string, IGenomeConfig> = {
  'web/desktop/page11': {
    designSystem: 'default',
    device: 'desktop',
    layout: 'standard',
  }
} as const;

export const shared: IPaths = {
  web: {
    sharedPath: '/_${project}_/l2/${moduleName}/web/shared',
    sharedSkill: '/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts'
  }
}

export const skills: ISkill = {
  definition:{
    skillPath:  ['_102034_'],
  },
  architecture: {
    skillPath:  ['_102021_/l2/skills/architecture.md'],
  },
  layer1: {
    skillPath:  ['_102021_/l2/skills/layer_1.md'],
  },
  layer2: {
    skillPath:  ['_102021_/l2/skills/layer_2.md'],
  },
  layer3: {
    skillPath:  ['_102021_/l2/skills/layer_3.md'],
  },
  layer4: {
    skillPath:  ['_102021_/l2/skills/layer_4.md'],
  },
  contract: {
    skillPath: ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"],
  }
}

export const moduleStates = {} as const;

export const moduleShellPreferences = {
  layout: {
    asideMode: { desktop: 'inline', mobile: 'fullscreen' },
  },
} as const;

export const moduleFrontendDefinition: AuraModuleFrontendDefinition = {
  pageTitle: '${moduleName}',
  device: 'desktop',
  navigation: [],
  routes: [],
};
`;
}
function buildIndexTs(project, moduleName) {
    return `/// <mls fileReference="_${project}_/l2/${moduleName}/index.ts" enhancement="_blank" />
import { bootstrapCollabApp } from '/_102033_/l2/core/bootstrap.js';

void bootstrapCollabApp({
  projectId: '${project}',
  appId: '${moduleName}',
  title: 'Collab Test · ${moduleName}',
  shellMode: 'spa',
  navigation: [
    { label: 'Monitor', href: '/monitor' },
  ],
  pages: [],
});
`;
}
function buildRouterTs(project, moduleName) {
    const fnName = `create${moduleName.charAt(0).toUpperCase()}${moduleName.slice(1)}Router`;
    return `/// <mls fileReference="_${project}_/l1/${moduleName}/layer_2_controllers/router.ts" enhancement="_blank" />
import type { BffHandler } from '/_102034_/l1/server/layer_2_controllers/contracts.js';

export function ${fnName}(): Map<string, BffHandler> {
  return new Map<string, BffHandler>([
  ]);
}
`;
}
function buildPersistenceTs(project, moduleName) {
    return `/// <mls fileReference="_${project}_/l1/${moduleName}/layer_1_external/persistence.ts" enhancement="_blank" />
import type { TableDefinition } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';

export const tableDefinitions: TableDefinition[] = [
];
`;
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
const systemPrompt = `<!-- modelType: codepro -->

You initialize the "materialize" task.

You receive a scan of .defs.ts files found in a project and confirm the scan is valid.

If valid, return:
{"type":"flexible","result":{"status":"ok","notes":[]}}

If invalid (no modules, no files), return:
{"type":"result","result":"Short error message"}

Return valid JSON only — no markdown, no prose outside the JSON.`;
function buildHumanPrompt(summaries) {
    const lines = ['# Materialize Scan', ''];
    for (const s of summaries) {
        lines.push(`## Module: ${s.moduleName}`);
        lines.push(`L1 files (${s.l1Count}): ${s.l1Files.join(', ') || '(none)'}`);
        lines.push(`L2 pages (${s.l2Count}): ${s.l2Files.join(', ') || '(none)'}`);
        lines.push('');
    }
    lines.push('Confirm the scan and return your response.');
    return lines.join('\n');
}
