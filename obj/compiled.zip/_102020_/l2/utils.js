/// <mls fileReference="_102020_/l2/utils.ts" enhancement="_blank"/>
import { setErrorOnModel } from '/_102027_/l2/utils.js';
export function resolveTagToFile(tag) {
    if (isNewFormat(tag)) {
        return resolveNewTag(tag);
    }
    return convertTagToFileName(tag);
}
// === ENTRADA PRINCIPAL: FILE → TAG ===
export function convertFileToTag(info) {
    const { shortName } = info;
    // Formato novo só se o shortName ORIGINAL já tem '-' (kebab nativo)
    // ex: "widget-test" → novo | "widgetTest" → legado
    if (shortName.includes('-')) {
        return fileToTagNew(info);
    }
    return fileToTagLegacy(info);
}
function isNewFormat(tag) {
    return !/-\d+$/.test(tag);
}
function resolveNewTag(tag) {
    if (!mls.actualProject)
        return undefined;
    const currentProject = mls.actualProject;
    const dependencies = mls.l5.getProjectDependencies(mls.actualProject, false);
    const files = mls.stor.files;
    const parsed = parseNewTag(tag);
    if (!parsed)
        return undefined;
    const { shortName, folderSuffix } = parsed;
    const searchOrder = [currentProject, ...dependencies];
    for (const project of searchOrder) {
        const found = Object.values(files).find((f) => {
            if (f.project !== project)
                return false;
            if (toKebab(f.shortName) !== shortName)
                return false;
            if (!folderSuffix)
                return true;
            // Match pelo final do folder
            // ex: folderSuffix = "groupSelectOne"
            //     f.folder = "molecules/groupSelectOne" → OK
            //     f.folder = "groupSelectOne"            → OK
            return f.folder === folderSuffix || f.folder.endsWith('/' + folderSuffix);
        });
        if (found) {
            return { project, shortName, folder: found.folder };
        }
    }
    return undefined;
}
function parseNewTag(tag) {
    const separatorIndex = tag.indexOf('--');
    if (separatorIndex === -1) {
        return { shortName: tag, folderSuffix: '' };
    }
    const folderPart = tag.substring(0, separatorIndex);
    const namePart = tag.substring(separatorIndex + 2);
    if (!namePart)
        return undefined;
    return {
        shortName: namePart,
        folderSuffix: fromKebab(folderPart),
    };
}
function fileToTagNew(info) {
    const { shortName, folder = '' } = info;
    const kebabName = toKebab(shortName);
    if (!folder)
        return kebabName;
    // Usa só a última parte do folder na tag
    const parts = folder.split('/');
    const lastFolder = parts[parts.length - 1];
    const kebabFolder = toKebab(lastFolder);
    return `${kebabFolder}--${kebabName}`;
}
// === FORMATO LEGADO (com projeto) ===
function convertTagToFileName(tag) {
    const parts = tag.split('--');
    const namePart = parts.pop() || '';
    const folder = parts.join('/').replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    const match = namePart.match(/(.+)-(\d+)$/);
    if (!match)
        return undefined;
    const [, rest, number] = match;
    const shortName = rest.replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    return { shortName, project: +number, folder };
}
function fileToTagLegacy(info) {
    const { shortName, project, folder = '' } = info;
    const kebabName = toKebab(shortName);
    const baseName = `${kebabName}-${project}`;
    const folderPrefix = folder
        ? toKebab(folder).replace(/\//g, '--') + '--'
        : '';
    return `${folderPrefix}${baseName}`;
}
function toKebab(str) {
    return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
}
function fromKebab(str) {
    return str.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}
export function isPageFile(folder) {
    if (!mls.actualModule)
        return false;
    const match = folder.match(/^(.+?)\/(web\/desktop|web\/mobile|android|ios)\/page\d+$/);
    if (!match)
        return false;
    return match[1] === mls.actualModule;
}
export function validateTagName(modelTS) {
    if (!modelTS || !modelTS.storFile)
        return false;
    const { storFile, model } = modelTS;
    const { project, shortName, folder } = storFile;
    storFile.hasError = false;
    clearErrorsOnModel(model);
    if (!modelTS.compilerResults)
        return false;
    const decorators = JSON.parse(modelTS.compilerResults.decorators);
    if (!decorators)
        return false;
    const decoratorToCheck = 'customElement';
    let rc = false;
    Object.entries(decorators).forEach((entrie) => {
        const decoratorInfo = entrie[1];
        if (!decoratorInfo || decoratorInfo.type !== 'ClassDeclaration')
            return;
        decoratorInfo.decorators.forEach((_decorator) => {
            const decoratorInfo = getDecoratorClassInfo(_decorator.text);
            if (!decoratorInfo || decoratorInfo.decoratorName !== decoratorToCheck)
                return;
            let correctTagName = convertFileToTag({ project, shortName, folder });
            if (correctTagName !== decoratorInfo.tagName) {
                rc = true;
                setErrorOnModel(model, _decorator.line + 1, decoratorToCheck.length + 3, _decorator.text.length + 1, `Invalid web component tag name, the correct definition is: ${correctTagName}`, monaco.MarkerSeverity.Error);
                storFile.hasError = true;
            }
        });
    });
    return rc;
}
function clearErrorsOnModel(model) {
    monaco.editor.setModelMarkers(model, 'markerSource', []);
}
function getDecoratorClassInfo(decoratorString) {
    const regex = /(\w+)\(['"](.+?)['"]\)/;
    const match = decoratorString.match(regex);
    let result = undefined;
    if (match && match.length > 2) {
        const decoratorName = match[1];
        const tagName = match[2];
        result = {
            decoratorName,
            tagName,
        };
    }
    return result;
}
