/// <mls fileReference="_102020_/l2/previewModeAura.ts" enhancement="_blank"/>
import { setErrorOnModel, getPath } from '/_102027_/l2/utils.js';
import { resolveTagToFile } from '/_102020_/l2/utils.js';
export class PreviewModeAura {
    constructor(_j, _i, _l, _s, _f, _m) {
        this.isService = false;
        this.models = undefined;
        this.file = undefined;
        this.needAwait = true;
        this.json = _j;
        this.ifr = _i;
        this.level = _l;
        this.isService = _s;
        this.file = _f;
        this.models = _m;
    }
    async init() {
        if (!this.json || !this.ifr)
            return;
        await this.loadEsbuild();
        if (this.needAwait)
            setTimeout(async () => await this.configIframe(), 200);
        else
            this.configIframe();
    }
    async buildJS(other) {
        await this.loadEsbuild();
        return this._buildJS(other);
    }
    async configIframe() {
        if (!this.json || !this.ifr || !this.esbuild || !this.file)
            return;
        const find = this.findWidgets(this.ifr.contentDocument?.body);
        const auraWidgets = this.getImportsAuraWigetsPlayGround();
        const result = await this._buildJS([...find, ...auraWidgets]);
        this.mountJSImporMap(this.json, this.ifr);
        this.mountLinks(this.json, this.ifr);
        this.mountTailwindDarkMode(this.ifr);
        this.mountTokens(this.json.tokens || '', this.file);
        this.addGlobalCss(this.json.globalCss);
        this.addDsGlobalCss(this.json.dsGlobalCss || '');
        this.addJsReference(this.ifr, this.level || '2');
        const s = document.createElement('script');
        s.textContent = result.outputFiles[0].text;
        this.ifr.contentDocument?.body.appendChild(s);
    }
    async _buildJS(other) {
        if (!this.json || !this.esbuild || !this.file)
            return;
        let myMap = this.parseImportsMap(this.json.importsMap);
        let valids = [...Object.keys(myMap), ...this.json.importsJs, ...other];
        valids = [...new Set(valids)];
        if (Object.keys(myMap).length === 0) {
            const enhancementModules = await import('/_102020_/l2/enhancementAura.js');
            const maps = enhancementModules.requires.filter((item) => item.type === 'cdn');
            maps.forEach((item) => {
                myMap[item.name] = item.ref;
            });
        }
        /*if (Object.keys(myMap).length === 0) myMap = {
            lit: "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js",
            "lit/decorators.js": "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm"
        }*/
        const virtualFsPlugin = {
            name: 'virtual-fs',
            setup(build) {
                build.onResolve({ filter: /.*/ }, (args) => {
                    if (valids.includes(args.path)) {
                        return {
                            path: args.path,
                            namespace: 'virtual',
                        };
                    }
                    if (args.path.startsWith("_") &&
                        !args.importer.startsWith("https://")) {
                        return {
                            path: args.path.replace('_', '/_'),
                            namespace: 'virtual',
                        };
                    }
                    if ((args.path.startsWith("/") || args.path.startsWith("./") || args.path.startsWith("../")) &&
                        !args.importer.startsWith("https://") && !myMap[args.importer]) {
                        const url = new URL(args.path, 'file:' + args.importer);
                        let path = url.pathname;
                        if (!(/_(\d+)_/.test(path))) {
                            const info = getPath(args.importer.replace('/l2/', '').replace('/', ''));
                            if (!info)
                                throw new Error('[virtualFsPlugin] Not found path:' + args.importer.replace('/l2/', '').replace('/', ''));
                            if (!info.project)
                                info.project = mls.actualProject;
                            if (path.indexOf(`_${info.project}_`) < 0) {
                                path = url.pathname.replace('/', `/_${info.project}_`);
                            }
                        }
                        return { path, namespace: 'virtual' };
                    }
                    // import url externa
                    if ((args.path.startsWith("./") ||
                        args.path.startsWith("../") ||
                        args.path.startsWith("/")) &&
                        args.importer.startsWith("https://")) {
                        const url = new URL(args.path, args.importer);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    // import url externa
                    if (args.path.startsWith("/") && myMap[args.importer]) {
                        const url = new URL(args.path, myMap[args.importer]);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    // url externa
                    if (args.path.startsWith("http")) {
                        return { path: args.path, namespace: 'virtual' };
                    }
                    if (myMap[args.path]) {
                        return { path: myMap[args.path], namespace: 'virtual' };
                    }
                    return null;
                });
                build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                    try {
                        let path = myMap[args.path] ? myMap[args.path] : args.path;
                        const res = await fetch(path);
                        if (!res.ok)
                            throw new Error(`Error get ${args.path}`);
                        const text = await res.text();
                        return { contents: text, loader: 'js' };
                    }
                    catch (e) {
                        console.info('erro:' + args.path);
                        return {
                            contents: '',
                            loader: 'js',
                            warnings: [{
                                    text: e.message, notes: [
                                        { text: 'build-error' }
                                    ]
                                }]
                        };
                    }
                });
            },
        };
        let allImports = [...this.json.importsJs, ...other];
        allImports = [...new Set(allImports)];
        const virtualEntryPath = "virtual-entry.js";
        const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
        const cachedJs = this.loadCache();
        const result = cachedJs ? cachedJs : await this.esbuild.build({
            stdin: {
                contents: virtualEntryContent,
                resolveDir: "/",
                sourcefile: virtualEntryPath,
                loader: "js"
            },
            bundle: true,
            minify: true,
            format: "esm",
            sourcemap: 'inline',
            write: false,
            plugins: [virtualFsPlugin]
        });
        if (result.warnings && result.warnings.length > 0) {
            const msgs = result.warnings
                .filter((item) => item.notes?.[0]?.text === 'build-error')
                .map((item) => item.text)
                .join('\n');
            if (this.models?.ts?.model && msgs.trim()) {
                const lineLength = this.models.ts.model.getLineLength(1);
                setErrorOnModel(this.models.ts.model, 1, 1, lineLength, msgs, monaco.MarkerSeverity.Error);
                this.models.ts.storFile.hasError = true;
            }
        }
        if (!window.cachePreview) {
            window.cachePreview = {};
        }
        window.cachePreview[this.json.importsJs[0]] = result;
        return result;
    }
    // =========================================================================
    // PHASE 1 — Isolated render (opaque-origin iframe, via srcdoc)
    // Builds a COMPLETE HTML document as a string (without touching contentDocument).
    // =========================================================================
    /**
     * Builds the full srcdoc for an opaque-origin iframe.
     * @param bodyHtml  the component HTML (this.actualFiles.htmlContent).
     * @param extraStyles  compiled styles (component less, tokens) keyed by id.
     */
    async buildSrcdoc(bodyHtml, extraStyles = []) {
        if (!this.json || !this.file)
            return '';
        await this.loadEsbuild();
        const find = this.findWidgetsFromString(bodyHtml);
        const auraWidgets = this.getImportsAuraWigetsPlayGround();
        const result = await this._buildJS([...find, ...auraWidgets]);
        let bundleJs = result?.outputFiles?.[0]?.text || '';
        // Prevents a "</script>" inside the bundle from closing the srcdoc <script>.
        bundleJs = bundleJs.replace(/<\/(script)/gi, '<\\/$1');
        const head = [
            this.strImportMap(this.json),
            this.strLinks(this.json),
            this.strTailwindDarkMode(),
            this.json.tokens ? `<style id="${this.getIdTokens(this.file)}">${this.json.tokens}</style>` : '',
            this.json.globalCss ? `<style id="global_css" type="text/tailwindcss">${this.json.globalCss}</style>` : '',
            this.json.dsGlobalCss ? `<style id="ds_global">${this.json.dsGlobalCss}</style>` : '',
            ...extraStyles.map(s => `<style id="${s.id}">${s.css}</style>`),
        ].filter(Boolean).join('\n');
        return `<!DOCTYPE html><html><head><meta charset="utf-8">
${head}
</head><body>
${bodyHtml}
${this.strRuntimeShim(this.level || '2')}
${this.strBootstrap()}
<script type="module">${bundleJs}</script>
</body></html>`;
    }
    findWidgetsFromString(htmlContent) {
        const div = document.createElement('div');
        div.innerHTML = htmlContent;
        return this.findWidgets(div);
    }
    strImportMap(info) {
        if (!info.importsMap || info.importsMap.length <= 0)
            return '';
        return `<script type="importmap">{"imports": { ${info.importsMap.join(',\n')} } }</script>`;
    }
    strLinks(info) {
        if (!info.importsLinks || info.importsLinks.length <= 0)
            return '';
        return info.importsLinks.map(l => `<link rel="${l.rel}" href="${l.ref}">`).join('\n');
    }
    strTailwindDarkMode() {
        const hasTailwind = this.json?.importsJs.some(u => u.includes('tailwindcss'));
        if (!hasTailwind)
            return '';
        return `<style type="text/tailwindcss">@custom-variant dark (&:where(.dark, .dark *));</style>`;
    }
    /**
     * Runtime shim for the opaque origin: it CANNOT read parent.* (would throw
     * SecurityError). Uses the iframe's native fetch and local stubs.
     */
    strRuntimeShim(level) {
        return `<script>
window['litDisableBundleWarning']=true;
window['collabActualLevel']=${level};
window['mls']=window['mls']||{};
window['globalVariation']=window['globalVariation']||0;
window['originalDefine']=customElements.define.bind(customElements);
customElements.define=function(n,c,o){if(!customElements.get(n))return window['originalDefine'](n,c,o);};
</script>`;
    }
    /**
     * Bootstrap inside the iframe: answers the heartbeat (ping->pong) and applies
     * dynamic updates from the parent via postMessage (dark/lang/style).
     */
    strBootstrap() {
        return `<script>
(function(){
  window.addEventListener('message', function(e){
    var d = e.data || {};
    if (d.type === 'ping') { parent.postMessage({type:'pong', id:d.id}, '*'); return; }
    if (d.type === 'setDarkMode') {
      var h = document.documentElement;
      if (d.dark) { h.classList.add('dark'); h.setAttribute('data-theme','dark'); }
      else { h.classList.remove('dark'); h.removeAttribute('data-theme'); }
    }
    if (d.type === 'setLang') { document.documentElement.lang = d.lang || 'en'; }
    if (d.type === 'setStyle') {
      var id = d.id || 'dyn-style';
      var el = document.getElementById(id);
      if (!el) { el = document.createElement('style'); el.id = id; document.head.appendChild(el); }
      el.textContent = d.css || '';
    }
  });
  parent.postMessage({type:'ready'}, '*');
})();
</script>`;
    }
    parseImportsMap(importsArray) {
        return Object.fromEntries(importsArray.map(str => {
            const match = str.match(/^"(.+?)":\s*"(.+?)"$/);
            if (!match)
                throw new Error("Formato inválido: " + str);
            const [, key, value] = match;
            return [key, value];
        }));
    }
    findWidgets(rootElement) {
        if (!rootElement)
            return [];
        const els = rootElement.querySelectorAll('[widget]');
        const array = Array.from(els)
            .map((el) => {
            const info = resolveTagToFile(el.getAttribute('widget') || '');
            if (!info)
                return '';
            return '/' + `_${info.project}_${info.shortName}`;
        })
            .filter(Boolean);
        const ret = [...new Set(array)];
        return ret;
    }
    getImportsAuraWigetsPlayGround() {
        return [
            '/_102020_widgetPlaygroundState',
            '/_102020_widgetPlaygroundStateBoolean',
            '/_102020_widgetPlaygroundStateNumber',
            '/_102020_widgetPlaygroundStateText',
            '/_102020_widgetPlaygroundStatePreviewCode',
        ];
    }
    async loadEsbuild() {
        this.needAwait = true;
        if (mls.esbuild) {
            this.esbuild = mls.esbuild;
            this.needAwait = false;
        }
        else if (!mls.esbuildInLoad)
            await this.initializeEsBuild();
    }
    async initializeEsBuild() {
        mls.esbuildInLoad = true;
        const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
        if (!this.esbuild) {
            this.esbuild = await import(url);
            await this.esbuild.initialize({
                wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
            });
            mls.esbuild = this.esbuild;
            mls.esbuildInLoad = false;
        }
    }
    loadCache() {
        if (mls.actualLevel !== 7)
            return;
        if (!window.cachePreview || !this.json)
            return;
        if (!window.cachePreview[this.json.importsJs[0]])
            return;
        let needCompile = false;
        this.json.importsJs.forEach((i) => {
            const name = i.startsWith('/') ? i.replace('/', '') : i;
            const f = getPath(name);
            if (!f)
                throw new Error('[loadCache] Not found path:' + name);
            const key = mls.stor.getKeyToFiles(f.project, 2, f.shortName, f.folder, '.ts');
            if (mls.stor.files[key] && mls.stor.files[key].inLocalStorage) {
                needCompile = true;
            }
        });
        if (needCompile)
            return;
        return window.cachePreview[this.json.importsJs[0]];
    }
    mountJSImporMap(info, ifr) {
        try {
            if (info.importsMap.length <= 0 || !ifr.contentDocument)
                return;
            const js = '{"imports": { ' + info.importsMap.join(',\n') + '} }';
            const script = document.createElement('script');
            script.type = 'importmap';
            script.textContent = js;
            ifr.contentDocument.head.appendChild(script);
        }
        catch (e) {
            console.info('Error mountJSImporMap: ' + e.message);
            return;
        }
    }
    mountLinks(info, ifr) {
        try {
            if (info.importsLinks.length <= 0 || !ifr.contentDocument)
                return;
            for (let link of info.importsLinks) {
                const linkRef = document.createElement('link');
                linkRef.href = link.ref;
                linkRef.rel = link.rel;
                ifr.contentDocument.head.appendChild(linkRef);
            }
        }
        catch (e) {
            console.info('Error mountJSImporMap: ' + e.message);
            return;
        }
    }
    /**
     * Injects Tailwind v4 dark mode configuration into the iframe.
     *
     * Tailwind v4 uses `prefers-color-scheme` by default.
     * This overrides it to use the `dark` class on <html>,
     * so toggleDarkLight() in servicePreview can control it via classList.
     *
     * Must be called BEFORE Tailwind processes the DOM (before the script runs).
     */
    mountTailwindDarkMode(ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            const hasTailwind = this.json?.importsJs.some((url) => url.includes('tailwindcss'));
            if (!hasTailwind)
                return;
            const style = document.createElement('style');
            style.setAttribute('type', 'text/tailwindcss');
            style.textContent = `@custom-variant dark (&:where(.dark, .dark *));`;
            ifr.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTailwindDarkMode: ' + e.message);
        }
    }
    mountTokens(tokens, file) {
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            this.removeOlderTokens(iframe, file);
            const css = tokens || '';
            if (!css)
                return;
            const style = document.createElement('style');
            style.textContent = css;
            style.id = this.getIdTokens(file);
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    removeOlderTokens(ifr, file) {
        const id = this.getIdTokens(file);
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.head.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    getIdTokens(file) {
        if (!file)
            return 'ds_tokens';
        const { project } = file;
        return '_' + project + '_ds_tokens';
    }
    addGlobalCss(globalCss) {
        if (!globalCss)
            return;
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            const oldStyle = iframe.contentDocument.querySelector('style#global_css');
            if (oldStyle)
                oldStyle.remove();
            const style = document.createElement('style');
            style.textContent = globalCss;
            style.id = 'global_css';
            style.type = "text/tailwindcss";
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    /**
     * Inject the Aura per-DS stylesheet (global.css). Plain <style> (NOT text/tailwindcss):
     * it is only CSS custom properties + @import/@font-face for fonts.
     */
    addDsGlobalCss(css) {
        if (!css)
            return;
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            const old = iframe.contentDocument.querySelector('style#ds_global');
            if (old)
                old.remove();
            const style = document.createElement('style');
            style.textContent = css;
            style.id = 'ds_global';
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error addDsGlobalCss: ' + e.message);
        }
    }
    addJsReference(ifr, level) {
        const s = document.createElement('script');
        s.textContent = `
				window['mls'] = window['mls']  ? window['mls']  : parent.mls ? parent.mls : top['mls'];
				window['monaco'] = window['monaco']  ? window['monaco']  : parent.monaco ? parent.monaco : top['monaco'];
                window['fetch'] = parent.fetch.bind(parent);
				window['globalVariation'] = window['globalVariation']  ? window['globalVariation']  : parent.globalVariation ? parent.globalVariation : top['globalVariation'];
				window['latest'] = window['latest']  ? window['latest']  : parent.latest ? parent.latest : top['latest'];
				window['EasyMDE'] = window['EasyMDE']  ? window['EasyMDE']  : parent.EasyMDE ? parent.EasyMDE : top['EasyMDE'];
                window['litDisableBundleWarning'] = true;
                window['collabActualLevel'] = ${level};
                window['previewL1'] = window['previewL1']  ? window['previewL1']  : parent.previewL1 ? parent.previewL1 : top['previewL1'];
                window['preview'] = window['preview']  ? window['preview']  : parent.preview ? parent.preview : top['preview'];

                (window)['originalDefine'] = customElements.define.bind(customElements);
                    customElements.define = (name, constructor, options) => {
                    if (!customElements.get(name)) {
                        return (window)['originalDefine'](name, constructor, options);
                    }
                };

            
    `;
        ifr.contentDocument?.body.appendChild(s);
    }
}
