/// <mls fileReference="_102020_/l2/agents/agentNewMoleculePlayground.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { skill } from '/_102020_/l2/skills/molecules/playgroundGenerator.js';
import { skills as skillList } from '/_102020_/l2/skills/molecules/index';
export function createAgent() {
    return {
        agentName: "agentNewMoleculePlayground",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "Agent for playground demonstration molecule",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const data = JSON.parse(userPrompt);
    console.info({ data });
    const path = mls.stor.getPathToFile(data.fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`(${agent.agentName})[beforePromptStep] invalid file`);
    const source = await getSource(files.ts);
    const usageSkill = await getUsageByGroupSkill(data.group);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                        .replace("{{ skill }}", skill)
                        .replace("{{ usageSkill }}", usageSkill)
                }, {
                    type: "human",
                    content: `#Molecule Source \n\n \`\`\`typescript \n ${source} \n\`\`\``
                }],
            taskTitle: `Prepare playground`,
            threadId: context.message.threadId,
            userMessage: 'Generate playground',
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const data = JSON.parse(args);
    console.info({ data });
    const path = mls.stor.getPathToFile(data.fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`(${agent.agentName})[beforePromptStep] invalid file`);
    const source = await getSource(files.ts);
    const usageSkill = await getUsageByGroupSkill(data.group);
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: `#Molecule Source \n\n \`\`\`typescript \n ${source} \n\`\`\``,
        systemPrompt: system1
            .replace("{{ skill }}", skill)
            .replace("{{ usageSkill }}", usageSkill)
    };
    return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output) {
    const fileReference = output.fileReference;
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    const paramsHtml = { ...fileInfo, content: output.html, versionRef: new Date().toISOString(), extension: ".html" };
    await updateStorFile(paramsHtml);
    return [];
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMolecule] Invalid storFile');
    const path = mls.stor.getKeyToFile(params);
    console.log(`[agentNewMolecule] updating file: ${path}`);
    console.log(`[agentNewMolecule] updating content: ${params.content}`);
    const modelDefs = await file.getOrCreateModel();
    modelDefs.model.setValue(params.content);
}
export async function getSource(file) {
    // change first line to new pattern
    if (!file)
        throw new Error(`[beforePromptStep] invalid args, file dont exists`);
    const source = (await file.getContent());
    if (typeof source !== 'string' || !source)
        throw new Error(`[beforePromptAtomic] invalid source`);
    return source;
}
async function getUsageByGroupSkill(group) {
    const path = skillList.find((item) => item.name === group)?.skillUsageReference;
    if (!path)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    const module = await import(path);
    if (!module || !module.skill)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    if (typeof module.skill !== 'string')
        throw new Error(`[getGroupSkill] invalid type of skill: ${path}, must be string`);
    return module.skill;
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

Task: Analyze the provided TypeScript code and produce usage examples for the component according to the following criteria:

# Generate 6 distinct examples, ensuring:
- Variation in attributes (props)
-Different uses of slots (when available)
-A mix of simple and advanced configurations

# The examples must:
-Be realistic and ready to use
-Follow best practices

##Playground Definition
{{ skill }}

##Component Group Usage 
{{ usageSkill }}


## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: IResult;
    }

interface IResult {
    fileReference: string // same ts file
    html: string
}

`;
//#endregion 
