/// <mls fileReference="_102020_/l2/agents/newModule/agentOntologyGapCheck.ts" enhancement="_102027_/l2/enhancementAgent" />
import { findPreviousAgentStep } from '/_102027_/l2/aiAgentHelper.js';
import { updateVariableJson, getVariableJson } from '/_102027_/l2/defsAST.js';
export function createAgent() {
    return {
        agentName: "agentOntologyGapCheck",
        agentProject: 102020,
        agentFolder: "agents/newModule",
        agentDescription: "Verify ontology covers all page data needs",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
function getOntologyStorFile(moduleName) {
    const key = mls.stor.getKeyToFile({ project: mls.actualProject || 0, level: 2, shortName: 'module', folder: moduleName, extension: '.defs.ts' });
    const sf = mls.stor.files[key];
    if (!sf)
        throw new Error('[agentOntologyGapCheck] ontology file not found');
    return sf;
}
async function buildSystemPrompt(moduleName, pagesJson) {
    const sf = getOntologyStorFile(moduleName);
    const src = await sf.getContent();
    const ontology = getVariableJson(src, 'ontology');
    return system1
        .replace('{{ontology}}', JSON.stringify(ontology, null, 2))
        .replace('{{pages}}', pagesJson);
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt)
        throw new Error('invalid prompt');
    const info = JSON.parse(userPrompt);
    const systemPrompt = await buildSystemPrompt(info.moduleName, JSON.stringify(info.pages, null, 2));
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: 'Check the ontology for gaps' }
            ],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { moduleName: info.moduleName }
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const info = JSON.parse(args);
    const systemPrompt = await buildSystemPrompt(info.moduleName, JSON.stringify(info.pages, null, 2));
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: 'Check the ontology for gaps',
        systemPrompt
    };
    return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step || !step.interaction?.payload)
        throw new Error('[afterPromptStep] invalid params');
    const payload = step.interaction.payload[0];
    if (!payload || payload.type !== 'flexible' || !payload.result)
        throw new Error('[afterPromptStep] invalid payload');
    const result = payload.result;
    const moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!moduleName)
        throw new Error('[agentOntologyGapCheck] moduleName not found');
    const sf = getOntologyStorFile(moduleName);
    let ontologyContent;
    if (result.hasGaps && result.updatedOntology) {
        const m = await sf.getOrCreateModel();
        const currentSrc = m.model.getValue();
        ontologyContent = updateVariableJson(currentSrc, 'ontology', result.updatedOntology);
        m.model.setValue(ontologyContent);
        await mls.stor.localStor.setContent(sf, { contentType: 'string', content: ontologyContent });
    }
    else {
        ontologyContent = await sf.getContent();
    }
    const stepOri = context.task ? (findPreviousAgentStep(context.task, parentStep.stepId))?.stepId : parentStep.stepId;
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: stepOri || parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: 'agentInterfaceOntology',
            prompt: ontologyContent,
            rags: [],
        }
    };
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status: 'completed'
    };
    return [newStep, updateStatus];
}
const system1 = `
<!-- modelType: codeinstruct -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior Domain Architect with 20+ years of experience in system design.

Your task is to verify whether an existing ontology covers all the data needs implied by a set of page definitions.

## Current Ontology
\`\`\`json
{{ontology}}
\`\`\`

## Page Definitions
\`\`\`json
{{pages}}
\`\`\`

## Instructions

Analyze each page's purpose and actor, and the purpose of each organism within it.
Identify domain entities that would logically be required to implement these pages but are NOT present in the current ontology.

Focus on:
- Entities implied by organism purposes (e.g. "show order history" implies an Order entity)
- Junction or relationship entities needed to connect existing entities
- Entities implied by page actors and their workflows

Do NOT add entities that:
- Already exist in the ontology (even with a slightly different name)
- Are purely technical (sessions, logs, cache, tokens)
- Can be modeled as fields within an existing entity

## Output format
Return strictly JSON, no spaces, no indent, minified
export type Output = {
    type: "flexible";
    result: GapCheckResult;
};

export type GapCheckResult =
    | {
        hasGaps: false;
        summary: string;
      }
    | {
        hasGaps: true;
        summary: string;
        updatedOntology: ModuleToBe;
      };
`;
//#endregion
