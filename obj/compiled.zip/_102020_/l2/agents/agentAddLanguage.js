/// <mls fileReference="_102020_/l2/agents/agentAddLanguage.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { skill as skilli18n } from '/_102020_/l2/skills/aura/language.js';
import { waitModelIdle } from '/_102027_/l2/libModel.js';
export function createAgent() {
    return {
        agentName: "agentAddLanguage",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "New i18n language",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const [dataUser] = JSON.parse(userPrompt);
    const paths = await getPaths(dataUser.languages, dataUser.projectId);
    if (paths.length === 0)
        throw new Error('No find files to add language');
    const inputs = [{ type: "system", content: system1.replace('{{ skillLanguage }}', skilli18n) }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Add language`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths.map((item) => JSON.stringify(item))
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    const data = JSON.parse(args);
    console.info(`===process with args: ${args}`);
    const actuali18n = await getPagei18nBlock(data.fileReference);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: `

        Add languages: ${data.languages}

        ##File Reference: ${data.fileReference}

        ## Actual i18n:
        \`\`\`typescript 
        ${actuali18n}
        \`\`\`
        
        `
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload;
    intents = await processOutput(context, output.result.i18n, output.result.fileReference);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function getPaths(languages, project) {
    if (!project)
        throw new Error(`[getPaths] invalid project`);
    const moduleProject = await import(`/_${project}_/l2/project.js`);
    if (!moduleProject?.projectConfig?.modules)
        throw new Error(`[getPaths] no modules configured in project`);
    const modules = moduleProject.projectConfig.modules;
    const result = [];
    for (const mod of modules) {
        ;
        const moduleConfig = await import(`/_${project}_/l2/${mod.name}/module.js`);
        if (!moduleConfig?.skills)
            continue;
        if (moduleConfig.skills.web) {
            const sharedFolder = `${moduleConfig.skills.web.sharedPath}`
                .replace(/^\/?_\d+_\/l2\//, '')
                .replace(/^\/|\/$/g, '');
            const sharedFiles = Object.values(mls.stor.files).filter((f) => f.project === project &&
                f.folder === sharedFolder &&
                f.extension === '.ts');
            for (const storFile of sharedFiles) {
                const model = await storFile.getOrCreateModel();
                if (!model)
                    continue;
                const source = model.model.getValue();
                const missingLangs = languages
                    .filter(lang => !_hasLanguageInI18nBlock(source, lang.code))
                    .map(lang => lang.code);
                if (missingLangs.length === 0)
                    continue;
                const fileReference = mls.stor.convertFileToFileReference(storFile);
                result.push({ languages: missingLangs, fileReference });
            }
        }
    }
    return result;
}
function _hasLanguageInI18nBlock(source, lang) {
    const startMarker = '/// **collab_i18n_start**';
    const endMarker = '/// **collab_i18n_end**';
    const startIdx = source.indexOf(startMarker);
    const endIdx = source.indexOf(endMarker);
    if (startIdx === -1 || endIdx === -1)
        return false;
    const i18nBlock = source.substring(startIdx, endIdx);
    const keyPatterns = [
        new RegExp(`\\b${lang}\\s*:`, 'm'),
        new RegExp(`['"]${lang}['"]\\s*:`, 'm'),
    ];
    return keyPatterns.some(pattern => pattern.test(i18nBlock));
}
async function getPagei18nBlock(fileReference) {
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[getPagei18nBlock] invalid file: ${fileReference}`);
    const i18nBlock = await geti18nByFile(files.ts);
    return i18nBlock;
}
async function geti18nByFile(stor) {
    const modelTS = await stor.getOrCreateModel();
    if (!modelTS)
        throw new Error(`[geti18nByFile] invalid models`);
    const source = modelTS.model.getValue();
    const startMarker = '/// **collab_i18n_start**';
    const endMarker = '/// **collab_i18n_end**';
    const startIdx = source.indexOf(startMarker);
    const endIdx = source.indexOf(endMarker);
    if (startIdx === -1 || endIdx === -1)
        return '';
    const i18nBlock = source.substring(startIdx, endIdx);
    return i18nBlock + '/// **collab_i18n_end**';
}
async function processOutput(context, newi18n, fileReference) {
    if (context.isTest)
        return [];
    if (!fileReference)
        throw new Error('[processOutput] Invalid fileReference');
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`[processOutput] Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[processOutput] invalid file: ${fileReference}`);
    const modelTS = await files.ts.getOrCreateModel();
    if (!modelTS)
        throw new Error(`[geti18nByFile] invalid models`);
    const source = modelTS.model.getValue();
    const newValue = replaceI18nBlock(source, newi18n);
    const paramsTs = { ...fileInfo, content: newValue, versionRef: new Date().toISOString(), extension: ".ts" };
    await updateStorFile(paramsTs);
    return [];
}
function replaceI18nBlock(content, newBlock) {
    const regex = /\/\/\/\s\*\*collab_i18n_start\*\*[\s\S]*?\/\/\/\s\*\*collab_i18n_end\*\*/g;
    return content.replace(regex, newBlock);
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMolecule] Invalid storFile');
    const models = await file.getOrCreateModel();
    models.model.pushEditOperations([], [{
            range: models.model.getFullModelRange(),
            text: params.content,
        }], () => null);
    mls.editor.forceModelUpdate(models.model);
    await waitModelIdle(models);
    return models;
}
const system1 = `
<!-- modelType: codeinstruct -->

<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You are a translation specialist responsible for adding a new i18n language, following the established standard.

{{ skillLanguage }}

## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: Result;
    }

export type Result = {
    i18n: string,
    fileReference: string // same prompt
}

`;
//#endregion 
