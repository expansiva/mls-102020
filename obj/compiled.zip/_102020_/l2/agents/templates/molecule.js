/// <mls fileReference="_102020_/l2/agents/templates/molecule.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// MOLECULE TEMPLATE — EXECUTION-SAFE CONTRACT
// =============================================================================
// This file defines how an Molecule must be generated.
// CORE PRINCIPLES:
// - Molecules are UI-first components.
// - Molecules do NOT own business logic.
// - Molecules it should function independently.
// - Molecules NO use shadow root
// LLM must replace fileReference to new molecule name
// LLM must add clear and concise comments to improve code readability for humans.
import { html } from 'lit'; // import lit and all directives always from 'lit'
import { customElement, property } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from '/_100554_/l2/collabDecorators';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
/**
 * =============================================================================
 * I18N SECTION -
 * =============================================================================
 */
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    /// add more languagues if requested 
};
/// **collab_i18n_end**
/*
## Web Component tag rule
`kebab-case(folder)--kebab-case(component)-(project)`
*/
let TemplateMolecule = class TemplateMolecule extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.hint = '';
        this.label = '';
        // @propertyDataSource: A property bound to a single dynamic state. Example binding: "{{page1.name}}".
        // @propertyCompositeDataSource: A property composed of multiple dynamic states. Example: "Hello {{page1.userId}} - {{page1.userName}}".
        this.loading = false;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `<div>${this.msg.loading}</div>`;
        }
        return html `

            // Dont use slot system

            <div>
                <label>${this.label}</label>
                <input type="text" value=${this.value}></input>
                <small>${this.hint}</small>
            </div>
        `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], TemplateMolecule.prototype, "value", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], TemplateMolecule.prototype, "hint", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], TemplateMolecule.prototype, "label", void 0);
__decorate([
    property({ type: Boolean })
], TemplateMolecule.prototype, "loading", void 0);
TemplateMolecule = __decorate([
    customElement('agents--templates--molecule-102020')
], TemplateMolecule);
export { TemplateMolecule };
