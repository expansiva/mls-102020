/// <mls fileReference="_102020_/l2/agents/agentNewMoleculePlanner2.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { skill as skillMolecule } from '/_102020_/l2/skills/aura/moleculeGeneration2.js';
import { finishClarification } from "/_102027_/l2/aiAgentOrchestration.js";
import { skills as skillList } from '/_102020_/l2/skills/molecules/index';
export function createAgent() {
    return {
        agentName: "agentNewMoleculePlanner2",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "Agent Planner for a new moleculle",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    if (!mls.actualProject)
        throw new Error(`(${agent.agentName})[beforePromptStep] project invalid: ${mls.actualProject}`);
    const baseMolecule = await getBaseMolecule();
    const data = JSON.parse(userPrompt);
    const skillByGroup = await getGroupSkill(data.group);
    console.info({
        data,
        skillByGroup
    });
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                        .replace("{{ group }}", userPrompt)
                        .replace("{{project}}", mls.actualProject?.toString())
                        .replace("{{ skillMolecule }}", skillMolecule)
                        .replace("{{ groupSkill }}", skillByGroup)
                        .replace("{{systemBaseMolecule}}", baseMolecule)
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Planner...`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    if (!mls.actualProject)
        throw new Error(`(${agent.agentName})[beforePromptStep] project invalid: ${mls.actualProject}`);
    const data = JSON.parse(args);
    const baseMolecule = await getBaseMolecule();
    const groupDetails = skillList.find((item) => item.name === data.group);
    const skillByGroup = await getGroupSkill(data.group);
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: data.prompt || '',
        systemPrompt: system1
            .replace("{{ group }}", data.group)
            .replace("{{project}}", mls.actualProject?.toString())
            .replace("{{ skillMolecule }}", skillMolecule)
            .replace("{{ groupSkill }}", skillByGroup)
            .replace("{{systemBaseMolecule}}", baseMolecule)
    };
    return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'clarification' || !payload.json)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    if (context.isTest) {
        console.info(JSON.stringify(payload.json, null, 2));
    }
    return [];
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error(`[beforeClarificationStep] invalid task: undefined`);
    const intentsToClarification = processOutput(agent, context, parentStep, step, hookSequential, json);
    await import('/_102020_/l2/agents/agentNewMoleculePlannerClarification.js');
    const clariEl = document.createElement('agents--agent-new-molecule-planner-clarification-102020');
    clariEl.data = json;
    clariEl.addEventListener('clarification-finish', (e) => {
        const { detail } = e;
        const { value, action } = detail;
        const normalizedValue = `\`\`\`json \n ${JSON.stringify(value, null, 2)} \n \`\`\``;
        finishClarification(agent, step.stepId, parentStep.stepId, intentsToClarification, context, normalizedValue, action);
    });
    return clariEl;
}
function processOutput(agent, context, parentStep, step, hookSequential, suggestions) {
    console.log("processOutput === Suggestions");
    console.log(JSON.stringify(suggestions, null, 2));
    let status = 'completed';
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    const updateStatusAgent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepId: parentStep.stepId,
        status: 'completed'
    };
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepTitle: 'Preparing defs',
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentNewMoleculeDefs",
            prompt: `{{clarification}}`,
            rags: null,
        }
    };
    const intents = [newStep, updateStatusAgent, updateStatus];
    return intents;
}
async function getGroupSkill(group) {
    const path = skillList.find((item) => item.name === group)?.skillReference;
    if (!path)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    const module = await import(path);
    if (!module || !module.skill)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    if (typeof module.skill !== 'string')
        throw new Error(`[getGroupSkill] invalid type of skill: ${path}, must be string`);
    return module.skill;
}
async function getBaseMolecule() {
    const key = mls.stor.getKeyToFile({ project: 102020, shortName: 'moleculeBase', folder: '', extension: '.ts', level: 2 });
    const storFile = mls.stor.files[key];
    if (!storFile)
        return '';
    return await storFile.getContent();
}
const system1 = `
<!-- modelType: codeinstruct -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You are a requirements analyst responsible for defining the functional and visual requirements of a new web component (molecule) that will be built following an existing group contract.

You receive the group skill contract which already defines ALL available properties, slot tags, events, visual states, and rendering logic. Read it carefully and use it as your source of truth.

## YOUR TASK

1. Interpret the user prompt — understand what they want functionally and visually.
2. Map the user's intent to the group contract (properties, slot tags, events, visual states).
3. Define concrete functional requirements — specific behaviors the molecule must have.
4. Define concrete visual requirements — specific visual/layout decisions derived from the user prompt.

## CRITICAL RULES

- You MUST NOT define implementation details (no HTML structure, no CSS strategy, no framework patterns).
- You MUST NOT create new properties, events, or slot tags that are not in the group contract.
- You MUST NOT ask questions, request information, or ask for confirmation. The group contract is your source of truth — use it directly.
- Every requirement MUST be a concrete, actionable, declarative statement.
- If the user prompt is ambiguous, make a reasonable decision and state it as a requirement.
- Domain-specific content from the user prompt maps to slot tags, never to custom properties.

## WHAT MAKES A GOOD REQUIREMENT

BAD — asks questions or requests information:
- "Confirm which slot tags should represent nodes"
- "Inform if there are interaction requirements in the contract"  
- "I need the contract to map the properties correctly"

GOOD — concrete and actionable:
- "Each Node slot tag represents one box in the org chart. Nested Node tags create parent-child relationships."
- "Clicking a node with children toggles its expanded/collapsed state via the contract's expand event."
- "Nodes are laid out horizontally from left to right, with the root node on the far left."
- "Connection lines use right-angle paths from parent's right edge to child's left edge."


Identify the most appropriate name for this molecule. Always suggest with prefix 'ml', ex: ml-select-dropdown
Suggest the name of molecule and put in 'fileReference'. Format: _{{project}}_/l2/molecules/[groupName(LowerCase)]/[moleculeName].ts

## CONTEXT

## How molecules works in collab.codes
\`\`\`md
{{ skillMolecule }}
\`\`\`

## GroupName: {{ group }}

\`\`\`md
{{ groupSkill }}
\`\`\`

## Molecule Class Base
\`\`\`typescript
{{systemBaseMolecule}}
\`\`\`

## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "clarification";
        json: TClarification;
    }

export interface TClarification {
    fileReference: string,
    description: string,
    prompt: string, // same user prompt
    group: string,
    functionalRequirements: string[],
    visualRequirements: string[],
}
`;
//#endregion 
