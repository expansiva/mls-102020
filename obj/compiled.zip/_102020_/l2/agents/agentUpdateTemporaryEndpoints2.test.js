/// <mls shortName="agentUpdateTemporaryEndpoints2" project="102020" enhancement="_blank" folder="agents" />
export const integrations = [];
export const tests = [];
