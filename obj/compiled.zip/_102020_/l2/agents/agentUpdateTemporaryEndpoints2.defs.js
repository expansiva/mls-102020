"use strict";
/// <mls shortName="agentUpdateTemporaryEndpoints2" project="102020" enhancement="_blank" folder="agents" />
