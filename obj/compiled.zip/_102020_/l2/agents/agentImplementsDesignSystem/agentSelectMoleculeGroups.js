/// <mls fileReference="_102020_/l2/agents/agentImplementsDesignSystem/agentSelectMoleculeGroups.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { buildGroupList } from '/_102020_/l2/dsMatch/groupCatalog.js';
import { loadPagePlan, buildAgent1HumanPrompt, validateAgent1Output } from '/_102020_/l2/dsMatch/agent1.js';
export function createAgent() {
    return {
        agentName: "agentSelectMoleculeGroups",
        agentProject: 102020,
        agentFolder: "agents/agentImplementsDesignSystem",
        agentDescription: "Selects which molecule groups each organism of a page needs (Fase B / Agent1)",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const info = JSON.parse(userPrompt);
    const prompt = await buildPrompt(info.path);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: prompt },
            ],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: info.path,
            longTermMemory: { path: info.path, onlyStep: "true" },
        },
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const info = JSON.parse(args);
    const prompt = await buildPrompt(info.path);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: prompt,
        systemPrompt: system1,
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid params`);
    const payload = step.interaction?.payload?.[0];
    if (payload?.type !== 'flexible' || !payload.result) {
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid payload: ${JSON.stringify(payload)}`);
    }
    // Validate the LLM output against the valid group set (drops hallucinated groups).
    const raw = payload.result;
    const groups = await buildGroupList();
    const validGroups = new Set(groups.map(g => g.group));
    const validated = validateAgent1Output(raw, validGroups, raw.path);
    const dropped = countDropped(raw, validated);
    if (dropped > 0)
        console.warn(`(${agent.agentName}) dropped ${dropped} unknown group(s) from ${validated.path}`);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status: 'completed',
    };
    return [updateStatus];
}
async function buildPrompt(path) {
    const pagePlan = await loadPagePlan(path);
    const groups = await buildGroupList();
    return buildAgent1HumanPrompt(path, pagePlan, groups);
}
function countDropped(raw, validated) {
    const rawCount = Array.isArray(raw?.perOrganism)
        ? raw.perOrganism.reduce((n, o) => n + (Array.isArray(o?.groups) ? o.groups.length : 0), 0)
        : 0;
    const keptCount = validated.perOrganism.reduce((n, o) => n + o.groups.length, 0);
    return Math.max(0, rawCount - keptCount);
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You must return ONLY a valid JSON object. No preamble, no explanation, no markdown
fences, no text before or after the JSON. Start your response with { and end with }

## Task
For each organism of the page, decide which molecule GROUPS its UI needs. Map an
organism to a group only when the group's purpose DIRECTLY and OBVIOUSLY matches a
UI need implied by the organism's purpose, userActions and fields.

## Rules
- Before adding a group, ask: "Does this organism clearly need this kind of UI?" If
  it requires any rationalization or indirect reasoning, the answer is NO — omit it.
- An organism may need several groups (e.g. a form with text + number + date inputs),
  one group, or none. A shorter accurate answer beats a longer wrong one.
- Choose group names EXACTLY as listed under "Molecule groups" (camelCase). Never
  invent a group. If no listed group fits a need, omit it.
- Do NOT pick a group as a generic fallback. Omission is correct when nothing fits.
- Decide GROUPS only — do NOT pick a specific variant/molecule (that is done later,
  deterministically, from the design system).

## Output format

export type Output = {
  type: "flexible";
  result: {
    path: string;
    perOrganism: Array<{
      organismName: string;
      groups: string[]; // camelCase, exactly as listed in the prompt
    }>;
  };
};

`;
//#endregion
