/// <mls fileReference="_102020_/l2/plugins/selectProject.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import '/_102020_/l2/plugins/markdownViewer.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Select Project',
    desc: 'A project is a deliverable within an organization — it contains pages, components, and all generated code.',
    allTitle: 'All Projects',
    allDesc: 'Overview of all projects in this organization.',
    customTitle: 'New Project',
    customDesc: 'Create a new project within this organization.',
    needsOrg: 'Select an organization first to see the available projects.',
    edit: 'Edit',
    cancel: 'Cancel',
    save: 'Save',
    loading: 'Loading README…',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Selecionar Projeto',
        desc: 'Um projeto é uma entrega dentro de uma organização — contém páginas, componentes e todo o código gerado.',
        allTitle: 'Todos os Projetos',
        allDesc: 'Visão geral de todos os projetos desta organização.',
        customTitle: 'Novo Projeto',
        customDesc: 'Crie um novo projeto dentro desta organização.',
        needsOrg: 'Selecione uma organização primeiro para ver os projetos disponíveis.',
        edit: 'Editar',
        cancel: 'Cancelar',
        save: 'Salvar',
        loading: 'Carregando README…',
    },
    es: {
        title: 'Seleccionar Proyecto',
        desc: 'Un proyecto es un entregable dentro de una organización — contiene páginas, componentes y todo el código generado.',
        allTitle: 'Todos los Proyectos',
        allDesc: 'Visión general de todos los proyectos de esta organización.',
        customTitle: 'Nuevo Proyecto',
        customDesc: 'Cree un nuevo proyecto dentro de esta organización.',
        needsOrg: 'Seleccione una organización primero para ver los proyectos disponibles.',
        edit: 'Editar',
        cancel: 'Cancelar',
        save: 'Guardar',
        loading: 'Cargando README…',
    },
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectProject = class PluginSelectProject extends StateLitElement {
    constructor() {
        super(...arguments);
        this.selectedOrg = null;
        this.value = null;
        this._editing = false;
        this._editText = '';
        this._readme = null;
        this._readmeLoading = false;
    }
    willUpdate(changed) {
        if (changed.has('value') || changed.has('selectedOrg')) {
            this._editing = false;
            this._readme = null;
            const project = this._selectedProject;
            if (project)
                this._loadReadme(project.project);
        }
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }
    get _isAll() {
        return this.value === 0;
    }
    get _isCustom() {
        return this.selectedOrg !== null && this.value !== null && this.value > this.selectedOrg.projects.length;
    }
    get _selectedProject() {
        if (!this.selectedOrg || this.value === null || this.value <= 0 || this.value > this.selectedOrg.projects.length)
            return null;
        return this.selectedOrg.projects[this.value - 1];
    }
    createRenderRoot() { return this; }
    render() {
        if (!this.selectedOrg)
            return this._renderNeedsOrg();
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    // ─── Async README load ────────────────────────────────────────────
    async _loadReadme(projectId) {
        this._readmeLoading = true;
        this.requestUpdate();
        try {
            const key = mls.stor.getKeyToFile({ project: projectId, level: 0, shortName: 'README', folder: '', extension: '.md' });
            let storFile = mls.stor.files[key];
            if (!storFile) {
                const params = {
                    shortName: 'README',
                    project: projectId,
                    folder: '',
                    level: 0,
                    source: '# README\n\nProject description here.',
                    extension: '.md',
                };
                storFile = await createStorFile(params, false, false, false);
            }
            this._readme = storFile ? await storFile.getContent() : '';
        }
        catch {
            this._readme = '';
        }
        this._readmeLoading = false;
        this.requestUpdate();
    }
    // ─── Scenario renders ─────────────────────────────────────────────
    _renderNeedsOrg() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, null, this.msg.desc)}
                ${this._renderNotice(this.msg.needsOrg)}
            </div>
        `;
    }
    _renderSelected() {
        const project = this._selectedProject;
        const org = this.selectedOrg;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, null, this.msg.desc)}
                ${project ? this._renderSelectedProjectDetail(project, org) : nothing}
            </div>
        `;
    }
    _renderSelectedProjectDetail(project, org) {
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5
            ">
                <div class="flex items-center gap-2">
                    <span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">${org.name}</span>
                    <span class="text-gray-300 dark:text-gray-700">/</span>
                    <span class="text-xs font-semibold text-gray-700 dark:text-gray-300">${project.name}</span>
                </div>
            </div>

            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-3 flex flex-col gap-2
            ">
                ${this._readmeLoading
            ? html `<span class="text-xs text-gray-400 dark:text-gray-600 italic">${this.msg.loading}</span>`
            : this._editing
                ? this._renderEditMode()
                : this._renderViewMode()}
            </div>
        `;
    }
    _renderViewMode() {
        const content = this._readme ?? '';
        return html `
            <div class="flex items-start gap-2">
                <div class="flex-1 min-w-0">
                    ${content
            ? html `<plugins--markdown-viewer-102020 .text=${content}></plugins--markdown-viewer-102020>`
            : html `<span class="text-xs text-gray-400 dark:text-gray-600 italic">—</span>`}
                </div>
                <button
                    class="
                        shrink-0 text-[10px] px-2 py-0.5 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-400 dark:text-gray-600
                        hover:text-gray-600 dark:hover:text-gray-400
                        hover:border-gray-300 dark:hover:border-gray-600
                        transition-colors
                    "
                    @click=${() => { this._editText = this._readme ?? ''; this._editing = true; }}
                >${this.msg.edit}</button>
            </div>
        `;
    }
    _renderEditMode() {
        return html `
            <textarea
                class="
                    w-full text-xs font-mono leading-relaxed resize-none
                    bg-white dark:bg-gray-900
                    border border-gray-300 dark:border-gray-700 rounded-md
                    px-2.5 py-2
                    text-gray-700 dark:text-gray-300
                    focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                "
                rows="6"
                .value=${this._editText}
                @input=${(e) => { this._editText = e.target.value; }}
            ></textarea>
            <div class="flex justify-end gap-2">
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-500 dark:text-gray-400
                        hover:bg-gray-100 dark:hover:bg-gray-800
                        transition-colors
                    "
                    @click=${() => { this._editing = false; }}
                >${this.msg.cancel}</button>
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors
                    "
                    @click=${() => { this._readme = this._editText; this._editing = false; }}
                >${this.msg.save}</button>
            </div>
        `;
    }
    _renderAll() {
        const org = this.selectedOrg;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.allTitle, null, this.msg.allDesc)}
                ${org.projects.length === 0
            ? nothing
            : html `
                        <div class="flex flex-col gap-1.5">
                            ${org.projects.map((p, i) => this._renderProjectCard(p, i + 1))}
                        </div>
                    `}
            </div>
        `;
    }
    _renderCustom() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.customTitle, null, this.msg.customDesc)}
            </div>
        `;
    }
    // ─── Shared helpers ───────────────────────────────────────────────
    _renderHeader(title, badge, description) {
        return html `
            <div class="flex flex-col gap-1">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    ${badge ? html `
                        <span class="
                            text-[10px] font-mono px-1.5 py-0.5 rounded
                            bg-gray-100 dark:bg-gray-800
                            text-gray-500 dark:text-gray-400
                        ">${badge}</span>
                    ` : nothing}
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">
                    ${description}
                </span>
            </div>
        `;
    }
    _renderNotice(message) {
        return html `
            <div class="
                rounded-lg border border-amber-200 dark:border-amber-800/40
                bg-amber-50 dark:bg-amber-900/10
                px-3 py-2.5
            ">
                <span class="text-[11px] text-amber-600 dark:text-amber-400 leading-relaxed">
                    ${message}
                </span>
            </div>
        `;
    }
    _renderProjectCard(project, selectValue) {
        const org = this.selectedOrg;
        const clickable = selectValue !== undefined;
        return html `
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center gap-2
                    ${clickable ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors' : ''}
                "
                @click=${clickable ? () => this._dispatchSelect(selectValue) : nothing}
            >
                <span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">${org.name}</span>
                <span class="text-gray-300 dark:text-gray-700">/</span>
                <span class="text-xs font-medium text-gray-700 dark:text-gray-300">${project.name}</span>
            </div>
        `;
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-project', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectProject.prototype, "selectedOrg", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectProject.prototype, "value", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_editing", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_editText", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_readme", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_readmeLoading", void 0);
PluginSelectProject = __decorate([
    customElement('plugins--select-project-102020')
], PluginSelectProject);
export { PluginSelectProject };
