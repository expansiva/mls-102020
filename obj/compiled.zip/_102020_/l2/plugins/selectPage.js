/// <mls fileReference="_102020_/l2/plugins/selectPage.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { getAuraState } from '/_102020_/l2/auraState.js';
import { getContentByMlsPath } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
import { isPageStaleByDefs } from '/_102020_/l2/dsMatch/dsVersion.js';
import '/_102020_/l2/plugins/navHeader.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Pages',
    desc: 'Pages of the selected module. Filtered by active device when one is selected.',
    allTitle: 'All Pages',
    allDesc: 'All pages found for the selected module and device.',
    customTitle: 'New Page',
    customDesc: 'Create a new page in this module.',
    noModule: 'No module selected.',
    noPages: 'No pages found for this module.',
    noResults: 'No pages match your search.',
    createNew: 'New Page',
    searchPlaceholder: 'Search pages…',
    inDevelopment: 'In development',
    devices: 'Devices',
    notCreated: 'Pages have not been created for this layout / design system combination.',
    generatePages: 'Generate pages',
    outdated: 'Outdated',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Páginas',
        desc: 'Páginas do módulo selecionado. Filtradas pelo device ativo quando um estiver selecionado.',
        allTitle: 'Todas as Páginas',
        allDesc: 'Todas as páginas encontradas para o módulo e device selecionados.',
        customTitle: 'Nova Página',
        customDesc: 'Crie uma nova página neste módulo.',
        noModule: 'Nenhum módulo selecionado.',
        noPages: 'Nenhuma página encontrada para este módulo.',
        noResults: 'Nenhuma página corresponde à sua busca.',
        createNew: 'Nova Página',
        searchPlaceholder: 'Buscar páginas…',
        inDevelopment: 'Em desenvolvimento',
        devices: 'Dispositivos',
        notCreated: 'As páginas não foram criadas para esta combinação de layout / design system.',
        generatePages: 'Gerar páginas',
        outdated: 'Desatualizada',
    },
    es: {
        title: 'Páginas',
        desc: 'Páginas del módulo seleccionado. Filtradas por dispositivo activo cuando hay uno seleccionado.',
        allTitle: 'Todas las Páginas',
        allDesc: 'Todas las páginas encontradas para el módulo y dispositivo seleccionados.',
        customTitle: 'Nueva Página',
        customDesc: 'Cree una nueva página en este módulo.',
        noModule: 'Ningún módulo seleccionado.',
        noPages: 'No se encontraron páginas para este módulo.',
        noResults: 'Ninguna página coincide con su búsqueda.',
        createNew: 'Nueva Página',
        searchPlaceholder: 'Buscar páginas…',
        inDevelopment: 'En desarrollo',
        devices: 'Dispositivos',
        notCreated: 'Las páginas no se han creado para esta combinación de layout / design system.',
        generatePages: 'Generar páginas',
        outdated: 'Desactualizada',
    },
};
// ─── Constants ───────────────────────────────────────────────────────
const DEVICE_SUB_PATHS = {
    1: 'web/desktop',
    2: 'web/mobile',
    3: 'android',
    4: 'ios',
};
const DEVICE_LABELS = {
    'web/desktop': 'Web Desktop',
    'web/mobile': 'Web Mobile',
    'android': 'Android',
    'ios': 'iOS',
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectPage = class PluginSelectPage extends StateLitElement {
    constructor() {
        super(...arguments);
        this.selectedModule = null;
        this.value = null;
        this.reloadToken = 0;
        this._pages = [];
        this._search = '';
        this._activeDevice = null;
        this._pagesNotCreated = false;
        // page name → true when generated under an older DS version (needs re-materialize).
        this._staleByName = {};
    }
    connectedCallback() {
        super.connectedCallback();
        this._loadPages();
    }
    willUpdate(changed) {
        if (changed.has('selectedModule') || changed.has('reloadToken')) {
            this._search = '';
            this._loadPages();
        }
        if (changed.has('value')) {
            this._search = '';
        }
    }
    get msg() {
        return messages[this.getMessageKey(messages)];
    }
    get _isAll() { return this.value === 0; }
    get _isCustom() { return this.value !== null && this.value > this._pages.length; }
    get _selectedPage() {
        if (this.value === null || this.value <= 0 || this.value > this._pages.length)
            return null;
        return this._pages[this.value - 1];
    }
    // ─── Page Loading ─────────────────────────────────────────────────
    get _modulePath() {
        return this.selectedModule?.path ?? getAuraState().actualModule ?? null;
    }
    get _moduleName() {
        return this.selectedModule?.name ?? getAuraState().actualModule ?? null;
    }
    async _loadPages() {
        this._pages = [];
        this._pagesNotCreated = false;
        const modulePath = this._modulePath;
        if (!modulePath) {
            this._dispatchConfig();
            return;
        }
        const project = getAuraState().actualProject;
        const activeDevicePath = getAuraState().actualDevice;
        this._activeDevice = activeDevicePath ? (DEVICE_LABELS[activeDevicePath] ?? null) : null;
        // The page variation folder is page<layout><designSystem> (e.g. page11 =
        // layout 1, DS 1). Build it from the current aura selection.
        const layout = getAuraState().actualLayout ?? 1;
        const ds = getAuraState().actualDesignSystem ?? 1;
        const variation = `page${layout}${ds}`;
        // Pages now live in the project config.json (l0). Read the stor content
        // and pull the frontend pages for the selected module.
        let pages = [];
        try {
            const content = await getContentByMlsPath(`_${project}_/l0/config.json`);
            if (!content)
                throw new Error('config.json not found');
            const config = JSON.parse(content);
            const moduleDef = config?.projects?.[String(project)]?.modules
                ?.find((m) => m.moduleId === modulePath);
            pages = moduleDef?.frontend?.pages ?? [];
        }
        catch {
            this._dispatchConfig();
            this.requestUpdate();
            return;
        }
        const pageMap = new Map();
        let candidateCount = 0;
        for (const page of pages) {
            // source: e.g. "l2/cafeFlow/web/desktop/page11/dashboardGerente.ts"
            const source = page.source ?? '';
            const relative = source.replace(/^\.?\//, '').replace(/\.ts$/, '');
            const levelMatch = relative.match(/^l(\d+)\/(.+)$/);
            if (!levelMatch)
                continue;
            const level = parseInt(levelMatch[1], 10);
            const afterLevel = levelMatch[2];
            const lastSlash = afterLevel.lastIndexOf('/');
            if (lastSlash < 0)
                continue;
            const rawFolder = afterLevel.substring(0, lastSlash);
            const shortName = afterLevel.substring(lastSlash + 1);
            if (!shortName)
                continue;
            let devicePath = null;
            for (const dp of Object.values(DEVICE_SUB_PATHS)) {
                if (rawFolder.includes(`/${dp}/`) || rawFolder.endsWith(`/${dp}`)) {
                    devicePath = dp;
                    break;
                }
            }
            if (!devicePath)
                continue;
            if (activeDevicePath && devicePath !== activeDevicePath)
                continue;
            // Swap the source's variation segment (e.g. page11) for the current one.
            const folder = rawFolder.replace(/page\d+(\/|$)/, `${variation}$1`);
            candidateCount++;
            // Only surface pages that actually exist for this layout/DS combination.
            if (!this._fileExists(project, level, folder, shortName))
                continue;
            const name = page.pageId || shortName;
            if (!pageMap.has(name)) {
                const file = { project, folder, shortName, level, extension: '.ts' };
                pageMap.set(name, { devices: new Set(), file });
            }
            pageMap.get(name).devices.add(devicePath);
        }
        this._pages = Array.from(pageMap.entries())
            .map(([name, { devices, file }]) => ({ name, devices: Array.from(devices).sort(), file }))
            .sort((a, b) => a.name.localeCompare(b.name));
        // Config lists pages for this module/device, but none exist for the
        // current variation → offer to generate them.
        this._pagesNotCreated = candidateCount > 0 && this._pages.length === 0;
        this._dispatchConfig();
        this.requestUpdate();
        this._autoSelectActivePage();
        this._loadStaleness();
    }
    // Flag pages whose generated defs were stamped under an older DS version
    // (effective rules or molecule catalog changed since). Only meaningful for
    // non-default design systems (the default DS / origin pages carry no stamp).
    async _loadStaleness() {
        this._staleByName = {};
        const module = this._modulePath;
        const ds = getAuraState().actualDesignSystem ?? 1;
        if (!module || !ds || ds <= 1 || this._pages.length === 0)
            return;
        const results = await Promise.all(this._pages.map(async (p) => {
            try {
                const stale = await isPageStaleByDefs({ project: p.file.project, folder: p.file.folder ?? '', shortName: p.file.shortName }, module, ds);
                return [p.name, stale];
            }
            catch {
                return [p.name, false];
            }
        }));
        const map = {};
        for (const [name, stale] of results)
            map[name] = stale;
        this._staleByName = map;
        this.requestUpdate();
    }
    // Re-fire the select event for the page already active in the state, so the
    // preview repaints when this component (re)loads.
    _autoSelectActivePage() {
        const activePage = getAuraState().actualPage;
        if (!activePage)
            return;
        const index = this._pages.findIndex(p => p.file.shortName === activePage.shortName &&
            p.file.project === activePage.project);
        if (index < 0)
            return;
        this._dispatchSelect(index + 1);
    }
    _fileExists(project, level, folder, shortName) {
        try {
            const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension: '.ts' });
            const file = mls.stor.files[key];
            return !!file && file.status !== 'deleted';
        }
        catch {
            return false;
        }
    }
    _dispatchConfig() {
        const labels = { 0: 'All' };
        this._pages.forEach((p, i) => { labels[i + 1] = p.name; });
        labels[this._pages.length + 1] = '+';
        this.dispatchEvent(new CustomEvent('page-config', {
            detail: {
                min: 0,
                max: this._pages.length + 1,
                labels,
                pages: this._pages.map(p => ({ name: p.name, file: p.file })),
            },
            bubbles: true,
            composed: true,
        }));
    }
    createRenderRoot() { return this; }
    render() {
        if (!this._modulePath)
            return this._renderNoModule();
        if (this._pagesNotCreated)
            return this._renderNotCreated();
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    // ─── Scenario renders ─────────────────────────────────────────────
    _renderNoModule() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader()}
                <div class="rounded-lg border border-amber-200 dark:border-amber-800/40 bg-amber-50 dark:bg-amber-900/10 px-3 py-2.5">
                    <span class="text-sm text-amber-600 dark:text-amber-400">${this.msg.noModule}</span>
                </div>
            </div>
        `;
    }
    _renderHeader(value = 0, max = 1) {
        return html `
            <plugins--nav-header-102020
                .fixedLabel=${this.msg.title}
                .itemName=${this.msg.allTitle}
                .desc=${this.msg.desc}
                .value=${value}
                .min=${0}
                .max=${max}
                @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
            ></plugins--nav-header-102020>
        `;
    }
    _renderSelected() {
        const page = this._selectedPage;
        const max = this._pages.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${page?.name ?? ''}
                    .desc=${this.msg.desc}
                    .value=${this.value ?? 0}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>
                ${page ? this._renderPageDetail(page) : nothing}
            </div>
        `;
    }
    _renderPageDetail(page) {
        return html `
            <div class="rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50 px-3 py-2.5 flex flex-col gap-2">
                <div class="flex items-baseline gap-1">
                    <span class="text-xs text-gray-400 dark:text-gray-500">${this._moduleName}/</span>
                    <span class="text-sm font-semibold text-gray-700 dark:text-gray-200">${page.name}</span>
                    ${this._staleByName[page.name] ? html `
                        <span class="ml-auto text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400">
                            ${this.msg.outdated}
                        </span>
                    ` : nothing}
                </div>
                <div class="flex items-center gap-1 flex-wrap">
                    <span class="text-xs text-gray-400 dark:text-gray-600">${this.msg.devices}:</span>
                    ${page.devices.map(d => html `
                        <span class="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">
                            ${DEVICE_LABELS[d] ?? d}
                        </span>
                    `)}
                </div>
            </div>
        `;
    }
    _renderAll() {
        const q = this._search.toLowerCase();
        const filtered = this._pages
            .map((p, i) => ({ p, selectValue: i + 1 }))
            .filter(({ p }) => !q || p.name.toLowerCase().includes(q));
        const max = this._pages.length + 1;
        const activePage = getAuraState().actualPage;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${this.msg.allTitle}
                    .desc=${this.msg.allDesc}
                    .value=${0}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>

                ${this._activeDevice ? html `
                    <div class="flex items-center gap-1.5 px-1">
                        <div class="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></div>
                        <span class="text-xs text-indigo-600 dark:text-indigo-400 font-medium">${this._activeDevice}</span>
                    </div>
                ` : nothing}

                <button
                    class="
                        self-end text-sm px-2.5 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap cursor-pointer
                    "
                    @click=${() => this._dispatchSelect(max)}
                >+ ${this.msg.createNew}</button>

                <input
                    type="text"
                    .value=${this._search}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-sm px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @input=${(e) => { this._search = e.target.value; }}
                />

                ${this._pages.length === 0
            ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noPages}</span>`
            : filtered.length === 0
                ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                : html `
                            <div class="flex flex-col gap-1.5">
                                ${filtered.map(({ p, selectValue }) => {
                    const isActive = !!activePage
                        && p.file.shortName === activePage.shortName
                        && p.file.project === activePage.project;
                    return this._renderPageCard(p, selectValue, isActive);
                })}
                            </div>
                        `}
            </div>
        `;
    }
    _renderCustom() {
        const max = this._pages.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${this.msg.customTitle}
                    .desc=${this.msg.customDesc}
                    .value=${max}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>
                <div class="rounded-lg border border-amber-200 dark:border-amber-800/40 bg-amber-50 dark:bg-amber-900/10 px-3 py-2.5">
                    <span class="text-sm text-amber-600 dark:text-amber-400">${this.msg.inDevelopment}</span>
                </div>
            </div>
        `;
    }
    _renderNotCreated() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader()}

                ${this._activeDevice ? html `
                    <div class="flex items-center gap-1.5 px-1">
                        <div class="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></div>
                        <span class="text-xs text-indigo-600 dark:text-indigo-400 font-medium">${this._activeDevice}</span>
                    </div>
                ` : nothing}

                <div class="rounded-lg border border-amber-200 dark:border-amber-800/40 bg-amber-50 dark:bg-amber-900/10 px-3 py-2.5">
                    <span class="text-sm text-amber-600 dark:text-amber-400">${this.msg.notCreated}</span>
                </div>

                <button
                    class="
                        self-start text-sm px-3 py-1.5 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap cursor-pointer
                    "
                    @click=${() => this._dispatchGenerate()}
                >${this.msg.generatePages}</button>
            </div>
        `;
    }
    // ─── Shared helpers ───────────────────────────────────────────────
    _renderPageCard(page, selectValue, isActive = false) {
        return html `
            <div
                class="
                    rounded-lg border px-3 py-2.5 flex items-center gap-2
                    cursor-pointer transition-colors
                    ${isActive
            ? 'border-emerald-200 dark:border-emerald-700/50 bg-emerald-50 dark:bg-emerald-900/10 hover:bg-emerald-100 dark:hover:bg-emerald-900/20'
            : 'border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50 hover:bg-gray-100 dark:hover:bg-gray-800/70'}
                "
                @click=${() => this._dispatchSelect(selectValue)}
            >
                ${isActive ? html `<div class="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400 shrink-0"></div>` : nothing}
                <div class="flex-1 flex items-baseline gap-1 min-w-0">
                    <span class="text-[10px] text-gray-400 dark:text-gray-600 shrink-0">${this._moduleName}/</span>
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300 truncate">${page.name}</span>
                </div>
                <div class="flex items-center gap-1 shrink-0">
                    ${this._staleByName[page.name] ? html `
                        <span class="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400">
                            ${this.msg.outdated}
                        </span>
                    ` : nothing}
                    ${page.devices.map(d => html `
                        <span class="text-[10px] font-medium px-1 py-0.5 rounded bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400">
                            ${DEVICE_LABELS[d]?.replace('Web ', '') ?? d}
                        </span>
                    `)}
                </div>
            </div>
        `;
    }
    _dispatchSelect(value) {
        const entry = value > 0 && value <= this._pages.length ? this._pages[value - 1] : null;
        this.dispatchEvent(new CustomEvent('select-page', {
            detail: { value, file: entry?.file ?? null },
            bubbles: true,
            composed: true,
        }));
    }
    _dispatchGenerate() {
        this.dispatchEvent(new CustomEvent('generate-pages', {
            detail: {
                module: this._modulePath,
                device: getAuraState().actualDevice,
                layout: getAuraState().actualLayout,
                designSystem: getAuraState().actualDesignSystem,
            },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectPage.prototype, "selectedModule", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectPage.prototype, "value", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectPage.prototype, "reloadToken", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_pages", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_search", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_activeDevice", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_pagesNotCreated", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_staleByName", void 0);
PluginSelectPage = __decorate([
    customElement('plugins--select-page-102020')
], PluginSelectPage);
export { PluginSelectPage };
