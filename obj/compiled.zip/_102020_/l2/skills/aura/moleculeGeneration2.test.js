/// <mls fileReference="_102020_/l2/skills/aura/moleculeGeneration2.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
