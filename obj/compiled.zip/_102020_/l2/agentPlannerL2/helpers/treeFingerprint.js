/// <mls fileReference="_102020_/l2/agentPlannerL2/helpers/treeFingerprint.ts" enhancement="_blank"/>
/** Snapshot an in-memory bag. Each item supplies its own relative path. */
export function snapshotEntries(entries) {
    const out = {};
    for (const entry of entries)
        out[entry.rel] = entry.fingerprint;
    return out;
}
export function diffTrees(before, after) {
    const created = [];
    const modified = [];
    const deleted = [];
    const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
    for (const key of [...keys].sort()) {
        const previous = before[key];
        const next = after[key];
        if (previous === undefined && next !== undefined)
            created.push(key);
        else if (previous !== undefined && next === undefined)
            deleted.push(key);
        else if (previous !== next)
            modified.push(key);
    }
    return { created, modified, deleted };
}
/** True when `rel` is `root` or a descendant. Both are posix paths. */
export function pathUnder(rel, root) {
    const a = posixPath(rel);
    const b = posixPath(root);
    if (!b)
        return false;
    return a === b || a.startsWith(`${b}/`);
}
/** Paths in the diff that sit outside every allowed root. */
export function changedOutside(diff, roots) {
    const all = [...diff.created, ...diff.modified, ...diff.deleted];
    return all.filter(rel => !roots.some(root => pathUnder(rel, root))).sort();
}
function posixPath(value) {
    return String(value || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
}
