/// <mls fileReference="_102020_/l2/agentPlannerL2/agentPlannerL2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { displayPath, setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { P2_AGENT_NAME, buildP2PlannedSteps, isP2StepId, loadP2Entry, moduleTokenOk, parseP2Invocation, p2InvocationRefusal, readP2Pipeline, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { drainWaitingSiblings, hooksFor, markAwaitingStep, p2StatusMessage, planIdOf, updateStatus, } from '/_102020_/l2/agentPlannerL2/helpers/p2Dispatch.js';
import '/_102020_/l2/agentPlannerL2/steps/entry10/agentP2Entry.js';
import '/_102020_/l2/agentPlannerL2/steps/menu20/agentP2Menu.js';
import '/_102020_/l2/agentPlannerL2/steps/needs30/agentP2Needs.js';
import '/_102020_/l2/agentPlannerL2/steps/effort40/agentP2Effort.js';
import '/_102020_/l2/agentPlannerL2/steps/workspaces20/agentP2Workspaces.js';
import '/_102020_/l2/agentPlannerL2/steps/contracts30/agentP2Contracts.js';
import '/_102020_/l2/agentPlannerL2/steps/shared40/agentP2Shared.js';
import '/_102020_/l2/agentPlannerL2/steps/requests50/agentP2Requests.js';
export function createAgent() {
    return {
        agentName: P2_AGENT_NAME,
        agentProject: 102020,
        agentFolder: 'agentPlannerL2',
        agentDescription: 'L2 planner — menu.json, needs.json and effort.json from a finished l4, driven by pool/l2',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const invocation = parseP2Invocation(userPrompt || context.message.content || '');
    const syntax = p2InvocationRefusal(invocation);
    if (syntax) {
        if (invocation.module && moduleTokenOk(invocation.module))
            setModuleRoot(invocation.module, null);
        return statusTask(agent, context, syntax);
    }
    const loaded = await loadP2Entry({
        kind: 'hand',
        moduleName: invocation.module,
        candidate: invocation.candidate,
    });
    if ('refusal' in loaded)
        return statusTask(agent, context, loaded.refusal);
    const entry = {
        thread: loaded.message.thread,
        file: displayPath(loaded.file),
        candidate: invocation.candidate,
    };
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentPlannerL2 deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: invocation.module },
            ],
            taskTitle: `plan l2 ${invocation.module}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'plannerL2',
                flowName: P2_AGENT_NAME,
                moduleName: invocation.module,
                thread: entry.thread,
                file: entry.file,
                ...(invocation.candidate ? { candidate: invocation.candidate } : {}),
            },
        },
    };
    const steps = buildP2PlannedSteps(invocation.module, entry, loaded.message).map(step => addStepIntent(context, step));
    return [addMessage, ...steps];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId, args || step.prompt);
    if (hooks?.beforePromptStep)
        return hooks.beforePromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isP2StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId, args || step.prompt);
    if (hooks?.afterPromptStep)
        return hooks.afterPromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isP2StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function notImplemented(context, parentStep, step, hookSequential, stepId) {
    const moduleName = memoryString(context, 'moduleName') || moduleNameFromPrompt(step);
    if (moduleName) {
        const pipeline = await readP2Pipeline(moduleName);
        if (pipeline)
            await markAwaitingStep(pipeline, stepId);
    }
    const traceMsg = `step ${stepId} not implemented yet`;
    return [
        ...drainWaitingSiblings(context, step, hookSequential, `stopped: awaiting step ${stepId}`, { onlyUnimplemented: true }),
        updateStatus(context, parentStep, step, hookSequential, 'completed', traceMsg),
    ];
}
function addStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function statusTask(agent, context, message) {
    const addMessage = p2StatusMessage(agent, context, message);
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Status',
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, addStepIntent(context, result)];
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function moduleNameFromPrompt(step) {
    try {
        const parsed = JSON.parse(String(step.prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName : '';
    }
    catch {
        return '';
    }
}
