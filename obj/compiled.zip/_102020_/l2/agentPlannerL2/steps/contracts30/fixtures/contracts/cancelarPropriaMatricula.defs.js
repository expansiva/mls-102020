/// <mls fileReference="_102047_/l2/mensalidadesAcademia/web/contracts/cancelarPropriaMatricula.defs.ts" enhancement="_blank"/>
export const qryListMatriculaRoute = 'mensalidadesAcademia.cancelarPropriaMatricula.qryListMatricula';
export const qryGetMatriculaRoute = 'mensalidadesAcademia.cancelarPropriaMatricula.qryGetMatricula';
export const cmdCancelarMatriculaRoute = 'mensalidadesAcademia.cancelarPropriaMatricula.cmdCancelarMatricula';
