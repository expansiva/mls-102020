/// <mls fileReference="_102047_/l2/mensalidadesAcademia/web/contracts/gerarMensalidadesDoMes.defs.ts" enhancement="_blank"/>
export const cmdGerarMensalidadesDoMesRoute = 'mensalidadesAcademia.gerarMensalidadesDoMes.cmdGerarMensalidadesDoMes';
