/// <mls fileReference="_102047_/l2/mensalidadesAcademia/web/contracts/matriculaCatalogue.defs.ts" enhancement="_blank"/>
export const qryListAlunoRoute = 'mensalidadesAcademia.matriculaCatalogue.qryListAluno';
export const qryListPlanoRoute = 'mensalidadesAcademia.matriculaCatalogue.qryListPlano';
export const cmdCreateMatriculaRoute = 'mensalidadesAcademia.matriculaCatalogue.cmdCreateMatricula';
