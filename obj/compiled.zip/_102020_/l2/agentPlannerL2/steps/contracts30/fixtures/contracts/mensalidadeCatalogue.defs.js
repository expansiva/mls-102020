/// <mls fileReference="_102047_/l2/mensalidadesAcademia/web/contracts/mensalidadeCatalogue.defs.ts" enhancement="_blank"/>
export const qryListMensalidadeRoute = 'mensalidadesAcademia.mensalidadeCatalogue.qryListMensalidade';
export const qryGetMensalidadeRoute = 'mensalidadesAcademia.mensalidadeCatalogue.qryGetMensalidade';
export const cmdCreatePagamentoRoute = 'mensalidadesAcademia.mensalidadeCatalogue.cmdCreatePagamento';
