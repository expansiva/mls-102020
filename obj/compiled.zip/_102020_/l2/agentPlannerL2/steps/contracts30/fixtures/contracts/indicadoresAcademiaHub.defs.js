/// <mls fileReference="_102047_/l2/mensalidadesAcademia/web/contracts/indicadoresAcademiaHub.defs.ts" enhancement="_blank"/>
export const qryInspectMensalidadeRoute = 'mensalidadesAcademia.indicadoresAcademiaHub.qryInspectMensalidade';
