/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/shared40/contracts.ts" enhancement="_blank"/>
import { moduleFile } from '/_102035_/l2/solution/fs.js';
import { collectionFieldName, isIdentityPath, } from '/_102020_/l2/agentPlannerL2/steps/contracts30/contracts.js';
export const P2_SHARED_SCHEMA_VERSION = '2026-09-18-p2-shared-v1';
/** The 20 keys of the 102039 shared `definition`. No others. */
export const P2_SHARED_KEYS = [
    'pageId',
    'pageName',
    'moduleName',
    'baseClassName',
    'routePattern',
    'sourceKind',
    'ownerIds',
    'operationIds',
    'origin',
    'contractRef',
    'layoutRef',
    'states',
    'actions',
    'scenaries',
    'destructiveCommandIds',
    'initialLoads',
    'dataBindings',
    'businessContextRefs',
    'navigationRefs',
    'automation',
];
/**
 * Named reader of each key in page11 / page21 / the shared skill.
 * A key without a reader must not be emitted.
 */
export const P2_SHARED_KEY_READERS = {
    pageId: 'genCfeSharedTs Input contract; genCfePage21 import path',
    pageName: 'genCfeSharedTs Input contract; genCfePage21 `{pageName}.js`',
    moduleName: 'genCfeSharedTs Input contract; genCfePage21 import path',
    baseClassName: 'genCfeSharedTs class name; genCfePage21 `extends Definition.baseClassName`',
    routePattern: 'genCfeSharedTs parse `Definition.routePattern` against the URL',
    sourceKind: 'genCfeSharedTs Input contract',
    ownerIds: 'genCfeSharedTs Input contract',
    operationIds: 'genCfeSharedTs Input contract',
    origin: 'genCfeSharedTs page origin from the workspace cut',
    contractRef: 'genCfeSharedTs `Definition.contractRef.tsPath` and `contracts[]`',
    layoutRef: 'genCfeSharedTs Input contract (future page11 defs path)',
    states: 'genCfeSharedTs `Definition.states[]`; page11/21 JSDoc `state <stateKey>`',
    actions: 'genCfeSharedTs `Definition.actions[]`; page11/21 JSDoc `action <actionId>`',
    scenaries: 'genCfePage11/21 skeleton: one `<Scene value>` per `scenaries[].value`',
    destructiveCommandIds: 'genCfePage11/21 / uiScenary contract: never become scenes',
    initialLoads: 'genCfeSharedTs `connectedCallback` runs `initialLoads[]`',
    dataBindings: 'genCfePage21 `Definition.dataBindings[]` is the structure source',
    businessContextRefs: 'genCfeSharedTs Input contract; page21 businessContext badge',
    navigationRefs: 'genCfeSharedTs Input contract',
    automation: 'genCfeSharedTs Input contract (`statePrefix` / `stateKeys` / `actionIds`)',
};
export const P2_SCENARY_KINDS = ['base', 'detail', 'command'];
export const P2_ACTION_KINDS = ['query', 'command', 'stateSetter'];
export const P2_STATE_KINDS = [
    'pageStatus', 'uiScenary', 'actionStatus', 'queryResult', 'input', 'commandOutput', 'actionError', 'businessContext',
];
export const P2_BINDING_KINDS = ['query', 'command'];
export const P2_INPUT_SOURCES = ['userInput', 'selectedEntity', 'routeParam'];
export const P2_PRESENTATIONS = ['form', 'selection', 'route'];
export const P2_SOURCE_KINDS = ['operation', 'landing'];
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const UI_SCENARY_HEADER = [
    'uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):',
    '  scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }',
    '  preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.',
    '  URL `?scenary=` is a request; the shared setter is the source of truth.',
    '  destructiveCommandIds never become scenes (confirmation stays a modal).',
].join('\n');
export function isP2ScenaryKind(value) {
    return P2_SCENARY_KINDS.includes(value);
}
export function isP2ActionKind(value) {
    return P2_ACTION_KINDS.includes(value);
}
export function isP2StateKind(value) {
    return P2_STATE_KINDS.includes(value);
}
export function isP2BindingKind(value) {
    return P2_BINDING_KINDS.includes(value);
}
export function isP2InputSource(value) {
    return P2_INPUT_SOURCES.includes(value);
}
export function isP2Presentation(value) {
    return P2_PRESENTATIONS.includes(value);
}
export function p2SharedFile(moduleName, workspaceId) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 2,
        folder: `${base.folder}/web/shared`,
        shortName: workspaceId,
        extension: '.defs.ts',
    };
}
export function sourceKindOf(workspaceKind) {
    return workspaceKind === 'hub' ? 'landing' : 'operation';
}
export function toPascalCase(value) {
    return value
        .split(/[^a-zA-Z0-9]+|(?=[A-Z])/)
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join('') || 'Item';
}
export function toKebabCase(value) {
    return value
        .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
        .replace(/[^a-zA-Z0-9]+/g, '-')
        .replace(/^-|-$/g, '')
        .toLowerCase();
}
export function callsOf(draft, workspaceId) {
    return draft.workspaces.find(item => item.workspaceId === workspaceId)?.calls.slice() || [];
}
/**
 * Deterministic keys the LLM must not invent: pageId, moduleName, baseClassName,
 * routePattern, sourceKind, ownerIds, operationIds, origin, contractRef, layoutRef,
 * businessContextRefs, navigationRefs. automation is assembled after judgment.
 */
export function deriveP2SharedBase(input) {
    const pageId = input.workspace.workspaceId;
    const moduleName = input.moduleName;
    const sourceKind = sourceKindOf(input.workspace.kind);
    const operationIds = input.calls.map(call => call.callName).filter(Boolean);
    const ownerIds = [
        `workspace:${pageId}`,
        ...operationIds.map(callName => `contract:${moduleName}.${pageId}.${callName}`),
    ];
    const owners = input.calls.map(call => ({
        kind: 'operation',
        id: call.callName,
        defPath: journeyDefPath(input.project, moduleName, input.workspace, input.sources, call.stepRef),
    }));
    return {
        pageId,
        moduleName,
        baseClassName: `${toPascalCase(moduleName)}${toPascalCase(pageId)}Base`,
        routePattern: `/${moduleName}/${pageId}`,
        sourceKind,
        ownerIds,
        operationIds,
        origin: {
            source: 'l4-journey',
            workspaceId: pageId,
            workspaceKind: sourceKind,
            actor: input.workspace.actorRefs[0] || '',
            entity: input.workspace.entityRef,
            owners,
            microUserFlow: {
                source: 'l4/story.steps',
                workflowSteps: [],
                operations: input.calls.map(call => ({
                    operationId: call.callName,
                    commandName: call.callName,
                    steps: [],
                })),
            },
        },
        contractRef: {
            tsPath: `_${input.project}_/l2/${moduleName}/web/contracts/${pageId}.ts`,
            contracts: input.calls.map(call => ({
                commandName: call.callName,
                routeConst: `${call.callName}Route`,
            })),
        },
        layoutRef: {
            defPath: `_${input.project}_/l2/${moduleName}/web/desktop/page11/${pageId}.defs.ts`,
            layoutId: `${toKebabCase(pageId)}-workspace`,
        },
        businessContextRefs: [],
        navigationRefs: [],
    };
}
/**
 * Mechanical starting cut from the contracts (CF `saveBaseSharedDefs` rules, local copy —
 * the planner graph must not import agentChangeFrontend). The model may change judgment.
 */
export function suggestP2SharedJudgment(workspace, calls, catalog, moduleName) {
    const pageId = workspace.workspaceId;
    const inputsByCall = new Map(calls.map(call => [call.callName, describeInputs(call, catalog)]));
    const scenaries = deriveUiScenaries(pageId, calls, inputsByCall);
    const destructiveIds = calls
        .filter(call => call.kind === 'command' && isDestructiveCommandName(call.callName))
        .map(call => call.callName);
    const states = buildStates(pageId, calls, inputsByCall, scenaries, catalog);
    const actions = buildActions(pageId, moduleName, calls, inputsByCall, states);
    const dataBindings = buildBindings(pageId, calls, inputsByCall);
    const initialLoads = calls
        .filter(call => call.kind === 'query' && qualifiesForInitialLoad(inputsByCall.get(call.callName) || []))
        .map(call => ({
        actionId: call.callName,
        stateKey: queryDataStateKey(pageId, call.callName),
    }));
    return {
        workspaceId: pageId,
        pageName: workspace.title,
        scenaries,
        states,
        dataBindings,
        initialLoads,
        actions,
        destructiveCommandIds: destructiveIds,
    };
}
export function assembleP2SharedDefinition(base, judgment) {
    const states = judgment.states.slice();
    const actions = judgment.actions.slice();
    return {
        pageId: base.pageId,
        pageName: judgment.pageName,
        moduleName: base.moduleName,
        baseClassName: base.baseClassName,
        routePattern: base.routePattern,
        sourceKind: base.sourceKind,
        ownerIds: base.ownerIds,
        operationIds: base.operationIds,
        origin: base.origin,
        contractRef: base.contractRef,
        layoutRef: base.layoutRef,
        states,
        actions,
        scenaries: judgment.scenaries,
        destructiveCommandIds: judgment.destructiveCommandIds,
        initialLoads: judgment.initialLoads,
        dataBindings: judgment.dataBindings,
        businessContextRefs: base.businessContextRefs,
        navigationRefs: base.navigationRefs,
        automation: {
            statePrefix: `ui.${base.pageId}`,
            stateKeys: states.map(state => state.stateKey).filter(Boolean),
            actionIds: actions.map(action => action.actionId).filter(Boolean),
        },
    };
}
export function emitP2SharedDefs(input) {
    const filePath = `_${input.project}_/l2/${input.moduleName}/web/shared/${input.workspaceId}.defs.ts`;
    const body = JSON.stringify(orderedDefinition(input.definition), null, 2);
    return [
        `/// <mls fileReference="${filePath}" enhancement="_blank"/>`,
        '',
        '/**',
        ...UI_SCENARY_HEADER.split('\n').map(line => ` * ${line}`),
        ' */',
        `export const definition = ${body} as const;`,
        '',
    ].join('\n');
}
export function orderedDefinition(definition) {
    const source = definition;
    const out = {};
    for (const key of P2_SHARED_KEYS)
        out[key] = source[key];
    return out;
}
export function normalizeP2SharedPayload(value, moduleName) {
    const root = record(value);
    return {
        schemaVersion: P2_SHARED_SCHEMA_VERSION,
        moduleName: memberId(text(root.moduleName) || moduleName),
        workspaces: list(root.workspaces).map(item => normalizeJudgment(item)).filter(workspace => workspace.workspaceId),
    };
}
export function buildP2SharedTool(schema) {
    return createP2ArtifactTool('submitP2Shared', 'Submit one shared definition judgment per workspace: scenaries, states, dataBindings, initialLoads, actions, destructiveCommandIds, pageName.', schema);
}
export function collectP2SharedBases(workspaces, contracts, sources, project) {
    return workspaces.workspaces.map(workspace => deriveP2SharedBase({
        project,
        moduleName: workspaces.moduleName,
        workspace,
        calls: callsOf(contracts, workspace.workspaceId),
        sources,
    }));
}
function describeInputs(call, catalog) {
    return call.inputFields.map(path => {
        const field = catalog.get(path);
        const name = field?.name || lastSegment(path);
        const identity = isIdentityPath(call.entityRef, path);
        const selected = identity && (call.shape === 'get' || call.shape === 'update' || call.shape === 'transition');
        return {
            name,
            path,
            source: selected ? 'selectedEntity' : 'userInput',
            presentation: selected ? 'selection' : 'form',
            required: field?.required === true || identity,
            tsType: field?.tsType || 'string',
            enumValues: field?.enumValues || [],
        };
    });
}
function deriveUiScenaries(pageId, calls, inputsByCall) {
    const queries = calls.filter(call => call.kind === 'query');
    const mutations = calls.filter(call => call.kind === 'command');
    const baseQuery = queries.find(call => call.shape === 'list' || call.shape === 'ddm') || queries[0];
    const scenaries = [{
            value: 'base',
            kind: 'base',
            commandName: baseQuery?.callName || '',
            preconditions: [],
        }];
    const inspect = queries.find(call => call.shape === 'get');
    const hasList = queries.some(call => call.shape === 'list');
    if (hasList && inspect) {
        scenaries.push({
            value: 'detail',
            kind: 'detail',
            commandName: inspect.callName,
            preconditions: preconditionKeys(pageId, inspect.callName, inputsByCall.get(inspect.callName) || []),
        });
    }
    for (const call of mutations) {
        if (isDestructiveCommandName(call.callName))
            continue;
        scenaries.push({
            value: commandScenaryValue(call.callName),
            kind: 'command',
            commandName: call.callName,
            preconditions: preconditionKeys(pageId, call.callName, inputsByCall.get(call.callName) || []),
        });
    }
    return scenaries;
}
export function isDestructiveCommandName(commandName) {
    const stripped = commandName.replace(/^cmd/i, '');
    const titled = stripped.charAt(0).toUpperCase() + stripped.slice(1);
    return /^(Delete|Cancel)(?=[A-Z]|$)/.test(titled);
}
export function commandScenaryValue(commandName) {
    if (!/^cmd/i.test(commandName))
        return commandName;
    const rest = commandName.replace(/^cmd/i, '');
    if (!rest)
        return commandName;
    return rest.charAt(0).toLowerCase() + rest.slice(1);
}
function preconditionKeys(pageId, callName, inputs) {
    return inputs
        .filter(field => field.required && (field.presentation === 'selection' || field.presentation === 'route'))
        .map(field => inputStateKey(pageId, callName, field.name));
}
function qualifiesForInitialLoad(inputs) {
    return !inputs.some(field => field.required && (field.source === 'userInput' || field.source === 'selectedEntity'));
}
function buildStates(pageId, calls, inputsByCall, scenaries, catalog) {
    const states = [
        {
            stateKey: `ui.${pageId}.status`,
            name: 'status',
            kind: 'pageStatus',
            defaultValue: '',
        },
        {
            stateKey: `ui.${pageId}.scenary`,
            name: 'uiScenary',
            kind: 'uiScenary',
            valueSet: (scenaries.length ? scenaries : [{ value: 'base' }]).map(scene => scene.value),
            defaultValue: 'base',
        },
    ];
    for (const call of calls) {
        const inputs = inputsByCall.get(call.callName) || [];
        states.push({
            stateKey: actionStatusStateKey(pageId, call.callName),
            name: `${call.callName}State`,
            kind: 'actionStatus',
            actionRef: call.callName,
            valueSet: ['idle', 'loading', 'success', 'error'],
            defaultValue: 'idle',
        });
        for (const field of inputs) {
            const state = {
                stateKey: inputStateKey(pageId, call.callName, field.name),
                name: inputStateName(call.callName, field.name),
                kind: 'input',
                source: field.source,
                presentation: field.presentation,
                contractRef: { commandName: call.callName, direction: 'input', field: field.name },
                defaultValue: defaultValueForType(field.tsType),
            };
            if (field.enumValues.length)
                state.valueSet = field.enumValues;
            states.push(state);
        }
        if (call.kind === 'query') {
            const paginated = call.shape === 'list';
            const itemsKey = collectionFieldName(call.entityRef);
            states.push({
                stateKey: queryDataStateKey(pageId, call.callName),
                name: `${call.callName}Data`,
                kind: 'queryResult',
                contractRef: { commandName: call.callName, direction: 'output' },
                outputShape: paginated ? 'paginated' : 'object',
                collection: paginated,
                defaultValue: paginated ? { [itemsKey]: [], total: 0 } : null,
            });
        }
        else {
            states.push({
                stateKey: commandOutputStateKey(pageId, call.callName),
                name: `${call.callName}Output`,
                kind: 'commandOutput',
                contractRef: { commandName: call.callName, direction: 'output' },
                defaultValue: null,
            });
            states.push({
                stateKey: actionErrorStateKey(pageId, call.callName),
                name: `${call.callName}Error`,
                kind: 'actionError',
                actionRef: call.callName,
                defaultValue: '',
            });
        }
    }
    void catalog;
    return states;
}
function buildActions(pageId, moduleName, calls, inputsByCall, states) {
    const queryIds = calls.filter(call => call.kind === 'query').map(call => call.callName);
    const actions = [];
    for (const call of calls) {
        const inputs = inputsByCall.get(call.callName) || [];
        const inputStateKeys = inputs.map(field => inputStateKey(pageId, call.callName, field.name));
        const isQuery = call.kind === 'query';
        const action = {
            actionId: call.callName,
            kind: isQuery ? 'query' : 'command',
            commandRef: call.callName,
            routeKey: `${moduleName}.${pageId}.${call.callName}`,
            purpose: call.callName,
            methodName: isQuery ? `load${toPascalCase(call.callName)}` : call.callName,
            handlerName: `handle${toPascalCase(call.callName)}Click`,
            inputStateKeys,
            routeParamInputStateKeys: inputs.filter(field => field.presentation === 'route').map(field => inputStateKey(pageId, call.callName, field.name)),
            selectedEntityInputStateKeys: inputs.filter(field => field.presentation === 'selection').map(field => inputStateKey(pageId, call.callName, field.name)),
            outputStateKeys: [isQuery ? queryDataStateKey(pageId, call.callName) : commandOutputStateKey(pageId, call.callName)],
            statusStateKey: actionStatusStateKey(pageId, call.callName),
        };
        if (!isQuery) {
            action.errorStateKey = actionErrorStateKey(pageId, call.callName);
            action.feedback = {
                successMessageKey: `action.${call.callName}.success`,
                errorMessageKey: `action.${call.callName}.error`,
                dismissible: true,
            };
            action.clearInputStateKeys = inputs
                .filter(field => field.presentation === 'form' || field.presentation === 'selection')
                .map(field => inputStateKey(pageId, call.callName, field.name));
            if (queryIds.length)
                action.refreshActionIds = queryIds.slice();
        }
        actions.push(action);
    }
    for (const state of states.filter(item => item.kind === 'input')) {
        actions.push({
            actionId: `set.${state.name}`,
            kind: 'stateSetter',
            stateKey: state.stateKey,
            methodName: `set${toPascalCase(state.name)}`,
            handlerName: `handle${toPascalCase(state.name)}Change`,
        });
    }
    return actions;
}
function buildBindings(pageId, calls, inputsByCall) {
    return calls.map(call => {
        const inputs = inputsByCall.get(call.callName) || [];
        const isQuery = call.kind === 'query';
        return {
            id: `binding.${pageId}.${call.callName}`,
            source: `bff.${call.callName}`,
            command: call.callName,
            description: call.callName,
            kind: isQuery ? 'query' : 'command',
            stateKey: isQuery ? queryDataStateKey(pageId, call.callName) : commandOutputStateKey(pageId, call.callName),
            inputStateKeys: inputs.map(field => inputStateKey(pageId, call.callName, field.name)),
            inputs: inputs.map(field => ({
                name: field.name,
                stateKey: inputStateKey(pageId, call.callName, field.name),
                source: field.source,
                required: field.required,
                presentation: field.presentation,
            })),
            selection: call.shape === 'list' ? 'single' : 'none',
        };
    });
}
function journeyDefPath(project, moduleName, workspace, sources, stepRef) {
    const journeyId = sources.journeys.find(journey => workspace.journeyRefs.includes(journey.journeyId) && journey.steps.some(step => step.stepId === stepRef))?.journeyId || workspace.journeyRefs[0] || '';
    return `_${project}_/l4/${moduleName}/journeys/${journeyId}.defs.ts`;
}
function inputStateKey(pageId, callName, fieldName) {
    return `ui.${pageId}.input.${callName}.${fieldName}`;
}
function inputStateName(callName, fieldName) {
    return `${callName}${toPascalCase(fieldName)}`;
}
function actionStatusStateKey(pageId, callName) {
    return `ui.${pageId}.action.${callName}.status`;
}
function queryDataStateKey(pageId, callName) {
    return `ui.${pageId}.data.${callName}`;
}
function commandOutputStateKey(pageId, callName) {
    return `ui.${pageId}.output.${callName}`;
}
function actionErrorStateKey(pageId, callName) {
    return `ui.${pageId}.action.${callName}.error`;
}
function defaultValueForType(tsType) {
    if (tsType === 'number')
        return 0;
    if (tsType === 'boolean')
        return false;
    return '';
}
function normalizeJudgment(value) {
    const source = record(value);
    return {
        workspaceId: memberId(text(source.workspaceId)),
        pageName: text(source.pageName),
        scenaries: list(source.scenaries).map(item => normalizeScenary(item)),
        states: list(source.states).map(item => normalizeState(item)),
        dataBindings: list(source.dataBindings).map(item => normalizeBinding(item)),
        initialLoads: list(source.initialLoads).map(item => normalizeLoad(item)),
        actions: list(source.actions).map(item => normalizeAction(item)),
        destructiveCommandIds: uniqueIds(source.destructiveCommandIds),
    };
}
function normalizeScenary(value) {
    const source = record(value);
    const kind = text(source.kind);
    return {
        value: text(source.value),
        kind: isP2ScenaryKind(kind) ? kind : '',
        commandName: text(source.commandName),
        preconditions: uniqueStrings(source.preconditions),
    };
}
function normalizeState(value) {
    const source = record(value);
    const kind = text(source.kind);
    const src = text(source.source);
    const presentation = text(source.presentation);
    const state = {
        stateKey: text(source.stateKey),
        name: text(source.name),
        kind: isP2StateKind(kind) ? kind : '',
        defaultValue: 'defaultValue' in source ? source.defaultValue : '',
    };
    const valueSet = uniqueStrings(source.valueSet);
    if (valueSet.length)
        state.valueSet = valueSet;
    if (text(source.actionRef))
        state.actionRef = text(source.actionRef);
    const contract = record(source.contractRef);
    if (text(contract.commandName)) {
        state.contractRef = {
            commandName: text(contract.commandName),
            direction: text(contract.direction) === 'input' ? 'input' : 'output',
            ...(text(contract.field) ? { field: text(contract.field) } : {}),
        };
    }
    if (text(source.outputShape))
        state.outputShape = text(source.outputShape);
    if (typeof source.collection === 'boolean')
        state.collection = source.collection;
    if (isP2InputSource(src))
        state.source = src;
    if (isP2Presentation(presentation))
        state.presentation = presentation;
    return state;
}
function normalizeAction(value) {
    const source = record(value);
    const kind = text(source.kind);
    const action = {
        actionId: text(source.actionId),
        kind: isP2ActionKind(kind) ? kind : '',
        methodName: text(source.methodName),
        handlerName: text(source.handlerName),
    };
    if (text(source.commandRef))
        action.commandRef = text(source.commandRef);
    if (text(source.routeKey))
        action.routeKey = text(source.routeKey);
    if (text(source.purpose))
        action.purpose = text(source.purpose);
    if (Array.isArray(source.inputStateKeys))
        action.inputStateKeys = uniqueStrings(source.inputStateKeys);
    if (Array.isArray(source.routeParamInputStateKeys))
        action.routeParamInputStateKeys = uniqueStrings(source.routeParamInputStateKeys);
    if (Array.isArray(source.selectedEntityInputStateKeys))
        action.selectedEntityInputStateKeys = uniqueStrings(source.selectedEntityInputStateKeys);
    if (Array.isArray(source.outputStateKeys))
        action.outputStateKeys = uniqueStrings(source.outputStateKeys);
    if (text(source.statusStateKey))
        action.statusStateKey = text(source.statusStateKey);
    if (text(source.errorStateKey))
        action.errorStateKey = text(source.errorStateKey);
    const feedback = record(source.feedback);
    if (text(feedback.successMessageKey) || text(feedback.errorMessageKey)) {
        action.feedback = {
            successMessageKey: text(feedback.successMessageKey),
            errorMessageKey: text(feedback.errorMessageKey),
            dismissible: feedback.dismissible !== false,
        };
    }
    if (Array.isArray(source.clearInputStateKeys))
        action.clearInputStateKeys = uniqueStrings(source.clearInputStateKeys);
    if (Array.isArray(source.refreshActionIds))
        action.refreshActionIds = uniqueStrings(source.refreshActionIds);
    if (text(source.stateKey))
        action.stateKey = text(source.stateKey);
    const prefill = record(source.prefill);
    if (text(prefill.command)) {
        action.prefill = {
            command: text(prefill.command),
            sourceStateKey: text(prefill.sourceStateKey),
            sourceOutputShape: text(prefill.sourceOutputShape),
            matchField: text(prefill.matchField),
            fields: list(prefill.fields).map(item => {
                const field = record(item);
                return { itemField: text(field.itemField), targetStateKey: text(field.targetStateKey) };
            }).filter(field => field.itemField && field.targetStateKey),
        };
    }
    return action;
}
function normalizeBinding(value) {
    const source = record(value);
    const kind = text(source.kind);
    return {
        id: text(source.id),
        source: text(source.source),
        command: text(source.command),
        description: text(source.description),
        kind: isP2BindingKind(kind) ? kind : '',
        stateKey: text(source.stateKey),
        inputStateKeys: uniqueStrings(source.inputStateKeys),
        inputs: list(source.inputs).map(item => {
            const field = record(item);
            const src = text(field.source);
            const presentation = text(field.presentation);
            return {
                name: text(field.name),
                stateKey: text(field.stateKey),
                source: isP2InputSource(src) ? src : 'userInput',
                required: field.required === true,
                presentation: isP2Presentation(presentation) ? presentation : 'form',
            };
        }),
        selection: text(source.selection) || 'none',
    };
}
function normalizeLoad(value) {
    const source = record(value);
    return {
        actionId: text(source.actionId),
        stateKey: text(source.stateKey),
    };
}
function createP2ArtifactTool(toolName, description, artifactSchema) {
    const result = { ...artifactSchema };
    const defs = result.$defs;
    delete result.$defs;
    delete result.$id;
    delete result.$schema;
    const parameters = {
        type: 'object',
        additionalProperties: false,
        required: ['type', 'result'],
        properties: {
            type: { type: 'string', const: 'flexible' },
            result,
        },
    };
    if (isRecord(defs))
        parameters.$defs = defs;
    return { type: 'function', function: { name: toolName, description, parameters } };
}
function uniqueIds(value) {
    return uniqueStrings(value).filter(item => MEMBER_ID.test(item) || item.length > 0);
}
function uniqueStrings(value) {
    const seen = new Set();
    const out = [];
    for (const item of list(value)) {
        const textValue = typeof item === 'string' ? item.trim() : '';
        if (!textValue || seen.has(textValue))
            continue;
        seen.add(textValue);
        out.push(textValue);
    }
    return out;
}
function lastSegment(path) {
    const parts = path.split('.');
    return parts[parts.length - 1] || path;
}
function memberId(value) {
    const trimmed = value.trim();
    return MEMBER_ID.test(trimmed) ? trimmed : trimmed;
}
function record(value) {
    return isRecord(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
