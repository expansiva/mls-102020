/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/entry10/agentP2Entry.ts" enhancement="_blank"/>
import { setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { buildP2PlannedSteps, executeP2Entry, moduleTokenOk, parseP2StepPrompt, plannedP2StepIds, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { P2_STEP_HOOKS, drainWaitingSiblings, planIdOf, updateStatus, } from '/_102020_/l2/agentPlannerL2/helpers/p2Dispatch.js';
export async function beforeP2EntryPromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const parsed = parseP2StepPrompt(args || step.prompt || '');
    if (parsed.kind === 'refusal') {
        const moduleName = moduleNameFromPrompt(args || step.prompt || '');
        if (moduleName && moduleTokenOk(moduleName))
            setModuleRoot(moduleName, null);
        return refuse(context, parentStep, step, hookSequential, parsed.refusal);
    }
    const source = parsed.kind === 'step'
        ? { kind: 'step', moduleName: parsed.moduleName, thread: parsed.thread, file: parsed.file, candidate: parsed.candidate }
        : { kind: 'hand', moduleName: parsed.moduleName, candidate: parsed.candidate };
    const result = await executeP2Entry(source, new Date());
    if ('refusal' in result) {
        return refuse(context, parentStep, step, hookSequential, result.refusal);
    }
    const mutationParent = findOpenParent(context, parentStep);
    const extras = missingPlannedSteps(context, result, parsed.candidate).map(item => addStep(context, mutationParent, item));
    return [
        ...extras,
        doneAnchor(context, mutationParent, result),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `entry10 recorded thread ${result.pipeline.thread} round ${result.pipeline.round}`),
    ];
}
export async function afterP2EntryPromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'entry10 already recorded.')];
}
function refuse(context, parentStep, step, hookSequential, message) {
    return [
        ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
        updateStatus(context, parentStep, step, hookSequential, 'completed', message),
    ];
}
function missingPlannedSteps(context, result, candidate) {
    const present = new Set(allSteps(context).map(item => planIdOf(item)).filter(Boolean));
    return buildP2PlannedSteps(result.pipeline.moduleName, {
        thread: result.pipeline.thread,
        file: result.pipeline.messageFile,
        candidate,
    }, result.message).filter(item => {
        const id = item.planning?.planId || '';
        return id !== 'entry10' && !present.has(id);
    });
}
function doneAnchor(context, parentStep, result) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Entry done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName: result.pipeline.moduleName,
            thread: result.pipeline.thread,
            round: result.pipeline.round,
            messageFile: result.pipeline.messageFile,
            sourceMessages: result.pipeline.sourceMessages,
            completedStep: 'entry10',
            nextStep: plannedP2StepIds(result.message).find(id => id !== 'entry10') || '',
        }),
        planning: { planId: 'entry10-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findOpenParent(context, parentStep) {
    const current = allSteps(context).find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function allSteps(context) {
    const root = context.task?.iaCompressed?.nextSteps || [];
    const out = [];
    const walk = (steps) => {
        for (const step of steps) {
            out.push(step);
            if (step.nextSteps?.length)
                walk(step.nextSteps);
        }
    };
    walk(root);
    return out;
}
function moduleNameFromPrompt(prompt) {
    try {
        const parsed = JSON.parse(String(prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName.trim() : '';
    }
    catch {
        return '';
    }
}
P2_STEP_HOOKS.entry10 = {
    beforePromptStep: beforeP2EntryPromptStep,
    afterPromptStep: afterP2EntryPromptStep,
};
