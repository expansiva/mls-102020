/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.ts" enhancement="_blank"/>
export const P2_WORKSPACES_SCHEMA_VERSION = '2026-09-18-p2-workspaces-v1';
export const P2_WORKSPACE_KINDS = ['catalogue', 'hub', 'command'];
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
export function isP2WorkspaceKind(value) {
    return P2_WORKSPACE_KINDS.includes(value);
}
export function isDdmEntity(entity) {
    if (entity.family === 'ddm')
        return true;
    if (entity.storageKind === 'timeSeries')
        return true;
    return entity.capabilities.includes('aggregate.byWindow');
}
export function suggestedWorkspaceKind(journey, entities) {
    const onlyAct = journey.steps.length > 0 && journey.steps.every(step => step.kind === 'act');
    const hasLocate = journey.steps.some(step => step.kind === 'locate');
    if (onlyAct && !hasLocate)
        return 'command';
    const hasAct = journey.steps.some(step => step.kind === 'act');
    const hasInspect = journey.steps.some(step => step.kind === 'inspect');
    if (journey.steps.some(step => entityIsDdm(entities, step.entity)))
        return 'hub';
    if (hasInspect && !hasLocate && !hasAct)
        return 'hub';
    return 'catalogue';
}
export function collectP2WorkspaceCandidates(sources) {
    const groups = new Map();
    for (const journey of sources.journeys) {
        const kind = suggestedWorkspaceKind(journey, sources.entities);
        for (const step of journey.steps) {
            const candidateId = workspaceCandidateId(journey.actorRef, step.entity, kind);
            let candidate = groups.get(candidateId);
            if (!candidate) {
                candidate = {
                    candidateId,
                    entityRef: step.entity,
                    actorRef: journey.actorRef,
                    kind,
                    journeyRefs: [],
                    stepRefs: [],
                };
                groups.set(candidateId, candidate);
            }
            if (!candidate.journeyRefs.includes(journey.journeyId))
                candidate.journeyRefs.push(journey.journeyId);
            if (!candidate.stepRefs.includes(step.stepId))
                candidate.stepRefs.push(step.stepId);
        }
    }
    return [...groups.values()].sort((left, right) => left.candidateId.localeCompare(right.candidateId));
}
export function workspaceCandidateId(actorRef, entityRef, kind) {
    return `${actorRef}${entityRef}${capitalize(kind)}`;
}
export function parseP2L4Sources(input) {
    const access = record(input.access);
    const ontologyIndex = record(input.ontologyIndex);
    const indexEntities = list(ontologyIndex.entities).map(item => record(item));
    const entityFiles = (input.ontologyEntities || []).map(item => record(item));
    const entitiesById = new Map();
    for (const entity of entityFiles) {
        const entityId = text(entity.entityId);
        if (entityId)
            entitiesById.set(entityId, entity);
    }
    const actors = list(access.actors).map(item => {
        const actor = record(item);
        return {
            actorId: memberId(text(actor.actorId)),
            title: text(actor.title),
            kind: text(actor.kind),
        };
    }).filter(actor => actor.actorId);
    const entities = indexEntities.map(row => {
        const entityId = text(row.entityId);
        const file = entitiesById.get(entityId) || {};
        const storage = record(file.storage);
        const capabilities = record(file.capabilities);
        const recordNode = record(file.record);
        const fields = record(recordNode.fields);
        return {
            entityId,
            title: text(file.title) || entityId,
            kind: text(row.kind) || text(file.kind),
            class: text(row.class) || text(file.class) || undefined,
            family: text(file.family) || undefined,
            storageKind: text(storage.kind) || undefined,
            displayField: text(file.displayField) || undefined,
            idField: fields.id ? 'id' : undefined,
            writer: ontologyWriter(file.writer),
            capabilities: Object.keys(capabilities),
            rules: list(file.rules).map(item => text(item)).filter(Boolean),
            transitions: list(file.transitions).map(item => {
                const transition = record(item);
                return {
                    transitionId: memberId(text(transition.transitionId)),
                    from: list(transition.from).map(value => text(value)).filter(Boolean),
                    to: text(transition.to),
                };
            }).filter(transition => transition.transitionId),
        };
    }).filter(entity => entity.entityId);
    const journeys = input.journeys.map(item => parseJourney(item)).filter(journey => journey.journeyId);
    const ontologyEntities = (input.ontologyEntities || []).filter(isOntologyEntity);
    return {
        moduleName: memberId(text(input.moduleName) || text(record(input.journeyIndex).moduleName) || text(access.moduleName)),
        userLanguage: text(input.userLanguage) || 'en',
        journeys,
        actors,
        entities,
        ontologyEntities,
    };
}
export function normalizeP2WorkspacesPayload(value, moduleName) {
    const root = record(value);
    const workspaces = list(root.workspaces).map(item => normalizeWorkspace(item)).filter(workspace => workspace.workspaceId || workspace.title);
    return {
        schemaVersion: P2_WORKSPACES_SCHEMA_VERSION,
        moduleName: memberId(text(root.moduleName) || moduleName),
        workspaces,
    };
}
export function buildP2WorkspacesTool(schema) {
    return createP2ArtifactTool('submitP2Workspaces', 'Submit the workspace cut: named workspaces chosen from the deterministic candidates.', schema);
}
export function unwrapP2ArtifactPayload(value) {
    const root = parseMaybeJson(value);
    const payload = isRecord(root) && root.type === 'flexible' ? parseMaybeJson(root.result) : root;
    const argumentsValue = toolArguments(payload);
    if (argumentsValue === undefined)
        return payload;
    const argumentsPayload = parseMaybeJson(argumentsValue);
    return isRecord(argumentsPayload) && argumentsPayload.type === 'flexible'
        ? parseMaybeJson(argumentsPayload.result)
        : argumentsPayload;
}
function createP2ArtifactTool(toolName, description, artifactSchema) {
    const result = { ...artifactSchema };
    const defs = result.$defs;
    delete result.$defs;
    delete result.$id;
    delete result.$schema;
    const parameters = {
        type: 'object',
        additionalProperties: false,
        required: ['type', 'result'],
        properties: {
            type: { type: 'string', const: 'flexible' },
            result,
        },
    };
    if (isRecord(defs))
        parameters.$defs = defs;
    return { type: 'function', function: { name: toolName, description, parameters } };
}
function parseJourney(value) {
    const source = record(value);
    const business = record(source.business);
    return {
        journeyId: memberId(text(source.journeyId)),
        actorRef: memberId(text(business.actorRef)),
        title: text(business.title),
        goal: text(business.goal),
        steps: list(business.steps).map(item => {
            const step = record(item);
            return {
                stepId: memberId(text(step.stepId)),
                kind: text(step.kind),
                entity: text(step.entity),
                effect: text(step.effect) || undefined,
                transitionRef: memberId(text(step.transitionRef)) || undefined,
            };
        }).filter(step => step.stepId),
    };
}
function normalizeWorkspace(value) {
    const source = record(value);
    const kind = text(source.kind);
    return {
        workspaceId: memberId(text(source.workspaceId) || text(source.title)),
        title: text(source.title),
        kind: isP2WorkspaceKind(kind) ? kind : '',
        entityRef: text(source.entityRef),
        actorRefs: uniqueMemberIds(source.actorRefs),
        journeyRefs: uniqueMemberIds(source.journeyRefs),
        stepRefs: uniqueMemberIds(source.stepRefs),
    };
}
function ontologyWriter(value) {
    const writer = text(value);
    if (writer === 'journey' || writer === 'crud' || writer === 'inbound')
        return writer;
    return undefined;
}
function entityIsDdm(entities, entityId) {
    return entities.some(entity => entity.entityId === entityId && isDdmEntity(entity));
}
function uniqueMemberIds(value) {
    const seen = new Set();
    const out = [];
    for (const item of list(value)) {
        const id = memberId(typeof item === 'string' ? item : text(record(item).id));
        if (!id || seen.has(id))
            continue;
        seen.add(id);
        out.push(id);
    }
    return out;
}
function toolArguments(value) {
    if (!isRecord(value))
        return undefined;
    if ('arguments' in value)
        return value.arguments;
    const calls = value.tool_calls;
    if (!Array.isArray(calls) || !isRecord(calls[0]))
        return undefined;
    const call = calls[0];
    return isRecord(call.function) && 'arguments' in call.function ? call.function.arguments : call.arguments;
}
function capitalize(value) {
    return value ? `${value.slice(0, 1).toUpperCase()}${value.slice(1)}` : '';
}
function memberId(value) {
    const trimmed = value.trim();
    return MEMBER_ID.test(trimmed) ? trimmed : trimmed;
}
function record(value) {
    return isRecord(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function isOntologyEntity(value) {
    if (!isRecord(value))
        return false;
    return typeof value.entityId === 'string' && !!value.entityId.trim();
}
