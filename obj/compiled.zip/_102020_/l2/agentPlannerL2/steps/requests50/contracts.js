/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/requests50/contracts.ts" enhancement="_blank"/>
import { emitP2ContractDefs, } from '/_102020_/l2/agentPlannerL2/steps/contracts30/contracts.js';
/** One second per request so `writePoolMessage` names (`<stamp>_<thread>_<round>`) do not collide. */
export function p2RequestNow(now, index) {
    return new Date(now.getTime() + index * 1000);
}
export function collectP2RequestCalls(contracts) {
    const out = [];
    for (const workspace of contracts.workspaces) {
        for (const call of workspace.calls) {
            out.push({ workspaceId: workspace.workspaceId, call });
        }
    }
    return out;
}
export function p2RequestSubject(moduleName, workspaceId, callName) {
    return `${moduleName}.${workspaceId}.${callName}`;
}
export function p2RequestArtifact(workspaceId) {
    return `web/contracts/${workspaceId}.defs.ts`;
}
export function extractP2CallBlock(source, callName) {
    const needle = `// bffCall ${callName} `;
    const start = source.indexOf(needle);
    if (start < 0)
        return '';
    const rest = source.slice(start);
    const next = rest.indexOf('\n// bffCall ');
    const chunk = next < 0 ? rest : rest.slice(0, next);
    return chunk.replace(/\s+$/u, '');
}
export function journeyStepOf(stepRef, workspace, sources) {
    const journeyRefs = workspace?.journeyRefs || [];
    for (const journeyId of journeyRefs) {
        const journey = sources.journeys.find(item => item.journeyId === journeyId);
        if (journey?.steps.some(step => step.stepId === stepRef)) {
            return { journeyId, stepId: stepRef };
        }
    }
    return { journeyId: journeyRefs[0] || '', stepId: stepRef };
}
export function buildP2RequestBody(input) {
    const block = extractP2CallBlock(input.contractSource, input.call.callName);
    const fields = [];
    const seen = new Set();
    for (const path of [...input.call.inputFields, ...input.call.outputFields]) {
        if (!path || seen.has(path))
            continue;
        seen.add(path);
        fields.push(path);
    }
    const lines = [
        `Journey step ${input.journeyId}/${input.stepId} motivates this BFF call.`,
        '',
        block,
        '',
        `l4 entity: ${input.call.entityRef}`,
        `l4 fields: ${fields.join(', ')}`,
    ];
    if (input.call.transitionRef)
        lines.push(`l4 transition: ${input.call.transitionRef}`);
    return lines.join('\n');
}
export function buildP2L1Requests(input) {
    const emitted = new Map();
    const workspaceById = new Map(input.workspaces.workspaces.map(workspace => [workspace.workspaceId, workspace]));
    const out = [];
    for (const entry of collectP2RequestCalls(input.contracts)) {
        let source = emitted.get(entry.workspaceId);
        if (!source) {
            source = emitP2ContractDefs({
                project: input.project,
                moduleName: input.moduleName,
                workspaceId: entry.workspaceId,
                calls: input.contracts.workspaces.find(item => item.workspaceId === entry.workspaceId)?.calls || [entry.call],
                catalog: input.catalog,
            });
            emitted.set(entry.workspaceId, source);
        }
        const cut = workspaceById.get(entry.workspaceId);
        const journey = journeyStepOf(entry.call.stepRef, cut, input.sources);
        out.push({
            from: 'l2',
            to: 'l1',
            thread: input.received.thread,
            round: input.received.round,
            mode: input.received.mode,
            subject: p2RequestSubject(input.moduleName, entry.workspaceId, entry.call.callName),
            artifacts: [p2RequestArtifact(entry.workspaceId)],
            body: buildP2RequestBody({
                journeyId: journey.journeyId,
                stepId: journey.stepId,
                call: entry.call,
                contractSource: source,
            }),
        });
    }
    return out;
}
