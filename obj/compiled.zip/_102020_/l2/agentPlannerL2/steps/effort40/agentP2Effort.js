/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/effort40/agentP2Effort.ts" enhancement="_blank"/>
import { displayPath, ontologyEntityFile, ontologyIndexFile, readDefsJson, readJson, writeJson, } from '/_102035_/l2/solution/fs.js';
import { readPoolMessage, writePoolMessage, } from '/_102035_/l2/solution/pool.js';
import { findP2Response, P2_MENU_DEVICE, isP2CandidateRoot, markP2Complete, markP2Step, p2BackendFile, readP2ModuleNavigation, p2DraftFile, p2EffortFile, p2L4DiffFile, p2MenuFile, p2NeedsFile, p2PipelineFile, readP2Pipeline, traceAndConsumeP2Input, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { P2_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102020_/l2/agentPlannerL2/helpers/p2Dispatch.js';
import { receivedPoolFile } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { buildP2EffortFile, buildP2EffortMessage, parseP2BackendFile, parseP2L4DiffFile, p2EntityRulesMap, } from '/_102020_/l2/agentPlannerL2/steps/effort40/contracts.js';
import { formatP2EffortGate, validateP2Effort, } from '/_102020_/l2/agentPlannerL2/steps/effort40/gate.js';
export async function executeP2Effort(moduleName, now) {
    const pipeline = await requirePipeline(moduleName);
    const receivedFile = receivedPoolFile(moduleName, pipeline.messageFile);
    const received = await readPoolMessage(receivedFile);
    if (received.mode !== 'estimate')
        throw new Error('effort40 only processes estimate messages; input remains pending.');
    const existing = await findP2Response(moduleName, received, 'effort.json');
    const checkpointInfo = p2DraftFile(moduleName, 'effort40');
    const checkpoint = await readJson(checkpointInfo);
    const matchingCheckpoint = checkpoint?.thread === received.thread
        && checkpoint.round === received.round
        && checkpoint.inputFile === displayPath(receivedFile)
        ? checkpoint
        : null;
    let effort;
    let message;
    let messageInfo;
    let effortPath;
    if (existing) {
        const device = pipeline.device || P2_MENU_DEVICE;
        const effortInfo = p2EffortFile(moduleName, device);
        const persisted = await readJson(effortInfo);
        if (!persisted)
            throw new Error('pool/l2 effort.json is missing for the existing response; input remains pending.');
        effort = persisted;
        message = existing.message;
        messageInfo = existing.file;
        effortPath = displayPath(effortInfo);
    }
    else if (matchingCheckpoint) {
        effort = matchingCheckpoint.effort;
        message = buildP2EffortMessage({ file: effort, received });
        const effortInfo = p2EffortFile(moduleName, effort.device);
        effortPath = await writeJson(effortInfo, effort);
        messageInfo = await writePoolMessage(moduleName, message, now);
    }
    else {
        const device = pipeline.device || P2_MENU_DEVICE;
        const menu = await readJson(p2MenuFile(moduleName, device));
        if (!menu)
            throw new Error(`pool/l2/${device}/menu.json is missing; the menu flow must run first.`);
        const rawBackend = await readJson(p2BackendFile(moduleName, device));
        if (rawBackend === null)
            throw new Error(`pool/l2/${device}/backend.json is missing; the l1 plan must run first.`);
        const backend = parseP2BackendFile(rawBackend);
        const candidate = await loadCandidateEffort(moduleName, device);
        effort = buildP2EffortFile({ menu, backend, now, candidate });
        const gate = validateP2Effort(effort, menu, { screenStatusFromAction: !candidate });
        if (!gate.ok)
            throw new Error(formatP2EffortGate(gate.issues));
        message = buildP2EffortMessage({ file: effort, received });
        await writeJson(checkpointInfo, {
            thread: received.thread,
            round: received.round,
            inputFile: displayPath(receivedFile),
            effort,
        });
        const effortInfo = p2EffortFile(moduleName, effort.device);
        effortPath = await writeJson(effortInfo, effort);
        messageInfo = await writePoolMessage(moduleName, message, now);
    }
    const messagePath = displayPath(messageInfo);
    await writeApproved(moduleName, [effortPath, messagePath], effort.unattributed);
    await traceAndConsumeP2Input(moduleName, receivedFile, received, messageInfo, message, now);
    return { effort, effortPath, message, messagePath };
}
export async function beforeP2EffortPromptStep(_agent, context, parentStep, step, hookSequential, args) {
    let moduleName = '';
    try {
        moduleName = resolveModuleName(context, args || step.prompt);
        if (!moduleName)
            throw new Error('effort40 needs a moduleName.');
        const mutationParent = findOpenParent(context, parentStep);
        const delivered = await executeP2Effort(moduleName, new Date());
        return [
            doneAnchor(context, mutationParent, moduleName, [delivered.effortPath, delivered.messagePath]),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `effort40 wrote ${delivered.effortPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterP2EffortPromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'effort40 already recorded.')];
}
async function requirePipeline(moduleName) {
    const pipeline = await readP2Pipeline(moduleName);
    if (!pipeline)
        throw new Error(`l2 pipeline.json is missing for ${moduleName}; entry10 must run first.`);
    return pipeline;
}
async function writeApproved(moduleName, artifactPaths, unattributed) {
    const pipeline = await requirePipeline(moduleName);
    const extra = unattributed.map(item => `unattributed ${item.changeId}: ${item.reason}`);
    const warnings = extra.length ? [...(pipeline.warnings || []), ...extra] : pipeline.warnings;
    const updated = markP2Step({ ...pipeline, warnings }, 'effort40', {
        status: 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths,
    });
    await writeJson(p2PipelineFile(moduleName), markP2Complete(updated));
}
async function loadCandidateEffort(moduleName, device) {
    if (!isP2CandidateRoot(moduleName))
        return undefined;
    const rawDiff = await readJson(p2L4DiffFile(moduleName, device));
    if (rawDiff === null)
        throw new Error(`pool/l2/${device}/l4diff.json is missing; the l4 candidate diff must run first.`);
    const needs = await readJson(p2NeedsFile(moduleName, device));
    if (!needs)
        throw new Error(`pool/l1/${device}/needs.json is missing; the menu flow must run first.`);
    const navigation = await readP2ModuleNavigation(moduleName);
    const entityRules = await loadEntityRules(moduleName);
    const effortInfo = p2ChangeEffortFile(moduleName);
    const rawEffort = await readJson(effortInfo);
    if (rawEffort === null)
        throw new Error('pool/l4/changeEffort.json is missing; the l4 change effort must run first.');
    const { validateChangeEffort } = await import('/_102035_/l2/solution/gates/changeEffort/gate.js');
    const checked = validateChangeEffort(rawEffort);
    if (!checked.ok) {
        const detail = checked.issues.map(issue => `${issue.code}:${issue.path}`).join(', ');
        throw new Error(`pool/l4/changeEffort.json rejected by gate: ${detail}`);
    }
    return {
        navigation,
        l4diff: parseP2L4DiffFile(rawDiff),
        needs,
        entityRules,
        changeEffort: checked.file,
    };
}
function p2ChangeEffortFile(moduleName) {
    const diff = p2L4DiffFile(moduleName);
    const folder = diff.folder.replace(/\/pool\/l2\/[^/]+$/, '/pool/l4');
    return {
        project: diff.project,
        level: diff.level,
        folder,
        shortName: 'changeEffort',
        extension: '.json',
    };
}
async function loadEntityRules(moduleName) {
    const index = await readDefsJson(ontologyIndexFile(moduleName));
    const rows = [];
    for (const row of index?.entities || []) {
        const entityId = typeof row.entityId === 'string' ? row.entityId.trim() : '';
        if (!entityId)
            continue;
        const entity = await readDefsJson(ontologyEntityFile(moduleName, entityId));
        const rules = Array.isArray(entity?.rules)
            ? entity.rules.filter((item) => typeof item === 'string' && !!item.trim()).map(item => item.trim())
            : [];
        rows.push({ entityId, rules });
    }
    return p2EntityRulesMap(rows);
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readP2Pipeline(moduleName);
        if (!pipeline)
            return;
        await writeJson(p2PipelineFile(moduleName), markP2Step(pipeline, 'effort40', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Effort done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName,
            artifactPaths,
            completedStep: 'effort40',
        }),
        planning: { planId: 'effort40-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findOpenParent(context, parentStep) {
    const current = allSteps(context).find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function allSteps(context) {
    const root = context.task?.iaCompressed?.nextSteps || [];
    const out = [];
    const walk = (steps) => {
        for (const step of steps) {
            out.push(step);
            if (step.nextSteps?.length)
                walk(step.nextSteps);
        }
    };
    walk(root);
    return out;
}
function resolveModuleName(context, value) {
    const parsed = parseRecord(value);
    return text(parsed.moduleName) || memoryString(context, 'moduleName');
}
function parseRecord(value) {
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return isRecord(parsed) ? parsed : {};
        }
        catch {
            return {};
        }
    }
    return isRecord(value) ? value : {};
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
P2_STEP_HOOKS.effort40 = {
    beforePromptStep: beforeP2EffortPromptStep,
    afterPromptStep: afterP2EffortPromptStep,
};
