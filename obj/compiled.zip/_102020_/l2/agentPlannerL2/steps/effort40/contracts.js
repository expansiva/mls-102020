/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/effort40/contracts.ts" enhancement="_blank"/>
import { P2_MENU_DEVICE, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { POOL_BACKEND_OPERATIONS, POOL_BACKEND_REMOVED_KINDS, POOL_BACKEND_SCHEMA_VERSION, POOL_EFFORT_REMOVED_KINDS, POOL_EFFORT_SCHEMA_VERSION, POOL_ENDPOINT_KINDS, POOL_PLAN_STATUSES, POOL_TEST_SUPPORT_OWNERS, } from '/_102035_/l2/solution/poolPlan.js';
// Lists and versions of the pool come from its one type (p2_34); these names stay for the readers that import them.
export const P2_EFFORT_SCHEMA_VERSION = POOL_EFFORT_SCHEMA_VERSION;
export const P2_L4DIFF_SCHEMA = '2026-09-21-p4-l4diff-v1';
export const P2_BACKEND_SCHEMA_VERSION = POOL_BACKEND_SCHEMA_VERSION;
export const P2_EFFORT_ARTIFACT = 'pool/l2/web/effort.json';
/**
 * Subset of OwnerStatus in mls-102021/l2/agentPlannerL1/helpers/l1Inventory.ts:7
 * (`'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done'`, OWNER_STATUSES at :8).
 * `inProgress` is left out on purpose — effort.json is a review snapshot, never a live run.
 * Do not import OwnerStatus from mls-102021.
 */
export const P2_EFFORT_STATUSES = POOL_PLAN_STATUSES;
export const P2_TEST_SUPPORT_OWNERS = POOL_TEST_SUPPORT_OWNERS;
export const P2_EFFORT_ENDPOINT_KINDS = POOL_ENDPOINT_KINDS;
export const P2_EFFORT_REMOVED_KINDS = POOL_EFFORT_REMOVED_KINDS;
const ACTION_TO_STATUS = {
    new: 'toCreate',
    change: 'toUpdate',
    remove: 'toRemove',
    keep: 'done',
};
export function isP2EffortStatus(value) {
    return P2_EFFORT_STATUSES.includes(value);
}
export function isP2TestSupportOwner(value) {
    return P2_TEST_SUPPORT_OWNERS.includes(value);
}
export function isP2EffortEndpointKind(value) {
    return P2_EFFORT_ENDPOINT_KINDS.includes(value);
}
export function isP2EffortRemovedKind(value) {
    return P2_EFFORT_REMOVED_KINDS.includes(value);
}
export function p2StatusFromMenuAction(action) {
    return ACTION_TO_STATUS[action];
}
export function emptyP2EffortTotalsBucket() {
    return { toCreate: 0, toUpdate: 0, toRemove: 0, done: 0 };
}
export function countP2EffortStatuses(rows) {
    const totals = emptyP2EffortTotalsBucket();
    for (const row of rows)
        totals[row.status] += 1;
    return totals;
}
export function p2EffortSubject(moduleName, device = P2_MENU_DEVICE) {
    return `effort of ${moduleName} (${device}) ready`;
}
export function p2EffortBody(file) {
    const { screens, endpoints, usecases, tables } = file.totals;
    return [
        `screens ${formatBucket(screens)}`,
        `endpoints ${formatBucket(endpoints)}`,
        `usecases ${formatBucket(usecases)}`,
        `tables ${formatBucket(tables)}`,
    ].join('\n');
}
function formatBucket(bucket) {
    return P2_EFFORT_STATUSES.map(status => `${status}:${bucket[status]}`).join(' ');
}
export function buildP2EffortFile(input) {
    const device = input.menu.device || input.backend.device || P2_MENU_DEVICE;
    const endpoints = input.backend.endpoints.map(copyEndpoint);
    const usecases = input.backend.usecases.map(copyUsecase);
    const tables = input.backend.tables.map(copyTable);
    // backend.json removes `usecase | port | table` (PoolBackendRemovedKind); effort.json lists `endpoint | usecase | table`
    // (PoolEffortRemovedKind) and its totals count no removal, so a removed port has no place in effort and is left out.
    const removed = input.backend.removed.flatMap(item => item.kind === 'port' ? [] : [copyRemoved({ ...item, kind: item.kind })]);
    const attributed = input.candidate
        ? attributeL4Diff(input.candidate.l4diff.items, input.candidate.needs, input.candidate.entityRules)
        : { pageIds: new Set(), unattributed: [] };
    const screens = input.candidate
        ? collectScreensFromL4Diff(input.menu, endpoints, input.candidate, attributed.pageIds)
        : collectScreens(input.menu, endpoints);
    return {
        schemaVersion: P2_EFFORT_SCHEMA_VERSION,
        moduleName: input.menu.moduleName || input.backend.moduleName,
        device,
        totals: {
            screens: countP2EffortStatuses(screens),
            endpoints: countP2EffortStatuses(endpoints),
            usecases: countP2EffortStatuses(usecases),
            tables: countP2EffortStatuses(tables),
        },
        screens,
        endpoints,
        usecases,
        tables,
        removed,
        testSupport: input.backend.testSupport.map(copyTestSupport),
        unattributed: attributed.unattributed,
        meta: {
            sourceMenu: `pool/l2/${device}/menu.json`,
            sourceBackend: `pool/l2/${device}/backend.json`,
            sourceVersion: input.backend.schemaVersion,
            generatedAt: input.now.toISOString(),
        },
    };
}
export function buildP2EffortMessage(input) {
    return {
        from: 'l2',
        to: 'l4',
        thread: input.received.thread,
        round: input.received.round,
        mode: input.received.mode,
        subject: p2EffortSubject(input.file.moduleName, input.file.device),
        artifacts: [P2_EFFORT_ARTIFACT],
        body: p2EffortBody(input.file),
    };
}
export function parseP2BackendFile(value) {
    if (!isRecord(value))
        throw new Error('backend.json must be an object.');
    if (value.schemaVersion !== P2_BACKEND_SCHEMA_VERSION) {
        throw new Error(`backend.json schemaVersion must be ${P2_BACKEND_SCHEMA_VERSION}.`);
    }
    const device = typeof value.device === 'string' && value.device.trim() ? value.device.trim() : P2_MENU_DEVICE;
    if (device !== P2_MENU_DEVICE)
        throw new Error(`backend.json device must be ${P2_MENU_DEVICE}.`);
    return {
        schemaVersion: P2_BACKEND_SCHEMA_VERSION,
        moduleName: text(value.moduleName),
        device,
        endpoints: asArray(value.endpoints).map((item, index) => parseEndpoint(item, index)),
        usecases: asArray(value.usecases).map((item, index) => parseUsecase(item, index)),
        tables: asArray(value.tables).map((item, index) => parseTable(item, index)),
        removed: asArray(value.removed).map((item, index) => parseRemoved(item, index)),
        testSupport: requiredArray(value.testSupport, 'testSupport').map((item, index) => parseTestSupport(item, index)),
    };
}
export function parseP2L4DiffFile(value) {
    if (!isRecord(value))
        throw new Error('l4diff.json must be an object.');
    return {
        schemaVersion: text(value.schemaVersion) || P2_L4DIFF_SCHEMA,
        moduleName: text(value.moduleName),
        base: text(value.base),
        candidate: text(value.candidate),
        items: asArray(value.items).map((item, index) => parseL4DiffItem(item, index)),
    };
}
export function p2EntityRulesMap(entities) {
    const out = new Map();
    for (const entity of entities) {
        if (!entity.entityId)
            continue;
        out.set(entity.entityId, [...(entity.rules || [])]);
    }
    return out;
}
export function attributeL4Diff(items, needs, entityRules) {
    const pageIds = new Set();
    const unattributed = [];
    for (const item of items) {
        const cited = pagesCitingChange(item, needs, entityRules);
        if (cited.length === 0) {
            unattributed.push({
                changeId: item.changeId,
                kind: item.kind,
                op: item.op,
                reason: unattributedReason(item, entityRules),
            });
            continue;
        }
        for (const pageId of cited)
            pageIds.add(pageId);
    }
    return { pageIds, unattributed };
}
function collectScreensFromL4Diff(menu, endpoints, candidate, updatedIds) {
    const pages = stampedPages(menu.tree);
    const canonicalPages = candidate.canonicalMenu ? stampedPages(candidate.canonicalMenu.tree) : [];
    const canonicalIds = new Set(canonicalPages.map(page => page.id));
    const actorsOfPage = pageActors(menu, pages);
    const canonicalActors = candidate.canonicalMenu
        ? pageActors(candidate.canonicalMenu, canonicalPages)
        : new Map();
    const routesByPage = routesByPageId(endpoints);
    const seen = new Set();
    const screens = [];
    for (const page of pages) {
        seen.add(page.id);
        const status = !canonicalIds.has(page.id)
            ? 'toCreate'
            : updatedIds.has(page.id) ? 'toUpdate' : 'done';
        screens.push({
            pageId: page.id,
            label: page.label,
            actors: actorsOfPage.get(page.id) || [],
            status,
            endpoints: routesByPage.get(page.id) || [],
        });
    }
    for (const page of canonicalPages) {
        if (seen.has(page.id))
            continue;
        seen.add(page.id);
        screens.push({
            pageId: page.id,
            label: page.label,
            actors: canonicalActors.get(page.id) || [],
            status: 'toRemove',
            endpoints: routesByPage.get(page.id) || [],
        });
    }
    return screens;
}
function collectScreens(menu, endpoints) {
    const pages = stampedPages(menu.tree);
    const actorsOfPage = pageActors(menu, pages);
    const routesByPage = routesByPageId(endpoints);
    const seen = new Set();
    const screens = [];
    for (const page of pages) {
        seen.add(page.id);
        screens.push({
            pageId: page.id,
            label: page.label,
            actors: actorsOfPage.get(page.id) || [],
            status: p2StatusFromMenuAction(page.action),
            endpoints: routesByPage.get(page.id) || [],
        });
    }
    for (const node of menu.meta.removed) {
        for (const page of stampedPages([node])) {
            if (seen.has(page.id))
                continue;
            seen.add(page.id);
            screens.push({
                pageId: page.id,
                label: page.label,
                actors: actorsOfPage.get(page.id) || [],
                status: 'toRemove',
                endpoints: routesByPage.get(page.id) || [],
            });
        }
    }
    return screens;
}
function routesByPageId(endpoints) {
    const out = new Map();
    for (const endpoint of endpoints) {
        const list = out.get(endpoint.page) || [];
        if (!list.includes(endpoint.route))
            list.push(endpoint.route);
        out.set(endpoint.page, list);
    }
    return out;
}
function copyEndpoint(item) {
    return {
        route: item.route,
        page: item.page,
        kind: item.kind,
        usecaseRef: item.usecaseRef,
        status: item.status,
    };
}
function copyUsecase(item) {
    return {
        usecaseId: item.usecaseId,
        entity: item.entity,
        operation: item.operation,
        status: item.status,
        existing: item.existing,
    };
}
function copyTable(item) {
    return {
        tableId: item.tableId,
        entity: item.entity,
        status: item.status,
    };
}
function copyRemoved(item) {
    return {
        kind: item.kind,
        id: item.id,
        status: 'toRemove',
    };
}
function copyTestSupport(item) {
    return {
        id: item.id,
        actorRefs: [...item.actorRefs],
        entityRefs: [...item.entityRefs],
        sourceRefs: [...item.sourceRefs],
        status: item.status,
        owner: item.owner,
        executorRef: item.executorRef,
        cleanupRef: item.cleanupRef,
        gap: item.gap,
    };
}
function parseTestSupport(value, index) {
    const path = `testSupport[${index}]`;
    if (!isRecord(value))
        throw new Error(`backend.json ${path} must be an object.`);
    const status = supportString(value.status, `${path}.status`, false);
    if (!isP2EffortStatus(status)) {
        throw new Error(`backend.json ${path}.status must be ${P2_EFFORT_STATUSES.join('|')}.`);
    }
    const owner = supportString(value.owner, `${path}.owner`, false);
    if (!isP2TestSupportOwner(owner)) {
        throw new Error(`backend.json ${path}.owner must be ${P2_TEST_SUPPORT_OWNERS.join('|')}.`);
    }
    return {
        id: supportString(value.id, `${path}.id`, false),
        actorRefs: supportStringArray(value.actorRefs, `${path}.actorRefs`),
        entityRefs: supportStringArray(value.entityRefs, `${path}.entityRefs`),
        sourceRefs: supportStringArray(value.sourceRefs, `${path}.sourceRefs`),
        status,
        owner,
        executorRef: supportString(value.executorRef, `${path}.executorRef`, true),
        cleanupRef: supportString(value.cleanupRef, `${path}.cleanupRef`, true),
        gap: supportString(value.gap, `${path}.gap`, true),
    };
}
function parseEndpoint(value, index) {
    if (!isRecord(value))
        throw new Error(`backend.json endpoints[${index}] must be an object.`);
    return {
        route: requiredText(value.route, `endpoints[${index}].route`),
        page: requiredText(value.page, `endpoints[${index}].page`),
        kind: parseKind(value.kind, `endpoints[${index}].kind`),
        usecaseRef: requiredText(value.usecaseRef, `endpoints[${index}].usecaseRef`),
        status: parseStatus(value.status, `endpoints[${index}].status`),
    };
}
function parseUsecase(value, index) {
    if (!isRecord(value))
        throw new Error(`backend.json usecases[${index}] must be an object.`);
    return {
        usecaseId: requiredText(value.usecaseId, `usecases[${index}].usecaseId`),
        entity: requiredText(value.entity, `usecases[${index}].entity`),
        operation: parseOperation(value.operation, `usecases[${index}].operation`),
        status: parseStatus(value.status, `usecases[${index}].status`),
        existing: text(value.existing),
    };
}
function parseTable(value, index) {
    if (!isRecord(value))
        throw new Error(`backend.json tables[${index}] must be an object.`);
    return {
        tableId: requiredText(value.tableId, `tables[${index}].tableId`),
        entity: requiredText(value.entity, `tables[${index}].entity`),
        status: parseStatus(value.status, `tables[${index}].status`),
    };
}
function parseRemoved(value, index) {
    if (!isRecord(value))
        throw new Error(`backend.json removed[${index}] must be an object.`);
    const kind = requiredText(value.kind, `removed[${index}].kind`);
    if (!POOL_BACKEND_REMOVED_KINDS.includes(kind)) {
        throw new Error(`P2_EFFORT_BACKEND_REMOVED_KIND: backend.json removed[${index}].kind must be ${POOL_BACKEND_REMOVED_KINDS.join('|')}.`);
    }
    const status = parseStatus(value.status, `removed[${index}].status`);
    if (status !== 'toRemove') {
        throw new Error(`backend.json removed[${index}].status must be toRemove.`);
    }
    return { kind: kind, id: requiredText(value.id, `removed[${index}].id`), status };
}
function parseOperation(value, path) {
    const operation = requiredText(value, path);
    if (!POOL_BACKEND_OPERATIONS.includes(operation)) {
        throw new Error(`P2_EFFORT_BACKEND_OPERATION: backend.json ${path} must be ${POOL_BACKEND_OPERATIONS.join('|')}, not ${operation}.`);
    }
    return operation;
}
function parseStatus(value, path) {
    const status = requiredText(value, path);
    if (!isP2EffortStatus(status)) {
        throw new Error(`backend.json ${path} must be ${P2_EFFORT_STATUSES.join('|')}.`);
    }
    return status;
}
function parseKind(value, path) {
    const kind = requiredText(value, path);
    if (!isP2EffortEndpointKind(kind)) {
        throw new Error(`backend.json ${path} must be ${P2_EFFORT_ENDPOINT_KINDS.join('|')}.`);
    }
    return kind;
}
function stampedPages(nodes) {
    const out = [];
    const walk = (list) => {
        for (const node of list) {
            if (node.kind === 'page')
                out.push(node);
            else
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function pageActors(menu, pages) {
    const pageIds = new Set(pages.map(page => page.id));
    const out = new Map();
    for (const page of pages)
        out.set(page.id, []);
    const byId = indexTree(menu.tree);
    for (const [key, listed] of Object.entries(menu.authorities)) {
        const actorRef = actorFromKey(key);
        if (!actorRef)
            continue;
        const visible = new Set();
        for (const id of listed)
            collectPageIds(byId.get(id), pageIds, visible);
        for (const pageId of visible) {
            const row = out.get(pageId);
            if (row && !row.includes(actorRef))
                row.push(actorRef);
        }
    }
    return out;
}
function collectPageIds(node, pageIds, out) {
    if (!node)
        return;
    if (node.kind === 'page' && pageIds.has(node.id))
        out.add(node.id);
    if (node.kind === 'hub' || node.kind === 'group') {
        for (const child of node.children)
            collectPageIds(child, pageIds, out);
    }
}
function indexTree(nodes) {
    const out = new Map();
    const walk = (list) => {
        for (const node of list) {
            out.set(node.id, node);
            if (node.kind === 'hub' || node.kind === 'group')
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function actorFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : '';
}
function asArray(value) {
    return Array.isArray(value) ? value : [];
}
function requiredArray(value, path) {
    if (!Array.isArray(value))
        throw new Error(`backend.json ${path} must be an array.`);
    return value;
}
function supportString(value, path, allowEmpty) {
    if (typeof value !== 'string' || (!allowEmpty && value.trim() === '')) {
        throw new Error(`backend.json ${path} must be ${allowEmpty ? 'a string' : 'a non-empty string'}.`);
    }
    return value;
}
function supportStringArray(value, path) {
    if (!Array.isArray(value))
        throw new Error(`backend.json ${path} must be an array of strings.`);
    return value.map((item, index) => {
        if (typeof item !== 'string')
            throw new Error(`backend.json ${path}[${index}] must be a string.`);
        return item;
    });
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function requiredText(value, path) {
    const out = text(value);
    if (!out)
        throw new Error(`backend.json ${path} is required.`);
    return out;
}
function parseL4DiffItem(value, index) {
    if (!isRecord(value))
        throw new Error(`l4diff.json items[${index}] must be an object.`);
    return {
        changeId: requiredDiffText(value.changeId, `items[${index}].changeId`),
        kind: requiredDiffText(value.kind, `items[${index}].kind`),
        op: requiredDiffText(value.op, `items[${index}].op`),
        entity: text(value.entity),
        source: text(value.source),
    };
}
function requiredDiffText(value, path) {
    const out = text(value);
    if (!out)
        throw new Error(`l4diff.json ${path} is required.`);
    return out;
}
function pagesCitingChange(item, needs, entityRules) {
    if (item.kind === 'rule') {
        const ruleId = stripKindPrefix(item.changeId, 'rule');
        const entities = entitiesDeclaringRule(ruleId, entityRules);
        if (entities.size === 0)
            return [];
        return needs.pages.filter(page => pageCitesAnyEntity(page, entities)).map(page => page.pageId);
    }
    if (item.kind === 'transition') {
        const transitionId = stripKindPrefix(item.changeId, 'transition');
        const byRef = needs.pages.filter(page => page.writes.some(write => write.transitionRef === transitionId));
        if (byRef.length)
            return byRef.map(page => page.pageId);
        if (item.entity)
            return needs.pages.filter(page => pageCitesEntity(page, item.entity)).map(page => page.pageId);
        return [];
    }
    if (item.kind === 'process') {
        const processId = stripKindPrefix(item.changeId, 'process');
        const marker = `process:${processId}`;
        const byFrom = needs.pages.filter(page => pageCitesFrom(page, marker));
        if (byFrom.length)
            return byFrom.map(page => page.pageId);
    }
    const entityId = item.entity || (item.kind === 'entity' ? stripKindPrefix(item.changeId, 'entity') : '');
    if (!entityId)
        return [];
    return needs.pages.filter(page => pageCitesEntity(page, entityId)).map(page => page.pageId);
}
function unattributedReason(item, entityRules) {
    if (item.kind === 'rule') {
        const ruleId = stripKindPrefix(item.changeId, 'rule');
        const declared = entitiesDeclaringRule(ruleId, entityRules);
        if (declared.size === 0)
            return `rule '${ruleId}' is not in any entity.rules[]`;
        return `rule '${ruleId}' is declared on ${[...declared].join(', ')} but no page reads or writes those entities`;
    }
    if (item.kind === 'transition') {
        return `transition '${stripKindPrefix(item.changeId, 'transition')}' is not in any page writes.transitionRef`;
    }
    if (!item.entity)
        return `${item.kind} '${item.changeId}' has empty entity and cites no page`;
    return `entity '${item.entity}' is not read or written by any page`;
}
function entitiesDeclaringRule(ruleId, entityRules) {
    const out = new Set();
    if (!ruleId)
        return out;
    for (const [entityId, rules] of entityRules) {
        if (rules.includes(ruleId))
            out.add(entityId);
    }
    return out;
}
function pageCitesEntity(page, entityId) {
    return page.reads.some(read => read.entity === entityId) || page.writes.some(write => write.entity === entityId);
}
function pageCitesAnyEntity(page, entities) {
    return page.reads.some(read => entities.has(read.entity)) || page.writes.some(write => entities.has(write.entity));
}
function pageCitesFrom(page, marker) {
    return page.reads.some(read => read.from.includes(marker)) || page.writes.some(write => write.from.includes(marker));
}
function stripKindPrefix(changeId, kind) {
    const prefix = `${kind}:`;
    return changeId.startsWith(prefix) ? changeId.slice(prefix.length) : changeId;
}
