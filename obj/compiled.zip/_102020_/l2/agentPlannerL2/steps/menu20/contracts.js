/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/menu20/contracts.ts" enhancement="_blank"/>
import { P2_MENU_DEVICE, readReadyL2Manifest, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { collectP2WorkspaceCandidates, isDdmEntity, } from '/_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.js';
import { isLucideIcon } from '/_102035_/l2/solution/lucideIcons.js';
import { MENU_PLACEMENTS, MENU_ACTIONS as POOL_MENU_ACTIONS, MENU_NODE_KINDS as POOL_MENU_NODE_KINDS, MENU_ORGANISM_KINDS as POOL_MENU_ORGANISM_KINDS, MENU_SCHEMA_VERSION as POOL_MENU_SCHEMA_VERSION, } from '/_102035_/l2/solution/poolPlan.js';
// Lists and version of menu.json come from the pool's one type (p2_34).
export const P2_MENU_SCHEMA_VERSION = POOL_MENU_SCHEMA_VERSION;
export const MENU_NODE_KINDS = POOL_MENU_NODE_KINDS;
export const MENU_ORGANISM_KINDS = POOL_MENU_ORGANISM_KINDS;
export const MENU_MECHANICAL_EFFECTS = ['transition', 'create', 'update'];
export const MENU_ACTIONS = POOL_MENU_ACTIONS;
const NODE_ID = /^[a-z][a-z0-9]*(_[a-z0-9]+)*$/;
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const ENTITY_ID = /^[A-Z][A-Za-z0-9]*$/;
const ACTOR_KEY = /^actor:([a-z][A-Za-z0-9]*)$/;
export function isMenuNodeKind(value) {
    return MENU_NODE_KINDS.includes(value);
}
export function isMenuOrganismKind(value) {
    return MENU_ORGANISM_KINDS.includes(value);
}
export function isMenuAction(value) {
    return MENU_ACTIONS.includes(value);
}
export function actorAuthorityKey(actorRef) {
    return `actor:${actorRef}`;
}
export function parseP2Grants(access) {
    return list(record(access).grants).map(item => {
        const grant = record(item);
        const dataScope = record(grant.dataScope);
        const disclosure = record(grant.disclosure);
        return {
            grantId: memberId(text(grant.grantId)),
            actorRef: memberId(text(grant.actorRef)),
            title: text(grant.title),
            description: text(grant.description),
            entityRefs: uniqueIds(grant.entityRefs, entityId),
            dataScope: {
                mode: text(dataScope.mode),
                anchorEntity: text(dataScope.anchorEntity),
                description: text(dataScope.description),
            },
            disclosure: {
                mode: text(disclosure.mode),
                description: text(disclosure.description),
            },
        };
    }).filter(grant => grant.grantId);
}
export function parseP2Processes(workflows) {
    return list(record(workflows).processes).map(item => {
        const process = record(item);
        const trigger = record(process.trigger);
        return {
            processId: memberId(text(process.processId)),
            trigger: {
                kind: text(trigger.kind),
                schedule: text(trigger.schedule),
                event: text(trigger.event),
                actorRef: memberId(text(trigger.actorRef)),
            },
            tasks: list(process.tasks).map(taskItem => {
                const task = record(taskItem);
                return {
                    taskId: memberId(text(task.taskId)),
                    kind: text(task.kind),
                    description: text(task.description),
                    actorRef: memberId(text(task.actorRef)),
                    entityRef: text(task.entityRef),
                    effect: text(task.effect),
                    journeyRef: memberId(text(task.journeyRef)),
                    transitionRef: memberId(text(task.transitionRef)),
                };
            }).filter(task => task.taskId),
        };
    }).filter(process => process.processId);
}
/** Hubs = grant anchors; pages = (entity, actor) groups from workspaces20. Candidates, not the answer. */
export function menuCandidates(sources, grants, processes = []) {
    const hubActors = new Map();
    for (const grant of grants) {
        const anchor = grant.dataScope.anchorEntity;
        if (!anchor)
            continue;
        let actors = hubActors.get(anchor);
        if (!actors) {
            actors = new Set();
            hubActors.set(anchor, actors);
        }
        if (grant.actorRef)
            actors.add(grant.actorRef);
    }
    const hubs = [...hubActors.entries()]
        .map(([entityRef, actors]) => ({ entityRef, actorRefs: [...actors].sort((a, b) => a.localeCompare(b)) }))
        .sort((left, right) => left.entityRef.localeCompare(right.entityRef));
    return {
        hubs,
        pages: collectP2WorkspaceCandidates(sources),
        beyondJourneys: collectBeyondJourneys(sources, grants, processes),
        recordsKept: collectRecordsKept(sources, grants),
    };
}
/** Pure. Per `writer: crud` entity, the grants that reach it. Description as-is. */
export function collectRecordsKept(sources, grants) {
    const crudIds = new Set(sources.entities.filter(entity => entity.writer === 'crud' && entity.entityId).map(entity => entity.entityId));
    const byEntity = new Map();
    for (const grant of grants) {
        if (!grant.actorRef)
            continue;
        for (const entityRef of grant.entityRefs) {
            if (!entityRef || !crudIds.has(entityRef))
                continue;
            let rows = byEntity.get(entityRef);
            if (!rows) {
                rows = [];
                byEntity.set(entityRef, rows);
            }
            rows.push({
                actorRef: grant.actorRef,
                dataScope: { mode: grant.dataScope.mode },
                disclosure: { mode: grant.disclosure.mode },
                description: grant.description,
            });
        }
    }
    return [...byEntity.entries()]
        .map(([entityRef, entityGrants]) => ({
        entityRef,
        grants: entityGrants.sort((left, right) => {
            const actor = left.actorRef.localeCompare(right.actorRef);
            return actor !== 0 ? actor : left.description.localeCompare(right.description);
        }),
    }))
        .sort((left, right) => left.entityRef.localeCompare(right.entityRef));
}
export function isMechanicalEffectTask(task) {
    return (task.kind === 'mechanical' || task.kind === 'llm')
        && MENU_MECHANICAL_EFFECTS.includes(task.effect);
}
/** Pure. Per actor: human stages, alerts, mechanical effects, derived/ddm their grant reaches. */
export function collectBeyondJourneys(sources, grants, processes) {
    const grantEntities = new Map();
    for (const grant of grants) {
        if (!grant.actorRef)
            continue;
        let entities = grantEntities.get(grant.actorRef);
        if (!entities) {
            entities = new Set();
            grantEntities.set(grant.actorRef, entities);
        }
        for (const entityRef of grant.entityRefs) {
            if (entityRef)
                entities.add(entityRef);
        }
    }
    const ddmIds = new Set(sources.entities.filter(isDdmEntity).map(entity => entity.entityId));
    const derivedByEntity = new Map();
    for (const entity of sources.ontologyEntities) {
        const entityId = text(record(entity).entityId);
        if (!entityId)
            continue;
        derivedByEntity.set(entityId, collectDerivedOfEntity(entity, ddmIds.has(entityId)));
    }
    const byActor = new Map();
    const actorOf = (actorRef) => {
        let row = byActor.get(actorRef);
        if (!row) {
            row = { actorRef, human: [], alerts: [], mechanicalEffects: [], derived: [] };
            byActor.set(actorRef, row);
        }
        return row;
    };
    for (const actor of sources.actors) {
        if (actor.actorId)
            actorOf(actor.actorId);
    }
    for (const process of processes) {
        for (const task of process.tasks) {
            if (task.kind === 'human' && task.actorRef) {
                actorOf(task.actorRef).human.push({
                    processId: process.processId,
                    taskId: task.taskId,
                    description: task.description,
                    entityRef: task.entityRef,
                });
            }
            if (task.kind === 'alert' && task.actorRef) {
                actorOf(task.actorRef).alerts.push({
                    processId: process.processId,
                    taskId: task.taskId,
                    description: task.description,
                    entityRef: task.entityRef,
                });
            }
            if (isMechanicalEffectTask(task) && task.entityRef) {
                for (const [actorRef, entities] of grantEntities) {
                    if (!entities.has(task.entityRef))
                        continue;
                    actorOf(actorRef).mechanicalEffects.push({
                        processId: process.processId,
                        taskId: task.taskId,
                        description: task.description,
                        entityRef: task.entityRef,
                        effect: task.effect,
                    });
                }
            }
        }
    }
    for (const [actorRef, entities] of grantEntities) {
        const row = actorOf(actorRef);
        const derived = [];
        for (const entityRef of [...entities].sort((left, right) => left.localeCompare(right))) {
            derived.push(...(derivedByEntity.get(entityRef) || []));
        }
        row.derived = derived;
    }
    return [...byActor.values()].sort((left, right) => left.actorRef.localeCompare(right.actorRef));
}
export function normalizeMenuV2(value) {
    const root = asRecord(value, '$');
    exactKeys(root, ['tree', 'authorities', 'meta'], '$');
    const meta = asRecord(root.meta, '$.meta');
    // Model answers must name a place for every journey. A menu.json written before the field never comes through here.
    exactKeys(meta, ['journeys', 'processes', 'records', 'placements'], '$.meta');
    return {
        tree: list(root.tree, '$.tree').map((item, index) => normalizeNode(item, `$.tree[${index}]`, 'model')),
        authorities: normalizeAuthorities(root.authorities, '$.authorities'),
        meta: {
            journeys: normalizeIdPagesMap(meta.journeys, '$.meta.journeys', 'journeyId'),
            processes: normalizeIdPagesMap(meta.processes, '$.meta.processes', 'processId'),
            records: normalizeIdPagesMap(meta.records, '$.meta.records', 'entityId'),
            placements: normalizePlacements(meta.placements, '$.meta.placements'),
        },
    };
}
export function buildP2MenuFile(input) {
    const device = input.device || P2_MENU_DEVICE;
    const ready = readReadyL2Manifest(input.moduleName, device);
    return {
        schemaVersion: P2_MENU_SCHEMA_VERSION,
        moduleName: input.moduleName,
        userLanguage: input.userLanguage,
        device,
        tree: stampAllNew(input.draft.tree, ready),
        authorities: input.draft.authorities,
        meta: {
            journeys: input.draft.meta.journeys,
            processes: input.draft.meta.processes,
            records: input.draft.meta.records,
            ...(input.draft.meta.placements !== undefined ? { placements: input.draft.meta.placements } : {}),
            removed: [],
        },
    };
}
export function menuActionCounts(file) {
    const counts = { new: 0, change: 0, keep: 0, remove: 0 };
    const visit = (nodes) => {
        for (const node of nodes) {
            counts[node.action] += 1;
            if (node.kind === 'hub' || node.kind === 'group')
                visit(node.children);
        }
    };
    visit(file.tree);
    visit(file.meta.removed);
    return counts;
}
function stampAllNew(nodes, ready) {
    void ready;
    return nodes.map((node) => {
        if (node.kind === 'page') {
            const { icon, ...page } = node;
            return icon ? { ...page, icon, action: 'new' } : { ...page, action: 'new' };
        }
        return { ...node, action: 'new', children: stampAllNew(node.children, ready) };
    });
}
/** Unknown Lucide names become `""`. Hubs, groups and every other field stay as they are. */
export function dropUnknownMenuIcons(draft) {
    const dropped = [];
    const walk = (nodes) => nodes.map(node => {
        if (node.kind === 'hub' || node.kind === 'group')
            return { ...node, children: walk(node.children) };
        const icon = node.icon ?? '';
        if (icon !== '' && !isLucideIcon(icon)) {
            dropped.push({ pageId: node.id, icon });
            return { ...node, icon: '' };
        }
        return node;
    });
    return { draft: { ...draft, tree: walk(draft.tree) }, dropped };
}
export function menuIconDropWarnings(dropped) {
    return dropped.map(row => `icon dropped: ${row.pageId} ${row.icon}`);
}
/** Read a stamped menu tree, stripping `action` so the node shape matches the draft. */
export function parsePreviousMenuTree(value) {
    const root = asRecord(value, '$');
    return list(root.tree, '$.tree').map((item, index) => (normalizeNode(stripAction(item), `$.tree[${index}]`)));
}
/** Ids the code knows (entities, actors, journeys, processes, kept records) become enums of the menu schema (d2_67). */
export function withP2MenuEnums(schema, sources, grants, processes) {
    const copy = structuredClone(schema);
    const limit = (def, field, values) => {
        const target = copy.$defs[def]?.properties?.[field];
        if (!target)
            throw new Error(`menu.schema.json has no $defs.${def}.properties.${field}.`);
        const list = [...new Set(values.filter(Boolean))];
        if (list.length)
            target.enum = list;
    };
    limit('hubNode', 'context', sources.entities.map(entity => entity.entityId));
    limit('authority', 'actorRef', sources.actors.map(actor => actor.actorId));
    limit('journeyPages', 'journeyId', sources.journeys.map(journey => journey.journeyId));
    limit('processPages', 'processId', processes.map(process => process.processId));
    limit('recordPages', 'entityId', collectRecordsKept(sources, grants).map(row => row.entityRef));
    return copy;
}
export function buildP2MenuTool(schema) {
    return createP2ArtifactTool('submitP2Menu', 'Submit the module menu tree: hubs, pages with organisms, authorities by actor, and journey/process mapping.', schema);
}
function normalizeNode(value, path, mode = 'file') {
    const source = asRecord(value, path);
    const kind = text(source.kind);
    if (kind === 'hub')
        return normalizeHub(source, path, mode);
    if (kind === 'page')
        return normalizePage(source, path, mode);
    if (kind === 'group')
        return normalizeGroup(source, path, mode);
    throw new Error(`${path}.kind must be hub, page or group.`);
}
function normalizeHub(source, path, mode) {
    exactKeys(source, ['id', 'kind', 'label', 'context', 'text', 'children'], path);
    const children = list(source.children, `${path}.children`);
    return {
        id: nodeId(source.id, `${path}.id`),
        kind: 'hub',
        label: requiredText(source.label, `${path}.label`),
        context: entityIdRequired(source.context, `${path}.context`),
        text: requiredText(source.text, `${path}.text`),
        children: children.map((item, index) => normalizeNode(item, `${path}.children[${index}]`, mode)),
    };
}
function normalizePage(source, path, mode) {
    const keys = ['id', 'kind', 'label', 'organisms'];
    if (mode === 'model' || Object.prototype.hasOwnProperty.call(source, 'icon'))
        keys.push('icon');
    exactKeys(source, keys, path);
    const page = {
        id: nodeId(source.id, `${path}.id`),
        kind: 'page',
        label: requiredText(source.label, `${path}.label`),
        organisms: list(source.organisms, `${path}.organisms`).map((item, index) => (normalizeOrganism(item, `${path}.organisms[${index}]`))),
    };
    if (mode === 'model' || Object.prototype.hasOwnProperty.call(source, 'icon')) {
        if (typeof source.icon !== 'string')
            throw new Error(`${path}.icon must be a string.`);
        page.icon = source.icon.trim();
    }
    return page;
}
function normalizeGroup(source, path, mode) {
    exactKeys(source, ['id', 'kind', 'label', 'text', 'children'], path);
    const children = list(source.children, `${path}.children`);
    return {
        id: nodeId(source.id, `${path}.id`),
        kind: 'group',
        label: requiredText(source.label, `${path}.label`),
        text: requiredText(source.text, `${path}.text`),
        children: children.map((item, index) => normalizeNode(item, `${path}.children[${index}]`, mode)),
    };
}
function normalizeOrganism(value, path) {
    const source = asRecord(value, path);
    exactKeys(source, ['kind', 'text'], path);
    const kind = text(source.kind);
    if (!isMenuOrganismKind(kind)) {
        throw new Error(`${path}.kind must be one of ${MENU_ORGANISM_KINDS.join(', ')}.`);
    }
    return { kind, text: requiredText(source.text, `${path}.text`) };
}
function normalizeAuthorities(value, path) {
    if (Array.isArray(value)) {
        const out = {};
        value.forEach((item, index) => {
            const row = asRecord(item, `${path}[${index}]`);
            exactKeys(row, ['actorRef', 'nodes'], `${path}[${index}]`);
            const actorRef = memberIdRequired(row.actorRef, `${path}[${index}].actorRef`);
            const key = actorAuthorityKey(actorRef);
            if (out[key])
                throw new Error(`${path}[${index}]: duplicate actorRef ${actorRef}.`);
            out[key] = stringIdList(row.nodes, `${path}[${index}].nodes`, nodeId);
        });
        return out;
    }
    const source = asRecord(value, path);
    const out = {};
    for (const [key, nodes] of Object.entries(source)) {
        if (!ACTOR_KEY.test(key))
            throw new Error(`${path}.${key}: authority key must be actor:<lowerCamel>.`);
        out[key] = stringIdList(nodes, `${path}[${JSON.stringify(key)}]`, nodeId);
    }
    return out;
}
function normalizeIdPagesMap(value, path, idKey) {
    const idOf = idKey === 'entityId' ? entityIdRequired : memberIdRequired;
    if (Array.isArray(value)) {
        const out = {};
        value.forEach((item, index) => {
            const row = asRecord(item, `${path}[${index}]`);
            exactKeys(row, [idKey, 'pages'], `${path}[${index}]`);
            const id = idOf(row[idKey], `${path}[${index}].${idKey}`);
            if (out[id])
                throw new Error(`${path}[${index}]: duplicate ${idKey} ${id}.`);
            out[id] = stringIdList(row.pages, `${path}[${index}].pages`, nodeId);
        });
        return out;
    }
    const source = asRecord(value, path);
    const out = {};
    for (const [key, pages] of Object.entries(source)) {
        const id = idOf(key, `${path}.${key}`);
        out[id] = stringIdList(pages, `${path}.${id}`, nodeId);
    }
    return out;
}
function collectDerivedOfEntity(entity, isDdm) {
    const root = record(entity);
    const entityRef = text(root.entityId);
    if (!entityRef)
        return [];
    const title = text(root.title) || entityRef;
    if (isDdm)
        return [{ entityRef, title }];
    const out = [];
    walkDerivedFields(record(record(root.record).fields), false, '', (fieldId, fieldTitle) => {
        out.push({ entityRef, fieldId, title: fieldTitle });
    });
    return out;
}
function walkDerivedFields(fields, platform, prefix, visit) {
    for (const [id, raw] of Object.entries(fields)) {
        const field = record(raw);
        const nextPlatform = platform || text(field.owner) === 'platform';
        const path = prefix ? `${prefix}.${id}` : id;
        const nested = field.fields;
        const container = isRecord(nested) && Object.keys(nested).length > 0;
        if (!nextPlatform && field.derived === true && id !== 'id' && id !== 'version' && !container) {
            visit(path, text(field.title) || path);
        }
        if (isRecord(nested))
            walkDerivedFields(nested, nextPlatform, path, visit);
    }
}
function createP2ArtifactTool(toolName, description, artifactSchema) {
    const result = { ...artifactSchema };
    const defs = result.$defs;
    delete result.$defs;
    delete result.$id;
    delete result.$schema;
    const parameters = {
        type: 'object',
        additionalProperties: false,
        required: ['type', 'result'],
        properties: {
            type: { type: 'string', const: 'flexible' },
            result,
        },
    };
    if (isRecord(defs))
        parameters.$defs = defs;
    return { type: 'function', function: { name: toolName, description, parameters } };
}
function stringIdList(value, path, normalize) {
    return list(value, path).map((item, index) => normalize(item, `${path}[${index}]`));
}
function uniqueIds(value, normalize) {
    const seen = new Set();
    const out = [];
    for (const item of Array.isArray(value) ? value : []) {
        const id = normalize(typeof item === 'string' ? item : text(record(item).id));
        if (!id || seen.has(id))
            continue;
        seen.add(id);
        out.push(id);
    }
    return out;
}
function exactKeys(source, allowed, path) {
    const allowedSet = new Set(allowed);
    for (const key of Object.keys(source)) {
        if (!allowedSet.has(key))
            throw new Error(`${path}: unexpected field '${key}'.`);
    }
    for (const key of allowed) {
        if (!Object.prototype.hasOwnProperty.call(source, key))
            throw new Error(`${path}: missing field '${key}'.`);
    }
}
function normalizePlacements(value, path) {
    return list(value, path).map((item, index) => {
        const row = asRecord(item, `${path}[${index}]`);
        exactKeys(row, ['journeyId', 'actorRef', 'placement', 'pageId', 'reason'], `${path}[${index}]`);
        const placement = text(row.placement);
        if (!MENU_PLACEMENTS.includes(placement)) {
            throw new Error(`${path}[${index}].placement must be ${MENU_PLACEMENTS.join(', ')}.`);
        }
        return {
            journeyId: memberIdRequired(row.journeyId, `${path}[${index}].journeyId`),
            actorRef: memberIdRequired(row.actorRef, `${path}[${index}].actorRef`),
            placement: placement,
            pageId: nodeId(row.pageId, `${path}[${index}].pageId`),
            reason: requiredText(row.reason, `${path}[${index}].reason`),
        };
    });
}
function stripAction(value) {
    if (Array.isArray(value))
        return value.map(stripAction);
    if (!isRecord(value))
        return value;
    const { action: _action, ...rest } = value;
    const out = {};
    for (const [key, item] of Object.entries(rest))
        out[key] = stripAction(item);
    return out;
}
function asRecord(value, path) {
    if (!isRecord(value))
        throw new Error(`${path} must be an object.`);
    return value;
}
function list(value, path) {
    if (Array.isArray(value))
        return value;
    if (path)
        throw new Error(`${path} must be an array.`);
    return [];
}
function nodeId(value, path) {
    const id = text(value);
    if (!NODE_ID.test(id))
        throw new Error(`${path} must be snake_case.`);
    return id;
}
function memberIdRequired(value, path) {
    const id = text(value);
    if (!MEMBER_ID.test(id))
        throw new Error(`${path} must be lowerCamel.`);
    return id;
}
function entityIdRequired(value, path) {
    const id = text(value);
    if (!ENTITY_ID.test(id))
        throw new Error(`${path} must be an l4 entity id.`);
    return id;
}
function requiredText(value, path) {
    const trimmed = text(value);
    if (!trimmed)
        throw new Error(`${path} must be a non-empty string.`);
    return trimmed;
}
function memberId(value) {
    const trimmed = value.trim();
    return MEMBER_ID.test(trimmed) ? trimmed : trimmed;
}
function entityId(value) {
    return value.trim();
}
function record(value) {
    return isRecord(value) ? value : {};
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
