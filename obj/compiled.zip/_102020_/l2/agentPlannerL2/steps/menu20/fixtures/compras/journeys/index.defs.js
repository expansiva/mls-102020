/// <mls fileReference="_102047_/l4/compras/journeys/index.defs.ts" enhancement="_blank"/>
export const comprasJourneyIndex = {
    "schemaVersion": "2026-09-10-ns5-journey-v1",
    "moduleName": "compras",
    "journeys": [
        {
            "journeyId": "cadastrarFornecedor",
            "actorRef": "comprador",
            "title": "Cadastrar fornecedor e condições de fornecimento"
        },
        {
            "journeyId": "abrirEenviarPedidoCompra",
            "actorRef": "comprador",
            "title": "Abrir e enviar pedido de compra"
        },
        {
            "journeyId": "decidirPedidoAcimaDoLimite",
            "actorRef": "gerenteCompras",
            "title": "Decidir pedido de compra acima do limite"
        },
        {
            "journeyId": "registrarRecebimentoPedido",
            "actorRef": "almoxarife",
            "title": "Registrar recebimento total ou parcial"
        },
        {
            "journeyId": "acompanharIndicadoresDeCompras",
            "actorRef": "gerenteCompras",
            "title": "Acompanhar indicadores de compras"
        }
    ],
    "systemDecisions": []
};
export default comprasJourneyIndex;
