/// <mls fileReference="_102047_/l4/locacaoEquipamentos/journeys/index.defs.ts" enhancement="_blank"/>
export const locacaoEquipamentosJourneyIndex = {
    "schemaVersion": "2026-09-10-ns5-journey-v1",
    "moduleName": "locacaoEquipamentos",
    "journeys": [
        {
            "journeyId": "criarContratoLocacao",
            "actorRef": "atendente",
            "title": "Criar contrato de locação"
        },
        {
            "journeyId": "registrarDevolucao",
            "actorRef": "atendente",
            "title": "Registrar devolução de equipamentos"
        },
        {
            "journeyId": "consultarSituacaoEquipamentos",
            "actorRef": "gerente",
            "title": "Consultar situação dos equipamentos"
        }
    ],
    "systemDecisions": []
};
export default locacaoEquipamentosJourneyIndex;
