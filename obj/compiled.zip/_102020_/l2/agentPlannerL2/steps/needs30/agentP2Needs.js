/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/needs30/agentP2Needs.ts" enhancement="_blank"/>
import { displayPath, readJson, writeJson } from '/_102035_/l2/solution/fs.js';
import { readPoolMessage, writePoolMessage, } from '/_102035_/l2/solution/pool.js';
import { findP2Response, P2_MENU_DEVICE, markP2Step, p2DraftFile, p2MenuFile, p2NeedsFile, p2PipelineFile, readP2Pipeline, traceAndConsumeP2Input, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { P2_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102020_/l2/agentPlannerL2/helpers/p2Dispatch.js';
import { loadP2MenuSources } from '/_102020_/l2/agentPlannerL2/steps/menu20/agentP2Menu.js';
import { receivedPoolFile } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { buildP2NeedsFile, buildP2NeedsMessage, } from '/_102020_/l2/agentPlannerL2/steps/needs30/contracts.js';
import { formatP2NeedsGate, validateP2Needs, } from '/_102020_/l2/agentPlannerL2/steps/needs30/gate.js';
export async function executeP2Needs(moduleName, now) {
    const pipeline = await requirePipeline(moduleName);
    const receivedFile = receivedPoolFile(moduleName, pipeline.messageFile);
    const received = await readPoolMessage(receivedFile);
    if (received.mode !== 'estimate')
        throw new Error('needs30 only processes estimate messages; input remains pending.');
    const existing = await findP2Response(moduleName, received, 'needs.json');
    const checkpointInfo = p2DraftFile(moduleName, 'needs30');
    const checkpoint = await readJson(checkpointInfo);
    const matchingCheckpoint = checkpoint?.thread === received.thread
        && checkpoint.round === received.round
        && checkpoint.inputFile === displayPath(receivedFile)
        ? checkpoint
        : null;
    let needs;
    let message;
    let messageInfo;
    let needsPath;
    if (existing) {
        const needsInfo = p2NeedsFile(moduleName, pipeline.device || P2_MENU_DEVICE);
        const persisted = await readJson(needsInfo);
        if (!persisted)
            throw new Error('pool/l1 needs.json is missing for the existing response; input remains pending.');
        needs = persisted;
        message = existing.message;
        messageInfo = existing.file;
        needsPath = displayPath(needsInfo);
    }
    else if (matchingCheckpoint) {
        needs = matchingCheckpoint.needs;
        const needsInfo = p2NeedsFile(moduleName, needs.device);
        message = buildP2NeedsMessage({ file: needs, received });
        needsPath = await writeJson(needsInfo, needs);
        messageInfo = await writePoolMessage(moduleName, message, now);
    }
    else {
        const menu = await readJson(p2MenuFile(moduleName, pipeline.device || P2_MENU_DEVICE));
        if (!menu)
            throw new Error(`pool/l2/${pipeline.device || P2_MENU_DEVICE}/menu.json is missing; menu20 must run first.`);
        const menuSources = await loadP2MenuSources(moduleName);
        needs = buildP2NeedsFile({
            menu,
            sources: menuSources.sources,
            grants: menuSources.grants,
            processes: menuSources.processes,
            now,
        });
        const gate = validateP2Needs(needs, menu, menuSources.sources, menuSources.grants);
        if (!gate.ok)
            throw new Error(formatP2NeedsGate(gate.issues));
        message = buildP2NeedsMessage({ file: needs, received });
        await writeJson(checkpointInfo, {
            thread: received.thread,
            round: received.round,
            inputFile: displayPath(receivedFile),
            needs,
        });
        const needsInfo = p2NeedsFile(moduleName, needs.device);
        needsPath = await writeJson(needsInfo, needs);
        messageInfo = await writePoolMessage(moduleName, message, now);
    }
    const messagePath = displayPath(messageInfo);
    await writeApproved(moduleName, [needsPath, messagePath]);
    await traceAndConsumeP2Input(moduleName, receivedFile, received, messageInfo, message, now);
    return { needs, needsPath, message, messagePath };
}
export async function beforeP2NeedsPromptStep(_agent, context, parentStep, step, hookSequential, args) {
    let moduleName = '';
    try {
        moduleName = resolveModuleName(context, args || step.prompt);
        if (!moduleName)
            throw new Error('needs30 needs a moduleName.');
        const mutationParent = findOpenParent(context, parentStep);
        const delivered = await executeP2Needs(moduleName, new Date());
        return [
            doneAnchor(context, mutationParent, moduleName, [delivered.needsPath, delivered.messagePath]),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `needs30 wrote ${delivered.needsPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterP2NeedsPromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'needs30 already recorded.')];
}
async function requirePipeline(moduleName) {
    const pipeline = await readP2Pipeline(moduleName);
    if (!pipeline)
        throw new Error(`l2 pipeline.json is missing for ${moduleName}; entry10 must run first.`);
    return pipeline;
}
async function writeApproved(moduleName, artifactPaths) {
    const pipeline = await requirePipeline(moduleName);
    const updated = markP2Step(pipeline, 'needs30', {
        status: 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths,
    });
    await writeJson(p2PipelineFile(moduleName), updated);
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readP2Pipeline(moduleName);
        if (!pipeline)
            return;
        await writeJson(p2PipelineFile(moduleName), markP2Step(pipeline, 'needs30', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Needs done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName,
            artifactPaths,
            completedStep: 'needs30',
        }),
        planning: { planId: 'needs30-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findOpenParent(context, parentStep) {
    const current = allSteps(context).find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function allSteps(context) {
    const root = context.task?.iaCompressed?.nextSteps || [];
    const out = [];
    const walk = (steps) => {
        for (const step of steps) {
            out.push(step);
            if (step.nextSteps?.length)
                walk(step.nextSteps);
        }
    };
    walk(root);
    return out;
}
function resolveModuleName(context, value) {
    const parsed = parseRecord(value);
    return text(parsed.moduleName) || memoryString(context, 'moduleName');
}
function parseRecord(value) {
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return isRecord(parsed) ? parsed : {};
        }
        catch {
            return {};
        }
    }
    return isRecord(value) ? value : {};
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
P2_STEP_HOOKS.needs30 = {
    beforePromptStep: beforeP2NeedsPromptStep,
    afterPromptStep: afterP2NeedsPromptStep,
};
