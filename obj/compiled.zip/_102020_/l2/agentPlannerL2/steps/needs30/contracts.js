/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/needs30/contracts.ts" enhancement="_blank"/>
import { P2_MENU_DEVICE, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { P2_MENU_SCHEMA_VERSION, actorAuthorityKey, collectBeyondJourneys, } from '/_102020_/l2/agentPlannerL2/steps/menu20/contracts.js';
import { journeyStepOf } from '/_102020_/l2/agentPlannerL2/steps/requests50/contracts.js';
import { transitionAllowedFor, transitionGroups } from '/_102020_/l2/agentPlannerL2/helpers/p2Transitions.js';
import { isDdmEntity, } from '/_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.js';
import { POOL_NEEDS_FAMILIES, POOL_NEEDS_OPERATIONS, POOL_NEEDS_SCHEMA_VERSION, POOL_NEEDS_SCOPES } from '/_102035_/l2/solution/poolPlan.js';
// Lists and version of needs.json come from the pool's one type (p2_34).
export const P2_NEEDS_SCHEMA_VERSION = POOL_NEEDS_SCHEMA_VERSION;
export const P2_NEEDS_OPERATIONS = POOL_NEEDS_OPERATIONS;
export const P2_NEEDS_SCOPES = POOL_NEEDS_SCOPES;
export const P2_NEEDS_FAMILIES = POOL_NEEDS_FAMILIES;
export const P2_NEEDS_ARTIFACT = 'pool/l1/web/needs.json';
const HOME_ID = /^inicio_/;
const READ_STEP_KINDS = new Set(['locate', 'inspect']);
const SCOPE_RANK = { own: 0, related: 1, organization: 2 };
export function isP2NeedsOperation(value) {
    return P2_NEEDS_OPERATIONS.includes(value);
}
export function isP2NeedsScope(value) {
    return P2_NEEDS_SCOPES.includes(value);
}
export function isP2NeedsFamily(value) {
    return P2_NEEDS_FAMILIES.includes(value);
}
/** kind role → mdm; ddm via isDdmEntity; else tdm. Family is not on the defs. */
export function p2EntityFamily(entity) {
    if (entity.kind === 'role')
        return 'mdm';
    if (isDdmEntity(entity))
        return 'ddm';
    return 'tdm';
}
/** Widest grant wins: own < related < organization. */
export function p2WidestScope(modes) {
    let best = '';
    let rank = -1;
    for (const mode of modes) {
        if (!isP2NeedsScope(mode))
            continue;
        if (SCOPE_RANK[mode] > rank) {
            best = mode;
            rank = SCOPE_RANK[mode];
        }
    }
    return best;
}
export function p2NeedsSubject(moduleName, device = P2_MENU_DEVICE) {
    return `needs of ${moduleName} (${device})`;
}
export function p2NeedsBody(file) {
    return file.pages.map(page => `${page.pageId}: ${page.reads.length} reads / ${page.writes.length} writes`).join('\n');
}
export function buildP2NeedsFile(input) {
    const pages = collectP2NeedsPages(input);
    return {
        schemaVersion: P2_NEEDS_SCHEMA_VERSION,
        moduleName: input.menu.moduleName || input.sources.moduleName,
        device: input.menu.device || P2_MENU_DEVICE,
        menuSchema: P2_MENU_SCHEMA_VERSION,
        pages,
        meta: {
            sourceMenu: `pool/l2/${input.menu.device || P2_MENU_DEVICE}/menu.json`,
            generatedAt: input.now.toISOString(),
        },
    };
}
export function buildP2NeedsMessage(input) {
    return {
        from: 'l2',
        to: 'l1',
        thread: input.received.thread,
        round: input.received.round,
        mode: input.received.mode,
        subject: p2NeedsSubject(input.file.moduleName, input.file.device),
        artifacts: [P2_NEEDS_ARTIFACT],
        body: p2NeedsBody(input.file),
    };
}
export function collectP2NeedsPages(input) {
    const { menu, sources, grants, processes } = input;
    const issues = [];
    const pages = stampedPages(menu.tree);
    const actorsOfPage = pageActors(menu, pages);
    const journeysOfPage = invertIdPages(menu.meta.journeys);
    const processesOfPage = invertIdPages(menu.meta.processes);
    if (!menu.meta.records)
        throw new Error('P2_NEEDS_MENU_RECORDS_MISSING: menu.json has no meta.records; run menu20 again so each form page names the record it keeps.');
    const recordsOfPage = invertIdPages(menu.meta.records);
    const journeyById = new Map(sources.journeys.map(journey => [journey.journeyId, journey]));
    const entityById = new Map(sources.entities.map(entity => [entity.entityId, entity]));
    const beyond = collectBeyondJourneys(sources, grants, processes);
    const homeIds = homePageIds(menu, pages, journeysOfPage);
    const processById = new Map(processes.map(process => [process.processId, process]));
    const out = [];
    for (const page of pages) {
        const actors = actorsOfPage.get(page.id) || [];
        if (homeIds.has(page.id)) {
            out.push(finishPage(page.id, actors, homeReads(page, actors, beyond, entityById, grants, sources), []));
            continue;
        }
        const reads = new Map();
        const writes = new Map();
        const addRead = (entityId, from) => {
            pushRead(reads, entityId, from, entityById, grants, actors, sources);
        };
        const addWrite = (entityId, operation, transitionRef, from) => {
            pushWrite(writes, entityId, operation, transitionRef, from);
        };
        for (const journeyId of journeysOfPage.get(page.id) || []) {
            const journey = journeyById.get(journeyId);
            if (!journey)
                continue;
            const journeySources = [];
            for (const [stepIndex, step] of journey.steps.entries()) {
                const from = journeyFrom(step.stepId, journey, sources);
                if (step.kind === 'decide' && step.entity) {
                    for (const transitionRef of decideTransitions(journey, stepIndex, sources, issues))
                        addWrite(step.entity, 'transition', transitionRef, from);
                }
                if (READ_STEP_KINDS.has(step.kind) && step.entity) {
                    addRead(step.entity, from);
                    journeySources.push(from);
                }
                if (step.kind !== 'act' || !step.entity)
                    continue;
                addRead(step.entity, from);
                journeySources.push(from);
                const operation = isP2NeedsOperation(step.effect || '') ? step.effect : '';
                if (!operation)
                    continue;
                if (operation === 'transition' && !step.transitionRef) {
                    issues.push(`P2_NEEDS_TRANSITION_WITHOUT_REF: journey ${journey.journeyId} step ${step.stepId} writes ${step.entity}.transition without a transitionRef.`);
                    continue;
                }
                addWrite(step.entity, operation, operation === 'transition' ? step.transitionRef : '', from);
            }
            for (const relational of collectJourneyRelationalReads(journey, page, journeySources, sources, entityById, grants, actors)) {
                for (const from of relational.from)
                    addRead(relational.entity, from);
            }
        }
        for (const processId of processesOfPage.get(page.id) || []) {
            const process = processById.get(processId);
            if (!process)
                continue;
            const from = `process:${processId}`;
            for (const task of process.tasks) {
                if (task.entityRef)
                    addRead(task.entityRef, from);
            }
        }
        if (hasOrganism(page, 'summary') || hasOrganism(page, 'highlights')) {
            for (const actorRef of actors) {
                for (const entity of ddmGrantedTo(actorRef, grants, sources)) {
                    addRead(entity.entityId, hasOrganism(page, 'summary') ? 'organism:summary' : 'organism:highlights');
                }
            }
        }
        // A form page without a journey keeps only the records menu20 assigned to it.
        if (hasOrganism(page, 'form') && (journeysOfPage.get(page.id) || []).length === 0) {
            for (const entityId of recordsOfPage.get(page.id) || []) {
                if (!entityById.has(entityId))
                    continue;
                addRead(entityId, 'organism:form');
                addWrite(entityId, 'create', '', 'organism:form');
                addWrite(entityId, 'update', '', 'organism:form');
            }
        }
        out.push(finishPage(page.id, actors, [...reads.values()], [...writes.values()]));
    }
    if (issues.length)
        throw new Error([...new Set(issues)].join(' | '));
    return out;
}
/**
 * The transitions a decide step offers that no act of the journey already writes. The group is the
 * origin-state group of the act that follows the decision; without one, the branching group the
 * journey actor may fire. Only transitions the lifecycle lets that actor fire become writes.
 */
function decideTransitions(journey, stepIndex, sources, issues) {
    const step = journey.steps[stepIndex];
    const groups = transitionGroups(step.entity, sources);
    const written = new Set(journey.steps.filter(item => item.kind === 'act' && item.entity === step.entity && item.transitionRef).map(item => item.transitionRef));
    const next = journey.steps.slice(stepIndex + 1).find(item => item.kind === 'act' && item.entity === step.entity && item.transitionRef);
    const candidates = next
        ? groups.filter(group => group.some(item => item.transitionId === next.transitionRef))
        : groups.filter(group => group.length >= 2 && group.every(item => transitionAllowedFor(item, journey.actorRef)));
    const where = `journey ${journey.journeyId} step ${step.stepId} (${step.entity})`;
    if (!candidates.length) {
        issues.push(`P2_NEEDS_DECIDE_GROUP_EMPTY: ${where} has no transition group to decide between.`);
        return [];
    }
    if (candidates.length > 1) {
        issues.push(`P2_NEEDS_DECIDE_GROUP_AMBIGUOUS: ${where} matches the groups ${candidates.map(group => `[${group.map(item => item.transitionId).join(', ')}]`).join(' and ')}.`);
        return [];
    }
    return candidates[0].filter(item => !written.has(item.transitionId) && transitionAllowedFor(item, journey.actorRef)).map(item => item.transitionId);
}
function homeReads(page, actors, beyond, entityById, grants, sources) {
    const reads = new Map();
    const see = beyond.filter(row => actors.includes(row.actorRef));
    const add = (entityId, from) => {
        pushRead(reads, entityId, from, entityById, grants, actors, sources);
    };
    if (hasOrganism(page, 'summary') || hasOrganism(page, 'highlights')) {
        const from = hasOrganism(page, 'summary') ? 'organism:summary' : 'organism:highlights';
        for (const row of see) {
            for (const item of row.derived) {
                if (item.entityRef)
                    add(item.entityRef, from);
            }
        }
    }
    if (hasOrganism(page, 'alerts')) {
        for (const row of see) {
            for (const task of row.mechanicalEffects) {
                if (task.entityRef)
                    add(task.entityRef, 'organism:alerts');
            }
        }
    }
    if (hasOrganism(page, 'inbox')) {
        for (const row of see) {
            for (const task of row.human) {
                if (task.entityRef)
                    add(task.entityRef, 'organism:inbox');
            }
        }
    }
    return [...reads.values()];
}
function pushRead(reads, entityId, from, entityById, grants, actors, sources) {
    if (!entityId)
        return;
    const entity = entityById.get(entityId);
    const family = entity ? p2EntityFamily(entity) : 'tdm';
    const eligibleGrants = grants.filter(grant => actors.includes(grant.actorRef) && grant.entityRefs.includes(entityId));
    const scope = p2WidestScope(eligibleGrants.map(grant => grant.dataScope.mode));
    if (!scope)
        return;
    const provenance = [...from.split('\n'), ...eligibleGrants.map(grant => `grant:${grant.grantId}`)];
    const derived = derivedFieldNames(entityId, sources);
    const current = reads.get(entityId);
    if (!current) {
        reads.set(entityId, {
            entity: entityId,
            family,
            scope,
            derived,
            from: mergeFrom(provenance),
        });
        return;
    }
    current.scope = p2WidestScope([current.scope, scope]) || current.scope;
    current.from = mergeFrom([...current.from, ...provenance]);
    current.derived = mergeNames([...current.derived, ...derived]);
}
function collectJourneyRelationalReads(journey, page, journeySources, sources, entityById, grants, actors) {
    const edges = relationshipEdges(sources);
    const context = semanticTerms([
        journey.title,
        journey.goal || '',
        ...page.organisms.map(organism => organism.text),
    ].join(' '));
    const queue = journey.steps
        .filter(step => step.entity && (READ_STEP_KINDS.has(step.kind) || step.kind === 'act'))
        .map(step => ({ entity: step.entity, depth: 0, path: [] }));
    const visited = new Set();
    const out = new Map();
    while (queue.length) {
        const current = queue.shift();
        if (!current || visited.has(current.entity))
            continue;
        visited.add(current.entity);
        for (const edge of edges) {
            const next = edge.left === current.entity ? edge.right : edge.right === current.entity ? edge.left : '';
            if (!next || next === current.entity || !entityById.has(next))
                continue;
            const candidate = sources.ontologyEntities.find(item => text(record(item).entityId) === next);
            if (!hasSemanticRelation(context, edge.prose, candidate))
                continue;
            const nextPath = [...current.path, edge.reference];
            const access = grants.some(grant => actors.includes(grant.actorRef) && grant.entityRefs.includes(next));
            if (!access)
                continue;
            const sourceRefs = mergeFrom([
                ...journeySources,
                ...nextPath.map(reference => `relationship:${reference}`),
            ]);
            const existing = out.get(next);
            if (existing)
                existing.from = mergeFrom([...existing.from, ...sourceRefs]);
            else
                out.set(next, { entity: next, from: sourceRefs });
            if (!visited.has(next))
                queue.push({ entity: next, depth: current.depth + 1, path: nextPath });
        }
    }
    return [...out.values()];
}
function relationshipEdges(sources) {
    const edges = new Map();
    for (const raw of sources.ontologyEntities) {
        const entity = record(raw);
        const left = text(entity.entityId);
        if (!left)
            continue;
        const relationships = record(entity.relationships);
        for (const relationship of Object.values(relationships)) {
            const item = record(relationship);
            const right = text(item.to);
            const relationshipId = text(item.relationshipId);
            if (!right || !relationshipId)
                continue;
            const reference = `${left}/${relationshipId}`;
            edges.set(reference, {
                left,
                right,
                reference,
                prose: [text(item.title), text(item.description)].filter(Boolean).join(' '),
            });
        }
    }
    return [...edges.values()];
}
function hasSemanticRelation(context, relationshipProse, candidate) {
    if (context.size === 0)
        return false;
    const entity = record(candidate);
    const relationshipOverlap = semanticOverlap(context, semanticTerms(relationshipProse));
    const entityOverlap = semanticOverlap(context, semanticTerms(text(entity.description)));
    return relationshipOverlap.length > 0 && new Set([...relationshipOverlap, ...entityOverlap]).size >= 2;
}
function semanticOverlap(context, evidence) {
    const matches = new Set();
    for (const left of context) {
        for (const right of evidence) {
            if (left === right || left.startsWith(right) || right.startsWith(left)) {
                matches.add(left.length >= right.length ? left : right);
            }
        }
    }
    return [...matches];
}
function semanticTerms(value) {
    return new Set(normalizeTokens(value).filter(word => word.length >= 5));
}
function normalizeTokens(value) {
    return value.normalize('NFD').replace(/[\u0300-\u036f]/gu, '').toLocaleLowerCase()
        .split(/[^a-z0-9]+/u).filter(Boolean);
}
function pushWrite(writes, entityId, operation, transitionRef, from) {
    const key = `${entityId}\0${operation}\0${transitionRef}`;
    const current = writes.get(key);
    if (!current) {
        writes.set(key, { entity: entityId, operation, transitionRef, from: mergeFrom([from]) });
        return;
    }
    current.from = mergeFrom([...current.from, from]);
}
function finishPage(pageId, actors, reads, writes) {
    return {
        pageId,
        actors: [...actors].sort((left, right) => left.localeCompare(right)),
        reads: reads.sort((left, right) => left.entity.localeCompare(right.entity)),
        writes: writes.sort((left, right) => {
            const entity = left.entity.localeCompare(right.entity);
            if (entity !== 0)
                return entity;
            const operation = left.operation.localeCompare(right.operation);
            return operation !== 0 ? operation : left.transitionRef.localeCompare(right.transitionRef);
        }),
    };
}
function journeyFrom(stepId, journey, sources) {
    const workspace = {
        workspaceId: journey.journeyId,
        title: journey.title,
        kind: 'catalogue',
        entityRef: '',
        actorRefs: [journey.actorRef],
        journeyRefs: [journey.journeyId],
        stepRefs: [stepId],
    };
    const resolved = journeyStepOf(stepId, workspace, sources);
    return `journey:${resolved.journeyId}/${resolved.stepId}`;
}
function derivedFieldNames(entityId, sources) {
    const raw = sources.ontologyEntities.find(item => item.entityId === entityId);
    if (!raw)
        return [];
    const names = [];
    const entity = record(raw);
    walkDerivedFields(record(record(entity.record).fields), false, '', (path) => names.push(path));
    return mergeNames(names);
}
function walkDerivedFields(fields, platform, prefix, visit) {
    for (const [id, raw] of Object.entries(fields)) {
        const field = record(raw);
        const nextPlatform = platform || text(field.owner) === 'platform';
        const path = prefix ? `${prefix}.${id}` : id;
        const nested = field.fields;
        const container = isRecord(nested) && Object.keys(nested).length > 0;
        if (!nextPlatform && field.derived === true && id !== 'id' && id !== 'version' && !container) {
            visit(path);
        }
        if (isRecord(nested))
            walkDerivedFields(nested, nextPlatform, path, visit);
    }
}
function ddmGrantedTo(actorRef, grants, sources) {
    const granted = new Set();
    for (const grant of grants) {
        if (grant.actorRef !== actorRef)
            continue;
        for (const entityRef of grant.entityRefs)
            granted.add(entityRef);
    }
    return sources.entities.filter(entity => granted.has(entity.entityId) && isDdmEntity(entity));
}
function homePageIds(menu, pages, journeysOfPage) {
    const pageIds = new Set(pages.map(page => page.id));
    const homes = new Set();
    for (const page of pages) {
        const journeys = journeysOfPage.get(page.id) || [];
        if (journeys.length)
            continue;
        if (HOME_ID.test(page.id))
            homes.add(page.id);
    }
    for (const actorRef of Object.keys(menu.authorities).map(actorFromKey).filter(Boolean)) {
        const first = firstVisiblePage(menu, actorRef, pageIds);
        if (first && !(journeysOfPage.get(first) || []).length)
            homes.add(first);
    }
    return homes;
}
function firstVisiblePage(menu, actorRef, pageIds) {
    const listed = menu.authorities[actorAuthorityKey(actorRef)] || [];
    const byId = indexTree(menu.tree);
    for (const id of listed) {
        const first = firstPageFrom(byId.get(id), pageIds);
        if (first)
            return first;
    }
    return '';
}
function firstPageFrom(node, pageIds) {
    if (!node)
        return '';
    if (node.kind === 'page' && pageIds.has(node.id))
        return node.id;
    if (node.kind === 'hub' || node.kind === 'group') {
        for (const child of node.children) {
            const found = firstPageFrom(child, pageIds);
            if (found)
                return found;
        }
    }
    return '';
}
function pageActors(menu, pages) {
    const pageIds = new Set(pages.map(page => page.id));
    const out = new Map();
    for (const page of pages)
        out.set(page.id, []);
    for (const [key, listed] of Object.entries(menu.authorities)) {
        const actorRef = actorFromKey(key);
        if (!actorRef)
            continue;
        const visible = new Set();
        const byId = indexTree(menu.tree);
        for (const id of listed)
            collectPageIds(byId.get(id), pageIds, visible);
        for (const pageId of visible) {
            const row = out.get(pageId);
            if (row && !row.includes(actorRef))
                row.push(actorRef);
        }
    }
    return out;
}
function collectPageIds(node, pageIds, out) {
    if (!node)
        return;
    if (node.kind === 'page' && pageIds.has(node.id))
        out.add(node.id);
    if (node.kind === 'hub' || node.kind === 'group') {
        for (const child of node.children)
            collectPageIds(child, pageIds, out);
    }
}
function indexTree(nodes) {
    const out = new Map();
    const walk = (list) => {
        for (const node of list) {
            out.set(node.id, node);
            if (node.kind === 'hub' || node.kind === 'group')
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function stampedPages(nodes) {
    const out = [];
    const walk = (list) => {
        for (const node of list) {
            if (node.kind === 'page')
                out.push(node);
            else
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function invertIdPages(map) {
    const out = new Map();
    for (const [id, pages] of Object.entries(map || {})) {
        for (const pageId of pages) {
            const row = out.get(pageId) || [];
            if (!row.includes(id))
                row.push(id);
            out.set(pageId, row);
        }
    }
    return out;
}
function hasOrganism(page, kind) {
    return page.organisms.some(organism => organism.kind === kind);
}
function actorFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : '';
}
function mergeFrom(values) {
    return mergeNames(values.filter(Boolean));
}
function mergeNames(values) {
    return [...new Set(values.filter(Boolean))].sort((left, right) => left.localeCompare(right));
}
function record(value) {
    return isRecord(value) ? value : {};
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value !== 'function' && typeof value === 'object' && !Array.isArray(value);
}
