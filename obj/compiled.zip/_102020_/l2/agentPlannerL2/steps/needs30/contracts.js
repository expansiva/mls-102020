/// <mls fileReference="_102020_/l2/agentPlannerL2/steps/needs30/contracts.ts" enhancement="_blank"/>
import { P2_MENU_DEVICE, } from '/_102020_/l2/agentPlannerL2/helpers/p2Core.js';
import { P2_MENU_SCHEMA_VERSION, actorAuthorityKey, collectBeyondJourneys, } from '/_102020_/l2/agentPlannerL2/steps/menu20/contracts.js';
import { journeyStepOf } from '/_102020_/l2/agentPlannerL2/steps/requests50/contracts.js';
import { isDdmEntity, } from '/_102020_/l2/agentPlannerL2/steps/workspaces20/contracts.js';
export const P2_NEEDS_SCHEMA_VERSION = '2026-09-21-p2-needs-v1';
export const P2_NEEDS_OPERATIONS = ['create', 'update', 'transition', 'delete'];
export const P2_NEEDS_SCOPES = ['own', 'related', 'organization'];
export const P2_NEEDS_FAMILIES = ['mdm', 'ddm', 'tdm'];
export const P2_NEEDS_ARTIFACT = 'pool/l1/web/needs.json';
const HOME_ID = /^inicio_/;
const READ_STEP_KINDS = new Set(['locate', 'inspect']);
const SCOPE_RANK = { own: 0, related: 1, organization: 2 };
export function isP2NeedsOperation(value) {
    return P2_NEEDS_OPERATIONS.includes(value);
}
export function isP2NeedsScope(value) {
    return P2_NEEDS_SCOPES.includes(value);
}
export function isP2NeedsFamily(value) {
    return P2_NEEDS_FAMILIES.includes(value);
}
/** kind role → mdm; ddm via isDdmEntity; else tdm. Family is not on the defs. */
export function p2EntityFamily(entity) {
    if (entity.kind === 'role')
        return 'mdm';
    if (isDdmEntity(entity))
        return 'ddm';
    return 'tdm';
}
/** Widest grant wins: own < related < organization. */
export function p2WidestScope(modes) {
    let best = '';
    let rank = -1;
    for (const mode of modes) {
        if (!isP2NeedsScope(mode))
            continue;
        if (SCOPE_RANK[mode] > rank) {
            best = mode;
            rank = SCOPE_RANK[mode];
        }
    }
    return best;
}
export function p2NeedsSubject(moduleName, device = P2_MENU_DEVICE) {
    return `needs of ${moduleName} (${device})`;
}
export function p2NeedsBody(file) {
    return file.pages.map(page => `${page.pageId}: ${page.reads.length} reads / ${page.writes.length} writes`).join('\n');
}
export function buildP2NeedsFile(input) {
    const pages = collectP2NeedsPages(input);
    return {
        schemaVersion: P2_NEEDS_SCHEMA_VERSION,
        moduleName: input.menu.moduleName || input.sources.moduleName,
        device: input.menu.device || P2_MENU_DEVICE,
        menuSchema: P2_MENU_SCHEMA_VERSION,
        pages,
        meta: {
            sourceMenu: `pool/l2/${input.menu.device || P2_MENU_DEVICE}/menu.json`,
            generatedAt: input.now.toISOString(),
        },
    };
}
export function buildP2NeedsMessage(input) {
    return {
        from: 'l2',
        to: 'l1',
        thread: input.received.thread,
        round: input.received.round,
        mode: input.received.mode,
        subject: p2NeedsSubject(input.file.moduleName, input.file.device),
        artifacts: [P2_NEEDS_ARTIFACT],
        body: p2NeedsBody(input.file),
    };
}
export function collectP2NeedsPages(input) {
    const { menu, sources, grants, processes } = input;
    const pages = stampedPages(menu.tree);
    const actorsOfPage = pageActors(menu, pages);
    const journeysOfPage = invertIdPages(menu.meta.journeys);
    const processesOfPage = invertIdPages(menu.meta.processes);
    const journeyById = new Map(sources.journeys.map(journey => [journey.journeyId, journey]));
    const entityById = new Map(sources.entities.map(entity => [entity.entityId, entity]));
    const beyond = collectBeyondJourneys(sources, grants, processes);
    const homeIds = homePageIds(menu, pages, journeysOfPage);
    const processById = new Map(processes.map(process => [process.processId, process]));
    const out = [];
    for (const page of pages) {
        const actors = actorsOfPage.get(page.id) || [];
        if (homeIds.has(page.id)) {
            out.push(finishPage(page.id, actors, homeReads(page, actors, beyond, entityById, grants, sources), []));
            continue;
        }
        const reads = new Map();
        const writes = new Map();
        const addRead = (entityId, from) => {
            pushRead(reads, entityId, from, entityById, grants, actors, sources);
        };
        const addWrite = (entityId, operation, transitionRef, from) => {
            pushWrite(writes, entityId, operation, transitionRef, from);
        };
        for (const journeyId of journeysOfPage.get(page.id) || []) {
            const journey = journeyById.get(journeyId);
            if (!journey)
                continue;
            for (const step of journey.steps) {
                const from = journeyFrom(step.stepId, journey, sources);
                if (READ_STEP_KINDS.has(step.kind) && step.entity)
                    addRead(step.entity, from);
                if (step.kind !== 'act' || !step.entity)
                    continue;
                addRead(step.entity, from);
                const operation = isP2NeedsOperation(step.effect || '') ? step.effect : '';
                if (!operation)
                    continue;
                addWrite(step.entity, operation, operation === 'transition' ? (step.transitionRef || '') : '', from);
            }
        }
        for (const processId of processesOfPage.get(page.id) || []) {
            const process = processById.get(processId);
            if (!process)
                continue;
            const from = `process:${processId}`;
            for (const task of process.tasks) {
                if (task.entityRef)
                    addRead(task.entityRef, from);
            }
        }
        if (hasOrganism(page, 'summary') || hasOrganism(page, 'highlights')) {
            for (const actorRef of actors) {
                for (const entity of ddmGrantedTo(actorRef, grants, sources)) {
                    addRead(entity.entityId, hasOrganism(page, 'summary') ? 'organism:summary' : 'organism:highlights');
                }
            }
        }
        if (hasOrganism(page, 'form') && (journeysOfPage.get(page.id) || []).length === 0) {
            for (const entity of crudReachedBy(actors, grants, sources)) {
                addRead(entity.entityId, 'organism:form');
                addWrite(entity.entityId, 'create', '', 'organism:form');
                addWrite(entity.entityId, 'update', '', 'organism:form');
            }
        }
        out.push(finishPage(page.id, actors, [...reads.values()], [...writes.values()]));
    }
    return out;
}
function homeReads(page, actors, beyond, entityById, grants, sources) {
    const reads = new Map();
    const see = beyond.filter(row => actors.includes(row.actorRef));
    const add = (entityId, from) => {
        pushRead(reads, entityId, from, entityById, grants, actors, sources);
    };
    if (hasOrganism(page, 'summary') || hasOrganism(page, 'highlights')) {
        const from = hasOrganism(page, 'summary') ? 'organism:summary' : 'organism:highlights';
        for (const row of see) {
            for (const item of row.derived) {
                if (item.entityRef)
                    add(item.entityRef, from);
            }
        }
    }
    if (hasOrganism(page, 'alerts')) {
        for (const row of see) {
            for (const task of row.mechanicalEffects) {
                if (task.entityRef)
                    add(task.entityRef, 'organism:alerts');
            }
        }
    }
    if (hasOrganism(page, 'inbox')) {
        for (const row of see) {
            for (const task of row.human) {
                if (task.entityRef)
                    add(task.entityRef, 'organism:inbox');
            }
        }
    }
    return [...reads.values()];
}
function pushRead(reads, entityId, from, entityById, grants, actors, sources) {
    if (!entityId)
        return;
    const entity = entityById.get(entityId);
    const family = entity ? p2EntityFamily(entity) : 'tdm';
    const scope = p2WidestScope(scopeModes(actors, entityId, grants));
    if (!scope)
        return;
    const derived = derivedFieldNames(entityId, sources);
    const current = reads.get(entityId);
    if (!current) {
        reads.set(entityId, {
            entity: entityId,
            family,
            scope,
            derived,
            from: mergeFrom([from]),
        });
        return;
    }
    current.scope = p2WidestScope([current.scope, scope]) || current.scope;
    current.from = mergeFrom([...current.from, from]);
    current.derived = mergeNames([...current.derived, ...derived]);
}
function pushWrite(writes, entityId, operation, transitionRef, from) {
    const key = `${entityId}\0${operation}\0${transitionRef}`;
    const current = writes.get(key);
    if (!current) {
        writes.set(key, { entity: entityId, operation, transitionRef, from: mergeFrom([from]) });
        return;
    }
    current.from = mergeFrom([...current.from, from]);
}
function finishPage(pageId, actors, reads, writes) {
    return {
        pageId,
        actors: [...actors].sort((left, right) => left.localeCompare(right)),
        reads: reads.sort((left, right) => left.entity.localeCompare(right.entity)),
        writes: writes.sort((left, right) => {
            const entity = left.entity.localeCompare(right.entity);
            if (entity !== 0)
                return entity;
            const operation = left.operation.localeCompare(right.operation);
            return operation !== 0 ? operation : left.transitionRef.localeCompare(right.transitionRef);
        }),
    };
}
function journeyFrom(stepId, journey, sources) {
    const workspace = {
        workspaceId: journey.journeyId,
        title: journey.title,
        kind: 'catalogue',
        entityRef: '',
        actorRefs: [journey.actorRef],
        journeyRefs: [journey.journeyId],
        stepRefs: [stepId],
    };
    const resolved = journeyStepOf(stepId, workspace, sources);
    return `journey:${resolved.journeyId}/${resolved.stepId}`;
}
function derivedFieldNames(entityId, sources) {
    const raw = sources.ontologyEntities.find(item => item.entityId === entityId);
    if (!raw)
        return [];
    const names = [];
    const entity = record(raw);
    walkDerivedFields(record(record(entity.record).fields), false, '', (path) => names.push(path));
    return mergeNames(names);
}
function walkDerivedFields(fields, platform, prefix, visit) {
    for (const [id, raw] of Object.entries(fields)) {
        const field = record(raw);
        const nextPlatform = platform || text(field.owner) === 'platform';
        const path = prefix ? `${prefix}.${id}` : id;
        const nested = field.fields;
        const container = isRecord(nested) && Object.keys(nested).length > 0;
        if (!nextPlatform && field.derived === true && id !== 'id' && id !== 'version' && !container) {
            visit(path);
        }
        if (isRecord(nested))
            walkDerivedFields(nested, nextPlatform, path, visit);
    }
}
function scopeModes(actors, entityId, grants) {
    const modes = [];
    for (const grant of grants) {
        if (!actors.includes(grant.actorRef))
            continue;
        if (!grant.entityRefs.includes(entityId))
            continue;
        if (grant.dataScope.mode)
            modes.push(grant.dataScope.mode);
    }
    return modes;
}
function crudReachedBy(actors, grants, sources) {
    const crud = new Set(sources.entities.filter(entity => entity.writer === 'crud' && entity.entityId).map(entity => entity.entityId));
    const reached = new Set();
    for (const grant of grants) {
        if (!actors.includes(grant.actorRef))
            continue;
        for (const entityRef of grant.entityRefs) {
            if (crud.has(entityRef))
                reached.add(entityRef);
        }
    }
    return sources.entities.filter(entity => reached.has(entity.entityId));
}
function ddmGrantedTo(actorRef, grants, sources) {
    const granted = new Set();
    for (const grant of grants) {
        if (grant.actorRef !== actorRef)
            continue;
        for (const entityRef of grant.entityRefs)
            granted.add(entityRef);
    }
    return sources.entities.filter(entity => granted.has(entity.entityId) && isDdmEntity(entity));
}
function homePageIds(menu, pages, journeysOfPage) {
    const pageIds = new Set(pages.map(page => page.id));
    const homes = new Set();
    for (const page of pages) {
        const journeys = journeysOfPage.get(page.id) || [];
        if (journeys.length)
            continue;
        if (HOME_ID.test(page.id))
            homes.add(page.id);
    }
    for (const actorRef of Object.keys(menu.authorities).map(actorFromKey).filter(Boolean)) {
        const first = firstVisiblePage(menu, actorRef, pageIds);
        if (first && !(journeysOfPage.get(first) || []).length)
            homes.add(first);
    }
    return homes;
}
function firstVisiblePage(menu, actorRef, pageIds) {
    const listed = menu.authorities[actorAuthorityKey(actorRef)] || [];
    const byId = indexTree(menu.tree);
    for (const id of listed) {
        const first = firstPageFrom(byId.get(id), pageIds);
        if (first)
            return first;
    }
    return '';
}
function firstPageFrom(node, pageIds) {
    if (!node)
        return '';
    if (node.kind === 'page' && pageIds.has(node.id))
        return node.id;
    if (node.kind === 'hub' || node.kind === 'group') {
        for (const child of node.children) {
            const found = firstPageFrom(child, pageIds);
            if (found)
                return found;
        }
    }
    return '';
}
function pageActors(menu, pages) {
    const pageIds = new Set(pages.map(page => page.id));
    const out = new Map();
    for (const page of pages)
        out.set(page.id, []);
    for (const [key, listed] of Object.entries(menu.authorities)) {
        const actorRef = actorFromKey(key);
        if (!actorRef)
            continue;
        const visible = new Set();
        const byId = indexTree(menu.tree);
        for (const id of listed)
            collectPageIds(byId.get(id), pageIds, visible);
        for (const pageId of visible) {
            const row = out.get(pageId);
            if (row && !row.includes(actorRef))
                row.push(actorRef);
        }
    }
    return out;
}
function collectPageIds(node, pageIds, out) {
    if (!node)
        return;
    if (node.kind === 'page' && pageIds.has(node.id))
        out.add(node.id);
    if (node.kind === 'hub' || node.kind === 'group') {
        for (const child of node.children)
            collectPageIds(child, pageIds, out);
    }
}
function indexTree(nodes) {
    const out = new Map();
    const walk = (list) => {
        for (const node of list) {
            out.set(node.id, node);
            if (node.kind === 'hub' || node.kind === 'group')
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function stampedPages(nodes) {
    const out = [];
    const walk = (list) => {
        for (const node of list) {
            if (node.kind === 'page')
                out.push(node);
            else
                walk(node.children);
        }
    };
    walk(nodes);
    return out;
}
function invertIdPages(map) {
    const out = new Map();
    for (const [id, pages] of Object.entries(map || {})) {
        for (const pageId of pages) {
            const row = out.get(pageId) || [];
            if (!row.includes(id))
                row.push(id);
            out.set(pageId, row);
        }
    }
    return out;
}
function hasOrganism(page, kind) {
    return page.organisms.some(organism => organism.kind === kind);
}
function actorFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : '';
}
function mergeFrom(values) {
    return mergeNames(values.filter(Boolean));
}
function mergeNames(values) {
    return [...new Set(values.filter(Boolean))].sort((left, right) => left.localeCompare(right));
}
function record(value) {
    return isRecord(value) ? value : {};
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value !== 'function' && typeof value === 'object' && !Array.isArray(value);
}
