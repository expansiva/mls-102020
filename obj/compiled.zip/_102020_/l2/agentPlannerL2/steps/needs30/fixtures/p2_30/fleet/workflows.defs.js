/// <mls fileReference="_102047_/l4/manutencaoFrota/workflows.defs.ts" enhancement="_blank"/>
export const manutencaoFrotaWorkflows = {
    "schemaVersion": "2026-09-17-ns5-workflows-v3",
    "moduleName": "manutencaoFrota",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "registrarAbastecimento",
            "inProcess": false
        },
        {
            "journeyId": "consultarVeiculosAtribuidos",
            "inProcess": false
        },
        {
            "journeyId": "cadastrarPlanoPreventivo",
            "inProcess": false
        },
        {
            "journeyId": "abrirOrdemPorDefeito",
            "inProcess": false
        },
        {
            "journeyId": "tratarAlertaPreventivaVencida",
            "inProcess": false
        },
        {
            "journeyId": "atualizarOrdemManutencao",
            "inProcess": false
        }
    ]
};
export default manutencaoFrotaWorkflows;
