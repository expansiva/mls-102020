/// <mls fileReference="_102020_/l2/aura/services/serviceBehavior.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { AuraInitState, getAuraState, moduleScopeTitle } from '/_102020_/l2/aura/helpers/auraState.js';
import '/_102020_/l2/aura/widgets/auraSelectKnob.js';
import '/_102020_/l2/aura/plugins/selectWorkflow.js';
import '/_102020_/l2/aura/plugins/selectRule.js';
/// **collab_i18n_start**
const message_en = {
    svcTitle: 'Behavior',
    workflow: 'Workflows',
    rule: 'Rules',
};
const messages = {
    en: message_en,
    pt: {
        svcTitle: 'Comportamento',
        workflow: 'Workflows',
        rule: 'Regras',
    },
    es: {
        svcTitle: 'Comportamiento',
        workflow: 'Workflows',
        rule: 'Reglas',
    },
};
let ServiceBehavior102020 = class ServiceBehavior102020 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aura--services--service-behavior-102020 {
  display: block;
}
`);
        this.details = {
            icon: '&#xf0f6',
            state: 'foreground',
            position: 'left',
            tooltip: 'Behavior',
            visible: true,
            widget: '_102020_/l2/aura/services/serviceBehavior',
            level: [4],
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: undefined,
            onClickMain: this.onClickMain.bind(this),
        };
        //State
        this.msg = message_en;
        this._modules = [];
        this._workflowConfig = { key: 'workflow', min: 0, max: 0, labels: { 0: 'All' } };
        this._ruleConfig = { key: 'rule', min: 0, max: 0, labels: { 0: 'All' } };
        this._workflowValue = 0;
        this._ruleValue = null;
        this._workflowReloadToken = 0;
        this._selectedKnob = 'workflow';
    }
    onClickMain(_op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onServiceClick(visible, _reinit, _el) {
        this._workflowReloadToken += 1; // re-scan the workflow list on each service (re)open
        this._updateMenuTitle();
        if (visible)
            this._openModuleBlueprint();
        // @ts-ignore
        this.requestUpdate();
    }
    /**
     * The module workspace belongs to master-solution (102035), but is hosted by the
     * Studio's existing detail service. Keeping this bridge event-only avoids making
     * the frontend master depend on the solution generator.
     */
    _openModuleBlueprint() {
        const { actualProject, actualModule } = getAuraState();
        if (!actualProject)
            return;
        const escapeAttribute = (value) => String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        const htmlText = `<new-release--widgets--index-102035 project="${escapeAttribute(actualProject)}" module-name="${escapeAttribute(actualModule)}"></new-release--widgets--index-102035>`;
        mls.events.fire(4, 'PluginDetails', JSON.stringify({
            project: 102035,
            shortName: 'l2/newRelease/widgets/index',
            htmlText,
        }), 0);
    }
    /** nav-3 menu title: project + module this service is acting on (module picked at l5). */
    _updateMenuTitle() {
        this.menu.title = moduleScopeTitle();
        this.menu.updateTitle?.();
    }
    //Data Loading
    async _loadData() {
        const project = getAuraState().actualProject;
        if (!project)
            return;
        try {
            const mod = await import(`/_${project}_/l2/project.js`);
            this._modules = mod?.projectConfig?.modules ?? [];
            this._ruleValue = 0;
        }
        catch {
            this._modules = [];
        }
        // @ts-ignore
        this.requestUpdate();
    }
    get _selectedModule() {
        const actualModule = getAuraState().actualModule;
        if (!actualModule)
            return null;
        return this._modules.find(m => m.name === actualModule) ?? null;
    }
    //Helpers
    get _knobValues() {
        return {
            workflow: this._workflowValue,
            rule: this._ruleValue,
        };
    }
    _getKnobConfig(key) {
        switch (key) {
            case 'workflow': return this._workflowConfig;
            case 'rule': return this._ruleConfig;
            default: return { key, min: 0, max: 0, labels: {}, disabled: true };
        }
    }
    _setKnobValue(key, value) {
        switch (key) {
            case 'workflow':
                this._workflowValue = value;
                break;
            case 'rule':
                this._ruleValue = value;
                break;
        }
        // @ts-ignore
        this.requestUpdate();
    }
    //Event Handlers
    _onKnobChange(key, e) {
        this._selectedKnob = key;
        this._setKnobValue(key, e.detail.value);
    }
    _onKnobClick(key) {
        this._selectedKnob = key;
        // @ts-ignore
        this.requestUpdate();
    }
    //Lifecycle
    connectedCallback() {
        super.connectedCallback();
        AuraInitState();
        this._loadData();
        this._updateMenuTitle();
    }
    //Render
    createRenderRoot() { return this; }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="flex flex-col min-h-full bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-200">
                ${this._renderKnobRow()}
                ${this._renderDetailsRow()}
            </div>
        `;
    }
    //Knob Row
    _renderKnobRow() {
        return html `
            <div class="
                flex items-center justify-center
                px-2 py-3
                border-b border-gray-200 dark:border-gray-800
                gap-0
            " style="--knob-scale: 0.5">
                ${this._renderKnobItem('workflow')}
                ${this._renderKnobItem('rule')}
            </div>
        `;
    }
    _renderKnobItem(key) {
        const config = this._getKnobConfig(key);
        const value = this._knobValues[key];
        const isContext = this._selectedKnob === key;
        const isDisabled = config.disabled ?? false;
        const label = this.msg[key] || key;
        return html `
            <div class="flex flex-col items-center gap-0.5 ${isDisabled ? 'opacity-30' : ''}">
                <aura--widgets--aura-select-knob-102020
                    .min=${config.min}
                    .max=${config.max}
                    .value=${value}
                    .step=${1}
                    .active=${true}
                    .disabled=${isDisabled}
                    .selected=${isContext}
                    .showTicks=${false}
                    @knob-change=${(e) => this._onKnobChange(key, e)}
                ></aura--widgets--aura-select-knob-102020>

                <div
                    class="flex flex-col items-center gap-0.5 cursor-pointer"
                    @click=${() => this._onKnobClick(key)}
                >
                    <span class="
                        text-[9px] font-semibold uppercase tracking-wider
                        ${isContext
            ? 'text-gray-700 dark:text-gray-200'
            : 'text-gray-400 dark:text-gray-600'}
                        transition-colors duration-200
                    ">${label}</span>

                    <div class="
                        w-full h-0.5 rounded-full
                        transition-all duration-200
                        ${isContext
            ? 'bg-cyan-400 shadow-[0_0_4px_1px_rgba(34,211,238,0.6),0_0_8px_2px_rgba(34,211,238,0.3)]'
            : 'bg-transparent'}
                    "></div>
                </div>
            </div>
        `;
    }
    //Details Row
    _onWorkflowConfig(e) {
        const { min, max, labels } = e.detail;
        this._workflowConfig = { key: 'workflow', min, max, labels };
        // @ts-ignore
        this.requestUpdate();
    }
    _onRuleConfig(e) {
        const { min, max, labels } = e.detail;
        this._ruleConfig = { key: 'rule', min, max, labels };
        // @ts-ignore
        this.requestUpdate();
    }
    _renderDetailsRow() {
        return html `
            <div class="flex flex-col flex-1">
                <div class="flex flex-col gap-3 px-4 py-4 flex-1"
                    @select-workflow=${(e) => this._setKnobValue('workflow', e.detail.value)}
                    @workflow-config=${(e) => this._onWorkflowConfig(e)}
                    @select-rule=${(e) => this._setKnobValue('rule', e.detail.value)}
                    @rule-config=${(e) => this._onRuleConfig(e)}
                >
                    ${this._renderContextStatusArea()}
                </div>
            </div>
        `;
    }
    _renderContextStatusArea() {
        switch (this._selectedKnob) {
            case 'workflow':
                return html `
                    <aura--plugins--select-workflow-102020
                        .value=${this._workflowValue}
                        .reloadToken=${this._workflowReloadToken}
                    ></aura--plugins--select-workflow-102020>
                `;
            case 'rule':
                return html `
                    <aura--plugins--select-rule-102020
                        .selectedModule=${this._selectedModule}
                        .value=${this._ruleValue}
                        @select-rule=${(e) => this._setKnobValue('rule', e.detail.value)}
                    ></aura--plugins--select-rule-102020>
                `;
            default:
                return nothing;
        }
    }
};
__decorate([
    state()
], ServiceBehavior102020.prototype, "msg", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_modules", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_workflowConfig", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_ruleConfig", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_workflowValue", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_ruleValue", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_workflowReloadToken", void 0);
__decorate([
    state()
], ServiceBehavior102020.prototype, "_selectedKnob", void 0);
ServiceBehavior102020 = __decorate([
    customElement('aura--services--service-behavior-102020')
], ServiceBehavior102020);
export { ServiceBehavior102020 };
