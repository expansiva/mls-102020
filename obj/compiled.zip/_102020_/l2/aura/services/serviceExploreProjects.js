/// <mls fileReference="_102020_/l2/aura/services/serviceExploreProjects.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { checkIfHasLocalProject, getLocalProjectName } from '/_102027_/l2/libCommom.js';
import { isStudioClient, getStudioScopeProject } from '/_102027_/l2/utils.js';
import { AuraInitState, getAuraState } from '/_102020_/l2/aura/helpers/auraState.js';
import '/_102020_/l2/aura/widgets/auraSelectKnob.js';
import '/_102020_/l2/aura/plugins/selectOrganization.js';
import '/_102020_/l2/aura/plugins/selectProject.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    svcTitle: 'Explore Projects',
    organization: 'Organization',
    project: 'Project',
    orgScenarioTitle: 'Select Organization',
    orgScenarioDesc: 'An organization groups multiple projects under the same umbrella. Select one to browse the projects available to your team.',
    orgAllTitle: 'All Organizations',
    orgAllDesc: 'Overview of all organizations available in the system.',
    orgCustomTitle: 'New Organization',
    orgCustomDesc: 'Create a new organization to group your projects.',
    projectScenarioTitle: 'Select Project',
    projectScenarioDesc: 'A project is a deliverable within an organization — it contains pages, components, and all generated code.',
    projectAllTitle: 'All Projects',
    projectAllDesc: 'Overview of all projects in this organization.',
    projectCustomTitle: 'New Project',
    projectCustomDesc: 'Create a new project within this organization.',
    projectNeedsOrg: 'Select an organization first to see the available projects.',
    projects: 'projects',
    noOrgs: 'No organizations found.',
};
const messages = {
    en: message_en,
    pt: {
        svcTitle: 'Explorar Projetos',
        organization: 'Organização',
        project: 'Projeto',
        orgScenarioTitle: 'Selecionar Organização',
        orgScenarioDesc: 'Uma organização agrupa vários projetos sob o mesmo guarda-chuva. Selecione uma para navegar pelos projetos disponíveis para o seu time.',
        orgAllTitle: 'Todas as Organizações',
        orgAllDesc: 'Visão geral de todas as organizações disponíveis no sistema.',
        orgCustomTitle: 'Nova Organização',
        orgCustomDesc: 'Crie uma nova organização para agrupar seus projetos.',
        projectScenarioTitle: 'Selecionar Projeto',
        projectScenarioDesc: 'Um projeto é uma entrega dentro de uma organização — contém páginas, componentes e todo o código gerado.',
        projectAllTitle: 'Todos os Projetos',
        projectAllDesc: 'Visão geral de todos os projetos desta organização.',
        projectCustomTitle: 'Novo Projeto',
        projectCustomDesc: 'Crie um novo projeto dentro desta organização.',
        projectNeedsOrg: 'Selecione uma organização primeiro para ver os projetos disponíveis.',
        projects: 'projetos',
        noOrgs: 'Nenhuma organização encontrada.',
    },
    es: {
        svcTitle: 'Explorar Proyectos',
        organization: 'Organización',
        project: 'Proyecto',
        orgScenarioTitle: 'Seleccionar Organización',
        orgScenarioDesc: 'Una organización agrupa múltiples proyectos bajo el mismo paraguas. Seleccione una para explorar los proyectos disponibles para su equipo.',
        orgAllTitle: 'Todas las Organizaciones',
        orgAllDesc: 'Visión general de todas las organizaciones disponibles en el sistema.',
        orgCustomTitle: 'Nueva Organización',
        orgCustomDesc: 'Cree una nueva organización para agrupar sus proyectos.',
        projectScenarioTitle: 'Seleccionar Proyecto',
        projectScenarioDesc: 'Un proyecto es un entregable dentro de una organización — contiene páginas, componentes y todo el código generado.',
        projectAllTitle: 'Todos los Proyectos',
        projectAllDesc: 'Visión general de todos los proyectos de esta organización.',
        projectCustomTitle: 'Nuevo Proyecto',
        projectCustomDesc: 'Cree un nuevo proyecto dentro de esta organización.',
        projectNeedsOrg: 'Seleccione una organización primero para ver los proyectos disponibles.',
        projects: 'proyectos',
        noOrgs: 'No se encontraron organizaciones.',
    },
};
// ─── Static configs ───────────────────────────────────────────────────
const DISABLED_CONFIG = (key) => ({
    key,
    min: 1,
    max: 1,
    labels: {},
    disabled: true,
});
// Studio client: a single position, no 'All' and no 'Custom' — there is one project to edit.
const LOCKED_CONFIG = (key, label) => ({
    key,
    min: 1,
    max: 1,
    labels: { 1: label },
    disabled: true,
});
const LOCAL_ORG_KEY = 'local-projects';
const LOCAL_ORG_NAME = 'Local Projects';
// ─── Service ─────────────────────────────────────────────────────────
let ServiceExploreProjects102020 = class ServiceExploreProjects102020 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aura--services--service-explore-projects-102020 {
  display: block;
}
`);
        this.details = {
            icon: '&#xf0b1',
            state: 'foreground',
            position: 'left',
            tooltip: 'Explore Projects',
            visible: true,
            widget: '_102020_/l2/aura/services/serviceExploreProjects',
            level: [6],
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: undefined,
            onClickMain: this.onClickMain.bind(this),
        };
        // ─── State ────────────────────────────────────────────────────────
        this.msg = message_en;
        this._orgs = [];
        this._orgConfig = DISABLED_CONFIG('organization');
        this._orgValue = null;
        this._projectValue = null;
        this._selectedKnob = 'organization';
        this._projectConfig = DISABLED_CONFIG('project');
        // ─── Run mode ─────────────────────────────────────────────────────
        // The studio client (the app served by the client's own server) edits ONE project: the
        // app's. Everything that switches org/project is locked there — the full studio
        // (on.collab.codes) is untouched. Resolved once, before the first render.
        this._locked = false;
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onServiceClick(_visible, _reinit, _el) { }
    _resolveRunMode() {
        if (!isStudioClient())
            return;
        this._scopeProject = getStudioScopeProject();
        this._locked = this._scopeProject !== undefined;
    }
    // ─── Org Loading ──────────────────────────────────────────────────
    _loadOrgs() {
        let orgs = this._getOrgsFromMls();
        if (this._locked)
            orgs = this._applyClientScope(orgs);
        this._orgs = orgs;
        this._orgConfig = this._buildOrgConfig(orgs);
        if (this._locked) {
            // One org, one project — assigned directly because _setKnobValue is a no-op while locked.
            this._orgValue = 1;
            this._projectConfig = this._buildProjectConfigFromOrg(orgs[0]);
            this._projectValue = 1;
            this._selectedKnob = 'project';
            return;
        }
        const isLocalActual = mls.actualProject === mls.stor.LOCALPROJECTNUMBER;
        const actualOrgIndex = mls?.l5?.actualOrg ?? null;
        let matchedPos = actualOrgIndex !== null
            ? orgs.findIndex(o => o.index === actualOrgIndex)
            : -1;
        if (isLocalActual)
            matchedPos = orgs.findIndex(o => o.key === LOCAL_ORG_KEY);
        this._setKnobValue('organization', matchedPos >= 0 ? matchedPos + 1 : 0);
        if (matchedPos >= 0) {
            const org = orgs[matchedPos];
            const actualProjectId = isLocalActual ? mls.stor.LOCALPROJECTNUMBER : getAuraState().actualProject;
            const matchedProjectPos = actualProjectId !== null
                ? org.projects.findIndex(p => p.project === actualProjectId)
                : -1;
            this._setKnobValue('project', matchedProjectPos >= 0 ? matchedProjectPos + 1 : 0);
            if (matchedProjectPos >= 0 && actualProjectId)
                this._selectedKnob = 'project';
        }
    }
    /**
     * Reduces the list to the org/project the client app belongs to. When that project is not
     * there (anonymous login, stor still cold) the scope cannot be honoured — keep the full list
     * and unlock, because degrading to the studio behaviour beats showing an empty service.
     */
    _applyClientScope(orgs) {
        const org = orgs.find(o => o.projects.some(p => p.project === this._scopeProject));
        const project = org?.projects.find(p => p.project === this._scopeProject);
        if (!org || !project) {
            console.warn(`[serviceExploreProjects] project ${this._scopeProject} not among the loaded orgs — client scope not applied`);
            this._locked = false;
            this._scopeProject = undefined;
            return orgs;
        }
        return [{ ...org, projects: [project] }];
    }
    _getOrgsFromMls() {
        if (!mls?.stor?.orgs)
            return [];
        const result = [];
        Object.keys(mls.stor.orgs).forEach((org, index) => {
            const { name, description, created_at, projects } = mls.stor.orgs[org].sett;
            const prj = [];
            projects.forEach((p) => {
                try {
                    const json = JSON.parse(p.value);
                    if (!p.id)
                        return;
                    const info = mls.l5.getProjectSettings(p.id);
                    let doSelect = true;
                    let projectDriver = '';
                    let projectURL = '';
                    if (!json.projectURL && json.l5_actionPrjSettings) {
                        projectDriver = json.l5_actionPrjSettings.projectDriver || '';
                        projectURL = json.l5_actionPrjSettings.projectURL || '';
                    }
                    else if (json.projectURL) {
                        projectDriver = json.projectDriver || '';
                        projectURL = json.projectURL || '';
                    }
                    if (!projectDriver || !projectURL || projectDriver === 'mls')
                        return;
                    if (!info || !info.projectDriver || !info.projectURL)
                        doSelect = false;
                    if (doSelect)
                        prj.push({ project: p.id, name: p.name, doSelect });
                }
                catch (e) { }
            });
            if (prj.length <= 0)
                return;
            result.push({ name, created_at, description, key: org, index, projects: prj });
        });
        // No local project in the client app — it only ever serves the app's own project.
        // Asked of the run mode, not of _locked: the scope may fail to apply and unlock below,
        // and a local org would still make no sense there.
        if (!isStudioClient() && checkIfHasLocalProject())
            result.unshift(this._buildLocalOrg());
        return result;
    }
    // Virtual organization, in memory only — the local project belongs to no real org.
    _buildLocalOrg() {
        return {
            name: LOCAL_ORG_NAME,
            created_at: '',
            description: 'Local test projects (browser only)',
            key: LOCAL_ORG_KEY,
            index: -1,
            projects: [{ project: mls.stor.LOCALPROJECTNUMBER, name: getLocalProjectName() || 'Local', doSelect: true }],
        };
    }
    _buildOrgConfig(orgs) {
        if (this._locked)
            return LOCKED_CONFIG('organization', orgs[0]?.name ?? '');
        const labels = { 0: 'All' };
        orgs.forEach((org, i) => { labels[i + 1] = org.name; });
        labels[orgs.length + 1] = 'Custom';
        return { key: 'organization', min: 0, max: orgs.length + 1, labels };
    }
    _buildProjectConfigFromOrg(org) {
        if (this._locked)
            return LOCKED_CONFIG('project', org.projects[0]?.name ?? '');
        const labels = { 0: 'All' };
        org.projects.forEach((p, i) => { labels[i + 1] = p.name; });
        labels[org.projects.length + 1] = 'Custom';
        return { key: 'project', min: 0, max: org.projects.length + 1, labels, disabled: false };
    }
    // ─── Helpers ──────────────────────────────────────────────────────
    get _selectedOrg() {
        if (this._orgValue === null || this._orgValue <= 0 || this._orgValue > this._orgs.length)
            return null;
        return this._orgs[this._orgValue - 1];
    }
    get _knobValues() {
        return {
            organization: this._orgValue,
            project: this._projectValue,
        };
    }
    _getKnobConfig(key) {
        switch (key) {
            case 'organization': return this._orgConfig;
            case 'project': return this._projectConfig;
            default: return DISABLED_CONFIG(key);
        }
    }
    _setKnobValue(key, value) {
        // Single choke point of every switch path (knob, nav-header arrows, All/Custom cards):
        // in the studio client the org/project are fixed to the app's.
        if (this._locked)
            return;
        switch (key) {
            case 'organization': {
                this._orgValue = value;
                const org = this._orgs[value !== null ? value - 1 : -1];
                if (org) {
                    this._projectConfig = this._buildProjectConfigFromOrg(org);
                    this._projectValue = 0;
                }
                else {
                    this._projectConfig = DISABLED_CONFIG('project');
                    this._projectValue = null;
                }
                break;
            }
            case 'project':
                this._projectValue = value;
                break;
        }
        this.requestUpdate();
    }
    // ─── Event Handlers ───────────────────────────────────────────────
    _onKnobChange(key, e) {
        this._selectedKnob = key;
        this._setKnobValue(key, e.detail.value);
    }
    _onKnobClick(key) {
        this._selectedKnob = key;
        this.requestUpdate();
    }
    // ─── Lifecycle ────────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        AuraInitState();
        this._resolveRunMode();
        this._loadOrgs();
    }
    // ─── Render ───────────────────────────────────────────────────────
    createRenderRoot() { return this; }
    render() {
        this.style.display = 'block';
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="flex flex-col min-h-full bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-200">
                ${this._renderKnobRow()}
                ${this._renderDetailsRow()}
            </div>
        `;
    }
    // ─── Knob Row ─────────────────────────────────────────────────────
    _renderKnobRow() {
        return html `
            <div class="
                flex items-center justify-center
                px-2 py-3
                border-b border-gray-200 dark:border-gray-800
                gap-0
            " style="--knob-scale: 0.5">
                ${this._renderKnobItem('organization')}
                ${this._renderKnobItem('project')}
            </div>
        `;
    }
    _renderKnobItem(key) {
        const config = this._getKnobConfig(key);
        const value = this._knobValues[key];
        const isContext = this._selectedKnob === key;
        const isDisabled = config.disabled ?? false;
        const label = this.msg[key] || key;
        const fullLabel = this.msg[`${key}Full`] || label; // tooltip: name in full
        return html `
            <div title=${fullLabel} class="flex flex-col items-center gap-0.5 ${isDisabled ? 'opacity-30' : ''}">
                <aura--widgets--aura-select-knob-102020
                    .min=${config.min}
                    .max=${config.max}
                    .value=${value}
                    .step=${1}
                    .active=${true}
                    .disabled=${isDisabled}
                    .selected=${isContext}
                    .showTicks=${false}
                    @knob-change=${(e) => this._onKnobChange(key, e)}
                ></aura--widgets--aura-select-knob-102020>

                <div
                    class="flex flex-col items-center gap-0.5 cursor-pointer"
                    @click=${() => this._onKnobClick(key)}
                >
                    <span class="
                        text-[9px] font-semibold uppercase tracking-wider
                        ${isContext
            ? 'text-gray-700 dark:text-gray-200'
            : 'text-gray-400 dark:text-gray-600'}
                        transition-colors duration-200
                    ">${label}</span>

                    <div class="
                        w-full h-0.5 rounded-full
                        transition-all duration-200
                        ${isContext
            ? 'bg-cyan-400 shadow-[0_0_4px_1px_rgba(34,211,238,0.6),0_0_8px_2px_rgba(34,211,238,0.3)]'
            : 'bg-transparent'}
                    "></div>
                </div>
            </div>
        `;
    }
    // ─── Details Row ──────────────────────────────────────────────────
    _renderDetailsRow() {
        return html `
            <div class="flex flex-col flex-1">
                <div class="flex flex-col gap-3 px-4 py-4 flex-1">
                    ${this._renderContextStatusArea()}
                </div>
            </div>
        `;
    }
    _renderContextStatusArea() {
        switch (this._selectedKnob) {
            case 'organization':
                return html `
                    <aura--plugins--select-organization-102020
                        .orgs=${this._orgs}
                        .value=${this._orgValue}
                        .locked=${this._locked}
                        @select-org=${(e) => this._setKnobValue('organization', e.detail.value)}
                    ></aura--plugins--select-organization-102020>
                `;
            case 'project':
                return html `
                    <aura--plugins--select-project-102020
                        .selectedOrg=${this._selectedOrg}
                        .value=${this._projectValue}
                        .locked=${this._locked}
                        @select-project=${(e) => this._setKnobValue('project', e.detail.value)}
                    ></aura--plugins--select-project-102020>
                `;
            default:
                return nothing;
        }
    }
};
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "msg", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_orgs", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_orgConfig", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_orgValue", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_projectValue", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_selectedKnob", void 0);
__decorate([
    state()
], ServiceExploreProjects102020.prototype, "_projectConfig", void 0);
ServiceExploreProjects102020 = __decorate([
    customElement('aura--services--service-explore-projects-102020')
], ServiceExploreProjects102020);
export { ServiceExploreProjects102020 };
