/// <mls fileReference="_102020_/l2/aura/services/serviceProject.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { AuraInitState, getAuraState, setAuraState, saveAuraProject, getActualLanguage, setActualLanguage } from '/_102020_/l2/aura/helpers/auraState.js';
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { readModuleLanguages } from '/_102020_/l2/aura/helpers/moduleLanguages.js';
import '/_102020_/l2/aura/widgets/auraSelectKnob.js';
import '/_102020_/l2/aura/plugins/selectModule.js';
import '/_102020_/l2/aura/plugins/selectLanguage.js';
import '/_102020_/l2/aura/plugins/selectDevice.js';
import '/_102020_/l2/aura/plugins/selectAssetsComponents.js';
import '/_102020_/l2/aura/plugins/selectAssetsPlugins.js';
import '/_102020_/l2/aura/plugins/selectAssetsMedia.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    svcTitle: 'Project',
    module: 'Module',
    language: 'Language',
    device: 'Device',
    assets: 'Assets',
};
const messages = {
    en: message_en,
    pt: {
        svcTitle: 'Projeto',
        module: 'Módulo',
        language: 'Idioma',
        device: 'Dispositivo',
        assets: 'Assets',
    },
    es: {
        svcTitle: 'Proyecto',
        module: 'Módulo',
        language: 'Idioma',
        device: 'Dispositivo',
        assets: 'Assets',
    },
};
// ─── Static configs ───────────────────────────────────────────────────
const DEVICE_CONFIG = {
    key: 'device',
    min: 1,
    max: 4,
    labels: { 1: 'Web D', 2: 'Web M', 3: 'Android', 4: 'iOS' },
};
const ASSETS_CONFIG = {
    key: 'assets',
    min: 1,
    max: 3,
    labels: { 1: 'Components', 2: 'Plugins', 3: 'Media' },
};
const DISABLED_CONFIG = (key) => ({
    key,
    min: 1,
    max: 1,
    labels: {},
    disabled: true,
});
const DEVICE_PATH_MAP = {
    1: 'web/desktop',
    2: 'web/mobile',
    3: 'android',
    4: 'ios',
};
// ─── Service ─────────────────────────────────────────────────────────
let ServiceProject102020 = class ServiceProject102020 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aura--services--service-project-102020 {
  display: block;
}
`);
        this.details = {
            icon: '&#xf1b2',
            state: 'foreground',
            position: 'left',
            tooltip: 'Project',
            visible: true,
            widget: '_102020_/l2/aura/services/serviceProject',
            level: [6],
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: undefined,
            onClickMain: this.onClickMain.bind(this),
        };
        // ─── State ────────────────────────────────────────────────────────
        this.msg = message_en;
        this._modules = [];
        this._moduleConfig = DISABLED_CONFIG('module');
        this._moduleReloadToken = 0;
        this._moduleValue = null;
        this._langValue = null;
        this._deviceValue = 1;
        this._assetsValue = 1;
        this._selectedKnob = 'module';
        this._langConfig = DISABLED_CONFIG('language');
        this._deviceConfig = { ...DEVICE_CONFIG };
        this._assetsConfig = { ...ASSETS_CONFIG };
        // Stable IProject reference for the selectLanguage plugin — a fresh object literal on
        // every render would retrigger the plugin's willUpdate (identity change) in a loop.
        this._projectRef = null;
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onServiceClick(_visible, _reinit, _el) {
        this._moduleReloadToken += 1; // re-check the module variations on each service (re)open
    }
    // ─── Module Loading ───────────────────────────────────────────────
    async _loadModules() {
        const project = getAuraState().actualProject;
        if (!project)
            return;
        try {
            const config = await getConfigProject(project);
            const rawModules = config?.modules ?? [];
            // project.json modules are `{ moduleName, module: { moduleName, businessDomain, … } }`.
            // `name` is the identifier (folder / actualModule); `path` is the secondary display line.
            const modules = rawModules.map((m) => ({
                name: m.moduleName ?? m.name ?? '',
                path: m.path ?? m.module?.businessDomain ?? m.module?.moduleName ?? '',
            }));
            this._modules = modules;
            this._moduleConfig = this._buildModuleConfig(modules);
            const actualModule = getAuraState().actualModule;
            const idx = actualModule ? modules.findIndex(m => m.name === actualModule) : -1;
            this._moduleValue = idx >= 0 ? idx + 1 : 0;
            this._initLangConfig();
        }
        catch {
            this._modules = [];
            this._moduleConfig = DISABLED_CONFIG('module');
        }
        const actualDevice = getAuraState().actualDevice;
        if (actualDevice) {
            const entry = Object.entries(DEVICE_PATH_MAP).find(([, v]) => v === actualDevice);
            this._deviceValue = entry ? Number(entry[0]) : 1;
        }
        this.requestUpdate();
    }
    _buildModuleConfig(modules) {
        const labels = { 0: 'All' };
        modules.forEach((m, i) => { labels[i + 1] = m.name; });
        labels[modules.length + 1] = 'Custom';
        return { key: 'module', min: 0, max: modules.length + 1, labels };
    }
    // ─── Helpers ──────────────────────────────────────────────────────
    get _selectedModule() {
        if (this._moduleValue === null || this._moduleValue <= 0 || this._moduleValue > this._modules.length)
            return null;
        return this._modules[this._moduleValue - 1];
    }
    get _moduleSelected() {
        return this._moduleValue !== null
            && this._moduleValue > 0
            && this._moduleValue <= this._modules.length;
    }
    get _selectedProjectRef() {
        const project = getAuraState().actualProject;
        if (!project)
            return (this._projectRef = null);
        if (this._projectRef?.project !== project)
            this._projectRef = { project, name: '', doSelect: true };
        return this._projectRef;
    }
    // Language knob config comes from the selected module's l4/<module>/module.defs.ts.
    async _initLangConfig() {
        const project = getAuraState().actualProject;
        const module = this._selectedModule?.name ?? null;
        if (!project || !module) {
            this._langConfig = DISABLED_CONFIG('language');
            this._langValue = null;
            this.requestUpdate();
            return;
        }
        try {
            const languages = await readModuleLanguages(project, module);
            const labels = { 0: 'All' };
            languages.forEach((lang, i) => { labels[i + 1] = lang; });
            labels[languages.length + 1] = '+';
            this._onLangConfig(new CustomEvent('lang-config', {
                detail: { min: 0, max: languages.length + 1, labels },
            }));
        }
        catch {
            this._langConfig = DISABLED_CONFIG('language');
            this.requestUpdate();
        }
    }
    _onLangConfig(e) {
        this._langConfig = { key: 'language', min: e.detail.min, max: e.detail.max, labels: e.detail.labels };
        const actualLanguage = getActualLanguage(this._selectedModule?.name);
        if (actualLanguage) {
            const entry = Object.entries(e.detail.labels).find(([, v]) => v === actualLanguage);
            this._langValue = entry ? Number(entry[0]) : 0;
        }
        else {
            if (this._langValue === null)
                this._langValue = 0;
        }
        this.requestUpdate();
    }
    get _knobValues() {
        return {
            module: this._moduleValue,
            language: this._langValue,
            device: this._deviceValue,
            assets: this._assetsValue,
        };
    }
    _getKnobConfig(key) {
        switch (key) {
            case 'module': return this._moduleConfig;
            case 'language':
                return this._moduleSelected ? this._langConfig : DISABLED_CONFIG('language');
            case 'device':
                return this._moduleSelected ? this._deviceConfig : DISABLED_CONFIG('device');
            case 'assets':
                return this._moduleSelected ? this._assetsConfig : DISABLED_CONFIG('assets');
            default: return DISABLED_CONFIG(key);
        }
    }
    _setKnobValue(key, value) {
        switch (key) {
            case 'module': {
                this._moduleValue = value;
                this._langValue = null;
                this._initLangConfig();
                break;
            }
            case 'language': {
                this._langValue = value;
                const langCode = (value !== null && value > 0 && value < this._langConfig.max)
                    ? this._langConfig.labels[value] ?? null
                    : null;
                const module = this._selectedModule?.name;
                if (langCode && module) {
                    setActualLanguage(module, langCode);
                    saveAuraProject();
                }
                break;
            }
            case 'device':
                this._deviceValue = value;
                setAuraState('actualDevice', value !== null ? DEVICE_PATH_MAP[value] ?? null : null);
                saveAuraProject();
                break;
            case 'assets':
                this._assetsValue = value;
                break;
        }
        this.requestUpdate();
    }
    // ─── Event Handlers ───────────────────────────────────────────────
    _onKnobChange(key, e) {
        this._selectedKnob = key;
        this._setKnobValue(key, e.detail.value);
    }
    _onKnobClick(key) {
        this._selectedKnob = key;
        this.requestUpdate();
    }
    // ─── Lifecycle ────────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        AuraInitState();
        this._loadModules();
    }
    // ─── Render ───────────────────────────────────────────────────────
    createRenderRoot() { return this; }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="flex flex-col min-h-full bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-200">
                ${this._renderKnobRow()}
                ${this._renderDetailsRow()}
            </div>
        `;
    }
    // ─── Knob Row ─────────────────────────────────────────────────────
    _renderKnobRow() {
        return html `
            <div class="
                flex items-center justify-center
                px-2 py-3
                border-b border-gray-200 dark:border-gray-800
                gap-0
            " style="--knob-scale: 0.5">
                ${this._renderKnobItem('module')}
                ${this._renderKnobItem('language')}
                ${this._renderKnobItem('device')}
                ${this._renderKnobItem('assets')}
            </div>
        `;
    }
    _renderKnobItem(key) {
        const config = this._getKnobConfig(key);
        const value = this._knobValues[key];
        const isContext = this._selectedKnob === key;
        const isDisabled = config.disabled ?? false;
        const label = this.msg[key] || key;
        const fullLabel = this.msg[`${key}Full`] || label; // tooltip: name in full
        return html `
            <div title=${fullLabel} class="flex flex-col items-center gap-0.5 ${isDisabled ? 'opacity-30' : ''}">
                <aura--widgets--aura-select-knob-102020
                    .min=${config.min}
                    .max=${config.max}
                    .value=${value}
                    .step=${1}
                    .active=${true}
                    .disabled=${isDisabled}
                    .selected=${isContext}
                    .showTicks=${false}
                    @knob-change=${(e) => this._onKnobChange(key, e)}
                ></aura--widgets--aura-select-knob-102020>

                <div
                    class="flex flex-col items-center gap-0.5 cursor-pointer"
                    @click=${() => this._onKnobClick(key)}
                >
                    <span class="
                        text-[9px] font-semibold uppercase tracking-wider
                        ${isContext
            ? 'text-gray-700 dark:text-gray-200'
            : 'text-gray-400 dark:text-gray-600'}
                        transition-colors duration-200
                    ">${label}</span>

                    <div class="
                        w-full h-0.5 rounded-full
                        transition-all duration-200
                        ${isContext
            ? 'bg-cyan-400 shadow-[0_0_4px_1px_rgba(34,211,238,0.6),0_0_8px_2px_rgba(34,211,238,0.3)]'
            : 'bg-transparent'}
                    "></div>
                </div>
            </div>
        `;
    }
    // ─── Details Row ──────────────────────────────────────────────────
    _renderDetailsRow() {
        return html `
            <div class="flex flex-col flex-1">
                <div class="flex flex-col gap-3 px-4 py-4 flex-1"
                    @select-assets=${(e) => this._setKnobValue('assets', e.detail.value)}
                    @lang-config=${(e) => this._onLangConfig(e)}
                    @select-language=${(e) => this._setKnobValue('language', e.detail.value)}
                >
                    ${this._renderContextStatusArea()}
                </div>
            </div>
        `;
    }
    _renderContextStatusArea() {
        switch (this._selectedKnob) {
            case 'module':
                return html `
                    <aura--plugins--select-module-102020
                        .modules=${this._modules}
                        .value=${this._moduleValue}
                        .reloadToken=${this._moduleReloadToken}
                        @select-module=${(e) => this._setKnobValue('module', e.detail.value)}
                    ></aura--plugins--select-module-102020>
                `;
            case 'language': {
                return html `
                    <aura--plugins--select-language-102020
                        .selectedProject=${this._selectedProjectRef}
                        .selectedModule=${this._selectedModule?.name ?? getAuraState().actualModule}
                        .value=${this._langValue}
                    ></aura--plugins--select-language-102020>
                `;
            }
            case 'device':
                return html `
                    <aura--plugins--select-device-102020
                        .value=${this._deviceValue}
                        .selectedModule=${this._selectedModule}
                        @select-device=${(e) => this._setKnobValue('device', e.detail.value)}
                    ></aura--plugins--select-device-102020>
                `;
            case 'assets':
                return this._renderAssetsPanel();
            default:
                return nothing;
        }
    }
    _renderAssetsPanel() {
        switch (this._assetsValue) {
            case 1:
                return html `
                    <aura--plugins--select-assets-components-102020
                        .selectedModule=${this._selectedModule}
                        .device=${this._deviceValue}
                    ></aura--plugins--select-assets-components-102020>
                `;
            case 2:
                return html `
                    <aura--plugins--select-assets-plugins-102020
                        .selectedModule=${this._selectedModule}
                        .device=${this._deviceValue}
                    ></aura--plugins--select-assets-plugins-102020>
                `;
            case 3:
                return html `
                    <aura--plugins--select-assets-media-102020
                        .selectedModule=${this._selectedModule}
                        .device=${this._deviceValue}
                    ></aura--plugins--select-assets-media-102020>
                `;
            default:
                return nothing;
        }
    }
};
__decorate([
    state()
], ServiceProject102020.prototype, "msg", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_modules", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_moduleConfig", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_moduleReloadToken", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_moduleValue", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_langValue", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_deviceValue", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_assetsValue", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_selectedKnob", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_langConfig", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_deviceConfig", void 0);
__decorate([
    state()
], ServiceProject102020.prototype, "_assetsConfig", void 0);
ServiceProject102020 = __decorate([
    customElement('aura--services--service-project-102020')
], ServiceProject102020);
export { ServiceProject102020 };
