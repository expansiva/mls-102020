/// <mls fileReference="_102020_/l2/aura/helpers/dsMatch/matchVariant.ts" enhancement="_blank" />
/**
 * @returns the matched molecule, or `null` when nothing matches the DS for this group
 *          (no AND match and no wildcard) — in which case NO molecule is assigned.
 */
export function matchVariant(group, dsRules, catalog) {
    // `filter` preserves catalog order → basis of the tie-break.
    const candidates = catalog.filter(m => m.group === group);
    if (candidates.length === 0)
        return null;
    let best = null;
    for (const entry of candidates) {
        const declared = Object.entries(entry.layoutConfig);
        // AND: every declared axis must match the DS.
        let ok = true;
        for (const [axis, value] of declared) {
            if (dsRules[axis] !== value) {
                ok = false;
                break;
            }
        }
        if (!ok)
            continue;
        const specificity = declared.length;
        // Strict `>` keeps the FIRST on a tie (catalog order).
        if (!best || specificity > best.specificity) {
            best = { entry, specificity };
        }
    }
    if (best)
        return { entry: best.entry, matched: true, specificity: best.specificity };
    // No molecule matches this DS for the group → NO assignment. Returning an arbitrary
    // variant (e.g. the catalog-first one) produced wrong choices (a grid became a
    // calendar). Better to assign nothing and keep the organism's original UI.
    return null;
}
