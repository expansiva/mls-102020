/// <mls fileReference="_102020_/l2/aura/helpers/dsMatch/variationStatusCore.ts" enhancement="_blank" />
export const VARIATION_DEVICES = ['desktop', 'mobile'];
/** Pipeline order — the worst (earliest) stage present wins. */
export const VARIATION_STATUS_ORDER = ['generation', 'stale', 'refused', 'materialize', 'fresh'];
export function worstVariationStatus(statuses) {
    const present = new Set(statuses);
    return VARIATION_STATUS_ORDER.find(status => present.has(status)) ?? 'fresh';
}
/**
 * The input20 verdict for one page folder (`genome`: page11 or a variant) against the defs on disk now. A verdict on
 * other defs (a sha256 that differs, a page or variant the snapshot does not list) is `outdated`: the materializer
 * has to run again before its verdict means anything.
 */
export function snapshotVerdictFor(snapshot, pageId, genome, defsHashes) {
    if (!snapshot || !Array.isArray(snapshot.pages))
        return { kind: 'absent' };
    const page = snapshot.pages.find(item => item.pageId === pageId);
    if (!page)
        return { kind: 'outdated' };
    const problems = page.problems ?? [];
    const pageErrors = problems.filter(item => item.severity === 'error').map(item => item.message);
    const sameDefs = (inputs) => VARIATION_DEVICES.every(device => (inputs?.[device]?.sha256 ?? null) === defsHashes[device]);
    if (genome === 'page11') {
        if (!sameDefs(page.inputs))
            return { kind: 'outdated' };
        if (page.status !== 'refused')
            return { kind: 'accepted' };
        return { kind: 'refused', reasons: pageErrors.length ? pageErrors : problems.map(item => item.message) };
    }
    const variant = page.variants?.find(item => item.genome === genome);
    if (!variant || !sameDefs(variant.inputs))
        return { kind: 'outdated' };
    if (variant.status !== 'refused')
        return { kind: 'accepted' };
    // gate.ts paths of a variant: `<genome>:` (M4_INPUT_VARIANT_REFUSED) or `<genome>/<device>:…` (molecule, rules).
    const own = problems
        .filter(item => item.path === `${genome}:` || item.path.startsWith(`${genome}/`) || item.path.startsWith(`${genome}:`))
        .map(item => item.message);
    // A variant of a refused page is left out with it (the page's errors say why).
    const reasons = [...new Set([...own, ...(page.status === 'refused' ? pageErrors : [])])];
    return { kind: 'refused', reasons: reasons.length ? reasons : [`input20 refused ${genome} of ${pageId}.`] };
}
/** The status of one page of a variation from its facts and the input20 verdict. */
export function pageVariationEntry(facts, verdict) {
    const ux = facts.kind === 'ux';
    const base = facts.kind === 'base';
    const templateChoice = base ? facts.templateChoice ?? null : null;
    // UX N always has a receipt to compare; the base only once agentGenomeUx base mode wrote one.
    const tracked = ux || (base && facts.hasReceipt);
    const staleReasons = tracked ? facts.staleReasons.filter(reason => reason !== 'receipt' || facts.hasReceipt) : [];
    const devices = {};
    for (const device of VARIATION_DEVICES) {
        if (facts.defsHashes[device] === null || (ux && (facts.diagnostic !== null || !facts.hasReceipt)) || templateChoice !== null)
            devices[device] = 'generation';
        else if (staleReasons.length)
            devices[device] = 'stale';
        else if (verdict.kind === 'refused')
            devices[device] = 'refused';
        else if (verdict.kind === 'outdated' || !facts.ts[device])
            devices[device] = 'materialize';
        else
            devices[device] = 'fresh';
    }
    const status = worstVariationStatus(Object.values(devices));
    return {
        page: facts.page,
        status,
        devices,
        staleReasons: status === 'stale' ? staleReasons : [],
        refusedReasons: status === 'refused' && verdict.kind === 'refused' ? verdict.reasons : [],
        diagnostic: ux || base ? facts.diagnostic : null,
        templateChoice,
    };
}
/** Aggregate per-page statuses into the variation status + counts. */
export function aggregateVariationStatus(pages) {
    const counts = { generation: 0, stale: 0, refused: 0, materialize: 0, fresh: 0 };
    for (const p of pages)
        counts[p.status]++;
    return { status: worstVariationStatus(pages.map(p => p.status)), counts };
}
/** UX numbers of `config.layouts` that have a genome folder: integer keys 2..9 (page{N}1), sorted. */
export function genomeUxNumbers(layouts) {
    return Object.keys(layouts ?? {})
        .filter(key => /^[2-9]$/.test(key))
        .map(Number)
        .sort((a, b) => a - b);
}
/** `page{N}1` of UX N, `page11` for UX 1. */
export function genomeUxFolder(layout) {
    return `page${layout}1`;
}
/** The page\d+ folders that are neither page11 nor the page{N}1 of a configured UX, sorted. */
export function orphanVariationFolders(segments, layouts) {
    const known = new Set(['page11', ...layouts.map(genomeUxFolder)]);
    return [...new Set(segments)].filter(seg => /^page\d+$/.test(seg) && !known.has(seg)).sort((a, b) => Number(a.slice(4)) - Number(b.slice(4)));
}
/**
 * The pages for the action of a variation: `generate` (UX N with generation/stale pages; base: pages with a UX 1
 * template choice or a stale base receipt) → agentGenomeUx with those pages (layout 1 for the base);
 * `regenerate` (UX N whose only problem is refused pages) → agentGenomeUx with them and force; `materialize`
 * (pending .ts) → agentMaterializeL2 with the genome scope; null = nothing to do (or an orphan). A base page whose
 * page11 defs is missing is agentDefsL2's, never part of `generate`.
 */
export function variationAction(kind, pages) {
    if (kind === 'orphan')
        return null;
    if (kind === 'ux') {
        const pending = pages.filter(p => p.status === 'generation' || p.status === 'stale').map(p => p.page);
        if (pending.length)
            return { kind: 'generate', pages: pending };
    }
    if (kind === 'base') {
        const pending = pages.filter(p => p.status === 'stale' || (p.status === 'generation' && !!p.templateChoice)).map(p => p.page);
        if (pending.length)
            return { kind: 'generate', pages: pending };
    }
    if (pages.some(p => p.status === 'materialize'))
        return { kind: 'materialize' };
    if (kind === 'ux') {
        const refused = pages.filter(p => p.status === 'refused').map(p => p.page);
        if (refused.length)
            return { kind: 'regenerate', pages: refused };
    }
    return null;
}
