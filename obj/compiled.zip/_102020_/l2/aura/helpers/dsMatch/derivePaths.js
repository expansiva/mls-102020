/// <mls fileReference="_102020_/l2/aura/helpers/dsMatch/derivePaths.ts" enhancement="_blank" />
// Path derivation for the DS-implementation flow.
//
// Page folder convention: page{layout}{ds}  (page11 = layout 1 + ds 1).
// The DESTINATION is always page{layout}{ds}. The ORIGIN (structural source of the
// defs) is resolved PER PAGE by fallback: page{L}{D} → page{L}1 → page11 — the first
// whose `.defs.ts` actually exists in mls.stor. So a variation reuses the closest
// same-layout ancestor already generated (e.g. page32 derives from page31) instead of
// always cloning page11's structure. Falls back to page11 when nothing else exists.
//
// Full layout under a module: {module}/web/{device}/page{layout}{ds}/<page>.{ts|defs.ts}
export const DEFAULT_DEVICE = 'desktop';
/** 'page12' for layout 1, ds 2. */
export function variationFolder(layout, ds) {
    return `page${layout}${ds}`;
}
/** Folder as stored in mls.stor (relative, no project/level), e.g. 'cafeFlow/web/desktop/page12'. */
export function pageFolder(module, layout, ds, device = DEFAULT_DEVICE) {
    return `${module}/web/${device}/${variationFolder(layout, ds)}`;
}
/** Full file reference, e.g. '_102043_/l2/cafeFlow/web/desktop/page12/cardapioEstoque.defs.ts'. */
export function pageRef(project, module, layout, ds, page, ext, device = DEFAULT_DEVICE) {
    return `_${project}_/l2/${pageFolder(module, layout, ds, device)}/${page}${ext}`;
}
/** Build the work item for one page. Origin resolved by fallback (see resolveOriginCoords). */
export function buildWorkItem(project, module, layout, ds, page, device = DEFAULT_DEVICE) {
    const [ol, od] = resolveOriginCoords(project, module, layout, ds, page, device);
    return {
        page,
        defsOrigem: pageRef(project, module, ol, od, page, '.defs.ts', device),
        defsDestino: pageRef(project, module, layout, ds, page, '.defs.ts', device),
        originFolder: variationFolder(ol, od),
    };
}
// ─── origin resolution (fallback page{L}{D} → page{L}1 → page11) ──────────────
/** Ordered, de-duplicated origin candidates for a variation: [[L,D],[L,1],[1,1]]. Pure. */
export function originCandidates(layout, ds) {
    const raw = [[layout, ds], [layout, 1], [1, 1]];
    const seen = new Set();
    const out = [];
    for (const [l, d] of raw) {
        const key = `${l}|${d}`;
        if (seen.has(key))
            continue;
        seen.add(key);
        out.push([l, d]);
    }
    return out;
}
/** Does the `.defs.ts` for this exact page variation exist in mls.stor? Synchronous.
 *  Returns false when stor is unavailable (test/no-stor context). */
export function pageDefsExists(project, module, layout, ds, page, device = DEFAULT_DEVICE) {
    const files = (typeof mls !== 'undefined') ? mls?.stor?.files : undefined;
    if (!files)
        return false;
    const folder = pageFolder(module, layout, ds, device);
    return Object.values(files).some(sf => sf &&
        sf.project === project &&
        sf.level === 2 &&
        sf.folder === folder &&
        sf.extension === '.defs.ts' &&
        sf.shortName === page);
}
/** Resolve the origin coordinates [layout, ds] for one page by fallback. Defensive:
 *  with no stor (test context) returns [1, 1] to preserve the page11 baseline. */
function resolveOriginCoords(project, module, layout, ds, page, device = DEFAULT_DEVICE) {
    const files = (typeof mls !== 'undefined') ? mls?.stor?.files : undefined;
    if (!files)
        return [1, 1];
    for (const [l, d] of originCandidates(layout, ds)) {
        if (pageDefsExists(project, module, l, d, page, device))
            return [l, d];
    }
    return [1, 1];
}
/** The resolved-origin `.defs.ts` reference for one page (first existing candidate; page11 fallback). */
export function resolveDefsOrigem(project, module, layout, ds, page, device = DEFAULT_DEVICE) {
    const [l, d] = resolveOriginCoords(project, module, layout, ds, page, device);
    return pageRef(project, module, l, d, page, '.defs.ts', device);
}
// ─── runtime (needs mls.stor) ────────────────────────────────────────────────
/** Distinct page shortNames present in the origin (page11) folder of a module.
 *  Enumerated by `.defs.ts` (the structural source of truth the flow reads) — NOT the
 *  rendered `.ts`, which the new defs-driven flow no longer depends on. */
export function listPages(project, module, device = DEFAULT_DEVICE) {
    const folder = `${module}/web/${device}/page11`;
    const pages = Object.values(mls.stor.files)
        .filter(sf => sf &&
        sf.project === project &&
        sf.level === 2 &&
        sf.folder === folder &&
        sf.extension === '.defs.ts' &&
        typeof sf.shortName === 'string' &&
        sf.shortName)
        .map(sf => sf.shortName);
    return [...new Set(pages)].sort();
}
/** Work items for every page of a module, targeting page{layout}{ds}. */
export function listWorkItems(project, module, layout, ds, device = DEFAULT_DEVICE) {
    return listPages(project, module, device).map(p => buildWorkItem(project, module, layout, ds, p, device));
}
