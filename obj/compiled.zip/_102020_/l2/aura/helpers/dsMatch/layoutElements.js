/// <mls fileReference="_102020_/l2/aura/helpers/dsMatch/layoutElements.ts" enhancement="_blank" />
const CONTAINER_INTENTS = new Set(['queryList', 'summary', 'workflowStatus']);
/** Walk `definition.layout` → flat list of molecule-eligible elements. Pure; no group choice. */
export function listLayoutElements(layout) {
    const out = [];
    for (const sec of layout?.sections ?? []) {
        for (const org of sec?.organisms ?? []) {
            const organismName = org?.organismName ?? '';
            for (const it of org?.intentions ?? []) {
                const intent = it?.intent ?? '';
                const base = { organismName, intent };
                if (CONTAINER_INTENTS.has(intent) && it?.id) {
                    out.push({ ...base, id: it.id, kind: 'container', labelKey: it.titleKey, purpose: it.titleKey, ref: it });
                }
                for (const f of it?.fields ?? []) {
                    if (f?.id)
                        out.push({ ...base, id: f.id, kind: 'field', inputType: f.inputType, field: f.field, labelKey: f.labelKey, ref: f });
                }
                for (const f of it?.filters ?? []) {
                    if (f?.id)
                        out.push({ ...base, id: f.id, kind: 'filter', inputType: f.inputType, field: f.field, labelKey: f.labelKey, ref: f });
                }
                for (const a of [...(it?.toolbar ?? []), ...(it?.rowActions ?? []), ...(it?.actions ?? [])]) {
                    if (a?.id)
                        out.push({ ...base, id: a.id, kind: 'action', labelKey: a.labelKey, ref: a });
                }
            }
        }
    }
    return out;
}
/** id → element, for O(1) placement during the deterministic resolve. */
export function indexById(elements) {
    return new Map(elements.map(e => [e.id, e]));
}
