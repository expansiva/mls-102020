/// <mls fileReference="_102020_/l2/aura/helpers/designSystemAuraBase.ts" enhancement="_blank" />
export const layoutSections = [
    { key: 'transversal', label: 'General', desc: 'Defaults that apply across the whole interface.', primary: true },
    { key: 'input', label: 'Input', desc: 'How users type and edit values.', primary: true },
    { key: 'selection', label: 'Selection', desc: 'How users choose from a set of options.', primary: true },
    { key: 'navigation', label: 'Navigation', desc: 'How users move between areas and steps.' },
    { key: 'feedback', label: 'Feedback & status', desc: 'How the interface responds and reports status.' },
    { key: 'action', label: 'Action & content', desc: 'Actions, ratings and expandable content.' },
    { key: 'visualization', label: 'Visualization', desc: 'How collections and data are displayed.' },
];
/** Every labeled-input group — governed by the input-transversal axes below. */
const labeledInputGroups = ['groupEnterText', 'groupEnterNumber', 'groupEnterMoney', 'groupEnterBoolean', 'groupEnterDate', 'groupEnterDatetime', 'groupEnterTime', 'groupEnterDateInterval', 'groupEnterDatetimeInterval', 'groupEnterTimeInterval', 'groupSelectOne', 'groupSelectMany', 'groupSelectFileForUpload'];
// Keyed by axis name. `as const` preserves the literal value types so molecule
// declarations can be validated against the exact allowed set.
export const layoutAxes = {
    // ── transversais (afetam muitos grupos; density/motion são page-wide → sem `groups`) ──
    density: { label: 'Density', section: 'transversal', values: ['comfortable', 'compact'], default: 'comfortable', essential: true },
    motion: { label: 'Motion', section: 'transversal', values: ['full', 'reduced', 'none'], default: 'full' },
    labelPlacement: { label: 'Label placement', section: 'transversal', values: ['top', 'inline', 'floating'], default: 'top', essential: true,
        inputTransversal: true, groups: labeledInputGroups },
    validation: { label: 'Validation', section: 'transversal', values: ['inline-below', 'tooltip', 'summary'], default: 'inline-below', essential: true,
        inputTransversal: true, groups: labeledInputGroups },
    requiredMark: { label: 'Required mark', section: 'transversal', values: ['asterisk', 'optional-tag', 'none'], default: 'asterisk', essential: true,
        inputTransversal: true, groups: labeledInputGroups },
    listOverflow: { label: 'List overflow', section: 'transversal', values: ['pagination', 'infinite', 'load-more'], default: 'pagination',
        groups: ['groupViewData', 'groupViewTable', 'groupSelectMany'] },
    // ── entrada ──
    boolean: { label: 'Boolean input', section: 'input', values: ['checkbox', 'toggle', 'segmented', 'icon'], default: 'checkbox', essential: true, groups: ['groupEnterBoolean'] },
    numberInput: { label: 'Number input', section: 'input', values: ['input', 'stepper', 'slider'], default: 'input', groups: ['groupEnterNumber'] },
    dateInput: { label: 'Date input', section: 'input', values: ['calendar-popover', 'inline-calendar', 'compact', 'shortcuts', 'masked'], default: 'calendar-popover', groups: ['groupEnterDate', 'groupEnterDatetime'] },
    timeInput: { label: 'Time input', section: 'input', values: ['clock', 'scroll-picker', 'duration'], default: 'clock', groups: ['groupEnterTime'] },
    intervalInput: { label: 'Interval input', section: 'input', values: ['dual-calendar', 'drag', 'presets', 'timeline', 'slider', 'fields', 'duration'], default: 'dual-calendar', groups: ['groupEnterDateInterval', 'groupEnterDatetimeInterval', 'groupEnterTimeInterval'] },
    // ── seleção ──
    selectOne: { label: 'Select one', section: 'selection', values: ['dropdown', 'radio', 'segmented', 'cards', 'listbox', 'slider', 'dial', 'table'], default: 'dropdown', essential: true, groups: ['groupSelectOne'] },
    selectMany: { label: 'Select many', section: 'selection', values: ['dropdown', 'checkbox-list', 'dual-list', 'popover', 'tree'], default: 'checkbox-list', essential: true, groups: ['groupSelectMany'] },
    upload: { label: 'File upload', section: 'selection', values: ['dropzone', 'button', 'avatar'], default: 'dropzone', groups: ['groupSelectFileForUpload'] },
    // ── navegação ──
    navMain: { label: 'Main navigation', section: 'navigation', values: ['sidebar', 'topbar', 'bottom-tabs'], default: 'sidebar', groups: ['groupNavigateMain'] },
    sectionNav: { label: 'Section navigation', section: 'navigation', values: ['tabs', 'pills', 'breadcrumb', 'scrollspy'], default: 'tabs', groups: ['groupNavigateSection'] },
    steps: { label: 'Steps', section: 'navigation', values: ['horizontal', 'vertical'], default: 'horizontal', groups: ['groupNavigateSteps'] },
    // ── feedback / status ──
    feedback: { label: 'User feedback', section: 'feedback', values: ['toast', 'banner', 'inline', 'modal'], default: 'inline', essential: true, groups: ['groupNotifyUser'] },
    progress: { label: 'Progress', section: 'feedback', values: ['linear', 'circular', 'segmented', 'spinner'], default: 'linear', groups: ['groupShowProgress'] },
    // ── ação / rating / expand / search ──
    actionStyle: { label: 'Action style', section: 'action', values: ['standard', 'icon', 'split', 'kebab'], default: 'standard', groups: ['groupTriggerAction'] },
    rating: { label: 'Rating', section: 'action', values: ['stars', 'thumbs', 'nps', 'emoji', 'slider', 'tags'], default: 'stars', groups: ['groupRateItem'] },
    expand: { label: 'Expand content', section: 'action', values: ['accordion', 'collapsible', 'readmore', 'overlay'], default: 'accordion', groups: ['groupExpandContent'] },
    accordionMode: { label: 'Accordion mode', section: 'action', values: ['single', 'multiple'], default: 'single', groups: ['groupExpandContent'] },
    search: { label: 'Search', section: 'action', values: ['bar', 'bar-with-history'], default: 'bar', groups: ['groupSearchContent'] },
    // ── visualização ──
    recordsView: { label: 'Records view', section: 'visualization', values: ['table', 'grid', 'list', 'kanban', 'calendar', 'timeline'], default: 'table', essential: true, groups: ['groupViewData', 'groupViewTable'] },
    cardLayout: { label: 'Card layout', section: 'visualization', values: ['horizontal', 'vertical', 'media', 'profile'], default: 'vertical', groups: ['groupViewCard'] },
    metric: { label: 'Metric', section: 'visualization', values: ['big-number', 'gauge', 'sparkline'], default: 'big-number', groups: ['groupViewMetric'] },
    hierarchy: { label: 'Hierarchy', section: 'visualization', values: ['tree', 'orgchart', 'mindmap'], default: 'tree', groups: ['groupViewHierarchy'] },
};
export const layoutAxisKeys = Object.keys(layoutAxes);
/** Ordered list form of `layoutAxes`, each entry carrying its own `key`. */
export const layoutAxisList = layoutAxisKeys.map(k => ({ key: k, ...layoutAxes[k] }));
/** Curated subset shown by default in the configuration UI. */
export const essentialAxisList = layoutAxisList.filter(a => a.essential);
/** Every axis at its default value. */
export function layoutRuleDefaults() {
    const out = {};
    for (const k of layoutAxisKeys)
        out[k] = layoutAxes[k].default;
    return out;
}
/** True when `value` is a valid choice for `key` (validates layout rules and molecule defs). */
export function isValidAxisValue(key, value) {
    const axis = layoutAxes[key];
    return !!axis && axis.values.includes(value);
}
