/// <mls fileReference="_102020_/l2/aura/helpers/taskManager.ts" enhancement="_blank" />
// ─── Module-level store ───────────────────────────────────────────────
// Lives outside any component — survives DOM re-creation between knob navigations.
const _store = new Map();
const _listeners = new Set();
// ─── Write ───────────────────────────────────────────────────────────
export function setTask(key, task) {
    _store.set(key, task);
    _listeners.forEach(fn => fn());
}
// ─── Read ─────────────────────────────────────────────────────────────
export function getTask(key) {
    return _store.get(key);
}
export function getTasksByScope(scope) {
    const prefix = `${scope}:`;
    const result = new Map();
    _store.forEach((task, key) => { if (key.startsWith(prefix))
        result.set(key, task); });
    return result;
}
export function hasRunning(scope) {
    return [...getTasksByScope(scope).values()].some(t => t.status === 'running');
}
/** A batch is busy while any of its tasks is running or still waiting for its turn. */
export function hasPending(scope) {
    return [...getTasksByScope(scope).values()].some(t => t.status === 'running' || t.status === 'queued');
}
// ─── Subscription ────────────────────────────────────────────────────
// Returns an unsubscribe function. Call it in disconnectedCallback.
export function clearScope(scope) {
    const prefix = `${scope}:`;
    [..._store.keys()].forEach(key => { if (key.startsWith(prefix))
        _store.delete(key); });
    _listeners.forEach(fn => fn());
}
export function subscribeTaskManager(listener) {
    _listeners.add(listener);
    return () => _listeners.delete(listener);
}
