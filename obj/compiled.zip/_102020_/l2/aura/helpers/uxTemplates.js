/// <mls fileReference="_102020_/l2/aura/helpers/uxTemplates.ts" enhancement="_blank" />
/**
 * The UX templates of a genome UX (`config.layouts[N]`), one per page, and the options a page can pick.
 *
 * A UX is a set of templates per page: `layouts[N].templates.pages["<module>/<page>"]` holds the full path
 * of the chosen `.md` (`_102020_/l4/collabux/templates/<category>/<file>.md`). The key carries the module
 * because `layouts` belongs to the project and the same page id can exist in two modules. A page with no
 * entry uses the template of its page11 (`template.category` of `web/desktop/page11/<page>.defs.ts`).
 * UX 1 (`layouts["1"]`) uses the same key: there the entry is a template to apply to page11 itself
 * (`uxBaseTemplateChoice`, agentGenomeUx base mode).
 *
 * The options come from `l4/collabux/templates/experienceIndex.json` → `categories[<category>]`, in the
 * index's order. The category is the folder segment of the page11 template path.
 *
 * PURE — no `mls.*`, no DOM. The plugin (`plugins/selectUx.ts`) reads the files and writes the config.
 */
export const UX_TEMPLATES_ROOT = '_102020_/l4/collabux/templates/';
export const UX_BESPOKE = 'bespoke';
/** Key of a page in `templates.pages`. */
export function uxPageKey(module, page) {
    return `${module}/${page}`;
}
/** Full path of an index entry's file. */
export function uxTemplatePath(file) {
    return `${UX_TEMPLATES_ROOT}${file}`;
}
/**
 * Category of a page11 `template.category` value: the folder segment of
 * `_102020_/l4/collabux/templates/<category>/<file>.md`, or `bespoke` as is. Anything else is null.
 */
export function uxTemplateCategory(templatePath) {
    const value = (templatePath ?? '').trim();
    if (!value)
        return null;
    if (value === UX_BESPOKE)
        return UX_BESPOKE;
    if (!value.startsWith(UX_TEMPLATES_ROOT))
        return null;
    const [category, file] = value.slice(UX_TEMPLATES_ROOT.length).split('/');
    return category && file ? category : null;
}
/** The template chosen for a page in this UX, or null when the page uses its page11 one. */
export function getPageTemplate(layout, key) {
    const value = layout?.templates?.pages?.[key];
    return typeof value === 'string' && value ? value : null;
}
/**
 * Writes (or, with null, deletes) the page's entry. Deleting the last entry also deletes `pages`, and an
 * empty `templates` with it, so "back to default" leaves no trace in the config.
 */
export function setPageTemplate(layout, key, template) {
    if (template) {
        const templates = isRecord(layout.templates) ? layout.templates : {};
        const pages = isRecord(templates.pages) ? templates.pages : {};
        pages[key] = template;
        templates.pages = pages;
        layout.templates = templates;
        return;
    }
    const templates = layout.templates;
    if (!isRecord(templates))
        return;
    if (isRecord(templates.pages)) {
        delete templates.pages[key];
        if (!Object.keys(templates.pages).length)
            delete templates.pages;
    }
    if (!Object.keys(templates).length)
        delete layout.templates;
}
/** How many pages of this UX have a template chosen. */
export function countPageTemplates(layout) {
    const pages = layout?.templates?.pages;
    return isRecord(pages) ? Object.values(pages).filter(v => typeof v === 'string' && v).length : 0;
}
/**
 * The options of the page's category, in the index's order, the page11 one marked as default.
 * `page11Template` is the page11 `template.category` (null when the page has no page11 defs).
 */
export function buildTemplateOptions(index, page11Template, lang) {
    const category = uxTemplateCategory(page11Template);
    if (!page11Template)
        return { category: null, options: [], reason: 'noDefs' };
    if (category === UX_BESPOKE)
        return { category, options: [], reason: 'bespoke' };
    const entries = category ? index?.categories?.[category] : undefined;
    if (!category || !Array.isArray(entries) || !entries.length)
        return { category, options: [], reason: 'unknownCategory' };
    const options = entries.map(entry => {
        const template = uxTemplatePath(entry.file);
        return {
            experience: entry.experience,
            template,
            label: pick(entry.label, lang) || entry.experience,
            description: pick(entry.description, lang),
            bestFor: pick(entry.bestFor, lang),
            isDefault: template === page11Template,
        };
    });
    return { category, options, reason: null };
}
/**
 * The template in effect for the page: the entry when there is one, the page11 one otherwise.
 * `missing` flags an entry that is not among the options (a template renamed or removed).
 */
export function resolveEffectiveTemplate(layout, key, page11Template, options) {
    const chosen = getPageTemplate(layout, key);
    if (!chosen)
        return { template: page11Template || null, isDefault: true, missing: false };
    return { template: chosen, isDefault: chosen === page11Template, missing: !options.some(o => o.template === chosen) };
}
/**
 * UX 1 (the base, TASK-102020-genome-ux-4): page11 itself. Its cards mark the template in effect the same way
 * (the entry, else the page11 one), but an entry is a choice still to be APPLIED: agentGenomeUx in base mode
 * rewrites page11 with it. Returns the entry when it differs from the page11 `template.category`, null when there is
 * no entry or it is already the page11 template (nothing to apply).
 */
export function uxBaseTemplateChoice(layout, key, page11Template) {
    const chosen = getPageTemplate(layout, key);
    return chosen && chosen !== page11Template ? chosen : null;
}
function pick(text, lang) {
    return text?.[lang] ?? text?.en ?? text?.pt ?? '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
