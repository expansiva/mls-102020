/// <mls fileReference="_102020_/l2/aura/helpers/moduleLanguages.ts" enhancement="_blank" />
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { readStorText, storTextExists, writeStorText } from '/_102020_/l2/agentMaterializeL2/helpers/storText.js';
// module.defs.ts is not importable as JS — the repo pattern is to read it from mls.stor
// and parse the `export const X = {...} as const` body as pure JSON.
export function parseDefsSource(content) {
    const exportMatch = content.match(/export\s+const\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=/);
    const start = content.indexOf('= ');
    if (!exportMatch || start === -1)
        return null;
    // Two emission dialects: `} as const;` and `} as const satisfies <Artifact>;` (agentNewSolution,
    // which types every artifact). The type assertion is never part of the value. The first cut wins
    // for a file that appends a second export; the last is the fallback.
    const first = content.indexOf(' as const', start);
    const last = content.lastIndexOf(' as const');
    for (const end of first === last ? [first] : [first, last]) {
        if (end <= start)
            continue;
        try {
            const parsed = JSON.parse(content.slice(start + 2, end));
            if (isRecord(parsed))
                return { exportName: exportMatch[1], data: parsed };
        }
        catch { /* try the other cut */ }
    }
    return null;
}
/**
 * Replace only the exported value, keeping everything the generator wrote around it: the header, the
 * `import type`, the `satisfies` and the trailing exports. An agent that only flips a status inside
 * a generated file must not rewrite the file's shape.
 */
export function replaceDefsValue(content, value) {
    const start = content.indexOf('= ');
    if (start === -1)
        return null;
    const first = content.indexOf(' as const', start);
    const last = content.lastIndexOf(' as const');
    for (const end of first === last ? [first] : [first, last]) {
        if (end <= start)
            continue;
        try {
            JSON.parse(content.slice(start + 2, end));
        }
        catch {
            continue;
        }
        return `${content.slice(0, start + 2)}${JSON.stringify(value, null, 2)}${content.slice(end)}`;
    }
    return null;
}
function moduleDefsFileInfo(project, moduleName) {
    return { project, level: 4, folder: moduleName, shortName: 'module', extension: '.defs.ts' };
}
/** NS5 v2: `[defaultLanguage, ...productLanguages]` with no repeats. `null` when neither key is present. */
export function moduleLanguagesOf(source) {
    const parsed = parseDefsSource(source);
    if (!parsed)
        return null;
    const { data } = parsed;
    const hasDefault = typeof data.defaultLanguage === 'string';
    const hasProduct = Array.isArray(data.productLanguages);
    if (!hasDefault && !hasProduct)
        return null;
    const out = [];
    const push = (value) => {
        if (typeof value !== 'string')
            return;
        const code = value.trim();
        if (code && !out.includes(code))
            out.push(code);
    };
    if (hasDefault)
        push(data.defaultLanguage);
    if (hasProduct)
        for (const code of data.productLanguages)
            push(code);
    return out;
}
/**
 * Replace only `productLanguages`, keeping the rest of the file. NS5 requires `defaultLanguage`
 * to be one of `productLanguages`.
 */
export function withModuleLanguages(source, languages) {
    const parsed = parseDefsSource(source);
    if (!parsed)
        throw new Error('[withModuleLanguages] invalid module.defs.ts source');
    const next = languages.map(l => (typeof l === 'string' ? l.trim() : '')).filter(Boolean);
    if (next.length === 0)
        throw new Error('[withModuleLanguages] productLanguages must not be empty');
    const defaultLanguage = typeof parsed.data.defaultLanguage === 'string' ? parsed.data.defaultLanguage.trim() : '';
    if (!defaultLanguage || !next.includes(defaultLanguage)) {
        throw new Error(`[withModuleLanguages] productLanguages must include defaultLanguage '${defaultLanguage || '(missing)'}'`);
    }
    const replaced = replaceDefsValue(source, { ...parsed.data, productLanguages: next });
    if (!replaced)
        throw new Error('[withModuleLanguages] could not replace productLanguages');
    return replaced;
}
/** The module's `defaultLanguage`, or `null` when the file or the key is missing. */
export async function readModuleDefaultLanguage(project, moduleName) {
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(moduleDefsFileInfo(project, moduleName))];
        if (!file)
            return null;
        const parsed = parseDefsSource(String(await file.getContent()));
        const value = parsed?.data.defaultLanguage;
        if (typeof value !== 'string')
            return null;
        const code = value.trim();
        return code || null;
    }
    catch (e) {
        console.warn(`[readModuleDefaultLanguage] failed to read module.defs.ts for '${moduleName}' (project ${project}): ${e instanceof Error ? e.message : String(e)}`);
        return null;
    }
}
/**
 * The module's own languages, WITHOUT the legacy fallback: `null` when the module.defs.ts is missing,
 * unreadable or carries no language. A batch over every module uses this to tell "configured" from "absent".
 */
export async function readModuleDefsLanguages(project, moduleName) {
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(moduleDefsFileInfo(project, moduleName))];
        if (!file)
            return null;
        const languages = moduleLanguagesOf(String(await file.getContent()));
        return languages && languages.length > 0 ? languages : null;
    }
    catch {
        return null;
    }
}
export async function readModuleLanguages(project, moduleName) {
    let reason = `module.defs.ts for '${moduleName}' (project ${project}) has no productLanguages/defaultLanguage`;
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(moduleDefsFileInfo(project, moduleName))];
        if (!file) {
            reason = `module.defs.ts not found for module '${moduleName}' (project ${project})`;
        }
        else {
            const languages = moduleLanguagesOf(String(await file.getContent()));
            if (languages && languages.length > 0)
                return languages;
            if (languages === null) {
                reason = `module.defs.ts for '${moduleName}' (project ${project}) has neither productLanguages nor defaultLanguage`;
            }
        }
    }
    catch (e) {
        reason = `failed to read module.defs.ts for '${moduleName}' (project ${project}): ${e instanceof Error ? e.message : String(e)}`;
    }
    try {
        const config = await getConfigProject(project);
        const legacy = (config?.languages ?? [])
            .map((i) => i?.language)
            .filter((l) => typeof l === 'string' && !!l.trim());
        if (legacy.length > 0) {
            console.warn(`[readModuleLanguages] ${reason}; falling back to project config.languages`);
            return legacy;
        }
    }
    catch { /* fall through to ['en'] */ }
    console.warn(`[readModuleLanguages] ${reason}; falling back to ['en']`);
    return ['en'];
}
export async function writeModuleLanguages(project, moduleName, languages) {
    const fileInfo = moduleDefsFileInfo(project, moduleName);
    const key = mls.stor.getKeyToFile(fileInfo);
    const storFile = mls.stor.files[key];
    if (!storFile)
        throw new Error(`[writeModuleLanguages] module.defs.ts not found for module '${moduleName}' (project ${project})`);
    const source = withModuleLanguages(String(await storFile.getContent()), languages);
    // l4 defs is not an editor file — write through localStor.setContent, not getOrCreateModel.
    if (storFile.status !== 'renamed' && storFile.status !== 'new')
        storFile.status = 'changed';
    storFile.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: source });
}
// ─── Runtime list: l5/config.json ────────────────────────────────────
// The app does not read module.defs.ts: Ctrl+Alt+L and the header language select use
// `window.collabBoot.languages`, which the server takes from l5/config.json
// `projects[<project>].modules[moduleId].languages`. finalize70 (agentMaterializeL2) writes it from
// productLanguages; adding or removing a language must keep it in step, or the new language never shows.
export function configJsonInfo(project) {
    return { project, level: 5, folder: '', shortName: 'config', extension: '.json' };
}
function configModuleEntry(config, project, moduleName) {
    const modules = config?.projects?.[String(project)]?.modules;
    if (!Array.isArray(modules))
        return null;
    const entry = modules.find((m) => isRecord(m) && m.moduleId === moduleName);
    return isRecord(entry) ? entry : null;
}
/** The module's runtime languages in config.json, or `null` when the module is not registered there. */
export function configModuleLanguagesOf(raw, project, moduleName) {
    let config;
    try {
        config = JSON.parse(raw);
    }
    catch {
        return null;
    }
    const entry = configModuleEntry(config, project, moduleName);
    if (!entry)
        return null;
    return Array.isArray(entry.languages) ? entry.languages.filter((l) => typeof l === 'string') : [];
}
/**
 * config.json with only `languages` of the module's entry replaced, written the way finalize70 writes it
 * (2-space JSON, trailing newline, the file's own line endings). `null` when the module is not registered —
 * registering a module is finalize70's job — or when the list is already the same.
 */
export function withConfigModuleLanguages(raw, project, moduleName, languages) {
    const eol = raw.includes('\r\n') ? '\r\n' : '\n';
    const config = JSON.parse(raw.replace(/\r\n/g, '\n'));
    const entry = configModuleEntry(config, project, moduleName);
    if (!entry)
        return null;
    if (JSON.stringify(entry.languages) === JSON.stringify(languages))
        return null;
    entry.languages = [...languages];
    return `${JSON.stringify(config, null, 2)}\n`.replace(/\n/g, eol);
}
/** The module's runtime languages, or `null` when there is no config.json or the module is not in it. */
export async function readConfigModuleLanguages(project, moduleName) {
    const info = configJsonInfo(project);
    if (!storTextExists(info))
        return null;
    try {
        return configModuleLanguagesOf(await readStorText(info), project, moduleName);
    }
    catch {
        return null;
    }
}
/** Writes the module's runtime languages. `false` when nothing was written (no config, not registered, same list). */
export async function writeConfigModuleLanguages(project, moduleName, languages) {
    const info = configJsonInfo(project);
    if (!storTextExists(info))
        return false;
    const next = withConfigModuleLanguages(await readStorText(info), project, moduleName, languages);
    if (next === null)
        return false;
    await writeStorText(info, next);
    return true;
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
