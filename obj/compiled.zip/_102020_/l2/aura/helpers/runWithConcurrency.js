/// <mls fileReference="_102020_/l2/aura/helpers/runWithConcurrency.ts" enhancement="_blank" />
export async function runWithConcurrency(items, limit, fn) {
    const results = new Array(items.length);
    const workers = Math.max(1, Math.min(Math.floor(limit) || 1, items.length));
    let next = 0;
    const worker = async () => {
        while (next < items.length) {
            const index = next++;
            try {
                results[index] = { ok: true, value: await fn(items[index], index) };
            }
            catch (error) {
                results[index] = { ok: false, error };
            }
        }
    };
    await Promise.all(Array.from({ length: workers }, worker));
    return results;
}
