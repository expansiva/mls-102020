/// <mls fileReference="_102020_/l2/aura/helpers/pageSimulationCore.ts" enhancement="_blank" />
// The simulation of the page on screen, without the app: what is simulated, what was there before, when a value is
// put back. The store is injected, so the tests run it on a Map. Wired to collabState in studio/studioPageSimulation,
// which also says WHY the simulation does not live in the "States" tab.
/**
 * How long after a live update a simulated value is put back when the app overwrites it.
 *
 * Long enough for a query to come back; after it, an overwrite is the app's and is only reported.
 */
export const REASSERT_MS = 10000;
/** Where the simulated keys are published, so the fact is visible outside the tab (the class picker's badge). */
export const SIMULATED_KEYS_STATE = 'aura.scenario.simulated';
/** `project:folder:shortName`, or '' for no page. */
export function pageIdOf(page) {
    return page ? `${page.project}:${page.folder}:${page.shortName}` : '';
}
export class PageSimulation {
    constructor(store) {
        this.store = store;
        this._pageId = '';
        this._active = null;
        this._simulated = new Map();
        this._reassertUntil = 0;
        this._unwatch = null;
        this._listeners = new Set();
    }
    /** The situation on for `pageId`, or null (normal). */
    activeFor(pageId) {
        return pageId === this._pageId ? this._active : null;
    }
    /** The simulated keys of `pageId`, with what was there before. */
    simulatedFor(pageId) {
        return pageId === this._pageId ? this._simulated : new Map();
    }
    /** Called on every change; returns the unsubscribe. */
    onChange(listener) {
        this._listeners.add(listener);
        return () => { this._listeners.delete(listener); };
    }
    /** Writes one simulated value on `pageId` (a simulation of another page is undone first). */
    write(pageId, key, value) {
        this._enter(pageId);
        this._write(key, value);
        this._changed();
    }
    /**
     * Turns a situation on (null = normal): the keys of the previous one (`undo`) are put back first, then `writes`
     * are applied. Only one situation is on at a time; the scene is not touched.
     */
    setSituation(pageId, id, undo, writes) {
        this._enter(pageId);
        for (const key of undo)
            this._restore(key);
        this._active = id;
        for (const [key, value] of Object.entries(writes))
            this._write(key, value);
        this._changed();
    }
    /** Everything back to what the app had. */
    restoreAll() {
        const had = this._simulated.size > 0 || this._active !== null;
        this._active = null;
        for (const key of [...this._simulated.keys()])
            this._restore(key);
        if (had)
            this._changed();
    }
    /** The page on screen is now `pageId`: a simulation of another page ends. */
    pageShown(pageId) {
        if (pageId !== this._pageId) {
            this.restoreAll();
            this._pageId = pageId;
        }
    }
    /** A live update remounted the page: put every simulation back, and hold it for a while (REASSERT_MS). */
    reapply() {
        if (!this._simulated.size)
            return;
        this._reassertUntil = this.store.now() + REASSERT_MS;
        for (const [key, simulation] of this._simulated)
            this.store.set(key, simulation.applied);
        this._notify();
    }
    _enter(pageId) {
        if (pageId !== this._pageId) {
            this.restoreAll();
            this._pageId = pageId;
        }
    }
    _write(key, value) {
        const existing = this._simulated.get(key);
        // The ORIGINAL is captured once: a second write must not make "restore" put back the first simulation.
        const original = existing ? existing.original : this.store.get(key);
        this._simulated.set(key, { original, applied: value });
        this.store.set(key, value);
    }
    _restore(key) {
        const simulation = this._simulated.get(key);
        if (!simulation)
            return;
        this._simulated.delete(key);
        this.store.set(key, simulation.original);
    }
    /** A simulated key changed: right after a live update it is put back, otherwise it is only reported. */
    _onWrote(key, value) {
        const simulation = this._simulated.get(key);
        if (simulation && value !== simulation.applied && this.store.now() < this._reassertUntil) {
            // After the app's own write has finished, never inside it.
            this.store.later(() => {
                const current = this._simulated.get(key);
                if (current && this.store.get(key) !== current.applied)
                    this.store.set(key, current.applied);
            });
            return;
        }
        this._notify();
    }
    _changed() {
        this._unwatch?.();
        this._unwatch = null;
        const keys = [...this._simulated.keys()];
        if (keys.length)
            this._unwatch = this.store.watch(keys, (key, value) => this._onWrote(key, value));
        this.store.set(SIMULATED_KEYS_STATE, keys);
        this._notify();
    }
    _notify() {
        for (const listener of this._listeners)
            listener();
    }
}
