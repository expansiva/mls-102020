/// <mls fileReference="_102020_/l2/aura/agentManagePage/editCore.ts" enhancement="_blank" />
// Pure core for the page-edit flow (TASK-102020-agent-manage-page). No mls.* — testable directly.
//
// The gate (agentManagePage root) classifies the user request into typed operations OR rejects it.
// agentEditDefs then asks the LLM for the edited `definition` and validates it here before writing.
// The guards are schema-agnostic: they preserve page IDENTITY and, for genome-shaped defs (with
// `definition.layout`), keep the layout schema parseable. Mode pages (brief/uiSpec, no layout) pass
// the identity guard and skip the layout guard.
import { listLayoutElements } from '/_102020_/l2/aura/helpers/dsMatch/layoutElements.js';
/** Fields that identify the page — an edit must NEVER change them. */
export const IDENTITY_KEYS = ['pageId', 'moduleName', 'genome', 'baseClassName', 'routePattern'];
export function isRecord(x) {
    return !!x && typeof x === 'object' && !Array.isArray(x);
}
/** True when the definition carries a genome layout tree (definition.layout.sections). */
export function hasGenomeLayout(def) {
    const layout = isRecord(def) ? def.layout : undefined;
    return !!layout && typeof layout === 'object' && Array.isArray(layout.sections);
}
/** The set of molecule-eligible element ids in a (genome) definition. Empty for mode defs. */
export function layoutElementIdSet(def) {
    const layout = isRecord(def) ? def.layout : undefined;
    if (!layout)
        return new Set();
    return new Set(listLayoutElements(layout).map(e => e.id));
}
/** Added/removed element ids between two genome definitions (for logging + soft checks). */
export function idDelta(originalDef, editedDef) {
    const before = layoutElementIdSet(originalDef);
    const after = layoutElementIdSet(editedDef);
    const added = [...after].filter(id => !before.has(id));
    const removed = [...before].filter(id => !after.has(id));
    return { added, removed };
}
/**
 * Validate the LLM-edited `definition` against the original:
 *   - must be an object;
 *   - identity fields present in the original must be byte-identical in the edited one;
 *   - if the original was genome-shaped, the edited one must remain genome-shaped and still parse
 *     to ≥1 layout element (schema not broken).
 * Returns the edited definition on success, or a human reason on failure.
 */
export function validateEditedDefinition(original, edited) {
    if (!isRecord(original))
        return { ok: false, reason: 'original definition is not an object' };
    if (!isRecord(edited))
        return { ok: false, reason: 'edited definition is not an object' };
    for (const k of IDENTITY_KEYS) {
        if (k in original && JSON.stringify(original[k]) !== JSON.stringify(edited[k])) {
            return { ok: false, reason: `identity field '${k}' must not change (was ${JSON.stringify(original[k])})` };
        }
    }
    if (hasGenomeLayout(original)) {
        if (!hasGenomeLayout(edited))
            return { ok: false, reason: 'definition.layout structure was dropped' };
        if (layoutElementIdSet(edited).size === 0)
            return { ok: false, reason: 'edited layout has no elements (schema broke)' };
    }
    return { ok: true, value: edited };
}
/** Normalize/validate the gate's operations array. Keeps only well-formed structural/cosmetic ops. */
export function normalizeOperations(raw) {
    const arr = Array.isArray(raw) ? raw : [];
    const out = [];
    for (const o of arr) {
        const kind = o?.kind;
        const description = typeof o?.description === 'string' ? o.description.trim() : '';
        if ((kind !== 'structural' && kind !== 'cosmetic') || !description)
            continue;
        out.push({ kind, target: typeof o?.target === 'string' ? o.target : '', description });
    }
    return out;
}
