/// <mls fileReference="_102020_/l2/aura/agentManagePage/editCore.ts" enhancement="_blank" />
// Pure core for the page-edit flow (TASK-102020-agent-manage-page). No mls.* — testable directly.
//
// The gate (agentManagePage root) classifies the user request into typed operations OR rejects it.
// agentEditDefs then asks the LLM for the edited `definition` and validates it here before writing.
// The guards are schema-agnostic: they preserve page IDENTITY and, for genome-shaped defs (with
// `definition.layout`), keep the layout schema parseable. Mode pages (brief/uiSpec, no layout) pass
// the identity guard and skip the layout guard.
import { listLayoutElements } from '/_102020_/l2/aura/helpers/dsMatch/layoutElements.js';
import { nextAdjustmentId } from '/_102020_/l2/aura/helpers/dsMatch/pageAdjustments.js';
/** Fields that identify the page — an edit must NEVER change them. */
export const IDENTITY_KEYS = ['pageId', 'moduleName', 'genome', 'baseClassName', 'routePattern'];
export function isRecord(x) {
    return !!x && typeof x === 'object' && !Array.isArray(x);
}
/** True when the definition carries a genome layout tree (definition.layout.sections). */
export function hasGenomeLayout(def) {
    const layout = isRecord(def) ? def.layout : undefined;
    return !!layout && typeof layout === 'object' && Array.isArray(layout.sections);
}
/** The set of molecule-eligible element ids in a (genome) definition. Empty for mode defs. */
export function layoutElementIdSet(def) {
    const layout = isRecord(def) ? def.layout : undefined;
    if (!layout)
        return new Set();
    return new Set(listLayoutElements(layout).map(e => e.id));
}
/** Added/removed element ids between two genome definitions (for logging + soft checks). */
export function idDelta(originalDef, editedDef) {
    const before = layoutElementIdSet(originalDef);
    const after = layoutElementIdSet(editedDef);
    const added = [...after].filter(id => !before.has(id));
    const removed = [...before].filter(id => !after.has(id));
    return { added, removed };
}
/**
 * Validate the LLM-edited `definition` against the original:
 *   - must be an object;
 *   - identity fields present in the original must be byte-identical in the edited one;
 *   - if the original was genome-shaped, the edited one must remain genome-shaped and still parse
 *     to ≥1 layout element (schema not broken).
 * Returns the edited definition on success, or a human reason on failure.
 */
export function validateEditedDefinition(original, edited) {
    if (!isRecord(original))
        return { ok: false, reason: 'original definition is not an object' };
    if (!isRecord(edited))
        return { ok: false, reason: 'edited definition is not an object' };
    for (const k of IDENTITY_KEYS) {
        if (k in original && JSON.stringify(original[k]) !== JSON.stringify(edited[k])) {
            return { ok: false, reason: `identity field '${k}' must not change (was ${JSON.stringify(original[k])})` };
        }
    }
    if (hasGenomeLayout(original)) {
        if (!hasGenomeLayout(edited))
            return { ok: false, reason: 'definition.layout structure was dropped' };
        if (layoutElementIdSet(edited).size === 0)
            return { ok: false, reason: 'edited layout has no elements (schema broke)' };
    }
    return { ok: true, value: edited };
}
/**
 * Delta-mode prompt section for the render step: the page's CURRENT generated code + the recorded
 * adjustments, with a minimal-change instruction. Pure. Returns '' when there is nothing to
 * preserve (no current code AND no adjustments) — caller then omits the section.
 */
export function buildDeltaSection(currentCode, adjustments) {
    const hasCode = !!currentCode && currentCode.trim().length > 0;
    if (!hasCode && (!adjustments || adjustments.length === 0))
        return '';
    const parts = ['## Edit mode — minimal change'];
    if (adjustments?.length) {
        parts.push('', 'Apply ONLY these visual adjustments; keep everything else in the current code structurally identical:', ...adjustments.map(a => {
            const tail = [a.notes ? `— ${a.notes}` : '', a.imageUrl ? `(reference image: ${a.imageUrl})` : ''].filter(Boolean).join(' ');
            return `- (${a.kind ?? 'edit'}) ${a.request}${tail ? ` ${tail}` : ''}`;
        }));
        // Explicit directive when an adjustment carries a reference image. NOTE: the prompt is
        // text-only — the model receives the URL, not the pixels — so this is a best-effort nudge:
        // follow the image if reachable, otherwise honor the adjustment text precisely.
        if (adjustments.some(a => a.imageUrl)) {
            parts.push('', 'One or more adjustments include a reference image (the URL after "reference image"). That URL is the visual target for its adjustment: reproduce its layout, spacing and formatting as faithfully as the existing states, actions and design-system tokens allow. If you cannot access the image, still honor the adjustment text exactly.');
        }
    }
    if (hasCode) {
        parts.push('', '### Current code (preserve verbatim except for the adjustments above)', '```ts', currentCode.trim(), '```');
    }
    return parts.join('\n');
}
/** Keep only well-formed items (non-empty request, valid kind); coerce id/notes/imageUrl. */
export function normalizeConsolidatedAdjustments(raw) {
    const arr = Array.isArray(raw) ? raw : [];
    const out = [];
    for (const o of arr) {
        const request = typeof o?.request === 'string' ? o.request.trim() : '';
        const kind = o?.kind;
        if (!request || (kind !== 'structural' && kind !== 'cosmetic'))
            continue;
        const id = typeof o?.id === 'string' && o.id.trim() ? o.id.trim() : undefined;
        const notes = typeof o?.notes === 'string' && o.notes.trim() ? o.notes.trim() : undefined;
        const imageUrl = typeof o?.imageUrl === 'string' && o.imageUrl.trim() ? o.imageUrl.trim() : undefined;
        out.push({ id, request, kind, notes, imageUrl });
    }
    return out;
}
/**
 * Reconcile the LLM's consolidated list against the existing adjustments into the final
 * PageAdjustment[] to persist. Pure (takes `nowIso` — no Date.now inside):
 *   - id matches an existing adjustment → reuse its id + `at` (audit continuity), take the
 *     consolidated request/kind, and its notes/imageUrl (falling back to the prior values);
 *   - no id, or an id NOT in `existing` → mint the next id + `at=nowIso` (unknown ids never trusted);
 *   - superseded prior adjustments simply don't appear in `consolidated`, so they drop out.
 *
 * `newImageUrl` is the reference image of the CURRENT request: the LLM does not echo URLs
 * reliably, so we attach it DETERMINISTICALLY to any freshly-minted adjustment that has none.
 * Surviving adjustments keep their own recorded imageUrl.
 */
export function reconcileAdjustments(existing, consolidated, nowIso, newImageUrl) {
    const byId = new Map(existing.map(a => [a.id, a]));
    const out = [];
    for (const item of consolidated) {
        const kind = item.kind === 'structural' ? 'structural' : 'cosmetic';
        const prior = item.id ? byId.get(item.id) : undefined;
        if (prior) {
            out.push({
                id: prior.id,
                at: prior.at,
                request: item.request,
                kind,
                notes: item.notes ?? prior.notes,
                imageUrl: item.imageUrl ?? prior.imageUrl,
            });
        }
        else {
            // Mint against existing + already-emitted so multiple new items get distinct ids.
            // A new adjustment with no image of its own inherits the current request's reference image.
            out.push({
                id: nextAdjustmentId([...existing, ...out]),
                at: nowIso,
                request: item.request,
                kind,
                notes: item.notes || undefined,
                imageUrl: item.imageUrl || newImageUrl || undefined,
            });
        }
    }
    return out;
}
/** Normalize/validate the gate's operations array. Keeps only well-formed structural/cosmetic ops. */
export function normalizeOperations(raw) {
    const arr = Array.isArray(raw) ? raw : [];
    const out = [];
    for (const o of arr) {
        const kind = o?.kind;
        const description = typeof o?.description === 'string' ? o.description.trim() : '';
        if ((kind !== 'structural' && kind !== 'cosmetic') || !description)
            continue;
        out.push({ kind, target: typeof o?.target === 'string' ? o.target : '', description });
    }
    return out;
}
