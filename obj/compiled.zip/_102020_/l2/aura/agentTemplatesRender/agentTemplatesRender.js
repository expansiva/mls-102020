/// <mls fileReference="_102020_/l2/aura/agentTemplatesRender/agentTemplatesRender.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { mkAgentStep, mkFail, makePlanId } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { DEFAULT_DEVICE } from '/_102020_/l2/aura/helpers/dsMatch/derivePaths.js';
import { deriveGenome, listWorkspaces } from '/_102020_/l2/aura/agentTemplatesRender/tplCore.js';
export function createAgent() {
    return {
        agentName: 'agentTemplatesRender',
        agentProject: 102020,
        agentFolder: 'aura/agentTemplatesRender',
        agentDescription: 'Generate pages guided by a reusable UX template (CollabUX): plan → template → defs → critique → fix → render',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const { module, styleModel, layout, ds, device, pages } = JSON.parse(userPrompt);
    if (!module || !styleModel || layout == null || ds == null) {
        throw new Error(`(${agent.agentName}) entry needs { module, styleModel, layout, ds }`);
    }
    const dev = device || DEFAULT_DEVICE;
    const genome = deriveGenome(layout, ds);
    const targetPages = Array.isArray(pages) ? pages.filter(p => typeof p === 'string' && p) : [];
    console.info('[agentTemplatesRender] ▶ request', { module, styleModel, layout, ds, device: dev, genome, pages: targetPages.length ? targetPages : 'ALL' });
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: JSON.stringify({ module, styleModel, layout, ds, device: dev, pages: targetPages }) },
            ],
            taskTitle: `Templates (${styleModel}) → ${genome} on ${module}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                module, styleModel, layout: String(layout), ds: String(ds), device: dev, genome,
                pages: JSON.stringify(targetPages),
            },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        if (payload.type === 'result') {
            return [mkFail(context, parentStep, step, hookSequential, String(payload.result || 'confirmation returned an error'))];
        }
        if (payload.type !== 'flexible' || payload.result?.status !== 'ok') {
            return [mkFail(context, parentStep, step, hookSequential, 'templates request not confirmed')];
        }
        const lm = (context.task?.iaCompressed?.longMemory || {});
        const module = lm['module'];
        const styleModel = lm['styleModel'];
        const layout = lm['layout'];
        const ds = lm['ds'];
        const device = lm['device'] || DEFAULT_DEVICE;
        const genome = lm['genome'] || deriveGenome(layout, ds);
        if (!module || !styleModel || layout == null || ds == null)
            throw new Error('missing run params in longMemory');
        const project = mls.actualProject || 0;
        let requested = [];
        try {
            requested = JSON.parse(lm['pages'] || '[]');
        }
        catch {
            requested = [];
        }
        const toShortName = (p) => (p.split('/').pop() ?? '').replace(/\.defs\.ts$/, '').replace(/\.ts$/, '');
        const requestedShort = requested.map(toShortName).filter(Boolean);
        const allPages = listWorkspaces(project, module);
        const pages = requestedShort.length ? allPages.filter(p => requestedShort.includes(p)) : allPages;
        console.info(`[agentTemplatesRender] project=${project} module=${module} style=${styleModel} genome=${genome}`);
        console.info(`[agentTemplatesRender] ${pages.length}/${allPages.length} workspace(s):`, pages, requestedShort.length ? `(requested: ${requestedShort.join(', ')})` : '(all)');
        if (pages.length === 0) {
            throw new Error(requestedShort.length
                ? `none of the requested pages [${requestedShort.join(', ')}] exist in ${module}/workspaces (available: ${allPages.join(', ') || 'none'})`
                : `no workspaces found in l4/${module}/workspaces`);
        }
        const planArgs = { module, styleModel, layout, ds, device, genome, pages };
        const plan = mkAgentStep(context, step, makePlanId('plan'), `Plan templates: ${styleModel}`, 'agentTplPlan', planArgs, [], 'waiting_human_input', 'sequential');
        console.info('[agentTemplatesRender] ✓ created plan step');
        return [plan];
    }
    catch (error) {
        const msg = `[${agent.agentName}] ${error instanceof Error ? error.message : String(error)}`;
        console.error('[agentTemplatesRender] ✗', msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
const system1 = `
<!-- modelType: classifier -->

You validate a template-guided page-generation request. The human message is a JSON object
{ module, styleModel, layout, ds, device, pages } (pages is an optional subset; empty = all pages).
If it is a well-formed request, return ONLY:
{"type":"flexible","result":{"status":"ok"}}

If it is clearly invalid, return ONLY:
{"type":"result","result":"a short reason in the user's language"}

Return valid JSON only. No preamble, no markdown fences.

## Output format
export type Output =
  | { type: 'flexible'; result: { status: 'ok' } }
  | { type: 'result'; result: string };
`;
//#endregion
