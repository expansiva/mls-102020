/// <mls fileReference="_102020_/l2/aura/agentTemplatesRender/agentTplCritique.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { mkFail, mkCompleted } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { parseTplArgs, templateRef, sharedRef, defsDestRef, critiqueRef, listContractRefs, readContextSections, saveTextArtifact, buildFileSystemPrompt, buildLabelledHuman, extractFileContent, TPL_FILE_TOOL, TPL_FILE_TOOL_NAME, } from '/_102020_/l2/aura/agentTemplatesRender/tplCore.js';
import { skill as critiqueSkill } from '/_102020_/l2/aura/agentTemplatesRender/skills/critiqueDefsVsTemplate.js';
export function createAgent() {
    return {
        agentName: 'agentTplCritique',
        agentProject: 102020,
        agentFolder: 'aura/agentTemplatesRender',
        agentDescription: 'Critique a page .defs against the template (adherence) and the shared (anchoring)',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseTplArgs(args ?? step.prompt);
        if (!a.page || !a.templateId)
            throw new Error('missing page or templateId');
        const project = mls.actualProject || 0;
        const outPath = critiqueRef(project, a.module, a.genome, a.page);
        console.info(`[agentTplCritique] ▶ ${a.page} → ${outPath}`);
        const contractRefs = listContractRefs(project, a.module, a.page, a.device);
        const contextSections = await readContextSections([
            { ref: defsDestRef(a, project), lang: 'ts' },
            { ref: templateRef(project, a.styleModel, a.templateId) },
            { ref: sharedRef(project, a.module, a.page), lang: 'ts' },
            ...contractRefs.map(ref => ({ ref, lang: 'ts' })),
        ]);
        const humanPrompt = buildLabelledHuman([
            { title: `Review target`, body: `Critique the .defs of page **${a.page}** against template **${a.templateId}** (${a.styleModel}) and the shared surface. Produce findings only.` },
            ...contextSections,
        ], outPath);
        const continueParallel = {
            type: 'prompt_ready',
            args: args ?? step.prompt ?? '',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt: buildFileSystemPrompt(critiqueSkill, 'code', outPath),
            humanPrompt,
            tools: [TPL_FILE_TOOL],
            toolChoice: { type: 'function', function: { name: TPL_FILE_TOOL_NAME } },
        };
        return [continueParallel];
    }
    catch (error) {
        return [mkFail(context, parentStep, step, hookSequential, `[agentTplCritique] ${error instanceof Error ? error.message : String(error)}`)];
    }
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const a = parseTplArgs(step.prompt);
        const project = mls.actualProject || 0;
        const outPath = critiqueRef(project, a.module, a.genome, a.page);
        const content = extractFileContent(step.interaction?.payload?.[0]);
        if (!content)
            return [mkFail(context, parentStep, step, hookSequential, 'critique returned no content')];
        if (!context.isTest) {
            const ok = await saveTextArtifact(outPath, content);
            if (!ok)
                return [mkFail(context, parentStep, step, hookSequential, `save failed: ${outPath}`)];
            console.info(`[agentTplCritique] ✓ ${a.page}: critique written`);
        }
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        return [mkFail(context, parentStep, step, hookSequential, `[agentTplCritique] ${error instanceof Error ? error.message : String(error)}`)];
    }
}
