/// <mls fileReference="_102020_/l2/aura/plugins/helpers/headerPluginCore.ts" enhancement="_blank"/>
// Pure core of the header editor (pluginHeaderEditor): reads what the project has, turns a
// form into the agent's request, and computes the config/backup writes. No DOM and no mls calls, so
// every rule here is testable in node — the widget stays a thin shell around it.
//
// Two documents are involved and it matters which is which:
//   * `l5/config.json`  — the RUNTIME document: `clientShell.regions.header.profiles[...]` (renderer,
//     heightPx, brand, props.actions). This is what the shell boots from.
//   * `l5/project.json` — the STUDIO document: one-shot drafts (`headerDraft`, `logoDraft`) and the
//     rollback slot (`headerBackup`). The runtime never reads these.
import { DEFAULT_HEADER_PROFILE, headerPaths, isProjectHeaderTag, variantFromTag, normalizeHeaderRequest, pointHeaderProfileAtProject, } from '/_102020_/l2/aura/agentManageHeader/helpers/generateHeaderCore.js';
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function clone(value) {
    return JSON.parse(JSON.stringify(value));
}
/** Reads the header region of `l5/config.json` for display. Returns undefined when there is none. */
export function readHeaderProfileView(config, projectId, profileName) {
    if (!isRecord(config))
        return undefined;
    const clientShell = isRecord(config.clientShell)
        ? config.clientShell
        : undefined;
    const header = clientShell?.regions?.header;
    if (!header?.profiles)
        return undefined;
    const name = readString(profileName) || header.activeProfile || DEFAULT_HEADER_PROFILE;
    const profile = header.profiles[name];
    if (!profile)
        return undefined;
    const props = isRecord(profile.props) ? profile.props : undefined;
    const actions = Array.isArray(props?.actions) ? props.actions : [];
    const stringList = (value) => (Array.isArray(value)
        ? value.map(readString).filter(Boolean)
        : []);
    return {
        profileName: name,
        profileNames: Object.keys(header.profiles),
        shellMode: readString(clientShell?.mode) || 'spa',
        variant: variantFromTag(readString(profile.renderer?.tag), projectId),
        isActive: name === (header.activeProfile || DEFAULT_HEADER_PROFILE),
        tag: readString(profile.renderer?.tag),
        entrypoint: readString(profile.renderer?.entrypoint),
        source: readString(profile.renderer?.source) || undefined,
        heightPx: typeof profile.heightPx === 'number' ? profile.heightPx : undefined,
        brand: isRecord(profile.brand) ? profile.brand : undefined,
        actions,
        locales: stringList(props?.locales),
        navLinks: stringList(props?.navLinks),
        // Any header this project generated counts — the default one and every variant.
        isProjectHeader: isProjectHeaderTag(readString(profile.renderer?.tag), projectId),
    };
}
/**
 * Re-scopes compiled design-system tokens from the document root onto one container.
 *
 * The preview renders inside the STUDIO's document, so the project's tokens cannot be dropped on
 * `:root` — they would repaint the studio itself. `tokensCssFromTheme` emits exactly two selector
 * shapes (`:root` for light, `[data-theme="dark"], :root.dark` for dark), so both are rewritten to
 * live under `scope` while keeping the dark switch working from an ancestor.
 *
 * @param css - The compiled token CSS (`tokensCssFromTheme`).
 * @param scope - Selector of the container that holds the band, e.g. `[data-token-scope="102051"]`.
 */
export function scopeTokensCss(css, scope) {
    if (!css.trim() || !scope.trim())
        return '';
    return css
        .replace(/\[data-theme="dark"\]\s*,\s*:root\.dark/gu, `[data-theme="dark"] ${scope}, .dark ${scope}`)
        .replace(/:root\.dark/gu, `.dark ${scope}`)
        .replace(/:root/gu, scope);
}
/**
 * Every header the project has, in config order — what the knob lists and what the panel renders.
 *
 * Profiles that point at a master's header (`studio`) are kept in the result with
 * `isProjectHeader: false`: the caller decides whether to show them, and hiding them here would make
 * "why does Ctrl+Alt+S cycle into something I cannot see" unanswerable.
 */
export function listProjectHeaders(config, projectId) {
    if (!isRecord(config))
        return [];
    const clientShell = isRecord(config.clientShell)
        ? config.clientShell
        : undefined;
    const header = clientShell?.regions?.header;
    if (!header?.profiles)
        return [];
    const active = header.activeProfile || DEFAULT_HEADER_PROFILE;
    return Object.entries(header.profiles).map(([profileName, raw]) => {
        const profile = raw;
        const props = isRecord(profile.props) ? profile.props : undefined;
        const stringList = (value) => (Array.isArray(value) ? value.map(readString).filter(Boolean) : []);
        const tag = readString(profile.renderer?.tag);
        return {
            profileName,
            variant: variantFromTag(tag, projectId),
            tag,
            source: readString(profile.renderer?.source) || undefined,
            isActive: profileName === active,
            isProjectHeader: isProjectHeaderTag(tag, projectId),
            brand: isRecord(profile.brand) ? profile.brand : undefined,
            actions: Array.isArray(props?.actions) ? props.actions : [],
            locales: stringList(props?.locales),
            navLinks: stringList(props?.navLinks),
            heightPx: typeof profile.heightPx === 'number' ? profile.heightPx : undefined,
        };
    });
}
/**
 * Makes a profile the one the shell boots. Only `activeProfile` moves — the renderer, brand and
 * props of each profile are already in place, which is the whole point of having variants.
 */
export function activateHeaderProfile(config, profileName) {
    if (!isRecord(config))
        throw new Error('l5/config.json not found or not an object');
    const name = readString(profileName);
    if (!name)
        throw new Error('activate needs a profile name');
    const next = clone(config);
    const header = next.clientShell?.regions?.header;
    if (!header?.profiles?.[name])
        throw new Error(`there is no header profile "${name}" to activate`);
    header.activeProfile = name;
    return next;
}
/**
 * Writes the brand TEXTS of one header profile: title and subtitle, nothing else.
 *
 * The brand is one object in the config (`title`, `subtitle`, `logoSvg`) and this is the single
 * writer of its texts — the mark has its own path (`applyLogoToBrand`), and these two must never
 * both claim the title, or one silently undoes the other.
 *
 * @param subtitle - Empty REMOVES the key: the band renders a subtitle only when there is one, and
 * an empty string would reserve the space for nothing.
 * @throws When the title is empty (`renderBrand()` with no title is a band with no identity) or the
 * profile does not exist.
 */
export function applyBrandTexts(config, options) {
    if (!isRecord(config))
        throw new Error('l5/config.json not found or not an object');
    const title = readString(options.title);
    if (!title)
        throw new Error('the brand needs a title — the band renders it as its identity');
    const next = clone(config);
    const header = next.clientShell?.regions?.header;
    if (!header?.profiles)
        throw new Error('no header region in l5/config.json');
    const profileName = readString(options.profileName) || header.activeProfile || DEFAULT_HEADER_PROFILE;
    const profile = header.profiles[profileName];
    if (!profile) {
        throw new Error(`header profile "${profileName}" does not exist (available: ${Object.keys(header.profiles).join(', ') || 'none'})`);
    }
    const brand = (isRecord(profile.brand) ? profile.brand : (profile.brand = {}));
    brand.title = title;
    const subtitle = readString(options.subtitle);
    if (subtitle)
        brand.subtitle = subtitle;
    else
        delete brand.subtitle;
    return { config: next, profileName };
}
export function emptyHeaderForm() {
    return {
        brief: '',
        actions: [],
        navLinks: [],
        locales: [],
        logo: 'keep',
        logoStyle: '',
        logoBrief: '',
        profileName: '',
        variant: '',
    };
}
/**
 * Pre-fills the form from what the project already has, so a regeneration is a small edit.
 *
 * @param languages - Every language the project declares; used as the default selection, since a
 * header with no `props.locales` speaks all of them.
 */
export function formFromProfile(view, languages = []) {
    const form = emptyHeaderForm();
    form.locales = [...languages];
    if (!view)
        return form;
    // The brand is NOT copied into the form: it is edited in its own section, straight into the config.
    form.actions = [...view.actions];
    form.navLinks = [...view.navLinks];
    if (view.locales.length)
        form.locales = view.locales.filter((locale) => !languages.length || languages.includes(locale));
    form.profileName = view.profileName;
    form.variant = view.variant ?? '';
    return form;
}
/** Languages the project declares (`l5/project.json > languages`). */
export function readProjectLanguages(projectConfig) {
    if (!isRecord(projectConfig) || !Array.isArray(projectConfig.languages))
        return [];
    return projectConfig.languages
        .filter(isRecord)
        .map((entry) => ({ code: readString(entry.language), name: readString(entry.name) }))
        .filter((entry) => Boolean(entry.code));
}
/** How many design-system themes the project declares — the switcher hides itself below two. */
export function countProjectDesignSystems(projectConfig) {
    if (!isRecord(projectConfig) || !Array.isArray(projectConfig.designSystems))
        return 0;
    return projectConfig.designSystems.filter(isRecord).length;
}
/**
 * Routes of the app, from `l5/config.json > projects[].modules[].navigation` — the same list the
 * shell hands the aside, and the only hrefs a header is allowed to link.
 */
export function readProjectRoutes(config, projectId) {
    if (!isRecord(config) || !isRecord(config.projects))
        return [];
    const projects = config.projects;
    const owners = isRecord(projects[String(projectId)]) ? [projects[String(projectId)]] : Object.values(projects);
    const routes = [];
    const seen = new Set();
    for (const owner of owners) {
        const modules = isRecord(owner) && Array.isArray(owner.modules) ? owner.modules : [];
        for (const module of modules) {
            const navigation = isRecord(module) && Array.isArray(module.navigation) ? module.navigation : [];
            for (const entry of navigation) {
                if (!isRecord(entry))
                    continue;
                const href = readString(entry.href);
                const label = readString(entry.label) || href;
                if (!href || seen.has(href))
                    continue;
                seen.add(href);
                routes.push({ href, label, description: readString(entry.description) || undefined });
            }
        }
    }
    return routes;
}
/**
 * Builds the request the agent receives. Always a DRAFT (`commit: false`): the plugin previews first
 * and writes only when the reviewer accepts — that is the whole point of the screen.
 */
/**
 * @param brand - The profile's brand, so the model knows the title it has to lay out. It comes from
 * the CONFIG (the Brand section owns it), never from a field typed twice.
 */
export function buildHeaderRequest(projectId, form, requestId, brand) {
    const brandTitle = readString(brand?.title);
    const raw = {
        projectId,
        brief: readString(form.brief) || undefined,
        actions: form.actions,
        // A list of hrefs, not a flag: the agent links exactly these and validates against them.
        navLinks: [...form.navLinks],
        locales: [...form.locales],
        logo: form.logo,
        logoStyle: readString(form.logoStyle) || undefined,
        logoBrief: readString(form.logoBrief) || undefined,
        profileName: readString(form.profileName) || undefined,
        variant: readString(form.variant) || undefined,
        requestId,
        commit: false,
    };
    if (brandTitle) {
        raw.brand = { title: brandTitle, subtitle: readString(brand?.subtitle) || undefined };
    }
    // normalizeHeaderRequest is the same gate the agent applies, so the plugin fails fast and locally
    // (missing brief AND brand, unknown action, …) instead of after a round trip.
    return normalizeHeaderRequest(raw);
}
/** The one-shot draft the agent parked, when it is the one this screen asked for. */
export function readHeaderDraft(projectConfig, requestId) {
    if (!isRecord(projectConfig))
        return undefined;
    const draft = projectConfig.headerDraft;
    if (!isRecord(draft) || !readString(draft.source))
        return undefined;
    if (requestId && readString(draft.requestId) !== requestId)
        return undefined;
    return {
        requestId: readString(draft.requestId),
        source: readString(draft.source),
        parts: isRecord(draft.parts) ? draft.parts : undefined,
        notes: readString(draft.notes) || undefined,
        profileName: readString(draft.profileName) || undefined,
        createdAt: readString(draft.createdAt) || undefined,
    };
}
export function readLogoDraft(projectConfig, requestId) {
    if (!isRecord(projectConfig))
        return undefined;
    const draft = projectConfig.logoDraft;
    if (!isRecord(draft) || !readString(draft.svg))
        return undefined;
    if (requestId && readString(draft.requestId) !== requestId)
        return undefined;
    return { svg: readString(draft.svg), notes: readString(draft.notes) || undefined };
}
/** Drops a consumed draft. Returns a copy — the caller decides when to persist. */
export function clearDraft(projectConfig, key) {
    const next = isRecord(projectConfig) ? clone(projectConfig) : {};
    delete next[key];
    return next;
}
/**
 * Everything the "Apply" button writes, computed in one place: the real source, the repointed profile,
 * the consumed draft and the rollback slot.
 *
 * The backup is taken from the profile as it is NOW plus the source currently on disk — that pair is
 * what "go back to the previous header" needs, and regenerating would not reproduce it.
 */
export function applyHeaderDraft(input, buildSource) {
    const view = readHeaderProfileView(input.config, input.projectId, input.form.profileName);
    const paths = headerPaths(input.projectId, { variant: input.form.variant || undefined });
    const written = pointHeaderProfileAtProject(input.config, {
        paths,
        // No brand here on purpose: absent = keep. The Brand section owns it, and a regeneration must
        // not cost the app its identity.
        actions: input.form.actions,
        // Both are DATA in the profile: changing which links or locales the header offers is a config
        // edit afterwards, with no regeneration.
        navLinks: input.form.navLinks,
        locales: input.form.locales,
        // A variant does not go on the air by being written: it is activated on purpose, from the list.
        activate: !readString(input.form.variant),
        profileName: readString(input.form.profileName) || undefined,
        dropLogo: input.form.logo === 'none',
    });
    const projectConfig = clearDraft(input.projectConfig, 'headerDraft');
    // Only worth a backup when there IS a previous project header to go back to.
    if (view?.isProjectHeader && readString(input.previousSource)) {
        const previousProfile = input.config.clientShell
            ?.regions?.header?.profiles?.[view.profileName];
        // One slot PER PROFILE: with several headers in the project, a single slot would let a variant's
        // rollback overwrite the default header's.
        const slots = isRecord(projectConfig.headerBackup) ? { ...projectConfig.headerBackup } : {};
        slots[view.profileName] = {
            source: readString(input.previousSource),
            profile: previousProfile ? clone(previousProfile) : undefined,
            profileName: view.profileName,
            at: input.at,
        };
        projectConfig.headerBackup = slots;
    }
    return {
        paths,
        source: buildSource(input.parts),
        config: written.config,
        projectConfig,
        profileName: written.profileName,
    };
}
/**
 * The rollback slot of one profile.
 *
 * The slot used to be a single object for the whole project; it is now keyed by profile name. Both
 * shapes are read (the old one answers for the profile it recorded), so a project mid-flight does not
 * lose its rollback.
 *
 * @param profileName - Whose slot to read; the default header's when omitted.
 */
export function readHeaderBackup(projectConfig, profileName) {
    if (!isRecord(projectConfig))
        return undefined;
    const raw = projectConfig.headerBackup;
    if (!isRecord(raw))
        return undefined;
    const wanted = readString(profileName);
    // Legacy single slot: it carries its own profileName.
    const legacy = readString(raw.source) && isRecord(raw.profile) ? raw : undefined;
    const entry = legacy
        ? ((!wanted || readString(legacy.profileName) === wanted || (!readString(legacy.profileName) && wanted === DEFAULT_HEADER_PROFILE))
            ? legacy
            : undefined)
        : (isRecord(raw[wanted || DEFAULT_HEADER_PROFILE]) ? raw[wanted || DEFAULT_HEADER_PROFILE] : undefined);
    if (!entry || !readString(entry.source) || !isRecord(entry.profile))
        return undefined;
    return {
        source: readString(entry.source),
        profile: entry.profile,
        profileName: readString(entry.profileName) || wanted || DEFAULT_HEADER_PROFILE,
        at: readString(entry.at),
    };
}
/** Puts the previous header back: the source file AND the profile block it came with. */
export function restoreHeaderBackup(projectId, config, projectConfig, profileName) {
    const backup = readHeaderBackup(projectConfig, profileName);
    if (!backup)
        throw new Error('there is no previous header to restore');
    if (!isRecord(config))
        throw new Error('l5/config.json not found or not an object');
    const next = clone(config);
    const clientShell = (isRecord(next.clientShell) ? next.clientShell : (next.clientShell = {}));
    const regions = (isRecord(clientShell.regions) ? clientShell.regions : (clientShell.regions = {}));
    const header = regions.header ?? (regions.header = { activeProfile: backup.profileName, profiles: {} });
    if (!isRecord(header.profiles))
        header.profiles = {};
    header.profiles[backup.profileName] = clone(backup.profile);
    header.activeProfile = backup.profileName;
    const nextProject = isRecord(projectConfig) ? clone(projectConfig) : {};
    // Restoring CONSUMES the slot of this profile, so a second "go back" does not resurrect an older
    // one — the other profiles keep theirs.
    const slots = nextProject.headerBackup;
    if (isRecord(slots) && !readString(slots.source)) {
        delete slots[backup.profileName];
        if (Object.keys(slots).length === 0)
            delete nextProject.headerBackup;
    }
    else {
        delete nextProject.headerBackup;
    }
    return {
        // The file to rewrite is the one THIS profile points at: a variant restores its own file.
        paths: headerPaths(projectId, { variant: variantFromTag(readString(backup.profile.renderer?.tag), projectId) }),
        source: backup.source,
        config: next,
        projectConfig: nextProject,
        profileName: backup.profileName,
    };
}
