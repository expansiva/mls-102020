/// <mls fileReference="_102020_/l2/aura/plugins/selectLayout.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getAuraState } from '/_102020_/l2/aura/helpers/auraState.js';
import { getConfigProject, updateConfigProject } from '/_102027_/l2/libProjectConfig.js';
import '/_102020_/l2/aura/plugins/navHeader.js';
import '/_102020_/l2/aura/plugins/selectLayoutRules.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'UX · User Experience',
    allTitle: 'All Layouts',
    desc: 'The layout defines the structural arrangement of UI elements on the page.',
    standard: 'Standard',
    standardDesc: 'Classic top-header with full-width content area.',
    compact: 'Compact',
    compactDesc: 'Condensed layout optimized for dense information display.',
    tabs: 'Tabs',
    tabsDesc: 'Tab-based navigation separating content into distinct sections.',
    sidebar: 'Sidebar',
    sidebarDesc: 'Persistent side navigation alongside a main content area.',
    bento: 'Bento Grids',
    bentoDesc: 'Mosaic-style grid of cards with variable sizes and positions.',
    adding: 'Adding…',
    addTitle: 'New Layout',
    addDesc: 'Create a new layout: pick a base skill (or custom) and configure its component rules.',
    chooseSkill: 'Layout skill',
    custom: 'Custom',
    nameLabel: 'Name',
    skillLabel: 'Skill path',
    namePlaceholder: 'e.g. compactSidebar',
    skillPlaceholder: '_102020_/l2/skills/layout/…',
    saveLayout: 'Save layout',
    saveError: 'Could not save the layout.',
    useMoleculesLabel: 'Use molecules',
    useMoleculesHint: 'When off, pages of this layout get only the configured layout rules (no web components).',
};
const messages = {
    en: message_en,
    pt: {
        title: 'UX · User Experience',
        allTitle: 'Todos os Layouts',
        desc: 'O layout define o arranjo estrutural dos elementos na página.',
        standard: 'Padrão',
        standardDesc: 'Cabeçalho superior com área de conteúdo em largura total.',
        compact: 'Compacto',
        compactDesc: 'Layout condensado otimizado para exibição densa de informações.',
        tabs: 'Abas',
        tabsDesc: 'Navegação por abas que separa o conteúdo em seções distintas.',
        sidebar: 'Barra Lateral',
        sidebarDesc: 'Navegação lateral persistente ao lado de uma área de conteúdo principal.',
        bento: 'Bento Grids',
        bentoDesc: 'Grade mosaico de cards com tamanhos e posições variáveis.',
        adding: 'Adicionando…',
        addTitle: 'Novo Layout',
        addDesc: 'Crie um novo layout: escolha uma skill base (ou custom) e configure as rules de componentes.',
        chooseSkill: 'Skill do layout',
        custom: 'Custom',
        nameLabel: 'Nome',
        skillLabel: 'Caminho da skill',
        namePlaceholder: 'ex.: compactSidebar',
        skillPlaceholder: '_102020_/l2/skills/layout/…',
        saveLayout: 'Salvar layout',
        saveError: 'Não foi possível salvar o layout.',
        useMoleculesLabel: 'Usar moléculas',
        useMoleculesHint: 'Quando desligado, as páginas deste layout recebem apenas as regras de layout configuradas (sem web components).',
    },
    es: {
        title: 'UX · User Experience',
        allTitle: 'Todos los Layouts',
        desc: 'El layout define la disposición estructural de los elementos en la página.',
        standard: 'Estándar',
        standardDesc: 'Cabecera superior con área de contenido de ancho completo.',
        compact: 'Compacto',
        compactDesc: 'Layout condensado optimizado para mostrar información densa.',
        tabs: 'Pestañas',
        tabsDesc: 'Navegación por pestañas que separa el contenido en secciones distintas.',
        sidebar: 'Barra Lateral',
        sidebarDesc: 'Navegación lateral persistente junto a un área de contenido principal.',
        bento: 'Bento Grids',
        bentoDesc: 'Cuadrícula mosaico de tarjetas con tamaños y posiciones variables.',
        adding: 'Agregando…',
        addTitle: 'Nuevo Layout',
        addDesc: 'Cree un nuevo layout: elija una skill base (o custom) y configure sus reglas de componentes.',
        chooseSkill: 'Skill del layout',
        custom: 'Custom',
        nameLabel: 'Nombre',
        skillLabel: 'Ruta de la skill',
        namePlaceholder: 'ej.: compactSidebar',
        skillPlaceholder: '_102020_/l2/skills/layout/…',
        saveLayout: 'Guardar layout',
        saveError: 'No se pudo guardar el layout.',
        useMoleculesLabel: 'Usar moléculas',
        useMoleculesHint: 'Cuando está desactivado, las páginas de este layout reciben solo las reglas de layout configuradas (sin web components).',
    },
};
// Presets for the "Add layout" form: each sets the layout name + its render skill.
const LAYOUT_PRESETS = [
    { name: 'standard', skill: '_102020_/l2/aura/agentImplementGenome/skills/layout/genCfePageLayoutStandard.ts' },
    { name: 'compact', skill: '_102020_/l2/aura/agentImplementGenome/skills/layout/genCfePageLayoutCompact.ts' },
    { name: 'sidebar', skill: '_102020_/l2/aura/agentImplementGenome/skills/layout/genCfePageLayoutSidebar.ts' },
    { name: 'tabs', skill: '_102020_/l2/aura/agentImplementGenome/skills/layout/genCfePageLayoutTabs.ts' },
    { name: 'bento', skill: '_102020_/l2/aura/agentImplementGenome/skills/layout/genCfePageLayoutBento.ts' },
];
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectLayout = class PluginSelectLayout extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = 0;
        this._layoutOptions = [];
        // ─── "Add layout" form state ──────────────────────────────────────
        this._addPreset = null; // preset name | 'custom' | null
        this._addName = '';
        this._addSkill = '';
        this._addRules = {};
        this._addUseMolecules = true;
        this._addSaving = false;
        this._addError = '';
    }
    /** The "+ Add layout" knob slot value (highest layout index + 1). */
    get _addValue() {
        return this._layoutOptions.reduce((m, o) => Math.max(m, o.value), 0) + 1;
    }
    connectedCallback() {
        super.connectedCallback();
        this._loadProjectConfig();
    }
    async _loadProjectConfig() {
        const project = getAuraState().actualProject;
        if (!project)
            return;
        try {
            const config = await getConfigProject(project);
            const layoutsMap = config?.layouts ?? {};
            this._layoutOptions = Object.entries(layoutsMap)
                .map(([k, v]) => ({ value: Number(k), name: v.name, skill: v.skill, useMolecules: v.useMolecules !== false }))
                .sort((a, b) => a.value - b.value);
        }
        catch { /* no project config */ }
        // @ts-ignore
        this.requestUpdate();
    }
    get msg() {
        return messages[this.getMessageKey(messages)];
    }
    _getLayoutLabel(name) {
        return this.msg[name] ?? name;
    }
    _getLayoutDesc(name) {
        return this.msg[`${name}Desc`] ?? '';
    }
    createRenderRoot() { return this; }
    render() {
        const addValue = this._addValue;
        const max = addValue; // last navigable slot is "+ Add layout"
        const v = this.value ?? 0;
        const isAll = v === 0;
        const isAdd = v === addValue;
        const selectedOption = this._layoutOptions.find(o => o.value === v);
        if (isAll) {
            return html `
                <div class="flex flex-col gap-3">
                    <aura--plugins--nav-header-102020
                        .fixedLabel=${this.msg.title}
                        .itemName=${this.msg.allTitle}
                        .desc=${this.msg.desc}
                        .value=${0}
                        .min=${0}
                        .max=${max}
                        @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                    ></aura--plugins--nav-header-102020>

                    <div class="grid grid-cols-2 gap-2">
                        ${this._layoutOptions.map(opt => this._renderLayoutCard(opt, false))}
                    </div>
                </div>
            `;
        }
        if (isAdd) {
            return html `
                <div class="flex flex-col gap-3">
                    <aura--plugins--nav-header-102020
                        .fixedLabel=${this.msg.title}
                        .itemName=${this.msg.addTitle}
                        .desc=${this.msg.addDesc}
                        .value=${addValue}
                        .min=${0}
                        .max=${max}
                        @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                    ></aura--plugins--nav-header-102020>
                    ${this._renderAddForm()}
                </div>
            `;
        }
        if (!selectedOption)
            return nothing;
        return html `
            <div class="flex flex-col gap-3">
                <aura--plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${this._getLayoutLabel(selectedOption.name)}
                    .desc=${this.msg.desc}
                    .value=${v}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></aura--plugins--nav-header-102020>

                ${this._renderLayoutCard(selectedOption, true)}
                ${this._renderUseMoleculesToggle(selectedOption)}
            </div>
        `;
    }
    // Per-layout "Use molecules" flag: persisted in config.layouts[value].useMolecules.
    // The genome flow reads it there — this is the single source of truth (no global state).
    _renderUseMoleculesToggle(opt) {
        return html `
            <label class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300 cursor-pointer" title=${this.msg.useMoleculesHint}>
                <input
                    type="checkbox"
                    class="cursor-pointer"
                    .checked=${opt.useMolecules}
                    @change=${(e) => this._onToggleUseMolecules(opt.value, e.target.checked)}
                />
                <span>${this.msg.useMoleculesLabel}</span>
            </label>
        `;
    }
    async _onToggleUseMolecules(value, checked) {
        const projectId = getAuraState().actualProject;
        if (projectId == null)
            return;
        try {
            const config = await getConfigProject(projectId);
            const layout = config?.layouts?.[String(value)];
            if (!layout)
                return;
            layout.useMolecules = checked;
            await updateConfigProject(projectId, config);
            await this._loadProjectConfig();
        }
        catch { /* leave the UI as-is on failure */ }
    }
    _renderLayoutCard(opt, isSelected) {
        const label = this._getLayoutLabel(opt.name);
        const desc = this._getLayoutDesc(opt.name);
        return html `
            <div
                class="
                    rounded-xl border p-2.5 transition-all flex flex-col gap-2 cursor-pointer
                    ${isSelected
            ? 'border-indigo-400 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 shadow-sm'
            : 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-gray-300 dark:hover:border-gray-700'}
                "
                @click=${() => this._dispatchSelect(opt.value)}
            >
                <div class="w-full aspect-[4/3] rounded-lg overflow-hidden
                    ${isSelected ? 'bg-indigo-100 dark:bg-indigo-900/30' : 'bg-gray-100 dark:bg-gray-800'}
                ">
                    ${this._renderDiagram(opt.name, isSelected)}
                </div>
                <div class="flex flex-col gap-0.5">
                    <div class="flex items-center gap-1.5">
                        ${isSelected ? html `<div class="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400 shrink-0"></div>` : nothing}
                        <span class="text-xs font-semibold
                            ${isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-700 dark:text-gray-200'}
                        ">${label}</span>
                    </div>
                    <span class="text-[10px] text-gray-400 dark:text-gray-500 leading-snug">${desc}</span>
                </div>
            </div>
        `;
    }
    _renderDiagram(name, selected) {
        const header = selected ? '#818cf8' : '#9ca3af';
        const content = selected ? '#c7d2fe' : '#e5e7eb';
        const sidebar = selected ? '#a5b4fc' : '#d1d5db';
        const darkHeader = selected ? '#4f46e5' : '#4b5563';
        const darkContent = selected ? '#3730a3' : '#374151';
        const darkSidebar = selected ? '#4338ca' : '#374151';
        if (name === 'standard')
            return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4" width="72" height="12" rx="2" fill="${header}" class="dark:hidden"/>
                <rect x="4" y="4" width="72" height="12" rx="2" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="4" y="20" width="72" height="36" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="20" width="72" height="36" rx="2" fill="${darkContent}" class="hidden dark:block"/>
            </svg>`;
        if (name === 'compact')
            return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4" width="72" height="8" rx="2" fill="${header}" class="dark:hidden"/>
                <rect x="4" y="4" width="72" height="8" rx="2" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="4" y="15" width="72" height="6" rx="1" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="15" width="72" height="6" rx="1" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="24" width="72" height="6" rx="1" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="24" width="72" height="6" rx="1" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="33" width="72" height="6" rx="1" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="33" width="72" height="6" rx="1" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="42" width="72" height="6" rx="1" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="42" width="72" height="6" rx="1" fill="${darkContent}" class="hidden dark:block"/>
            </svg>`;
        if (name === 'tabs')
            return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4" width="16" height="12" rx="2" fill="${header}" class="dark:hidden"/>
                <rect x="4" y="4" width="16" height="12" rx="2" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="22" y="4" width="16" height="12" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="22" y="4" width="16" height="12" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="40" y="4" width="16" height="12" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="40" y="4" width="16" height="12" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="12" width="72" height="44" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="12" width="72" height="44" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="12" width="16" height="4" rx="0" fill="${header}" class="dark:hidden"/>
                <rect x="4" y="12" width="16" height="4" rx="0" fill="${darkHeader}" class="hidden dark:block"/>
            </svg>`;
        if (name === 'sidebar')
            return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4" width="18" height="52" rx="2" fill="${sidebar}" class="dark:hidden"/>
                <rect x="4" y="4" width="18" height="52" rx="2" fill="${darkSidebar}" class="hidden dark:block"/>
                <rect x="26" y="4" width="50" height="52" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="26" y="4" width="50" height="52" rx="2" fill="${darkContent}" class="hidden dark:block"/>
            </svg>`;
        if (name === 'bento')
            return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4"  width="44" height="26" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="4"  width="44" height="26" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="52" y="4" width="24" height="12" rx="2" fill="${header}" class="dark:hidden"/>
                <rect x="52" y="4" width="24" height="12" rx="2" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="52" y="18" width="24" height="12" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="52" y="18" width="24" height="12" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="4" y="34"  width="24" height="22" rx="2" fill="${header}" class="dark:hidden"/>
                <rect x="4" y="34"  width="24" height="22" rx="2" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="32" y="34" width="44" height="22" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="32" y="34" width="44" height="22" rx="2" fill="${darkContent}" class="hidden dark:block"/>
            </svg>`;
        return html `
            <svg viewBox="0 0 80 60" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="4" y="4" width="72" height="52" rx="2" fill="${content}" class="dark:hidden"/>
                <rect x="4" y="4" width="72" height="52" rx="2" fill="${darkContent}" class="hidden dark:block"/>
                <rect x="16" y="20" width="48" height="4" rx="1" fill="${header}" class="dark:hidden"/>
                <rect x="16" y="20" width="48" height="4" rx="1" fill="${darkHeader}" class="hidden dark:block"/>
                <rect x="24" y="28" width="32" height="4" rx="1" fill="${header}" class="dark:hidden"/>
                <rect x="24" y="28" width="32" height="4" rx="1" fill="${darkHeader}" class="hidden dark:block"/>
            </svg>`;
    }
    // ─── "Add layout" form ────────────────────────────────────────────
    _renderAddForm() {
        const projectId = getAuraState().actualProject;
        const isCustom = this._addPreset === 'custom';
        const hasChoice = this._addPreset != null;
        const canSave = !!this._addName.trim() && !!this._addSkill.trim() && !this._addSaving;
        return html `
            <div class="flex flex-col gap-4">
                <!-- Skill preset picker -->
                <div class="flex flex-col gap-1.5">
                    <span class="text-xs font-semibold text-gray-600 dark:text-gray-300">${this.msg.chooseSkill}</span>
                    <div class="flex flex-wrap gap-1.5">
                        ${LAYOUT_PRESETS.map(p => this._renderPresetChip(p.name, p.skill, this._getLayoutLabel(p.name)))}
                        ${this._renderPresetChip('custom', '', this.msg.custom)}
                    </div>
                </div>

                <!-- Name + skill path (editable in custom; shown read-only-ish for presets) -->
                ${hasChoice ? html `
                    <div class="flex flex-col gap-2">
                        <label class="flex flex-col gap-1">
                            <span class="text-xs font-medium text-gray-500 dark:text-gray-400">${this.msg.nameLabel}</span>
                            <input
                                type="text"
                                class="text-sm px-2 py-1 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100"
                                .value=${this._addName}
                                placeholder=${this.msg.namePlaceholder}
                                ?readonly=${!isCustom}
                                @input=${(e) => { this._addName = e.target.value; }}
                            />
                        </label>
                        <label class="flex flex-col gap-1">
                            <span class="text-xs font-medium text-gray-500 dark:text-gray-400">${this.msg.skillLabel}</span>
                            <input
                                type="text"
                                class="text-xs px-2 py-1 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-mono"
                                .value=${this._addSkill}
                                placeholder=${this.msg.skillPlaceholder}
                                ?readonly=${!isCustom}
                                @input=${(e) => { this._addSkill = e.target.value; }}
                            />
                        </label>
                    </div>
                ` : nothing}

                <!-- Component rules editor (draft mode) -->
                ${hasChoice && projectId != null ? html `
                    <aura--plugins--select-layout-rules-102020
                        .projectId=${projectId}
                        .draft=${true}
                        .initialRules=${this._addRules}
                        @rules-changed=${this._onAddRulesChanged}
                    ></aura--plugins--select-layout-rules-102020>
                ` : nothing}

                <!-- Use molecules (per-layout flag) -->
                ${hasChoice ? html `
                    <label class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300 cursor-pointer" title=${this.msg.useMoleculesHint}>
                        <input
                            type="checkbox"
                            class="cursor-pointer"
                            .checked=${this._addUseMolecules}
                            @change=${(e) => { this._addUseMolecules = e.target.checked; }}
                        />
                        <span>${this.msg.useMoleculesLabel}</span>
                    </label>
                ` : nothing}

                <!-- Save -->
                ${hasChoice ? html `
                    <div class="flex flex-col gap-2">
                        <button
                            class="
                                self-start text-sm px-3 py-1.5 rounded
                                bg-indigo-500 dark:bg-indigo-600 text-white
                                hover:bg-indigo-600 dark:hover:bg-indigo-500
                                disabled:opacity-50 disabled:cursor-not-allowed
                                transition-colors cursor-pointer
                            "
                            ?disabled=${!canSave}
                            @click=${this._onSaveNewLayout}
                        >
                            ${this._addSaving ? this.msg.adding : this.msg.saveLayout}
                        </button>
                        ${this._addError ? html `
                            <div class="rounded-md border border-red-200 dark:border-red-800/40 bg-red-50 dark:bg-red-900/10 px-2.5 py-1.5">
                                <span class="text-xs text-red-600 dark:text-red-400 font-mono">${this._addError}</span>
                            </div>
                        ` : nothing}
                    </div>
                ` : nothing}
            </div>
        `;
    }
    _renderPresetChip(name, skill, label) {
        const active = this._addPreset === name;
        return html `
            <button
                class="
                    text-xs px-2.5 py-1 rounded-full border transition-colors cursor-pointer
                    ${active
            ? 'border-indigo-400 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300'
            : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'}
                "
                @click=${() => this._selectPreset(name, skill)}
            >${label}</button>
        `;
    }
    _selectPreset(name, skill) {
        this._addPreset = name;
        this._addError = '';
        if (name === 'custom') {
            this._addName = '';
            this._addSkill = '';
        }
        else {
            this._addName = name;
            this._addSkill = skill;
        }
    }
    _onAddRulesChanged(e) {
        this._addRules = { ...(e.detail?.rules ?? {}) };
    }
    async _onSaveNewLayout() {
        const projectId = getAuraState().actualProject;
        if (projectId == null)
            return;
        const name = this._addName.trim();
        const skill = this._addSkill.trim();
        if (!name || !skill)
            return;
        this._addSaving = true;
        this._addError = '';
        try {
            const config = await getConfigProject(projectId);
            if (!config)
                throw new Error('project config not found');
            const current = config.layouts;
            const layouts = (current && typeof current === 'object' && !Array.isArray(current)) ? current : {};
            const newIndex = this._addValue;
            layouts[newIndex] = { name, skill, rules: { ...this._addRules }, useMolecules: this._addUseMolecules };
            config.layouts = layouts;
            await updateConfigProject(projectId, config);
            // Refresh options and notify the host so it rebuilds the layout knob
            // (new entry + fresh "+ Add" slot) and selects the freshly created layout.
            await this._loadProjectConfig();
            this._resetAddForm();
            this.dispatchEvent(new CustomEvent('layout-created', {
                detail: { value: newIndex },
                bubbles: true,
                composed: true,
            }));
        }
        catch (err) {
            this._addError = `${this.msg.saveError} ${err?.message ?? ''}`.trim();
        }
        finally {
            this._addSaving = false;
        }
    }
    _resetAddForm() {
        this._addPreset = null;
        this._addName = '';
        this._addSkill = '';
        this._addRules = {};
        this._addUseMolecules = true;
        this._addError = '';
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-layout', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectLayout.prototype, "value", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_layoutOptions", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addPreset", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addName", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addSkill", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addRules", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addUseMolecules", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addSaving", void 0);
__decorate([
    state()
], PluginSelectLayout.prototype, "_addError", void 0);
PluginSelectLayout = __decorate([
    customElement('aura--plugins--select-layout-102020')
], PluginSelectLayout);
export { PluginSelectLayout };
