/// <mls fileReference="_102020_/l2/aura/agentManageHeader/agentGenerateLogo.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getConfigProject, updateConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { mkCompleted, mkFail } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { skill as logoContract } from '/_102020_/l2/aura/agentManageHeader/skills/logoContract.js';
import { applyLogoToBrand, buildGenerateLogoHumanPrompt, normalizeLogoRequest, readBrandTitle, sanitizeGeneratedLogo, } from '/_102020_/l2/aura/agentManageHeader/helpers/generateLogoCore.js';
export function createAgent() {
    return {
        agentName: 'agentGenerateLogo',
        agentProject: 102020,
        agentFolder: 'aura/agentManageHeader',
        agentDescription: "Draw the project's brand mark as inline SVG for the header profile",
        visibility: 'private',
        beforePromptImplicit,
        afterPromptStep,
    };
}
/** The composed client config (l5/config.json) — where the header profile and its brand live. */
async function readClientConfig(projectId) {
    const fileInfo = { project: projectId, level: 5, folder: '', shortName: 'config', extension: '.json' };
    const key = mls.stor.getKeyToFile(fileInfo);
    const storFile = mls.stor.files[key];
    if (!storFile)
        throw new Error(`l5/config.json not found for project ${projectId}`);
    const raw = await storFile.getContent();
    return { storFile, config: typeof raw === 'string' && raw.trim() ? JSON.parse(raw) : undefined };
}
// ─── before: resolve the brand + one generation prompt ───────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    let req;
    try {
        req = normalizeLogoRequest(JSON.parse(userPrompt));
    }
    catch (error) {
        throw new Error(`(${agent.agentName}) ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!req.brandTitle) {
        try {
            const { config } = await readClientConfig(req.projectId);
            req.brandTitle = readBrandTitle(config, req.profileName) || undefined;
        }
        catch (error) {
            console.warn('[agentGenerateLogo] could not read the configured brand title', error);
        }
    }
    if (!req.brandTitle && !req.brief) {
        throw new Error(`(${agent.agentName}) no brandTitle in the request nor in the header profile — pass { brandTitle } or a brief`);
    }
    console.info(`[agentGenerateLogo] ▶ project=${req.projectId} brand="${req.brandTitle ?? '—'}" style=${req.style} commit=${String(req.commit)}`);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: buildGenerateLogoHumanPrompt(req) },
            ],
            taskTitle: req.brandTitle ? `Generate logo · ${req.brandTitle}` : 'Generate logo',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            // longMemory is string-only → the request round-trips JSON-encoded to afterPromptStep.
            longTermMemory: { request: JSON.stringify(req) },
        },
    };
    return [addMessageAI];
}
// ─── after: validate + write ─────────────────────────────────────────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (payload?.type !== 'flexible' || !payload.result)
            throw new Error(`invalid payload: ${JSON.stringify(payload)}`);
        const lm = (context.task?.iaCompressed?.longMemory || {});
        const req = JSON.parse(lm['request'] || '{}');
        if (!req.projectId)
            throw new Error('missing request in longMemory');
        const sanitized = sanitizeGeneratedLogo(payload.result);
        if (!sanitized.ok || !sanitized.value)
            throw new Error(`LLM output rejected: ${sanitized.error || 'invalid result'}`);
        const { svg, notes } = sanitized.value;
        if (!context.isTest) {
            if (req.commit)
                await writeLogoToConfig(req, svg);
            else
                await persistDraft(req, svg, notes);
        }
        console.info(`[agentGenerateLogo] ✓ ${req.commit ? 'wrote' : 'drafted'} mark for project ${req.projectId} (${svg.length} bytes)`);
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        const msg = `[agentGenerateLogo] ${error instanceof Error ? error.message : String(error)}`;
        console.error('✗', msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
/** Writes `brand.logoSvg` into the header profile the shell boots with. */
async function writeLogoToConfig(req, svg) {
    const { storFile, config } = await readClientConfig(req.projectId);
    const written = applyLogoToBrand(config, {
        svg,
        profileName: req.profileName,
        brandTitle: req.brandTitle,
    });
    if (storFile.status !== 'renamed' && storFile.status !== 'new')
        storFile.status = 'changed';
    storFile.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(storFile, {
        contentType: 'string',
        content: `${JSON.stringify(written.config, null, 2)}\n`,
    });
    console.info(`[agentGenerateLogo] brand of header profile "${written.profileName}" ${written.replaced ? 'replaced its mark' : 'got a mark'}`);
}
/** One-shot channel to a reviewer: config.logoDraft (never read by the runtime). */
async function persistDraft(req, svg, notes) {
    const config = await getConfigProject(req.projectId);
    if (!config)
        throw new Error('project config not found');
    config.logoDraft = {
        requestId: req.requestId ?? '',
        brandTitle: req.brandTitle ?? '',
        style: req.style ?? 'monogram',
        svg,
        notes: notes ?? '',
        createdAt: new Date().toISOString(),
    };
    await updateConfigProject(req.projectId, config);
}
// ─── prompt ──────────────────────────────────────────────────────────────────
const system1 = `
<!-- modelType: design -->

You must return ONLY a valid JSON object. No preamble, no markdown fences. Start with { and end with }

You are a brand designer who writes SVG by hand. You draw ONE small monochrome mark for an app, and
you return its markup — nothing else. Restraint is the whole job: the mark lives at 28px next to the
brand name, so a shape that reads instantly beats a clever illustration.

${logoContract}

## Output format
export type Output = {
  type: 'flexible';
  result: {
    /** The mark: a single <svg> root, viewBox, currentColor only. */
    svg: string;
    /** One or two sentences on the choice made, in the requested language. */
    notes?: string;
  };
};
`;
//#endregion
