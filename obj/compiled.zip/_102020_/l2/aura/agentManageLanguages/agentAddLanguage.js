/// <mls fileReference="_102020_/l2/aura/agentManageLanguages/agentAddLanguage.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { skill as skilli18n } from '/_102020_/l2/skills/aura/language.js';
import { waitModelIdle } from '/_102027_/l2/libModel.js';
import { applyTranslatedI18nBlock, collectPending, extractI18nBlock, stepFileReference, } from '/_102020_/l2/aura/agentManageLanguages/helpers/addLanguageCore.js';
import { readCurrentSource, readModulePageSources } from '/_102020_/l2/aura/agentManageLanguages/helpers/moduleLanguageScan.js';
export function createAgent() {
    return {
        agentName: "agentAddLanguage",
        agentProject: 102020,
        agentFolder: "aura/agentManageLanguages",
        agentDescription: "New i18n language",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const [dataUser] = JSON.parse(userPrompt);
    const paths = await getPaths(dataUser.languages, dataUser.projectId, dataUser.moduleName, dataUser.force === true);
    if (paths.length === 0)
        throw new Error('No find files to add language');
    const inputs = [{ type: "system", content: system1.replace('{{ skillLanguage }}', skilli18n) }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Add language`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths.map((item) => JSON.stringify(item))
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    const data = JSON.parse(args);
    console.info(`===process with args: ${args}`);
    const actuali18n = await getPagei18nBlock(data.fileReference);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: `

        Add languages: ${data.languages}

        ##File Reference: ${data.fileReference}

        ## Actual i18n:
        \`\`\`typescript 
        ${actuali18n}
        \`\`\`
        
        `
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload;
    // The file comes from the step's own args; the model's echo is only a fallback.
    intents = await processOutput(context, output.result.i18n, stepFileReference(step.prompt, payload));
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function getPaths(languages, project, moduleName, force = false) {
    if (!project)
        throw new Error(`[getPaths] invalid project`);
    // Languages are per module — never translate the whole project by accident.
    if (!moduleName)
        throw new Error(`[getPaths] moduleName is required`);
    // The catalogue lives in the PAGES now (and in the organisms of a split page, which share the page
    // folders). The shared no longer emits one, so scanning it would queue nothing at all.
    const pages = await readModulePageSources(project, moduleName);
    const scan = collectPending(pages, languages.map(lang => lang.code), force);
    console.info(`[agentAddLanguage] ${moduleName}: scanned ${scan.pages + scan.noCatalogue}, queued ${scan.pending.length}, already translated ${scan.complete}, without catalogue ${scan.noCatalogue}${force ? ' (force)' : ''}`);
    return scan.pending;
}
async function getPagei18nBlock(fileReference) {
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[getPagei18nBlock] invalid file: ${fileReference}`);
    const i18nBlock = await geti18nByFile(files.ts);
    return i18nBlock;
}
async function geti18nByFile(stor) {
    // The current text (open model first), the same that processOutput applies the translation to.
    const source = await readCurrentSource(stor);
    return extractI18nBlock(source) || '';
}
async function processOutput(context, newi18n, fileReference) {
    if (context.isTest)
        return [];
    if (!fileReference)
        throw new Error('[processOutput] Invalid fileReference');
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`[processOutput] Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[processOutput] invalid file: ${fileReference}`);
    const modelTS = await files.ts.getOrCreateModel();
    if (!modelTS)
        throw new Error(`[processOutput] invalid models`);
    const source = modelTS.model.getValue();
    // Guarded: a block that lost a locale const or its parity annotation is rejected instead of written
    // over a good file, and the untranslated markers are consumed here — the translation is what clears
    // them, so this file stops being queued on the next run.
    const newValue = applyTranslatedI18nBlock(source, newi18n);
    const paramsTs = { ...fileInfo, content: newValue, versionRef: new Date().toISOString(), extension: ".ts" };
    await updateStorFile(paramsTs);
    return [];
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMolecule] Invalid storFile');
    const models = await file.getOrCreateModel();
    models.model.pushEditOperations([], [{
            range: models.model.getFullModelRange(),
            text: params.content,
        }], () => null);
    mls.editor.forceModelUpdate(models.model);
    await waitModelIdle(models);
    return models;
}
const system1 = `
<!-- modelType: translate -->

You must return ONLY a valid JSON object. No preamble, no markdown fences. Start with { and end with }

You are a translation specialist responsible for adding a new i18n language, following the established standard.

{{ skillLanguage }}

## Output format
Return exactly this JSON shape — "type" is always the literal "flexible":

{"type":"flexible","result":{"i18n":"/// **collab_i18n_start**\\n...\\n/// **collab_i18n_end**","fileReference":"<the File Reference from the prompt>"}}

- "i18n" is a JSON string holding the whole translated block, encoded ONCE by the normal JSON rules: once parsed, it must contain the block's real line breaks. Never escape twice.
- "fileReference" is copied unchanged from the prompt.
- Never answer with the TypeScript block itself, and never wrap the JSON in \`\`\`.

export type Output =
    {
        type: "flexible";
        result: Result;
    }

export type Result = {
    i18n: string,
    fileReference: string // same prompt
}
`;
//#endregion 
