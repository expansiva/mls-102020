/// <mls fileReference="_102020_/l2/aura/agentManageLanguages/agentRemoveLanguage.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { skill as skilli18n } from '/_102020_/l2/skills/aura/language.js';
import { waitModelIdle } from '/_102027_/l2/libModel.js';
import { stepFileReference, unflattenBlock } from '/_102020_/l2/aura/agentManageLanguages/helpers/addLanguageCore.js';
export function createAgent() {
    return {
        agentName: "agentRemoveLanguage",
        agentProject: 102020,
        agentFolder: "aura/agentManageLanguages",
        agentDescription: "Remove i18n language",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const [dataUser] = JSON.parse(userPrompt);
    const paths = await getPaths(dataUser.languages, dataUser.projectId, dataUser.moduleName);
    if (paths.length === 0)
        throw new Error('No find files to remove language');
    const inputs = [{ type: "system", content: system1.replace('{{ skillLanguage }}', skilli18n) }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Remove language`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths.map((item) => JSON.stringify(item))
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    const data = JSON.parse(args);
    const actuali18n = await getPagei18nBlock(data.fileReference);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: `

        Remove languages: ${data.languages}

        ##File Reference: ${data.fileReference}

        ## Actual i18n:
        \`\`\`typescript 
        ${actuali18n}
        \`\`\`
        
        `
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload;
    // The file comes from the step's own args; the model's echo is only a fallback.
    intents = await processOutput(context, output.result.i18n, stepFileReference(step.prompt, payload));
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function getPaths(languages, project, moduleName) {
    if (!project)
        throw new Error(`[getPaths] invalid project`);
    // Languages are per module — never touch the whole project by accident.
    if (!moduleName)
        throw new Error(`[getPaths] moduleName is required`);
    const sharedFolder = await getSharedFolder(project, moduleName);
    const result = [];
    const sharedFiles = Object.values(mls.stor.files).filter((f) => f.project === project &&
        f.folder === sharedFolder &&
        f.extension === '.ts');
    for (const storFile of sharedFiles) {
        const model = await storFile.getOrCreateModel();
        if (!model)
            continue;
        const source = model.model.getValue();
        const presentLangs = languages
            .filter(lang => _hasLanguageInI18nBlock(source, lang.code))
            .map(lang => lang.code);
        if (presentLangs.length === 0)
            continue;
        // @ts-ignore
        const fileReference = mls.stor.convertFileToFileReference(storFile);
        result.push({ languages: presentLangs, fileReference });
    }
    return result;
}
// Legacy modules declare skills.web.sharedPath in l2/<module>/module.js; NS2 modules have
// no module.js and follow the l2/<module>/web/shared convention (see cfeCreateShared).
async function getSharedFolder(project, moduleName) {
    try {
        const moduleConfig = await import(`/_${project}_/l2/${moduleName}/module.js`);
        const sharedPath = moduleConfig?.skills?.web?.sharedPath;
        if (sharedPath) {
            return `${sharedPath}`
                .replace(/^\/?_\d+_\/l2\//, '')
                .replace(/^\/|\/$/g, '');
        }
    }
    catch { /* no module.js — NS2 module */ }
    return `${moduleName}/web/shared`;
}
function _hasLanguageInI18nBlock(source, lang) {
    const startMarker = '/// **collab_i18n_start**';
    const endMarker = '/// **collab_i18n_end**';
    const startIdx = source.indexOf(startMarker);
    const endIdx = source.indexOf(endMarker);
    if (startIdx === -1 || endIdx === -1)
        return false;
    const i18nBlock = source.substring(startIdx, endIdx);
    const keyPatterns = [
        new RegExp(`\\b${lang}\\s*:`, 'm'),
        new RegExp(`['"]${lang}['"]\\s*:`, 'm'),
    ];
    return keyPatterns.some(pattern => pattern.test(i18nBlock));
}
async function getPagei18nBlock(fileReference) {
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[getPagei18nBlock] invalid file: ${fileReference}`);
    const i18nBlock = await geti18nByFile(files.ts);
    return i18nBlock;
}
async function geti18nByFile(stor) {
    const modelTS = await stor.getOrCreateModel();
    if (!modelTS)
        throw new Error(`[geti18nByFile] invalid models`);
    const source = modelTS.model.getValue();
    const startMarker = '/// **collab_i18n_start**';
    const endMarker = '/// **collab_i18n_end**';
    const startIdx = source.indexOf(startMarker);
    const endIdx = source.indexOf(endMarker);
    if (startIdx === -1 || endIdx === -1)
        return '';
    const i18nBlock = source.substring(startIdx, endIdx);
    return i18nBlock + '/// **collab_i18n_end**';
}
async function processOutput(context, newi18n, fileReference) {
    if (context.isTest)
        return [];
    if (!fileReference)
        throw new Error('[processOutput] Invalid fileReference');
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`[processOutput] Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[processOutput] invalid file: ${fileReference}`);
    const modelTS = await files.ts.getOrCreateModel();
    if (!modelTS)
        throw new Error(`[geti18nByFile] invalid models`);
    const source = modelTS.model.getValue();
    // The model has been seen escaping the line breaks twice; one line would turn the block into a comment.
    const block = unflattenBlock(newi18n);
    if (!block.includes('\n'))
        throw new Error('[processOutput] the returned block has no line breaks');
    const newValue = replaceI18nBlock(source, block);
    const paramsTs = { ...fileInfo, content: newValue, versionRef: new Date().toISOString(), extension: ".ts" };
    await updateStorFile(paramsTs);
    return [];
}
function replaceI18nBlock(content, newBlock) {
    const regex = /\/\/\/\s\*\*collab_i18n_start\*\*[\s\S]*?\/\/\/\s\*\*collab_i18n_end\*\*/g;
    return content.replace(regex, newBlock);
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMolecule] Invalid storFile');
    const models = await file.getOrCreateModel();
    models.model.pushEditOperations([], [{
            range: models.model.getFullModelRange(),
            text: params.content,
        }], () => null);
    mls.editor.forceModelUpdate(models.model);
    await waitModelIdle(models);
    return models;
}
const system1 = `
<!-- modelType: general -->

You must return ONLY a valid JSON object. No preamble, no markdown fences. Start with { and end with }

You are an agent responsible for removing an existing i18n new language, following the established standard.

{{ skillLanguage }}

## Output format
Return exactly this JSON shape — "type" is always the literal "flexible":

{"type":"flexible","result":{"i18n":"/// **collab_i18n_start**\\n...\\n/// **collab_i18n_end**","fileReference":"<the File Reference from the prompt>"}}

- "i18n" is a JSON string holding the whole block, encoded ONCE by the normal JSON rules: once parsed, it must contain the block's real line breaks. Never escape twice.
- "fileReference" is copied unchanged from the prompt.
- Never answer with the TypeScript block itself, and never wrap the JSON in \`\`\`.

export type Output =
    {
        type: "flexible";
        result: Result;
    }

export type Result = {
    i18n: string,
    fileReference: string // same prompt
}
`;
//#endregion 
