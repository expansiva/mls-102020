/// <mls fileReference="_102020_/l2/aura/agentManageDesignSystem/agentGenerateDs.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getConfigProject, updateConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { mkCompleted, mkFail } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { MANDATORY_COLOR_ROLES } from '/_102029_/l2/designSystemBase.js';
import { skill as dsTokenStandard } from '/_102020_/l2/aura/agentManageDesignSystem/skills/dsTokenStandard.js';
import { buildGenerateDsHumanPrompt, sanitizeGeneratedDs, } from '/_102020_/l2/aura/helpers/dsMatch/generateDsCore.js';
export function createAgent() {
    return {
        agentName: 'agentGenerateDs',
        agentProject: 102020,
        agentFolder: 'aura/agentManageDesignSystem',
        agentDescription: 'Generate a design-system tokens draft from a brand palette (mandatory-token standard)',
        visibility: 'private',
        beforePromptImplicit,
        afterPromptStep,
    };
}
// ─── before: validate request + one generation prompt ────────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    const req = JSON.parse(userPrompt);
    if (!req?.projectId)
        throw new Error(`(${agent.agentName}) entry needs { projectId }`);
    const brief = req.brief?.trim() ?? '';
    const palette = Array.isArray(req.palette) ? req.palette.filter(c => typeof c === 'string' && c.trim()) : [];
    if (!brief && !palette.length)
        throw new Error(`(${agent.agentName}) entry needs a brief and/or a palette`);
    console.info(`[agentGenerateDs] ▶ project=${req.projectId} brief=${brief ? `"${brief.slice(0, 60)}…"` : '—'} palette=[${palette.join(',') || '—'}]`);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: buildGenerateDsHumanPrompt({ ...req, brief, palette }) },
            ],
            taskTitle: req.nameHint?.trim() ? `Generate design system · ${req.nameHint.trim()}` : 'Generate design system',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            // longMemory is string-only → the request round-trips JSON-encoded to afterPromptStep.
            longTermMemory: { request: JSON.stringify({ ...req, brief, palette }) },
        },
    };
    return [addMessageAI];
}
// ─── after: sanitize + write the one-shot draft ───────────────────────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (payload?.type !== 'flexible' || !payload.result)
            throw new Error(`invalid payload: ${JSON.stringify(payload)}`);
        const lm = (context.task?.iaCompressed?.longMemory || {});
        const req = JSON.parse(lm['request'] || '{}');
        if (!req.projectId)
            throw new Error('missing request in longMemory');
        const sanitized = sanitizeGeneratedDs(payload.result, req);
        if (!sanitized.ok || !sanitized.value)
            throw new Error(`LLM output rejected: ${sanitized.error || 'invalid result'}`);
        const draft = {
            ...sanitized.value,
            requestId: req.requestId ?? '',
            brief: req.brief ?? '',
            palette: req.palette ?? [],
            createdAt: new Date().toISOString(),
        };
        if (!context.isTest)
            await persistDraft(req.projectId, draft);
        const colorCount = Object.keys(sanitized.value.tokens.color ?? {}).length;
        console.info(`[agentGenerateDs] ✓ draft "${sanitized.value.name || '(sem nome)'}": ${colorCount} color token(s) · palette=[${(req.palette ?? []).join(',')}]`);
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        const msg = `[agentGenerateDs] ${error instanceof Error ? error.message : String(error)}`;
        console.error('✗', msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
/** One-shot channel to the plugin: config.dsDraft (outside designSystems — never rendered). */
async function persistDraft(projectId, draft) {
    const config = await getConfigProject(projectId);
    if (!config)
        throw new Error('project config not found');
    config.dsDraft = draft;
    await updateConfigProject(projectId, config);
}
// ─── prompt ───────────────────────────────────────────────────────────────────
const system1 = `
<!-- modelType: design -->

You must return ONLY a valid JSON object. No preamble, no markdown fences. Start with { and end with }

You are a senior brand/product designer. Given a brand palette (and optional brief), pick the
color ANCHORS of a design system following the standard below. Return light AND dark anchors for
each of the ${MANDATORY_COLOR_ROLES.length} roles — nothing else (the system derives the
hover/focus/disabled states and fills typography/spacing).

A ROLE says WHERE the color is used, so pick by usage, never by hue: "<role>-bg" is always paired
with "<role>-text" and the pair must be legible together. Keep the surface hierarchy readable
(page-bg behind surface-bg behind surface-alt-bg) and keep chart-series-1..6 mutually
distinguishable IN ORDER (that order is the colour-blindness safeguard).

${dsTokenStandard}

## Example (format reference — values ABRIDGED to 4 roles; you must return ALL of them)
{"type":"flexible","result":{"name":"earthy","description":"Warm, organic feel for an artisan marketplace.","roles":{"page-bg":{"light":"#f6f1eb","dark":"#1b1714"},"surface-bg":{"light":"#fffdfa","dark":"#262019"},"text-default":{"light":"#3b2f2f","dark":"#f6f1eb"},"button-primary-bg":{"light":"#c85a2a","dark":"#e0723f"}}}}

## Output format
export type Output = {
  type: 'flexible';
  result: {
    name: string;
    description: string;
    roles: Record<string, { light: string; dark: string }>;
  };
};
`;
//#endregion
