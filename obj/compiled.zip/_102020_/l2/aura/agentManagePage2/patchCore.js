/// <mls fileReference="_102020_/l2/aura/agentManagePage2/patchCore.ts" enhancement="_blank" />
export const I18N_START = '/// **collab_i18n_start**';
export const I18N_END = '/// **collab_i18n_end**';
/** Members every Lit page may touch regardless of the shared base class surface. */
export const MEMBER_ALLOWLIST = new Set([
    'msg', 'requestUpdate', 'updateComplete', 'dispatchEvent', 'getMessageKey',
    'querySelector', 'querySelectorAll', 'renderRoot', 'isConnected',
]);
/** Chars after which a `/` opens a regex literal rather than dividing. */
const REGEX_PREV = new Set(['(', ',', '=', ':', '[', '!', '&', '|', '?', '{', '}', ';', '+', '-', '*', '%', '<', '>', '~', '^', 'n' /* return */]);
function lastMeaningful(src, before) {
    for (let i = before - 1; i >= 0; i--) {
        const c = src[i];
        if (c !== ' ' && c !== '\t' && c !== '\n' && c !== '\r')
            return c;
    }
    return '';
}
/** Index after the closing quote of the string starting at `from`, or -1 when unterminated. */
function skipQuoted(src, from, quote) {
    for (let i = from + 1; i < src.length; i++) {
        const c = src[i];
        if (c === '\\') {
            i++;
            continue;
        }
        if (c === quote)
            return i + 1;
        if (c === '\n')
            return -1; // a plain string never spans lines
    }
    return -1;
}
/** Index after a regex literal starting at `from`, or -1 when it does not terminate on the line. */
function skipRegex(src, from) {
    let inClass = false;
    for (let i = from + 1; i < src.length; i++) {
        const c = src[i];
        if (c === '\\') {
            i++;
            continue;
        }
        if (c === '\n')
            return -1;
        if (inClass) {
            if (c === ']')
                inClass = false;
            continue;
        }
        if (c === '[') {
            inClass = true;
            continue;
        }
        if (c === '/') {
            let end = i + 1;
            while (end < src.length && /[a-z]/.test(src[end]))
                end++; // flags
            return end;
        }
    }
    return -1;
}
const OPENERS = new Set(['{', '[', '(']);
const CLOSERS = new Set(['}', ']', ')']);
/**
 * From `src[from]` (which must be `{`, `[` or `(`), return the index AFTER the matching closer. Aware
 * of `'…'`, `"…"`, `` `…${ }…` `` (recursively), `//` and block comments, and regex literals. The
 * three bracket kinds share one depth counter — in valid TypeScript they cannot cross, and a
 * parameter list like `(handler: (e: Event) => void)` needs the nesting to be counted. -1 when the
 * value is unbalanced or the source cannot be scanned confidently.
 */
export function scanBalancedTs(src, from) {
    if (!OPENERS.has(src[from]))
        return -1;
    const stack = [{ kind: 'code', depth: 0 }];
    let i = from;
    while (i < src.length) {
        const top = stack[stack.length - 1];
        const c = src[i];
        if (top.kind === 'tpl') {
            if (c === '\\') {
                i += 2;
                continue;
            }
            if (c === '`') {
                stack.pop();
                i++;
                continue;
            }
            if (c === '$' && src[i + 1] === '{') {
                stack.push({ kind: 'code', depth: 1 });
                i += 2;
                continue;
            }
            i++;
            continue;
        }
        if (c === '/' && src[i + 1] === '/') {
            const nl = src.indexOf('\n', i);
            i = nl < 0 ? src.length : nl + 1;
            continue;
        }
        if (c === '/' && src[i + 1] === '*') {
            const close = src.indexOf('*/', i + 2);
            if (close < 0)
                return -1;
            i = close + 2;
            continue;
        }
        if (c === '/' && REGEX_PREV.has(lastMeaningful(src, i))) {
            const end = skipRegex(src, i);
            i = end < 0 ? i + 1 : end; // unterminated ⇒ it was a division after all
            continue;
        }
        if (c === '\'' || c === '"') {
            const end = skipQuoted(src, i, c);
            if (end < 0)
                return -1;
            i = end;
            continue;
        }
        if (c === '`') {
            stack.push({ kind: 'tpl' });
            i++;
            continue;
        }
        if (OPENERS.has(c)) {
            top.depth++;
            i++;
            continue;
        }
        if (CLOSERS.has(c)) {
            top.depth--;
            i++;
            if (top.depth < 0)
                return -1;
            if (top.depth === 0) {
                if (stack.length === 1)
                    return i; // closed the value we were asked about
                stack.pop(); // closed a `${ … }` expression
            }
            continue;
        }
        i++;
    }
    return -1;
}
/** `scanBalancedTs` restricted to a `{` … `}` block (a method body, an object literal). */
export function scanBlock(src, from) {
    return src[from] === '{' ? scanBalancedTs(src, from) : -1;
}
/** `scanBalancedTs` restricted to a `[` … `]` value (an array literal). */
export function scanArray(src, from) {
    return src[from] === '[' ? scanBalancedTs(src, from) : -1;
}
/** `scanBalancedTs` restricted to a `(` … `)` value (a parameter list). */
export function scanParens(src, from) {
    return src[from] === '(' ? scanBalancedTs(src, from) : -1;
}
/** Index of the `{` that opens the page class body, or -1. */
export function findClassBodyStart(src) {
    const m = /export\s+class\s+[A-Za-z0-9_$]+[^{]*\{/u.exec(src);
    return m ? m.index + m[0].length - 1 : -1;
}
function escapeRe(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
}
/** Control-flow keywords that look like a method declaration at the start of a line. */
const NOT_A_METHOD = new Set(['if', 'for', 'while', 'switch', 'catch', 'do', 'else', 'return', 'function', 'with']);
/**
 * Every method declared directly in the page class body, in source order. Accessors and modifiers
 * (`protected get msg()`) count as methods: skipping their body is what keeps a nested `if (…) {`
 * from being mistaken for a declaration.
 */
export function listMethods(src) {
    const bodyStart = findClassBodyStart(src);
    if (bodyStart < 0)
        return [];
    const bodyEnd = scanBlock(src, bodyStart);
    if (bodyEnd < 0)
        return [];
    const out = [];
    // The parameter list is scanned, not regex-matched: `(handler: (e: Event) => void)` has nested
    // parens, and a `[^)]*` pattern silently skips such a method — which then stops being skipped as
    // a block, so its inner braces start looking like declarations.
    const re = /(^|\n)([ \t]*)((?:(?:public|private|protected|static|override|readonly|async|get|set)\s+)*(?:#)?[A-Za-z_$][A-Za-z0-9_$]*)\s*\(/gu;
    re.lastIndex = bodyStart;
    for (let m = re.exec(src); m; m = re.exec(src)) {
        const parenStart = m.index + m[0].length - 1;
        if (parenStart >= bodyEnd)
            break;
        const rawName = m[3].replace(/^(?:(?:public|private|protected|static|override|readonly|async|get|set)\s+)*/u, '');
        if (NOT_A_METHOD.has(rawName))
            continue;
        const parenEnd = scanParens(src, parenStart);
        if (parenEnd < 0)
            continue;
        const head = /^\s*(?::\s*[^{;=]+)?\{/u.exec(src.slice(parenEnd));
        if (!head)
            continue; // a call, not a declaration
        const openBrace = parenEnd + head[0].length - 1;
        if (openBrace >= bodyEnd)
            break;
        const end = scanBlock(src, openBrace);
        if (end < 0)
            continue;
        out.push({ name: rawName, start: m.index + m[1].length, end, indent: m[2] });
        re.lastIndex = end; // never look for a method inside another method
    }
    return out;
}
/**
 * Index of the `{` that opens the body of a standalone method declaration, skipping its parameter
 * list (which may itself contain braces, e.g. a destructured or object-typed parameter). -1 when the
 * text is not a method declaration.
 */
export function methodBodyBrace(code) {
    const parenStart = code.indexOf('(');
    if (parenStart < 0)
        return -1;
    const parenEnd = scanParens(code, parenStart);
    if (parenEnd < 0)
        return -1;
    const head = /^\s*(?::\s*[^{;=]+)?\{/u.exec(code.slice(parenEnd));
    return head ? parenEnd + head[0].length - 1 : -1;
}
/** The single method `name` in the class body. Null when absent; null when ambiguous (2+). */
export function findMethod(src, name) {
    const hits = listMethods(src).filter(mth => mth.name === name);
    return hits.length === 1 ? hits[0] : null;
}
/** How many times `name` is declared in the class body (0, 1 or more). */
export function countMethod(src, name) {
    return listMethods(src).filter(mth => mth.name === name).length;
}
/**
 * Replace (or append) whole methods. Each `code` must start with the same signature name, so the
 * model cannot rename or merge methods by accident. Patches are applied one at a time, re-locating
 * the target every round, so earlier splices never invalidate later offsets.
 */
export function applyMethodPatches(src, methods) {
    if (!Array.isArray(methods) || methods.length === 0)
        return { ok: false, reason: 'no method patch was returned' };
    const seen = new Set();
    let out = src;
    for (const patch of methods) {
        const name = typeof patch?.name === 'string' ? patch.name.trim() : '';
        const code = typeof patch?.code === 'string' ? patch.code.trim() : '';
        if (!name)
            return { ok: false, reason: 'a method patch has no name' };
        if (seen.has(name))
            return { ok: false, reason: `method '${name}' was patched twice` };
        seen.add(name);
        if (!code)
            return { ok: false, reason: `method '${name}' came back empty` };
        const sig = new RegExp(`^(?:async\\s+)?(?:#)?${escapeRe(name)}\\s*\\(`, 'u');
        if (!sig.test(code))
            return { ok: false, reason: `the code for '${name}' does not start with its own signature` };
        const brace = methodBodyBrace(code);
        if (brace < 0 || scanBlock(code, brace) !== code.length) {
            return { ok: false, reason: `the code for '${name}' is not a single balanced method body` };
        }
        const occurrences = countMethod(out, name);
        if (occurrences > 1)
            return { ok: false, reason: `method '${name}' is declared ${occurrences} times — cannot patch unambiguously` };
        if (occurrences === 1) {
            const span = findMethod(out, name);
            out = out.slice(0, span.start) + span.indent + code + out.slice(span.end);
            continue;
        }
        // New helper: append just before the class closing brace.
        const bodyStart = findClassBodyStart(out);
        const bodyEnd = bodyStart < 0 ? -1 : scanBlock(out, bodyStart);
        if (bodyEnd < 0)
            return { ok: false, reason: 'could not locate the page class body' };
        const closeBrace = bodyEnd - 1;
        out = `${out.slice(0, closeBrace)}${code}\n${out.slice(closeBrace)}`;
    }
    return { ok: true, value: out };
}
/** Span of the generated i18n block (between the markers). Null when the markers are not a pair. */
export function findI18nBlock(src) {
    const startHits = src.split(I18N_START).length - 1;
    const endHits = src.split(I18N_END).length - 1;
    if (startHits !== 1 || endHits !== 1)
        return null;
    const start = src.indexOf(I18N_START) + I18N_START.length;
    const end = src.indexOf(I18N_END);
    return end > start ? { start, end } : null;
}
/** The per-locale catalogue consts (`pageMessage_pt`, `o1Message_pt_br`, …) inside the i18n block. */
export function findMessageConsts(src) {
    const block = findI18nBlock(src);
    if (!block)
        return [];
    const out = [];
    const re = /const\s+([A-Za-z0-9$_]*Message_([a-z0-9_]+))\s*(?::\s*[A-Za-z0-9_$<>[\]]+\s*)?=\s*\{/gu;
    re.lastIndex = block.start;
    for (let m = re.exec(src); m; m = re.exec(src)) {
        if (m.index >= block.end)
            break;
        const bodyStart = m.index + m[0].length - 1;
        const bodyEnd = scanBlock(src, bodyStart);
        if (bodyEnd < 0)
            continue;
        out.push({ name: m[1], locale: m[2].replace(/_/gu, '-'), bodyStart, bodyEnd });
        re.lastIndex = bodyEnd;
    }
    return out;
}
/** Short keys the page's `this.msg` offers: the `fromShared` map plus every locale const. */
export function catalogueKeys(src) {
    const keys = new Set();
    const collect = (from, to) => {
        const slice = src.slice(from, to);
        const re = /'([^']+)'\s*:/gu;
        for (let m = re.exec(slice); m; m = re.exec(slice))
            keys.add(m[1]);
    };
    const shared = /const\s+fromShared\s*=[^{]*\{/u.exec(src);
    if (shared) {
        const bodyStart = shared.index + shared[0].length - 1;
        const bodyEnd = scanBlock(src, bodyStart);
        if (bodyEnd > 0)
            collect(bodyStart, bodyEnd);
    }
    for (const konst of findMessageConsts(src))
        collect(konst.bodyStart, konst.bodyEnd);
    return keys;
}
function quoteValue(value) {
    return `'${value.replace(/\\/gu, '\\\\').replace(/'/gu, "\\'").replace(/\r?\n/gu, ' ')}'`;
}
/** Indentation of the last property line inside a catalogue body. */
function bodyIndent(src, konst) {
    const inner = src.slice(konst.bodyStart + 1, konst.bodyEnd - 1);
    const lines = inner.split('\n').filter(line => line.trim().length > 0);
    const last = lines[lines.length - 1] ?? '';
    return (/^[ \t]*/u.exec(last)?.[0]) ?? '';
}
/**
 * Add brand-new short keys to EVERY locale const. The first const defines `PageMessageType` by
 * inference, so a key missing from one locale is a TS2741 and a key only in one locale is a TS2353 —
 * which is why this is deterministic code and not something the model is asked to write. A locale the
 * model did not translate falls back to the default locale's text (an untranslated string compiles;
 * a missing key does not).
 */
export function applyMessagePatches(src, messages) {
    if (!messages.length)
        return { ok: true, value: { code: src, warnings: [] } };
    const consts = findMessageConsts(src);
    if (!consts.length) {
        return { ok: false, reason: 'this page has no per-locale catalogue block, so no new text can be introduced here — reuse an existing message key' };
    }
    const existing = catalogueKeys(src);
    const warnings = [];
    const normalized = [];
    for (const entry of messages) {
        const key = typeof entry?.key === 'string' ? entry.key.trim() : '';
        if (!key)
            return { ok: false, reason: 'an i18n entry has no key' };
        if (!/^[A-Za-z][A-Za-z0-9_.-]*$/u.test(key))
            return { ok: false, reason: `i18n key '${key}' is not a short dotted key` };
        if (existing.has(key))
            return { ok: false, reason: `i18n key '${key}' already exists — changing existing text is a shared/l4 edit, out of scope here` };
        const values = {};
        for (const [rawLocale, text] of Object.entries(entry.values ?? {})) {
            if (typeof text === 'string' && text.trim())
                values[rawLocale.toLowerCase().replace(/_/gu, '-')] = text;
        }
        if (!Object.keys(values).length)
            return { ok: false, reason: `i18n key '${key}' came back with no value` };
        normalized.push({ key, values });
        existing.add(key);
    }
    const defaultLocale = consts[0].locale;
    let out = src;
    // Last const first: an earlier splice would shift every later offset.
    for (let i = consts.length - 1; i >= 0; i--) {
        const konst = consts[i];
        const indent = bodyIndent(src, konst);
        const lines = normalized.map(entry => {
            const text = entry.values[konst.locale] ?? entry.values[defaultLocale] ?? Object.values(entry.values)[0];
            if (!entry.values[konst.locale])
                warnings.push(`i18n '${entry.key}' not translated for '${konst.locale}' — fell back to '${defaultLocale}'`);
            return `${indent}'${entry.key}': ${quoteValue(text)},`;
        });
        const closeBrace = konst.bodyEnd - 1;
        const before = out.slice(0, closeBrace);
        const glue = before.endsWith('\n') ? '' : '\n';
        out = `${before}${glue}${lines.join('\n')}\n${out.slice(closeBrace)}`;
    }
    return { ok: true, value: { code: out, warnings } };
}
/**
 * True when the page owns a per-locale catalogue block (the current generator shape). Some pages
 * generated before the skeleton rule have no block at all and read the SHARED keys directly through
 * `this.msg` — on those, new visible text cannot be introduced by a patch.
 */
export function hasPageCatalogue(src) {
    return !!findI18nBlock(src) && findMessageConsts(src).length > 0;
}
function sliceBlockAfter(src, re) {
    const m = re.exec(src);
    if (!m)
        return '';
    const openBrace = src.indexOf('{', m.index + m[0].length - 1);
    if (openBrace < 0)
        return '';
    const end = scanBlock(src, openBrace);
    return end < 0 ? '' : src.slice(m.index, end);
}
/** The parts of a page file a visual patch must never touch. */
export function fingerprint(src) {
    return {
        header: (/^\/\/\/\s*<mls[^\n]*$/mu.exec(src)?.[0] ?? '').trim(),
        tag: /@customElement\(\s*'([^']+)'\s*\)/u.exec(src)?.[1] ?? '',
        classDecl: (/export\s+class\s+[A-Za-z0-9_$]+\s+extends\s+[A-Za-z0-9_$]+/u.exec(src)?.[0] ?? '').replace(/\s+/gu, ' '),
        imports: (src.match(/^import[^\n]*$/gmu) ?? []).join('\n'),
        locales: findMessageConsts(src).map(konst => konst.locale),
        msgGetter: sliceBlockAfter(src, /(?:protected\s+|public\s+)?get\s+msg\s*\(\s*\)[^{]*\{/u).replace(/\s+/gu, ' '),
        hasRender: countMethod(src, 'render') === 1,
        i18nMarkers: [src.split(I18N_START).length - 1, src.split(I18N_END).length - 1],
    };
}
/** Reject a patched file that broke the contract with the shell, the compiler or i18n. */
export function guardInvariants(before, after) {
    const a = fingerprint(before);
    const b = fingerprint(after);
    if (a.header !== b.header)
        return { ok: false, reason: 'the mls header line changed' };
    if (a.tag !== b.tag)
        return { ok: false, reason: 'the custom element tag changed' };
    if (a.classDecl !== b.classDecl)
        return { ok: false, reason: 'the class declaration changed' };
    if (a.imports !== b.imports)
        return { ok: false, reason: 'the import block changed — a visual patch never needs a new import' };
    if (a.locales.join(',') !== b.locales.join(','))
        return { ok: false, reason: 'the i18n locale set changed' };
    if (a.msgGetter !== b.msgGetter)
        return { ok: false, reason: 'the msg getter changed' };
    if (!b.hasRender)
        return { ok: false, reason: 'render() is missing or duplicated after the patch' };
    if (a.i18nMarkers[0] !== b.i18nMarkers[0] || a.i18nMarkers[1] !== b.i18nMarkers[1]) {
        return { ok: false, reason: 'the collab_i18n markers changed' };
    }
    return { ok: true, value: true };
}
const BEHAVIOR_PATTERNS = [
    { re: /@property\s*\(/u, reason: 'declares @property — state belongs to the shared base class' },
    { re: /(^|\n)\s*(?:async\s+)?handle[A-Z][A-Za-z0-9_$]*\s*\([^)]*\)\s*\{/u, reason: 'declares a handler — handlers belong to the shared base class' },
    { re: /\bfetch\s*\(/u, reason: 'calls fetch — the page never talks to the network' },
    { re: /\bimport\s*\(/u, reason: 'uses a dynamic import' },
    { re: /\bset(?:Interval|Timeout)\s*\(/u, reason: 'schedules a timer' },
    { re: /\bnew\s+EventSource\b/u, reason: 'opens an EventSource' },
    { re: /\b(?:setState|initStateValue|collabState)\s*\(/u, reason: 'writes application state' },
    { re: /\blocalStorage\b|\bsessionStorage\b/u, reason: 'touches browser storage' },
    { re: /\bthis\.[A-Za-z0-9_$]+\s*=(?!=)/u, reason: 'assigns to a member — the page renders, it does not mutate state' },
    { re: /\bawait\b/u, reason: 'awaits — render is synchronous' },
];
/** Reject patched code that stops being pure presentation. */
export function guardNoBehavior(code) {
    for (const { re, reason } of BEHAVIOR_PATTERNS) {
        if (re.test(code))
            return { ok: false, reason: `patch ${reason}` };
    }
    return { ok: true, value: true };
}
/** `this.<member>` references in the patched code that the runtime surface does not offer. */
export function guardMembers(code, allowed) {
    const unknown = new Set();
    const re = /\bthis\.([A-Za-z0-9_$]+)/gu;
    for (let m = re.exec(code); m; m = re.exec(code)) {
        const name = m[1];
        if (!allowed.has(name) && !MEMBER_ALLOWLIST.has(name))
            unknown.add(name);
    }
    return unknown.size
        ? { ok: false, reason: `patch references members that do not exist: ${[...unknown].join(', ')}` }
        : { ok: true, value: true };
}
/** `msg['key']` references that the catalogue (after the message patch) does not carry. */
export function guardMsgKeys(code, keys) {
    const unknown = new Set();
    const re = /\bmsg\[\s*'([^']+)'\s*\]/gu;
    for (let m = re.exec(code); m; m = re.exec(code)) {
        if (!keys.has(m[1]))
            unknown.add(m[1]);
    }
    return unknown.size
        ? { ok: false, reason: `patch uses i18n keys that do not exist: ${[...unknown].join(', ')}` }
        : { ok: true, value: true };
}
/** Method names the approved operations authorize (a `page`-scoped op means the root render()). */
export function allowedScopes(operations) {
    const out = new Set();
    for (const op of operations)
        out.add(op.scope === 'page' || !op.scope ? 'render' : op.scope);
    return out;
}
/**
 * Keep the patch inside the approved blast radius: every touched method is either authorized by an
 * operation or a brand-new helper, and at least one authorized method is actually touched.
 */
export function guardScope(src, patch, operations) {
    const allowed = allowedScopes(operations);
    const existing = new Set(listMethods(src).map(mth => mth.name));
    let touchedAuthorized = 0;
    for (const method of patch.methods ?? []) {
        const name = method?.name ?? '';
        if (allowed.has(name)) {
            touchedAuthorized++;
            continue;
        }
        if (!existing.has(name))
            continue; // new helper is fine
        return { ok: false, reason: `patch touches '${name}', which no approved operation authorizes` };
    }
    return touchedAuthorized
        ? { ok: true, value: true }
        : { ok: false, reason: `patch touched no authorized method (expected one of: ${[...allowed].join(', ')})` };
}
/** Non-fatal: design-system variables the patch used that the project does not declare. */
export function warnTokens(code, dsTokens) {
    if (!dsTokens.size)
        return [];
    const unknown = new Set();
    const re = /var\(\s*(--[a-z0-9-]+)/gu;
    for (let m = re.exec(code); m; m = re.exec(code)) {
        if (!dsTokens.has(m[1]))
            unknown.add(m[1]);
    }
    return unknown.size ? [`unknown design tokens used: ${[...unknown].join(', ')}`] : [];
}
/**
 * Guard → splice → guard again. Returns the patched source plus non-fatal warnings, or the reason the
 * patch was refused. Nothing here writes: the caller decides to save.
 */
export function applyPagePatch(src, patch, ctx) {
    if (!patch || !Array.isArray(patch.methods))
        return { ok: false, reason: 'patch has no methods array' };
    const patchedCode = patch.methods.map(method => method?.code ?? '').join('\n');
    const behavior = guardNoBehavior(patchedCode);
    if (!behavior.ok)
        return behavior;
    const scope = guardScope(src, patch, ctx.operations);
    if (!scope.ok)
        return scope;
    const warnings = [];
    let out = src;
    if (patch.messages?.length) {
        const applied = applyMessagePatches(out, patch.messages);
        if (!applied.ok)
            return applied;
        out = applied.value.code;
        warnings.push(...applied.value.warnings);
    }
    const spliced = applyMethodPatches(out, patch.methods);
    if (!spliced.ok)
        return spliced;
    out = spliced.value;
    const invariants = guardInvariants(src, out);
    if (!invariants.ok)
        return invariants;
    const allowedMembers = new Set([...ctx.sharedMembers, ...listMethods(out).map(mth => mth.name)]);
    const members = guardMembers(patchedCode, allowedMembers);
    if (!members.ok)
        return members;
    const keys = guardMsgKeys(patchedCode, new Set([...catalogueKeys(out), ...(ctx.sharedMsgKeys ?? [])]));
    if (!keys.ok)
        return keys;
    warnings.push(...warnTokens(patchedCode, ctx.dsTokens ?? new Set()));
    return { ok: true, value: { code: out, warnings } };
}
/** Keep only well-formed operations. `scope` defaults to 'page' (the root render). */
export function normalizeOperations2(raw) {
    const arr = Array.isArray(raw) ? raw : [];
    const kinds = new Set(['layout', 'style', 'text', 'visibility']);
    const out = [];
    for (const item of arr) {
        const kind = item?.kind;
        const description = typeof item?.description === 'string' ? item.description.trim() : '';
        if (!kinds.has(kind) || !description)
            continue;
        const scope = typeof item?.scope === 'string' && item.scope.trim() ? item.scope.trim() : 'page';
        out.push({ kind, scope, target: typeof item?.target === 'string' ? item.target : '', description });
    }
    return out;
}
/** Validate a patch payload's shape before anything else looks at it. */
export function normalizePatch(raw) {
    if (!raw || typeof raw !== 'object')
        return null;
    const source = raw;
    const methods = Array.isArray(source.methods) ? source.methods : [];
    const clean = methods
        .filter(m => m && typeof m.name === 'string' && typeof m.code === 'string')
        .map(m => ({ name: m.name.trim(), code: m.code }));
    if (!clean.length)
        return null;
    const messages = Array.isArray(source.messages)
        ? source.messages
            .filter(m => m && typeof m.key === 'string' && m.values && typeof m.values === 'object')
            .map(m => ({ key: m.key.trim(), values: m.values }))
        : [];
    return { methods: clean, messages, notes: typeof source.notes === 'string' ? source.notes.trim() : '' };
}
// ─── generic `export const NAME = …;` splice (defs files) ────────────────────
/** Span of `export const <name> = <object|array>;` (including `as const` and the `;`). */
export function findExportConst(content, name) {
    const re = new RegExp(`export\\s+const\\s+${escapeRe(name)}\\s*=\\s*`, 'gu');
    const m = re.exec(content);
    if (!m)
        return null;
    const valueStart = m.index + m[0].length;
    const open = content[valueStart];
    if (open !== '{' && open !== '[')
        return null;
    const valueEnd = scanBalancedTs(content, valueStart);
    if (valueEnd < 0)
        return null;
    const tail = /^\s*(?:as\s+const)?\s*;/u.exec(content.slice(valueEnd));
    return { start: m.index, valueStart, end: tail ? valueEnd + tail[0].length : valueEnd };
}
/** Parse `export const <name> = <json>;` as data. Null when absent or not JSON. */
export function parseExportJson(content, name) {
    const span = findExportConst(content, name);
    if (!span)
        return null;
    const valueEnd = scanBalancedTs(content, span.valueStart);
    if (valueEnd < 0)
        return null;
    try {
        return JSON.parse(content.slice(span.valueStart, valueEnd));
    }
    catch {
        return null;
    }
}
// ─── the prompt contract (single source of truth, shared with the LLM) ───────
export const PATCH_TOOL_NAME = 'submitPagePatch';
/** Tool the patch step forces: methods as code, new text as data, one line of notes. */
export const PATCH_TOOL = {
    type: 'function',
    function: {
        name: PATCH_TOOL_NAME,
        description: 'Submit the render methods you changed, plus any brand-new i18n keys.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['methods', 'notes'],
            properties: {
                methods: {
                    type: 'array',
                    description: 'One entry per method you changed. Complete method text, signature included.',
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        required: ['name', 'code'],
                        properties: {
                            name: { type: 'string', description: 'Method name, exactly as declared in the class.' },
                            code: { type: 'string', description: 'The COMPLETE method, starting with its own signature and ending with its closing brace.' },
                        },
                    },
                },
                messages: {
                    type: 'array',
                    description: 'Brand-new short i18n keys this patch needs. Omit when none.',
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        required: ['key', 'values'],
                        properties: {
                            key: { type: 'string', description: 'Short dotted key, e.g. actions.exportCsv.' },
                            values: { type: 'object', description: 'Text per locale, keyed by the file\'s locales (e.g. { "pt": "…", "en": "…" }).', additionalProperties: { type: 'string' } },
                        },
                    },
                },
                notes: { type: 'string', description: "One line, in the user's language: what you changed." },
            },
        },
    },
};
export const PATCH_RULES = `
Return ONLY the render methods you actually changed, each as a COMPLETE method (signature + body),
plus any brand-new i18n keys as DATA. The file is spliced deterministically around what you return.

Hard rules — a patch that breaks any of these is rejected before it is saved:
- Do NOT add, remove or reorder imports. If a change would need a new import, it is out of scope.
- Do NOT touch the mls header line, the \`@customElement\` tag, the class declaration, the
  \`get msg()\` getter, or anything between the \`collab_i18n_start\`/\`collab_i18n_end\` markers.
- Do NOT declare state (\`@property\`) or handlers (\`handleX\`), do NOT assign to \`this.…\`, do NOT
  call fetch/import()/timers/storage, and never use \`await\`: this file only renders.
- Use ONLY members the shared base class already offers (the \`.d.ts\` in context) and ONLY i18n keys
  that already exist — or ones you declare in \`messages\` in this same response.
- Touch ONLY the methods named in the approved operations' \`scope\`. Extracting a NEW private
  \`render*\` helper is allowed; renaming or merging existing methods is not.
- Keep the file's own style: Tailwind classes plus \`var(--token, #fallback)\` for colors. No <style>
  blocks, no inline hex without the token, no new dependency.

New visible text goes in \`messages\` as \`{ key, values: { <locale>: '…' } }\` with a SHORT dotted key
(e.g. \`actions.exportCsv\`). Cover every locale of the file; a locale you omit falls back to the
default one. Never inline a literal string in the markup, and never change the text of an existing
key — that is a shared/l4 edit, not a visual one.

\`notes\` is one line, in the user's language, saying what you changed.`;
