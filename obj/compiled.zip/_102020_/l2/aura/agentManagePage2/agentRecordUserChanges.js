/// <mls fileReference="_102020_/l2/aura/agentManagePage2/agentRecordUserChanges.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { pageRef } from '/_102020_/l2/aura/helpers/dsMatch/derivePaths.js';
import { mkCompleted, mkFail, saveFile } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { getContentByMlsPath } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeStudio.js';
import { parseUserChanges, upsertUserChanges, nextChangeId, supersedeDeterministic, validateConsolidated, summarizeUserChanges, CHANGE_INTENTS, } from '/_102020_/l2/aura/agentManagePage2/userChangesCore.js';
import { traceStep, traceSent, traceReceived, traceVerdict, traceFail } from '/_102020_/l2/aura/agentManagePage2/trace.js';
export function createAgent() {
    return {
        agentName: 'agentRecordUserChanges',
        agentProject: 102020,
        agentFolder: 'aura/agentManagePage2',
        agentDescription: 'Record the applied visual change in the page defs as the consolidated userChanges set',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
function parseArgs(prompt) {
    if (!prompt)
        throw new Error('[agentRecordUserChanges] empty step prompt');
    const args = JSON.parse(prompt);
    if (!args.module || !args.page || args.layout == null || args.ds == null)
        throw new Error(`[agentRecordUserChanges] invalid args: ${prompt}`);
    if (!args.device)
        args.device = 'desktop';
    if (!Array.isArray(args.operations))
        args.operations = [];
    return args;
}
function defsRefOf(args) {
    return pageRef(mls.actualProject || 0, args.module, args.layout, args.ds, args.page, '.defs.ts', args.device);
}
/**
 * The entries this request introduces, already stamped. One per operation, because two operations of
 * the same request can sit on different axes (align the buttons AND hide a column) and must be able
 * to be superseded independently later.
 */
export function buildIncoming(args, existing, user, date) {
    const out = [];
    for (const operation of args.operations) {
        out.push({
            id: nextChangeId([...existing, ...out]),
            change: operation.description,
            scope: operation.scope || 'page',
            intent: defaultIntentFor(operation),
            user,
            date,
        });
    }
    return out;
}
/** Axis guess from the operation kind — the model may refine it, within CHANGE_INTENTS. */
function defaultIntentFor(operation) {
    if (operation.kind === 'visibility')
        return 'visibility';
    if (operation.kind === 'text')
        return 'text.label';
    if (operation.kind === 'style')
        return 'style.emphasis';
    return 'layout.align';
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseArgs(args ?? step.prompt);
        const meta = { agent: 'agentRecordUserChanges', page: a.page, taskId: context.task?.PK };
        const defsRef = defsRefOf(a);
        const defsSrc = await getContentByMlsPath(defsRef);
        if (!defsSrc)
            throw new Error(`defs not found: ${defsRef}`);
        const existing = parseUserChanges(defsSrc);
        const user = context.message.senderId || '';
        const date = new Date().toISOString();
        const incoming = buildIncoming(a, existing, user, date);
        // Deterministic pass first: the axes the code can already resolve.
        let baseline = existing;
        for (const entry of incoming)
            baseline = supersedeDeterministic(baseline, entry);
        traceStep(meta, 'consolidating userChanges', {
            target: defsRef,
            existing: existing.map(entry => `${entry.id}[${entry.intent}@${entry.scope}]`),
            incoming: incoming.map(entry => `${entry.id}[${entry.intent}@${entry.scope}]`),
            afterDeterministicSupersede: baseline.map(entry => entry.id),
            user,
        });
        const human = JSON.stringify({
            request: a.request,
            operations: a.operations,
            currentUserChanges: existing,
            incoming,
            deterministicResult: baseline,
            allowedIntents: CHANGE_INTENTS,
        });
        const continueParallel = {
            type: 'prompt_ready',
            args: args ?? step.prompt ?? '',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt: recordPrompt,
            humanPrompt: human,
        };
        traceSent(meta, 'userChanges consolidation', {
            system: recordPrompt,
            human,
            data: { existing, incoming, deterministicResult: baseline },
        });
        return [continueParallel];
    }
    catch (error) {
        const msg = `[agentRecordUserChanges] ${error instanceof Error ? error.message : String(error)}`;
        traceFail({ agent: 'agentRecordUserChanges' }, msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const a = parseArgs(step.prompt);
        const meta = { agent: 'agentRecordUserChanges', page: a.page, taskId: context.task?.PK };
        const defsRef = defsRefOf(a);
        const defsSrc = await getContentByMlsPath(defsRef);
        if (!defsSrc)
            throw new Error(`defs not found: ${defsRef}`);
        const existing = parseUserChanges(defsSrc);
        const payload = step.interaction?.payload?.[0];
        traceReceived(meta, 'userChanges consolidation', payload, {
            returned: Array.isArray(payload?.result?.userChanges) ? payload.result.userChanges.map((entry) => entry?.id) : 'NOT AN ARRAY',
        });
        // Same derivation as beforePromptStep, stamped here — this hook is the one that writes.
        const incoming = buildIncoming(a, existing, context.message.senderId || '', new Date().toISOString());
        // The model's list is only accepted when it survives the net; otherwise the deterministic result
        // is written instead — the record must never be lost because the consolidation was sloppy.
        let consolidated;
        const guard = validateConsolidated(existing, payload?.result?.userChanges, incoming);
        if (guard.ok) {
            consolidated = guard.value;
            traceVerdict(meta, 'consolidation accepted', true, consolidated.map(entry => entry.id).join(', '));
        }
        else {
            traceVerdict(meta, 'consolidation REFUSED — writing the deterministic result instead', false, guard.reason);
            consolidated = incoming.reduce((list, entry) => supersedeDeterministic(list, entry), existing);
        }
        const out = upsertUserChanges(defsSrc, consolidated);
        if (!context.isTest) {
            await saveFile(defsRef, out);
            traceVerdict(meta, `DONE — ${consolidated.length} userChange(s) written to ${defsRef}`, true, `${defsSrc.length}B -> ${out.length}B`);
            console.info(`[agentRecordUserChanges] userChanges now:
${summarizeUserChanges(consolidated)}`);
        }
        return [mkCompleted(context, parentStep, step, hookSequential, `CHANGES:${summarizeUserChanges(consolidated)}`)];
    }
    catch (error) {
        const msg = `[agentRecordUserChanges] ${error instanceof Error ? error.message : String(error)}`;
        traceFail({ agent: 'agentRecordUserChanges' }, msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
const recordPrompt = `
<!-- modelType: classifier -->

You maintain the \`userChanges\` list of a page: the CURRENT SET of visual deviations the user wants,
relative to what the generator would produce. It is NOT a history — an entry that a newer request
contradicts must disappear, not accumulate.

The human message is { request, operations, currentUserChanges, incoming, deterministicResult, allowedIntents }.

- \`incoming\` are the entries for the change that was JUST applied. You may refine each one's
  \`change\` wording (short, in the user's voice), its \`scope\` and its \`intent\` (one of
  \`allowedIntents\`). You may NOT change its \`id\`. Authorship (\`user\`/\`date\`) is stamped by the
  system: echo the values you were given, they are ignored either way.
- \`deterministicResult\` already dropped every previous entry that sits on the SAME (scope, intent)
  axis as an incoming one. Start from it.
- Your only remaining job: drop previous entries that the new one contradicts ACROSS axes — e.g. a new
  \`layout.order\` that makes an older \`visibility\` entry meaningless, or an older entry about an
  element the new change removes. When in doubt, KEEP the previous entry.

Rules:
- Every entry you return is either one of \`currentUserChanges\` with its \`change\`/\`scope\`/\`intent\`
  UNCHANGED, or one of \`incoming\`. Never invent an entry, never merge two into one.
- Every \`incoming\` entry MUST be present in your answer.
- Order does not matter.

Return ONLY:
{"type":"flexible","result":{"userChanges":[{"id":"…","change":"…","scope":"…","intent":"…","user":"…","date":"…"}]}}

Return valid JSON only. No preamble, no markdown fences.

## Output format
export type Output = { type: 'flexible'; result: { userChanges: Array<{ id: string; change: string; scope: string; intent: string; user: string; date: string }> } };
`;
//#endregion
