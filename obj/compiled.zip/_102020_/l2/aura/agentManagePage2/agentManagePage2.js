/// <mls fileReference="_102020_/l2/aura/agentManagePage2/agentManagePage2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { pageRef, DEFAULT_DEVICE } from '/_102020_/l2/aura/helpers/dsMatch/derivePaths.js';
import { mkAgentStep, mkFail, mkCompleted, makePlanId } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
import { getContentByMlsPath, getCompiledDtsByMlsPath } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeStudio.js';
import { checkSharedDtsProvenance, sharedDtsArtifactRef } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeCore.js';
import { normalizeOperations2 } from '/_102020_/l2/aura/agentManagePage2/patchCore.js';
import { buildPageEditContext, partitionOperationsByScope, scopeVocabulary } from '/_102020_/l2/aura/agentManagePage2/pageContextCore.js';
import { parseUserChanges } from '/_102020_/l2/aura/agentManagePage2/userChangesCore.js';
import { traceStep, traceSources, traceSent, traceReceived, traceVerdict, traceFail, tracePlan } from '/_102020_/l2/aura/agentManagePage2/trace.js';
export function createAgent() {
    return {
        agentName: 'agentManagePage2',
        agentProject: 102020,
        agentFolder: 'aura/agentManagePage2',
        agentDescription: 'Pointed VISUAL edit of a generated page: gate the scope, patch the .ts, record the intent in the defs',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
// ─── refs ───────────────────────────────────────────────────────────────────
export function sharedTsRef(project, module, page) {
    return `_${project}_/l2/${module}/web/shared/${page}.ts`;
}
export function l4WorkspaceRef(project, module, page) {
    return `_${project}_/l4/${module}/workspaces/${page}.defs.ts`;
}
export function designSystemRef(project) {
    return `_${project}_/l2/designSystem.ts`;
}
/**
 * The shared base class surface: the persisted compiled `.d.ts` artifact, else compiled on demand,
 * else the raw `.ts`. Same three-tier resolution the materializer uses — the `.d.ts` is 4x smaller
 * than the source and is the authoritative contract. `onResolve` reports which tier answered, which
 * matters when the surface looks thinner than expected.
 */
export async function readSharedSurfaceSource(project, module, page, onResolve) {
    const tsRef = sharedTsRef(project, module, page);
    const artifact = sharedDtsArtifactRef(tsRef);
    if (artifact) {
        const persisted = await getContentByMlsPath(artifact);
        // Same provenance test the materializer applies: the artifact is served only when its stamp proves
        // the shared .ts on disk produced it. This reader had NO freshness check at all, so it would hand
        // over the run01 artifact — which declared a handler the shared had lost — as the base-class surface.
        const checked = checkSharedDtsProvenance(persisted, await getContentByMlsPath(tsRef));
        if (checked.dts) {
            onResolve?.({ ref: artifact, via: 'persisted .d.ts artifact', size: checked.dts.length });
            return checked.dts;
        }
        if (persisted?.trim())
            onResolve?.({ ref: artifact, via: `artifact refused (${checked.reason})`, size: persisted.length });
    }
    const compiled = await getCompiledDtsByMlsPath(tsRef);
    if (compiled?.trim()) {
        onResolve?.({ ref: tsRef, via: 'compiled on demand', size: compiled.length });
        return compiled;
    }
    const raw = (await getContentByMlsPath(tsRef)) ?? '';
    onResolve?.({ ref: tsRef, via: raw ? 'raw .ts fallback' : 'NOT FOUND', size: raw.length });
    return raw;
}
/** Read every source the gate's digest needs, tracing what each one resolved to. */
export async function loadEditContext(entry, meta) {
    const project = mls.actualProject || 0;
    const defsRef = pageRef(project, entry.module, entry.layout, entry.ds, entry.page, '.defs.ts', entry.device);
    const tsRef = pageRef(project, entry.module, entry.layout, entry.ds, entry.page, '.ts', entry.device);
    const l4Ref = l4WorkspaceRef(project, entry.module, entry.page);
    const defsSrc = await getContentByMlsPath(defsRef);
    const pageSrc = await getContentByMlsPath(tsRef);
    const l4WorkspaceSrc = defsSrc && pageSrc ? await getContentByMlsPath(l4Ref) : null;
    let sharedInfo;
    const sharedSrc = defsSrc && pageSrc
        ? await readSharedSurfaceSource(project, entry.module, entry.page, info => { sharedInfo = info; })
        : '';
    if (meta) {
        traceSources(meta, {
            'page .defs.ts': { ref: defsRef, found: !!defsSrc, size: defsSrc?.length },
            'page .ts': { ref: tsRef, found: !!pageSrc, size: pageSrc?.length },
            'l4 workspace': { ref: l4Ref, found: !!l4WorkspaceSrc, size: l4WorkspaceSrc?.length ?? undefined },
            'shared surface': { ref: sharedInfo?.ref ?? '', found: !!sharedSrc, size: sharedInfo?.size, via: sharedInfo?.via },
        });
    }
    if (!defsSrc || !pageSrc)
        return null;
    const context = buildPageEditContext({
        page: entry.page,
        module: entry.module,
        l4WorkspaceSrc,
        defsSrc,
        pageSrc,
        sharedSrc,
        userChanges: parseUserChanges(defsSrc),
    });
    if (meta) {
        traceStep(meta, 'context digest built', {
            source: context.contextSource,
            scopes: scopeVocabulary(context),
            routines: context.data.length,
            states: context.surface.states.length,
            handlers: context.surface.handlers.length,
            msgKeys: context.pageMsgKeys.length,
            locales: context.languages,
            canAddText: context.canAddText,
            userChanges: context.userChanges.length,
        });
    }
    return { context, tsRef, defsRef };
}
// ─── hooks ──────────────────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    const entry = JSON.parse(userPrompt);
    const { module, page, layout, ds, request } = entry;
    const meta = { agent: agent.agentName, page };
    traceStep(meta, 'entry', { project: mls.actualProject || 0, module, page, layout, ds, device: entry.device ?? DEFAULT_DEVICE, planOnly: !!entry.planOnly, operations: entry.operations?.length ?? 0, request });
    if (!module || !page || layout == null || ds == null || !request?.trim()) {
        throw new Error(`(${agent.agentName}) entry needs { module, page, layout, ds, request }`);
    }
    const device = entry.device || DEFAULT_DEVICE;
    const planOnly = !!entry.planOnly;
    const preApproved = Array.isArray(entry.operations) ? normalizeOperations2(entry.operations) : [];
    const imageUrl = typeof entry.imageUrl === 'string' ? entry.imageUrl : '';
    const longTermMemory = {
        module, page, layout: String(layout), ds: String(ds), device, request,
        planOnly: String(planOnly),
        ...(imageUrl ? { imageUrl } : {}),
        ...(preApproved.length ? { operations: JSON.stringify(preApproved) } : {}),
    };
    // APPLY — the user already confirmed these operations; the gate would only cost tokens.
    if (preApproved.length) {
        traceStep(meta, 'PHASE = APPLY (gate skipped, operations pre-approved)', { operations: preApproved.map(op => `${op.kind}@${op.scope}`) });
        traceSent(meta, 'apply classifier (vehicle step)', { system: applyPrompt, data: preApproved });
        return [{
                type: 'add-message-ai',
                request: {
                    action: 'addMessageAI',
                    agentName: agent.agentName,
                    inputAI: [
                        { type: 'system', content: applyPrompt },
                        { type: 'human', content: JSON.stringify({ request, operations: preApproved.length }) },
                    ],
                    taskTitle: `Apply visual edit ${page}: ${request.slice(0, 60)}`,
                    threadId: context.message.threadId,
                    userMessage: context.message.content,
                    longTermMemory,
                },
            }];
    }
    // PLAN — run the gate over the digest.
    traceStep(meta, `PHASE = ${planOnly ? 'PLAN (gate only, nothing is written)' : 'LEGACY single-shot (gate then apply)'}`);
    const loaded = await loadEditContext({ module, page, layout, ds, device }, meta);
    if (!loaded)
        throw new Error(`(${agent.agentName}) page not found (needs both .defs.ts and .ts): ${module}/${page}`);
    const { context: editContext } = loaded;
    const human = JSON.stringify({
        request,
        scopeVocabulary: scopeVocabulary(editContext),
        context: editContext,
    });
    traceSent(meta, 'scope gate', { system: gatePrompt, human, data: { request, context: editContext } });
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: gatePrompt },
                { type: 'human', content: human },
            ],
            taskTitle: `Plan visual edit ${page}: ${request.slice(0, 60)}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory,
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const lm = (context.task?.iaCompressed?.longMemory || {});
        const module = lm['module'];
        const page = lm['page'];
        const layout = lm['layout'];
        const ds = lm['ds'];
        const device = lm['device'] || DEFAULT_DEVICE;
        const request = lm['request'] || '';
        const imageUrl = lm['imageUrl'] || '';
        const planOnly = lm['planOnly'] === 'true';
        const meta = { agent: agent.agentName, page, taskId: context.task?.PK };
        if (!module || !page || layout == null || ds == null)
            throw new Error('missing run params in longMemory');
        const base = { module, page, layout, ds, device, request, ...(imageUrl ? { imageUrl } : {}) };
        // APPLY — operations came pre-approved in longMemory; this step's payload carries nothing.
        let preApproved = [];
        try {
            preApproved = lm['operations'] ? normalizeOperations2(JSON.parse(lm['operations'])) : [];
        }
        catch {
            preApproved = [];
        }
        if (preApproved.length) {
            traceVerdict(meta, `APPLY — ${preApproved.length} pre-approved operation(s)`, true, preApproved.map(op => `${op.kind}@${op.scope}: ${op.description}`).join(' | '));
            return traceChildSteps(meta, buildChildSteps(context, step, { ...base, operations: preApproved }));
        }
        // PLAN — read the gate's verdict.
        const payload = step.interaction?.payload?.[0];
        traceReceived(meta, 'scope gate', payload, { verdict: payload?.type === 'result' ? 'REJECTED' : payload?.type === 'flexible' ? 'APPROVED' : 'UNEXPECTED' });
        if (!payload)
            throw new Error('missing gate payload');
        if (payload.type === 'result') {
            const reason = String(payload.result || 'edit request rejected by the scope gate');
            traceVerdict(meta, 'gate rejected — nothing was written', false, reason);
            return [mkFail(context, parentStep, step, hookSequential, reason)];
        }
        if (payload.type !== 'flexible' || !payload.result) {
            traceVerdict(meta, 'gate payload not understood', false, `type=${payload.type}`);
            return [mkFail(context, parentStep, step, hookSequential, 'gate returned an unexpected payload')];
        }
        const operations = normalizeOperations2(payload.result.operations);
        traceVerdict(meta, `operations normalized: ${operations.length} of ${payload.result.operations?.length ?? 0}`, operations.length > 0, operations.map(op => `${op.kind}@${op.scope}: ${op.description}`).join(' | '));
        if (!operations.length) {
            return [mkFail(context, parentStep, step, hookSequential, 'no actionable visual operations were produced from the request')];
        }
        // A scope this page does not own (typically a split page whose target lives in another file) is
        // dropped here rather than sent to a patch that could never anchor it.
        const loaded = await loadEditContext({ module, page, layout, ds, device });
        if (!loaded)
            throw new Error(`page not found: ${module}/${page}`);
        const { valid, unknown } = partitionOperationsByScope(operations, loaded.context);
        if (unknown.length) {
            traceVerdict(meta, `${unknown.length} operation(s) dropped — scope not in this page`, false, `${unknown.map(op => op.scope).join(', ')} (page has: ${scopeVocabulary(loaded.context).join(', ')})`);
        }
        if (!valid.length) {
            const scopes = unknown.map(op => op.scope).join(', ');
            return [mkFail(context, parentStep, step, hookSequential, `the change targets '${scopes}', which is not part of this page (methods: ${scopeVocabulary(loaded.context).join(', ')})`)];
        }
        if (planOnly) {
            traceVerdict(meta, `PLAN ready — ${valid.length} operation(s) returned to the caller, nothing written`, true, valid.map(op => `${op.kind}@${op.scope}`).join(', '));
            return [mkCompleted(context, parentStep, step, hookSequential, `PLAN:${JSON.stringify(valid)}`)];
        }
        traceVerdict(meta, `gate approved — ${valid.length} operation(s)`, true);
        return traceChildSteps(meta, buildChildSteps(context, step, { ...base, operations: valid }));
    }
    catch (error) {
        const msg = `[${agent.agentName}] ${error instanceof Error ? error.message : String(error)}`;
        traceFail({ agent: agent.agentName, page: lmPage(context) }, msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
function lmPage(context) {
    return (context.task?.iaCompressed?.longMemory || {})['page'];
}
/** Log the run shape the orchestrator just scheduled (planId → agent, and what waits on what). */
function traceChildSteps(meta, intents) {
    tracePlan(meta, intents
        .filter(intent => intent.type === 'add-step')
        .map(intent => {
        const step = intent.step;
        return {
            planId: step?.planning?.planId ?? '?',
            agent: step?.agentName ?? '?',
            dependsOn: step?.planning?.dependsOn,
        };
    }));
    return intents;
}
/** Patch the page, then record the intent. The record waits on the patch — and is skipped if it fails. */
function buildChildSteps(context, step, args) {
    const patchPlan = makePlanId('patch', args.page);
    return [
        mkAgentStep(context, step, patchPlan, `Patch: ${args.page}`, 'agentPatchPage', args, [], 'waiting_human_input', 'sequential'),
        mkAgentStep(context, step, makePlanId('record', args.page), `Record change: ${args.page}`, 'agentRecordUserChanges', args, [patchPlan], 'waiting_dependency', 'sequential'),
    ];
}
// ─── prompts ────────────────────────────────────────────────────────────────
// APPLY phase — the user approved the operations in the confirm panel; there is nothing to decide.
const applyPrompt = `
<!-- modelType: classifier -->

The visual edit operations for this page were ALREADY approved by the user. Do not re-evaluate them.
Return ONLY: {"type":"flexible","result":{"status":"ok"}}
Return valid JSON only. No preamble, no markdown fences.
`;
const gatePrompt = `
<!-- modelType: reasoning -->

You are the SCOPE GATE for pointed VISUAL edits of an already-generated page. The human message is a
JSON object { request, scopeVocabulary, context }.

\`context\` describes what this screen IS and what the project HAS:
- \`purpose\`, \`actors\`, \`entity\`, \`presentation\` — what the page is for and for whom.
- \`sections\` — the intent of each region of the screen, its organisms (role / usage / dataSource /
  action) and the render \`method\` that draws it.
- \`data\` — every routine the page can reach: each with \`kind\` (query/command), its \`inputs\`
  (name, source, required) and its \`output.fields\` (name, type). THIS IS THE CLOSED SET of data the
  screen has. A field that is not there does not exist for this page.
- \`surface\` — the states and handlers the page inherits. Also closed.
- \`outline\` — each render method of the page today, with the i18n keys and members it references.
- \`pageMsgKeys\` / \`languages\` / \`canAddText\` — the text vocabulary and whether NEW text can be
  introduced at all (some older pages carry no catalogue of their own).
- \`userChanges\` — visual deviations the user already asked for. Reversing or replacing one of them
  is a NORMAL in-scope edit: emit the operation directly and NEVER ask the user to confirm.
- \`contextSource\` — 'l4-workspace' means the field/routine lists are authoritative; 'page-defs'
  means output fields are unknown, so judge data questions by what the page already renders.

Decide whether the request is a purely VISUAL change realizable with the EXISTING surface.

REJECT (out of scope) ONLY when the request would require ANY of:
- a field, routine, query or command that is not in \`data\`;
- a new state or action, or a change in how data behaves;
- a backend change or a business-rule change;
- something that is not about THIS page (another screen, new navigation, a new permission);
- new visible text when \`canAddText\` is false.

CRITICAL — presentation is ALWAYS in scope. Alignment, spacing, ordering, grouping, sizing, emphasis,
colour, borders, and hiding or showing an element that is ALREADY on the screen never require new
data, so they are never out of scope. There is no structural definition to check against: the change
is applied as markup in the page file, so "the definition has no attribute for it" is NOT a reason to
reject. Do not invent a hypothetical config field and then reject for its absence.

If out of scope, return ONLY:
{"type":"result","result":"a short, specific reason in the user's language explaining what is not possible and why"}

If in scope, return ONLY the typed operations:
{"type":"flexible","result":{"operations":[{"kind":"layout"|"style"|"text"|"visibility","scope":"<render method>","target":"<element/field/action, '' if n/a>","description":"<precise change>"}]}}

- \`kind\`: \`layout\` = position/order/spacing/grouping/size; \`style\` = colour/emphasis/border/shadow;
  \`text\` = a label change using an EXISTING key or a NEW page key (only when \`canAddText\`);
  \`visibility\` = hide or reveal an element that already exists.
- \`scope\` MUST be one of \`scopeVocabulary\` — the method that draws the affected region (use
  \`page\` only when the change is about the page-level arrangement, i.e. the root \`render\`). Pick it
  from \`sections[].method\` and \`outline\`.
- \`description\` is imperative and specific enough to be implemented without re-reading the request.
- One request may produce several operations; never invent data, states or actions.

Return valid JSON only. No preamble, no markdown fences.

## Output format
export type Output =
  | { type: 'flexible'; result: { operations: Array<{ kind: 'layout' | 'style' | 'text' | 'visibility'; scope: string; target: string; description: string }> } }
  | { type: 'result'; result: string };
`;
//#endregion
