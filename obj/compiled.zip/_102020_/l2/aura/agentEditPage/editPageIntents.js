/// <mls fileReference="_102020_/l2/aura/agentEditPage/editPageIntents.ts" enhancement="_blank"/>
// The collab-messages intents agentEditPage emits (add a step, update a step, the prompt of a step). Private to
// this folder: no other agent's intents module is imported (skills/agentCodeIsPrivate.md).
import { EDIT_PAGE_GATE_AGENT_NAME, EDIT_PAGE_PATCH_AGENT_NAME } from '/_102020_/l2/aura/agentEditPage/editPageCore.js';
export function addStep(context, parentStepId, step, bootstrap = false) {
    return {
        type: 'add-step',
        messageId: bootstrap ? '' : context.message.orderAt,
        threadId: context.message.threadId,
        taskId: bootstrap ? '' : context.task?.PK || '',
        parentStepId,
        step,
    };
}
export function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
export function promptReady(context, parentStep, step, hookSequential, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready', args: step.prompt || '', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', hookSequential, parentStepId: parentStep.stepId, systemPrompt, humanPrompt,
        tools: [{ type: 'function', function: tool }],
        toolChoice: { type: 'function', function: { name: tool.name } },
    };
}
function agentStep(agentName, title, planId, args) {
    return {
        type: 'agent', stepId: 0, interaction: null, stepTitle: title, status: 'waiting_human_input', nextSteps: [],
        agentName, prompt: JSON.stringify(args), rags: [],
        planning: { planId, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
export function gateStep(args) {
    return agentStep(EDIT_PAGE_GATE_AGENT_NAME, `Plan the change of ${args.page}`, `editPage-gate-${args.page}`, args);
}
export function patchStep(args) {
    return agentStep(EDIT_PAGE_PATCH_AGENT_NAME, `Change ${args.page}${args.attempt > 1 ? ' (repair)' : ''}`, `editPage-patch-${args.page}-${args.attempt}`, args);
}
