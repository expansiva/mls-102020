/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/genomeUxIo.ts" enhancement="_blank"/>
/**
 * Studio IO of agentGenomeUx: the page list, the project config, the page11 defs, the template, the molecule
 * catalog, the variant defs and the receipts. Everything runs in the browser over `mls.stor`; the decisions live
 * in the pure files (genomeUxCore / genomeUxVariant / genomeUxReceipt).
 *
 * `readGenomeUxPageStatus` is the entry for the select-module status panel (part C): it gives the receipt, the
 * current inputs and the stale verdict of one page of a UX.
 */
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { readStorText, storTextExists, writeStorText } from '/_102020_/l2/agentMaterializeL2/helpers/storText.js';
import { parseL2Page11 } from '/_102020_/l2/agentMaterializeL2/helpers/defs/page11.js';
import { buildD2MoleculeInventory } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.js';
import { d2MoleculeCatalogPort } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeCatalog.js';
import { UX_BESPOKE } from '/_102020_/l2/aura/helpers/uxTemplates.js';
import { GENOME_UX_DEVICES, genomeUxContractInfo, genomeUxEffectiveTemplate, genomeUxExperience, genomeUxGenome, genomeUxPage11Info, genomeUxReceiptInfo, genomeUxRules, genomeUxSharedInfo, genomeUxTemplateInfo, genomeUxUseMolecules, genomeUxVariantInfo, } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
import { genomeUxPageData } from '/_102020_/l2/aura/agentGenomeUx/genomeUxPageData.js';
import { genomeUxCurrentFromTexts, genomeUxStale } from '/_102020_/l2/aura/agentGenomeUx/genomeUxReceipt.js';
/** The text of a stor file, or null when it does not exist or cannot be read. */
export async function readGenomeUxText(info) {
    if (!storTextExists(info))
        return null;
    try {
        return await readStorText(info);
    }
    catch {
        return null;
    }
}
export async function writeGenomeUxText(info, text) {
    await writeStorText(info, text);
}
/** The page ids of the module: the page11 desktop defs, sorted. */
export function listGenomeUxPages(project, module) {
    const folder = `${module}/web/desktop/page11`;
    return Object.values(mls.stor.files)
        .filter(file => file.project === project && file.level === 2 && file.folder === folder && file.extension === '.defs.ts' && file.status !== 'deleted')
        .map(file => file.shortName)
        .sort();
}
/** `config.layouts[N]` of the project, or null when the UX does not exist. */
export async function readGenomeUxLayout(project, layout) {
    const config = await getConfigProject(project);
    const entry = config?.layouts?.[String(layout)];
    return entry && typeof entry === 'object' ? entry : null;
}
let experienceIndexCache = null;
/** `l4/collabux/templates/experienceIndex.json` of 102020, read once per session (as selectUx does). */
export function readGenomeUxExperienceIndex() {
    if (!experienceIndexCache) {
        experienceIndexCache = (async () => {
            const text = await readGenomeUxText({ project: 102020, level: 4, folder: 'collabux/templates', shortName: 'experienceIndex', extension: '.json' });
            if (!text) {
                experienceIndexCache = null;
                return null;
            }
            try {
                return JSON.parse(text);
            }
            catch {
                experienceIndexCache = null;
                return null;
            }
        })();
    }
    return experienceIndexCache;
}
/** The template text of a path: null for a bespoke page; throws when the file is missing. */
export async function readGenomeUxTemplateText(path) {
    if (path === UX_BESPOKE)
        return null;
    const info = genomeUxTemplateInfo(path);
    if (!info)
        throw new Error(`GENOME_UX_TEMPLATE_PATH: ${path}`);
    const text = await readGenomeUxText(info);
    if (text === null || !text.trim())
        throw new Error(`GENOME_UX_TEMPLATE_MISSING: ${path}`);
    return text;
}
/**
 * Everything a page needs before any LLM call: both page11 defs, the UX entry, the effective template with its
 * text, experience and rules. Throws a `GENOME_UX_*` code the model cannot fix (missing defs, missing template,
 * unreadable rules).
 */
export async function loadGenomeUxPageContext(project, module, layout, pageId, layoutEntry) {
    const genome = genomeUxGenome(layout);
    const page11 = {};
    for (const device of GENOME_UX_DEVICES) {
        const source = await readGenomeUxText(genomeUxPage11Info(project, module, pageId, device));
        if (source === null)
            throw new Error(`GENOME_UX_PAGE11_MISSING: ${module}/web/${device}/page11/${pageId}.defs.ts`);
        try {
            page11[device] = { source, definition: parseL2Page11(source).definition };
        }
        catch (error) {
            throw new Error(`GENOME_UX_PAGE11_INVALID: ${device}/${pageId}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    const entry = layoutEntry === undefined ? await readGenomeUxLayout(project, layout) : layoutEntry;
    const page11Template = page11.desktop.definition.template;
    const effective = genomeUxEffectiveTemplate(entry, module, pageId, page11Template.category);
    const text = await readGenomeUxTemplateText(effective.path);
    const experience = effective.path === UX_BESPOKE ? page11Template.experience : genomeUxExperience(effective.path, await readGenomeUxExperienceIndex(), page11Template);
    if (!experience)
        throw new Error(`GENOME_UX_EXPERIENCE_UNKNOWN: ${effective.path}`);
    const rules = genomeUxRules(text);
    if (rules.kind === 'error')
        throw new Error(`GENOME_UX_TEMPLATE_RULES: ${effective.path}: ${rules.message}`);
    const contractSource = await readGenomeUxText(genomeUxContractInfo(project, module, pageId));
    const sharedSource = await readGenomeUxText(genomeUxSharedInfo(project, module, pageId));
    return { project, module, layout, genome, pageId, page11, layoutEntry: entry, useMolecules: genomeUxUseMolecules(entry),
        template: { path: effective.path, isDefault: effective.isDefault, experience, text, rules },
        pageData: { contractSource, sharedSource, data: genomeUxPageData(contractSource, sharedSource) } };
}
/** The molecule catalog inventory of the project (agentDefsL2's discovery: the project or one direct dependency). */
export async function readGenomeUxInventory(project) {
    return buildD2MoleculeInventory(d2MoleculeCatalogPort, project);
}
export async function readGenomeUxReceipt(project, module, genome, pageId) {
    const text = await readGenomeUxText(genomeUxReceiptInfo(project, module, genome, pageId));
    if (!text?.trim())
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
export async function readGenomeUxVariants(project, module, genome, pageId) {
    return {
        desktop: await readGenomeUxText(genomeUxVariantInfo(project, module, pageId, 'desktop', genome)),
        mobile: await readGenomeUxText(genomeUxVariantInfo(project, module, pageId, 'mobile', genome)),
    };
}
/** Both variant defs, then the receipt (last: a receipt exists only for a pair that was fully written). */
export async function writeGenomeUxPage(context, variants, receipt) {
    for (const device of GENOME_UX_DEVICES)
        await writeGenomeUxText(genomeUxVariantInfo(context.project, context.module, context.pageId, device, context.genome), variants[device]);
    await writeGenomeUxText(genomeUxReceiptInfo(context.project, context.module, context.genome, context.pageId), `${JSON.stringify(receipt, null, 2)}\n`);
}
/**
 * The stale verdict of one page of UX N from what is on disk now. `catalogHash` (from `readGenomeUxInventory`)
 * is compared only when given. Missing page11 or template → `error` with the code.
 */
export async function readGenomeUxPageStatus(project, module, layout, pageId, options = {}) {
    try {
        const context = await loadGenomeUxPageContext(project, module, layout, pageId, options.layoutEntry);
        const [receipt, variants] = await Promise.all([
            readGenomeUxReceipt(project, module, context.genome, pageId),
            readGenomeUxVariants(project, module, context.genome, pageId),
        ]);
        const current = await genomeUxCurrentFromTexts({
            templatePath: context.template.path, templateText: context.template.text, rules: context.template.rules,
            page11: { desktop: context.page11.desktop.source, mobile: context.page11.mobile.source },
            pageData: { contract: context.pageData.contractSource, shared: context.pageData.sharedSource },
            variants, useMolecules: context.useMolecules,
            ...(options.catalogHash === undefined ? {} : { catalogHash: options.catalogHash }),
        });
        return { kind: 'ok', receipt, current, verdict: genomeUxStale(receipt, current), context };
    }
    catch (error) {
        return { kind: 'error', diagnostic: error instanceof Error ? error.message : String(error) };
    }
}
