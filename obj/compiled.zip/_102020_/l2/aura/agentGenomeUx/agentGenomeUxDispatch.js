/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/agentGenomeUxDispatch.ts" enhancement="_blank"/>
import { addD2Step, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { GENOME_UX_DISPATCH_AGENT_NAME, GENOME_UX_FOLDER, genomeUxGenome, genomeUxUseMolecules } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
import { listGenomeUxPages, readGenomeUxInventory, readGenomeUxLayout, readGenomeUxPageStatus } from '/_102020_/l2/aura/agentGenomeUx/genomeUxIo.js';
import { genomeUxCompletionSteps, genomeUxPageStep } from '/_102020_/l2/aura/agentGenomeUx/genomeUxRun.js';
export function createAgent() {
    return { agentName: GENOME_UX_DISPATCH_AGENT_NAME, agentProject: 102020, agentFolder: GENOME_UX_FOLDER, agentDescription: 'Plan one genome UX worker per pending page', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    try {
        const entry = JSON.parse(args || step.prompt || '{}');
        const { project, module, layout } = entry;
        const genome = genomeUxGenome(layout);
        const layoutEntry = await readGenomeUxLayout(project, layout);
        if (!layoutEntry)
            throw new Error(`GENOME_UX_LAYOUT_MISSING: layouts["${layout}"] is not in the project config`);
        const all = listGenomeUxPages(project, module);
        if (!all.length)
            throw new Error(`GENOME_UX_PAGES_MISSING: no page11 defs in ${module}/web/desktop/page11`);
        const requested = entry.pages ?? [];
        const absent = requested.filter(page => !all.includes(page));
        if (absent.length)
            throw new Error(`GENOME_UX_PAGES_UNKNOWN: ${absent.join(', ')} (available: ${all.join(', ')})`);
        const runPages = requested.length ? all.filter(page => requested.includes(page)) : all;
        const run = { project, module, layout, runPages, subset: requested.length > 0, materialize: entry.materialize === true };
        // The catalog counts for reuse only when the UX uses molecules; an unreadable catalog leaves the decision to the worker.
        let catalogHash;
        if (genomeUxUseMolecules(layoutEntry)) {
            try {
                catalogHash = (await readGenomeUxInventory(project)).sourceHash;
            }
            catch {
                catalogHash = undefined;
            }
        }
        const pending = [];
        const reasons = [];
        for (const pageId of runPages) {
            if (entry.force) {
                pending.push(pageId);
                continue;
            }
            const status = await readGenomeUxPageStatus(project, module, layout, pageId, { layoutEntry, ...(catalogHash === undefined ? {} : { catalogHash }) });
            if (status.kind === 'ok' && !status.verdict.stale)
                continue;
            pending.push(pageId);
            reasons.push(`${pageId}: ${status.kind === 'ok' ? status.verdict.reasons.join(', ') : status.diagnostic}`);
        }
        console.info(`[agentGenomeUx] ${module} UX ${layout} (${genome}): ${pending.length}/${runPages.length} page(s) to generate`, reasons);
        if (!pending.length) {
            return [...genomeUxCompletionSteps(run).map(item => addD2Step(context, parentStep.stepId, item)),
                updateD2Status(context, parentStep, step, hookSequential, 'completed', `All ${runPages.length} page(s) of ${genome} are fresh; nothing to generate.`)];
        }
        const workers = pending.map(pageId => addD2Step(context, parentStep.stepId, genomeUxPageStep({ ...run, pageId, stage: 'groups', attempt: 1 })));
        return [...workers, updateD2Status(context, parentStep, step, hookSequential, 'completed', `Planned ${workers.length} ${genome} page(s); ${runPages.length - pending.length} reused. ${reasons.join(' | ')}`)];
    }
    catch (error) {
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
