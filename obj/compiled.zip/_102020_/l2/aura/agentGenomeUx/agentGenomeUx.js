/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/agentGenomeUx.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { addD2Step, d2Result, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { GENOME_UX_AGENT_NAME, GENOME_UX_DISPATCH_AGENT_NAME, GENOME_UX_FOLDER, GENOME_UX_USAGE, genomeUxGenome, parseGenomeUxEntry } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
import '/_102020_/l2/aura/agentGenomeUx/agentGenomeUxDispatch.js';
import '/_102020_/l2/aura/agentGenomeUx/agentGenomeUxPage.js';
export function createAgent() {
    return { agentName: GENOME_UX_AGENT_NAME, agentProject: 102020, agentFolder: GENOME_UX_FOLDER,
        agentDescription: 'Generate the UX N variant (page{N}1) of a module: page11 with the UX template and molecules chosen for it', visibility: 'public',
        beforePromptImplicit, beforePromptStep };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const project = Number(mls.actualProject || 0);
    const parsed = parseGenomeUxEntry(userPrompt || context.message.content || '');
    const createTask = (human, title, memory) => ({
        type: 'add-message-ai', skipRootLLM: true,
        request: { action: 'addMessageAI', agentName: agent.agentName,
            inputAI: [{ type: 'system', content: 'agentGenomeUx deterministic bootstrap. The root model is disabled.' }, { type: 'human', content: human }],
            taskTitle: title, threadId: context.message.threadId, userMessage: context.message.content,
            longTermMemory: { taskName: GENOME_UX_AGENT_NAME, flowName: GENOME_UX_AGENT_NAME, ...memory },
        },
    });
    if (parsed.kind === 'refusal' || !Number.isSafeInteger(project) || project <= 0) {
        const diagnostic = parsed.kind === 'refusal' ? parsed.diagnostic : `GENOME_UX_PROJECT: the current project is unavailable. ${GENOME_UX_USAGE}`;
        return [createTask(diagnostic, 'agentGenomeUx status', { statusOnly: 'true' }), addD2Step(context, 1, d2Result('Status', diagnostic, 'status'), true)];
    }
    const { entry } = parsed;
    const genome = genomeUxGenome(entry.layout);
    const dispatch = {
        type: 'agent', stepId: 0, interaction: null, stepTitle: `UX ${entry.layout} (${genome}) of ${entry.module}`, status: 'waiting_human_input', nextSteps: [],
        agentName: GENOME_UX_DISPATCH_AGENT_NAME, prompt: JSON.stringify({ project, ...entry }), rags: [],
        planning: { planId: 'genomeUx-dispatch', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    const title = `genome UX ${entry.layout} of ${entry.module}${entry.pages.length ? ` (${entry.pages.join(', ')})` : ''}`;
    return [createTask(JSON.stringify(entry), title, { project: String(project), module: entry.module, layout: String(entry.layout), genome }), addD2Step(context, 1, dispatch, true)];
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential) {
    if (step.stepId === 1 && context.task?.iaCompressed?.longMemory?.flowName === GENOME_UX_AGENT_NAME) {
        return [updateD2Status(context, parentStep, step, hookSequential, 'completed', 'Deterministic message bootstrap completed.')];
    }
    return [updateD2Status(context, parentStep, step, hookSequential, 'failed', `agentGenomeUx steps run through ${GENOME_UX_DISPATCH_AGENT_NAME} and agentGenomeUxPage.`)];
}
