/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/genomeUxReceipt.ts" enhancement="_blank"/>
/**
 * The receipt of one page of UX N (`l2/<module>/pipeline/agentGenomeUx/page{N}1/<pageId>.json`, page11 for the base) and the "stale"
 * verdict of a page from its current inputs. A fresh page is reused without an LLM call; the status panel of
 * select-module (part C) reads the same verdict. See README.md for the contract.
 *
 * page11 counts only through what a variant inherits from it — intent, sections and organisms
 * (`page11ContractHashes`): a page11 whose template or molecules change (base mode, agentDefsL2) does not make a
 * UX N variant stale. In base mode (UX 1) the written defs ARE page11, so `variantHashes` vs the current page11
 * says whether someone rewrote it afterwards.
 *
 * PURE — no `mls.*`, no file system (hashing uses Web Crypto, as helpers/hash.ts does).
 */
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { parseL2Page11 } from '/_102020_/l2/agentMaterializeL2/helpers/defs/page11.js';
import { defsWithoutHistory } from '/_102020_/l2/helpers/defsHistory/defsHistory.js';
import { GENOME_UX_RECEIPT_VERSION } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
/** The stale verdict: fresh only when the receipt matches every current input and both written defs are untouched. */
export function genomeUxStale(receipt, current) {
    if (!receipt || receipt.schemaVersion !== GENOME_UX_RECEIPT_VERSION)
        return { stale: true, reasons: ['receipt'] };
    const reasons = [];
    const devices = ['desktop', 'mobile'];
    if (devices.some(device => current.page11ContractHashes[device] !== receipt.page11ContractHashes?.[device]))
        reasons.push('page11');
    if (current.pageDataHash !== receipt.pageDataHash)
        reasons.push('pageData');
    if (current.templatePath !== receipt.template.path || current.templateHash !== receipt.template.hash)
        reasons.push('template');
    if (current.rulesHash !== receipt.template.rulesHash)
        reasons.push('rules');
    if (current.useMolecules !== receipt.useMolecules)
        reasons.push('useMolecules');
    else if (current.useMolecules && current.catalogHash !== undefined && current.catalogHash !== receipt.catalogHash)
        reasons.push('catalog');
    if (devices.some(device => current.variantHashes[device] !== receipt.variantHashes[device]))
        reasons.push('variant');
    // Base mode: page11 rewritten afterwards (`variant`/`page11`) while it still carries the applied template on both
    // devices is agentDefsL2 regenerating the page and keeping the choice (TASK-102020-genome-ux-4, part B) —
    // accepted, not stale; otherwise "Generate" would re-choose the molecules over agentDefsL2's answer. A page11
    // back on another template stays stale.
    const keptTemplate = devices.every(device => current.page11Templates[device] === receipt.template.path);
    const accepted = receipt.layout === 1 && keptTemplate && !reasons.includes('template')
        ? reasons.filter(reason => reason !== 'variant' && reason !== 'page11') : reasons;
    return { stale: accepted.length > 0, reasons: accepted };
}
/** JSON with the object keys sorted (arrays keep their order): the same content always hashes the same. */
function stableJson(value) {
    if (Array.isArray(value))
        return `[${value.map(stableJson).join(',')}]`;
    if (value && typeof value === 'object') {
        const row = value;
        return `{${Object.keys(row).sort().filter(key => row[key] !== undefined).map(key => `${JSON.stringify(key)}:${stableJson(row[key])}`).join(',')}}`;
    }
    return JSON.stringify(value);
}
/**
 * sha256 of what a variant inherits from a page11 defs text: `intent`, `sections` and `organisms` (with their
 * intents), key order ignored. `template` and `molecules` are left out, so a page11 that only gets another template
 * or other molecules hashes the same. A text outside the page11 grammar hashes its raw text (always "changed").
 */
export async function genomeUxPage11ContractHash(page11Text) {
    let definition;
    // The Studio edit history (helpers/defsHistory) is not part of the contract, parsed or not.
    const text = defsWithoutHistory(page11Text);
    try {
        definition = parseL2Page11(text).definition;
    }
    catch {
        return sha256Text(`unparsed:${text}`);
    }
    return sha256Text(stableJson({ intent: definition.intent, sections: definition.sections, organisms: definition.organisms }));
}
/** The `template.category` of a page11 text, null when it does not parse. */
export function genomeUxPage11Template(page11Text) {
    try {
        return parseL2Page11(defsWithoutHistory(page11Text)).definition.template.category;
    }
    catch {
        return null;
    }
}
/** sha256 of the normalized rules (stable key order), null for none or an unreadable block. */
export async function genomeUxRulesHash(rules) {
    if (rules.kind !== 'rules')
        return null;
    const axes = Object.fromEntries(Object.keys(rules.rules.axes).sort().map(key => [key, rules.rules.axes[key]]));
    return sha256Text(JSON.stringify({ axes, prefer: [...rules.rules.prefer].sort(), forbid: [...rules.rules.forbid].sort() }));
}
/** sha256 of the page data texts; a missing file hashes differently from an empty one. */
export function genomeUxPageDataHash(texts) {
    return sha256Text(JSON.stringify([texts.contract, texts.shared]));
}
export async function genomeUxCurrentFromTexts(texts) {
    // In base mode the variant IS page11: its Studio edit history is not a change of the variant.
    const hashOrNull = async (value) => value === null ? null : sha256Text(defsWithoutHistory(value));
    const contractOrNull = async (value) => value === null ? null : genomeUxPage11ContractHash(value);
    return {
        templatePath: texts.templatePath,
        templateHash: await sha256Text(texts.templateText ?? ''),
        rulesHash: await genomeUxRulesHash(texts.rules),
        page11ContractHashes: { desktop: await contractOrNull(texts.page11.desktop), mobile: await contractOrNull(texts.page11.mobile) },
        page11Templates: {
            desktop: texts.page11.desktop === null ? null : genomeUxPage11Template(texts.page11.desktop),
            mobile: texts.page11.mobile === null ? null : genomeUxPage11Template(texts.page11.mobile),
        },
        pageDataHash: await genomeUxPageDataHash(texts.pageData),
        useMolecules: texts.useMolecules,
        ...(texts.catalogHash === undefined ? {} : { catalogHash: texts.useMolecules ? texts.catalogHash : null }),
        variantHashes: { desktop: await hashOrNull(texts.variants.desktop), mobile: await hashOrNull(texts.variants.mobile) },
    };
}
export async function buildGenomeUxReceipt(input) {
    return {
        schemaVersion: GENOME_UX_RECEIPT_VERSION,
        project: input.project, module: input.module, layout: input.layout, genome: input.genome, pageId: input.pageId,
        template: {
            path: input.template.path, experience: input.template.experience, isDefault: input.template.isDefault,
            hash: await sha256Text(input.template.text ?? ''),
            rulesHash: await genomeUxRulesHash(input.template.rules),
            rules: input.template.rules.kind === 'rules' ? input.template.rules.rules : null,
        },
        page11ContractHashes: { desktop: await genomeUxPage11ContractHash(input.page11.desktop), mobile: await genomeUxPage11ContractHash(input.page11.mobile) },
        pageDataHash: await genomeUxPageDataHash(input.pageData),
        useMolecules: input.useMolecules,
        catalogHash: input.useMolecules ? input.catalogHash : null,
        moleculeHashes: input.moleculeHashes,
        selectedGroups: input.selectedGroups,
        dropped: input.dropped,
        variantHashes: { desktop: await sha256Text(input.variants.desktop), mobile: await sha256Text(input.variants.mobile) },
        createdAt: (input.now ?? new Date()).toISOString(),
    };
}
