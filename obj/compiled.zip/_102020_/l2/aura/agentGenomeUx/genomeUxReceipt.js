/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/genomeUxReceipt.ts" enhancement="_blank"/>
/**
 * The receipt of one variant page (`l2/<module>/pipeline/agentGenomeUx/page{N}1/<pageId>.json`) and the "stale"
 * verdict of a page from its current inputs. A fresh page is reused without an LLM call; the status panel of
 * select-module (part C) reads the same verdict. See README.md for the contract.
 *
 * PURE — no `mls.*`, no file system (hashing uses Web Crypto, as helpers/hash.ts does).
 */
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { GENOME_UX_RECEIPT_VERSION } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
/** The stale verdict: fresh only when the receipt matches every current input and both written defs are untouched. */
export function genomeUxStale(receipt, current) {
    if (!receipt || receipt.schemaVersion !== GENOME_UX_RECEIPT_VERSION)
        return { stale: true, reasons: ['receipt'] };
    const reasons = [];
    const devices = ['desktop', 'mobile'];
    if (devices.some(device => current.page11Hashes[device] !== receipt.page11Hashes[device]))
        reasons.push('page11');
    if (current.pageDataHash !== receipt.pageDataHash)
        reasons.push('pageData');
    if (current.templatePath !== receipt.template.path || current.templateHash !== receipt.template.hash)
        reasons.push('template');
    if (current.rulesHash !== receipt.template.rulesHash)
        reasons.push('rules');
    if (current.useMolecules !== receipt.useMolecules)
        reasons.push('useMolecules');
    else if (current.useMolecules && current.catalogHash !== undefined && current.catalogHash !== receipt.catalogHash)
        reasons.push('catalog');
    if (devices.some(device => current.variantHashes[device] !== receipt.variantHashes[device]))
        reasons.push('variant');
    return { stale: reasons.length > 0, reasons };
}
/** sha256 of the normalized rules (stable key order), null for none or an unreadable block. */
export async function genomeUxRulesHash(rules) {
    if (rules.kind !== 'rules')
        return null;
    const axes = Object.fromEntries(Object.keys(rules.rules.axes).sort().map(key => [key, rules.rules.axes[key]]));
    return sha256Text(JSON.stringify({ axes, prefer: [...rules.rules.prefer].sort(), forbid: [...rules.rules.forbid].sort() }));
}
/** sha256 of the page data texts; a missing file hashes differently from an empty one. */
export function genomeUxPageDataHash(texts) {
    return sha256Text(JSON.stringify([texts.contract, texts.shared]));
}
export async function genomeUxCurrentFromTexts(texts) {
    const hashOrNull = async (value) => value === null ? null : sha256Text(value);
    return {
        templatePath: texts.templatePath,
        templateHash: await sha256Text(texts.templateText ?? ''),
        rulesHash: await genomeUxRulesHash(texts.rules),
        page11Hashes: { desktop: await hashOrNull(texts.page11.desktop), mobile: await hashOrNull(texts.page11.mobile) },
        pageDataHash: await genomeUxPageDataHash(texts.pageData),
        useMolecules: texts.useMolecules,
        ...(texts.catalogHash === undefined ? {} : { catalogHash: texts.useMolecules ? texts.catalogHash : null }),
        variantHashes: { desktop: await hashOrNull(texts.variants.desktop), mobile: await hashOrNull(texts.variants.mobile) },
    };
}
export async function buildGenomeUxReceipt(input) {
    return {
        schemaVersion: GENOME_UX_RECEIPT_VERSION,
        project: input.project, module: input.module, layout: input.layout, genome: input.genome, pageId: input.pageId,
        template: {
            path: input.template.path, experience: input.template.experience, isDefault: input.template.isDefault,
            hash: await sha256Text(input.template.text ?? ''),
            rulesHash: await genomeUxRulesHash(input.template.rules),
            rules: input.template.rules.kind === 'rules' ? input.template.rules.rules : null,
        },
        page11Hashes: { desktop: await sha256Text(input.page11.desktop), mobile: await sha256Text(input.page11.mobile) },
        pageDataHash: await genomeUxPageDataHash(input.pageData),
        useMolecules: input.useMolecules,
        catalogHash: input.useMolecules ? input.catalogHash : null,
        moleculeHashes: input.moleculeHashes,
        selectedGroups: input.selectedGroups,
        dropped: input.dropped,
        variantHashes: { desktop: await sha256Text(input.variants.desktop), mobile: await sha256Text(input.variants.mobile) },
        createdAt: (input.now ?? new Date()).toISOString(),
    };
}
