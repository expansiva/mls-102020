/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/genomeUxCore.ts" enhancement="_blank"/>
/**
 * Identity, entry, paths, template and rules of agentGenomeUx (TASK-102020-genome-ux-3, part A).
 *
 * A genome UX N of a module is the page folder `page{N}1` (UX 1 is page11 itself). For every page the agent
 * writes `web/<device>/page{N}1/<page>.defs.ts` on both devices, in the page11 grammar, with the template of
 * the UX and the molecules chosen again for it. Everything it owns besides those defs lives under
 * `l2/<module>/pipeline/agentGenomeUx/page{N}1/` (receipts and raw LLM answers), never inside `page{N}1`.
 *
 * UX 1 is the **base mode** (TASK-102020-genome-ux-4): the output is page11 itself, rewritten in place with the
 * template chosen in `layouts["1"].templates.pages` and the molecules chosen again (intent, sections and organisms
 * unchanged). A page with no choice (or with the page11 template chosen) is a no-op.
 *
 * PURE — no `mls.*`, no file system.
 */
import { getPageTemplate, uxBaseTemplateChoice, uxPageKey, uxTemplatePath } from '/_102020_/l2/aura/helpers/uxTemplates.js';
import { extractTemplateRules, validateTemplateRules } from '/_102020_/l2/aura/helpers/templateRules.js';
export const GENOME_UX_AGENT_NAME = 'agentGenomeUx';
export const GENOME_UX_DISPATCH_AGENT_NAME = 'agentGenomeUxDispatch';
export const GENOME_UX_PAGE_AGENT_NAME = 'agentGenomeUxPage';
export const GENOME_UX_FOLDER = 'aura/agentGenomeUx';
/**
 * Bumped whenever the receipt shape or the way a variant is built changes: an older receipt is stale.
 * v3 (2026-10-23): `page11Hashes` (the whole page11 text) → `page11ContractHashes` (only intent, sections and
 * organisms: what a variant inherits), and UX 1 (base mode, page11 rewritten in place) has receipts too.
 */
export const GENOME_UX_RECEIPT_VERSION = '2026-10-23-genome-ux-v3';
/** The result step every run ends with when all its pages are fresh; the materialize step follows it. */
export const GENOME_UX_DONE_PLAN_ID = 'genomeUx-done';
export const GENOME_UX_MATERIALIZE_PLAN_ID = 'genomeUx-materialize';
export const GENOME_UX_DEVICES = ['desktop', 'mobile'];
const MODULE = /^[a-z][A-Za-z0-9]{0,59}$/u;
const PAGE_ID = /^[a-z][A-Za-z0-9_]{0,59}$/u;
export const GENOME_UX_USAGE = '@@agentGenomeUx {"module":"<lowerCamel>","layout":N,"pages":["<pageId>"],"materialize":true} — N from 1 to 9 (1 = base mode: page11 rewritten with the template chosen for UX 1).';
/** `_102047_/l2/m/web/desktop/page11/foo.defs.ts`, `foo.ts` or `foo` → `foo`. */
export function genomeUxPageShortName(value) {
    return (value.split('/').pop() ?? '').replace(/\.defs\.ts$/u, '').replace(/\.ts$/u, '');
}
export function parseGenomeUxEntry(value) {
    const text = String(value || '').replace(/@@\s*(?:_102020_\/l2\/aura\/agentGenomeUx\/)?agentGenomeUx/giu, ' ').trim();
    let raw;
    try {
        raw = JSON.parse(text || '{}');
    }
    catch {
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_JSON: the entry must be a JSON object. ${GENOME_UX_USAGE}` };
    }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_JSON: the entry must be a JSON object. ${GENOME_UX_USAGE}` };
    const row = raw;
    const unknown = Object.keys(row).find(key => !['module', 'layout', 'pages', 'materialize', 'force'].includes(key));
    if (unknown)
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_KEY: unknown key ${unknown}. ${GENOME_UX_USAGE}` };
    const module = typeof row.module === 'string' ? row.module.trim() : '';
    if (!MODULE.test(module))
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_MODULE: module must be lowerCamel, without a path. ${GENOME_UX_USAGE}` };
    const layout = typeof row.layout === 'string' && /^\d+$/u.test(row.layout) ? Number(row.layout) : row.layout;
    if (!genomeUxLayoutValid(layout))
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_LAYOUT: layout must be an integer from 1 to 9. ${GENOME_UX_USAGE}` };
    if (row.pages !== undefined && !Array.isArray(row.pages))
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_PAGES: pages must be a list of page ids. ${GENOME_UX_USAGE}` };
    const pages = [...new Set((row.pages ?? []).filter((item) => typeof item === 'string' && !!item).map(genomeUxPageShortName))];
    if (pages.some(page => !PAGE_ID.test(page)))
        return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_PAGES: pages must be page ids. ${GENOME_UX_USAGE}` };
    for (const key of ['materialize', 'force']) {
        if (row[key] !== undefined && typeof row[key] !== 'boolean')
            return { kind: 'refusal', diagnostic: `GENOME_UX_ENTRY_${key.toUpperCase()}: ${key} must be a boolean. ${GENOME_UX_USAGE}` };
    }
    return { kind: 'run', entry: { module, layout, pages, materialize: row.materialize === true, force: row.force === true } };
}
/** The UX numbers the agent accepts: 1 (base mode, page11) to 9. */
export function genomeUxLayoutValid(layout) {
    return typeof layout === 'number' && Number.isInteger(layout) && layout >= 1 && layout <= 9;
}
/** UX 1 is the base: its output is page11 itself, the folder agentDefsL2 writes. */
export function genomeUxIsBase(layout) {
    return layout === 1;
}
/** UX N → `page{N}1`; UX 1 → `page11` (base mode: the agent rewrites page11 in place). */
export function genomeUxGenome(layout) {
    if (!genomeUxLayoutValid(layout))
        throw new Error(`GENOME_UX_LAYOUT: ${layout}`);
    return `page${layout}1`;
}
/**
 * Base mode: whether a page has work to do without looking at a receipt — the UX 1 choice exists and differs
 * from the page11 `template.category`. A page with no choice (or the page11 template chosen) is a no-op.
 */
export function genomeUxBaseChoice(layout, module, pageId, page11Template) {
    return uxBaseTemplateChoice(layout, uxPageKey(module, pageId), page11Template);
}
// ─── paths ─────────────────────────────────────────────────────────────────────
export function genomeUxPage11Info(project, module, pageId, device) {
    return { project, level: 2, folder: `${module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' };
}
/** The page's data contract (row types and routes): `l2/<module>/web/contracts/<page>.defs.ts`. */
export function genomeUxContractInfo(project, module, pageId) {
    return { project, level: 2, folder: `${module}/web/contracts`, shortName: pageId, extension: '.defs.ts' };
}
/** The page's shared defs (states and the organisms they feed): `l2/<module>/web/shared/<page>.defs.ts`. */
export function genomeUxSharedInfo(project, module, pageId) {
    return { project, level: 2, folder: `${module}/web/shared`, shortName: pageId, extension: '.defs.ts' };
}
export function genomeUxVariantInfo(project, module, pageId, device, genome) {
    return { project, level: 2, folder: `${module}/web/${device}/${genome}`, shortName: pageId, extension: '.defs.ts' };
}
/** The fileReference a variant defs carries (and the materializer checks): `_<p>_/l2/<m>/web/<device>/<genome>/<page>.defs.ts`. */
export function genomeUxVariantReference(project, module, pageId, device, genome) {
    return `_${project}_/l2/${module}/web/${device}/${genome}/${pageId}.defs.ts`;
}
/** Everything the agent owns in a module: `l2/<module>/pipeline/agentGenomeUx/<genome>/`. */
export function genomeUxOwnedFolder(module, genome) {
    return `${module}/pipeline/agentGenomeUx/${genome}`;
}
/** The receipt of one page: `l2/<module>/pipeline/agentGenomeUx/<genome>/<pageId>.json`. */
export function genomeUxReceiptInfo(project, module, genome, pageId) {
    return { project, level: 2, folder: genomeUxOwnedFolder(module, genome), shortName: pageId, extension: '.json' };
}
/** The raw LLM answers: `l2/<module>/pipeline/agentGenomeUx/<genome>/responses/<pageId>-<stage>-<attempt>.json`. */
export function genomeUxResponsesFolder(module, genome) {
    return `${genomeUxOwnedFolder(module, genome)}/responses`;
}
/** `_102020_/l4/collabux/templates/<category>/<file>.md` → its stor file, or null when the path is not a `.md` file reference. */
export function genomeUxTemplateInfo(templatePath) {
    const match = /^\/?_(\d+)_\/l(\d)\/(.+)\/([^/]+)\.md$/u.exec(String(templatePath || '').trim());
    if (!match || match[3].split('/').some(part => !part || part === '..'))
        return null;
    return { project: Number(match[1]), level: Number(match[2]), folder: match[3], shortName: match[4], extension: '.md' };
}
// ─── template ──────────────────────────────────────────────────────────────────
/**
 * The template of the page in UX N: `layouts[N].templates.pages["<module>/<page>"]` when the UX chose one,
 * the page11 `template.category` otherwise (phase 1, helpers/uxTemplates.ts).
 */
export function genomeUxEffectiveTemplate(layout, module, pageId, page11Template) {
    const chosen = getPageTemplate(layout, uxPageKey(module, pageId));
    return chosen ? { path: chosen, isDefault: chosen === page11Template } : { path: page11Template, isDefault: true };
}
/** `useMolecules` of `layouts[N]`; an absent key means true. */
export function genomeUxUseMolecules(layout) {
    return layout?.useMolecules !== false;
}
/**
 * The experience name written in `template.experience`: the experienceIndex entry of that file, else the page11
 * experience when the template is the page11 one, else the file name when it is not a legacy `pageNN.md`.
 */
export function genomeUxExperience(templatePath, index, page11) {
    for (const entries of Object.values(index?.categories ?? {})) {
        if (!Array.isArray(entries))
            continue;
        const entry = entries.find(item => item && typeof item.file === 'string' && uxTemplatePath(item.file) === templatePath);
        if (entry?.experience)
            return entry.experience;
    }
    if (templatePath === page11.category && page11.experience)
        return page11.experience;
    const name = genomeUxTemplateInfo(templatePath)?.shortName ?? '';
    return name && !/^page\d\d$/u.test(name) ? name : null;
}
/**
 * The `## Molecule rules` of a template (phase 2, helpers/templateRules.ts). A legacy `pageNN.md` (or a bespoke
 * page, `markdown` null) has none: no restriction. `problems` are the validator's findings against the catalog
 * group ids (when given); they do not stop the run — `forbid` is applied as written.
 */
export function genomeUxRules(markdown, groupIds) {
    if (markdown === null)
        return { kind: 'none' };
    const extracted = extractTemplateRules(markdown);
    if (extracted.kind !== 'rules')
        return extracted;
    const raw = extracted.rules;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return { kind: 'error', message: 'the rules must be a JSON object' };
    const list = (value) => Array.isArray(value) && value.every(item => typeof item === 'string') ? [...new Set(value)] : value === undefined ? [] : null;
    const prefer = list(raw.groups?.prefer);
    const forbid = list(raw.groups?.forbid);
    if (!prefer || !forbid)
        return { kind: 'error', message: 'groups.prefer and groups.forbid must be lists of group ids' };
    const axes = {};
    if (raw.axes && typeof raw.axes === 'object' && !Array.isArray(raw.axes)) {
        for (const [axis, axisValue] of Object.entries(raw.axes))
            if (typeof axisValue === 'string')
                axes[axis] = axisValue;
    }
    const problems = groupIds ? validateTemplateRules(extracted.rules, undefined, groupIds) : [];
    return { kind: 'rules', rules: { axes, prefer, forbid }, problems };
}
/** `groupviewtable--ml-data-table` → `groupviewtable` (the group, lower case). */
export function genomeUxTagGroup(tag) {
    const at = tag.indexOf('--');
    return (at < 0 ? tag : tag.slice(0, at)).toLowerCase();
}
/** Whether a group id (`groupViewTable`) or a tag (`groupviewtable--ml-x`) falls in `forbid`, ignoring case. */
export function genomeUxForbidden(groupOrTag, forbid) {
    const group = genomeUxTagGroup(groupOrTag);
    return forbid.some(item => item.toLowerCase() === group);
}
