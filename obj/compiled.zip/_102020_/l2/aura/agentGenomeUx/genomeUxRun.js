/// <mls fileReference="_102020_/l2/aura/agentGenomeUx/genomeUxRun.ts" enhancement="_blank"/>
import { d2Result } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { GENOME_UX_DEVICES, GENOME_UX_DONE_PLAN_ID, GENOME_UX_MATERIALIZE_PLAN_ID, GENOME_UX_PAGE_AGENT_NAME, genomeUxGenome, genomeUxLayoutValid } from '/_102020_/l2/aura/agentGenomeUx/genomeUxCore.js';
import { buildGenomeUxVariant, renderGenomeUxDefs } from '/_102020_/l2/aura/agentGenomeUx/genomeUxVariant.js';
import { buildGenomeUxReceipt } from '/_102020_/l2/aura/agentGenomeUx/genomeUxReceipt.js';
import { readGenomeUxPagePending, writeGenomeUxPage } from '/_102020_/l2/aura/agentGenomeUx/genomeUxIo.js';
const PAGE_ID = /^[a-z][A-Za-z0-9_]{0,59}$/u;
const MODULE = /^[a-z][A-Za-z0-9]{0,59}$/u;
export function parseGenomeUxPageArgs(raw) {
    let value;
    try {
        value = JSON.parse(raw);
    }
    catch {
        throw new Error('GENOME_UX_ARGS_INVALID');
    }
    const args = value;
    if (!args || typeof args !== 'object' || !Number.isSafeInteger(args.project) || args.project <= 0 || !MODULE.test(String(args.module))
        || !genomeUxLayoutValid(args.layout) || !PAGE_ID.test(String(args.pageId))
        || !Array.isArray(args.runPages) || !['groups', 'decision'].includes(args.stage) || ![1, 2].includes(args.attempt))
        throw new Error('GENOME_UX_ARGS_INVALID');
    if (args.stage === 'decision' && !args.selectedGroups)
        throw new Error('GENOME_UX_GROUPS_MISSING');
    return args;
}
/** The worker step of one page (or its next stage / repair). */
export function genomeUxPageStep(args) {
    return {
        type: 'agent', stepId: 0, interaction: null, stepTitle: `UX ${args.layout} ${args.pageId} ${args.stage}${args.attempt === 2 ? ' (repair)' : ''}`,
        status: 'waiting_human_input', nextSteps: [], agentName: GENOME_UX_PAGE_AGENT_NAME, prompt: JSON.stringify(args), rags: [],
        planning: { planId: `genomeUx-${args.pageId}-${args.stage}-${args.attempt}`, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
    };
}
/**
 * Builds, validates and writes both variant defs and then the receipt. `molecules` null → no `molecules` key
 * (useMolecules false). Nothing is written unless both devices render and read back in the page11 grammar.
 * Base mode: `context.genome` is page11, so page11 itself is rewritten (fileReference `web/<device>/page11/<page>`).
 */
export async function finalizeGenomeUxPage(context, molecules, meta) {
    const template = { category: context.template.path, experience: context.template.experience };
    const variants = {};
    for (const device of GENOME_UX_DEVICES) {
        const page11 = context.page11[device].definition;
        const definition = buildGenomeUxVariant(page11, template, molecules ? molecules[device] : null);
        variants[device] = renderGenomeUxDefs({ project: context.project, module: context.module, pageId: context.pageId, device, genome: context.genome }, definition, page11);
    }
    const receipt = await buildGenomeUxReceipt({
        project: context.project, module: context.module, layout: context.layout, genome: context.genome, pageId: context.pageId,
        template: { path: context.template.path, experience: context.template.experience, isDefault: context.template.isDefault, text: context.template.text, rules: context.template.rules },
        page11: { desktop: context.page11.desktop.source, mobile: context.page11.mobile.source },
        pageData: { contract: context.pageData.contractSource, shared: context.pageData.sharedSource },
        useMolecules: context.useMolecules, catalogHash: meta.catalogHash, moleculeHashes: meta.moleculeHashes,
        selectedGroups: meta.selectedGroups, dropped: meta.dropped, variants,
    });
    await writeGenomeUxPage(context, variants, receipt);
    return receipt;
}
/**
 * Whether no page of the run has work left (catalog not compared: the run itself just read it). Base mode: a page
 * with no UX 1 choice counts as done (`readGenomeUxPagePending`).
 */
export async function genomeUxRunFresh(args, layoutEntry) {
    for (const pageId of args.runPages) {
        if ((await readGenomeUxPagePending(args.project, args.module, args.layout, pageId, { layoutEntry })).pending)
            return false;
    }
    return true;
}
/** The steps that close a run: the done anchor and, with materialize, agentMaterializeL2 for `page{N}1` (page11 for the base). */
export function genomeUxCompletionSteps(args) {
    const genome = genomeUxGenome(args.layout);
    const steps = [d2Result(`UX ${args.layout} ready`, JSON.stringify({ project: args.project, module: args.module, layout: args.layout, genome, pages: args.runPages }), GENOME_UX_DONE_PLAN_ID)];
    if (args.materialize) {
        const scope = { genome, ...(args.subset ? { pages: args.runPages } : {}) };
        steps.push({
            type: 'agent', stepId: 0, interaction: null, stepTitle: `Materialize ${args.module} ${genome}`, status: 'waiting_dependency', nextSteps: [],
            agentName: 'agentMaterializeL2', prompt: JSON.stringify({ project: args.project, module: args.module, scope }), rags: [],
            planning: { planId: GENOME_UX_MATERIALIZE_PLAN_ID, dependsOn: [GENOME_UX_DONE_PLAN_ID], executionMode: 'sequential', executionHost: 'client' },
        });
    }
    return steps;
}
