/// <mls fileReference="_102020_/l2/aura/agentImplementGenome/agentRegisterGenome.ts" enhancement="_102027_/l2/enhancementAgent"/>
// [DESATIVADO temporariamente] avaliando se module.ts/moduleGenome ainda é necessário.
// import { registerPageGenome } from '/_102020_/l2/aura/helpers/dsMatch/registerPageGenome.js';
import { parseStepArgs, mkCompleted, mkFail } from '/_102020_/l2/aura/agentImplementGenome/planning.js';
export function createAgent() {
    return {
        agentName: 'agentRegisterGenome',
        agentProject: 102020,
        agentFolder: 'aura/agentImplementGenome',
        agentDescription: 'Register the new page variation in module.ts (terminal, no LLM)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseStepArgs(args ?? step.prompt);
        const project = mls.actualProject || 0;
        console.info(`[agentRegisterGenome] ▶ terminal — page${a.layout}${a.ds} (${a.module})`);
        if (!context.isTest) {
            // [DESATIVADO temporariamente] registro da variação no module.ts (moduleGenome).
            // O materializador atual (agentMaterializeL2) lê o .defs.ts direto e ignora o moduleGenome;
            // avaliando se ainda há consumidor vivo antes de remover de vez. Reative as 2 linhas + o import.
            // await registerPageGenome(project, a.module, a.layout, a.ds, a.device);
            // console.info(`[agentRegisterGenome] module.ts atualizado (web/${a.device}/page${a.layout}${a.ds})`);
            // Styling tokens live in designSystem.ts (single home) — nothing to regenerate here:
            // the Design System plugin/reconciliation agent write it directly.
        }
        console.info('[agentRegisterGenome] ✓ fluxo agentImplementGenome concluído');
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        const msg = `[agentRegisterGenome] ${error instanceof Error ? error.message : String(error)}`;
        console.error('✗', msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
