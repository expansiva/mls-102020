/// <mls fileReference="_102020_/l2/aura/agentImplementGenome/planning.ts" enhancement="_blank" />
// Shared planning helpers for the barrier-group orchestration (see
// skills/desingsystem/agentsgrouping.md and the agentNewSolution model).
//
// The orchestrator enumerates pages and creates one step per page per group, wiring
// dependencies (dependsOn) so a group only starts when its barrier completes:
//   select:<page>  (group A, waiting_human_input, dependsOn [])
//   gen:<page>     (group B, waiting_dependency, dependsOn [select:<page>])
//   register       (terminal, waiting_dependency, dependsOn [gen:* for every page])
import { createStorFile } from '/_102027_/l2/libStor.js';
/** 'select:cardapioEstoque' / 'gen:cardapioEstoque' / 'register'. */
export function makePlanId(group, page) {
    return page ? `${group}:${page}` : group;
}
/** Build an add-step intent for a planned agent step (child of the orchestrator step). */
export function mkAgentStep(context, rootStep, planId, title, agentName, args, dependsOn, status = 'waiting_dependency', executionMode = 'parallel_static') {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: rootStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: title,
            status,
            nextSteps: [],
            agentName,
            prompt: JSON.stringify(args),
            rags: [],
            planning: {
                planId,
                dependsOn,
                executionMode,
                executionHost: 'client',
            },
        },
    };
}
/** Mark the current step completed (used by no-LLM steps and after-processing). `traceMsg` is an
 *  optional carrier the caller can read back from the stream's hook-done intents (e.g. the plan's
 *  operations or the edit's notes surfaced to the Studio UI). */
export function mkCompleted(context, parentStep, step, hookSequential, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status: 'completed',
        ...(traceMsg ? { traceMsg } : {}),
    };
}
/** Mark the current step failed, surfacing the reason in traceMsg. */
export function mkFail(context, parentStep, step, hookSequential, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status: 'failed',
        traceMsg,
    };
}
/** Parse a step's `prompt` (the StepArgs JSON). */
export function parseStepArgs(prompt) {
    if (!prompt)
        throw new Error('[planning] empty step prompt');
    const a = JSON.parse(prompt);
    if (!a.module || a.layout == null || a.ds == null)
        throw new Error(`[planning] invalid step args: ${prompt}`);
    if (!a.device)
        a.device = 'desktop';
    return a;
}
/** Read raw file content by file reference (''. when missing). */
export async function readRawSource(ref) {
    const norm = ref.startsWith('/') ? ref.slice(1) : ref;
    const info = mls.stor.convertFileReferenceToFile(norm);
    const key = mls.stor.getKeyToFile(info);
    const sf = mls.stor.files[key];
    if (!sf)
        return '';
    const content = await sf.getContent();
    return typeof content === 'string' ? content : '';
}
/** Create or overwrite a file by file reference. */
export async function saveFile(ref, src) {
    const info = mls.stor.convertFileReferenceToFile(ref);
    const key = mls.stor.getKeyToFile(info);
    let sf = mls.stor.files[key];
    if (!sf) {
        sf = await createStorFile({ ...info, source: src }, true, true, true);
    }
    else {
        const m = await sf.getOrCreateModel();
        if (m && m.model)
            m.model.setValue(src);
    }
    await mls.stor.localStor.setContent(sf, { contentType: 'string', content: src });
}
