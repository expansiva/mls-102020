/// <mls fileReference="_102020_/l2/aura/molecules/agentCopyMolecule/steps/c4-less/gate.test.ts" enhancement="_blank"/>
// The sheet is copied verbatim, so there is exactly one thing that can go wrong and one thing
// that can go wrong silently: the scope (the root selector must BE the copy's tag) and the
// source in the flattened path (the shell's sheet, never the parent's).
import test from 'node:test';
import assert from 'node:assert/strict';
import { renderCopiedLess } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cTemplates.js';
import { runLessGate } from '/_102020_/l2/aura/molecules/agentCopyMolecule/steps/c4-less/gate.js';
const DEST = 102053;
const ORIGIN_LESS = `/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner.less" enhancement="_102020_/l2/enhancementStyleAura" />

groupshowprogress--ml-indeterminate-spinner {
  display: block;
  .ml-spinner { animation: spin 1s linear infinite; }
}
`;
function item(overrides = {}) {
    return {
        origin: {
            ref: '_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner',
            project: 102040,
            group: 'groupshowprogress',
            shortName: 'ml-indeterminate-spinner',
            tag: 'groupshowprogress--ml-indeterminate-spinner',
            className: 'IndeterminateSpinnerMolecule',
            chain: { isShell: false },
        },
        destination: {
            group: 'groupshowprogress',
            files: {
                ts: 'l2/molecules/groupshowprogress/ml-indeterminate-spinner.ts',
                defs: 'l2/molecules/groupshowprogress/ml-indeterminate-spinner.defs.ts',
                less: 'l2/molecules/groupshowprogress/ml-indeterminate-spinner.less',
                html: 'l2/molecules/groupshowprogress/ml-indeterminate-spinner.html',
            },
        },
        collision: null,
        rename: null,
        skip: false,
        ...overrides,
    };
}
test('a folha que o renderer produz passa limpa', () => {
    const target = item();
    assert.deepEqual(runLessGate({ item: target, destProject: DEST, writtenLess: renderCopiedLess(target, ORIGIN_LESS, DEST), sourceIsShellSheet: true }), []);
});
test('folha vazia para na primeira queixa', () => {
    const issues = runLessGate({ item: item(), destProject: DEST, writtenLess: '', sourceIsShellSheet: true });
    assert.equal(issues.length, 1);
    assert.equal(issues[0].code, 'less_empty');
});
test('header do .less com o projeto errado é pego', () => {
    const target = item();
    const wrong = renderCopiedLess(target, ORIGIN_LESS, 999999);
    assert.ok(runLessGate({ item: target, destProject: DEST, writtenLess: wrong, sourceIsShellSheet: true }).some(issue => issue.code === 'less_header'));
});
test('seletor raiz que não é a tag da cópia é pego, e a mensagem mostra o que achou', () => {
    const target = item();
    const wrongScope = renderCopiedLess(target, ORIGIN_LESS, DEST).replace('groupshowprogress--ml-indeterminate-spinner {', 'outra--tag {');
    const issues = runLessGate({ item: target, destProject: DEST, writtenLess: wrongScope, sourceIsShellSheet: true });
    const scope = issues.find(issue => issue.code === 'less_scope');
    assert.ok(scope);
    assert.match(String(scope?.message), /outra--tag/);
});
test('renomeado: re-escopado passa, e a tag antiga sobrando é pega', () => {
    const target = item({ rename: 'ml-indeterminate-spinner-app' });
    const rescoped = renderCopiedLess(target, ORIGIN_LESS, DEST);
    assert.deepEqual(runLessGate({ item: target, destProject: DEST, writtenLess: rescoped, sourceIsShellSheet: true }), []);
    const leftover = `${rescoped}\ngroupshowprogress--ml-indeterminate-spinner { color: red; }`;
    assert.ok(runLessGate({ item: target, destProject: DEST, writtenLess: leftover, sourceIsShellSheet: true }).some(issue => issue.code === 'less_old_tag'));
});
test('casca: folha vinda do PAI é barrada — desfaria o tema que o cliente escolheu', () => {
    const shell = item({ origin: { ...item().origin, chain: { isShell: true, parentRef: '_102040_/l2/molecules/g/ml-p' } } });
    const written = renderCopiedLess(shell, ORIGIN_LESS, DEST);
    const issues = runLessGate({ item: shell, destProject: DEST, writtenLess: written, sourceIsShellSheet: false });
    const fromParent = issues.find(issue => issue.code === 'less_from_parent');
    assert.ok(fromParent);
    assert.match(String(fromParent?.message), /CASCA/);
    // com a folha da casca, passa
    assert.ok(!runLessGate({ item: shell, destProject: DEST, writtenLess: written, sourceIsShellSheet: true }).some(issue => issue.code === 'less_from_parent'));
});
test('seletor raiz com pseudo/classe ainda conta como escopo certo', () => {
    const target = item();
    const withPseudo = renderCopiedLess(target, ORIGIN_LESS, DEST)
        .replace('groupshowprogress--ml-indeterminate-spinner {', 'groupshowprogress--ml-indeterminate-spinner:hover {');
    assert.deepEqual(runLessGate({ item: target, destProject: DEST, writtenLess: withPseudo, sourceIsShellSheet: true }), []);
});
