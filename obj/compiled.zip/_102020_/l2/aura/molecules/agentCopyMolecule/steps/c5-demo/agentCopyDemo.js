/// <mls fileReference="_102020_/l2/aura/molecules/agentCopyMolecule/steps/c5-demo/agentCopyDemo.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { C_AGENT_FOLDER, cContextFileInfo, cDestMoleculeFile, cMoleculeFile, cTraceFileInfo, readJsonArtifact, readStorText, writeJsonArtifact, writeStorTextAtomic, } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cFs.js';
import { copyShortName, itemsToWrite } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cContext.js';
import { renderCopiedHtml } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cTemplates.js';
import { cDoneAnchor, cParseStepArgs, cResultStepIntent, cUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cSteps.js';
import { runDemoGate } from '/_102020_/l2/aura/molecules/agentCopyMolecule/steps/c5-demo/gate.js';
import { getCRunKey } from '/_102020_/l2/aura/molecules/agentCopyMolecule/agentCopyMolecule.js';
const AGENT_NAME = 'agentCopyDemo';
const PLAN_ID = 'c5-demo';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${C_AGENT_FOLDER}/steps/c5-demo`,
        agentDescription: 'c5-demo — copies the demo .html of each molecule (never blocks the pipeline)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const runKey = getCRunKey(context, cParseStepArgs(args || step.prompt).runKey);
    const ctx = await readJsonArtifact(cContextFileInfo(runKey), true);
    if (!ctx)
        throw new Error(`[${AGENT_NAME}] context.json missing for ${runKey}`);
    const written = [];
    const issues = [];
    for (const item of itemsToWrite(ctx)) {
        const source = await readStorText(cMoleculeFile(item.origin.project, item.origin.group, item.origin.shortName, '.html'));
        if (!source.trim()) {
            issues.push({ code: 'source_html', message: `${item.origin.ref}: sem página de demonstração legível na origem` });
            continue;
        }
        const html = renderCopiedHtml(item, source);
        const itemIssues = runDemoGate({ item, writtenHtml: html });
        if (itemIssues.length) {
            issues.push(...itemIssues);
            continue; // this item's demo is skipped; the others still get theirs
        }
        await writeStorTextAtomic(cDestMoleculeFile(item.destination.group, copyShortName(item), '.html'), html, true);
        written.push(item.destination.files.html);
    }
    await writeJsonArtifact(cTraceFileInfo(runKey, PLAN_ID, 1), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        written,
        issues,
    });
    const ok = issues.length === 0;
    const trace = ok ? `${written.length} demo(s) copiada(s)` : issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
    // The anchor lands EITHER WAY (ok:false when something failed) — c6 reads it and reports.
    return [
        cResultStepIntent(context, parentStep, {
            planId: cDoneAnchor(PLAN_ID),
            dependsOn: [],
            stepTitle: !ok ? 'demo com pendências' : !written.length ? 'nada a copiar' : written.length === 1 ? written[0] : `${written.length} páginas de demonstração`,
            result: { ok, written, issues },
        }),
        cUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace, 'input_output'),
    ];
}
