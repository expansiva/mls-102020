/// <mls fileReference="_102020_/l2/aura/molecules/agentCopyMolecule/steps/c1-bootstrap/agentCopyBootstrap.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { C_AGENT_FOLDER, C_MOLECULE_EXTENSIONS, cContextFileInfo, cDestMoleculeFile, cDestProject, cFileExists, cMoleculeFile, cTraceFileInfo, listGroupMolecules, readStorText, toDisplayPath, writeJsonArtifact, } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cFs.js';
import { copyContextSummary, } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cContext.js';
import { copyModeForRefs, detectChain, expandRefs, extractExtendedClassName, extractOriginClassName, parseCopyRefs, refTag, MOLECULE_BASE_CLASS, } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cOrigin.js';
import { extractCopiedFrom } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cTemplates.js';
import { cDoneAnchor, cParseStepArgs, cResultStepIntent, cUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cSteps.js';
import { C_BOOTSTRAP_NON_BLOCKING, formatIssues, runBootstrapGate } from '/_102020_/l2/aura/molecules/agentCopyMolecule/steps/c1-bootstrap/gate.js';
import { getCInput, getCRootPlan, getCRunKey } from '/_102020_/l2/aura/molecules/agentCopyMolecule/agentCopyMolecule.js';
const AGENT_NAME = 'agentCopyBootstrap';
const PLAN_ID = 'c1-bootstrap';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${C_AGENT_FOLDER}/steps/c1-bootstrap`,
        agentDescription: 'c1-bootstrap — deterministic admission of the whole list + context assembly',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const input = getCInput(context);
    const rootPlan = getCRootPlan(context);
    const runKey = getCRunKey(context, cParseStepArgs(args || step.prompt).runKey);
    const destProject = cDestProject();
    // 1. parse the mention into references, 2. expand group references. Both deterministic.
    const parsed = parseCopyRefs(input.entryText);
    const mode = copyModeForRefs(parsed.refs);
    const expanded = expandRefs(parsed.refs, listGroupMolecules);
    // 3. probe every item BEFORE building anything: origin readable, chain resolved, depth <= 1.
    const probes = [];
    const items = [];
    const copiedFromDate = new Date().toISOString().slice(0, 10);
    for (const ref of expanded.refs) {
        const probe = await probeItem(ref);
        probes.push(probe);
        if (!probe.tsFound || probe.chainError)
            continue;
        items.push(await buildItem(ref, probe));
    }
    const ctx = items.length || expanded.refs.length ? {
        schemaVersion: 1,
        createdAt: new Date().toISOString(),
        runKey,
        destProject,
        mode,
        userLanguage: rootPlan.userLanguage,
        userNotes: input.notes,
        copiedFromDate,
        items,
    } : null;
    const gateInputs = {
        parseErrors: parsed.errors,
        expandErrors: expanded.errors,
        refsFound: parsed.refs.length,
        probes,
        context: ctx,
    };
    const issues = runBootstrapGate(gateInputs);
    const blocking = issues.filter(issue => !C_BOOTSTRAP_NON_BLOCKING.includes(issue.code));
    if (blocking.length || !ctx) {
        const message = formatIssues(blocking) || 'admissão falhou';
        // The trace is written even on failure: it is the record of WHY nothing was copied.
        await writeJsonArtifact(cTraceFileInfo(runKey, PLAN_ID, 1), {
            savedAt: new Date().toISOString(),
            planId: PLAN_ID,
            entryText: input.entryText,
            refs: expanded.refs.map(ref => ref.ref),
            issues: blocking,
        });
        return [cUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
    await writeJsonArtifact(cContextFileInfo(runKey), ctx);
    await writeJsonArtifact(cTraceFileInfo(runKey, PLAN_ID, 1), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        summary: copyContextSummary(ctx),
        warnings: issues,
        items: ctx.items.map(item => ({
            origin: item.origin.ref,
            shell: item.origin.chain.isShell ? item.origin.chain.parentRef : null,
            collision: item.collision?.files || null,
        })),
    });
    return [
        cResultStepIntent(context, parentStep, {
            planId: cDoneAnchor(PLAN_ID),
            dependsOn: [],
            stepTitle: copyContextSummary(ctx),
            result: {
                contextFile: toDisplayPath(cContextFileInfo(runKey)),
                runKey,
                mode: ctx.mode,
                items: ctx.items.length,
                collisions: ctx.items.filter(item => !!item.collision).length,
            },
        }),
        cUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', copyContextSummary(ctx), 'input_output'),
    ];
}
// Everything the gate needs to judge one item, read from the stor.
async function probeItem(ref) {
    const originTs = await readStorText(cMoleculeFile(ref.project, ref.group, ref.shortName, '.ts'));
    const originLess = await readStorText(cMoleculeFile(ref.project, ref.group, ref.shortName, '.less'));
    const probe = {
        ref: ref.ref,
        tsFound: !!originTs.trim(),
        className: extractOriginClassName(originTs) || '',
        chain: { isShell: false },
        parentTsFound: false,
        parentIsShell: false,
        lessFound: !!originLess.trim(),
    };
    if (!probe.tsFound)
        return probe;
    const { chain, error } = detectChain(originTs);
    probe.chain = chain;
    if (error) {
        probe.chainError = error;
        return probe;
    }
    if (!chain.isShell)
        return probe;
    const parentTs = await readStorText(cMoleculeFile(chain.parentProject, chain.parentGroup, chain.parentShortName, '.ts'));
    probe.parentTsFound = !!parentTs.trim();
    if (probe.parentTsFound) {
        probe.parentIsShell = extractExtendedClassName(parentTs) !== MOLECULE_BASE_CLASS;
    }
    return probe;
}
// The chain comes from the probe (read once, above) — never re-derived here.
async function buildItem(ref, probe) {
    const files = {
        ts: toDisplayPath(cDestMoleculeFile(ref.group, ref.shortName, '.ts')),
        defs: toDisplayPath(cDestMoleculeFile(ref.group, ref.shortName, '.defs.ts')),
        less: toDisplayPath(cDestMoleculeFile(ref.group, ref.shortName, '.less')),
        html: toDisplayPath(cDestMoleculeFile(ref.group, ref.shortName, '.html')),
    };
    // Collision = ANY of the 4 destination files already exists (the Variant's criterion): a
    // leftover .less from an earlier copy surviving under a fresh .ts is the worse outcome.
    const existing = [];
    for (const extension of C_MOLECULE_EXTENSIONS) {
        const fileInfo = cDestMoleculeFile(ref.group, ref.shortName, extension);
        if (cFileExists(fileInfo))
            existing.push(toDisplayPath(fileInfo));
    }
    let collisionCopiedFrom;
    if (existing.length) {
        // WHEN the existing copy was made is what makes 'replace' an informed choice.
        const existingTs = await readStorText(cDestMoleculeFile(ref.group, ref.shortName, '.ts'));
        collisionCopiedFrom = extractCopiedFrom(existingTs) || undefined;
    }
    return {
        origin: {
            ref: ref.ref,
            project: ref.project,
            group: ref.group,
            shortName: ref.shortName,
            tag: refTag(ref),
            className: probe.className,
            chain: probe.chain,
        },
        destination: { group: ref.group, files },
        collision: existing.length ? { files: existing, ...(collisionCopiedFrom ? { copiedFrom: collisionCopiedFrom } : {}) } : null,
        rename: null,
        skip: false,
    };
}
