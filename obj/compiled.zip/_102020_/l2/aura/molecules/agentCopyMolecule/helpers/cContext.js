/// <mls fileReference="_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cContext.ts" enhancement="_blank"/>
// ---- effective identity ------------------------------------------------------
// The identity a copy is WRITTEN with. Three cases collapse here, and getting this wrong
// is what would make the whole agent pointless:
//  - default: the origin's own identity (same name/tag => the copy shadows the base);
//  - flattened shell: STILL the shell's identity (the origin IS the shell) even though the
//    body comes from the parent — with the parent's identity the copy would shadow the BASE
//    molecule instead of the themed one the client actually uses;
//  - renamed (single mode, collision): the identity derived from the new shortName.
export function copyShortName(item) {
    return item.rename || item.origin.shortName;
}
export function copyTag(item) {
    return `${item.destination.group}--${copyShortName(item)}`;
}
export function copyClassName(item) {
    if (!item.rename)
        return item.origin.className;
    return deriveClassName(item.rename, item.origin.className);
}
// 'ml-combobox-local' + origin 'ComboboxMolecule' -> 'ComboboxLocalMolecule'
// 'ml-button-standard-brutal-2' + origin 'ButtonStandardBrutal' -> 'ButtonStandardBrutal2'
// The 'Molecule' suffix is kept only when the origin used it: the base molecules do, the
// hand-made shells of 102054/102055 do not.
export function deriveClassName(shortName, originClassName) {
    const pascal = shortName
        .replace(/^ml-/, '')
        .split('-')
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join('');
    return /Molecule$/.test(originClassName) ? `${pascal}Molecule` : pascal;
}
// ---- selectors ---------------------------------------------------------------
// The items c3/c4/c5 actually write. `skip` is the ONLY reason an item is left out at
// this point: invalid items never make it past c1 (fail-fast).
export function itemsToWrite(ctx) {
    return ctx.items.filter(item => !item.skip);
}
export function collidingItems(ctx) {
    return ctx.items.filter(item => !!item.collision);
}
export function copyContextSummary(ctx) {
    const shells = ctx.items.filter(item => item.origin.chain.isShell).length;
    const collisions = collidingItems(ctx).length;
    const parts = [`${ctx.items.length} molécula(s) [${ctx.mode}]`];
    if (shells)
        parts.push(`${shells} casca(s) achatada(s)`);
    parts.push(collisions ? `${collisions} colisão(ões)` : 'sem colisão');
    return `${parts.join(', ')} -> _${ctx.destProject}_`;
}
