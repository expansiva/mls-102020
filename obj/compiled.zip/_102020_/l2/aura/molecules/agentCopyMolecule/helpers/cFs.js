/// <mls fileReference="_102020_/l2/aura/molecules/agentCopyMolecule/helpers/cFs.ts" enhancement="_102027_/l2/enhancementAgent"/>
// File-system helpers for agentCopyMolecule. Step-agnostic: knows paths and stor mechanics
// only (pattern: agentNewMoleculeVariant/helpers/vFs.ts, agentNewTheme/helpers/ntFs.ts,
// agentNewMolecule2/helpers/nmFs.ts — four agents, four fs helpers; see spec.md on why
// nothing was promoted to shared/).
//
// TWO differences from vFs, and both come from what this agent does:
// 1. it READS from another project (the origin) and WRITES to the current one, so the
//    molecule-path builder takes the project explicitly;
// 2. the work folder is keyed by the RUN (l4/agentCopy/<runKey>/), not by a molecule
//    shortName — a batch has no single shortName. Precedent: the runKey of
//    agentImproveMolecule2 (helpers/imResolve.ts + imRootPlan.getImRunKey).
import { createStorFile } from '/_102027_/l2/libStor.js';
export const C_AGENT_PROJECT = 102020;
export const C_AGENT_FOLDER = 'aura/molecules/agentCopyMolecule';
export const C_MOLECULE_EXTENSIONS = ['.ts', '.defs.ts', '.less', '.html'];
export function cAgentFile(folder, shortName, extension) {
    const sub = folder ? `${C_AGENT_FOLDER}/${folder}` : C_AGENT_FOLDER;
    return { project: C_AGENT_PROJECT, level: 2, folder: sub, shortName, extension };
}
export async function readCAgentText(folder, shortName, extension, required = false) {
    return readStorText(cAgentFile(folder, shortName, extension), required);
}
export function cDestProject() {
    const project = mls.actualProject;
    if (!project)
        throw new Error('[cFs] mls.actualProject not available');
    return project;
}
// Any molecule file, in ANY project: the origin lives in a dependency, the copy in the
// current project. Never assume the destination here.
export function cMoleculeFile(project, group, shortName, extension) {
    return { project, level: 2, folder: `molecules/${group}`, shortName, extension };
}
export function cDestMoleculeFile(group, shortName, extension) {
    return cMoleculeFile(cDestProject(), group, shortName, extension);
}
export function cWorkFile(runKey, shortName, extension = '.json') {
    return { project: cDestProject(), level: 4, folder: `agentCopy/${runKey}`, shortName, extension };
}
export function cContextFileInfo(runKey) {
    return cWorkFile(runKey, 'context');
}
export function cAnswersFileInfo(runKey) {
    return cWorkFile(runKey, 'answers');
}
export function cTraceFileInfo(runKey, planId, attempt) {
    return cWorkFile(runKey, `trace-${planId}-${String(attempt).padStart(2, '0')}`);
}
export function cFileExists(fileInfo) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    return !!file && file.status !== 'deleted';
}
// The molecules of a group in a project, as shortNames. This is how a group-only reference
// is expanded (c1-bootstrap), reading the ORIGIN project — same stor scan the index steps
// already do (agentVariantIndex.scanGroupMolecules, agentIndexGroupPage.getMoleculeFiles).
//
// '.defs.ts' and '.test.ts' are their OWN extensions in the stor, so filtering on '.ts'
// already excludes them; the explicit shortName guards below are the belt to that
// suspenders, for a project that ever stored them as 'ml-x.defs' + '.ts'.
export function listGroupMolecules(project, group) {
    const folder = `molecules/${group}`;
    const found = Object.keys(mls.stor.files)
        .map(key => mls.stor.files[key])
        .filter(sf => !!sf
        && sf.status !== 'deleted'
        && sf.project === project
        && sf.level === 2
        && sf.folder === folder
        && sf.extension === '.ts'
        && sf.shortName !== 'index'
        && !/\.(defs|test)$/.test(sf.shortName))
        .map(sf => sf.shortName);
    return Array.from(new Set(found)).sort();
}
export async function readStorText(fileInfo, required = false) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted') {
        if (required)
            throw new Error(`[cFs] file not found: ${toDisplayPath(fileInfo)}`);
        return '';
    }
    const raw = await file.getContent();
    if (typeof raw === 'string')
        return raw;
    if (fileInfo.extension === '.json' && (isRecord(raw) || Array.isArray(raw))) {
        return `${JSON.stringify(raw, null, 2)}\n`;
    }
    if (required)
        throw new Error(`[cFs] file content is not text: ${toDisplayPath(fileInfo)}`);
    return '';
}
export async function readJsonArtifact(fileInfo, required = false) {
    const raw = await readStorText(fileInfo, required);
    if (!raw.trim())
        return null;
    const parsed = parseMaybeJson(raw);
    if (parsed === raw)
        throw new Error(`[cFs] invalid JSON: ${toDisplayPath(fileInfo)}`);
    return parsed;
}
export async function writeJsonArtifact(fileInfo, data) {
    await writeStorTextAtomic(fileInfo, `${JSON.stringify(data, null, 2)}\n`);
    return toDisplayPath(fileInfo);
}
// needCreateModel=true for molecule source files (the editor model is kept in sync);
// false for l4 work files.
export async function writeStorTextAtomic(fileInfo, content, needCreateModel = false) {
    const key = mls.stor.getKeyToFile(fileInfo);
    let storFile = mls.stor.files[key];
    if (!storFile) {
        storFile = await createStorFile({ ...fileInfo, source: content }, needCreateModel, needCreateModel, false);
    }
    else {
        // Re-run resurrection (lesson inherited from nsFs/vFs — do NOT drop this branch): a
        // locally deleted file stays in the stor with status 'deleted' and would silently
        // never persist. It matters MORE here than in the Variant: 'replace' on a collision
        // is a re-run over files that may have been deleted by hand.
        if (storFile.status === 'deleted') {
            storFile.status = 'changed';
            storFile.updatedAt = new Date().toISOString();
        }
        if (needCreateModel) {
            const model = await storFile.getOrCreateModel();
            if (model?.model)
                model.model.setValue(content);
        }
    }
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content });
}
export function toDisplayPath(fileInfo) {
    const folder = fileInfo.folder ? `${fileInfo.folder}/` : '';
    return `l${fileInfo.level}/${folder}${fileInfo.shortName}${fileInfo.extension}`;
}
export function toMlsFileReference(fileInfo) {
    const folder = fileInfo.folder ? `${fileInfo.folder}/` : '';
    return `_${fileInfo.project}_/l${fileInfo.level}/${folder}${fileInfo.shortName}${fileInfo.extension}`;
}
export function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const trimmed = value.trim();
    if (!trimmed)
        return value;
    if (!trimmed.startsWith('{') && !trimmed.startsWith('['))
        return value;
    try {
        return JSON.parse(trimmed);
    }
    catch {
        return value;
    }
}
export function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
