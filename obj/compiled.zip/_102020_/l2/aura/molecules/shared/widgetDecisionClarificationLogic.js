/// <mls fileReference="_102020_/l2/aura/molecules/shared/widgetDecisionClarificationLogic.ts" enhancement="_blank"/>
// Pre-select the recommended option (or the first) so the user can accept fast.
export function initialDecisionAnswers(questions) {
    const out = {};
    for (const q of questions) {
        const rec = q.options.find(o => o.recommended) || q.options[0];
        out[q.id] = { optionId: rec ? rec.id : '', notes: '' };
    }
    return out;
}
// A question is answered if an option is chosen OR (notes allowed and provided).
export function isDecisionAnswered(question, local) {
    if (!local)
        return false;
    if (local.optionId)
        return true;
    return !!question.allowNotes && local.notes.trim().length > 0;
}
export function allDecisionAnswered(questions, local) {
    return questions.every(q => isDecisionAnswered(q, local[q.id]));
}
// Resolve the emitted answers (label from the chosen option; notes only when allowed + present).
export function buildDecisionResult(questions, local) {
    return questions.map(q => {
        const a = local[q.id] || { optionId: '', notes: '' };
        const opt = q.options.find(o => o.id === a.optionId);
        const answer = { id: q.id, optionId: a.optionId, label: opt ? opt.label : '' };
        if (q.allowNotes && a.notes && a.notes.trim())
            answer.notes = a.notes.trim();
        return answer;
    });
}
