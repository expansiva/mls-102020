/// <mls fileReference="_102020_/l2/aura/molecules/shared/mentionEntry.ts" enhancement="_blank"/>
// The mention text without OUR OWN '@@'/agent-name prefix. Another agent's '@@' is left
// intact on purpose, so the caller can tell it apart from real content.
export function stripAgentMention(userPrompt, agentName) {
    const text = (userPrompt || '').trim();
    const name = (agentName || '').toLowerCase();
    if (!name)
        return text;
    const lower = text.toLowerCase();
    for (const prefix of [`@@${name}`, `@@ ${name}`, name]) {
        if (!lower.startsWith(prefix))
            continue;
        const rest = text.slice(prefix.length);
        // 'agentNewThemeStyle ...' is content, not our mention followed by arguments.
        if (!rest || /^[\s:,{]/.test(rest))
            return rest.trim();
    }
    return text;
}
// Only text that opens an object literal is worth handing to the arg parser.
export function looksLikeArgs(text) {
    return text.trim().startsWith('{');
}
// Parse an object-literal mention, or null when it is not one / does not parse. Callers
// decide what a non-object mention means for them (prose, a bare reference, an error).
export function tryParseArgs(text, parseArgs) {
    if (!looksLikeArgs(text))
        return null;
    try {
        return parseArgs(text) || null;
    }
    catch {
        return null;
    }
}
// A mention that is just ANOTHER agent's mention carries no content (the preview sends the
// mention itself in `prompt`).
export function isBareMention(text) {
    return text.trim().startsWith('@@');
}
