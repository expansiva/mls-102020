/// <mls fileReference="_102020_/l2/aura/molecules/shared/configuration.ts" enhancement="_blank"/>
/**
 * Returns the configuration for a group, loaded on-demand from the group's own `configuration.ts`.
 * Returns an empty list when the group has no file — no error, no throw.
 */
export async function loadGroupConfiguration(group) {
    try {
        const mod = await import(`/_102020_/l2/aura/molecules/skills/${group}/configuration.js`);
        return Array.isArray(mod.configuration) ? mod.configuration : [];
    }
    catch {
        return [];
    }
}
/**
 * Filters a configuration list to only the entries visible from a given molecule tag, each with the
 * default THAT tag uses (`defaults[tag]` when declared). An entry with no `only` constraint is always
 * included.
 */
export function configurationFor(tag, list) {
    return list
        .filter((prop) => !prop.only || prop.only.includes(tag))
        .map((prop) => (prop.defaults && tag in prop.defaults ? { ...prop, default: prop.defaults[tag] } : prop));
}
/** The default a given tag uses for a property: its own when declared, the group's otherwise. */
export function defaultFor(prop, tag) {
    return prop.defaults && tag in prop.defaults ? prop.defaults[tag] : prop.default;
}
/**
 * The slot order of a group, loaded on demand from its `configuration.ts` (`export const slotOrder`).
 * A group without the file or without the export answers an empty list — no error, no throw.
 */
export async function loadGroupSlotOrder(group) {
    try {
        const mod = await import(`/_102020_/l2/aura/molecules/skills/${group}/configuration.js`);
        return Array.isArray(mod.slotOrder) ? mod.slotOrder : [];
    }
    catch {
        return [];
    }
}
/** The entries a given molecule tag reads: the ones with no `only`, and the ones that name it. */
export function slotOrderFor(tag, list) {
    return list.filter((entry) => !entry.only || entry.only.includes(tag));
}
