/// <mls fileReference="_102020_/l2/aura/molecules/shared/contractFingerprint.ts" enhancement="_blank"/>
export function contractFingerprint(text) {
    const bytes = new TextEncoder().encode(text || '');
    let hash = 0x811c9dc5;
    for (const byte of bytes) {
        hash ^= byte;
        // 32-bit FNV prime multiply without overflowing into float precision
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return { chars: (text || '').length, hash: hash.toString(16).padStart(8, '0') };
}
/** One-line form for a summary or a log: `19.487 chars · a1b2c3d4`. */
export function fingerprintLabel(print) {
    return `${print.chars} chars · ${print.hash}`;
}
