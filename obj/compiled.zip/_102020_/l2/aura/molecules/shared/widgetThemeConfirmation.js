/// <mls fileReference="_102020_/l2/aura/molecules/shared/widgetThemeConfirmation.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// Theme Confirmation widget (Checkpoint 2): shows the generated theme's layout
// signature + palette swatches over its background, and emits `clarification-finish`
// with { value: { confirmed }, action: 'continue' | 'cancel' }. Confirm => the agent
// writes theme.ts + theme.html; Exit => discard. No Shadow DOM (styles in the .less).
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { readableTextOn, } from '/_102020_/l2/aura/molecules/shared/widgetThemeConfirmationLogic.js';
let WidgetThemeConfirmation102020 = class WidgetThemeConfirmation102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-theme-confirmation-102020 {
  display: block;
}
widget-theme-confirmation-102020 .tc {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1rem;
}
widget-theme-confirmation-102020 .tc-title {
  font-size: 1.1rem;
  font-weight: 700;
  margin: 0;
}
widget-theme-confirmation-102020 .tc-preview {
  display: flex;
  align-items: flex-end;
  padding: 0.75rem;
  border: 1px solid rgba(0, 0, 0, 0.1);
}
widget-theme-confirmation-102020 .tc-preview-name {
  font-weight: 700;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.75);
  color: #0f172a;
}
widget-theme-confirmation-102020 .tc-section-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #94a3b8;
}
widget-theme-confirmation-102020 .tc-swatches {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
}
widget-theme-confirmation-102020 .tc-swatch {
  width: 8rem;
}
widget-theme-confirmation-102020 .tc-chip {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 3rem;
  border-radius: 6px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  font-size: 0.7rem;
  font-family: monospace;
}
widget-theme-confirmation-102020 .tc-swatch-label {
  margin-top: 0.25rem;
  font-weight: 600;
  font-size: 0.8rem;
}
widget-theme-confirmation-102020 .tc-swatch-token {
  color: #94a3b8;
  font-size: 0.7rem;
  font-family: monospace;
}
widget-theme-confirmation-102020 .tc-signature {
  border-collapse: collapse;
  width: 100%;
}
widget-theme-confirmation-102020 .tc-signature th,
widget-theme-confirmation-102020 .tc-signature td {
  text-align: left;
  padding: 0.35rem 0.5rem;
  border-bottom: 1px solid #eef2f7;
  font-size: 0.85rem;
}
widget-theme-confirmation-102020 .tc-signature th {
  width: 30%;
  color: #64748b;
  font-weight: 600;
}
widget-theme-confirmation-102020 .tc-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
widget-theme-confirmation-102020 .tc-btn {
  padding: 0.45rem 1rem;
  border-radius: 0.375rem;
  border: 1px solid #cbd5e1;
  background: #fff;
  cursor: pointer;
  font-weight: 600;
}
widget-theme-confirmation-102020 .tc-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
widget-theme-confirmation-102020 .tc-confirm {
  background: #16a34a;
  border-color: #16a34a;
  color: #fff;
}
widget-theme-confirmation-102020 .empty {
  padding: 1rem;
  color: #94a3b8;
}
`);
        this.value = null;
        this.readonly = false;
    }
    finish(action) {
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: { value: { confirmed: action === 'continue' }, action },
            bubbles: true,
        }));
    }
    render() {
        if (!this.value)
            return html `<div class="empty">No theme to confirm.</div>`;
        const s = this.value.summary;
        return html `
      <div class="tc">
        <h2 class="tc-title">${this.value.title}</h2>

        <div class="tc-preview" style=${`min-height:96px; border-radius:8px; ${s.background.css}`}>
          <span class="tc-preview-name">${s.displayName}</span>
        </div>

        <div class="tc-section-title">Palette</div>
        <div class="tc-swatches">
          ${s.palette.map(sw => html `
            <div class="tc-swatch">
              <div class="tc-chip" style=${`background:${sw.color}; color:${readableTextOn(sw.color)};`}>${sw.color}</div>
              <div class="tc-swatch-label">${sw.label}</div>
              <div class="tc-swatch-token">${sw.token}</div>
            </div>
          `)}
        </div>

        <div class="tc-section-title">Signature</div>
        <table class="tc-signature">
          <tbody>
            ${s.signature.map(row => html `
              <tr><th>${row.aspect}</th><td>${row.value}</td></tr>
            `)}
          </tbody>
        </table>

        <div class="tc-actions">
          <button class="tc-btn tc-exit" ?disabled=${this.readonly} @click=${() => this.finish('cancel')}>Exit</button>
          <button class="tc-btn tc-confirm" ?disabled=${this.readonly} @click=${() => this.finish('continue')}>Confirm &amp; create</button>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetThemeConfirmation102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetThemeConfirmation102020.prototype, "readonly", void 0);
WidgetThemeConfirmation102020 = __decorate([
    customElement('widget-theme-confirmation-102020')
], WidgetThemeConfirmation102020);
export { WidgetThemeConfirmation102020 };
