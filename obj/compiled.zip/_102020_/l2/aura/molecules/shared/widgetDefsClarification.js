/// <mls fileReference="_102020_/l2/aura/molecules/shared/widgetDefsClarification.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// "Defs Clarification" widget: the human checkpoint that confirms a NEW molecule's requirements
// before the .defs.ts is written. Emits `clarification-finish` with
// { value: { tagName, ...data }, action: 'continue' | 'cancel' }.
//
// Reproduces the interface of agentsManageMolecules/agentNewMoleculePlannerClarification
// (decision D2) so users of the old New Molecule flow see no change — click-to-edit fields,
// collapsible requirement lists with add/edit/remove, footer Cancel/Confirm. What changed:
// - it lives in shared/ (the old file is named like an agent but is a Lit component);
// - `group` and the tag are DERIVED from the fileReference and read-only (decision Q1);
// - a read-only line names the detected theme (decision Q3);
// - all mutation logic is in widgetDefsClarificationLogic, unit-tested without a DOM.
//
// No Shadow DOM (StateLitElement) — styles live in the sibling .less scoped under the tag.
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { tagFromFileReference } from '/_102020_/l2/aura/molecules/shared/moleculeTemplates.js';
import { addDefsRequirement, applyDefsAxisValue, applyDefsFieldEdit, applyDefsRequirementEdit, buildDefsResult, canConfirmDefs, emptyDefsData, removeDefsRequirement, DEFS_AXIS_WILDCARD, } from '/_102020_/l2/aura/molecules/shared/widgetDefsClarificationLogic.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Confirmar a molécula',
    intro: 'Revise os requisitos antes de gerar os arquivos. O nome e a tag podem ser ajustados agora — depois exigem renomear quatro arquivos.',
    fileReference: 'Referência do arquivo',
    tagName: 'Tag (derivada)',
    group: 'Grupo (derivado)',
    theme: 'Tema detectado',
    noTheme: 'nenhum (molécula neutra)',
    description: 'Descrição',
    prompt: 'Prompt final',
    functionalRequirements: 'Requisitos funcionais',
    visualRequirements: 'Requisitos visuais',
    layoutAxes: 'Eixos de layout (Design System)',
    layoutAxesHint: 'Definem para quais páginas esta molécula é escolhida. "Qualquer" deixa o eixo livre.',
    axisWildcard: 'qualquer (coringa)',
    axisDefaultHint: 'padrão',
    clickToEdit: 'Clique para editar',
    save: 'Salvar',
    cancel: 'Cancelar',
    confirm: 'Confirmar',
    addRequirement: '+ Adicionar requisito',
    newFunctionalRequirement: 'Novo requisito funcional',
    newVisualRequirement: 'Novo requisito visual',
    edit: 'Editar',
    remove: 'Remover',
    incomplete: 'Informe a referência do arquivo, a descrição e ao menos um requisito funcional (sem linhas vazias).',
    incompleteAxes: 'Escolha ao menos um eixo de layout — deixar todos em "qualquer" faz esta molécula ser o coringa do grupo.',
};
const message_en = {
    title: 'Confirm the molecule',
    intro: 'Review the requirements before the files are generated. The name and the tag can be adjusted now — later they mean renaming four files.',
    fileReference: 'File reference',
    tagName: 'Tag (derived)',
    group: 'Group (derived)',
    theme: 'Detected theme',
    noTheme: 'none (neutral molecule)',
    description: 'Description',
    prompt: 'Final prompt',
    functionalRequirements: 'Functional requirements',
    visualRequirements: 'Visual requirements',
    layoutAxes: 'Layout axes (Design System)',
    layoutAxesHint: 'They decide which pages pick this molecule. "Any" leaves the axis free.',
    axisWildcard: 'any (wildcard)',
    axisDefaultHint: 'default',
    clickToEdit: 'Click to edit',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    addRequirement: '+ Add requirement',
    newFunctionalRequirement: 'New functional requirement',
    newVisualRequirement: 'New visual requirement',
    edit: 'Edit',
    remove: 'Remove',
    incomplete: 'Provide the file reference, the description and at least one functional requirement (no blank lines).',
    incompleteAxes: 'Choose at least one layout axis — leaving them all on "any" makes this molecule the group\'s wildcard.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let WidgetDefsClarification102020 = class WidgetDefsClarification102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-defs-clarification-102020 {
  display: block;
}
widget-defs-clarification-102020 .dfc {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
  padding: 1rem;
}
widget-defs-clarification-102020 .dfc-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
}
widget-defs-clarification-102020 .dfc-title {
  font-size: 1.1rem;
  font-weight: 700;
  margin: 0;
}
widget-defs-clarification-102020 .dfc-group-chip {
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #2563eb;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 999px;
  padding: 0.1rem 0.5rem;
}
widget-defs-clarification-102020 .dfc-intro {
  margin: 0;
  color: #64748b;
  font-size: 0.85rem;
}
widget-defs-clarification-102020 .dfc-fields {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
widget-defs-clarification-102020 .dfc-row {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
widget-defs-clarification-102020 .dfc-label {
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #94a3b8;
}
widget-defs-clarification-102020 .dfc-value {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.4rem 0.5rem;
  border: 1px solid #e2e8f0;
  border-radius: 0.375rem;
  cursor: pointer;
}
widget-defs-clarification-102020 .dfc-value:hover:not(.is-locked) {
  border-color: #cbd5e1;
  background: #f8fafc;
}
widget-defs-clarification-102020 .dfc-value.is-locked {
  cursor: default;
}
widget-defs-clarification-102020 .dfc-value-text {
  white-space: pre-wrap;
  word-break: break-word;
}
widget-defs-clarification-102020 .dfc-pencil {
  color: #94a3b8;
  flex: none;
}
widget-defs-clarification-102020 .dfc-row-readonly .dfc-readonly-value {
  padding: 0.4rem 0.5rem;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8rem;
  color: #475569;
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  border-radius: 0.375rem;
  word-break: break-all;
}
widget-defs-clarification-102020 .dfc-edit {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}
widget-defs-clarification-102020 .dfc-input,
widget-defs-clarification-102020 .dfc-textarea {
  width: 100%;
  border: 1px solid #cbd5e1;
  border-radius: 0.375rem;
  padding: 0.4rem 0.5rem;
  font: inherit;
}
widget-defs-clarification-102020 .dfc-textarea {
  resize: vertical;
}
widget-defs-clarification-102020 .dfc-edit-actions {
  display: flex;
  gap: 0.35rem;
}
widget-defs-clarification-102020 .dfc-sections {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
widget-defs-clarification-102020 .dfc-section {
  border: 1px solid #e2e8f0;
  border-radius: 0.5rem;
  overflow: hidden;
}
widget-defs-clarification-102020 .dfc-section-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.65rem;
  background: #f8fafc;
  cursor: pointer;
  user-select: none;
}
widget-defs-clarification-102020 .dfc-section-title {
  font-weight: 600;
  flex: 1;
}
widget-defs-clarification-102020 .dfc-count {
  font-size: 0.7rem;
  color: #64748b;
  background: #e2e8f0;
  border-radius: 999px;
  padding: 0 0.4rem;
}
widget-defs-clarification-102020 .dfc-toggle {
  color: #94a3b8;
  font-size: 0.7rem;
}
widget-defs-clarification-102020 .dfc-list {
  list-style: none;
  margin: 0;
  padding: 0.35rem 0.65rem;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
widget-defs-clarification-102020 .dfc-item-content {
  display: flex;
  align-items: flex-start;
  gap: 0.4rem;
}
widget-defs-clarification-102020 .dfc-item-index {
  color: #94a3b8;
  font-variant-numeric: tabular-nums;
  flex: none;
}
widget-defs-clarification-102020 .dfc-item-text {
  flex: 1;
  cursor: pointer;
}
widget-defs-clarification-102020 .dfc-item-text:hover {
  color: #2563eb;
}
widget-defs-clarification-102020 .dfc-item-actions {
  display: flex;
  gap: 0.15rem;
  flex: none;
}
widget-defs-clarification-102020 .dfc-icon {
  border: none;
  background: transparent;
  color: #94a3b8;
  cursor: pointer;
  padding: 0 0.15rem;
}
widget-defs-clarification-102020 .dfc-icon:hover {
  color: #2563eb;
}
widget-defs-clarification-102020 .dfc-btn {
  padding: 0.35rem 0.85rem;
  border-radius: 0.375rem;
  border: 1px solid #cbd5e1;
  background: #fff;
  cursor: pointer;
  font-weight: 600;
}
widget-defs-clarification-102020 .dfc-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
widget-defs-clarification-102020 .dfc-add {
  margin: 0 0.65rem 0.5rem;
  font-weight: 500;
  font-size: 0.8rem;
}
widget-defs-clarification-102020 .dfc-save,
widget-defs-clarification-102020 .dfc-confirm {
  background: #2563eb;
  border-color: #2563eb;
  color: #fff;
}
widget-defs-clarification-102020 .dfc-axes {
  padding-bottom: 0.5rem;
}
widget-defs-clarification-102020 .dfc-axes-header {
  cursor: default;
}
widget-defs-clarification-102020 .dfc-axes-hint {
  margin: 0.35rem 0.65rem 0.5rem;
  font-size: 0.75rem;
  color: #64748b;
}
widget-defs-clarification-102020 .dfc-axis {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.15rem 0.65rem 0.35rem;
}
widget-defs-clarification-102020 .dfc-axis-label {
  flex: 0 0 40%;
  font-size: 0.8rem;
  color: #475569;
}
widget-defs-clarification-102020 .dfc-axis-select {
  flex: 1;
  border: 1px solid #cbd5e1;
  border-radius: 0.375rem;
  padding: 0.3rem 0.4rem;
  font: inherit;
  background: #fff;
}
widget-defs-clarification-102020 .dfc-axis-select:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
widget-defs-clarification-102020 .dfc-warning {
  margin: 0;
  font-size: 0.8rem;
  color: #b45309;
}
widget-defs-clarification-102020 .dfc-footer {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
widget-defs-clarification-102020 .dfc-empty {
  padding: 1rem;
  color: #94a3b8;
}
`);
        this.value = null;
        this.readonly = false;
        this.data = emptyDefsData();
        this.initialized = false;
        this.editingField = null;
        this.editingIndex = null;
        this.tempValue = '';
        this.expanded = new Set(['functional', 'visual']);
        this.msg = messages['en'];
    }
    willUpdate(changed) {
        if (changed.has('value') && this.value && !this.initialized) {
            this.data = { ...emptyDefsData(), ...this.value.data };
            this.initialized = true;
        }
    }
    startEdit(field, currentValue, index = null) {
        if (this.readonly)
            return;
        this.editingField = field;
        this.editingIndex = index;
        this.tempValue = currentValue;
    }
    cancelEdit() {
        this.editingField = null;
        this.editingIndex = null;
        this.tempValue = '';
    }
    saveEdit() {
        if (!this.editingField)
            return;
        if (this.editingIndex !== null) {
            const kind = this.editingField === 'visualRequirements' ? 'visual' : 'functional';
            this.data = applyDefsRequirementEdit(this.data, kind, this.editingIndex, this.tempValue);
        }
        else {
            this.data = applyDefsFieldEdit(this.data, this.editingField, this.tempValue);
        }
        this.cancelEdit();
    }
    onKeydown(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            this.saveEdit();
        }
        else if (event.key === 'Escape') {
            this.cancelEdit();
        }
    }
    toggleSection(section) {
        const next = new Set(this.expanded);
        if (next.has(section))
            next.delete(section);
        else
            next.add(section);
        this.expanded = next;
    }
    addRequirement(kind) {
        const placeholder = kind === 'functional' ? this.msg.newFunctionalRequirement : this.msg.newVisualRequirement;
        this.data = addDefsRequirement(this.data, kind, placeholder);
    }
    removeRequirement(kind, index) {
        this.data = removeDefsRequirement(this.data, kind, index);
    }
    get axes() {
        return this.value?.axes || [];
    }
    onAxisChange(key, value) {
        this.data = applyDefsAxisValue(this.data, this.axes, key, value);
    }
    finish(action) {
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: { value: buildDefsResult(this.data, this.axes), action },
            bubbles: true,
            composed: true,
        }));
    }
    // One select per axis the group is governed by, pre-selected with what the model proposed. The
    // options are the vocabulary's closed enum plus a wildcard — the user never types a value.
    renderAxes() {
        const axes = this.axes;
        if (!axes.length)
            return nothing;
        return html `
      <div class="dfc-section dfc-axes">
        <div class="dfc-section-header dfc-axes-header">
          <span class="dfc-section-title">${this.msg.layoutAxes}</span>
        </div>
        <p class="dfc-axes-hint">${this.msg.layoutAxesHint}</p>
        ${axes.map(axis => html `
          <div class="dfc-axis">
            <label class="dfc-axis-label" for=${`dfc-axis-${axis.key}`}>${axis.label}</label>
            <select
              id=${`dfc-axis-${axis.key}`}
              class="dfc-axis-select"
              ?disabled=${this.readonly}
              .value=${this.data.layoutConfig[axis.key] ?? DEFS_AXIS_WILDCARD}
              @change=${(e) => this.onAxisChange(axis.key, e.target.value)}
            >
              <option value=${DEFS_AXIS_WILDCARD}>${this.msg.axisWildcard}</option>
              ${axis.values.map(value => html `
                <option value=${value} ?selected=${this.data.layoutConfig[axis.key] === value}>
                  ${value}${value === axis.default ? ` (${this.msg.axisDefaultHint})` : ''}
                </option>
              `)}
            </select>
          </div>
        `)}
      </div>
    `;
    }
    renderReadonlyRow(label, text) {
        return html `
      <div class="dfc-row dfc-row-readonly">
        <span class="dfc-label">${label}</span>
        <span class="dfc-readonly-value">${text}</span>
      </div>
    `;
    }
    renderEditable(label, field, multiline = false) {
        const value = this.data[field];
        const isEditing = this.editingField === field && this.editingIndex === null;
        return html `
      <div class="dfc-row">
        <span class="dfc-label">${label}</span>
        ${isEditing ? html `
          <div class="dfc-edit">
            ${multiline ? html `
              <textarea
                class="dfc-textarea"
                rows="4"
                .value=${this.tempValue}
                @input=${(e) => { this.tempValue = e.target.value; }}
                @keydown=${this.onKeydown}
              ></textarea>
            ` : html `
              <input
                type="text"
                class="dfc-input"
                .value=${this.tempValue}
                @input=${(e) => { this.tempValue = e.target.value; }}
                @keydown=${this.onKeydown}
              />
            `}
            <div class="dfc-edit-actions">
              <button class="dfc-btn dfc-save" @click=${this.saveEdit}>${this.msg.save}</button>
              <button class="dfc-btn" @click=${this.cancelEdit}>${this.msg.cancel}</button>
            </div>
          </div>
        ` : html `
          <div class="dfc-value ${this.readonly ? 'is-locked' : ''}" @click=${() => this.startEdit(field, value)}>
            <span class="dfc-value-text">${value || this.msg.clickToEdit}</span>
            ${this.readonly ? nothing : html `<span class="dfc-pencil">✎</span>`}
          </div>
        `}
      </div>
    `;
    }
    renderRequirements(label, kind) {
        const key = kind === 'functional' ? 'functionalRequirements' : 'visualRequirements';
        const items = this.data[key];
        const isExpanded = this.expanded.has(kind);
        return html `
      <div class="dfc-section">
        <div class="dfc-section-header" @click=${() => this.toggleSection(kind)}>
          <span class="dfc-section-title">${label}</span>
          <span class="dfc-count">${items.length}</span>
          <span class="dfc-toggle">${isExpanded ? '▼' : '▶'}</span>
        </div>
        ${isExpanded ? html `
          <ul class="dfc-list">
            ${items.map((item, index) => html `
              <li class="dfc-item">
                ${this.editingField === key && this.editingIndex === index ? html `
                  <div class="dfc-edit">
                    <textarea
                      class="dfc-textarea"
                      rows="3"
                      .value=${this.tempValue}
                      @input=${(e) => { this.tempValue = e.target.value; }}
                      @keydown=${this.onKeydown}
                    ></textarea>
                    <div class="dfc-edit-actions">
                      <button class="dfc-btn dfc-save" @click=${this.saveEdit}>${this.msg.save}</button>
                      <button class="dfc-btn" @click=${this.cancelEdit}>${this.msg.cancel}</button>
                    </div>
                  </div>
                ` : html `
                  <div class="dfc-item-content">
                    <span class="dfc-item-index">${index + 1}.</span>
                    <span class="dfc-item-text" @click=${() => this.startEdit(key, item, index)}>${item}</span>
                    ${this.readonly ? nothing : html `
                      <span class="dfc-item-actions">
                        <button class="dfc-icon" title=${this.msg.edit} @click=${() => this.startEdit(key, item, index)}>✎</button>
                        <button class="dfc-icon" title=${this.msg.remove} @click=${() => this.removeRequirement(kind, index)}>✕</button>
                      </span>
                    `}
                  </div>
                `}
              </li>
            `)}
          </ul>
          ${this.readonly ? nothing : html `
            <button class="dfc-btn dfc-add" @click=${() => this.addRequirement(kind)}>${this.msg.addRequirement}</button>
          `}
        ` : nothing}
      </div>
    `;
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)];
        if (!this.value)
            return html `<div class="dfc-empty">No clarification.</div>`;
        const tag = tagFromFileReference(this.data.fileReference);
        const axesIncomplete = this.axes.length > 0 && !this.axes.some(axis => !!this.data.layoutConfig[axis.key]);
        const canConfirm = !this.readonly && canConfirmDefs(this.data, this.axes);
        return html `
      <div class="dfc">
        <header class="dfc-header">
          <h2 class="dfc-title">${this.value.title || this.msg.title}</h2>
          <span class="dfc-group-chip">${this.data.group}</span>
        </header>
        <p class="dfc-intro">${this.value.intro || this.msg.intro}</p>

        <div class="dfc-fields">
          ${this.renderEditable(this.msg.fileReference, 'fileReference')}
          ${this.renderReadonlyRow(this.msg.tagName, tag || '—')}
          ${this.renderReadonlyRow(this.msg.group, this.data.group || '—')}
          ${this.renderReadonlyRow(this.msg.theme, this.value.themeLabel || this.msg.noTheme)}
          ${this.renderEditable(this.msg.description, 'description', true)}
          ${this.renderEditable(this.msg.prompt, 'prompt', true)}
        </div>

        <div class="dfc-sections">
          ${this.renderRequirements(this.msg.functionalRequirements, 'functional')}
          ${this.renderRequirements(this.msg.visualRequirements, 'visual')}
          ${this.renderAxes()}
        </div>

        ${!this.readonly && !canConfirm ? html `<p class="dfc-warning">${axesIncomplete ? this.msg.incompleteAxes : this.msg.incomplete}</p>` : nothing}

        <footer class="dfc-footer">
          <button class="dfc-btn" ?disabled=${this.readonly} @click=${() => this.finish('cancel')}>${this.msg.cancel}</button>
          <button class="dfc-btn dfc-confirm" ?disabled=${!canConfirm} @click=${() => this.finish('continue')}>${this.msg.confirm}</button>
        </footer>
      </div>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetDefsClarification102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetDefsClarification102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "data", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "initialized", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "editingField", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "editingIndex", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "tempValue", void 0);
__decorate([
    state()
], WidgetDefsClarification102020.prototype, "expanded", void 0);
WidgetDefsClarification102020 = __decorate([
    customElement('widget-defs-clarification-102020')
], WidgetDefsClarification102020);
export { WidgetDefsClarification102020 };
