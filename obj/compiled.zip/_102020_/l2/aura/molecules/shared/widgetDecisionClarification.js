/// <mls fileReference="_102020_/l2/aura/molecules/shared/widgetDecisionClarification.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// Generic "Decision Clarification" widget: renders a set of questions (each with
// options + an optional free-text note) and emits a `clarification-finish` CustomEvent
// with { value: { answers }, action: 'continue' | 'cancel' }. Reusable by any agent's
// checkpoint (collab_messages.md "Rendering a checkpoint"). No Shadow DOM (StateLitElement)
// — styles live in the sibling .less scoped under the tag.
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { allDecisionAnswered, buildDecisionResult, initialDecisionAnswers, } from '/_102020_/l2/aura/molecules/shared/widgetDecisionClarificationLogic.js';
let WidgetDecisionClarification102020 = class WidgetDecisionClarification102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-decision-clarification-102020 {
  display: block;
}
widget-decision-clarification-102020 .dc {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1rem;
}
widget-decision-clarification-102020 .dc-title {
  font-size: 1.1rem;
  font-weight: 700;
  margin: 0;
}
widget-decision-clarification-102020 .dc-intro {
  margin: 0;
  color: #64748b;
  font-size: 0.9rem;
}
widget-decision-clarification-102020 .dc-q {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 0.75rem;
  border: 1px solid #e2e8f0;
  border-radius: 0.5rem;
}
widget-decision-clarification-102020 .dc-q-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #94a3b8;
}
widget-decision-clarification-102020 .dc-q-text {
  font-weight: 600;
}
widget-decision-clarification-102020 .dc-options {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}
widget-decision-clarification-102020 .dc-option {
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
  cursor: pointer;
}
widget-decision-clarification-102020 .dc-option.is-recommended .dc-option-label {
  font-weight: 600;
}
widget-decision-clarification-102020 .dc-badge {
  margin-left: 0.4rem;
  font-size: 0.65rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #2563eb;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 999px;
  padding: 0 0.4rem;
}
widget-decision-clarification-102020 .dc-option-desc {
  color: #94a3b8;
  font-size: 0.8rem;
}
widget-decision-clarification-102020 .dc-notes {
  width: 100%;
  min-height: 2.5rem;
  border: 1px solid #e2e8f0;
  border-radius: 0.375rem;
  padding: 0.4rem 0.5rem;
  font: inherit;
  resize: vertical;
}
widget-decision-clarification-102020 .dc-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
widget-decision-clarification-102020 .dc-btn {
  padding: 0.45rem 1rem;
  border-radius: 0.375rem;
  border: 1px solid #cbd5e1;
  background: #fff;
  cursor: pointer;
  font-weight: 600;
}
widget-decision-clarification-102020 .dc-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
widget-decision-clarification-102020 .dc-continue {
  background: #2563eb;
  border-color: #2563eb;
  color: #fff;
}
widget-decision-clarification-102020 .empty {
  padding: 1rem;
  color: #94a3b8;
}
`);
        this.value = null;
        this.readonly = false;
        this.localAnswers = {};
        this.initialized = false;
    }
    willUpdate(changed) {
        if (changed.has('value') && this.value && !this.initialized) {
            this.localAnswers = initialDecisionAnswers(this.value.questions);
            this.initialized = true;
        }
    }
    onSelect(questionId, optionId) {
        const prev = this.localAnswers[questionId] || { optionId: '', notes: '' };
        this.localAnswers = { ...this.localAnswers, [questionId]: { ...prev, optionId } };
    }
    onNotes(questionId, notes) {
        const prev = this.localAnswers[questionId] || { optionId: '', notes: '' };
        this.localAnswers = { ...this.localAnswers, [questionId]: { ...prev, notes } };
    }
    finish(action) {
        const answers = this.value ? buildDecisionResult(this.value.questions, this.localAnswers) : [];
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: { value: { answers }, action },
            bubbles: true,
        }));
    }
    render() {
        if (!this.value)
            return html `<div class="empty">No clarification.</div>`;
        const canContinue = !this.readonly && allDecisionAnswered(this.value.questions, this.localAnswers);
        return html `
      <div class="dc">
        <h2 class="dc-title">${this.value.title}</h2>
        ${this.value.intro ? html `<p class="dc-intro">${this.value.intro}</p>` : nothing}
        ${this.value.questions.map(q => html `
          <div class="dc-q">
            ${q.title ? html `<div class="dc-q-title">${q.title}</div>` : nothing}
            <div class="dc-q-text">${q.question}</div>
            <div class="dc-options">
              ${q.options.map(opt => html `
                <label class="dc-option ${opt.recommended ? 'is-recommended' : ''}">
                  <input
                    type="radio"
                    name=${q.id}
                    .checked=${this.localAnswers[q.id]?.optionId === opt.id}
                    ?disabled=${this.readonly}
                    @change=${() => this.onSelect(q.id, opt.id)}
                  />
                  <span class="dc-option-label">${opt.label}${opt.recommended ? html `<span class="dc-badge">recommended</span>` : nothing}</span>
                  ${opt.description ? html `<span class="dc-option-desc">${opt.description}</span>` : nothing}
                </label>
              `)}
            </div>
            ${q.allowNotes ? html `
              <textarea
                class="dc-notes"
                placeholder=${q.notesPlaceholder || 'Custom / notes'}
                ?disabled=${this.readonly}
                .value=${this.localAnswers[q.id]?.notes ?? ''}
                @input=${(e) => this.onNotes(q.id, e.target.value)}
              ></textarea>
            ` : nothing}
          </div>
        `)}
        <div class="dc-actions">
          <button class="dc-btn dc-cancel" ?disabled=${this.readonly} @click=${() => this.finish('cancel')}>Cancel</button>
          <button class="dc-btn dc-continue" ?disabled=${!canContinue} @click=${() => this.finish('continue')}>Continue</button>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetDecisionClarification102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetDecisionClarification102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetDecisionClarification102020.prototype, "localAnswers", void 0);
__decorate([
    state()
], WidgetDecisionClarification102020.prototype, "initialized", void 0);
WidgetDecisionClarification102020 = __decorate([
    customElement('widget-decision-clarification-102020')
], WidgetDecisionClarification102020);
export { WidgetDecisionClarification102020 };
