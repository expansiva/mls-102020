/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules2/helpers/cm2Types.ts" enhancement="_blank"/>
// Types, constants and the PURE helpers of agentChooseMolecules2. No I/O beyond the tiny stor read for
// this agent's own prompt/schema files (readCm2AgentText) — everything else here is pure.
//
// Unlike agentChooseMolecules (the probe), there is NO l4 artifact anywhere in this agent: c1's answer
// and every c2's answer travel ONLY through the task tree's step `result` field (cm2ReadStepResult),
// the same mechanism the probe already uses to read c1 from its fan-out — never a file on disk. The
// only file this agent ever writes is the target `.defs.ts` itself (steps/c3-patch).
import { isRecord, parseMaybeJson, readStorText } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
export const CM2_AGENT_NAME = 'agentChooseMolecules2';
export const CM2_AGENT_FOLDER = 'aura/molecules/agentChooseMolecules2';
export const CM2_AGENT_PROJECT = 102020;
/** One retry with the gate errors in the prompt, same budget as the probe. */
export const CM2_MAX_ATTEMPTS = 2;
export const CM2_PLAN_C1 = 'c1-groups';
export const CM2_PLAN_FANOUT = 'c1r-fanout';
export const CM2_PLAN_C3 = 'c3-patch';
/** 'c1-groups' -> 'c1-done'. The c2 steps use cm2GroupDoneAnchor instead — see agentChooseMolecules
 * for why splitting on '-' would collide every group onto the same 'c2-done'. */
export function cm2DoneAnchor(planId) {
    return `${planId.split('-')[0]}-done`;
}
export function cm2GroupFolder(groupName) {
    return (groupName || '').trim().toLowerCase();
}
export function cm2GroupPlanId(groupName) {
    return `c2-${cm2GroupFolder(groupName)}`;
}
export function cm2GroupDoneAnchor(groupName) {
    return `${cm2GroupPlanId(groupName)}-done`;
}
// ---- this agent's own files (prompt.md, schemas), in its 102020 folder ----
export function cm2AgentFile(folder, shortName, extension) {
    const sub = folder ? `${CM2_AGENT_FOLDER}/${folder}` : CM2_AGENT_FOLDER;
    return { project: CM2_AGENT_PROJECT, level: 2, folder: sub, shortName, extension };
}
export async function readCm2AgentText(folder, shortName, extension, required = false) {
    return readStorText(cm2AgentFile(folder, shortName, extension), required);
}
export function cm2ParseStepArgs(value) {
    const parsed = parseMaybeJson(value);
    if (!isRecord(parsed))
        return {};
    return {
        planId: typeof parsed.planId === 'string' ? parsed.planId : undefined,
        catalogProject: typeof parsed.catalogProject === 'number' ? parsed.catalogProject : undefined,
        target: typeof parsed.target === 'string' ? parsed.target : undefined,
        group: typeof parsed.group === 'string' ? parsed.group : undefined,
        retryAttempt: typeof parsed.retryAttempt === 'number' ? parsed.retryAttempt : undefined,
        retryContext: typeof parsed.retryContext === 'string' ? parsed.retryContext : undefined,
    };
}
/** '/_102040_/l2/molecules/groupselectone/ml-select-one' from catalogProject + a published tag —
 * always derivable (the catalog itself proves the file exists, via the group's own molecules[].tag). */
export function cm2ComponentReference(catalogProject, tag) {
    const separator = tag.indexOf('--');
    const groupFolder = separator < 0 ? tag : tag.slice(0, separator);
    const shortName = separator < 0 ? tag : tag.slice(separator + 2);
    return `/_${catalogProject}_/l2/molecules/${groupFolder}/${shortName}`;
}
/** The result JSON of the step whose planning.planId === anchor, or null when it hasn't landed yet. */
export function cm2ReadStepResult(context, anchor) {
    const found = getAllSteps(context.task?.iaCompressed?.nextSteps).find(item => item.type === 'result' && item.planning?.planId === anchor);
    const parsed = parseMaybeJson(found?.result);
    return isRecord(parsed) ? parsed : null;
}
export function cm2ReadC1Result(context) {
    return cm2ReadStepResult(context, cm2DoneAnchor(CM2_PLAN_C1));
}
export function cm2ReadGroupResult(context, group) {
    return cm2ReadStepResult(context, cm2GroupDoneAnchor(group));
}
