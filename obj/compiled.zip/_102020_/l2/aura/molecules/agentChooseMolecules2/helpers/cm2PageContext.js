/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules2/helpers/cm2PageContext.ts" enhancement="_blank"/>
const LABELS = ['page', 'actor', 'purpose', 'uxExperience'];
export function extractPageContext(definitionText) {
    const found = {};
    for (const line of String(definitionText || '').split('\n')) {
        const match = /^\s*([A-Za-z][A-Za-z0-9]*)\s*:\s*(.+?)\s*$/u.exec(line);
        if (!match)
            continue;
        const [, label, value] = match;
        // First occurrence wins: the closing paragraph is prose and may well contain a colon.
        if (LABELS.includes(label) && !found[label])
            found[label] = value;
    }
    return {
        page: found.page || '',
        actor: found.actor || '',
        purpose: found.purpose || '',
        uxExperience: found.uxExperience || '',
    };
}
/** '' when the target declares none of it — the caller then omits the whole prompt section. */
export function formatPageContext(context) {
    const lines = [];
    if (context.page)
        lines.push(`Page: ${context.page}`);
    if (context.actor)
        lines.push(`Actor who uses it: ${context.actor}`);
    if (context.purpose)
        lines.push(`Purpose: ${context.purpose}`);
    if (context.uxExperience) {
        lines.push('');
        lines.push(`Experience shape ALREADY DECIDED for this page: **${context.uxExperience}**. A molecule that contradicts it is the wrong molecule, however well it fits the region's own words — and it is what rules a SPECIFIC scenario row in or out, so read it before settling for a broad one.`);
    }
    if (!lines.length)
        return '';
    return ['## What this page is for (declared in the target file)', '', ...lines].join('\n');
}
