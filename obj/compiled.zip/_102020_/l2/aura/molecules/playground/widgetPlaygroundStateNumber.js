/// <mls fileReference="_102020_/l2/aura/molecules/playground/widgetPlaygroundStateNumber.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, property } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let WcInputNumber102020 = class WcInputNumber102020 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aura--molecules--playground--widget-playground-state-number-102020 {
  display: block;
  margin-bottom: 0.5rem;
}
`);
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.error = '';
    }
    render() {
        return html `
      <div class="flex flex-col gap-1">

        ${this.label ? html `
          <label class="text-sm font-medium text-gray-700 dark:text-gray-300">
            ${this.label}
          </label>
        ` : null}

        <input
          type="number"
          class="
            w-full px-3 py-2 rounded-lg border
            text-sm text-gray-900 dark:text-gray-100
            bg-white dark:bg-slate-800
            border-gray-300 dark:border-slate-600
            transition outline-none

            focus:ring-2 focus:ring-blue-500 focus:border-blue-500
            dark:focus:ring-blue-400 dark:focus:border-blue-400

            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed
            dark:disabled:bg-slate-700 dark:disabled:text-slate-500

            placeholder:text-gray-400 dark:placeholder:text-slate-500

            ${this.error ? 'border-red-500 focus:ring-red-500 focus:border-red-500 dark:border-red-400 dark:focus:ring-red-400 dark:focus:border-red-400' : ''}
          "
          name=${ifDefined(this.name)}
          .value=${this.value ?? ''}
          min=${ifDefined(this.min)}
          max=${ifDefined(this.max)}
          step=${ifDefined(this.step)}
          placeholder=${ifDefined(this.placeholder)}
          ?disabled=${this.disabled}
          ?readonly=${this.readonly}
          ?required=${this.required}
          @input=${this.handleChange}
        />

        ${this.hint ? html `
          <small class="text-xs text-gray-500 dark:text-gray-400">${this.hint}</small>
        ` : null}

        ${this.error ? html `
          <div class="text-xs text-red-500 dark:text-red-400 font-medium">${this.error}</div>
        ` : null}

      </div>
    `;
    }
    handleChange(event) {
        const input = event.target;
        this.value = input.value ? Number(input.value) : undefined;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], WcInputNumber102020.prototype, "value", void 0);
__decorate([
    property({ type: String })
], WcInputNumber102020.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputNumber102020.prototype, "label", void 0);
__decorate([
    property({ type: Number })
], WcInputNumber102020.prototype, "min", void 0);
__decorate([
    property({ type: Number })
], WcInputNumber102020.prototype, "max", void 0);
__decorate([
    property({ type: Number })
], WcInputNumber102020.prototype, "step", void 0);
__decorate([
    property({ type: String })
], WcInputNumber102020.prototype, "placeholder", void 0);
__decorate([
    property({ type: Boolean })
], WcInputNumber102020.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcInputNumber102020.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WcInputNumber102020.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputNumber102020.prototype, "hint", void 0);
WcInputNumber102020 = __decorate([
    customElement('aura--molecules--playground--widget-playground-state-number-102020')
], WcInputNumber102020);
export { WcInputNumber102020 };
