/// <mls fileReference="_102020_/l2/aura/molecules/playground/widgetPlaygroundState.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { initState, setState } from '/_102029_/l2/collabState.js';
let WidgetPlaygroundState = class WidgetPlaygroundState extends LitElement {
    constructor() {
        super(...arguments);
        this.state = '';
    }
    connectedCallback() {
        setState('playground', {});
        // Seed SÍNCRONO, antes de qualquer 1º render das moléculas da página: os upgrades
        // só agendam o render como microtask, então semear aqui elimina a corrida em que
        // uma molécula lê {{playground.*}} antes do estado existir (era no firstUpdated).
        this.initStatePlayground();
        super.connectedCallback();
    }
    render() {
        return html ``;
    }
    initStatePlayground() {
        try {
            // getAttribute: a property pode ainda não ter sido sincronizada pelo Lit aqui.
            const raw = this.getAttribute('state') || this.state;
            if (!raw)
                return;
            const js = JSON.parse(raw);
            Object.keys({ ...js }).forEach((k) => {
                initState(k, js[k]);
            });
        }
        catch (e) {
            console.info(e.message);
        }
    }
};
__decorate([
    property({ type: String })
], WidgetPlaygroundState.prototype, "state", void 0);
WidgetPlaygroundState = __decorate([
    customElement('aura--molecules--playground--widget-playground-state-102020')
], WidgetPlaygroundState);
export { WidgetPlaygroundState };
