/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s1-group/agentSyGroup.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { nmFileExists, nmDestProject, readStorText, writeJsonArtifact, writeStorTextAtomic } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { SY_AGENT_PROJECT, syGroupDoneAnchor, syGroupFolder, } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syTypes.js';
import { syExtractExistingScenarios, syExtractMoleculeDefs, syExtractTag, syHarvestScenarios, syPublishedLayout, syVaryingAxes, } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syExtract.js';
import { syRenderIndexDefs, syRenderIndexHtml } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syRenderDefs.js';
import { nmDefsFile, nmGroupDefsFile, nmGroupIndexFile, nmTsFile, syGroupArtifactFileInfo, syScanGroupMoleculeShortNames, } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syFs.js';
const AGENT_NAME = 'agentSyGroup';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: SY_AGENT_PROJECT,
        agentFolder: 'aura/molecules/agentSyncMoleculeCatalog/steps/s1-group',
        agentDescription: "s1-group — writes one group's index.defs.ts and index.html, derived from its molecule files. No LLM.",
        visibility: 'private',
        beforePromptStep,
    };
}
function parseGroupStepArgs(prompt) {
    const raw = typeof prompt === 'string' ? prompt : '';
    if (!raw.trim().startsWith('{'))
        return null;
    try {
        const parsed = JSON.parse(raw);
        const group = typeof parsed.group === 'string' ? parsed.group.trim() : '';
        if (!group)
            return null;
        return {
            group,
            purpose: typeof parsed.purpose === 'string' ? parsed.purpose : '',
            usageContract: typeof parsed.usageContract === 'string' ? parsed.usageContract : '',
        };
    }
    catch {
        return null;
    }
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const stepArgs = nmParseStepArgs(step.prompt);
    const groupArgs = parseGroupStepArgs(step.prompt);
    if (!stepArgs.runKey || !groupArgs) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] step args missing runKey/group/purpose/usageContract`)];
    }
    const runKey = stepArgs.runKey;
    const { group: canonical, purpose, usageContract } = groupArgs;
    const folder = syGroupFolder(canonical);
    const project = nmDestProject();
    const shortNames = syScanGroupMoleculeShortNames(folder);
    if (!shortNames.length) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] no molecule files found under molecules/${folder}`)];
    }
    const warnings = [];
    const extracted = [];
    for (const shortName of shortNames) {
        const tsSource = await readStorText(nmTsFile(folder, shortName), false);
        const tag = syExtractTag(tsSource);
        if (!tag) {
            warnings.push(`${shortName}.ts: nenhum @customElement encontrado — molécula ignorada`);
            continue;
        }
        const defsInfo = nmDefsFile(folder, shortName);
        const hasDefs = nmFileExists(defsInfo);
        const defsExtracted = hasDefs ? syExtractMoleculeDefs(await readStorText(defsInfo, false)) : null;
        if (hasDefs && !defsExtracted)
            warnings.push(`${shortName}.defs.ts: sem '# Objective' legível — tratada como sem contrato`);
        extracted.push({
            tag,
            shortName,
            layoutConfig: defsExtracted?.layoutConfig || {},
            objective: defsExtracted?.objective || null,
            defsRef: defsExtracted ? `/_${project}_/l2/molecules/${folder}/${shortName}.defs` : null,
        });
    }
    if (!extracted.length) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] every molecule of ${folder} was unreadable: ${warnings.join('; ')}`)];
    }
    const varyingAxes = syVaryingAxes(extracted.filter(m => m.defsRef).map(m => m.layoutConfig));
    const molecules = extracted
        .slice()
        .sort((a, b) => a.tag.localeCompare(b.tag))
        .map(m => ({
        tag: m.tag,
        shortName: m.shortName,
        layout: syPublishedLayout(m.layoutConfig, varyingAxes),
        defsRef: m.defsRef,
        objective: m.objective,
    }));
    const { scenarios, scenariosSource } = await resolveScenarios(folder, extracted.map(m => ({ tag: m.tag })));
    const generatedAt = new Date().toISOString();
    const indexDefsText = syRenderIndexDefs({ project, groupCanonical: canonical, groupFolder: folder, usageContract, purpose, molecules, scenarios, generatedAt });
    const indexHtmlText = syRenderIndexHtml(folder, project);
    await writeStorTextAtomic(nmGroupDefsFile(folder), indexDefsText);
    await writeStorTextAtomic(nmGroupIndexFile(folder, '.html'), indexHtmlText);
    const artifact = {
        schemaVersion: 1,
        savedAt: generatedAt,
        runKey,
        folder,
        canonical,
        purpose,
        usageContract,
        // Derived from the TAG, not the filename-based shortName: the tag is the authoritative source
        // (§4.4), and this is exactly the "Moléculas: ml-x, ml-y" line skill.ts (level 1) needs.
        moleculeShortTags: molecules.map(m => (m.tag.includes('--') ? m.tag.slice(m.tag.indexOf('--') + 2) : m.tag)),
        moleculesWithoutDefs: molecules.filter(m => !m.defsRef).map(m => m.tag),
        scenarioCount: scenarios.length,
        scenariosSource,
        indexDefsFile: `l2/molecules/${folder}/index.defs.ts`,
        indexHtmlFile: `l2/molecules/${folder}/index.html`,
    };
    await writeJsonArtifact(syGroupArtifactFileInfo(runKey, folder), artifact);
    const note = `${folder}: ${molecules.length} molécula(s), ${scenarios.length} cenário(s) (${scenariosSource})${warnings.length ? ` — ${warnings.length} aviso(s)` : ''}`;
    return [
        nmResultStepIntent(context, parentStep, {
            planId: syGroupDoneAnchor(canonical),
            dependsOn: [],
            stepTitle: note,
            result: { ...artifact, warnings },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', note, 'input_output'),
    ];
}
/**
 * Scenarios come from ONE of three places, in this order (todo §4.4 / §6.1):
 * 1. Already in this group's index.defs.ts from a PREVIOUS sync — editorial content is preserved, never
 *    re-derived (the one field in the catalog that is not derived).
 * 2. Harvested from the group's CURRENT index.ts, mechanically — the first sync of a group that already
 *    has an authored showcase page with a hand-written `renderReferenceTable()`.
 * 3. Empty — a brand-new group with no index.ts yet (G1), or a page whose table could not be parsed.
 */
async function resolveScenarios(folder, molecules) {
    const existingDefsText = await readStorText(nmGroupDefsFile(folder), false);
    const existing = syExtractExistingScenarios(existingDefsText);
    if (existing && existing.length)
        return { scenarios: existing, scenariosSource: 'preserved-existing' };
    const indexTsExists = nmFileExists(nmGroupIndexFile(folder, '.ts'));
    const indexTsText = indexTsExists ? await readStorText(nmGroupIndexFile(folder, '.ts'), false) : '';
    const harvested = syHarvestScenarios(indexTsText, molecules);
    if (harvested)
        return { scenarios: harvested, scenariosSource: 'harvested' };
    return { scenarios: [], scenariosSource: 'empty-no-source' };
}
