/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s3-indexts/createGate.ts" enhancement="_blank"/>
import { syMoleculesNotShown } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syMigrateIndexTs.js';
import { contractItemsMissing, contractItemsUsed, usageContractItems } from '/_102020_/l2/aura/molecules/shared/usageContract.js';
export function runSyCreateIndexTsGate(indexTs, options) {
    const issues = [];
    const content = indexTs || '';
    if (!content.trim())
        return [{ code: 'empty', message: 'index.ts came out empty' }];
    if (content.includes('```')) {
        issues.push({ code: 'fence', message: 'index.ts must be raw TypeScript, without markdown fences' });
    }
    if (!content.includes(options.headerRef)) {
        issues.push({ code: 'header', message: `the index.ts header must reference ${options.headerRef}` });
    }
    if (!content.includes(`@customElement('${options.indexTag}')`)) {
        issues.push({ code: 'custom_element', message: `index.ts must declare @customElement('${options.indexTag}')` });
    }
    // ⚠️ IMPORTED AND SHOWN ARE TWO DIFFERENT CHECKS, and merging them into one `content.includes(name)`
    // made this gate pass THE DEFECT IT EXISTS TO CATCH. Measured 2026-08-27 against a fixture: a page that
    // imported `ml-b` and never instantiated it came back with zero issues, because the import line alone
    // satisfies `includes`. That is the 2026-08-05 defect verbatim — a molecule imported and never shown,
    // found by accident days later — and it is why `i6-index` carries the invariant at all.
    //
    // So: count the IMPORT (exactly once, never twice) and look for the INSTANCE outside the import lines
    // — syMoleculesNotShown (helpers/syMigrateIndexTs.ts), shared with the G4 regeneration trigger.
    const notImported = [];
    const importedTwice = [];
    for (const shortName of options.groupMoleculeShortNames) {
        // matched by PATH END, so `ml-data-table` never counts an `ml-data-table-select` import as its own
        const importRe = new RegExp(`^\\s*import\\s+['"][^'"]*/${escapeForRegExp(shortName)}(?:\\.js)?['"];?\\s*$`, 'gm');
        const importCount = (content.match(importRe) || []).length;
        if (importCount === 0)
            notImported.push(shortName);
        else if (importCount > 1)
            importedTwice.push(shortName);
    }
    const notShown = syMoleculesNotShown(content, options.groupFolder, options.groupMoleculeShortNames);
    if (notImported.length) {
        issues.push({
            code: 'molecule_missing',
            message: `these molecules of the group are never imported: ${notImported.join(', ')} — the page must import every molecule of the group`,
        });
    }
    if (importedTwice.length) {
        issues.push({
            code: 'molecule_imported_twice',
            message: `these molecules are imported more than once: ${importedTwice.join(', ')} — exactly one import each`,
        });
    }
    if (notShown.length) {
        issues.push({
            code: 'molecule_not_shown',
            message: `these molecules are imported but never instantiated: ${notShown.join(', ')} — imported and never shown is a silent gap (the defect of 2026-08-05); every molecule needs a <${options.groupFolder}--…> instance on the page`,
        });
    }
    if (!content.includes(`from '${options.indexDefsReference}'`)) {
        issues.push({ code: 'defs_import', message: `index.ts must import { molecules, scenarios } from '${options.indexDefsReference}'` });
    }
    if (!content.includes(`from '${options.sharedTableReference}'`)) {
        issues.push({ code: 'shared_import', message: `index.ts must import { renderCatalogReferenceTable } from '${options.sharedTableReference}'` });
    }
    // ⚠️ THE PAGE MUST BE BORN MIGRATED (the brief §3). renderReferenceTable() must be EXACTLY the 3-line
    // delegating call — never a hand-written table for a later run to fix.
    if (!content.includes('renderCatalogReferenceTable(molecules, scenarios)')) {
        issues.push({
            code: 'reference_table_not_delegated',
            message: "renderReferenceTable() must return renderCatalogReferenceTable(molecules, scenarios) — do not hand-write the reference table",
        });
    }
    if (/<table[\s>]/i.test(content) || /\bheaders\s*\.map\(/.test(content) || /\bconst\s+rows\s*[:=]/.test(content)) {
        issues.push({
            code: 'reference_table_handwritten',
            message: 'index.ts must not hand-write the reference table (<table>, headers.map(...), or a rows array) — the markup and data both come from renderCatalogReferenceTable/index.defs.ts',
        });
    }
    // The showcase must demonstrate the molecule's OWN contract (usage skill Properties/Events), not just
    // the mold's envelope (name/value/isEditing/@change). See shared/usageContract.ts for why.
    const contract = usageContractItems(options.groupUsageSkill || '');
    if (contract.size && !contractItemsUsed(content, options.groupFolder, contract).length) {
        const sample = contractItemsMissing(options.groupUsageSkill || '', content, options.groupFolder).slice(0, 5).join(', ');
        issues.push({
            code: 'contract_not_demonstrated',
            message: `the showcase never uses any property or event from the group's usage contract beyond the mold's envelope (name/value/isEditing/@change) — e.g. ${sample}; read the group usage skill's Properties and Events tables and add them to at least one card`,
        });
    }
    return issues;
}
/** A molecule short name is plain, but never trust it into a RegExp unescaped. */
function escapeForRegExp(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
