/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s4-report/report.ts" enhancement="_blank"/>
export const SY_INDEX_TS_HOWTO = "para incluir o index.ts, mencione o agente com 'incluindo o arquivo index.ts' ou 'com todos os arquivos' depois dos grupos";
export const SY_PUBLISH_WARNING = 'o catálogo foi gravado no stor (editor), mas NÃO foi publicado — não existe API de publicação nesta plataforma (D5). ' +
    'Um consumidor fora do editor (await import()) ainda lê o catálogo anterior, e um projeto publicado com esta edição não salva lê o conteúdo ANTIGO, sem erro nenhum. Publique o projeto manualmente para que o catálogo valha.';
export function buildSyRunReport(facts) {
    return {
        schemaVersion: 1,
        savedAt: facts.savedAt,
        runKey: facts.runKey,
        project: facts.project,
        written: {
            skillFile: facts.projectArtifact?.skillFile || null,
            groupCount: facts.groupArtifacts.length,
            moleculeCount: facts.groupArtifacts.reduce((sum, g) => sum + g.moleculeShortTags.length, 0),
            groups: facts.groupArtifacts
                .map(g => ({
                canonical: g.canonical,
                folder: g.folder,
                indexDefsFile: g.indexDefsFile,
                indexHtmlFile: g.indexHtmlFile,
                moleculeCount: g.moleculeShortTags.length,
                moleculesWithoutDefs: g.moleculesWithoutDefs,
                scenarioCount: g.scenarioCount,
                scenariosSource: g.scenariosSource,
            }))
                .sort((a, b) => a.folder.localeCompare(b.folder)),
        },
        ignored: facts.input.ignoredGroups,
        requestedButIgnored: facts.input.requestedButIgnoredGroups,
        unknown: facts.input.unknownGroups,
        indexTs: { requested: facts.input.includeIndexTsRequested, touched: false, howToRequest: SY_INDEX_TS_HOWTO },
        publish: { published: false, warning: SY_PUBLISH_WARNING },
    };
}
export function renderSyRunSummary(report) {
    const lines = [];
    lines.push(`agentSyncMoleculeCatalog — run ${report.runKey} (mls-${report.project})`);
    lines.push('');
    lines.push(`Gravado: ${report.written.skillFile || 'l2/molecules/skill.ts'} + ${report.written.groupCount} grupo(s), ${report.written.moleculeCount} molécula(s) no total.`);
    for (const group of report.written.groups) {
        const defsNote = group.moleculesWithoutDefs.length ? `, ${group.moleculesWithoutDefs.length} sem .defs.ts` : '';
        lines.push(`  - ${group.canonical}: ${group.moleculeCount} molécula(s)${defsNote}, ${group.scenarioCount} cenário(s) (${group.scenariosSource}) — ${group.indexDefsFile}`);
    }
    if (report.ignored.length || report.requestedButIgnored.length) {
        lines.push('');
        lines.push('Grupos ignorados (não geraram nada, e por quê):');
        for (const group of [...report.requestedButIgnored, ...report.ignored])
            lines.push(`  - ${group.folder}: ${group.reason}`);
    }
    if (report.unknown.length) {
        lines.push('');
        lines.push(`Nomes não reconhecidos na menção: ${report.unknown.join(', ')}.`);
    }
    lines.push('');
    lines.push(report.indexTs.requested
        ? `index.ts: pedido na menção, mas esta versão do agente ainda não o gera (o passo s3 é trabalho futuro) — o catálogo acima foi gravado normalmente.`
        : `index.ts: não tocado nesta run. ${report.indexTs.howToRequest}.`);
    lines.push('');
    lines.push(`⚠️ Publicação: ${report.publish.warning}`);
    return lines.join('\n');
}
