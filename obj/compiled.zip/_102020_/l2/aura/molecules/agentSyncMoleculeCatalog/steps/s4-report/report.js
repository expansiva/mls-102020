/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s4-report/report.ts" enhancement="_blank"/>
export const SY_PUBLISH_WARNING = 'o catálogo foi gravado no stor (editor), mas NÃO foi publicado — não existe API de publicação nesta plataforma (D5). ' +
    'Um consumidor fora do editor (await import()) ainda lê o catálogo anterior, e um projeto publicado com esta edição não salva lê o conteúdo ANTIGO, sem erro nenhum. Publique o projeto manualmente para que o catálogo valha.';
export function buildSyRunReport(facts) {
    const migrationSet = new Set(facts.input.indexTsMigrationGroups);
    const creationSet = new Set(facts.input.indexTsCreationGroups);
    const indexTsArtifactByCanonical = new Map(facts.indexTsArtifacts.map(artifact => [artifact.canonical, artifact]));
    const indexTsGroups = facts.input.matchedGroups
        .map((canonical) => {
        const folder = canonical.trim().toLowerCase();
        if (creationSet.has(canonical)) {
            const artifact = indexTsArtifactByCanonical.get(canonical);
            if (artifact?.status === 'created')
                return { canonical, folder, status: 'created', scenarioCount: artifact.scenarioCount, droppedScenarioNames: artifact.droppedScenarioNames };
            // A group flagged for creation whose s3 step left no artifact (crashed) is reported the same as
            // one that reported failure — the run must never read as silently having skipped it.
            return { canonical, folder, status: 'creation-failed', reason: artifact?.reason || "o passo s3 não deixou artefato" };
        }
        if (migrationSet.has(canonical)) {
            const artifact = indexTsArtifactByCanonical.get(canonical);
            if (artifact?.status === 'migrated')
                return { canonical, folder, status: 'migrated' };
            // A group flagged for migration whose s3 step left no artifact (crashed) is reported the same
            // as one that reported failure — the run must never read as silently having skipped it.
            return { canonical, folder, status: 'migration-failed', reason: artifact?.reason || "o passo s3 não deixou artefato" };
        }
        return { canonical, folder, status: 'already-migrated' };
    })
        .sort((a, b) => a.folder.localeCompare(b.folder));
    return {
        schemaVersion: 1,
        savedAt: facts.savedAt,
        runKey: facts.runKey,
        project: facts.project,
        written: {
            skillFile: facts.projectArtifact?.skillFile || null,
            groupCount: facts.groupArtifacts.length,
            moleculeCount: facts.groupArtifacts.reduce((sum, g) => sum + g.moleculeShortTags.length, 0),
            groups: facts.groupArtifacts
                .map(g => ({
                canonical: g.canonical,
                folder: g.folder,
                indexDefsFile: g.indexDefsFile,
                indexHtmlFile: g.indexHtmlFile,
                moleculeCount: g.moleculeShortTags.length,
                moleculesWithoutDefs: g.moleculesWithoutDefs,
                scenarioCount: g.scenarioCount,
                scenariosSource: g.scenariosSource,
                cachedAs: g.cachedAs || '',
                cacheError: g.cacheError || '',
            }))
                .sort((a, b) => a.folder.localeCompare(b.folder)),
        },
        ignored: facts.input.ignoredGroups,
        requestedButIgnored: facts.input.requestedButIgnoredGroups,
        unknown: facts.input.unknownGroups,
        refusal: facts.input.refusal || null,
        // The names a mention MAY use. Without them an "I don't know that group" message is a dead end;
        // with them it is a correction the human can act on in one read.
        validGroups: (facts.input.catalogGroups || []).map(group => group.canonical || group.folder),
        indexTs: { requested: facts.input.includeIndexTsRequested, groups: indexTsGroups },
        publish: { published: false, warning: SY_PUBLISH_WARNING },
    };
}
const INDEX_TS_STATUS_LABEL = {
    migrated: 'index.ts migrado (tabela agora vem do index.defs)',
    'migration-failed': 'index.ts NÃO migrado',
    created: 'index.ts criado (E8b)',
    'creation-failed': 'index.ts NÃO criado',
    'already-migrated': 'index.ts já estava migrado, nada a fazer',
};
export function renderSyRunSummary(report) {
    const lines = [];
    lines.push(`agentSyncMoleculeCatalog — run ${report.runKey} (mls-${report.project})`);
    lines.push('');
    if (report.refusal) {
        lines.push(`⚠️ Nada foi gerado: ${report.refusal}`);
        if (report.validGroups.length) {
            lines.push('');
            lines.push(`Grupos que este projeto aceita: ${report.validGroups.join(', ')}.`);
        }
        lines.push('');
        lines.push('Nenhum arquivo foi escrito — corrija a menção e rode de novo.');
        return lines.join('\n');
    }
    lines.push(`Gravado: ${report.written.skillFile || 'l2/molecules/skill.ts'} + ${report.written.groupCount} grupo(s), ${report.written.moleculeCount} molécula(s) no total.`);
    for (const group of report.written.groups) {
        const defsNote = group.moleculesWithoutDefs.length ? `, ${group.moleculesWithoutDefs.length} sem .defs.ts` : '';
        lines.push(`  - ${group.canonical}: ${group.moleculeCount} molécula(s)${defsNote}, ${group.scenarioCount} cenário(s) (${group.scenariosSource}) — ${group.indexDefsFile}`);
        // A module that is written and compiled but not CACHED fails only later, in the page, with a fetch
        // error — while the run looks successful. Say it here, where someone will read it.
        if (group.cacheError)
            lines.push(`    ⚠️ fora do cache (${group.cacheError}) — a página do grupo não vai conseguir importar molecules/scenarios`);
    }
    if (report.ignored.length || report.requestedButIgnored.length) {
        lines.push('');
        lines.push('Grupos ignorados (não geraram nada, e por quê):');
        for (const group of [...report.requestedButIgnored, ...report.ignored])
            lines.push(`  - ${group.folder}: ${group.reason}`);
    }
    if (report.unknown.length) {
        lines.push('');
        lines.push(`Nomes não reconhecidos na menção: ${report.unknown.join(', ')}.`);
        if (report.validGroups.length)
            lines.push(`  Grupos que este projeto aceita: ${report.validGroups.join(', ')}.`);
    }
    lines.push('');
    lines.push('index.ts, por grupo:');
    for (const group of report.indexTs.groups) {
        const failureSuffix = (group.status === 'migration-failed' || group.status === 'creation-failed') && group.reason ? ` — ${group.reason}` : '';
        const createdSuffix = group.status === 'created' ? `, ${group.scenarioCount ?? 0} cenário(s)${group.droppedScenarioNames?.length ? `, ${group.droppedScenarioNames.length} nome(s) inventado(s) descartado(s)` : ''}` : '';
        lines.push(`  - ${group.canonical}: ${INDEX_TS_STATUS_LABEL[group.status]}${failureSuffix}${createdSuffix}`);
    }
    lines.push('');
    lines.push(`⚠️ Publicação: ${report.publish.warning}`);
    return lines.join('\n');
}
