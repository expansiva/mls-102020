/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s4-report/agentSyReport.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { nmDestProject, readJsonArtifact, writeJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { SY_AGENT_PROJECT, SY_PLAN_S4, syDoneAnchor, syGroupFolder } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syTypes.js';
import { buildSyRunReport, renderSyRunSummary } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/steps/s4-report/report.js';
import { syGroupArtifactFileInfo, syInputFileInfo, syProjectArtifactFileInfo, syReportFileInfo } from '/_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syFs.js';
const AGENT_NAME = 'agentSyReport';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: SY_AGENT_PROJECT,
        agentFolder: 'aura/molecules/agentSyncMoleculeCatalog/steps/s4-report',
        agentDescription: 's4-report — consolidates the run into report.json and renders the readable summary. No LLM.',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const args = nmParseStepArgs(step.prompt);
    if (!args.runKey) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] step args missing runKey`)];
    }
    const runKey = args.runKey;
    const input = await readJsonArtifact(syInputFileInfo(runKey), true);
    if (!input) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] run ${runKey} has no input.json to report on`)];
    }
    const projectArtifact = await readJsonArtifact(syProjectArtifactFileInfo(runKey), false);
    const groupArtifacts = [];
    for (const canonical of input.matchedGroups) {
        const artifact = await readJsonArtifact(syGroupArtifactFileInfo(runKey, syGroupFolder(canonical)), false);
        if (artifact)
            groupArtifacts.push(artifact);
    }
    const savedAt = new Date().toISOString();
    const report = buildSyRunReport({ savedAt, runKey, project: nmDestProject(), input, projectArtifact, groupArtifacts });
    await writeJsonArtifact(syReportFileInfo(runKey), report);
    const summary = renderSyRunSummary(report);
    return [
        nmResultStepIntent(context, parentStep, {
            planId: syDoneAnchor(SY_PLAN_S4),
            dependsOn: [],
            stepTitle: `run ${runKey}: ${report.written.groupCount} grupo(s), ${report.written.moleculeCount} molécula(s)`,
            // `runKey` is NOT repeated here: the report already carries it, and spreading it last silently
            // overwrote the explicit one (TS2783). Same value either way — the report is the payload, and
            // `reportFile` is the only thing this adds to it.
            result: { reportFile: `l4/agentSyncMoleculeCatalog/${runKey}/report.json`, ...report },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary, 'input_output'),
    ];
}
