/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syCreateIndexTs.ts" enhancement="_blank"/>
/**
 * `molecules` is the group's own list — `{ shortName, tag }` pairs, the same shape s1 derives before
 * rendering index.defs.ts. Blank scenario text is dropped (nothing readable to show); a scenario left
 * with zero resolved tags after dropping invented names is KEPT (not silently erased) — same as any
 * human-authored scenario with no recommendation — the empty state is legitimate, only the name was not.
 */
export function syResolveCreationScenarios(raw, molecules) {
    const byShortName = new Map(molecules.map(molecule => [molecule.shortName, molecule.tag]));
    const droppedNames = [];
    const scenarios = (Array.isArray(raw) ? raw : [])
        .map((entry) => {
        const scenario = typeof entry?.scenario === 'string' ? entry.scenario.trim() : '';
        if (!scenario)
            return null;
        const names = Array.isArray(entry?.recommended) ? entry.recommended : [];
        const recommended = [];
        for (const name of names) {
            if (typeof name !== 'string')
                continue;
            const tag = byShortName.get(name.trim());
            if (tag)
                recommended.push(tag);
            else
                droppedNames.push(name);
        }
        return { scenario, recommended };
    })
        .filter((entry) => entry !== null);
    return { scenarios, droppedNames };
}
