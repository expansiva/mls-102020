/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syEntry.ts" enhancement="_blank"/>
const ALL_WORDS = new Set(['all', 'todos', 'todas']);
const LEADING_WORDS = new Set(['atualizar', 'atualize', 'gerar', 'gere', 'sincronizar', 'sincronize', 'sync', 'update']);
const GROUP_WORDS = new Set(['grupo', 'grupos', 'group', 'groups']);
/** Recognized ways of asking for the index.ts (G2), matched as a whole phrase (accents/case folded). */
const INDEX_PHRASES = [
    'incluindo o arquivo index.ts',
    'incluindo o index.ts',
    'incluindo index.ts',
    'com o arquivo index.ts',
    'com index.ts',
    'com todos os arquivos',
    'including the index.ts file',
    'including index.ts',
    'with all files',
];
/** A mention that names the index page without a recognized phrase is ambiguity, refused by name. */
const INDEX_HINT = /\bindex(\.ts)?\b|p[áa]gina|showcase/i;
export function syParseEntry(raw) {
    const rawText = (raw || '').trim();
    let projectTarget = null;
    let text = rawText;
    if (rawText.startsWith('{')) {
        const close = matchingBrace(rawText);
        if (close < 0) {
            return {
                projectTarget: null,
                wantsAll: false,
                groupTokens: [],
                includeIndexTs: false,
                error: `o argumento abre com '{' e nunca fecha — escreva '{ projectTarget: 102040 }' seguido do pedido`,
            };
        }
        const argument = rawText.slice(0, close + 1);
        const found = new RegExp(`['"]?projectTarget['"]?\\s*:\\s*['"]?(\\d+)`).exec(argument);
        if (!found) {
            return {
                projectTarget: null,
                wantsAll: false,
                groupTokens: [],
                includeIndexTs: false,
                error: `o único argumento aceito é 'projectTarget' — escreva '{ projectTarget: 102040 }' seguido do pedido, ou nada e o projeto ativo é usado`,
            };
        }
        projectTarget = Number(found[1]);
        text = rawText.slice(close + 1).trim();
    }
    if (!text)
        return { projectTarget, wantsAll: true, groupTokens: [], includeIndexTs: false, error: '' };
    const normalized = foldAccents(text).toLowerCase();
    let includeIndexTs = false;
    let withoutIndexPhrase = text;
    for (const phrase of INDEX_PHRASES) {
        const at = normalized.indexOf(phrase);
        if (at < 0)
            continue;
        includeIndexTs = true;
        withoutIndexPhrase = `${text.slice(0, at)} ${text.slice(at + phrase.length)}`;
        break;
    }
    if (!includeIndexTs && INDEX_HINT.test(withoutIndexPhrase)) {
        return {
            projectTarget,
            wantsAll: false,
            groupTokens: [],
            includeIndexTs: false,
            error: `não entendi o pedido sobre o index.ts — para incluí-lo, escreva 'incluindo o arquivo index.ts' ou 'com todos os arquivos' depois dos grupos; sem isso, o index.ts não é tocado`,
        };
    }
    const tokens = withoutIndexPhrase.trim().split(/\s+/).filter(Boolean);
    while (tokens.length) {
        const head = foldAccents(tokens[0]).toLowerCase();
        if (!LEADING_WORDS.has(head) && !GROUP_WORDS.has(head))
            break;
        tokens.shift();
    }
    const rest = tokens.join(' ').trim();
    if (!rest || ALL_WORDS.has(foldAccents(rest).toLowerCase())) {
        return { projectTarget, wantsAll: true, groupTokens: [], includeIndexTs, error: '' };
    }
    const groupTokens = rest
        .split(/,| e /i)
        .map(item => item.trim())
        .filter(Boolean);
    return { projectTarget, wantsAll: false, groupTokens, includeIndexTs, error: '' };
}
function matchingBrace(text) {
    let depth = 0;
    for (let index = 0; index < text.length; index += 1) {
        if (text[index] === '{')
            depth += 1;
        else if (text[index] === '}') {
            depth -= 1;
            if (!depth)
                return index;
        }
    }
    return -1;
}
function foldAccents(text) {
    return text.normalize('NFD').replace(/[̀-ͯ]/g, '');
}
