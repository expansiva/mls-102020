/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syDifferentiators.ts" enhancement="_blank"/>
/** Attributes every molecule of the family reads; naming them as differentiators would be noise. */
const UNIVERSAL_SWITCHES = new Set(['is-editing', 'editing-rows', 'disabled', 'loading']);
/** Cap per molecule — the prompt must stay readable, and the rarest items carry the signal. */
const MAX_EXCLUSIVE = 8;
export function syExtractMoleculeFacts(source) {
    const ts = source.ts || '';
    const slotsMatch = ts.match(/slotTags\s*=\s*\[([\s\S]*?)\]/);
    const less = source.less || '';
    return {
        shortName: source.shortName,
        tag: (ts.match(/@customElement\(\s*'([^']+)'/) || [])[1] || '',
        slots: slotsMatch ? uniqueSorted(allMatches(slotsMatch[1], /'([^']+)'/g)) : [],
        props: uniqueSorted(allMatches(ts, /@propertyDataSource\([^)]*\)\s*(?:\r?\n\s*)?(?:declare\s+)?([A-Za-z_$][\w$]*)/g)),
        // Both spellings on purpose: a molecule may dispatch directly AND through a helper that takes the
        // event name as an argument — `ml-inline-edit-table` emits 5 of its 9 events only through the helper.
        events: uniqueSorted([
            ...allMatches(ts, /new CustomEvent\(\s*'([^']+)'/g),
            ...allMatches(ts, /\bemit[A-Za-z]*\(\s*'([^']+)'/g),
        ]),
        switches: uniqueSorted(allMatches(ts, /hasAttribute\(\s*'([^']+)'/g)).filter(name => !UNIVERSAL_SWITCHES.has(name)),
        actions: extractActionVocabulary(ts),
        liveSlots: /usesLiveSlots/.test(ts),
        reactsTo: /@container|container-type/.test(less) ? 'container' : /@media\s*\(/.test(less) ? 'window' : 'none',
        objective: firstSentence(source.defs || ''),
    };
}
export function syGroupDifferentiators(sources) {
    const facts = sources.map(syExtractMoleculeFacts);
    const total = facts.length;
    const rarity = new Map();
    const bump = (key) => rarity.set(key, (rarity.get(key) ?? 0) + 1);
    for (const f of facts) {
        for (const s of f.slots)
            bump(`slot:${s}`);
        for (const p of f.props)
            bump(`.${p}`);
        for (const e of f.events)
            bump(`@${e}`);
    }
    const molecules = facts.map(f => {
        const keys = [...f.slots.map(s => `slot:${s}`), ...f.props.map(p => `.${p}`), ...f.events.map(e => `@${e}`)];
        // NOT UNIVERSAL is the whole test: an item all N siblings carry cannot tell them apart. Rarest first,
        // so the model reads the sharpest difference at the top of each line.
        const exclusive = keys
            .filter(k => (rarity.get(k) ?? 0) < total)
            .sort((a, b) => (rarity.get(a) ?? 0) - (rarity.get(b) ?? 0) || a.localeCompare(b))
            .slice(0, MAX_EXCLUSIVE);
        const ownSwitches = f.switches.filter(sw => facts.filter(o => o.switches.includes(sw)).length === 1);
        return { ...f, exclusive, ownSwitches };
    });
    return {
        molecules,
        allEvents: uniqueSorted(facts.flatMap(f => f.events)),
        distinguishingSwitches: uniqueSorted(molecules.flatMap(m => m.ownSwitches)),
        distinguishingActions: uniqueSorted(uniqueSorted(facts.flatMap(f => f.actions)).filter(verb => facts.filter(f => f.actions.includes(verb)).length === 1)),
        withoutExclusiveApi: molecules.filter(m => m.exclusive.length === 0).map(m => m.shortName),
    };
}
/** The block injected into the creation prompt. Plain text on purpose — it sits inside a markdown section. */
export function syRenderDifferentiators(group) {
    if (!group.molecules.length)
        return '';
    const lines = group.molecules.map(m => {
        const parts = [];
        parts.push(m.liveSlots ? 'live slots (its slot content can BE a molecule)' : 'snapshot slots (slot content is read as text)');
        if (m.reactsTo !== 'none') {
            parts.push(m.reactsTo === 'container'
                ? 'changes shape by CONTAINER width (@container) — a narrow card demonstrates it'
                : 'has a WINDOW-width rule (@media) — a narrow CARD cannot trigger it; name the rule in the card instead of faking it');
        }
        parts.push(m.exclusive.length
            ? `only it (or few): ${m.exclusive.join(', ')}`
            : 'NO exclusive slot/property/event — it can only be told apart by interaction, by the space it sits in, or by the shape of its data');
        if (m.ownSwitches.length)
            parts.push(`turn it ON with: ${m.ownSwitches.map(s => `${s}="…"`).join(', ')}`);
        if (m.actions.length)
            parts.push(`answers to <RowAction action="…">: ${m.actions.join(', ')}`);
        return `- ${m.shortName} — ${parts.join(' · ')}\n    emits: ${m.events.join(', ') || '(none)'}\n    objective: ${m.objective || '(not declared)'}`;
    });
    const notes = [];
    if (group.withoutExclusiveApi.length) {
        notes.push(`${group.withoutExclusiveApi.length} of ${group.molecules.length} have NO exclusive API (${group.withoutExclusiveApi.join(', ')}). That is not a defect — it is the signal that a static card will never tell them apart from their siblings.`);
    }
    if (group.distinguishingActions.length) {
        notes.push(`\`action\` verbs exactly ONE molecule answers to — the feature they unlock has no other way in: ${group.distinguishingActions.join(', ')}.`);
    }
    if (group.distinguishingSwitches.length) {
        notes.push(`Attributes read by exactly ONE molecule of the group — the feature stays invisible until the showcase sets them: ${group.distinguishingSwitches.join(', ')}.`);
    }
    return [lines.join('\n'), notes.length ? `\n${notes.map(n => `⚠️ ${n}`).join('\n')}` : ''].filter(Boolean).join('\n');
}
/**
 * The `action="…"` verbs a molecule answers to. Read from the COMPARISONS, not from a declaration:
 * there is no list to read — the vocabulary only exists as `name === 'open'`, `action === 'save'` and
 * `case 'cancel'` inside the handler. Spacing varies between files (`action ==='cancel'` occurs), so
 * the pattern tolerates it.
 */
function extractActionVocabulary(ts) {
    if (!/getAttribute\(\s*'action'\s*\)/.test(ts))
        return [];
    return uniqueSorted([
        ...allMatches(ts, /(?:name|action)\s*===\s*'([a-z][\w-]*)'/g),
        ...allMatches(ts, /case\s*'([a-z][\w-]*)'/g),
    ]);
}
function allMatches(text, re) {
    return [...text.matchAll(re)].map(m => m[1]);
}
function uniqueSorted(values) {
    return [...new Set(values.filter(Boolean))].sort();
}
/** The `# Objective` paragraph's first sentence — enough to place the molecule, short enough for a list. */
function firstSentence(defs) {
    const body = (defs.match(/# Objective\s*\n([\s\S]*?)(?:\n#|$)/) || [])[1] || '';
    const flat = body.replace(/\s+/g, ' ').trim();
    const stop = flat.indexOf('. ');
    return (stop > 0 ? flat.slice(0, stop + 1) : flat).slice(0, 300);
}
