/// <mls fileReference="_102020_/l2/aura/molecules/agentSyncMoleculeCatalog/helpers/syTypes.ts" enhancement="_blank"/>
// Types, constants and small pure helpers of agentSyncMoleculeCatalog. No I/O, no mls.* access — see
// flow.json and spec.md for the design record (analysis: the molecule-catalog analysis for this
// agent, on the author's machine — never cited by path here, per the invariant this project ships to
// other developers through the Studio).
//
// Plumbing that already exists is imported, not restated: intents and l4 mechanics come from
// agentNewMolecule2/helpers (nmSteps, nmFs), the same way agentChooseMolecules reuses them.
export const SY_AGENT_NAME = 'agentSyncMoleculeCatalog';
export const SY_AGENT_FOLDER = 'aura/molecules/agentSyncMoleculeCatalog';
export const SY_AGENT_PROJECT = 102020;
/** Fixed planIds. The s1 steps are one per group — see syGroupPlanId. */
export const SY_PLAN_S2 = 's2-project';
export const SY_PLAN_S4 = 's4-report';
/** The folder spelling of a group: the catalog publishes 'groupSelectOne', the folder is lowercase. */
export function syGroupFolder(groupName) {
    return (groupName || '').trim().toLowerCase();
}
export function syGroupPlanId(groupName) {
    return `s1-${syGroupFolder(groupName)}`;
}
/**
 * 's2-project' -> 's2-done'. Same convention as the rest of the family (nmDoneAnchor / chDoneAnchor).
 *
 * ⚠️ NOT USABLE FOR THE s1 GROUP STEPS — splitting on '-' would give every group's step the same
 * 's1-done' anchor, so s2 (which dependsOn every s1) would unlock as soon as the FIRST group finished.
 * Use syGroupDoneAnchor for those (same reasoning as chGroupDoneAnchor).
 */
export function syDoneAnchor(planId) {
    return `${planId.split('-')[0]}-done`;
}
export function syGroupDoneAnchor(groupName) {
    return `${syGroupPlanId(groupName)}-done`;
}
