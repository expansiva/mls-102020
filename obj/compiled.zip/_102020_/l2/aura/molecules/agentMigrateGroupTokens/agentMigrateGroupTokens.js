/// <mls fileReference="_102020_/l2/aura/molecules/agentMigrateGroupTokens/agentMigrateGroupTokens.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { isBareMention, stripAgentMention } from '/_102020_/l2/aura/molecules/shared/mentionEntry.js';
import { readJsonArtifact, writeJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmParseStepArgs, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { skills as skillList } from '/_102020_/l2/aura/molecules/skills/index';
import { IM_AGENT_NAME, imDoneAnchor } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
import { mgtParseEntry } from '/_102020_/l2/aura/molecules/agentMigrateGroupTokens/helpers/mgtEntry.js';
import { mgtDefsMissingReason, mgtListMolecules, mgtProgressFileInfo } from '/_102020_/l2/aura/molecules/agentMigrateGroupTokens/helpers/mgtFs.js';
import { ADVANCE_PLAN_ID, MGT_AGENT_NAME, } from '/_102020_/l2/aura/molecules/agentMigrateGroupTokens/helpers/mgtTypes.js';
const AGENT_NAME = MGT_AGENT_NAME;
// The prompt every molecule's i2-triage/i3-edit sees, verbatim, in every branch. FIXED and never
// molecule-specific: it travels through `context.task.iaCompressed.longMemory.prompt`
// (`getImInput`), shared by the WHOLE task — naming one molecule here would hand every OTHER
// molecule the wrong name.
const MIGRATION_PROMPT = "the appearance of this molecule must move to the design-system tokens approved by the team, in place of the old `--ml-*` vocabulary. Swap each token's NAME for the right design-system role, choosing the role by the PLACE it is used (background, text, border). Keep the fallback value the sheet already uses — the migration must not change anything visually. Tokens the design system does not cover (border width and style, focus ring thickness, disabled opacity, status borders) stay `--ml-*`.";
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: 'aura/molecules/agentMigrateGroupTokens',
        agentDescription: "Migrates every molecule of one group from --ml-* to design-system tokens, one @@agentImproveMolecule2 pass per molecule, chained in series. '@@agentMigrateGroupTokens <group> [a partir de <shortName>]'.",
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const text = stripAgentMention(userPrompt, agent.agentName);
    const raw = isBareMention(text) ? '' : text;
    const entry = mgtParseEntry(raw);
    const runKey = mgtRunKeyFromNow();
    // ⚠️ NOTHING HERE THROWS — same reason as agentSyncMoleculeCatalog's own bootstrap: the platform's
    // executeBeforePromptStream has no try/catch around beforePromptImplicit, so a throw becomes an
    // uncaught promise rejection and the user sees an empty screen. Every problem becomes `refusal`,
    // the task is created anyway, and the advance step alone reports it.
    const resolved = entry.error ? null : await resolveGroupAndQueue(entry);
    const refusal = entry.error || resolved?.refusal || '';
    const groupFolder = resolved?.groupFolder || '';
    const groupCanonical = resolved?.groupCanonical || '';
    const queue = resolved?.queue || [];
    const skipped = resolved?.skipped || [];
    const progress = {
        schemaVersion: 1,
        savedAt: new Date().toISOString(),
        runKey,
        groupFolder,
        groupCanonical,
        refusal,
        queue,
        current: 0,
        skipped,
        done: [],
    };
    await writeJsonArtifact(mgtProgressFileInfo(runKey), progress);
    const addMessageAI = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: AGENT_NAME,
            inputAI: [
                {
                    type: 'system',
                    content: `${AGENT_NAME} deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM — scope was decided by helpers/mgtEntry.ts (mention parsing) and helpers/mgtFs.ts (a stor scan), both pure/deterministic.`,
                },
                { type: 'human', content: raw || AGENT_NAME },
            ],
            taskTitle: refusal ? 'Migrate group tokens: nada a fazer' : `Migrate group tokens: ${groupCanonical} (${queue.length} molécula(s))`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { flowName: AGENT_NAME, runKey, prompt: MIGRATION_PROMPT },
        },
    };
    const intents = [addMessageAI];
    if (refusal || !queue.length) {
        // Nothing to plant: the advance step alone, immediately runnable, reports the refusal.
        intents.push(bootstrapAddStep(context, { planId: ADVANCE_PLAN_ID, agentName: AGENT_NAME, title: 'mgt-advance · relatório', dependsOn: [], runKey }));
        return intents;
    }
    intents.push(...plantMoleculeBootstrap(context, groupFolder, queue[0], moleculeRunKey(queue[0])), bootstrapAddStep(context, {
        planId: ADVANCE_PLAN_ID,
        agentName: AGENT_NAME,
        title: `mgt-advance (1/${queue.length})`,
        dependsOn: [imDoneAnchor('i7-summary')],
        runKey,
    }));
    return intents;
}
/**
 * PHASE 2 — the reentrant advance step. Deterministic, no LLM: it reads progress.json, records the
 * molecule that just finished, and either plants the next one (+ another instance of itself) or,
 * when the queue is exhausted, reports and stops.
 */
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    if (parsedArgs.planId !== ADVANCE_PLAN_ID) {
        throw new Error(`[${AGENT_NAME}] unexpected step '${parsedArgs.planId || '(none)'}' — the root only handles ${ADVANCE_PLAN_ID}`);
    }
    const runKey = parsedArgs.runKey || '';
    if (!runKey)
        throw new Error(`[${AGENT_NAME}] runKey missing on the advance step`);
    const progress = await readJsonArtifact(mgtProgressFileInfo(runKey), true);
    if (!progress)
        throw new Error(`[${AGENT_NAME}] progress.json missing for ${runKey}`);
    // Refusal, or every molecule failed pre-validation: nothing was ever planted, report as-is.
    if (progress.refusal || !progress.queue.length) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', mgtReportSummary(progress), 'input_output')];
    }
    const justFinished = progress.queue[progress.current];
    const done = [...progress.done, justFinished];
    const nextIndex = progress.current + 1;
    if (nextIndex >= progress.queue.length) {
        const finished = { ...progress, done, current: nextIndex };
        await writeJsonArtifact(mgtProgressFileInfo(runKey), finished);
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', mgtReportSummary(finished), 'input_output')];
    }
    const nextShortName = progress.queue[nextIndex];
    const updated = { ...progress, done, current: nextIndex };
    await writeJsonArtifact(mgtProgressFileInfo(runKey), updated);
    return [
        ...plantMolecule(context, step, progress.groupFolder, nextShortName, moleculeRunKey(nextShortName)),
        addStep(context, step, {
            planId: ADVANCE_PLAN_ID,
            agentName: AGENT_NAME,
            title: `mgt-advance (${nextIndex + 1}/${progress.queue.length})`,
            dependsOn: [imDoneAnchor('i7-summary')],
            runKey,
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `${justFinished} done — starting ${nextShortName} (${nextIndex + 1}/${progress.queue.length})`, 'input_output'),
    ];
}
// ---- resolution (group -> canonical + queue), impure but deterministic ----
async function resolveGroupAndQueue(entry) {
    const matched = skillList.find(item => item.name.toLowerCase() === entry.group.trim().toLowerCase());
    if (!matched) {
        return { refusal: `'${entry.group}' is not a group in skills/index.ts`, groupFolder: '', groupCanonical: '', queue: [], skipped: [] };
    }
    const groupFolder = matched.name.toLowerCase();
    const groupCanonical = matched.name;
    const all = mgtListMolecules(groupFolder);
    if (!all.length) {
        return { refusal: `group '${groupCanonical}' has no molecules on disk`, groupFolder, groupCanonical, queue: [], skipped: [] };
    }
    let candidates = all;
    if (entry.startFrom) {
        const at = all.indexOf(entry.startFrom);
        if (at === -1) {
            return {
                refusal: `'${entry.startFrom}' is not a molecule of '${groupCanonical}' — known: ${all.join(', ')}`,
                groupFolder,
                groupCanonical,
                queue: [],
                skipped: [],
            };
        }
        candidates = all.slice(at);
    }
    const queue = [];
    const skipped = [];
    for (const shortName of candidates) {
        const reason = await mgtDefsMissingReason(groupFolder, shortName);
        if (reason)
            skipped.push({ shortName, reason });
        else
            queue.push(shortName);
    }
    const refusal = queue.length ? '' : `every molecule of '${groupCanonical}' failed pre-validation — nothing to migrate (${skipped.map(s => s.shortName).join(', ')})`;
    return { refusal, groupFolder, groupCanonical, queue, skipped };
}
// ---- planting the three steps IM2's own root plants, per molecule ----
function plantMoleculeBootstrap(context, groupFolder, shortName, runKey) {
    return [
        bootstrapAddStep(context, { planId: 'i1-locate', agentName: 'agentIm2Locate', title: `i1-locate · ${shortName}`, dependsOn: [], runKey, target: `${groupFolder}/${shortName}` }),
        bootstrapAddStep(context, { planId: 'i2-triage', agentName: 'agentIm2Triage', title: `i2-triage · ${shortName}`, dependsOn: [imDoneAnchor('i1-locate')], runKey }),
        bootstrapAddStep(context, { planId: 'i2r-route', agentName: IM_AGENT_NAME, title: `i2r-route · ${shortName}`, dependsOn: [imDoneAnchor('i2-triage')], runKey }),
    ];
}
function plantMolecule(context, parent, groupFolder, shortName, runKey) {
    return [
        addStep(context, parent, { planId: 'i1-locate', agentName: 'agentIm2Locate', title: `i1-locate · ${shortName}`, dependsOn: [], runKey, target: `${groupFolder}/${shortName}` }),
        addStep(context, parent, { planId: 'i2-triage', agentName: 'agentIm2Triage', title: `i2-triage · ${shortName}`, dependsOn: [imDoneAnchor('i1-locate')], runKey }),
        addStep(context, parent, { planId: 'i2r-route', agentName: IM_AGENT_NAME, title: `i2r-route · ${shortName}`, dependsOn: [imDoneAnchor('i2-triage')], runKey }),
    ];
}
function moleculeRunKey(shortName) {
    return `tokens-${shortName}`;
}
function stepPayload(args) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: args.title,
        // 'waiting_human_input' runs immediately (empty dependsOn); 'waiting_dependency' waits on the anchors.
        status: args.dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: args.agentName,
        prompt: JSON.stringify({ planId: args.planId, runKey: args.runKey, ...(args.target ? { target: args.target } : {}) }),
        rags: [],
        planning: { planId: args.planId, dependsOn: args.dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
/**
 * Planted with `parentStepId: 1`, same as agentSyncMoleculeCatalog's own bootstrap: there is no
 * real parent step object yet inside `beforePromptImplicit` — the `add-message-ai` intent in the
 * same batch is what creates it, and the platform's convention for "the step this message became"
 * is id 1.
 */
function bootstrapAddStep(context, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step: stepPayload(args),
    };
}
/**
 * The reentrant form, used from `beforePromptStep` where a real parent step exists.
 *
 * ⚠️ Copied from `agentImproveMolecule2.ts`'s own `addStep`, with `target` added to the prompt —
 * the ONE thing Tarefa 1 made `i1-locate` accept. The original is not touched (Armadilha #4).
 */
function addStep(context, parent, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parent.stepId,
        step: stepPayload(args),
    };
}
function mgtRunKeyFromNow() {
    const iso = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, '');
    return `migrate-${iso.toLowerCase()}`;
}
function mgtReportSummary(progress) {
    if (progress.refusal)
        return progress.refusal;
    const lines = [
        `${progress.groupCanonical}: ${progress.done.length}/${progress.queue.length} molécula(s) migrada(s)`,
        progress.done.length ? `rodaram: ${progress.done.join(', ')}` : '',
        progress.skipped.length ? `não migráveis (pré-validação): ${progress.skipped.map(s => `${s.shortName} (${s.reason})`).join('; ')}` : '',
    ];
    return lines.filter(Boolean).join('\n');
}
