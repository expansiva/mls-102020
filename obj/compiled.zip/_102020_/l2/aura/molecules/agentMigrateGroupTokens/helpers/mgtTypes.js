/// <mls fileReference="_102020_/l2/aura/molecules/agentMigrateGroupTokens/helpers/mgtTypes.ts" enhancement="_blank"/>
// Types and constants for agentMigrateGroupTokens (spec: todo/moleculetokens/todo-casca-migracao-por-grupo.md).
// Pure — no I/O, no mls.* access.
export const MGT_AGENT_NAME = 'agentMigrateGroupTokens';
export const MGT_AGENT_FOLDER = 'aura/molecules/agentMigrateGroupTokens';
export const MGT_AGENT_PROJECT = 102020;
/**
 * The one step this agent plants and handles itself, reentrantly — same shape as IM2's own
 * `i2r-route` (agentImproveMolecule2.ts), which is the router planted once and handled by the
 * root's own `beforePromptStep` when it becomes runnable.
 *
 * ⚠️ REUSED VERBATIM ACROSS EVERY ITERATION, on purpose: only ONE instance of this planId is ever
 * `waiting_dependency` at a time (the previous one already completed before the next is planted),
 * which is the whole point of the reentrant design — see the control's "O plantio em lote NÃO
 * funciona" section for why N simultaneous branches cannot share `i1-done`/`i2-done` anchors.
 */
export const ADVANCE_PLAN_ID = 'mgt-advance';
