/// <mls fileReference="_102020_/l2/aura/molecules/agentMigrateGroupTokens/helpers/mgtEntry.ts" enhancement="_blank"/>
const START_FROM_RE = /\s+a partir de\s+(ml-[a-z0-9-]+)\s*$/i;
export function mgtParseEntry(raw) {
    const text = (raw || '').trim();
    if (!text) {
        return { group: '', startFrom: null, error: "say which group to migrate, e.g. '@@agentMigrateGroupTokens groupEnterDateTime'" };
    }
    const match = text.match(START_FROM_RE);
    const startFrom = match ? match[1].toLowerCase() : null;
    const group = (match ? text.slice(0, match.index) : text).trim();
    if (!group) {
        return { group: '', startFrom, error: 'say which group to migrate' };
    }
    return { group, startFrom, error: '' };
}
