/// <mls fileReference="_102020_/l2/aura/molecules/agentNewTheme/steps/t2-clarify/agentNtClarify.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { NT_AGENT_FOLDER, ntAnswersFile, ntPlanFile, readJsonArtifact, writeJsonArtifact, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntFs.js';
import { NT_EXTRA_FIELD } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntTypes.js';
import { ntAnswerResultIntent, ntApplyIntentsAndRefresh, ntCheckClarificationPayload, ntClarificationPromptReady, ntDoneAnchor, ntFindMutableParent, ntUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntSteps.js';
const AGENT_NAME = 'agentNtClarify';
const PLAN_ID = 't2-clarify';
const LABELS = {
    pt: {
        intro: 'Responda para completar o estilo do tema. As opções recomendadas já vêm marcadas.',
        answered: 'Estilo completado',
        cancelled: 'Cancelado pelo usuário',
        notes: 'Outro valor / observações',
        openValue: 'Digite o valor',
        extraNotes: 'Ex.: borda 3px, sombra 4px 4px 0 #000000, no hover o elemento translada 2px para dentro da sombra, sem blur',
    },
    en: {
        intro: 'Answer to complete the theme style. The recommended options come pre-selected.',
        answered: 'Style completed',
        cancelled: 'Cancelled by the user',
        notes: 'Another value / notes',
        openValue: 'Type the value',
        extraNotes: 'e.g. border 3px, shadow 4px 4px 0 #000000, on hover the element slides 2px into its shadow, no blur',
    },
};
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NT_AGENT_FOLDER}/steps/t2-clarify`,
        agentDescription: 't2-clarify — the checkpoint: collects the missing theme fields',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const plan = await readPlan();
    return [ntClarificationPromptReady(context, parentStep, hookSequential, {
            planId: PLAN_ID,
            stepArgs: args || step.prompt || JSON.stringify({ planId: PLAN_ID }),
            systemPrompt: buildEnvelopePrompt(plan.title),
            humanPrompt: `Render the checkpoint with ${plan.questions.length} question(s). Return only the clarification payload requested in the system prompt.`,
        })];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    const error = ntCheckClarificationPayload(step.interaction?.payload?.[0], PLAN_ID);
    if (error)
        return [ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error)];
    // Keep the payload: it is what the framework renders the checkpoint from.
    return [];
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const planId = readPlanId(json);
    if (planId !== PLAN_ID)
        throw new Error(`[${AGENT_NAME}] unsupported clarification ${planId || '(missing)'}`);
    const plan = await readPlan();
    await import('/_102020_/l2/aura/molecules/shared/widgetDecisionClarification.js');
    const el = document.createElement('widget-decision-clarification-102020');
    const labels = labelsFor(plan.userLanguage);
    const value = {
        title: plan.title,
        intro: labels.intro,
        userLanguage: plan.userLanguage,
        questions: plan.questions.map(question => toDecisionQuestion(question, labels)),
    };
    el.value = value;
    el.addEventListener('clarification-finish', (event) => {
        const detail = event.detail;
        void applyAnswers(context, parentStep, step, hookSequential, plan, detail.value?.answers || [], detail.action)
            .catch(error => console.error(`[${AGENT_NAME}] ${error instanceof Error ? error.message : String(error)}`));
    });
    return el;
}
async function applyAnswers(context, parentStep, step, hookSequential, plan, widgetAnswers, action) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const labels = labelsFor(plan.userLanguage);
    const mutationParent = ntFindMutableParent(context, parentStep);
    if (action !== 'continue') {
        await ntApplyIntentsAndRefresh(context, [
            ntUpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', labels.cancelled),
        ], false);
        return;
    }
    const answers = widgetAnswers.map(answer => ({
        field: answer.id,
        ...(answer.optionId ? { value: answer.optionId } : {}),
        ...(answer.notes ? { notes: answer.notes } : {}),
    }));
    await writeJsonArtifact(ntAnswersFile(), { savedAt: new Date().toISOString(), answers });
    // Intent order matters: the completed answer result (the 't2-done' anchor t3 depends
    // on) lands BEFORE the update-status that closes this step.
    await ntApplyIntentsAndRefresh(context, [
        ntAnswerResultIntent(context, mutationParent, {
            planId: ntDoneAnchor(PLAN_ID),
            stepTitle: labels.answered,
            result: { answers },
        }),
        // 'input_output' drops the widget interaction once the answers are on disk
        // (the task record has a 400KB limit).
        ntUpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
    ], true);
}
function toDecisionQuestion(question, labels) {
    return {
        id: question.field,
        question: question.question,
        options: question.options,
        allowNotes: question.allowNotes,
        notesPlaceholder: placeholderFor(question, labels),
    };
}
// Three different textareas wear three different hints. Keying this off "has options?" put
// the slot's example ("border 3px, shadow 4px 4px 0 ...") under the brand-color question,
// which made no sense — the slot is identified by its FIELD, not by its option count.
function placeholderFor(question, labels) {
    if (question.field === NT_EXTRA_FIELD)
        return labels.extraNotes;
    return question.options.length ? labels.notes : labels.openValue;
}
async function readPlan() {
    const plan = await readJsonArtifact(ntPlanFile(), true);
    if (!plan || !Array.isArray(plan.questions))
        throw new Error(`[${AGENT_NAME}] plan.json missing or invalid`);
    return plan;
}
function labelsFor(userLanguage) {
    return LABELS[(userLanguage || '').slice(0, 2).toLowerCase()] || LABELS.en;
}
function readPlanId(value) {
    const parsed = typeof value === 'string' ? safeParse(value) : value;
    if (typeof parsed !== 'object' || parsed === null)
        return '';
    const planId = parsed.planId;
    return typeof planId === 'string' ? planId : '';
}
function safeParse(value) {
    try {
        return JSON.parse(value);
    }
    catch {
        return null;
    }
}
// The cheap call only produces the envelope the framework needs to render a checkpoint;
// the questions themselves come from plan.json (deterministic, already gated).
function buildEnvelopePrompt(title) {
    return `<!-- modelType: general -->

Return JSON only. Do not call tools. Do not explain.

Required payload:
{
  "type": "clarification",
  "json": {
    "planId": "${PLAN_ID}",
    "title": ${JSON.stringify(title)}
  }
}`;
}
