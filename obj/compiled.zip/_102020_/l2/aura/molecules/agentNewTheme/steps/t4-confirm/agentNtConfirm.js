/// <mls fileReference="_102020_/l2/aura/molecules/agentNewTheme/steps/t4-confirm/agentNtConfirm.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { NT_AGENT_FOLDER, ntDraftFile, ntPlanFile, readJsonArtifact, themeFile, toDisplayPath, writeStorTextAtomic, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntFs.js';
import { renderThemeHtml } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntThemeHtml.js';
import { ntApplyIntentsAndRefresh, ntCheckClarificationPayload, ntClarificationPromptReady, ntDoneAnchor, ntFindMutableParent, ntResultStepIntent, ntUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntSteps.js';
import { parseThemeSource } from '/_102020_/l2/aura/molecules/agentNewTheme/steps/t3-generate/gate.js';
const AGENT_NAME = 'agentNtConfirm';
const PLAN_ID = 't4-confirm';
const LABELS = {
    pt: { title: 'Confirmar o tema', created: 'Tema criado', discarded: 'Tema descartado pelo usuário' },
    en: { title: 'Confirm the theme', created: 'Theme created', discarded: 'Theme discarded by the user' },
};
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NT_AGENT_FOLDER}/steps/t4-confirm`,
        agentDescription: 't4-confirm — Checkpoint 2: confirms and writes theme.ts + theme.html',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const draft = await readDraft();
    return [ntClarificationPromptReady(context, parentStep, hookSequential, {
            planId: PLAN_ID,
            stepArgs: args || step.prompt || JSON.stringify({ planId: PLAN_ID }),
            systemPrompt: buildEnvelopePrompt(draft.summary.displayName),
            humanPrompt: `Render Checkpoint 2 for the theme "${draft.summary.displayName}". Return only the clarification payload requested in the system prompt.`,
        })];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    const error = ntCheckClarificationPayload(step.interaction?.payload?.[0], PLAN_ID);
    if (error)
        return [ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error)];
    return [];
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const planId = readPlanId(json);
    if (planId !== PLAN_ID)
        throw new Error(`[${AGENT_NAME}] unsupported clarification ${planId || '(missing)'}`);
    const draft = await readDraft();
    const labels = labelsFor((await readPlanLanguage()));
    await import('/_102020_/l2/aura/molecules/shared/widgetThemeConfirmation.js');
    const el = document.createElement('widget-theme-confirmation-102020');
    const value = { title: labels.title, summary: draft.summary };
    el.value = value;
    el.addEventListener('clarification-finish', (event) => {
        const detail = event.detail;
        void applyConfirmation(context, parentStep, step, hookSequential, draft, labels, detail.action === 'continue' && detail.value?.confirmed !== false)
            .catch(error => console.error(`[${AGENT_NAME}] ${error instanceof Error ? error.message : String(error)}`));
    });
    return el;
}
async function applyConfirmation(context, parentStep, step, hookSequential, draft, labels, confirmed) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const mutationParent = ntFindMutableParent(context, parentStep);
    if (!confirmed) {
        // Exit: the draft stays in l4 as a record, nothing lands in l2/skills.
        await ntApplyIntentsAndRefresh(context, [
            ntUpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', labels.discarded, 'input_output'),
        ], false);
        return;
    }
    const tsInfo = themeFile('.ts');
    const htmlInfo = themeFile('.html');
    const parsed = parseThemeSource(draft.themeTs);
    const info = (parsed.module?.themeInfo || {});
    await writeStorTextAtomic(tsInfo, draft.themeTs, true);
    await writeStorTextAtomic(htmlInfo, renderThemeHtml({
        summary: draft.summary,
        description: typeof info.description === 'string' ? info.description : '',
        suffix: typeof info.suffix === 'string' ? info.suffix : '',
    }), true);
    // The molecule agents import('/_<dest>_/l2/skills/theme.js'), so the .ts must be
    // compiled. Best-effort (same stance as the Variant's group index): a failure is
    // reported in the result, the file stays for the user to fix.
    const compiled = await compileTheme(tsInfo);
    await ntApplyIntentsAndRefresh(context, [
        ntResultStepIntent(context, mutationParent, {
            planId: ntDoneAnchor(PLAN_ID),
            dependsOn: [],
            stepTitle: labels.created,
            result: {
                theme: draft.summary.name,
                files: [toDisplayPath(tsInfo), toDisplayPath(htmlInfo)],
                compiled,
            },
        }),
        ntUpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
    ], true);
}
async function compileTheme(fileInfo) {
    try {
        const storFile = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        if (!storFile)
            return false;
        const model = await storFile.getOrCreateModel();
        if (!model?.model)
            return false;
        return await mls.l2.typescript.compileAndPostProcess(model, true, false);
    }
    catch {
        return false;
    }
}
async function readDraft() {
    const draft = await readJsonArtifact(ntDraftFile(), true);
    if (!draft?.themeTs || !draft.summary)
        throw new Error(`[${AGENT_NAME}] draft.json missing or invalid`);
    return draft;
}
async function readPlanLanguage() {
    const plan = await readJsonArtifact(ntPlanFile(), false);
    return plan?.userLanguage || 'pt';
}
function labelsFor(userLanguage) {
    return LABELS[(userLanguage || '').slice(0, 2).toLowerCase()] || LABELS.en;
}
function readPlanId(value) {
    const parsed = typeof value === 'string' ? safeParse(value) : value;
    if (typeof parsed !== 'object' || parsed === null)
        return '';
    const planId = parsed.planId;
    return typeof planId === 'string' ? planId : '';
}
function safeParse(value) {
    try {
        return JSON.parse(value);
    }
    catch {
        return null;
    }
}
function buildEnvelopePrompt(displayName) {
    return `<!-- modelType: general -->

Return JSON only. Do not call tools. Do not explain.

Required payload:
{
  "type": "clarification",
  "json": {
    "planId": "${PLAN_ID}",
    "title": ${JSON.stringify(displayName)}
  }
}`;
}
