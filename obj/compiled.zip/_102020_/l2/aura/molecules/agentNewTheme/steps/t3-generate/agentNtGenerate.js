/// <mls fileReference="_102020_/l2/aura/molecules/agentNewTheme/steps/t3-generate/agentNtGenerate.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { NT_AGENT_FOLDER, isRecord, ntAnswersFile, ntDestProject, ntDraftFile, ntPlanFile, ntTraceFile, parseMaybeJson, readJsonArtifact, readNtAgentText, toDisplayPath, toMlsFileReference, themeFile, writeJsonArtifact, writeStorTextAtomic, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntFs.js';
import { renderThemeHtml } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntThemeHtml.js';
import { buildVToolInstruction, createVToolSchema, extractVToolOutput, ntAgentStepIntent, ntDoneAnchor, ntParseStepArgs, ntResultStepIntent, ntUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntSteps.js';
import { parseThemeSource, runThemeGate } from '/_102020_/l2/aura/molecules/agentNewTheme/steps/t3-generate/gate.js';
import { getNtInput } from '/_102020_/l2/aura/molecules/agentNewTheme/agentNewTheme.js';
const AGENT_NAME = 'agentNtGenerate';
const TOOL_NAME = 'submitTheme';
const PLAN_ID = 't3-generate';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NT_AGENT_FOLDER}/steps/t3-generate`,
        agentDescription: 't3-generate — generates and creates the project theme (theme.ts + theme.html)',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
        openStepView,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = ntParseStepArgs(args ?? step.prompt);
    const plan = await readJsonArtifact(ntPlanFile(), true);
    if (!plan)
        throw new Error(`[${AGENT_NAME}] plan.json missing`);
    const answers = await readAnswers();
    const authoring = await loadAuthoringSkill();
    const promptMd = await readNtAgentText('steps/t3-generate', 'prompt', '.md', true);
    const schemaRaw = await readNtAgentText('schemas', 't3-generate.schema', '.json', true);
    const schema = parseMaybeJson(schemaRaw);
    if (!isRecord(schema))
        throw new Error(`[${AGENT_NAME}] invalid t3-generate schema`);
    const systemPrompt = promptMd
        .split('{{themeAuthoringSkill}}').join(authoring)
        .split('{{headerRef}}').join(toMlsFileReference(themeFile('.ts')))
        + `\n\n${buildVToolInstruction(TOOL_NAME, 'the description and answers are contradictory or impossible to turn into a theme')}`;
    const { prompt } = getNtInput(context);
    const humanPrompt = [
        `## User description\n${prompt || '(empty — everything was decided at the checkpoint)'}`,
        `## Fields already decided (known)\n${JSON.stringify(plan.known, null, 2)}`,
        answers.length ? `## Checkpoint answers\n${JSON.stringify(answers, null, 2)}` : '',
        parsedArgs.retryContext ? `## Previous attempt failed the deterministic gate — fix ALL of these\n${parsedArgs.retryContext}` : '',
    ].filter(Boolean).join('\n\n');
    return [{
            type: 'prompt_ready',
            args: args || JSON.stringify({ planId: PLAN_ID }),
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt,
            humanPrompt,
            tools: [createVToolSchema(TOOL_NAME, 'Submit the complete theme.ts and its structured summary', schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = ntParseStepArgs(step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    let themeTs = '';
    let summary = null;
    let extractError = '';
    try {
        const output = extractVToolOutput(step.interaction?.payload?.[0], TOOL_NAME, ['themeTs', 'summary']);
        if (output.status === 'failed')
            extractError = `model reported failure: ${output.trace.join('; ') || 'no reason'}`;
        else {
            themeTs = String(output.result.themeTs || '');
            const raw = parseMaybeJson(output.result.summary);
            summary = isRecord(raw) ? raw : null;
        }
    }
    catch (error) {
        extractError = error instanceof Error ? error.message : String(error);
    }
    const issues = extractError
        ? [{ code: 'extract', message: extractError }]
        : runThemeGate({ themeTs, summary, destProject: ntDestProject() });
    const errorText = issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
    await writeJsonArtifact(ntTraceFile(PLAN_ID, attempt), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        attempt,
        ok: issues.length === 0,
        themeChars: themeTs.length,
        ...(issues.length ? { error: errorText } : {}),
    });
    if (issues.length === 0 && summary) {
        // The draft outlives the write: the structured summary is not deterministically
        // recoverable from theme.ts, and it feeds theme.html, the read-only step view and a
        // future Improve Theme.
        const draft = { themeTs, summary };
        await writeJsonArtifact(ntDraftFile(), draft);
        const files = await writeTheme(draft);
        return [
            ntResultStepIntent(context, parentStep, {
                planId: ntDoneAnchor(PLAN_ID),
                dependsOn: [],
                stepTitle: summary.displayName,
                result: { theme: summary.name, files: files.paths, compiled: files.compiled, attempt },
            }),
            ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `theme created (attempt ${attempt})`, 'input_output'),
        ];
    }
    if (attempt >= 2) {
        return [ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `t3-generate failed after retry:\n${errorText}`)];
    }
    // Bounded retry: the OPEN retry step lands FIRST, then this one completes with the
    // trace (never 'failed' while a retry is in flight — collab_messages.md).
    return [
        ntAgentStepIntent(context, parentStep, {
            agentName: AGENT_NAME,
            stepTitle: `${step.stepTitle || PLAN_ID} (retry)`,
            planId: 't3-generate-retry1',
            prompt: { planId: PLAN_ID, retryAttempt: 2, retryContext: errorText },
        }),
        ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `gate failed, retrying:\n${errorText}`, 'input_output'),
    ];
}
// Writes the theme pair and compiles the .ts. The description/suffix shown in the
// documentation page are read back from the generated source, so the page can never
// disagree with the file it documents.
async function writeTheme(draft) {
    const tsInfo = themeFile('.ts');
    const htmlInfo = themeFile('.html');
    const info = (parseThemeSource(draft.themeTs).module?.themeInfo || {});
    await writeStorTextAtomic(tsInfo, draft.themeTs, true);
    await writeStorTextAtomic(htmlInfo, renderThemeHtml({
        summary: draft.summary,
        description: typeof info.description === 'string' ? info.description : '',
        suffix: typeof info.suffix === 'string' ? info.suffix : '',
    }), true);
    // The molecule agents import('/_<dest>_/l2/skills/theme.js'), so the .ts must be
    // compiled. Best-effort (same stance as the Variant's group index): a failure is
    // reported in the result and the file stays for the user to fix.
    const compiled = await compileTheme(tsInfo);
    return { paths: [toDisplayPath(tsInfo), toDisplayPath(htmlInfo)], compiled };
}
async function compileTheme(fileInfo) {
    try {
        const storFile = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        if (!storFile)
            return false;
        const model = await storFile.getOrCreateModel();
        if (!model?.model)
            return false;
        return await mls.l2.typescript.compileAndPostProcess(model, true, false);
    }
    catch {
        return false;
    }
}
// Read-only view of what was created (adjust A1: there is no confirmation checkpoint).
// The shared Theme Confirmation widget in `readonly` mode disables both buttons.
async function openStepView(agent, context, step) {
    const draft = await readJsonArtifact(ntDraftFile(), false);
    await import('/_102020_/l2/aura/molecules/shared/widgetThemeConfirmation.js');
    const el = document.createElement('widget-theme-confirmation-102020');
    if (draft?.summary) {
        const value = { title: draft.summary.displayName, summary: draft.summary };
        el.value = value;
    }
    el.readonly = true;
    return el;
}
async function readAnswers() {
    const saved = await readJsonArtifact(ntAnswersFile(), false);
    return Array.isArray(saved?.answers) ? saved.answers : [];
}
async function loadAuthoringSkill() {
    const mod = await import('/_102020_/l2/aura/molecules/skills/themeAuthoring/index.js');
    if (typeof mod.skill !== 'string' || !mod.skill.trim())
        throw new Error(`[${AGENT_NAME}] themeAuthoring skill unreadable`);
    return mod.skill;
}
