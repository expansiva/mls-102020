/// <mls fileReference="_102020_/l2/aura/molecules/agentNewTheme/agentNewTheme.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { NT_AGENT_FOLDER, ntPlanFile, readNtAgentText, themeExists, themeFile, toDisplayPath, writeJsonArtifact, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntFs.js';
import { ntParseEntryPrompt } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntEntry.js';
import { ntAgentStepIntent, ntDoneAnchor, ntUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewTheme/helpers/ntSteps.js';
import { normalizeNtPlan, runPlanGate } from '/_102020_/l2/aura/molecules/agentNewTheme/steps/t1-plan/gate.js';
const AGENT_NAME = 'agentNewTheme';
// Step titles are UI text, so they follow the detected userLanguage. Only the two
// languages the Studio actually runs in are tabled; anything else falls back to English.
const STEP_TITLES = {
    pt: { 't2-clarify': 'Completar o estilo', 't3-generate': 'Gerar e criar o tema' },
    en: { 't2-clarify': 'Complete the style', 't3-generate': 'Generate and create the theme' },
};
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: NT_AGENT_FOLDER,
        agentDescription: 'Creates this project\'s theme (l2/skills/theme.ts, contract v1) from a description, with one clarification checkpoint',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    // Admission first: New Theme only creates from scratch, it never clobbers a theme.
    if (themeExists()) {
        throw new Error(`[${AGENT_NAME}] this project already has ${toDisplayPath(themeFile('.ts'))} — New Theme only creates a theme from scratch (Improve Theme is not available yet)`);
    }
    let prompt;
    if (context.isTest) {
        const testData = JSON.parse(userPrompt || '{}');
        prompt = (testData.prompt || '').trim();
    }
    else {
        // Prose is the natural form here, so the runtime-stripped userPrompt is the source
        // (agentNewSolution does the same) and the arg parser is only tried on an object
        // literal — calling it on prose throws. See helpers/ntEntry.
        prompt = ntParseEntryPrompt(userPrompt, agent.agentName, raw => mls.common.safeParseArgs(raw));
    }
    const planPrompt = await readNtAgentText('steps/t1-plan', 'prompt', '.md', true);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: planPrompt },
                { type: 'human', content: JSON.stringify({ prompt }) },
            ],
            taskTitle: 'New theme',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { flowName: AGENT_NAME, prompt },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const plan = normalizeNtPlan(step.interaction?.payload?.[0]);
        const issues = runPlanGate(plan);
        if (issues.length) {
            const errorText = issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
            return [ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', errorText)];
        }
        await writeJsonArtifact(ntPlanFile(), { savedAt: new Date().toISOString(), ...plan });
        const titles = STEP_TITLES[plan.userLanguage.slice(0, 2).toLowerCase()] || STEP_TITLES.en;
        const hasQuestions = plan.questions.length > 0;
        const intents = [];
        // Fast path: with nothing missing, the checkpoint is not planted at all and
        // t3-generate becomes the first step to run.
        if (hasQuestions) {
            intents.push(ntAgentStepIntent(context, step, {
                agentName: 'agentNtClarify',
                stepTitle: titles['t2-clarify'],
                planId: 't2-clarify',
                prompt: { planId: 't2-clarify' },
                status: 'waiting_human_input',
            }));
        }
        // t3 is the last step: it generates AND writes (adjust A1 dropped the confirmation
        // checkpoint), so its 't3-done' anchor is terminal.
        intents.push(ntAgentStepIntent(context, step, {
            agentName: 'agentNtGenerate',
            stepTitle: titles['t3-generate'],
            planId: 't3-generate',
            dependsOn: hasQuestions ? [ntDoneAnchor('t2-clarify')] : [],
            prompt: { planId: 't3-generate' },
            status: hasQuestions ? 'waiting_dependency' : 'waiting_human_input',
        }));
        return intents;
    }
    catch (error) {
        return [ntUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
// ---- shared reader for the step agents ----
// The initial description, published to task memory by beforePromptImplicit.
export function getNtInput(context) {
    const memory = context.task?.iaCompressed?.longMemory || {};
    return { prompt: typeof memory.prompt === 'string' ? memory.prompt : '' };
}
