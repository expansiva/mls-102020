/// <mls fileReference="_102020_/l2/aura/molecules/agentNewTheme/helpers/ntAnswers.ts" enhancement="_blank"/>
export const NT_EXTRA_ANSWER_FIELD = 'extra';
export function ntResolveAnswers(known, answers) {
    const fields = cloneFields(known);
    const guidance = [];
    for (const answer of answers || []) {
        const field = (answer.field || '').trim();
        if (!field)
            continue;
        const notes = (answer.notes || '').trim();
        const value = (answer.value || '').trim();
        if (field === NT_EXTRA_ANSWER_FIELD) {
            if (notes)
                guidance.push(notes);
            else if (value)
                guidance.push(value);
            continue;
        }
        // An OPEN field is answered by typing, so its notes ARE the value; a CLOSED field
        // answers with an option id and its notes are extra nuance worth keeping.
        const chosen = value || notes;
        if (chosen)
            applyField(fields, field, chosen);
        if (notes && value)
            guidance.push(`${field}: ${notes}`);
    }
    if (fields.name && !fields.suffix)
        fields.suffix = `-${kebab(fields.name)}`;
    return { fields, guidance: guidance.join('\n') };
}
// 'background.kind' -> fields.background.kind, with the enum casts the model expects.
function applyField(fields, field, value) {
    switch (field) {
        case 'name':
            fields.name = kebab(value);
            return;
        case 'displayName':
            fields.displayName = value;
            return;
        case 'primary':
            fields.primary = value;
            return;
        case 'corners':
            fields.corners = value;
            return;
        case 'shadow':
            fields.shadow = value;
            return;
        case 'motion':
            fields.motion = value;
            return;
        case 'background.kind':
            fields.background = { ...(fields.background || {}), kind: value };
            return;
        case 'background.css':
            fields.background = { ...(fields.background || {}), css: value };
            return;
        case 'border.style':
            fields.border = { ...(fields.border || {}), style: value };
            return;
        case 'border.color':
            fields.border = { ...(fields.border || {}), color: value };
            return;
        case 'typography.family':
            fields.typography = { ...(fields.typography || {}), family: value };
            return;
        case 'typography.uppercaseLabels':
            fields.typography = { ...(fields.typography || {}), uppercaseLabels: value === 'true' };
            return;
        default:
            return; // unknown field ids were already rejected by the t1 gate
    }
}
// A theme id is a kebab token: 'Neo Brutal' -> 'neo-brutal'. Keeps name and the derived
// suffix consistent with the t3 gate (suffix === '-' + name).
function kebab(value) {
    return value.trim().toLowerCase().replace(/[\s_]+/g, '-').replace(/[^a-z0-9-]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '');
}
function cloneFields(known) {
    return {
        ...known,
        ...(known.background ? { background: { ...known.background } } : {}),
        ...(known.border ? { border: { ...known.border } } : {}),
        ...(known.typography ? { typography: { ...known.typography } } : {}),
    };
}
