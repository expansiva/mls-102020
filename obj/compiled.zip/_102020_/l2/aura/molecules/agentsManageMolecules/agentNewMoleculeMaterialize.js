/// <mls fileReference="_102020_/l2/aura/molecules/agentsManageMolecules/agentNewMoleculeMaterialize.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { appendLongTermMemory } from '/_102027_/l2/aiAgentHelper.js';
import { convertFileToTag } from '/_102020_/l2/utils';
import { createStorFile } from '/_102027_/l2/libStor.js';
// import { skill as skillDesing } from '/_102020_/l2/skills/aura/design.js';
import { skill as skillAura } from '/_102020_/l2/skills/aura/overview.js';
import { skill as skillMolecule } from '/_102020_/l2/skills/aura/moleculeGeneration2.js';
import { skills as skillList } from '/_102020_/l2/skills/molecules/index';
export function createAgent() {
    return {
        agentName: "agentNewMoleculeMaterialize",
        agentProject: 102020,
        agentFolder: "aura/molecules/agentsManageMolecules",
        agentDescription: "New agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const data = JSON.parse(userPrompt);
    const baseMolecule = await getBaseMolecule();
    const userPrompt2 = await getSystemUser(context, data.fileReference, { skill: data.skill, group: data.group });
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                        // .replace("{{systemSkillDesign}}", skillDesing)
                        .replace("{{systemSkillAura}}", skillAura)
                        .replace("{{systemSkillMolecule}}", skillMolecule)
                        .replace("{{systemBaseMolecule}}", baseMolecule)
                }, {
                    type: "human",
                    content: userPrompt2
                }],
            taskTitle: `Creating molecule`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { group: data.group }
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const baseMolecule = await getBaseMolecule();
    const userPrompt = await getSystemUser(context, args);
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: userPrompt,
        systemPrompt: system1
            // .replace("{{systemSkillDesign}}", skillDesing)
            .replace("{{systemSkillAura}}", skillAura)
            .replace("{{systemSkillMolecule}}", skillMolecule)
            .replace("{{systemBaseMolecule}}", baseMolecule)
    };
    return [continueIntent];
}
async function getSystemUser(context, fileReference, dataForTest) {
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    let data = { fileReference: '', skill: '', group: '' };
    if (dataForTest) {
        data = {
            fileReference,
            group: dataForTest.group,
            skill: dataForTest.skill
        };
    }
    else if (!files.defs)
        throw new Error(`[getSystemUser] invalid file: ${fileReference}`);
    else
        data = await getMoleculeSkill(files.defs);
    const skillByGroup = await getGroupSkill(data.group);
    const tagName = convertFileToTag(path);
    if (context.task)
        await appendLongTermMemory(context, { 'group': data.group });
    const system2 = `

    ## TagName : ${tagName}
    
    ## File Reference : ${data.fileReference}

    ## Skill Group: ${data.group}
    \`\`\`
        ${skillByGroup}
    \`\`\`


    ## Molecule ${tagName} specification:
    \`\`\`
        ${data.skill}
    \`\`\`

    `;
    return system2;
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
const MaxFixEffort = 2;
async function processOutput(context, output) {
    if (context.isTest) {
        console.info(output.ts);
        return [];
    }
    const data = await updateFiles(context, output);
    const group = context.task?.iaCompressed?.longMemory['group'];
    const fixCountRaw = context.task?.iaCompressed?.longMemory['fixCount'];
    const parsed = Number(fixCountRaw);
    const fixCount = Number.isNaN(parsed) ? 0 : parsed;
    if (data.hasErrors && fixCount < MaxFixEffort && !context.isTest) {
        const newCount = fixCount + 1;
        await appendLongTermMemory(context, { 'fixCount': newCount.toString() });
        const newStep = {
            type: "add-step",
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: 1,
            stepTitle: `Fix errors: ${data.fileReference}`,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                stepTitle: `Fix(${newCount})`,
                agentName: "agentNewMoleculeFix",
                prompt: data.fileReference,
                rags: null,
            }
        };
        return [newStep];
    }
    // Chain the .less materializer (it chains the playground once the styles are written).
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepTitle: 'Materializing styles',
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentMoleculeMaterializeLess",
            prompt: JSON.stringify({ fileReference: data.fileReference, group, nextPlayground: true }),
            rags: null,
        }
    };
    return [newStep];
}
async function updateFiles(context, result) {
    const molecule = result.ts;
    const fileReference = molecule.trim().split('\n')[0];
    const tripleSlash = mls.common.tripleslash.parseXMLTripleSlash(fileReference);
    let fileInfo = mls.stor.convertFileReferenceToFile(tripleSlash.variables['fileReference']);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
    const paramsTs = { ...fileInfo, content: molecule, versionRef: new Date().toISOString(), extension: ".ts" };
    const files = await mls.stor.getFiles({ ...fileInfo, loadContent: false });
    let modelTs;
    if (!files.ts) {
        const storFile = await createStorFile({
            extension: '.ts',
            folder: fileInfo.folder,
            level: fileInfo.level,
            project: fileInfo.project,
            shortName: fileInfo.shortName,
            source: molecule,
            status: 'new'
        }, true, true, true);
        modelTs = await storFile.getOrCreateModel();
    }
    else {
        modelTs = await updateStorFile(paramsTs);
    }
    const compileResultOk = await mls.l2.typescript.compileAndPostProcess(modelTs, true, false);
    console.info({ compileResultOk });
    return {
        fileReference: tripleSlash.variables['fileReference'],
        hasErrors: compileResultOk === false
    };
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMoleculeMaterialize] Invalid storFile');
    const path = mls.stor.getKeyToFile(params);
    console.log(`[agentNewMoleculeMaterialize] updating file: ${path}`);
    console.log(`[agentNewMoleculeMaterialize] updating content: ${params.content}`);
    const models = await file.getOrCreateModel();
    models.model.setValue(params.content);
    return models;
}
async function getGroupSkill(group) {
    const path = skillList.find((item) => item.name === group)?.skillReference;
    if (!path)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    const module = await import(path);
    if (!module || !module.skill)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    if (typeof module.skill !== 'string')
        throw new Error(`[getGroupSkill] invalid type of skill: ${path}, must be string`);
    return module.skill;
}
async function getBaseMolecule() {
    const key = mls.stor.getKeyToFile({ project: 102033, shortName: 'moleculeBase', folder: '', extension: '.ts', level: 2 });
    const storFile = mls.stor.files[key];
    if (!storFile)
        return '';
    const content = await storFile.getContent();
    return content;
}
async function getMoleculeSkill(file) {
    const path = `/_${file.project}_/${file.folder ? file.folder + '/' : ''}${file.shortName}.defs.js`;
    const defs = await import(path);
    const fileReference = mls.stor.convertFileToFileReference(file);
    if (!defs)
        throw new Error(`[getMoleculeSkill] defs not found: ${path}`);
    if (!defs.skill)
        throw new Error(`[getMoleculeSkill] defs skill not found: ${path}`);
    if (!defs.group)
        throw new Error(`[getMoleculeSkill] defs group not found: ${path}`);
    return {
        skill: defs.skill,
        group: defs.group,
        fileReference: fileReference.replace('.defs.ts', '.ts')
    };
}
const system1 = `
<!-- modelType: codeinstruct -->

You are a senior Frontend Architect and Staff Software Engineer with 20+ years of experience building large-scale web applications using TypeScript, Lit, and state-driven architectures.

You must generate production-ready code that compiles without errors.
Task: Generate a molecule according the user request.


## File Reference Rule
The triple-slash comment \`fileReference\` value must be copied EXACTLY from \`## File Reference\` in the human message.
- fileReference format: \`_NNNNN_/l2/...\`  (no leading slash)
- Import path format:   \`/_NNNNN_/l2/...\` (leading slash required)
These are different conventions. Never apply the import path convention to fileReference.

## Context
### Aura Overview
\`\`\`
{{systemSkillAura}}
\`\`\`

### Molecule Skill
\`\`\`
{{systemSkillMolecule}}
\`\`\`

### Molecule Class Base
\`\`\`typescript
{{systemBaseMolecule}}
\`\`\`

### Desing Skill
\`\`\`
{{systemSkillDesign}}
\`\`\`


## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: Result;
    }

export type Result = {
    ts: string,
}

`;
//#endregion 
