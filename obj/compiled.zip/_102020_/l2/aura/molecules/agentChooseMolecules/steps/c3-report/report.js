/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/steps/c3-report/report.ts" enhancement="_blank"/>
/**
 * The joined table is the product: one row per region, carrying the group c1 chose and the molecule c2
 * chose for it. Scoring the battery against the gabarito is reading this table by hand
 * (flow.json.decisions.scoring).
 */
export function buildChRunReport(facts, charsPerToken) {
    const byGroup = new Map();
    for (const artifact of facts.groups)
        byGroup.set(artifact.group, artifact);
    const rows = facts.regions.map(region => {
        const artifact = region.group ? byGroup.get(region.group) : undefined;
        const choice = artifact?.choices.find(item => item.region === region.region);
        return {
            region: region.region,
            need: region.need,
            group: region.group,
            groupReason: region.reason,
            tag: choice?.tag ?? null,
            scenarioUsed: choice?.scenarioUsed ?? null,
            moleculeReason: choice?.reason || '',
        };
    });
    const notes = [];
    // The catalog read from the local cache is a finding, not a detail: the measurement is valid, but a
    // consumer outside the editor has only the published URL and would have read nothing.
    const viaCache = [
        ...(facts.level1Via === 'local-cache' ? ['nível 1'] : []),
        ...facts.groups.filter(artifact => artifact.catalogVia === 'local-cache').map(artifact => artifact.group),
    ];
    if (viaCache.length) {
        notes.push(`catálogo lido do CACHE LOCAL (não do projeto publicado): ${viaCache.join(', ')} — a escolha vale, mas um consumidor fora do editor não conseguiria ler; publicar o arquivo`);
    }
    for (const artifact of facts.groups) {
        if (!artifact.ok) {
            notes.push(`${artifact.group}: nenhuma resposta aceita pelo gate — ${artifact.errors.join(' | ') || 'sem detalhe'}`);
        }
        for (const tag of artifact.chosenWithoutDefs) {
            notes.push(`${tag} foi escolhida e está marcada como fora de contrato (sem .defs.ts) — o objetivo dela não estava disponível para a decisão`);
        }
    }
    for (const region of facts.regions) {
        if (!region.group)
            notes.push(`região '${region.region}': nenhum grupo publicado cobre — ${region.reason}`);
    }
    const rowsWithoutMolecule = rows.filter(row => row.group && !row.tag);
    for (const row of rowsWithoutMolecule) {
        notes.push(`região '${row.region}': ${row.group} não tem molécula para ela — ${row.moleculeReason}`);
    }
    return {
        schemaVersion: 1,
        savedAt: facts.savedAt,
        runKey: facts.runKey,
        definition: facts.definition,
        userLanguage: facts.userLanguage,
        catalog: {
            level1Reference: facts.level1Reference,
            publishedGroups: facts.publishedGroups,
            level1Via: facts.level1Via,
            groupsViaLocalCache: facts.groups.filter(artifact => artifact.catalogVia === 'local-cache').map(artifact => artifact.group),
        },
        rows,
        totals: {
            regions: facts.regions.length,
            regionsWithoutGroup: facts.regions.filter(region => !region.group).length,
            regionsWithoutMolecule: rowsWithoutMolecule.length,
            groupsChosen: facts.groups.length,
            groupsNotAnswered: facts.groups.filter(artifact => !artifact.ok).map(artifact => artifact.group),
        },
        gates: {
            tagIssues: facts.tagIssues,
            attemptsRefused: facts.attemptsRefused,
            // Zero by construction — the gate is what makes it zero. The count of REFUSALS above is the
            // interesting number: a gate that fired is a model that tried.
            inventedTagsInArtifacts: 0,
        },
        notes,
        sizes: {
            perStep: facts.sizes,
            catalogTokensEstTotal: facts.sizes.reduce((sum, size) => sum + size.catalogTokensEst, 0),
            totalTokensEstTotal: facts.sizes.reduce((sum, size) => sum + size.totalTokensEst, 0),
            charsPerTokenAssumed: charsPerToken,
        },
    };
}
/** The text the user reads in the task tree. Markdown, deterministic, nothing not measured. */
export function renderChRunSummary(report) {
    const lines = [];
    lines.push(`**Sonda do catálogo** · run \`${report.runKey}\` · ${report.totals.regions} região(ões), ${report.totals.groupsChosen} grupo(s)`);
    lines.push('');
    lines.push('| região | grupo | molécula | cenário |');
    lines.push('|---|---|---|---|');
    for (const row of report.rows) {
        lines.push(`| ${row.region} | ${row.group || '— (nenhum)'} | ${row.tag || '— (nenhuma)'} | ${row.scenarioUsed || '—'} |`);
    }
    lines.push('');
    lines.push('### Gates');
    lines.push(`- tags inventadas que chegaram ao artefato: **${report.gates.inventedTagsInArtifacts}**`);
    lines.push(`- tentativas recusadas pelo gate: ${report.gates.attemptsRefused}` +
        ` (inventada ${report.gates.tagIssues.invented}, sem prefixo ${report.gates.tagIssues.short}, caixa errada ${report.gates.tagIssues.case})`);
    if (report.totals.groupsNotAnswered.length) {
        lines.push(`- grupos sem resposta aceita: ${report.totals.groupsNotAnswered.join(', ')}`);
    }
    lines.push('');
    lines.push('### Tamanho dos prompts (tokens estimados)');
    lines.push('| passo | modelType | catálogo | total |');
    lines.push('|---|---|---|---|');
    for (const size of report.sizes.perStep) {
        const attempt = size.attempt > 1 ? ` (tent. ${size.attempt})` : '';
        lines.push(`| ${size.planId}${attempt} | ${size.modelType || '—'} | ${size.catalogTokensEst} | ${size.totalTokensEst} |`);
    }
    lines.push(`| **soma** | | **${report.sizes.catalogTokensEstTotal}** | **${report.sizes.totalTokensEstTotal}** |`);
    lines.push('');
    lines.push(`Estimativa a ${report.sizes.charsPerTokenAssumed} chars/token — a plataforma não expõe o consumo real.`);
    if (report.notes.length) {
        lines.push('');
        lines.push('### Observações');
        for (const note of report.notes)
            lines.push(`- ${note}`);
    }
    lines.push('');
    lines.push('A pontuação contra o gabarito é manual: `run.json` tem a tabela completa com as justificativas.');
    return lines.join('\n');
}
