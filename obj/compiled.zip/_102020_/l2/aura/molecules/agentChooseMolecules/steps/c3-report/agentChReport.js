/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/steps/c3-report/agentChReport.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readJsonArtifact, toDisplayPath, writeJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { CH_AGENT_FOLDER, CH_CHARS_PER_TOKEN, CH_MAX_ATTEMPTS, CH_PLAN_C1, CH_PLAN_C3, chDoneAnchor, chGroupPlanId, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';
import { chGroupArtifactFileInfo, chGroupsFileInfo, chInputFileInfo, chPromptSizeFileInfo, chRunFileInfo, chTraceFileInfo, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chCatalog.js';
import { getChRunKey } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chRootPlan.js';
import { buildChRunReport, renderChRunSummary } from '/_102020_/l2/aura/molecules/agentChooseMolecules/steps/c3-report/report.js';
const AGENT_NAME = 'agentChReport';
const PLAN_ID = CH_PLAN_C3;
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${CH_AGENT_FOLDER}/steps/c3-report`,
        agentDescription: 'c3-report — consolidates the run into run.json and renders the readable summary',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const runKey = getChRunKey(context, nmParseStepArgs(step.prompt).runKey);
    const input = await readJsonArtifact(chInputFileInfo(runKey), true);
    const groupsArtifact = await readJsonArtifact(chGroupsFileInfo(runKey), true);
    if (!input || !groupsArtifact) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `[${AGENT_NAME}] run ${runKey} has no input.json / c1-groups.json to report on`)];
    }
    const groups = [];
    for (const group of groupsArtifact.groups) {
        const artifact = await readJsonArtifact(chGroupArtifactFileInfo(runKey, group), false);
        // A group whose step died before writing is recorded as unanswered rather than dropped: silent
        // truncation would read as "this group was never chosen", which is the opposite of what happened.
        groups.push(artifact || {
            schemaVersion: 1,
            savedAt: '',
            runKey,
            group,
            indexDefsReference: '',
            choices: [],
            ok: false,
            gateHits: 0,
            chosenWithoutDefs: [],
            errors: ['o passo deste grupo não deixou artefato'],
        });
    }
    const planIds = [CH_PLAN_C1, ...groupsArtifact.groups.map(group => chGroupPlanId(group))];
    const sizes = await readSizes(runKey, planIds);
    const { tagIssues, attemptsRefused } = await readTraceTotals(runKey, planIds);
    const facts = {
        savedAt: new Date().toISOString(),
        runKey,
        definition: input.definition,
        userLanguage: input.userLanguage,
        level1Reference: input.level1Reference || groupsArtifact.level1Reference,
        publishedGroups: (input.publishedGroups || []).map(group => group.name),
        regions: groupsArtifact.regions,
        groups,
        sizes,
        tagIssues,
        attemptsRefused,
    };
    const report = buildChRunReport(facts, CH_CHARS_PER_TOKEN);
    await writeJsonArtifact(chRunFileInfo(runKey), report);
    const summary = renderChRunSummary(report);
    return [
        nmResultStepIntent(context, parentStep, {
            planId: chDoneAnchor(PLAN_ID),
            dependsOn: [],
            stepTitle: `run ${runKey}: ${report.totals.regions} região(ões), ${report.totals.groupsChosen} grupo(s)`,
            result: {
                runKey,
                runFile: toDisplayPath(chRunFileInfo(runKey)),
                regions: report.totals.regions,
                regionsWithoutGroup: report.totals.regionsWithoutGroup,
                regionsWithoutMolecule: report.totals.regionsWithoutMolecule,
                attemptsRefused: report.gates.attemptsRefused,
                tagIssues: report.gates.tagIssues,
                totalTokensEst: report.sizes.totalTokensEstTotal,
            },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary, 'input_output'),
    ];
}
// ---- helpers ----
/**
 * Every attempt's size artifact. Enumerated from the plan ids and the attempt budget rather than by
 * listing the folder: the set of files a run can have written is known, and reading a name that was
 * never written costs one miss.
 */
async function readSizes(runKey, planIds) {
    const out = [];
    for (const planId of planIds) {
        for (let attempt = 1; attempt <= CH_MAX_ATTEMPTS; attempt += 1) {
            const size = await readJsonArtifact(chPromptSizeFileInfo(runKey, planId, attempt), false);
            if (size)
                out.push(size);
        }
    }
    return out;
}
/** The gate history of the run: how many attempts were refused, and how the tags were wrong. */
async function readTraceTotals(runKey, planIds) {
    const tagIssues = { invented: 0, short: 0, case: 0 };
    let attemptsRefused = 0;
    for (const planId of planIds) {
        for (let attempt = 1; attempt <= CH_MAX_ATTEMPTS; attempt += 1) {
            const trace = await readJsonArtifact(chTraceFileInfo(runKey, planId, attempt), false);
            if (!trace)
                continue;
            if (trace.ok === false)
                attemptsRefused += 1;
            tagIssues.invented += trace.tagIssues?.invented || 0;
            tagIssues.short += trace.tagIssues?.short || 0;
            tagIssues.case += trace.tagIssues?.case || 0;
        }
    }
    return { tagIssues, attemptsRefused };
}
