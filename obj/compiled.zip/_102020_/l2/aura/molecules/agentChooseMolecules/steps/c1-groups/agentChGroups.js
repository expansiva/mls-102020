/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/steps/c1-groups/agentChGroups.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { appendLongTermMemory } from '/_102027_/l2/aiAgentHelper.js';
import { isRecord, parseMaybeJson, toDisplayPath, writeJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { buildVToolInstruction, createVToolSchema, extractVToolOutput, nmAgentStepIntent, nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { CH_AGENT_FOLDER, CH_MAX_ATTEMPTS, CH_PLAN_C1, chDoneAnchor, chMeasurePrompt, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';
import { chGroupsFileInfo, chInputFileInfo, chPromptSizeFileInfo, chTraceFileInfo, readChAgentText, readChLevel1, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chCatalog.js';
import { getChDefinition, getChRootPlan, getChRunKey } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chRootPlan.js';
import { buildChRegions, chDistinctGroups, normalizeChGroupsOutput, runChGroupsGate, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/steps/c1-groups/gate.js';
const AGENT_NAME = 'agentChGroups';
const PLAN_ID = CH_PLAN_C1;
const TOOL_NAME = 'submitGroupChoice';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${CH_AGENT_FOLDER}/steps/c1-groups`,
        agentDescription: 'c1-groups — chooses which published group serves each region of the page definition',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    const runKey = getChRunKey(context, parsedArgs.runKey);
    const plan = getChRootPlan(context);
    const definition = getChDefinition(context);
    const { level1, error } = await readChLevel1();
    if (!level1) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error)];
    }
    const promptMd = await readChAgentText('steps/c1-groups', 'prompt', '.md', true);
    const schemaRaw = await readChAgentText('schemas', 'c1-groups.schema', '.json', true);
    const schema = parseMaybeJson(schemaRaw);
    if (!isRecord(schema))
        throw new Error(`[${AGENT_NAME}] invalid c1-groups schema`);
    const groupNames = level1.groups.map(group => group.name);
    const systemPrompt = promptMd
        .split('{{catalog}}').join(level1.skill)
        .split('{{groupNames}}').join(groupNames.join(', '))
        .split('{{userLanguage}}').join(plan.userLanguage || 'the language of the request')
        + `\n\n${buildVToolInstruction(TOOL_NAME, 'the text is not a definition of a page or system at all')}`;
    const humanPrompt = [
        '## The definition',
        definition,
        parsedArgs.retryContext ? `\n## What the gate rejected — fix ALL of these\n${parsedArgs.retryContext}` : '',
    ].filter(Boolean).join('\n');
    // Written once, on the first attempt: the entry as it arrived, for whoever scores the battery.
    if (attempt === 1) {
        await writeJsonArtifact(chInputFileInfo(runKey), {
            schemaVersion: 1,
            savedAt: new Date().toISOString(),
            runKey,
            definition,
            userLanguage: plan.userLanguage,
            level1Reference: level1.reference,
            level1Via: level1.via,
            publishedGroups: level1.groups.map(group => ({ name: group.name, molecules: group.molecules })),
        });
        await appendLongTermMemory(context, { runKey });
    }
    await writeJsonArtifact(chPromptSizeFileInfo(runKey, PLAN_ID, attempt), chMeasurePrompt({ planId: PLAN_ID, attempt, systemPrompt, catalog: level1.skill, humanPrompt }));
    return [{
            type: 'prompt_ready',
            args: args || step.prompt || JSON.stringify({ planId: PLAN_ID, runKey }),
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt,
            humanPrompt,
            tools: [createVToolSchema(TOOL_NAME, 'Submit one entry per region of the page, with the group that serves it', schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    const runKey = getChRunKey(context, parsedArgs.runKey);
    const { level1, error: catalogError } = await readChLevel1();
    if (!level1) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', catalogError)];
    }
    const groupNames = level1.groups.map(group => group.name);
    let output = null;
    let extractError = '';
    try {
        const raw = extractVToolOutput(step.interaction?.payload?.[0], TOOL_NAME, ['regions']);
        if (raw.status === 'failed')
            extractError = `model reported failure: ${raw.trace.join('; ') || 'no reason'}`;
        else
            output = normalizeChGroupsOutput(raw.result);
    }
    catch (thrown) {
        extractError = thrown instanceof Error ? thrown.message : String(thrown);
    }
    const gate = output
        ? runChGroupsGate({ output, knownGroups: groupNames })
        : { ok: false, errors: [`extract: ${extractError}`] };
    const errorText = gate.errors.join('\n');
    await writeJsonArtifact(chTraceFileInfo(runKey, PLAN_ID, attempt), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        attempt,
        ok: gate.ok,
        // The trace keeps what the MODEL said; the artifact below keeps what will be used.
        ...(gate.ok ? {} : { errors: gate.errors, output }),
    });
    if (gate.ok && output) {
        const regions = buildChRegions(output, groupNames);
        const groups = chDistinctGroups(regions);
        const artifact = {
            schemaVersion: 1,
            savedAt: new Date().toISOString(),
            runKey,
            level1Reference: level1.reference,
            regions,
            groups,
        };
        await writeJsonArtifact(chGroupsFileInfo(runKey), artifact);
        const groupless = regions.filter(region => !region.group).length;
        const summary = groups.length
            ? `${regions.length} region(s) · ${groups.join(', ')}${groupless ? ` · ${groupless} without a group` : ''}`
            : `${regions.length} region(s) · no published group covers any of them`;
        return [
            nmResultStepIntent(context, parentStep, {
                planId: chDoneAnchor(PLAN_ID),
                dependsOn: [],
                stepTitle: summary,
                // The ROOT reads this to plant one c2 per group, so everything it needs is here.
                result: {
                    runKey,
                    groups,
                    regionCount: regions.length,
                    grouplessCount: groupless,
                    groupsFile: toDisplayPath(chGroupsFileInfo(runKey)),
                    attempt,
                },
            }),
            nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary, 'input_output'),
        ];
    }
    if (attempt >= CH_MAX_ATTEMPTS) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `${PLAN_ID} failed after ${attempt} attempts:\n${errorText}`)];
    }
    // Bounded retry: the OPEN retry step comes first, then complete-with-trace (never 'failed' with a
    // retry in flight — skills/collab_messages.md).
    return [
        nmAgentStepIntent(context, parentStep, {
            agentName: AGENT_NAME,
            stepTitle: `${step.stepTitle || PLAN_ID} (retry)`,
            planId: `${PLAN_ID}-retry${attempt}`,
            prompt: { planId: PLAN_ID, runKey, retryAttempt: attempt + 1, retryContext: errorText },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `gate failed, retrying:\n${errorText}`, 'input_output'),
    ];
}
