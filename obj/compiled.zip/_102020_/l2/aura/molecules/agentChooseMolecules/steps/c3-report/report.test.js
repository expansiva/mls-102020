/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/steps/c3-report/report.test.ts" enhancement="_blank"/>
import test from 'node:test';
import assert from 'node:assert/strict';
import { buildChRunReport, renderChRunSummary } from '/_102020_/l2/aura/molecules/agentChooseMolecules/steps/c3-report/report.js';
const SAVED_AT = '2026-08-19T12:00:00.000Z';
function size(planId, catalogTokensEst, totalTokensEst, attempt = 1) {
    return {
        planId,
        attempt,
        modelType: 'reasoning',
        instructionChars: 0,
        catalogChars: catalogTokensEst * 4,
        inputChars: 0,
        totalChars: totalTokensEst * 4,
        instructionTokensEst: 0,
        catalogTokensEst,
        inputTokensEst: 0,
        totalTokensEst,
    };
}
function groupArtifact(over) {
    return {
        schemaVersion: 1,
        savedAt: SAVED_AT,
        runKey: 'cadastro',
        group: 'groupEnterText',
        indexDefsReference: '/_102040_/l2/molecules/groupentertext/index.defs',
        catalogVia: 'published',
        choices: [],
        ok: true,
        gateHits: 0,
        chosenWithoutDefs: [],
        errors: [],
        ...over,
    };
}
function facts(over) {
    return {
        savedAt: SAVED_AT,
        runKey: 'cadastro',
        definition: 'Cadastro de cliente: nome e CPF',
        userLanguage: 'pt',
        level1Reference: '/_102040_/l2/molecules/skill',
        level1Via: 'published',
        catalogProject: 102040,
        catalogSelectedBy: 'dependency',
        candidates: [102040],
        catalogWarnings: [],
        publishedGroups: ['groupEnterText'],
        regions: [],
        groups: [],
        sizes: [],
        usage: [],
        tagIssues: { invented: 0, short: 0, case: 0 },
        attemptsRefused: 0,
        ...over,
    };
}
const REGIONS = [
    { region: 'nome', need: 'nome completo', group: 'groupEnterText', reason: 'texto livre' },
    { region: 'grafico', need: 'gráfico de vendas', group: null, reason: 'nenhum grupo publicado tem gráfico' },
];
void test('joins each region to the molecule chosen for it', () => {
    const report = buildChRunReport(facts({
        regions: REGIONS,
        groups: [groupArtifact({
                choices: [{ region: 'nome', group: 'groupEnterText', tag: 'groupentertext--ml-enter-text', scenarioUsed: null, reason: 'texto simples' }],
            })],
    }), 4);
    assert.equal(report.rows.length, 2);
    assert.equal(report.rows[0].tag, 'groupentertext--ml-enter-text');
    assert.equal(report.rows[1].group, null);
    assert.equal(report.rows[1].tag, null);
    assert.equal(report.totals.regionsWithoutGroup, 1);
    assert.equal(report.totals.regionsWithoutMolecule, 0);
});
void test('a region whose group answered "none" is counted apart from one with no group', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({
                choices: [{ region: 'nome', group: 'groupEnterText', tag: null, scenarioUsed: null, reason: 'nada neste grupo serve' }],
            })],
    }), 4);
    assert.equal(report.totals.regionsWithoutGroup, 0);
    assert.equal(report.totals.regionsWithoutMolecule, 1);
    assert.match(report.notes.join('\n'), /não tem molécula para ela/);
});
void test('a group with no accepted answer is reported, never dropped', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({ ok: false, errors: ['tag_invented: ...'] })],
    }), 4);
    assert.deepEqual(report.totals.groupsNotAnswered, ['groupEnterText']);
    assert.match(report.notes.join('\n'), /nenhuma resposta aceita/);
});
void test('choosing a molecule marked as outside the contract is noted', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({
                choices: [{ region: 'nome', group: 'groupEnterText', tag: 'groupselectmany--ml-table-multi-select', scenarioUsed: null, reason: 'r' }],
                chosenWithoutDefs: ['groupselectmany--ml-table-multi-select'],
            })],
    }), 4);
    assert.match(report.notes.join('\n'), /fora de contrato/);
});
void test('the gate history is carried, and no invented tag ever reaches an artifact', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({ gateHits: 1 })],
        tagIssues: { invented: 2, short: 1, case: 0 },
        attemptsRefused: 3,
    }), 4);
    assert.equal(report.gates.inventedTagsInArtifacts, 0);
    assert.equal(report.gates.attemptsRefused, 3);
    assert.equal(report.gates.tagIssues.invented, 2);
});
void test('the prompt sizes are summed per catalog and per total', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        sizes: [size('c1-groups', 387, 900), size('c2-groupentertext', 928, 1500)],
    }), 4);
    assert.equal(report.sizes.catalogTokensEstTotal, 1315);
    assert.equal(report.sizes.totalTokensEstTotal, 2400);
    assert.equal(report.sizes.charsPerTokenAssumed, 4);
});
void test('the summary shows the joined table, the zero and the estimate caveat', () => {
    const report = buildChRunReport(facts({
        regions: REGIONS,
        groups: [groupArtifact({
                choices: [{ region: 'nome', group: 'groupEnterText', tag: 'groupentertext--ml-enter-text', scenarioUsed: 'Simple text', reason: 'r' }],
            })],
        sizes: [size('c1-groups', 387, 900)],
    }), 4);
    const text = renderChRunSummary(report);
    assert.match(text, /\| nome \| groupEnterText \| groupentertext--ml-enter-text \| Simple text \|/);
    assert.match(text, /\| grafico \| — \(nenhum\) \| — \(nenhuma\) \| — \|/);
    assert.match(text, /tags inventadas que chegaram ao artefato: \*\*0\*\*/);
    assert.match(text, /4 chars\/token/);
    assert.match(text, /pontuação contra o gabarito é manual/);
});
void test('a catalog read from the editor is reported as a finding', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({ catalogVia: 'stor' })],
    }), 4);
    assert.deepEqual(report.catalog.groupsReadFromEditor, ['groupEnterText']);
    assert.match(report.notes.join('\n'), /EDITOR \(stor\)/);
    assert.match(renderChRunSummary(report), /EDITOR \(stor\)/);
});
void test('a catalog served by the published module leaves no such note', () => {
    const report = buildChRunReport(facts({ regions: [REGIONS[0]], groups: [groupArtifact({})] }), 4);
    assert.deepEqual(report.catalog.groupsReadFromEditor, []);
    assert.equal(report.notes.some(note => note.includes('EDITOR')), false);
});
void test('the catalog that answered is named in the report and in the summary', () => {
    const report = buildChRunReport(facts({ regions: [REGIONS[0]], groups: [groupArtifact({})] }), 4);
    assert.equal(report.catalog.project, 102040);
    assert.equal(report.catalog.selectedBy, 'dependency');
    assert.match(renderChRunSummary(report), /catálogo do projeto \*\*102040\*\* \(dependency\)/);
});
void test('a catalog outside the dependencies is warned about ABOVE the per-region notes', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({})],
        catalogWarnings: ['102054 is not a direct dependency of 102053: a page in 102053 cannot import the molecules that were chosen'],
    }), 4);
    assert.match(report.notes[0], /cannot import/);
});
void test('more than one reachable catalog is recorded even when one was named', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({})],
        catalogSelectedBy: 'arg',
        candidates: [102040, 102054],
    }), 4);
    assert.match(report.notes.join('\n'), /mais de um catálogo alcançável \(102040, 102054\)/);
});
void test('the real cost of the run is carried, and the platform overhead is the gap to the estimate', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({})],
        sizes: [size('c1-groups', 387, 1200), size('c2-groupentertext', 928, 1800)],
        usage: [
            { planId: 'c1-groups', attempt: 1, inputTokens: 7727, outputTokens: 649, costUsd: 0.0239, calls: 1, models: ['x'] },
            { planId: 'c2-groupentertext', attempt: 1, inputTokens: 9273, outputTokens: 400, costUsd: 0.03, calls: 1, models: ['x'] },
        ],
    }), 4);
    assert.equal(report.usage.inputTokensTotal, 17000);
    assert.equal(report.usage.outputTokensTotal, 1049);
    assert.equal(report.usage.costUsdTotal, 0.0539);
    // 17000 real against 3000 assembled.
    assert.equal(report.usage.overheadFactor, 5.67);
    assert.deepEqual(report.usage.stepsNotMeasured, []);
    const text = renderChRunSummary(report);
    assert.match(text, /7727/);
    assert.match(text, /5\.67×/);
});
void test('a step whose trace carried no provider line is named, never counted as zero', () => {
    const report = buildChRunReport(facts({
        regions: [REGIONS[0]],
        groups: [groupArtifact({})],
        sizes: [size('c1-groups', 387, 1200), size('c2-groupentertext', 928, 1800)],
        usage: [{ planId: 'c1-groups', attempt: 1, inputTokens: 7727, outputTokens: 649, costUsd: 0.0239, calls: 1, models: ['x'] }],
    }), 4);
    assert.deepEqual(report.usage.stepsNotMeasured, ['c2-groupentertext (tent. 1)']);
    // The factor compares only what was measured: 7727 against c1's 1200.
    assert.equal(report.usage.overheadFactor, 6.44);
    assert.match(renderChRunSummary(report), /não medido/);
});
