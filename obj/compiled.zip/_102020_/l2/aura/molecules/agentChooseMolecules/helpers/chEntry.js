/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chEntry.ts" enhancement="_blank"/>
const ENTRY_KEY = 'catalogProject';
/**
 * `{ catalogProject: 102040 } Cadastro de cliente: nome completo, CPF...` — an optional object literal
 * followed by the prose.
 *
 * mls.common.safeParseArgs is not used and must not be: it THROWS on anything that is not an object
 * literal, and here the object is optional and never alone (the prose follows it). The braces are matched
 * by depth rather than by regex so a brace inside the definition cannot end the argument early.
 */
export function chParseEntry(raw) {
    const text = (raw || '').trim();
    if (!text.startsWith('{'))
        return { catalogProject: null, definition: text, error: '' };
    const close = matchingBrace(text);
    if (close < 0) {
        return { catalogProject: null, definition: '', error: `the argument opens with '{' and never closes — write it as '{ ${ENTRY_KEY}: 102040 }' followed by the definition` };
    }
    const argument = text.slice(0, close + 1);
    const definition = text.slice(close + 1).trim();
    const found = new RegExp(`['"]?${ENTRY_KEY}['"]?\\s*:\\s*['"]?(\\d+)`).exec(argument);
    if (!found) {
        return { catalogProject: null, definition, error: `the only argument this agent takes is '${ENTRY_KEY}' — write '{ ${ENTRY_KEY}: 102040 }' followed by the definition, or nothing at all and the catalog is looked up` };
    }
    return { catalogProject: Number(found[1]), definition, error: '' };
}
function matchingBrace(text) {
    let depth = 0;
    for (let index = 0; index < text.length; index += 1) {
        if (text[index] === '{')
            depth += 1;
        else if (text[index] === '}') {
            depth -= 1;
            if (!depth)
                return index;
        }
    }
    return -1;
}
/**
 * EXACTLY ONE catalog answers a run.
 *
 * With no argument the rule is: one candidate, use it; none, say where it looked; more than one, refuse and
 * name them. Refusing is deliberate — picking a theme in silence would answer with the wrong aesthetic and
 * the run would look correct. The message carries the argument that resolves it, so the refusal is a
 * question with the answer attached.
 */
export function chChooseCatalog(inputs) {
    const { activeProject, argProject, candidates, directDeps } = inputs;
    if (argProject) {
        if (!candidates.includes(argProject)) {
            return {
                project: null,
                selectedBy: null,
                error: `project ${argProject} has no molecule catalog (l2/molecules/skill.ts)${candidates.length ? `. Projects that do: ${candidates.join(', ')}` : ' — and neither has any project reachable from here'}`,
                warnings: [],
            };
        }
        const warnings = [];
        // Allowed on purpose: probing a theme's catalog from outside it is a legitimate test. But a page in
        // this project could not import what it chose, so the run has to say so.
        if (argProject !== activeProject && !directDeps.includes(argProject)) {
            warnings.push(`${argProject} is not a direct dependency of ${activeProject}: a page in ${activeProject} cannot import the molecules that were chosen`);
        }
        return { project: argProject, selectedBy: 'arg', error: '', warnings };
    }
    if (!candidates.length) {
        return {
            project: null,
            selectedBy: null,
            error: `no molecule catalog found. Looked for l2/molecules/skill.ts in ${activeProject}${directDeps.length ? ` and in its direct dependencies (${directDeps.join(', ')})` : ' (it declares no dependency)'}`,
            warnings: [],
        };
    }
    if (candidates.length > 1) {
        return {
            project: null,
            selectedBy: null,
            error: `more than one catalog is reachable: ${candidates.join(', ')}. Say which one to use — '@@agentChooseMolecules { ${ENTRY_KEY}: ${candidates[0]} } <the definition>' — because molecules of two different themes do not belong in the same page`,
            warnings: [],
        };
    }
    const project = candidates[0];
    return { project, selectedBy: project === activeProject ? 'local' : 'dependency', error: '', warnings: [] };
}
