/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.ts" enhancement="_blank"/>
// Types, constants and the PURE helpers of agentChooseMolecules. No I/O, no mls.* access — which is
// what makes every gate and the report renderer node-testable (skills/agentTest.md, category B).
//
// Plumbing that already exists is imported, not restated: intents and l4 mechanics come from
// agentNewMolecule2/helpers (nmSteps, nmFs) and the strict tool wrapper from shared/llmTool. This file
// only declares what is specific to CHOOSING from the catalog. See flow.json.
export const CH_AGENT_NAME = 'agentChooseMolecules';
export const CH_AGENT_FOLDER = 'aura/molecules/agentChooseMolecules';
/** The agent lives in 102020 whatever project's catalog it reads. */
export const CH_AGENT_PROJECT = 102020;
/** One retry with the gate errors in the prompt, then stop. Same budget as agentImproveMolecule2. */
export const CH_MAX_ATTEMPTS = 2;
/** Steps whose planId is fixed. The c2 steps are one per chosen group — see chGroupPlanId. */
export const CH_PLAN_C1 = 'c1-groups';
export const CH_PLAN_FANOUT = 'c1r-fanout';
export const CH_PLAN_C3 = 'c3-report';
/**
 * 'c1-groups' -> 'c1-done'. Same convention as the rest of the family.
 *
 * ⚠️ NOT USABLE FOR THE c2 STEPS, and that is the whole reason chGroupDoneAnchor exists: splitting on
 * '-' would give every group's step the same 'c2-done' anchor, so a c3 that dependsOn it would be
 * waiting on an anchor several steps write — and the first one to land would unlock it.
 */
export function chDoneAnchor(planId) {
    return `${planId.split('-')[0]}-done`;
}
/** The folder spelling of a group: the catalog publishes 'groupSelectOne', the folder is lowercase. */
export function chGroupFolder(groupName) {
    return (groupName || '').trim().toLowerCase();
}
export function chGroupPlanId(groupName) {
    return `c2-${chGroupFolder(groupName)}`;
}
export function chGroupDoneAnchor(groupName) {
    return `${chGroupPlanId(groupName)}-done`;
}
/**
 * The catalog's own spelling for a group the model named, or '' when it named one that does not exist.
 *
 * Case-insensitive on purpose: 'groupselectone' for 'groupSelectOne' is a spelling slip, and spending a
 * retry on it would teach nothing about the catalog. The TAG is the opposite case — there the exact
 * spelling is the thing being measured (flow.json.decisions.tagSpelling).
 */
export function chCanonicalGroup(groupName, known) {
    const wanted = (groupName || '').trim().toLowerCase();
    if (!wanted)
        return '';
    return known.find(name => name.trim().toLowerCase() === wanted) || '';
}
export function chGateOk() {
    return { ok: true, errors: [] };
}
export function chGateFail(...errors) {
    return { ok: false, errors: errors.filter(Boolean) };
}
export function chIssue(code, message) {
    return `${code}: ${message}`;
}
// ---- prompt size, which is how "tokens per step" is measured here ----
/**
 * 4 chars per token, the usual ratio for prose in English and Portuguese.
 *
 * ⚠️ IT IS AN ESTIMATE AND IT IS THE METRIC (decision of 2026-08-19). There is no token telemetry on
 * this platform: the step contract carries no provider `usage`, so a step cannot read what its own call
 * consumed. The estimate errs by roughly ±20%, and the §11.4 question — does one level per prompt stay
 * in the 1–2k range? — has 2× to 4× of margin on the measured files, so the error cannot flip it.
 */
export const CH_CHARS_PER_TOKEN = 4;
export function chEstTokens(chars) {
    return Math.ceil(Math.max(0, chars) / CH_CHARS_PER_TOKEN);
}
export function chMeasurePrompt(args) {
    const catalogChars = args.catalog.length;
    const instructionChars = Math.max(0, args.systemPrompt.length - catalogChars);
    const inputChars = args.humanPrompt.length;
    const totalChars = args.systemPrompt.length + inputChars;
    return {
        planId: args.planId,
        attempt: args.attempt,
        modelType: chParseModelType(args.systemPrompt),
        instructionChars,
        catalogChars,
        inputChars,
        totalChars,
        instructionTokensEst: chEstTokens(instructionChars),
        catalogTokensEst: chEstTokens(catalogChars),
        inputTokensEst: chEstTokens(inputChars),
        totalTokensEst: chEstTokens(totalChars),
    };
}
export function chParseUsage(trace) {
    const lines = Array.isArray(trace) ? trace.filter((line) => typeof line === 'string') : [];
    const usage = { inputTokens: 0, outputTokens: 0, costUsd: 0, calls: 0, models: [] };
    for (const line of lines) {
        const input = /inputTokens:\s*(\d+)/.exec(line);
        const output = /outputTokens:\s*(\d+)/.exec(line);
        if (!input && !output)
            continue;
        usage.calls += 1;
        usage.inputTokens += input ? Number(input[1]) : 0;
        usage.outputTokens += output ? Number(output[1]) : 0;
        const cost = /cost:\s*\$?([\d.]+)/.exec(line);
        if (cost)
            usage.costUsd += Number(cost[1]);
        const model = /\bmodel:\s*(\S+)/.exec(line);
        if (model && !usage.models.includes(model[1]))
            usage.models.push(model[1]);
    }
    if (!usage.calls)
        return null;
    // Float addition of dollar amounts drifts; the cost is reported to the cent-of-a-cent it came in at.
    usage.costUsd = Math.round(usage.costUsd * 1e6) / 1e6;
    return usage;
}
/** The marker skills/modelTypes.md makes mandatory. Reported, so the run says which model type ran. */
export function chParseModelType(prompt) {
    const match = /<!--\s*modelType:\s*([a-zA-Z]+)\s*-->/.exec(prompt || '');
    return match ? match[1] : '';
}
/**
 * The "nothing fits" sentinel, at both levels.
 *
 * The strict tool schema cannot express a nullable string — a `["string","null"]` union is refused by
 * the strictest providers (agentsBestPractices §9) — so the schema asks for the word 'none' and the
 * gates turn it into null here. The accepted spellings include the Portuguese ones on purpose: the
 * prompts are answered in the user's language, and refusing 'nenhum' would spend a retry on a slip
 * that says nothing about the catalog.
 */
const CH_NONE_WORDS = ['', 'none', 'null', 'nenhum', 'nenhuma', 'nenhum grupo', 'n/a'];
export function chIsNone(value) {
    return CH_NONE_WORDS.includes(String(value ?? '').trim().toLowerCase());
}
/**
 * The GROUP a c2 step is about, read from its own args.
 *
 * nmParseStepArgs is the shared reader of step args (planId, runKey, retry) and knows nothing about a
 * group — widening a shared helper for one agent's field is the boundary agentsBestPractices §2 warns
 * about, so this reads the one extra field and the shared helper keeps reading the rest. Parsing the
 * same short string twice costs nothing.
 */
export function chGroupArg(value) {
    if (typeof value !== 'string') {
        return isPlainRecord(value) && typeof value.group === 'string' ? value.group.trim() : '';
    }
    const trimmed = value.trim();
    if (!trimmed.startsWith('{'))
        return '';
    try {
        const parsed = JSON.parse(trimmed);
        return isPlainRecord(parsed) && typeof parsed.group === 'string' ? parsed.group.trim() : '';
    }
    catch {
        return '';
    }
}
function isPlainRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/**
 * The stor file behind an import reference: '/_102040_/l2/molecules/groupenterdate/index.defs' ->
 * { project: 102040, level: 2, folder: 'molecules/groupenterdate', shortName: 'index', extension: '.defs.ts' }.
 *
 * ⚠️ MEASURED ON THE FIRST STUDIO RUN (2026-08-19): a dynamic import is served from the PUBLISHED project
 * (`https://on.collab.codes/_102040_/...`), so a catalog file that exists in the editor and was never
 * published fails with 'Failed to fetch dynamically imported module'. Reading it needs the stor, and the
 * stor is addressed by these five fields — hence this parse. Derived from the reference and never from a
 * second assumption about where a group's catalog lives, so the two cannot drift.
 *
 * `.defs` is an EXTENSION and not part of the shortName (the rule nmFs documents at length): 'index.defs'
 * is shortName 'index' + extension '.defs.ts', and getting it wrong files the model under a phantom group
 * where nothing finds it.
 */
export function chFileRefFromImport(reference) {
    const match = /^\/?_(\d+)_\/l(\d+)\/(.+)$/.exec((reference || '').trim());
    if (!match)
        return null;
    const project = Number(match[1]);
    const level = Number(match[2]);
    const rest = match[3].replace(/\.ts$/, '');
    const parts = rest.split('/');
    const last = parts.pop() || '';
    if (!project || !level || !last)
        return null;
    const defs = last.endsWith('.defs');
    return {
        project,
        level,
        folder: parts.join('/'),
        shortName: defs ? last.slice(0, -'.defs'.length) : last,
        extension: defs ? '.defs.ts' : '.ts',
    };
}
