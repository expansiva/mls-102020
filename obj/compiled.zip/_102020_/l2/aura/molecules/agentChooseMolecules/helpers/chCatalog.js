/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chCatalog.ts" enhancement="_blank"/>
// Reading the catalog, and the l4 paths of a run. The ONLY module here that touches the disk — every
// gate and the report renderer are pure and are fed from what this one reads.
//
// ⚠️ THE STOR IS READ FIRST, and the published module is the fallback. Inverted on 2026-08-19 after the
// first Studio run, for a reason that outlives the pilot: `await import(reference)` — the gesture of
// imResolve.readGroupSkill, which the pilot plan asked for — is served by the PUBLISHED project, so a
// catalog that exists in the editor and was never published is unreadable by it, and a published one that
// has unsaved edits is read STALE without saying so. Every other agent of this family reads the stor
// (nmFs), which is how agentNewMolecule2 writes a molecule and reads it back in the same run;
// readGroupSkill is the exception because it reads 102020's own published skills.
//
// The import stays as the second rung: it is the only one a consumer outside the editor has, and it needs
// no parser. Which rung answered is recorded per level (`via`).
//
// ⚠️ THE CATALOG IS NOT NECESSARILY IN THE ACTIVE PROJECT, and from 2026-08-20 it is looked up. The probe
// runs from the CLIENT project while the molecules live in a dependency: the base library, a theme project,
// or — after a molecule is copied — the client itself. So the search set is the active project plus its
// DIRECT dependencies, and exactly one catalog answers a run (helpers/chEntry.chChooseCatalog). Never a
// hardcoded 102040.
//
// ⚠️ AND THE FINDING BEHIND THAT ORDER IS ABOUT THE §10 DESIGN, not about this agent: a generated
// `index.defs.ts` is unreadable by any consumer until it is published. Publishing is part of generating a
// catalog, and the report says which rung answered so a run can never pass that off silently.
import { nmDestProject, nmFileExists, readStorText } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { CH_AGENT_FOLDER, CH_AGENT_PROJECT, chFileRefFromImport, chGroupFolder, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';
import { chExtractCatalogModule } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chExtract.js';
import { chChooseCatalog, } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chEntry.js';
// ---- agent-owned files (prompt.md, schemas) in the 102020 agent folder ----
export function chAgentFile(folder, shortName, extension) {
    const sub = folder ? `${CH_AGENT_FOLDER}/${folder}` : CH_AGENT_FOLDER;
    return { project: CH_AGENT_PROJECT, level: 2, folder: sub, shortName, extension };
}
export async function readChAgentText(folder, shortName, extension, required = false) {
    return readStorText(chAgentFile(folder, shortName, extension), required);
}
// ---- l4 work artifacts of one run ----
export function chWorkFile(runKey, shortName) {
    return { project: nmDestProject(), level: 4, folder: `agentChooseMolecules/${runKey}`, shortName, extension: '.json' };
}
export const chInputFileInfo = (runKey) => chWorkFile(runKey, 'input');
export const chGroupsFileInfo = (runKey) => chWorkFile(runKey, 'c1-groups');
/**
 * The consolidated report of a run.
 *
 * ⚠️ NAMED report.json, NOT run.json (2026-08-21). A file called run.json in this folder was found holding a
 * TaskData dump — the platform's task, not this report, and not even of the same run as its folder. Whatever
 * writes it, the name is contested and this artifact is the one thing a run must not lose.
 */
export const chRunFileInfo = (runKey) => chWorkFile(runKey, 'report');
export function chGroupArtifactFileInfo(runKey, groupName) {
    return chWorkFile(runKey, `c2-${chGroupFolder(groupName)}`);
}
export function chTraceFileInfo(runKey, planId, attempt) {
    return chWorkFile(runKey, `trace-${planId}-${String(attempt).padStart(2, '0')}`);
}
/** The prompt-size measurement of one attempt — written by beforePromptStep, before the call. */
export function chPromptSizeFileInfo(runKey, planId, attempt) {
    return chWorkFile(runKey, `prompt-${planId}-${String(attempt).padStart(2, '0')}`);
}
export function chLevel1FileInfo(project) {
    return { project, level: 2, folder: 'molecules', shortName: 'skill', extension: '.ts' };
}
export function chLevel1Reference(project) {
    return `/_${project}_/l2/molecules/skill`;
}
export async function readChLevel1(project) {
    const reference = chLevel1Reference(project);
    const imported = await loadCatalogModule(reference);
    if (!imported.mod || !imported.via)
        return { level1: null, error: imported.error };
    const mod = imported.mod;
    const groups = normalizeGroups(mod.groups);
    const skill = typeof mod.skill === 'string' ? mod.skill : '';
    if (!groups.length)
        return { level1: null, error: `${reference} publishes no group — nothing can be chosen from it` };
    if (!skill.trim())
        return { level1: null, error: `${reference} exports no 'skill' text — level 1 is what the first call reads` };
    return {
        level1: { project, reference, groups, skill, theme: typeof mod.theme === 'string' ? mod.theme : null, via: imported.via },
        error: '',
    };
}
/**
 * The search set is [active project, ...direct dependencies] and the rule that picks one of them is pure
 * (chChooseCatalog). Scanning is a filter over mls.stor.files, the same gesture utils.resolveNewTag uses to
 * resolve a molecule tag across projects — no fetch.
 */
export async function discoverChCatalog(argProject) {
    const activeProject = nmDestProject();
    // A cold session may not have the dependencies' file index in memory yet, and without it every candidate
    // would look absent.
    try {
        await mls.stor.loadProjectdependenciesInfoIfNeed(activeProject);
    }
    catch {
        // Best effort: if it fails, the scan below simply sees whatever is loaded and the error names it.
    }
    const declared = mls.l5.getProjectDetails(activeProject)?.prj_dependencies;
    const resolvedDeps = mls.l5.getProjectDependencies(activeProject, false) || [];
    const directDeps = Array.isArray(declared) ? declared.filter(project => project !== activeProject) : resolvedDeps;
    const searchOrder = [activeProject, ...directDeps];
    const candidates = searchOrder.filter(project => nmFileExists(chLevel1FileInfo(project)));
    const choice = chChooseCatalog({ activeProject, argProject, candidates, directDeps });
    return { ...choice, activeProject, directDeps, resolvedDeps, candidates };
}
export async function readChGroupCatalog(reference) {
    if (!reference)
        return { catalog: null, error: 'the group has no index.defs reference in level 1' };
    const imported = await loadCatalogModule(reference);
    if (!imported.mod || !imported.via)
        return { catalog: null, error: imported.error };
    const mod = imported.mod;
    const molecules = normalizeMolecules(mod.molecules);
    const skill = typeof mod.skill === 'string' ? mod.skill : '';
    // The 26 groups outside the pilot are one-line stubs: the file is there and says nothing. Saying that
    // beats "cannot read", which would point at the wrong problem.
    if (!molecules.length || !skill.trim()) {
        return { catalog: null, error: `${reference} has no catalog yet (no molecules or no 'skill' text) — this group is not part of the catalog of this project` };
    }
    return {
        catalog: {
            reference,
            via: imported.via,
            group: typeof mod.group === 'string' ? mod.group : '',
            usageContract: typeof mod.usageContract === 'string' ? mod.usageContract : '',
            molecules,
            scenarios: normalizeScenarios(mod.scenarios),
            skill,
        },
        error: '',
    };
}
/**
 * Rung 1 is the STOR: the source of truth inside the editor, including content that was never published.
 * Its text is turned into values by the pure chExtract, which parses only what the gates need and
 * evaluates nothing.
 *
 * Rung 2 is `await import(reference)`, the published module — the only rung available to a consumer that
 * is not the editor, and the one that needs no parser.
 *
 * Failing both, the message says which rung failed how: a file absent from the project is a different
 * problem from a file that is present, unparseable and unpublished.
 */
async function loadCatalogModule(reference) {
    const trace = [];
    const ref = chFileRefFromImport(reference);
    if (!ref) {
        trace.push(`'${reference}' is not a project reference`);
    }
    else if (!nmFileExists(ref)) {
        trace.push('it is not in this project');
    }
    else {
        const extracted = chExtractCatalogModule(await readStorText(ref, false));
        if (extracted.module)
            return { mod: extracted.module, via: 'stor', error: '' };
        trace.push(`the file in this project could not be read as a catalog (${extracted.error})`);
    }
    try {
        return { mod: await import(reference), via: 'published', error: '' };
    }
    catch (error) {
        trace.push(`the published project does not serve it (${error instanceof Error ? error.message : String(error)})`);
    }
    return { mod: null, via: null, error: `${reference} could not be read: ${trace.join('; ')}.` };
}
// ---- normalizers: the catalog is generated code, so shape is checked and never assumed ----
//
// Both rungs pass through them. chExtract already returns typed arrays, so on the stor path they are a
// second guard; on the published path they are the only one, since a module can export anything.
function normalizeGroups(value) {
    if (!Array.isArray(value))
        return [];
    const out = [];
    for (const item of value) {
        if (!isRecord(item))
            continue;
        const name = typeof item.name === 'string' ? item.name.trim() : '';
        const indexDefs = typeof item.indexDefs === 'string' ? item.indexDefs.trim() : '';
        if (!name || !indexDefs)
            continue;
        out.push({ name, molecules: typeof item.molecules === 'number' ? item.molecules : 0, indexDefs });
    }
    return out;
}
function normalizeMolecules(value) {
    if (!Array.isArray(value))
        return [];
    const out = [];
    for (const item of value) {
        if (!isRecord(item))
            continue;
        const tag = typeof item.tag === 'string' ? item.tag.trim() : '';
        if (!tag)
            continue;
        out.push({ tag, defs: typeof item.defs === 'string' && item.defs.trim() ? item.defs.trim() : null });
    }
    return out;
}
function normalizeScenarios(value) {
    if (!Array.isArray(value))
        return [];
    const out = [];
    for (const item of value) {
        if (!isRecord(item))
            continue;
        const scenario = typeof item.scenario === 'string' ? item.scenario.trim() : '';
        if (!scenario)
            continue;
        const recommended = Array.isArray(item.recommended)
            ? item.recommended.filter((tag) => typeof tag === 'string')
            : [];
        out.push({ scenario, recommended });
    }
    return out;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
