/// <mls fileReference="_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chExtract.ts" enhancement="_blank"/>
export function chExtractCatalogModule(source) {
    const text = source || '';
    if (!text.trim())
        return { module: null, error: 'the file is empty' };
    const module = {};
    const skill = extractTemplate(text, 'skill');
    if (skill)
        module.skill = skill;
    const groups = extractGroups(text);
    if (groups.length)
        module.groups = groups;
    const molecules = extractMolecules(text);
    if (molecules.length)
        module.molecules = molecules;
    const scenarios = extractScenarios(text);
    if (scenarios.length)
        module.scenarios = scenarios;
    const group = extractString(text, 'group');
    if (group)
        module.group = group;
    const usageContract = extractString(text, 'usageContract');
    if (usageContract)
        module.usageContract = usageContract;
    if (/export const theme\s*=\s*null/.test(text))
        module.theme = null;
    else {
        const theme = extractString(text, 'theme');
        if (theme)
            module.theme = theme;
    }
    // A one-line stub (the 26 groups outside the pilot are exactly that) parses to nothing, and saying
    // "nothing to read" is the honest answer — the caller turns it into "this group has no catalog yet".
    if (!module.skill && !module.groups && !module.molecules) {
        return { module: null, error: 'no catalog export found in the source (no skill, no groups, no molecules)' };
    }
    return { module, error: '' };
}
// ---- one export at a time ----
/** `export const skill = ` + a template literal. The generated files put it last and use no inner backtick. */
function extractTemplate(text, name) {
    const marker = `export const ${name} = \``;
    const start = text.indexOf(marker);
    if (start < 0)
        return '';
    const from = start + marker.length;
    // lastIndexOf, not indexOf: it survives a backtick inside the markdown, which the generated files do
    // not have today and a hand edit could introduce.
    const end = text.lastIndexOf('`');
    return end > from ? text.slice(from, end) : '';
}
function extractString(text, name) {
    const match = new RegExp(`export const ${name}\\s*=\\s*(['"\`])([^'"\`]*)\\1`).exec(text);
    return match ? match[2] : '';
}
/** The lines of `export const <name> = [ ... ];`. Comment lines come back too and simply match nothing. */
function extractArrayLines(text, name) {
    const marker = `export const ${name} = [`;
    const start = text.indexOf(marker);
    if (start < 0)
        return [];
    const from = start + marker.length;
    const end = text.indexOf('];', from);
    if (end < 0)
        return [];
    return text.slice(from, end).split('\n');
}
function extractGroups(text) {
    const out = [];
    for (const line of extractArrayLines(text, 'groups')) {
        const name = quoted(line, 'name');
        const indexDefs = quoted(line, 'indexDefs');
        if (!name || !indexDefs)
            continue;
        const count = /molecules:\s*(\d+)/.exec(line);
        out.push({ name, molecules: count ? Number(count[1]) : 0, indexDefs });
    }
    return out;
}
function extractMolecules(text) {
    const out = [];
    for (const line of extractArrayLines(text, 'molecules')) {
        const tag = quoted(line, 'tag');
        if (!tag)
            continue;
        // `defs: null` is the mark of a molecule with no contract — the ml-table-multi-select case. It has to
        // survive the read, because the prompt asks the model to repeat that limitation.
        const defs = /defs:\s*null/.test(line) ? null : quoted(line, 'defs') || null;
        out.push({ tag, defs });
    }
    return out;
}
function extractScenarios(text) {
    const out = [];
    for (const line of extractArrayLines(text, 'scenarios')) {
        const scenario = quoted(line, 'scenario');
        if (!scenario)
            continue;
        const list = /recommended:\s*\[([^\]]*)\]/.exec(line);
        const recommended = list
            ? [...list[1].matchAll(/['"]([^'"]+)['"]/g)].map(match => match[1])
            : [];
        out.push({ scenario, recommended });
    }
    return out;
}
/** `key: 'value'` on one line, in either quote style. */
function quoted(line, key) {
    const match = new RegExp(`${key}:\\s*(['"])(.*?)\\1`).exec(line);
    return match ? match[2] : '';
}
