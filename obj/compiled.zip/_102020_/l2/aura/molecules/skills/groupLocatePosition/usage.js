/// <mls fileReference="_102020_/l2/aura/molecules/skills/groupLocatePosition/usage.ts" enhancement="_blank"/>
export const skill = `

# locate + position — Usage

> Quick reference for using molecules in the **locate + position** group.
> Use this when you need the user to **inform or visualize a geographic location**.

---

## Slot Tags

| Tag | Description |
|-----|-------------|
| \`Label\` | Label displayed above or beside the field |
| \`Helper\` | Descriptive text shown below the field when there is no error |
| \`Trigger\` | Custom label for the geolocation button |
| \`Suggestions\` | Container for suggestion items, populated by the page |
| \`Item\` | One suggestion inside \`<Suggestions>\`. Attribute: \`value\` = \`"lat,lng"\`. Content = address label |
| \`Empty\` | Content shown when no location is selected or no suggestions found |

---

## Properties

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| \`value\` | \`string \| null\` | \`null\` | Coordinates as \`"lat,lng"\` (e.g. \`"-23.55,-46.63"\`) or \`null\` |
| \`error\` | \`string\` | \`''\` | Error message. Empty string means no error |
| \`name\` | \`string\` | \`''\` | Field name for form identification |
| \`placeholder\` | \`string\` | \`''\` | Placeholder text for the search input |
| \`show-map\` | \`boolean\` | \`false\` | Show an embedded map preview of the selected location |
| \`allow-geolocation\` | \`boolean\` | \`false\` | Show a button to capture the user's current position |
| \`is-editing\` | \`boolean\` | \`true\` | \`true\` = interactive input, \`false\` = read-only text |
| \`disabled\` | \`boolean\` | \`false\` | Disables the field entirely |
| \`readonly\` | \`boolean\` | \`false\` | Prevents editing but keeps the field focusable |
| \`required\` | \`boolean\` | \`false\` | Marks a location as required |
| \`loading\` | \`boolean\` | \`false\` | Shows a loading indicator (e.g. while fetching suggestions) |

---

## Events

| Event | Detail | Description |
|-------|--------|-------------|
| \`change\` | \`{ value: string \| null }\` | Fired when a location is selected. Value is \`"lat,lng"\` or null |
| \`search\` | \`{ query: string }\` | Fired when the user types. Page must update \`<Suggestions>\` items in response |
| \`blur\` | \`{}\` | Fired when the field loses focus |
| \`focus\` | \`{}\` | Fired when the field receives focus |

---

## Value Format

- \`value\` is a plain **string** in \`"lat,lng"\` format (e.g. \`"-23.55,-46.63"\`)
- \`null\` when nothing is selected
- Suggestions are provided via \`<Item>\` elements inside the \`<Suggestions>\` slot tag

---

## Search Flow

The molecule does **not** call any API directly. The page is responsible for fetching suggestions:

\`\`\`
1. User types → molecule emits \`search\` with { query }
2. Page calls BFF, receives address list
3. Page updates <Suggestions> slot with <Item> elements
4. Molecule renders the suggestion list
5. User selects → molecule sets value = item.value, emits \`change\`
\`\`\`

---

## Examples

> **Tag names:** every molecule in this group is \`grouplocateposition--ml-<name>\` (e.g. \`grouplocateposition--ml-address-autocomplete\`), with no \`molecules--\` prefix and no project suffix. Copy the exact tag from the molecule's \`.defs.ts\` (\`TagName\`); never compose it.

### Address autocomplete

\`\`\`html
<grouplocateposition--ml-address-autocomplete
  value="{{ui.order.deliveryCoords}}"
  error="{{ui.order.addressError}}"
  placeholder="Search address..."
  required>
  <Label>Delivery Address</Label>
  <Suggestions>
    <Item value="-23.55,-46.63">São Paulo, SP</Item>
    <Item value="-22.90,-43.17">Rio de Janeiro, RJ</Item>
  </Suggestions>
</grouplocateposition--ml-address-autocomplete>
\`\`\`

---

## Customization via data-class

### On the component host

Pass extra CSS classes via \`data-class\`:

\`\`\`html
<component data-class="w-full mt-4">
  <Label>Text</Label>
</component>
\`\`\`

### On slot tags

Pass CSS classes on slot tags via \`data-class\`:

\`\`\`html
<component>
  <Label data-class="uppercase tracking-wide">Text</Label>
  <Helper data-class="italic">Help text</Helper>
</component>
\`\`\`

Each slot tag's classes land on the element it becomes: \`Trigger\` on the geolocation button, \`Suggestions\` on
the suggestions panel, each \`Item\` on its own option, \`Empty\` on the "no results" message (and on the value box
in view mode, while it shows the Empty content). In view mode the selected \`Item\`'s label is shown without its
classes:

\`\`\`html
<component allow-geolocation>
  <Trigger data-class="font-semibold">📍 Use my location</Trigger>
  <Suggestions data-class="max-h-72">
    <Item value="-23.55,-46.63" data-class="font-bold">São Paulo, SP</Item>
  </Suggestions>
  <Empty data-class="italic">No addresses found</Empty>
</component>
\`\`\`

---

## Design Tokens

The component's visual styling can be customized by overriding \`--ml-*\` CSS custom
properties on a parent element. The values below are this group's current defaults —
copy the block and change them:

\`\`\`css
.my-container {
  --ml-outline-focus: #3b82f6;
  --ml-outline-error: #ef4444;
}
\`\`\`

### Available tokens

| Token | Default | Purpose |
|-------|---------|---------|
| \`--ml-disabled-opacity\` | \`0.5\` | Opacity of disabled elements |
| \`--ml-focus-ring-width\` | \`2px\` | Focus ring width |
| \`--ml-outline-error\` | \`#ef4444\` | Error border |
| \`--ml-outline-focus\` | \`#3b82f6\` | Focus border |

`;
