/// <mls fileReference="_102020_/l2/aura/molecules/skills/groupNavigateSection/creation.ts" enhancement="_blank"/>
export const skill = `
# groupNavigateSection — Creation

> Implementation reference for creating molecules in the **groupNavigateSection** group.
> Follow the general Lit/Aura rules defined in \`molecule-generation2.md\`.

---

## 1. Metadata

| Field | Value |
|-------|-------|
| **Group** | \`groupNavigateSection\` |
| **Category** | Navigation |
| **Version** | \`1.0.0\` |

---

## 2. Slot Tags

| Tag | Required | Description |
|-----|:--------:|-------------|
| \`Label\` | No | Title displayed above the navigation |
| \`Tab\` | Yes | Defines one section. Attributes: \`value\` (required), \`title\` (required), \`disabled\`, \`icon\`, \`data-class\`. Content = the section body |

\`\`\`typescript
slotTags = ['Label', 'Tab'];
\`\`\`

### Slot Hierarchy

\`\`\`
component (root)
├── <Label>
└── <Tab value="..." title="..." icon="..." disabled>
      ...section content (text, HTML, web components)...
    </Tab>
\`\`\`

### Tab Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| \`value\` | \`string\` | Unique identifier for the section |
| \`title\` | \`string\` | Display text for the tab |
| \`icon\` | \`string\` (optional) | Icon content (emoji, text) displayed alongside the title |
| \`disabled\` | \`boolean\` (presence) | Tab cannot be selected |
| \`data-class\` | \`string\` (optional) | Consumer CSS classes applied to that tab's **button** (not to the content panel) |

---

## 3. Properties

### 3.1 Data

| Property | Type | Default | Decorator | Description |
|----------|------|---------|-----------|-------------|
| \`value\` | \`string \| null\` | \`null\` | \`@propertyDataSource\` | Value of the currently active tab. \`null\` = first tab is active |
| \`error\` | \`string\` | \`''\` | \`@propertyDataSource\` | Error message (empty = no error) |

### 3.2 States

| Property | Type | Default | Decorator | Description |
|----------|------|---------|-----------|-------------|
| \`disabled\` | \`boolean\` | \`false\` | \`@propertyDataSource\` | Disables all navigation |
| \`loading\` | \`boolean\` | \`false\` | \`@propertyDataSource\` | Show loading state |

---

## 4. Value Contract

- \`value\` is a **string** matching the \`value\` attribute of the active \`<Tab>\`
- \`null\` means no explicit selection — default to the first non-disabled tab
- When the user clicks a tab, \`value\` is updated and \`change\` is emitted
- The component renders only the content of the active tab — other tabs' content is hidden

---

## 5. Events

| Event | Detail | Bubbles | Description |
|-------|--------|:-------:|-------------|
| \`change\` | \`{ value: string, title: string }\` | ✓ | Fired when the active tab changes |

### Dispatch Example

\`\`\`typescript
this.dispatchEvent(new CustomEvent('change', {
  bubbles: true,
  composed: true,
  detail: { value: this.value, title: 'Settings' }
}));
\`\`\`

---

## 6. Reading Tabs

Read tabs inline using \`getSlots\`:

\`\`\`typescript
const tabs = this.getSlots('Tab').map(el => ({
  value: el.getAttribute('value') || '',
  title: el.getAttribute('title') || '',
  icon: el.getAttribute('icon') || '',
  disabled: el.hasAttribute('disabled'),
  cls: el.getAttribute('data-class') || '',
}));
\`\`\`

Each tab's \`cls\` goes on its own button: \`class="\${cn(this.getTabClasses(...), tab.cls)}"\`.

**In a trail (breadcrumb).** Each \`Tab\` is one item of the trail, and two things differ from a tab bar:
- the current item (usually the last) is not clickable, so it is a \`span\`, not a button: \`tab.cls\` goes on that \`span\` too;
- the trail is often rendered more than once (a narrow and a wide version, and the hidden items again inside an overflow menu): \`tab.cls\` goes on the item's element in **every** copy, so the class shows whichever version is visible.

\`\`\`typescript
// current item:
html\`<span class="\${cn(this.getTabClasses(isActive, tab.disabled, false), tab.cls)}" role="tab">…</span>\`
// other items, in each version of the trail and in the overflow menu:
html\`<button class="\${cn(this.getTabClasses(isActive, disabled, interactive), tab.cls)}" role="tab" @click=\${() => this.handleTabClick(tab)}>…</button>\`
\`\`\`

---

## 7. Visual States

| State | Behavior |
|-------|----------|
| **Active** | Selected tab highlighted |
| **Inactive** | Default/unselected appearance |
| **Disabled (tab)** | Individual tab dimmed, not clickable |
| **Disabled (component)** | All tabs dimmed, no interaction |
| **Loading** | Loading placeholder |

---

## 8. Accessibility (a11y)

| Requirement | Implementation |
|-------------|----------------|
| Container | \`role="tablist"\` |
| Tab | \`role="tab"\`, \`aria-selected\`, \`aria-disabled\`, \`aria-controls\` pointing to panel |
| Content panel | \`role="tabpanel"\`, \`aria-labelledby\` pointing to active tab |
| Label | \`aria-label\` from Label slot |
| Keyboard | \`ArrowLeft\`/\`ArrowRight\` navigate tabs; \`Enter\`/\`Space\` selects |

---

## 9. Design Tokens

### Tokens

This group uses CSS custom properties (tokens) for all visual styling.
All tokens are consumed in the .less file via var(--ml-token, fallback).
The fallback ensures the component renders without external configuration.

#### Surface and text
- --ml-surface (#ffffff) — background
- --ml-surface-dim (#f5f5f5) — hover background
- --ml-on-surface (#1c1b1f) — primary text
- --ml-on-surface-muted (#49454f) — secondary text
- --ml-on-surface-faint (#79747e) — placeholder

#### Action and feedback
- --ml-primary (#3b82f6) — primary action color
- --ml-on-primary (#ffffff) — text on primary
- --ml-error (#ef4444) — error color
- --ml-on-error (#ffffff) — text on error

#### Border and shape
- --ml-outline-variant (#e2e8f0) — default border
- --ml-outline-focus (#3b82f6) — focus border
- --ml-outline-error (#ef4444) — error border
- --ml-radius-sm (6px) — default radius
- --ml-radius-full (9999px) — circular radius
- --ml-border-width (1px) — border thickness
- --ml-border-style (solid) — border style

#### Elevation, typography, motion, focus, state
- --ml-shadow-0 (none) — no shadow
- --ml-shadow-1 (0 1px 3px rgba(0,0,0,0.1)) — subtle shadow
- --ml-shadow-2 (0 4px 6px rgba(0,0,0,0.1)) — medium shadow
- --ml-font-family (system-ui, -apple-system, sans-serif) — font
- --ml-font-weight-medium (500) — medium weight
- --ml-transition (200ms ease) — default transition
- --ml-focus-ring-color (rgba(59,130,246,0.4)) — focus ring color
- --ml-focus-ring-width (2px) — focus ring width
- --ml-disabled-opacity (0.5) — disabled opacity

### data-class

The component accepts \`data-class\` for consumer-provided CSS classes:
- On host: \`<component data-class="w-full mt-4">\`
- On slots: \`<Label data-class="uppercase tracking-wide">\` — applied to the label wrapper via \`getSlotClass('Label')\`
- On each Tab: \`<Tab value="a" title="A" data-class="font-bold">\` — applied to that tab's button (see §6)

### Shared semantic classes

| Class | Purpose |
|-------|---------|
| ml-label | Field label |
| ml-helper | Helper text |
| ml-error-text | Error message |
| ml-text | Default text |
| ml-text-muted | Secondary text |
| ml-text-faint | Placeholder text |
| ml-disabled | Disabled state |
| ml-skeleton | Loading placeholder |
| ml-spinner | Loading spinner |

Group-specific semantic classes will be defined during component migration.

---

## 10. Possible Implementations

| Component | Description |
|-----------|-------------|
| **Tabs** | Horizontal tab bar with underline indicator |
| **Pills / Segmented Control** | Compact inline button group |
| **Navigation Menu** | Vertical or horizontal nav links |
| **Bottom Navigation** | Mobile bottom bar with icons and labels |
| **Pagination** | Numbered page navigation |

All implementations share the same slot tag contract.

---

## 11. Changelog

| Version | Date | Description |
|---------|------|-------------|
| 1.0.0 | 2026-04-21 | Initial creation reference |
| 1.1.0 | 2026-04-21 | Tab content rendered by component; section body inside Tab slot |
| 1.2.0 | 2026-10-29 | §6: in a trail (breadcrumb), \`tab.cls\` also goes on the \`span\` of the current item and on the item's element in every copy of the trail (narrow, wide, overflow menu) |
`;
