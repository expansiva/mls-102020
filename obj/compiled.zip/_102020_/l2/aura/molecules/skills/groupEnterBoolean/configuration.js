/// <mls fileReference="_102020_/l2/aura/molecules/skills/groupEnterBoolean/configuration.ts" enhancement="_blank"/>
export const group = 'groupEnterBoolean';
// No design-time configuration for this group.
// All properties are page state (value, error, name, isEditing, disabled).
export const configuration = [];
