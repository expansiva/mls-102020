/// <mls fileReference="_102020_/l2/aura/molecules/skills/groupNavigateSteps/configuration.ts" enhancement="_blank"/>
export const group = 'groupNavigateSteps';
// Decisions on ambiguous cases:
// - `value` (current step), `error`, `disabled`, `loading` are page state — out.
// - `linear`: decides whether steps must be completed in order — in (design-time UX decision).
export const configuration = [
    { property: 'linear', type: 'boolean', default: true },
];
// Slot order: the steps are shown in the order written. No pair — a
// step's content lives inside its own `Step`.
export const slotOrder = [
    { slot: 'Step' },
];
