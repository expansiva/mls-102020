/// <mls fileReference="_102020_/l2/aura/molecules/skills/groupEnterNumberInterval/usage.ts" enhancement="_blank"/>
export const skill = `

# enter + number-interval — Usage

> Quick reference for using molecules in the **enter + number-interval** group.
> Use this when you need the user to provide a **numeric range (lower and upper value)**.

---

## Slot Tags

| Tag | Description |
|-----|-------------|
| \`Label\` | Overall label for the range field |
| \`LabelStart\` | Label shown above the lower-value control |
| \`LabelEnd\` | Label shown above the upper-value control |
| \`Helper\` | Descriptive text shown below the field when there is no error |
| \`Prefix\` | Content rendered before each value (e.g. unit symbol \`R$\`) |
| \`Suffix\` | Content rendered after each value (e.g. unit label \`%\`, \`kg\`) |

---

## Properties

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| \`startValue\` | \`number \| null\` | \`null\` | Lower bound of the interval |
| \`endValue\` | \`number \| null\` | \`null\` | Upper bound of the interval |
| \`error\` | \`string\` | \`''\` | Error message. Empty string means no error |
| \`name\` | \`string\` | \`''\` | Field name for form identification |
| \`min\` | \`number \| null\` | \`null\` | Absolute floor for both controls |
| \`max\` | \`number \| null\` | \`null\` | Absolute ceiling for both controls |
| \`step\` | \`number\` | \`1\` | Increment for both controls |
| \`decimals\` | \`number\` | \`0\` | Number of decimal places allowed |
| \`locale\` | \`string\` | \`''\` | Display locale, e.g. \`'en-US'\`, \`'pt-BR'\` |
| \`placeholder\` | \`string\` | \`''\` | Placeholder text when the interval is unset |
| \`minGap\` | \`number\` | \`0\` | Minimum distance between the two values (0 = no minimum) |
| \`maxGap\` | \`number\` | \`0\` | Maximum distance between the two values (0 = no maximum) |
| \`isEditing\` | \`boolean\` | \`true\` | \`true\` = input mode, \`false\` = read-only formatted text |
| \`disabled\` | \`boolean\` | \`false\` | Disables the field entirely |
| \`readonly\` | \`boolean\` | \`false\` | Prevents editing but keeps the field focusable |
| \`required\` | \`boolean\` | \`false\` | Marks both values as required |
| \`loading\` | \`boolean\` | \`false\` | Shows a loading indicator inside the field |

---

## Events

| Event | Detail | Description |
|-------|--------|-------------|
| \`change\` | \`{ startValue: number \| null, endValue: number \| null }\` | Fired when the interval is confirmed |
| \`input\` | \`{ startValue: number \| null, endValue: number \| null }\` | Fired continuously while either control is adjusted |
| \`blur\` | \`{}\` | Fired when the field loses focus |
| \`focus\` | \`{}\` | Fired when the field receives focus |

---

## Value Format

- Both values stored and emitted as native **JavaScript numbers**
- \`null\` when not yet provided
- \`startValue\` never exceeds \`endValue\` (the pair is clamped)
- Display format respects \`decimals\`, \`locale\`, and Prefix/Suffix; stored value is always a plain number

---

## Examples

> **Tag names:** every molecule in this group is \`groupenternumberinterval--ml-<name>\` (e.g. \`groupenternumberinterval--ml-number-range-slider\`), with no \`molecules--\` prefix and no project suffix. Copy the exact tag from the molecule's \`.defs.ts\` (\`TagName\`); never compose it.

### Basic — price band

\`\`\`html
<groupenternumberinterval--ml-number-range-slider
  startValue="{{ui.filter.priceMin}}"
  endValue="{{ui.filter.priceMax}}"
  error="{{ui.filter.priceError}}"
  min="0"
  max="1000"
  step="50"
  locale="pt-BR">
  <Label>Faixa de preço</Label>
  <LabelStart>De</LabelStart>
  <LabelEnd>Até</LabelEnd>
  <Prefix>R$</Prefix>
</groupenternumberinterval--ml-number-range-slider>
\`\`\`

### With decimals and a minimum gap

\`\`\`html
<groupenternumberinterval--ml-number-range-slider
  startValue="{{ui.config.weightMin}}"
  endValue="{{ui.config.weightMax}}"
  min="0"
  max="100"
  step="0.5"
  decimals="1"
  locale="pt-BR"
  minGap="5">
  <Label>Faixa de peso</Label>
  <LabelStart>Mínimo</LabelStart>
  <LabelEnd>Máximo</LabelEnd>
  <Suffix>kg</Suffix>
  <Helper>Diferença mínima de 5 kg entre os limites</Helper>
</groupenternumberinterval--ml-number-range-slider>
\`\`\`

---

## Customization via data-class

### On the component host

Pass extra CSS classes via \`data-class\`:

\`\`\`html
<component data-class="w-full mt-4">
  <Label>Text</Label>
</component>
\`\`\`

### On slot tags

Each slot tag's \`data-class\` lands on the element it becomes: \`Label\` on the label, \`LabelStart\`/\`LabelEnd\` on the
labels of the start and end values, \`Helper\` on the help text, and \`Prefix\`/\`Suffix\` on the affix in every place
it is shown (next to the start value, next to the end value, in the summary):

\`\`\`html
<component>
  <Label data-class="uppercase tracking-wide">Price range</Label>
  <Prefix data-class="font-semibold">R$</Prefix>
  <Suffix data-class="text-xs">/month</Suffix>
  <Helper data-class="italic">Help text</Helper>
</component>
\`\`\`

---

## Design Tokens

The component's visual styling can be customized by overriding \`--ml-*\` CSS custom
properties on a parent element. The values below are this group's current defaults —
copy the block and change them:

\`\`\`css
.my-container {
  --ml-focus-ring-error-color: rgba(239, 68, 68, 0.4);
  --ml-error: #ef4444;
  --ml-outline-focus: #3b82f6;
}
\`\`\`

### Available tokens

| Token | Default | Purpose |
|-------|---------|---------|
| \`--ml-border-style\` | \`solid\` | Border style |
| \`--ml-border-width\` | \`1px\` | Border width |
| \`--ml-disabled-opacity\` | \`0.5\` | Opacity of disabled elements |
| \`--ml-error\` | \`#ef4444\` | Error color |
| \`--ml-focus-ring-error-color\` | \`rgba(239, 68, 68, 0.4)\` | Focus ring color in error state |
| \`--ml-focus-ring-width\` | \`2px\` | Focus ring width |
| \`--ml-outline-error\` | \`#ef4444\` | Error border |
| \`--ml-outline-focus\` | \`#3b82f6\` | Focus border |

`;
