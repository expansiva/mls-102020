/// <mls fileReference="_102020_/l2/aura/molecules/skills/moleculeGeometry.ts" enhancement="_blank"/>
export const GEOMETRY_REGISTRY = [
    { token: '--ml-spinner-size', concept: 'spinner-size', value: '16px', purpose: 'diameter of the loading spinner' },
    { token: '--ml-spinner-duration', concept: 'spinner-duration', value: '0.8s', purpose: 'one full turn of the spinner' },
    { token: '--ml-spinner-border-width', concept: 'spinner-border-width', value: '2px', purpose: 'thickness of the spinner ring' },
    { token: '--ml-skeleton-duration', concept: 'skeleton-duration', value: '1.5s', purpose: 'one cycle of the skeleton shimmer' },
];
/** The markdown table of token -> value -> purpose, header row included. */
export function geometryRegistryRows() {
    return [
        '| token | value | purpose |',
        '|---|---|---|',
        ...GEOMETRY_REGISTRY.map(({ token, value, purpose }) => `| \`${token}\` | \`${value}\` | ${purpose} |`),
    ].join('\n');
}
