/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmContext.ts" enhancement="_blank"/>
// 'glass (-glass)' for the checkpoint's read-only theme line (decision Q3); '' with no theme,
// so the widget shows its own "none" label instead of a fake value.
export function themeLabel(ctx) {
    if (!ctx.theme.present || !ctx.theme.info)
        return '';
    const info = ctx.theme.info;
    return `${info.displayName || info.name}${info.suffix ? ` (${info.suffix})` : ''}`;
}
// The suffix a themed molecule's shortName must end with; '' when the project has no theme.
export function themeSuffix(ctx) {
    return ctx.theme.present && ctx.theme.info ? ctx.theme.info.suffix || '' : '';
}
export function moleculeContextSummary(ctx) {
    const theme = ctx.theme.present && ctx.theme.info ? ctx.theme.info.displayName || ctx.theme.info.name : 'no theme';
    return `${ctx.destination.groupCanonical} in mls-${ctx.destination.project} (${theme})`;
}
// l4 folder name for a run. Kebab, ascii-safe and bounded — it becomes a file path, and the
// model proposes it. Falls back to the group so a useless proposal still produces a valid path.
export function nmRunKey(raw, groupFolder) {
    const cleaned = (raw || '')
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 40)
        .replace(/-+$/g, '');
    return cleaned || groupFolder || 'run';
}
