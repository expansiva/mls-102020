/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmTypes.ts" enhancement="_blank"/>
// Shared types + plan ids for agentNewMolecule2. See flow.json for the contract each of these
// serves. Pure — no runtime imports, so gates and tests can use them freely.
// Constants the deterministic templates need. They live HERE, not in nmFs, because nmFs imports
// the 102027 stor runtime — a pure module must never reach it, or its tests cannot load.
export const NM_TS_ENHANCEMENT = '_102020_/l2/enhancementAura';
export const NM_LESS_ENHANCEMENT = '_102020_/l2/enhancementStyleAura';
// The molecule base class lives in mls-102033 (analise-fluxo-new-molecule-atual.md §2) — reading
// it from 102040 would inject the wrong contract.
export const NM_BASE_PROJECT = 102033;
export const NM_BASE_CLASS = 'MoleculeAuraElement';
export const NM_BASE_IMPORT = '/_102033_/l2/moleculeBase.js';
export const NM_PLAN_IDS = [
    'n1-bootstrap',
    'n2-plan',
    'n3-defs',
    'n4-render',
    'n5-less',
    'n6-demo',
    'n7-index',
    'n8-summary',
];
export function nmGateOk() {
    return { ok: true, errors: [] };
}
export function nmGateFail(errors) {
    return { ok: false, errors };
}
