/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmDiagnostics.ts" enhancement="_blank"/>
// `messageText` is either a string or a nested DiagnosticMessageChain.
export function flattenMessageText(messageText, depth = 0) {
    if (typeof messageText === 'string')
        return messageText;
    if (!messageText || typeof messageText !== 'object' || depth > 8)
        return '';
    const chain = messageText;
    const head = typeof chain.messageText === 'string' ? chain.messageText : '';
    const next = Array.isArray(chain.next) ? chain.next : chain.next ? [chain.next] : [];
    const tail = next.map(item => flattenMessageText(item, depth + 1)).filter(Boolean);
    return [head, ...tail].filter(Boolean).join(' -> ');
}
// 1-based line and column of a byte offset, plus the text of that line.
export function resolvePosition(source, offset) {
    const safeOffset = Math.max(0, Math.min(offset, source.length));
    const before = source.slice(0, safeOffset);
    const line = before.split('\n').length;
    const lineStart = before.lastIndexOf('\n') + 1;
    const lineEndRelative = source.slice(lineStart).indexOf('\n');
    const lineEnd = lineEndRelative === -1 ? source.length : lineStart + lineEndRelative;
    return { line, column: safeOffset - lineStart + 1, text: source.slice(lineStart, lineEnd) };
}
// Longest line kept in the excerpt. A minified or very long line would otherwise flood the retry
// prompt; the caret is what locates the problem, not the whole line.
const MAX_EXCERPT = 160;
export function formatCompileDiagnostics(diagnostics, source) {
    return diagnostics.map(diagnostic => {
        const message = flattenMessageText(diagnostic.messageText) || 'unknown compiler error';
        const code = typeof diagnostic.code === 'number' ? `TS${diagnostic.code}: ` : '';
        if (typeof diagnostic.start !== 'number' || !source)
            return `${code}${message}`;
        const { line, column, text } = resolvePosition(source, diagnostic.start);
        const width = Math.max(1, Math.min(diagnostic.length || 1, Math.max(1, text.length - column + 1)));
        const excerpt = text.length > MAX_EXCERPT ? `${text.slice(0, MAX_EXCERPT)}…` : text;
        const caretVisible = column <= MAX_EXCERPT;
        const caret = caretVisible ? `\n  ${' '.repeat(column - 1)}${'^'.repeat(width)}` : '';
        return `line ${line}, col ${column} — ${code}${message}\n  ${excerpt}${caret}`;
    });
}
