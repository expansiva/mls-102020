/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/steps/n3-defs/agentNm2Defs.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { NM_AGENT_FOLDER, compileStorTs, isRecord, nmContextFileInfo, nmDefsFile, nmPlanFileInfo, nmTraceFileInfo, parseMaybeJson, readJsonArtifact, readNmAgentText, toDisplayPath, writeJsonArtifact, writeStorTextAtomic, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmDefsHeader, nmIdentityFromPlan, renderDefsTs } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmTemplates.js';
import { buildVToolInstruction, createVToolSchema, extractVToolOutput, nmAgentStepIntent, nmDoneAnchor, nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { runNm2DefsGate } from '/_102020_/l2/aura/molecules/agentNewMolecule2/steps/n3-defs/gate.js';
import { getNmRunKey } from '/_102020_/l2/aura/molecules/agentNewMolecule2/agentNewMolecule2.js';
const AGENT_NAME = 'agentNm2Defs';
const PLAN_ID = 'n3-defs';
const TOOL_NAME = 'submitMoleculeContract';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NM_AGENT_FOLDER}/steps/n3-defs`,
        agentDescription: 'n3-defs — writes the molecule contract (.defs.ts)',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    const runKey = getNmRunKey(context, parsedArgs.runKey);
    const { ctx, plan } = await readArtifacts(runKey);
    const promptMd = await readNmAgentText('steps/n3-defs', 'prompt', '.md', true);
    const schemaRaw = await readNmAgentText('schemas', 'n3-defs.schema', '.json', true);
    const schema = parseMaybeJson(schemaRaw);
    if (!isRecord(schema))
        throw new Error(`[${AGENT_NAME}] invalid n3-defs schema`);
    const groupSkill = await loadGroupSkill(ctx);
    const systemPrompt = promptMd
        .split('{{tag}}').join(plan.tag)
        .split('{{groupCanonical}}').join(plan.groupCanonical)
        .split('{{groupSkill}}').join(groupSkill)
        .split('{{requirements}}').join(buildRequirements(plan))
        + `\n\n${buildVToolInstruction(TOOL_NAME, 'the confirmed requirements are not enough to write a contract')}`;
    const humanPrompt = [
        `Write the contract for ${plan.tag} in '${ctx.userLanguage}'.`,
        parsedArgs.retryContext ? `## The previous attempt failed the deterministic gate — fix ALL of these\n${parsedArgs.retryContext}` : '',
    ].filter(Boolean).join('\n\n');
    return [{
            type: 'prompt_ready',
            args: args || step.prompt || JSON.stringify({ planId: PLAN_ID, runKey }),
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt,
            humanPrompt,
            tools: [createVToolSchema(TOOL_NAME, 'Submit the molecule contract markdown', schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    const runKey = getNmRunKey(context, parsedArgs.runKey);
    const { plan } = await readArtifacts(runKey);
    const identity = nmIdentityFromPlan(plan);
    let source = '';
    let extractError = '';
    try {
        const output = extractVToolOutput(step.interaction?.payload?.[0], TOOL_NAME, ['skillMd']);
        if (output.status === 'failed')
            extractError = `model reported failure: ${output.trace.join('; ') || 'no reason'}`;
        else {
            const skillMd = String(output.result.skillMd || '');
            source = skillMd.trim() ? renderDefsTs(identity, skillMd, plan.layoutConfig || {}) : '';
        }
    }
    catch (error) {
        extractError = error instanceof Error ? error.message : String(error);
    }
    // A5b (2026-07-30): the .defs.ts is TypeScript and used to be written blind. Its known failure mode
    // is an unescaped backtick or `${` inside the skill literal, which the gate checks textually — the
    // compiler is the definitive check, so the file is written first and compiled. A failed attempt
    // leaves the content on disk for the retry to read, the same trade n4-render already makes.
    const fileInfo = nmDefsFile(plan.group, plan.shortName);
    let compileErrors = [];
    if (!extractError && source.trim()) {
        await writeStorTextAtomic(fileInfo, source, true);
        compileErrors = (await compileStorTs(fileInfo)).errors;
    }
    const issues = extractError
        ? [{ code: 'extract', message: extractError }]
        : [
            ...runNm2DefsGate(source, plan, nmDefsHeader(identity)),
            ...compileErrors.map(message => ({ code: 'compile', message })),
        ];
    const errorText = issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
    await writeJsonArtifact(nmTraceFileInfo(runKey, PLAN_ID, attempt), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        attempt,
        ok: issues.length === 0,
        chars: source.length,
        ...(issues.length ? { error: errorText } : {}),
    });
    if (issues.length === 0) {
        const display = toDisplayPath(fileInfo);
        return [
            nmResultStepIntent(context, parentStep, {
                planId: nmDoneAnchor(PLAN_ID),
                dependsOn: [],
                stepTitle: display,
                result: { file: display, attempt },
            }),
            nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `contract written (attempt ${attempt})`, 'input_output'),
        ];
    }
    if (attempt >= 2) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `${PLAN_ID} failed after retry:\n${errorText}`)];
    }
    // Bounded retry: the OPEN retry step comes first, then complete-with-trace (never 'failed' with a
    // retry in flight — collab_messages.md).
    return [
        nmAgentStepIntent(context, parentStep, {
            agentName: AGENT_NAME,
            stepTitle: `${step.stepTitle || PLAN_ID} (retry)`,
            planId: `${PLAN_ID}-retry1`,
            prompt: { planId: PLAN_ID, runKey, retryAttempt: 2, retryContext: errorText },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `gate failed, retrying:\n${errorText}`, 'input_output'),
    ];
}
// ---- helpers ----
async function readArtifacts(runKey) {
    const ctx = await readJsonArtifact(nmContextFileInfo(runKey), true);
    if (!ctx)
        throw new Error(`[${AGENT_NAME}] context.json missing for ${runKey}`);
    const plan = await readJsonArtifact(nmPlanFileInfo(runKey), true);
    if (!plan || !plan.confirmedAt)
        throw new Error(`[${AGENT_NAME}] plan.json missing or not confirmed for ${runKey}`);
    return { ctx, plan };
}
async function loadGroupSkill(ctx) {
    const mod = await import(ctx.groupSkill.reference);
    if (typeof mod.skill !== 'string' || !mod.skill.trim()) {
        throw new Error(`[${AGENT_NAME}] group creation skill unreadable: ${ctx.groupSkill.reference}`);
    }
    return mod.skill;
}
function buildRequirements(plan) {
    const lines = [
        `**Description**: ${plan.description}`,
        '',
        `**Instruction**: ${plan.prompt}`,
        '',
        '**Functional requirements**',
        ...plan.functionalRequirements.map(item => `- ${item}`),
    ];
    if (plan.visualRequirements.length) {
        lines.push('', '**Visual requirements** (fold these in as hierarchy statements, never as values)');
        lines.push(...plan.visualRequirements.map(item => `- ${item}`));
    }
    return lines.join('\n');
}
