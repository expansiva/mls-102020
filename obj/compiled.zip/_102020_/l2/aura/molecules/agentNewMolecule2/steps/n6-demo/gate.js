/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/steps/n6-demo/gate.ts" enhancement="_blank"/>
import { PLAYGROUND_STATE_PLACEHOLDER, PLAYGROUND_STATE_WIDGET, pageHasStateWidget, } from '/_102020_/l2/aura/molecules/shared/moleculeTemplates.js';
export const NM_MIN_DEMO_EXAMPLES = 6;
/**
 * Slot content written as an ATTRIBUTE — `<div slot="Label">` — which does nothing in this library.
 *
 * ⚠️ MEASURED 2026-08-17/18. This project has **no Shadow DOM**, so a molecule reads its slots BY TAG
 * NAME: `moleculeBase.getSlotContent(tag)` is `getSnapshot().querySelector(tag)`, and the mutation
 * observer compares `tagName` against `slotTags`. `<div slot="Label">` matches neither. It renders, it
 * does not crash, and the slot is simply empty.
 *
 * It shipped because the wrong form was INSTRUCTED: this step's prompt gave
 * `<div slot="Label">Revenue</div>` as the example, and two molecules generated on two different days,
 * in two different groups, came out with 68 occurrences of it and zero named tags. Across the 671 index
 * and playground files of the six projects, those two are the ONLY ones — the other 22.903 slot uses
 * are named tags.
 *
 * `slot="name"` is standard practice for web components WITH Shadow DOM, which is exactly why it leaks
 * in. Same shape as the `nothing` sentinel that reappeared in five generations of code: a platform
 * habit arriving in a library that does not use it.
 */
export function findAttributeSlots(html) {
    const names = new Set();
    for (const m of (html || '').matchAll(/slot\s*=\s*['"]([A-Za-z][\w-]*)['"]/g))
        names.add(m[1]);
    return [...names];
}
/**
 * ⚠️ 2026-08-18: this was the SUFFIX, tested with `includes`, so the truncated
 * `<widget-playground-state-102020>` passed — and 5 pages shipped with it. The truncated tag is not a
 * registered element: it renders nothing and every binding on the page is dead. The prose of the
 * message below already spelled the full name, which is how the discrepancy was visible all along.
 * Now the one shared constant, compared AS A TAG.
 */
export const NM_STATE_WIDGET = PLAYGROUND_STATE_WIDGET;
/**
 * The two ways a page's bindings die silently, as one pure check.
 *
 * Extracted 2026-08-18 so i5-playground can run the SAME rule when route E regenerates a page from
 * scratch — that path had no state rule at all and produced 20 bindings with no state behind them.
 * A malformed `stateName` is dropped by `substituteDemoState` without a word, and a binding whose key
 * no example declares renders empty: both are invisible on screen and trivial to check here.
 */
export function demoStateIssues(html, examples) {
    const issues = [];
    const stateKeys = new Set();
    for (const example of examples) {
        for (const entry of example.state || []) {
            const parts = (entry.stateName || '').split('.');
            if (parts.length !== 3 || parts[0] !== 'playground') {
                issues.push({
                    code: 'state_shape',
                    message: `example '${example.name}' has the state name '${entry.stateName}' — it must be 'playground.<exampleKey>.<property>'`,
                });
                continue;
            }
            stateKeys.add(parts[1]);
        }
    }
    const boundKeys = new Set();
    for (const match of (html || '').matchAll(/\{\{\s*playground\.([A-Za-z0-9_$]+)\./g))
        boundKeys.add(match[1]);
    const orphans = [...boundKeys].filter(key => !stateKeys.has(key));
    if (orphans.length) {
        issues.push({
            code: 'state_binding',
            message: `these bindings have no matching example state and would render empty: ${orphans.map(key => `playground.${key}`).join(', ')}`,
        });
    }
    return issues;
}
export function runNm2DemoGate(html, examples, plan, ctx) {
    const issues = [];
    const content = html || '';
    if (!content.trim())
        return [{ code: 'empty', message: 'the demo page came out empty' }];
    if (content.includes('```')) {
        issues.push({ code: 'fence', message: 'the html contains markdown fences — return raw HTML only' });
    }
    // The demo is a FRAGMENT (a playground page inside the Studio), never a full document, and styling
    // comes from Tailwind + the molecule's own sheet — not from an inline <style> or an external link.
    if (/<!DOCTYPE|<html[\s>]|<head[\s>]|<body[\s>]|<style[\s>]|<link[\s>]/i.test(content)) {
        issues.push({
            code: 'document',
            message: 'the demo must be a FRAGMENT, not a full HTML document — remove <!DOCTYPE>/<html>/<head>/<body>/<style>/<link>',
        });
    }
    // Slot content by attribute is inert here — see findAttributeSlots. Named tags or nothing.
    const attributeSlots = findAttributeSlots(content);
    if (attributeSlots.length) {
        issues.push({
            code: 'slot_as_attribute',
            message: `slot content is written as an attribute (${attributeSlots.map(n => `slot="${n}"`).join(', ')}) and this library has NO Shadow DOM — a molecule reads its slots by TAG NAME, so those render empty. Write <${attributeSlots[0]}>…</${attributeSlots[0]}> instead`,
        });
    }
    if (/<script[\s>]/i.test(content)) {
        issues.push({ code: 'script', message: 'the demo page must not contain <script> tags' });
    }
    if (/<footer[\s>]/i.test(content)) {
        issues.push({ code: 'footer', message: 'the demo must not add a <footer>/attribution — emit only the playground structure (container, header, state widget, demo cards)' });
    }
    if (!pageHasStateWidget(content)) {
        issues.push({
            code: 'state_widget',
            message: `the demo must include the playground state widget before the demo cards, written with its REGISTERED tag: <${NM_STATE_WIDGET} state='${PLAYGROUND_STATE_PLACEHOLDER}'></${NM_STATE_WIDGET}>. A shortened tag is not a registered element — it renders nothing and every {{playground.*}} binding dies`,
        });
    }
    if (!content.includes(PLAYGROUND_STATE_PLACEHOLDER)) {
        issues.push({
            code: 'state_placeholder',
            message: `the state widget must carry state='${PLAYGROUND_STATE_PLACEHOLDER}' — code replaces that literal token with the real state after generation`,
        });
    }
    if (examples.length < NM_MIN_DEMO_EXAMPLES) {
        issues.push({
            code: 'examples_count',
            message: `at least ${NM_MIN_DEMO_EXAMPLES} distinct examples are required (found ${examples.length})`,
        });
    }
    // Every declared example must actually appear on the page. Floor of 6 because that is the library's
    // minimum, so a page with 6 examples but 2 cards is caught.
    const tagUses = content.split(`<${plan.tag}`).length - 1;
    const expected = Math.max(NM_MIN_DEMO_EXAMPLES, examples.length);
    if (tagUses < expected) {
        issues.push({
            code: 'tag_uses',
            message: `<${plan.tag}> must appear at least once per declared example (${expected} expected, found ${tagUses})`,
        });
    }
    issues.push(...demoStateIssues(content, examples));
    // A themed project's demo page must provide the theme's background contract — glass is invisible on
    // white. With no theme there is no such requirement (the library's pages use a neutral Tailwind
    // background), and nothing theme-related may appear at all.
    if (ctx.theme.present && ctx.theme.info) {
        const backgroundCss = ctx.theme.info.background.css.replace(/\s+/g, ' ').replace(/;$/, '').trim();
        const normalized = content.replace(/\s+/g, ' ');
        if (backgroundCss && !normalized.includes(backgroundCss)) {
            issues.push({
                code: 'background',
                message: `the page container must carry the theme background exactly: '${ctx.theme.info.background.css}'`,
            });
        }
    }
    return issues;
}
