/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMolecule2/steps/n1-bootstrap/agentNm2Bootstrap.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { appendLongTermMemory } from '/_102027_/l2/aiAgentHelper.js';
import { skills as skillList } from '/_102020_/l2/aura/molecules/skills/index';
import { NM_AGENT_FOLDER, nmBaseFile, nmContextFileInfo, nmDestProject, nmThemeExists, nmTraceFileInfo, readStorText, toDisplayPath, writeJsonArtifact, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { NM_BASE_CLASS, NM_BASE_IMPORT } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmTypes.js';
import { moleculeContextSummary } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmContext.js';
import { nmDoneAnchor, nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { contractFingerprint } from '/_102020_/l2/aura/molecules/shared/contractFingerprint.js';
import { loadVTheme } from '/_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vTheme.js';
import { runNmBootstrapGate } from '/_102020_/l2/aura/molecules/agentNewMolecule2/steps/n1-bootstrap/gate.js';
import { getNmInput, getNmRootPlan, getNmRunKey } from '/_102020_/l2/aura/molecules/agentNewMolecule2/agentNewMolecule2.js';
const AGENT_NAME = 'agentNm2Bootstrap';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NM_AGENT_FOLDER}/steps/n1-bootstrap`,
        agentDescription: 'n1-bootstrap — deterministic context assembly for the New Molecule 2 pipeline',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(step.prompt);
    const runKey = getNmRunKey(context, parsedArgs.runKey);
    const input = getNmInput(context);
    const rootPlan = getNmRootPlan(context);
    const destProject = nmDestProject();
    const groupEntry = skillList.find(item => item.name.toLowerCase() === rootPlan.group.toLowerCase());
    const groupCanonical = groupEntry?.name || rootPlan.group;
    const groupFolder = groupCanonical.toLowerCase();
    // The creation skill is only PROBED here (fail fast); each later step imports it from the
    // reference in context.json, so the skill text never bloats the artifact.
    const creationProbe = await probeSkill(groupEntry?.skillReference);
    const { loaded: groupSkillLoaded, error: groupSkillError } = creationProbe;
    // Probed, never gated — see traceContracts.
    const usageProbe = await probeSkill(groupEntry?.skillUsageReference);
    const baseSource = await readStorText(nmBaseFile(), false);
    // A theme is OPTIONAL. Absence => neutral molecule, exactly like the old flow; presence with a
    // broken contract => fatal. loadVTheme reports absence as an error (the Variant requires a
    // theme), so existence is checked first to keep the two cases apart.
    const themePresent = nmThemeExists();
    const themeLoad = themePresent ? await loadVTheme(destProject) : { theme: null, errors: [] };
    const ctx = {
        schemaVersion: 1,
        createdAt: new Date().toISOString(),
        runKey,
        userPrompt: input.prompt,
        userLanguage: rootPlan.userLanguage,
        destination: { project: destProject, groupFolder, groupCanonical },
        groupSkill: {
            description: groupEntry?.description || '',
            reference: groupEntry?.skillReference || '',
            usageReference: groupEntry?.skillUsageReference || '',
        },
        base: {
            reference: `_102033_/l2/${nmBaseFile().shortName}.ts`,
            className: NM_BASE_CLASS,
            importPath: NM_BASE_IMPORT,
        },
        theme: {
            present: themePresent,
            reference: themePresent ? `_${destProject}_/l2/skills/theme.ts` : null,
            info: themeLoad.theme?.themeInfo || null,
        },
    };
    const gateInputs = {
        group: rootPlan.group,
        known: skillList,
        groupSkillLoaded,
        groupSkillError,
        baseFound: !!baseSource.trim(),
        themePresent,
        themeErrors: themeLoad.errors,
        destProject,
        context: ctx,
    };
    const issues = runNmBootstrapGate(gateInputs);
    if (issues.length) {
        const message = issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
    await writeJsonArtifact(nmContextFileInfo(runKey), ctx);
    await appendLongTermMemory(context, { runKey });
    await writeJsonArtifact(nmTraceFileInfo(runKey, 'n1-bootstrap', 1), {
        savedAt: ctx.createdAt,
        planId: 'n1-bootstrap',
        summary: moleculeContextSummary(ctx),
        themePresent,
        contracts: traceContracts(groupEntry?.skillReference || '', creationProbe, groupEntry?.skillUsageReference || '', usageProbe),
    });
    const summary = moleculeContextSummary(ctx);
    return [
        nmResultStepIntent(context, parentStep, {
            planId: nmDoneAnchor('n1-bootstrap'),
            dependsOn: [],
            stepTitle: summary,
            result: { contextFile: toDisplayPath(nmContextFileInfo(runKey)), runKey, themePresent },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary, 'input_output'),
    ];
}
async function probeSkill(reference) {
    if (!reference)
        return { loaded: false, error: 'no skillReference declared' };
    try {
        const mod = await import(reference);
        if (typeof mod.skill !== 'string' || !mod.skill.trim())
            return { loaded: false, error: `${reference} exports no non-empty 'skill'` };
        return { loaded: true, print: contractFingerprint(mod.skill) };
    }
    catch (error) {
        return { loaded: false, error: error instanceof Error ? error.message : String(error) };
    }
}
// Both contracts, for the trace. The CREATION one gates this step (n2-plan/n4-render read it); the
// USAGE one does not — n6-demo and n7-index read it much later, and a run that only fails there is
// worth finishing. Recording it here is what makes the failure diagnosable afterwards instead of
// having to guess which text the playground was generated from.
function traceContracts(creationReference, creation, usageReference, usage) {
    const entry = (reference, probe) => ({
        reference,
        loaded: probe.loaded,
        ...(probe.print ? { chars: probe.print.chars, hash: probe.print.hash } : {}),
        ...(probe.error ? { error: probe.error } : {}),
    });
    return { creation: entry(creationReference, creation), usage: entry(usageReference, usage) };
}
