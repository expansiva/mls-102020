/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vContext.ts" enhancement="_blank"/>
export function variantContextSummary(ctx) {
    return `${ctx.origin.tag} -> ${ctx.variant.tag} (${ctx.theme.info.name}${ctx.origin.portal ? ', portal' : ''}${ctx.example.coldStart ? ', COLD START' : ''})`;
}
