/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vTheme.ts" enhancement="_blank"/>
export const V_THEME_SKILL_SECTIONS = [
    '## 1. Visual Signature',
    '## 2. Tokens',
    '## 3. Canonical CSS Rules',
]; // '## 4. Theme Nuances' is optional by contract
export function validateVThemeModule(mod) {
    const errors = [];
    const record = (typeof mod === 'object' && mod !== null) ? mod : null;
    if (!record)
        return { theme: null, errors: ['theme module is not an object'] };
    const info = record.themeInfo;
    if (!info || typeof info !== 'object')
        errors.push('missing export themeInfo');
    else {
        for (const field of ['name', 'suffix', 'displayName', 'description']) {
            if (typeof info[field] !== 'string' || !info[field].trim())
                errors.push(`themeInfo.${field} missing or empty`);
        }
        if (typeof info.suffix === 'string' && !info.suffix.startsWith('-'))
            errors.push(`themeInfo.suffix must start with '-' (got '${info.suffix}')`);
        const bg = info.background;
        if (!bg || typeof bg !== 'object')
            errors.push('themeInfo.background missing');
        else {
            if (!['light', 'dark', 'image'].includes(String(bg.kind)))
                errors.push(`themeInfo.background.kind invalid: ${String(bg.kind)}`);
            if (typeof bg.css !== 'string' || !bg.css.trim())
                errors.push('themeInfo.background.css missing');
        }
    }
    const skill = record.skill;
    if (typeof skill !== 'string' || !skill.trim())
        errors.push('missing export skill');
    else {
        for (const section of V_THEME_SKILL_SECTIONS) {
            if (!skill.includes(section))
                errors.push(`skill missing mandatory section "${section}"`);
        }
    }
    const examples = record.examples;
    if (examples !== undefined && !Array.isArray(examples))
        errors.push('export examples must be an array when present');
    const normalizedExamples = [];
    if (Array.isArray(examples)) {
        examples.forEach((item, index) => {
            const entry = (typeof item === 'object' && item !== null) ? item : null;
            if (!entry || !['simple', 'portal'].includes(String(entry.pattern)) || typeof entry.ref !== 'string' || !entry.ref.trim()) {
                errors.push(`examples[${index}] must be { pattern: 'simple'|'portal', ref: string }`);
                return;
            }
            normalizedExamples.push({ pattern: entry.pattern, ref: entry.ref });
        });
    }
    if (errors.length)
        return { theme: null, errors };
    return {
        theme: {
            themeInfo: info,
            skill: skill,
            examples: normalizedExamples,
        },
        errors: [],
    };
}
// Loads the destination project's l2/skills/theme.ts. Returns errors instead of
// throwing so the bootstrap gate can report readable admission failures.
export async function loadVTheme(project) {
    const path = `/_${project}_/l2/skills/theme.js`;
    let mod;
    try {
        mod = await import(path);
    }
    catch {
        return { theme: null, errors: [`project ${project} has no theme skill (expected l2/skills/theme.ts) — this agent only runs inside a themed project`] };
    }
    return validateVThemeModule(mod);
}
export function pascalCaseThemeName(name) {
    return name.replace(/(^|[-_ ])([a-z0-9])/g, (_m, _sep, ch) => ch.toUpperCase());
}
// The theme's Visual Signature section ('## 1 ..' up to '## 2. Tokens') — the
// chrome-styling guidance shared by the demo (v5) and the group index (v4).
// Falls back to the whole skill when the sections are absent.
export function extractVisualSignature(skill) {
    const start = skill.indexOf('## 1. Visual Signature');
    const end = skill.indexOf('## 2. Tokens');
    if (start >= 0 && end > start)
        return skill.slice(start, end).trim();
    return skill.trim();
}
// Loads the destination theme skill and returns its Visual Signature section.
export async function loadThemeSignature(project) {
    const mod = await import(`/_${project}_/l2/skills/theme.js`);
    return extractVisualSignature(typeof mod.skill === 'string' ? mod.skill : '');
}
