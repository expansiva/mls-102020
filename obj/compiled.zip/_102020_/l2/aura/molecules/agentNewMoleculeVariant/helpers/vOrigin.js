/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vOrigin.ts" enhancement="_blank"/>
// Accepts '_102040_/l2/molecules/<group>/<shortName>' with optional leading '/'
// and optional '.ts' suffix.
export function parseOriginRef(page) {
    const cleaned = (page || '').trim().replace(/^\//, '').replace(/\.ts$/, '');
    const match = cleaned.match(/^_(\d+)_\/l2\/molecules\/([a-z0-9]+)\/([a-z0-9-]+)$/);
    if (!match) {
        return { ref: null, error: `invalid origin reference '${page}' — expected '_<project>_/l2/molecules/<group>/<molecule>' (a molecule of a dependency project)` };
    }
    const project = Number(match[1]);
    const group = match[2];
    const shortName = match[3];
    return {
        ref: {
            project,
            group,
            shortName,
            tag: `${group}--${shortName}`,
            importPath: `/_${project}_/l2/molecules/${group}/${shortName}.js`,
        },
    };
}
export function detectPortal(originTs) {
    return /getPortalTemplate\s*\(|portalWidgetName/.test(originTs);
}
export function extractOriginClassName(originTs) {
    const match = originTs.match(/export\s+class\s+([A-Za-z0-9_]+)/);
    return match ? match[1] : null;
}
// The ml-* semantic class inventory: union of occurrences in the origin .ts
// (emitted by render()) and .less (styled selectors). This is the discipline
// gate input AND the v3-less subset check universe.
export function extractMlInventory(originTs, originLess) {
    const found = new Set();
    const pattern = /(?<![\w-])ml-[a-z][a-z0-9-]*/g;
    for (const source of [originTs, originLess]) {
        for (const match of source.matchAll(pattern))
            found.add(match[0]);
    }
    return Array.from(found).sort();
}
// ml-* classes REFERENCED as selectors in a generated .less.
export function extractMlClassesFromLess(less) {
    const found = new Set();
    for (const match of less.matchAll(/\.(ml-[a-z][a-z0-9-]*)/g))
        found.add(match[1]);
    return Array.from(found).sort();
}
// 'ml-button-standard' -> 'BUTTON STANDARD' (shell header title convention — fase 0 finding).
export function toShellTitle(shortName) {
    return shortName.replace(/^ml-/, '').split('-').join(' ').toUpperCase();
}
