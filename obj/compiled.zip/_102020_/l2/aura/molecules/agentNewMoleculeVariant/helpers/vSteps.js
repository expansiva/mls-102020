/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vSteps.ts" enhancement="_blank"/>
// Task-step intent builders + LLM tool plumbing for the variant pipeline.
// Deliberately self-contained (mirrors agentNewSolution/helpers/nsSteps.ts and
// nsLlm.ts) so this agent has zero coupling to another agent's folder.
// Orchestration rules honored (mls-base/skills/collab_messages.md):
// - parents auto-complete per intent — add the next OPEN step before any
//   completed result / update-status in the same batch;
// - downstream steps depend ONLY on 'vN-done' anchors (retries have dynamic planIds).
export const V_PLAN_IDS = ['v1-bootstrap', 'v2-shell', 'v3-less', 'v4-index', 'v5-demo', 'v6-summary'];
export function vDoneAnchor(planId) {
    return `${planId.split('-')[0]}-done`; // 'v3-less' -> 'v3-done'
}
export function vUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    // traceMsg is accepted by the backend (production usage: nsSteps.ts) but the
    // local mls.d.ts is behind — hence the assertion instead of a typed literal.
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        ...(traceMsg ? { traceMsg } : {}),
        ...(cleaner ? { cleaner } : {}),
    };
    return intent;
}
export function vResultStepIntent(context, parentStep, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle: args.stepTitle,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify(args.result, null, 2),
            planning: { planId: args.planId, dependsOn: args.dependsOn, executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
// Dynamic agent step (retries). Status 'waiting_human_input' == runs immediately.
export function vAgentStepIntent(context, parentStep, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: args.stepTitle,
            status: args.status || 'waiting_human_input',
            nextSteps: [],
            agentName: args.agentName,
            prompt: JSON.stringify(args.prompt),
            rags: [],
            planning: { planId: args.planId, dependsOn: args.dependsOn || [], executionMode: 'sequential', executionHost: 'client' },
        },
    };
}
export function vParseStepArgs(value) {
    const parsed = parseMaybeJsonLocal(value);
    if (typeof parsed !== 'object' || parsed === null)
        return {};
    const record = parsed;
    return {
        planId: typeof record.planId === 'string' ? record.planId : undefined,
        retryAttempt: typeof record.retryAttempt === 'number' ? record.retryAttempt : undefined,
        retryContext: typeof record.retryContext === 'string' ? record.retryContext : undefined,
    };
}
export { createVToolSchema, buildVToolInstruction, extractVToolOutput } from '/_102020_/l2/aura/molecules/shared/llmTool.js';
// Local JSON parse kept for vParseStepArgs (the tool plumbing now lives in shared/llmTool).
function parseMaybeJsonLocal(value) {
    if (typeof value !== 'string')
        return value;
    const trimmed = value.trim();
    if (!trimmed)
        return value;
    if (!trimmed.startsWith('{') && !trimmed.startsWith('['))
        return value;
    try {
        return JSON.parse(trimmed);
    }
    catch {
        return value;
    }
}
