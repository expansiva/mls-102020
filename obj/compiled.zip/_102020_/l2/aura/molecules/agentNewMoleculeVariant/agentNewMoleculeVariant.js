/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/agentNewMoleculeVariant.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { V_AGENT_FOLDER, isRecord, parseMaybeJson } from '/_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vFs.js';
import { normalizeOriginPage, parseVariantEntry } from '/_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vOrigin.js';
import { V_PLAN_IDS, vDoneAnchor, vUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vSteps.js';
const AGENT_NAME = 'agentNewMoleculeVariant';
const STEP_AGENTS = {
    'v1-bootstrap': 'agentVariantBootstrap',
    'v2-shell': 'agentVariantShell',
    'v3-less': 'agentVariantLess',
    'v4-index': 'agentVariantIndex',
    'v5-demo': 'agentVariantDemo',
    'v6-summary': 'agentVariantSummary',
};
// The preview sends `prompt` = the agent mention (e.g. "@@NewMoleculeVariant"), NOT user
// notes. Strip any leading mention so it never pollutes the LLM notes. (The mention paths
// go through vOrigin.parseVariantEntry, which applies the same rule; this covers test mode.)
function cleanNotes(prompt) {
    const raw = (prompt || '').trim();
    if (!raw || raw.startsWith('@@'))
        return '';
    return raw;
}
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: V_AGENT_FOLDER,
        agentDescription: 'Creates a themed variant (Strategy D, by inheritance) of an existing molecule in the current themed project',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
        scope: ['l2_preview'],
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error(`[${AGENT_NAME}] invalid prompt — expected { page, prompt }`);
    let page;
    let notes;
    if (context.isTest) {
        const testData = JSON.parse(userPrompt);
        if (!testData.fileReference)
            throw new Error(`[${AGENT_NAME}] invalid test prompt: missing fileReference`);
        page = testData.fileReference.replace(/\.ts$/, '');
        notes = cleanNotes(testData.prompt);
    }
    else {
        // Three entry shapes, one parser (helpers/vOrigin.parseVariantEntry): the preview
        // payload ({ fullName, page, prompt, position }), a typed object mention and a typed
        // BARE reference — the last one used to die inside safeParseArgs, which throws on
        // anything that is not an object literal.
        const entry = parseVariantEntry(userPrompt, agent.agentName, raw => mls.common.safeParseArgs(raw));
        if (!entry.page)
            throw new Error(`[${AGENT_NAME}] invalid prompt: no origin molecule reference found — mention it as '@@${agent.agentName} _102040_/l2/molecules/<group>/<molecule>' or as { page: '<ref>' }`);
        page = entry.page;
        notes = entry.notes;
    }
    // Normalize to the canonical ref once at entry, so the rootPlan classifier and
    // task memory hold the clean form (preview sends /l2/-less page or spaced fullName).
    page = normalizeOriginPage(page);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: rootPlanSystemPrompt },
                { type: 'human', content: JSON.stringify({ page, notes }) },
            ],
            taskTitle: `Molecule variant: ${page.split('/').pop()}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { flowName: AGENT_NAME, page, notes },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const plan = normalizeRootPlan(step.interaction?.payload?.[0]);
        if (!plan.validInput) {
            return [vUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', plan.invalidReason || 'Invalid input')];
        }
        const intents = [];
        let previous = null;
        for (const planId of V_PLAN_IDS) {
            intents.push({
                type: 'add-step',
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: step.stepId,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    stepTitle: plan.titles[planId] || planId,
                    status: previous ? 'waiting_dependency' : 'waiting_human_input',
                    nextSteps: [],
                    agentName: STEP_AGENTS[planId],
                    prompt: JSON.stringify({ planId }),
                    rags: [],
                    planning: {
                        planId,
                        dependsOn: previous ? [vDoneAnchor(previous)] : [],
                        executionMode: 'sequential',
                        executionHost: 'client',
                    },
                },
            });
            previous = planId;
        }
        return intents;
    }
    catch (error) {
        return [vUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
// ---- shared readers for the step agents ----
export function getVRootPlan(context) {
    if (!context.task)
        throw new Error('[getVRootPlan] task invalid');
    const root = getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.type === 'agent' && item.agentName === AGENT_NAME);
    const plan = normalizeRootPlan(root?.interaction?.payload?.[0]);
    return plan;
}
export function getVInput(context) {
    const memory = context.task?.iaCompressed?.longMemory || {};
    const page = typeof memory.page === 'string' ? memory.page : '';
    const notes = typeof memory.notes === 'string' ? memory.notes : '';
    if (!page)
        throw new Error('[getVInput] missing origin page in task memory');
    return { page, notes };
}
// Steps v2..v6 locate the context artifact through the task memory published by v1-bootstrap.
export function getVariantShortName(context) {
    const memory = context.task?.iaCompressed?.longMemory || {};
    const shortName = typeof memory.variantShortName === 'string' ? memory.variantShortName : '';
    if (!shortName)
        throw new Error('[getVariantShortName] v1-bootstrap did not publish variantShortName');
    return shortName;
}
function normalizeRootPlan(payload) {
    const parsed = parseMaybeJson(payload);
    const record = isRecord(parsed) ? parsed : {};
    const result = isRecord(parseMaybeJson(record.result)) ? parseMaybeJson(record.result) : {};
    const titlesRaw = isRecord(result.titles) ? result.titles : {};
    const titles = {};
    for (const planId of V_PLAN_IDS) {
        titles[planId] = typeof titlesRaw[planId] === 'string' ? titlesRaw[planId] : planId;
    }
    return {
        validInput: result.validInput !== false,
        invalidReason: typeof result.invalidReason === 'string' ? result.invalidReason : undefined,
        userLanguage: typeof result.userLanguage === 'string' ? result.userLanguage : 'pt',
        titles,
    };
}
const rootPlanSystemPrompt = `
<!-- modelType: classifier -->

You are the root planner of a pipeline that creates a THEMED VARIANT of an existing web-component molecule.
The human message is a JSON: { "page": "<origin molecule reference>", "notes": "<optional user notes>" }.

Tasks:
1. validInput: false ONLY when page is clearly not a molecule reference (expected shape: _<digits>_/l2/molecules/<group>/<name>). Everything else is validated later by deterministic code — do NOT over-reject.
2. userLanguage: detect from the notes ('pt' | 'en' | ...); default 'pt' when notes are empty or ambiguous.
3. titles: SHORT step titles in the detected language for each planId:
   v1-bootstrap (analyze origin and theme), v2-shell (create inherited shell), v3-less (generate theme stylesheet), v4-index (register in group index), v5-demo (create demo page), v6-summary (final summary).

## Output format
You must return the object strictly as JSON
export type Output = {
  type: 'flexible';
  result: {
    validInput: boolean;
    invalidReason?: string;
    userLanguage: string;
    titles: {
      'v1-bootstrap': string;
      'v2-shell': string;
      'v3-less': string;
      'v4-index': string;
      'v5-demo': string;
      'v6-summary': string;
    };
  };
};
`;
//#endregion
