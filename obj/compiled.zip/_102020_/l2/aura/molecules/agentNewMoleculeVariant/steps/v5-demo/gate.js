/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/steps/v5-demo/gate.ts" enhancement="_blank"/>
export function runDemoGate(html, ctx) {
    const issues = [];
    const content = html || '';
    if (!content.trim())
        return [{ code: 'empty', message: 'html is empty' }];
    if (content.includes('```'))
        issues.push({ code: 'fence', message: 'html contains markdown fences — return raw HTML only' });
    // M1: the demo must be a FRAGMENT (playground page), never a full document.
    const documentTags = /<!DOCTYPE|<html[\s>]|<head[\s>]|<body[\s>]|<style[\s>]|<link[\s>]/i;
    if (documentTags.test(content)) {
        issues.push({ code: 'document', message: 'demo must be a FRAGMENT, not a full HTML document — remove <!DOCTYPE>/<html>/<head>/<body>/<style>/<link> (styling comes from Tailwind + the theme, not inline <style> or external <link>)' });
    }
    if (/<script[\s>]/i.test(content))
        issues.push({ code: 'script', message: 'demo page must not contain <script> tags' });
    // P2: no extra chrome beyond the playground structure (the LLM added an
    // attribution <footer> inconsistently — not part of the contract).
    if (/<footer[\s>]/i.test(content))
        issues.push({ code: 'footer', message: 'demo must not add a <footer>/attribution — emit only the playground structure (container, header, state widget, demo cards)' });
    const tagUses = content.split(`<${ctx.variant.tag}`).length - 1;
    if (tagUses < 3) {
        issues.push({ code: 'tag_uses', message: `the variant tag <${ctx.variant.tag}> must be exercised at least 3 times (found ${tagUses})` });
    }
    // M1: the playground state widget must be present (both tag forms share this
    // substring), and the substitution placeholder must survive when there are
    // {{playground.*}} bindings to feed — otherwise the bindings render dead.
    if (!content.includes('widget-playground-state-102020')) {
        issues.push({ code: 'state_widget', message: "demo must include the playground state widget 'aura--molecules--playground--widget-playground-state-102020' before the demos" });
    }
    if (/\{\{playground\./.test(content) && !content.includes('playgroundDinamicState')) {
        issues.push({ code: 'state_placeholder', message: "the state widget must carry state='playgroundDinamicState' (the literal token is replaced with the real state after generation) — {{playground.*}} bindings need it" });
    }
    // The page container must provide the theme's background contract
    // (e.g. glass is invisible on white).
    const bgCss = ctx.theme.info.background.css.replace(/\s+/g, ' ').replace(/;$/, '').trim();
    const normalized = content.replace(/\s+/g, ' ');
    if (bgCss && !normalized.includes(bgCss)) {
        issues.push({ code: 'background', message: `the page container must carry the theme background exactly: '${ctx.theme.info.background.css}'` });
    }
    return issues;
}
