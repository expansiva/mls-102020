/// <mls fileReference="_102020_/l2/aura/molecules/agentNewMoleculeVariant/steps/v4-index/gate.ts" enhancement="_blank"/>
import { groupIndexTag } from '/_102020_/l2/aura/molecules/agentNewMoleculeVariant/helpers/vTemplates.js';
export function runIndexGate(indexTs, ctx) {
    const issues = [];
    if (!indexTs.trim()) {
        issues.push({ code: 'no_content', message: 'index.ts is empty' });
        return issues;
    }
    if (indexTs.includes('```')) {
        issues.push({ code: 'fenced', message: 'index.ts must be raw TypeScript, without markdown fences' });
    }
    const headerRef = `_${ctx.theme.project}_/l2/molecules/${ctx.variant.group}/index.ts`;
    if (!indexTs.includes(headerRef)) {
        issues.push({ code: 'header', message: `index.ts header must reference ${headerRef}` });
    }
    const indexTag = groupIndexTag(ctx);
    if (!indexTs.includes(`@customElement('${indexTag}')`)) {
        issues.push({ code: 'custom_element', message: `index.ts must declare @customElement('${indexTag}')` });
    }
    // The molecule this run created must be registered and shown in the showcase.
    if (!indexTs.includes(`/l2/molecules/${ctx.variant.group}/${ctx.variant.shortName}'`)) {
        issues.push({ code: 'variant_import', message: `index.ts must import the variant module '${ctx.variant.shortName}'` });
    }
    if (!indexTs.includes(ctx.variant.tag)) {
        issues.push({ code: 'variant_tag', message: `index.ts must reference the variant tag ${ctx.variant.tag}` });
    }
    return issues;
}
