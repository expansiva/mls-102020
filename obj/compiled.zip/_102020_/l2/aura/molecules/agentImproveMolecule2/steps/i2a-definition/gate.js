/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i2a-definition/gate.ts" enhancement="_blank"/>
// Gate for the definition checkpoint (pure — unit-testable).
//
// It runs TWICE, like i4-inherit's: once on the MODEL's proposal before the widget mounts, once on
// what the HUMAN confirmed, because that second one is what i3-edit is instructed by.
//
// WHAT THIS GATE CAN CHECK, and it is more than the routing gates can. A definition change is a
// movement of the measured surface, and the surface is measured — so "you propose adding a slot that
// already exists" and "you propose removing an event the molecule does not have" are decidable here,
// not judgement. That is the whole reason this step is cheap to make safe: route A is the first
// route that changes what the molecule PROMISES, and every promise it moves is checked against what
// the molecule declares today.
import { groupVocabulary } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imSurface.js';
import { imGateFail, imGateOk, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
const KINDS = ['slot', 'property', 'event'];
const OPS = ['add', 'remove', 'rename'];
function issue(code, message) {
    return `${code}: ${message}`;
}
/** The names the molecule declares today, for the kind this change is about. */
function existing(current, kind) {
    if (kind === 'slot')
        return current.slots;
    if (kind === 'property')
        return current.properties;
    if (kind === 'event')
        return current.events;
    return [];
}
export function runImDefinitionGate(inputs) {
    const changes = inputs.answer.changes || [];
    const errors = [];
    // BLOCKED is a valid answer with no changes: the request needs a name the group does not declare,
    // and that file is edited by hand. It must be accepted, or the model is punished for being right and
    // escalates — measured 2026-08-17, where the escalation was "remove the Label slot".
    if (inputs.answer.blocked) {
        if (changes.length) {
            return imGateFail(issue('blocked_with_changes', 'the answer is that the group contract has to change first, and it also names changes — one or the other'));
        }
        if (!(inputs.answer.reason || '').trim()) {
            return imGateFail(issue('reason_missing', 'a blocked answer IS the answer the user reads: say which name the group lacks and that its contract is edited by hand'));
        }
        return imGateOk();
    }
    // Route A exists to move the public surface. A checkpoint that moves nothing and is not blocked is
    // not a definition change, and the run would go on to instruct i3-edit with an empty list.
    if (!changes.length) {
        return imGateFail(issue('no_change', 'a definition change that names nothing is not a definition change — say which slot, property or event moves, or set `blocked` when the group contract is what has to change, or this request is a route B edit'));
    }
    const seen = new Set();
    changes.forEach((change, index) => {
        const at = `change ${index + 1}`;
        const kind = String(change.kind || '').trim();
        const op = String(change.op || '').trim();
        const name = String(change.name || '').trim();
        const previousName = String(change.previousName || '').trim();
        if (!KINDS.includes(kind)) {
            errors.push(issue('kind_invalid', `${at}: '${kind}' is not one of ${KINDS.join(', ')} — those three ARE the public surface`));
            return;
        }
        if (!OPS.includes(op)) {
            errors.push(issue('op_invalid', `${at}: '${op}' is not one of ${OPS.join(', ')}`));
            return;
        }
        if (!name) {
            errors.push(issue('name_missing', `${at}: the ${kind} being ${op}d has no name`));
            return;
        }
        if (!String(change.purpose || '').trim()) {
            // The purpose is not decoration: it is what the human weighs at the checkpoint and the only
            // instruction i3-edit gets about what the new contract sentence should say.
            errors.push(issue('purpose_missing', `${at}: say in one line what \`${name}\` is for — the human reads it and i3-edit writes the contract from it`));
        }
        const key = `${kind}:${name}`;
        if (seen.has(key))
            errors.push(issue('duplicate', `${at}: ${kind} \`${name}\` is named twice`));
        seen.add(key);
        // The group's vocabulary bounds what may be added at all: widening the group is manual work.
        if ((op === 'add' || op === 'rename') && inputs.groupSkill.trim() && !groupVocabulary(inputs.groupSkill).has(name)) {
            errors.push(issue('not_in_group', `${at}: the group contract does not declare a ${kind} called \`${name}\`, and this agent never widens a group — that file is edited by hand. Either use the name the group already has, exactly (it is case-sensitive), or the group contract has to change first`));
        }
        const declared = existing(inputs.current, kind);
        if (op === 'add' && declared.includes(name)) {
            errors.push(issue('already_exists', `${at}: ${kind} \`${name}\` already exists in this molecule — adding it changes nothing. If it exists and does not work, that is a defect, and defects are route B`));
        }
        // REMOVING something the GROUP declares makes this molecule non-conformant, and the group contract
        // is edited by hand. Measured 2026-08-17: refused the correct "blocked" answer and the retry
        // proposed removing the group's `Label` slot — which the gate accepted. It must not.
        if (op === 'remove' && inputs.groupSkill.trim() && groupVocabulary(inputs.groupSkill).has(name)) {
            errors.push(issue('group_declares_it', `${at}: the group contract declares the ${kind} \`${name}\`, so a molecule of this group is expected to offer it — dropping it here makes this one the odd molecule out. If it really should go, the group contract changes first, by hand`));
        }
        if ((op === 'remove' || op === 'rename') && !declared.includes(op === 'rename' ? previousName : name)) {
            const missing = op === 'rename' ? previousName : name;
            errors.push(issue('not_declared', `${at}: ${kind} \`${missing || '(unnamed)'}\` is not declared by this molecule — it declares ${declared.length ? declared.join(', ') : '(none)'}`));
        }
        if (op === 'rename') {
            if (!previousName)
                errors.push(issue('previous_missing', `${at}: a rename needs the name it had before`));
            else if (previousName === name)
                errors.push(issue('rename_noop', `${at}: \`${name}\` is renamed to itself`));
        }
        if (op !== 'rename' && previousName) {
            errors.push(issue('previous_off_op', `${at}: a previous name ('${previousName}') was given on '${op}' — only a rename has one`));
        }
    });
    // The proposal arrives pre-selected in the widget, so an unexplained one is a nudge with no
    // argument. The human's own confirmation needs no justification.
    if (inputs.fromModel && !(inputs.answer.reason || '').trim()) {
        errors.push(issue('reason_missing', 'the proposal arrives pre-selected in the widget and must say why the definition has to move, in the user\'s language'));
    }
    return errors.length ? imGateFail(...errors) : imGateOk();
}
