/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i4-inherit/widgetInheritChoiceLogic.ts" enhancement="_blank"/>
export function emptyInheritData() {
    return { where: 'less', member: '' };
}
/**
 * Changing the choice clears the member unless the new choice is 'override'.
 *
 * Without this, picking 'override', selecting `render`, then switching to 'less' would submit
 * `{ where: 'less', member: 'render' }` — the gate would pass it and inherit.json would record a
 * member nobody chose.
 */
export function applyInheritWhere(data, where) {
    return { where, member: where === 'override' ? data.member : '' };
}
export function applyInheritMember(data, member) {
    return { ...data, where: 'override', member };
}
/** True when overriding this member forfeits the whole parent render, not just a piece of it. */
export function isExpensiveOverride(member) {
    return member === 'render';
}
/** Reasons the human cannot confirm yet, in the widget's own words. */
export function inheritBlockingIssues(data, value) {
    const issues = [];
    if (data.where === 'less' && !value.hasLess) {
        issues.push('no_less');
    }
    if (data.where === 'override') {
        if (!data.member.trim())
            issues.push('no_member');
        else if (value.overridableMembers.length && !value.overridableMembers.some(m => m.name === data.member)) {
            issues.push('unknown_member');
        }
    }
    return issues;
}
export function canConfirmInherit(data, value) {
    return inheritBlockingIssues(data, value).length === 0;
}
export function buildInheritResult(data, action) {
    return {
        where: data.where,
        member: data.where === 'override' ? data.member.trim() : '',
        action,
    };
}
/**
 * Members offered for override, with the ones the shell already declares marked.
 *
 * They are not removed: seeing that `portalWidgetName` is already overridden is what tells the
 * user the shell has a local answer to a related question, and re-choosing it is legitimate.
 */
export function offerableMembers(value) {
    return value.overridableMembers.map(member => ({
        ...member,
        alreadyOverridden: value.ownMembers.includes(member.name),
    }));
}
/**
 * The unreachable members, capped for display.
 *
 * Capped because a parent with an i18n block declares several module constants and the list would
 * bury the picker; the first names are the ones a request is usually about. `hiddenCount` is shown
 * rather than dropped — "and 4 more" keeps the list honest about being partial.
 */
export function unreachableForDisplay(value, limit = 6) {
    const all = value.unreachableMembers || [];
    return { shown: all.slice(0, limit), hiddenCount: Math.max(0, all.length - limit) };
}
