/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i4-inherit/widgetInheritChoiceLogic.ts" enhancement="_blank"/>
import { isCapableMember } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imInherit.js';
export function emptyInheritData() {
    return { where: 'less', member: '' };
}
/**
 * Changing the choice clears the member unless the new choice is 'override'.
 *
 * Without this, picking 'override', selecting `render`, then switching to 'less' would submit
 * `{ where: 'less', member: 'render' }` — the gate would pass it and inherit.json would record a
 * member nobody chose.
 */
export function applyInheritWhere(data, where) {
    return { where, member: where === 'override' ? data.member : '' };
}
export function applyInheritMember(data, member) {
    return { ...data, where: 'override', member };
}
/** True when overriding this member forfeits the whole parent render, not just a piece of it. */
export function isExpensiveOverride(member) {
    return member === 'render';
}
/**
 * Which message set the widget's own chrome uses.
 *
 * ⚠️ Measured 2026-08-14: with `userLanguage: 'pt'` in the payload, the cards rendered in English
 * beside a title and a reason in Portuguese — the model's text obeyed the run and the widget's did
 * not. The base `getMessageKey` reads `document.documentElement.lang`, and with it unset returns the
 * FIRST key of the map, which is `en`. The run measured the language back at i0-classify and carries
 * it in the payload; preferring it is the whole fix.
 *
 * `fallback` is what the document says, kept for the case where the run recorded nothing.
 */
export function inheritMessageKey(userLanguage, available, fallback) {
    const tag = (userLanguage || '').toLowerCase().split('-')[0];
    return available.includes(tag) ? tag : fallback;
}
/**
 * Is `override` available at all for this molecule?
 *
 * False when the parent exposes nothing that could carry a change — every member is private, a
 * module constant, or a method that only composes private ones. Measured 2026-08-14: that is the
 * case for **every** shell in this library today. Offering the choice anyway is offering a trap,
 * and the user who takes it gets a member that compiles and does nothing.
 *
 * This is a fact about the PARENT, not about the request, so the widget can state it before the
 * user chooses rather than after.
 */
export function isOverrideAvailable(value) {
    return value.overridableMembers.some(isCapableMember);
}
/** Reasons the human cannot confirm yet, in the widget's own words. */
export function inheritBlockingIssues(data, value) {
    const issues = [];
    if (data.where === 'less' && !value.hasLess) {
        issues.push('no_less');
    }
    if (data.where === 'override') {
        if (!isOverrideAvailable(value) && value.overridableMembers.length)
            issues.push('no_capable_member');
        else if (!data.member.trim())
            issues.push('no_member');
        else if (value.overridableMembers.length && !value.overridableMembers.some(m => isCapableMember(m) && m.name === data.member)) {
            issues.push('unknown_member');
        }
    }
    return issues;
}
export function canConfirmInherit(data, value) {
    return inheritBlockingIssues(data, value).length === 0;
}
export function buildInheritResult(data, action) {
    return {
        where: data.where,
        member: data.where === 'override' ? data.member.trim() : '',
        action,
    };
}
/**
 * Members offered for override, with the ones the shell already declares marked.
 *
 * Already-overridden members are not removed: seeing that `portalWidgetName` is already overridden
 * is what tells the user the shell has a local answer to a related question, and re-choosing it is
 * legitimate.
 *
 * **Members that cannot carry a change ARE removed** (2026-08-14). They are not a cheaper option,
 * they are a wrong one, and a picker that lists them turns "nothing here can do this" into a shrug
 * — the user picks the least implausible name and the run produces an override that does nothing.
 * The list of what the shell cannot reach is shown separately, so the absence is explained rather
 * than silent.
 */
export function offerableMembers(value) {
    return value.overridableMembers
        .filter(isCapableMember)
        .map(member => ({
        ...member,
        alreadyOverridden: value.ownMembers.includes(member.name),
    }));
}
/**
 * The unreachable members, capped for display.
 *
 * Capped because a parent with an i18n block declares several module constants and the list would
 * bury the picker; the first names are the ones a request is usually about. `hiddenCount` is shown
 * rather than dropped — "and 4 more" keeps the list honest about being partial.
 */
export function unreachableForDisplay(value, limit = 6) {
    const all = value.unreachableMembers || [];
    return { shown: all.slice(0, limit), hiddenCount: Math.max(0, all.length - limit) };
}
