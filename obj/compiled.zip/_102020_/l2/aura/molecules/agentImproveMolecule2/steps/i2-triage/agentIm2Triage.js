/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i2-triage/agentIm2Triage.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { isRecord, parseMaybeJson, toDisplayPath, writeJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { readJsonArtifact } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { buildVToolInstruction, createVToolSchema, extractVToolOutput, nmAgentStepIntent, nmParseStepArgs, nmResultStepIntent, nmUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { IM_AGENT_FOLDER, IM_MAX_ATTEMPTS, imDoneAnchor, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
import { imContextFileInfo, imTraceFileInfo, imTriageFileInfo, readImAgentText, sourceOf, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imResolve.js';
import { getImRunKey } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imRootPlan.js';
import { readSurface, renderSurface } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imSurface.js';
import { normalizeExpectedArtifacts, runImTriageGate, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i2-triage/gate.js';
const AGENT_NAME = 'agentIm2Triage';
const PLAN_ID = 'i2-triage';
const TOOL_NAME = 'submitTriage';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${IM_AGENT_FOLDER}/steps/i2-triage`,
        agentDescription: 'i2-triage — decides which route handles the change request',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    const runKey = getImRunKey(context, parsedArgs.runKey);
    const ctx = await readContext(runKey);
    const promptMd = await readImAgentText('steps/i2-triage', 'prompt', '.md', true);
    const schemaRaw = await readImAgentText('schemas', 'i2-triage.schema', '.json', true);
    const schema = parseMaybeJson(schemaRaw);
    if (!isRecord(schema))
        throw new Error(`[${AGENT_NAME}] invalid i2-triage schema`);
    const present = ctx.artifacts.filter(a => a.present).map(a => a.kind);
    const systemPrompt = promptMd
        .split('{{tag}}').join(ctx.target.tag)
        .split('{{groupCanonical}}').join(ctx.target.groupCanonical)
        .split('{{artifactsPresent}}').join(present.join(', ') || '(none)')
        .split('{{inheritance}}').join(renderInheritance(ctx))
        .split('{{surface}}').join(renderSurface(readSurface(sourceOf(ctx.artifacts, 'ts'))))
        .split('{{defs}}').join(renderContract(ctx))
        .split('{{userPrompt}}').join(ctx.userPrompt)
        .split('{{userLanguage}}').join(ctx.userLanguage || 'the language of the request')
        + `\n\n${buildVToolInstruction(TOOL_NAME, 'the request cannot be routed from what is shown')}`;
    const humanPrompt = [
        `Route this request for ${ctx.target.tag}.`,
        parsedArgs.retryContext ? `## What the gate rejected — fix ALL of these\n${parsedArgs.retryContext}` : '',
    ].filter(Boolean).join('\n\n');
    return [{
            type: 'prompt_ready',
            args: args || step.prompt || JSON.stringify({ planId: PLAN_ID, runKey }),
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt,
            humanPrompt,
            tools: [createVToolSchema(TOOL_NAME, 'Submit the routing decision', schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    const runKey = getImRunKey(context, parsedArgs.runKey);
    const ctx = await readContext(runKey);
    let output = null;
    let extractError = '';
    try {
        const raw = extractVToolOutput(step.interaction?.payload?.[0], TOOL_NAME, ['route']);
        if (raw.status === 'failed')
            extractError = `model reported failure: ${raw.trace.join('; ') || 'no reason'}`;
        else
            output = normalizeOutput(raw.result);
    }
    catch (error) {
        extractError = error instanceof Error ? error.message : String(error);
    }
    const present = ctx.artifacts.filter(a => a.present).map(a => a.kind);
    const gate = output
        ? runImTriageGate({ output, isShell: ctx.inheritance.isShell, artifactsPresent: present })
        : { ok: false, errors: [`extract: ${extractError}`] };
    const errorText = gate.errors.join('\n');
    await writeJsonArtifact(imTraceFileInfo(runKey, PLAN_ID, attempt), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        attempt,
        ok: gate.ok,
        ...(gate.ok ? {} : { error: errorText, output }),
    });
    if (gate.ok && output) {
        // Normalization happens AFTER the gate: the gate judges what the model said, the artifact
        // records what will be done. Folding groupIndex in earlier would hide the model's answer.
        const triage = {
            route: output.route,
            rationale: output.rationale.trim(),
            expectedArtifacts: normalizeExpectedArtifacts(output.expectedArtifacts),
        };
        await writeJsonArtifact(imTriageFileInfo(runKey), {
            ...triage,
            definitionElements: output.definitionElements.filter(item => item.trim()),
            decidedAt: new Date().toISOString(),
        });
        const summary = `route ${triage.route}${triage.expectedArtifacts.length ? ` · ${triage.expectedArtifacts.join(', ')}` : ''}`;
        return [
            nmResultStepIntent(context, parentStep, {
                planId: imDoneAnchor(PLAN_ID),
                dependsOn: [],
                stepTitle: summary,
                // The ROOT reads this result to plant the branch — flow.json.routes. Everything it needs
                // to choose is here, so it never has to open triage.json.
                result: {
                    route: triage.route,
                    rationale: triage.rationale,
                    expectedArtifacts: triage.expectedArtifacts,
                    definitionElements: output.definitionElements,
                    triageFile: toDisplayPath(imTriageFileInfo(runKey)),
                    runKey,
                    attempt,
                },
            }),
            nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `${summary} — ${triage.rationale}`, 'input_output'),
        ];
    }
    if (attempt >= IM_MAX_ATTEMPTS) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `${PLAN_ID} failed after ${attempt} attempts:\n${errorText}`)];
    }
    // Bounded retry: the OPEN retry step comes first, then complete-with-trace (never 'failed' with
    // a retry in flight — skills/collab_messages.md).
    return [
        nmAgentStepIntent(context, parentStep, {
            agentName: AGENT_NAME,
            stepTitle: `${step.stepTitle || PLAN_ID} (retry)`,
            planId: `${PLAN_ID}-retry${attempt}`,
            prompt: { planId: PLAN_ID, runKey, retryAttempt: attempt + 1, retryContext: errorText },
        }),
        nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `gate failed, retrying:\n${errorText}`, 'input_output'),
    ];
}
// ---- helpers ----
async function readContext(runKey) {
    const ctx = await readJsonArtifact(imContextFileInfo(runKey), true);
    if (!ctx)
        throw new Error(`[${AGENT_NAME}] context.json missing for ${runKey}`);
    return ctx;
}
/** Everything is defaulted here so the gate reads one shape; the gate is what rejects. */
function normalizeOutput(result) {
    const list = (value) => Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
    return {
        route: String(result.route || '').trim().toUpperCase(),
        rationale: String(result.rationale || ''),
        expectedArtifacts: list(result.expectedArtifacts),
        definitionElements: list(result.definitionElements),
    };
}
/**
 * The contract that governs the molecule — its own, or its parent's when it is a shell without one.
 * Saying WHICH matters: a shell's contract describes the parent, so "the contract promises X" is
 * still the right test, but the reader must know it is not this file that promises it.
 */
function renderContract(ctx) {
    if (!ctx.contract.source.trim())
        return '(the contract could not be read — decide from the code alone, and say so in the rationale)';
    if (!ctx.contract.inherited)
        return ctx.contract.source;
    return [
        `⚠️ This molecule is a shell and has no contract of its own. What follows is the contract of its`,
        `PARENT, \`${ctx.contract.reference}\` — it is what the molecule promises, because a shell changes`,
        `appearance and not promises.`,
        '',
        ctx.contract.source,
    ].join('\n');
}
/**
 * The inheritance block of the prompt. When the molecule is not a shell the section still exists
 * and says so: route C has to be visibly unavailable, not merely unmentioned.
 *
 * ⚠️ THE UNREACHABLE LIST IS THE EVIDENCE FOR THE THIRD QUESTION (2026-08-14). Until then this block
 * showed only what the shell COULD override, so "the code lives in the parent, out of reach" — the
 * whole of route C — had to be inferred from a short list with no explanation for why it was short.
 * That is the same silent filter that made i4-inherit suggest a teardown hook for a timer duration on
 * 2026-08-13, one step later and with the same cause. Measured, not judged: the model is not being
 * asked to guess what it cannot see.
 */
function renderInheritance(ctx) {
    const inh = ctx.inheritance;
    if (!inh.isShell) {
        return '### Inheritance\n\nThis molecule is **not a shell** — it does not extend a molecule from another project. Route C is not available for it.';
    }
    const members = inh.overridableMembers.length
        ? inh.overridableMembers.slice(0, 12).map(m => `- \`${m.name}\` (${m.kind})`).join('\n')
        : '- (the parent source is not readable from here)';
    const own = inh.ownMembers.length ? inh.ownMembers.join(', ') : 'nothing — the body is empty';
    return [
        '### Inheritance',
        '',
        `This molecule is a **shell**: \`${inh.parentClassName}\` from \`${inh.parentReference}\` (project ${inh.parentProject}).`,
        `It overrides: ${own}.`,
        '',
        'Members of the parent it could override, cheapest first:',
        members,
        '',
        'Members of the parent NO subclass can reach — if what has to change is one of these, the fix is not in this file:',
        renderUnreachable(inh.unreachableMembers),
    ].join('\n');
}
/** Capped: on a molecule with an i18n block the list runs long, and the first names are the ones the request is about. */
function renderUnreachable(members) {
    const list = members || [];
    if (!list.length)
        return '- (none detected — every member of the parent is reachable, or its source could not be read)';
    const shown = list.slice(0, 12).map(m => m.why === 'private'
        ? `- \`${m.name}\` — private`
        : `- \`${m.name}\` — module-scope constant, not a class member`);
    if (list.length > shown.length)
        shown.push(`- (and ${list.length - shown.length} more)`);
    return shown.join('\n');
}
