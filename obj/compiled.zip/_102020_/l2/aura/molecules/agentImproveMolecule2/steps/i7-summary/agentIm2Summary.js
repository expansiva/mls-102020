/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i7-summary/agentIm2Summary.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { isRecord, parseMaybeJson, readJsonArtifact, readStorText, writeJsonArtifact, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { buildVToolInstruction, createVToolSchema, extractVToolOutput, nmAgentStepIntent, nmParseStepArgs, nmUpdateStatusIntent, } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { IM_AGENT_FOLDER, IM_MAX_ATTEMPTS, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
import { buildCoherenceReport } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imCoherence.js';
import { imContextFileInfo, imFileInfoFor, imTraceFileInfo, imTriageFileInfo, imWorkFile, readGroupSkill, readImAgentText, sourceOf, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imResolve.js';
import { getImRunKey } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imRootPlan.js';
import { emptyRunFacts, findingsCarried, renderFindings, renderRunFacts, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i7-summary/gather.js';
const AGENT_NAME = 'agentIm2Summary';
const PLAN_ID = 'i7-summary';
const TOOL_NAME = 'submitSummary';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${IM_AGENT_FOLDER}/steps/i7-summary`,
        agentDescription: 'i7-summary — the final summary and the coherence report',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    const runKey = getImRunKey(context, parsedArgs.runKey);
    const facts = await gatherFacts(runKey);
    const promptMd = await readImAgentText('steps/i7-summary', 'prompt', '.md', true);
    const schemaRaw = await readImAgentText('schemas', 'i7-summary.schema', '.json', true);
    const schema = parseMaybeJson(schemaRaw);
    if (!isRecord(schema))
        throw new Error(`[${AGENT_NAME}] invalid i7-summary schema`);
    const ctx = await readContext(runKey);
    const systemPrompt = promptMd
        .split('{{userLanguage}}').join(ctx.userLanguage || 'the language of the request')
        .split('{{facts}}').join(renderRunFacts(facts))
        .split('{{findings}}').join(renderFindings(facts.findings))
        + `\n\n${buildVToolInstruction(TOOL_NAME, 'the run left nothing that can be summarised')}`;
    const humanPrompt = [
        `Write the closing summary for ${facts.tag}.`,
        parsedArgs.retryContext ? `## Fix this\n${parsedArgs.retryContext}` : '',
    ].filter(Boolean).join('\n\n');
    return [{
            type: 'prompt_ready',
            args: args || step.prompt || JSON.stringify({ planId: PLAN_ID, runKey }),
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt,
            humanPrompt,
            tools: [createVToolSchema(TOOL_NAME, 'Submit the closing summary and the coherence report', schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(step.prompt);
    const attempt = parsedArgs.retryAttempt || 1;
    const runKey = getImRunKey(context, parsedArgs.runKey);
    const facts = await gatherFacts(runKey);
    let summary = '';
    let reported = [];
    let error = '';
    try {
        const raw = extractVToolOutput(step.interaction?.payload?.[0], TOOL_NAME, ['summary']);
        if (raw.status === 'failed')
            error = `model reported failure: ${raw.trace.join('; ') || 'no reason'}`;
        else {
            summary = String(raw.result.summary || '').trim();
            reported = Array.isArray(raw.result.findings)
                ? raw.result.findings.filter((item) => typeof item === 'string')
                : [];
        }
    }
    catch (caught) {
        error = caught instanceof Error ? caught.message : String(caught);
    }
    // The only check this step makes, and flow.json said it would make none. A model asked to write
    // "a short summary" of ten problems writes about three, and a dropped finding is a defect nobody
    // hears about — which is precisely how the thirteen behind this agent were found.
    const carried = findingsCarried(reported, facts.findings);
    if (!error && !summary)
        error = 'the summary came out empty';
    if (!error && !carried.ok) {
        error = `${carried.missing} of the ${facts.findings.length} coherence findings were left out — report every one, one entry each`;
    }
    await writeJsonArtifact(imTraceFileInfo(runKey, PLAN_ID, attempt), {
        savedAt: new Date().toISOString(),
        planId: PLAN_ID,
        attempt,
        ok: !error,
        findings: facts.findings.length,
        ...(error ? { error } : {}),
    });
    if (error) {
        if (attempt >= IM_MAX_ATTEMPTS) {
            // The run WORKED — the files are written and correct. Failing the whole task over a summary
            // would tell the user the change did not happen, which is false. The findings are emitted
            // verbatim instead, in English, and the step closes.
            return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', fallbackSummary(facts, error), 'input_output')];
        }
        return [
            nmAgentStepIntent(context, parentStep, {
                agentName: AGENT_NAME,
                stepTitle: `${step.stepTitle || PLAN_ID} (retry)`,
                planId: `${PLAN_ID}-retry${attempt}`,
                prompt: { planId: PLAN_ID, runKey, retryAttempt: attempt + 1, retryContext: error },
            }),
            nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `summary rejected, retrying: ${error}`, 'input_output'),
        ];
    }
    const text = [
        summary,
        facts.findings.length ? `\n### ${coherenceHeading(facts)}\n${reported.map(line => `- ${line}`).join('\n')}` : '',
    ].filter(Boolean).join('\n');
    await writeJsonArtifact(imWorkFile(runKey, 'summary'), {
        savedAt: new Date().toISOString(),
        summary,
        findings: reported,
        findingsFound: facts.findings.length,
        touched: facts.touched,
        route: facts.route,
    });
    return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', text, 'input_output')];
}
// ---- helpers ----
async function readContext(runKey) {
    const ctx = await readJsonArtifact(imContextFileInfo(runKey), true);
    if (!ctx)
        throw new Error(`[${AGENT_NAME}] context.json missing for ${runKey}`);
    return ctx;
}
/**
 * Every step's artifact, plus the coherence report computed over the molecule AS IT STANDS NOW.
 *
 * `context.json` holds the pre-edit sources, so passing both to buildCoherenceReport is what lets
 * it mark a finding as caused by this run rather than merely noticed by it.
 */
async function gatherFacts(runKey) {
    const ctx = await readContext(runKey);
    const facts = emptyRunFacts();
    facts.tag = ctx.target.tag;
    facts.groupCanonical = ctx.target.groupCanonical;
    facts.request = ctx.userPrompt;
    const triage = await readJsonArtifact(imTriageFileInfo(runKey), false);
    if (triage) {
        facts.route = triage.route;
        facts.rationale = triage.rationale;
    }
    const edit = await readJsonArtifact(imWorkFile(runKey, 'edit'), false);
    if (edit) {
        facts.touched = (edit.touched || []).map(item => item.kind);
        facts.why = edit.why || [];
    }
    const playground = await readJsonArtifact(imWorkFile(runKey, 'playground'), false);
    if (playground?.playgroundChanged) {
        facts.playgroundChanged = true;
        facts.addedSlots = playground.addedSlots || [];
        if (!facts.touched.includes('html'))
            facts.touched.push('html');
    }
    const index = await readJsonArtifact(imWorkFile(runKey, 'index'), false);
    if (index?.indexUpdated) {
        facts.indexUpdated = true;
        if (!facts.touched.includes('groupIndex'))
            facts.touched.push('groupIndex');
    }
    const definition = await readJsonArtifact(imWorkFile(runKey, 'definition'), false);
    if (definition?.blocked) {
        facts.definitionBlocked = true;
        facts.definitionBlockedReason = definition.blockedReason || '';
        facts.groupContract = ctx.groupSkill.reference || '';
    }
    const inherit = await readJsonArtifact(imWorkFile(runKey, 'inherit'), false);
    if (inherit) {
        facts.inheritWhere = inherit.where;
        facts.inheritMember = inherit.member || '';
        // On the 'parent' outcome this is the whole answer the user gets: the run wrote nothing, by
        // design, so the summary has to name the file to open in the base project.
        facts.parentReference = ctx.inheritance.parentReference || '';
    }
    facts.findings = (await coherence(ctx)).findings;
    return facts;
}
async function coherence(ctx) {
    const groupCreationSkill = await readGroupSkill(ctx.groupSkill.reference);
    return buildCoherenceReport({
        // A shell has no .defs.ts of its own; the contract that governs it is the parent's, and
        // gate 1 must be judged against THAT — reading an empty local defs would report every slot
        // as undocumented.
        defsSource: ctx.contract.inherited
            ? ctx.contract.source
            : await readStorText(imFileInfoFor(ctx, 'defs'), false),
        tsSource: await readStorText(imFileInfoFor(ctx, 'ts'), false),
        groupCreationSkill,
        reference: ctx.target.fileReference,
        // The pre-edit snapshot. Without both, every finding is reported as pre-existing.
        previousTsSource: sourceOf(ctx.artifacts, 'ts'),
        previousDefsSource: ctx.contract.inherited ? ctx.contract.source : sourceOf(ctx.artifacts, 'defs'),
    }, new Date().toISOString());
}
function coherenceHeading(facts) {
    return facts.findings.some(f => f.severity === 'introduced')
        ? 'Coherence — including problems this change introduced'
        : 'Coherence — problems that were already there';
}
/**
 * When the model fails twice, the RUN still succeeded: the files are written and correct. Failing
 * the task over its summary would tell the user the change did not happen, which is false.
 */
function fallbackSummary(facts, error) {
    return [
        `${facts.tag} — ${facts.touched.length ? `changed: ${facts.touched.join(', ')}` : 'no file was changed'}.`,
        '',
        `(the closing summary could not be written: ${error} — the findings below are verbatim)`,
        '',
        renderFindings(facts.findings),
    ].join('\n');
}
