/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i2a-definition/widgetDefinitionChoice.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// The route A checkpoint: what this molecule will start promising.
//
// It is the only screen in the agent where a promise moves, so it says the consequence out loud —
// pages already written against this molecule keep working only for what is ADDED; a removal or a
// rename is a break, and the card shows which is which before the click, not after.
//
// The list is the whole widget. Each line can be dropped on its own, dropping all of them disables
// Confirm (that is a cancellation), and nothing is written until Confirm — same contract as the
// inheritance checkpoint.
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { imMessageKey } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
import { buildDefinitionResult, canConfirmDefinition, changeLabelKey, definitionBlockingIssues, initialSelection, toggleSelection, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i2a-definition/widgetDefinitionChoiceLogic.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'A definição desta molécula vai mudar',
    intro: 'Isto não é um ajuste: é o que a molécula promete. As páginas que já usam esta tag continuam funcionando no que for ADICIONADO — remover ou renomear quebra quem já escreveu.',
    requestLabel: 'O que foi pedido',
    todayLabel: 'O que ela declara hoje',
    changesLabel: 'O que vai mudar',
    slots: 'slots',
    properties: 'propriedades',
    events: 'eventos',
    none: '(nenhum)',
    slot_add: 'slot novo',
    slot_remove: 'slot removido',
    slot_rename: 'slot renomeado',
    property_add: 'propriedade nova',
    property_remove: 'propriedade removida',
    property_rename: 'propriedade renomeada',
    event_add: 'evento novo',
    event_remove: 'evento removido',
    event_rename: 'evento renomeado',
    breaking: 'quebra páginas existentes',
    wasCalled: 'antes',
    dropHint: 'Desmarque o que não deve entrar.',
    noChange: 'Nada selecionado — confirmar assim seria o mesmo que cancelar.',
    cancel: 'Cancelar',
    confirm: 'Confirmar',
};
const message_en = {
    title: 'This molecule\'s definition is about to change',
    intro: 'This is not an adjustment: it is what the molecule promises. Pages already using this tag keep working for whatever is ADDED — a removal or a rename breaks whoever already wrote one.',
    requestLabel: 'What was asked',
    todayLabel: 'What it declares today',
    changesLabel: 'What will change',
    slots: 'slots',
    properties: 'properties',
    events: 'events',
    none: '(none)',
    slot_add: 'new slot',
    slot_remove: 'slot removed',
    slot_rename: 'slot renamed',
    property_add: 'new property',
    property_remove: 'property removed',
    property_rename: 'property renamed',
    event_add: 'new event',
    event_remove: 'event removed',
    event_rename: 'event renamed',
    breaking: 'breaks existing pages',
    wasCalled: 'was',
    dropHint: 'Uncheck anything that should not go in.',
    noChange: 'Nothing selected — confirming this would be the same as cancelling.',
    cancel: 'Cancel',
    confirm: 'Confirm',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let WidgetDefinitionChoice102020 = class WidgetDefinitionChoice102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-definition-choice-102020 {
  display: block;
}
widget-definition-choice-102020 .dfc {
  display: flex;
  flex-direction: column;
  gap: 0.9rem;
  padding: 0.9rem 1rem;
  font-size: 0.9rem;
}
widget-definition-choice-102020 .dfc-title {
  margin: 0 0 0.3rem;
  font-size: 1rem;
  font-weight: 600;
}
widget-definition-choice-102020 .dfc-intro {
  margin: 0 0 0.4rem;
  line-height: 1.4;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-tag {
  margin: 0 0 0.3rem;
  font-family: monospace;
  font-size: 0.85rem;
}
widget-definition-choice-102020 .dfc-request,
widget-definition-choice-102020 .dfc-reason {
  margin: 0.25rem 0 0;
  line-height: 1.4;
}
widget-definition-choice-102020 .dfc-reason {
  padding-left: 0.6rem;
  border-left: 2px solid var(--collab-primary, #3b82f6);
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-label {
  display: block;
  margin: 0 0 0.35rem;
  font-size: 0.78rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-today {
  margin: 0;
  padding: 0.5rem 0.7rem;
  list-style: none;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  border-radius: 0.5rem;
}
widget-definition-choice-102020 .dfc-today li {
  display: flex;
  gap: 0.5rem;
  padding: 0.15rem 0;
}
widget-definition-choice-102020 .dfc-today-kind {
  min-width: 7rem;
  font-weight: 600;
}
widget-definition-choice-102020 .dfc-today-names {
  font-family: monospace;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-changes {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
widget-definition-choice-102020 .dfc-change {
  display: flex;
  gap: 0.6rem;
  padding: 0.6rem 0.75rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  border-radius: 0.5rem;
  cursor: pointer;
}
widget-definition-choice-102020 .dfc-change:hover {
  border-color: var(--collab-primary, #3b82f6);
}
widget-definition-choice-102020 .dfc-change.is-on {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-surface-2, rgba(59, 130, 246, 0.06));
}
widget-definition-choice-102020 .dfc-change:not(.is-on) {
  opacity: 0.55;
}
widget-definition-choice-102020 .dfc-change.is-breaking {
  border-style: dashed;
  border-color: var(--collab-warning, #f59e0b);
}
widget-definition-choice-102020 .dfc-check {
  flex: 0 0 auto;
  width: 0.95rem;
  height: 0.95rem;
  margin-top: 0.15rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.55));
  border-radius: 0.25rem;
}
widget-definition-choice-102020 .dfc-check.is-on {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-primary, #3b82f6);
}
widget-definition-choice-102020 .dfc-change-body {
  flex: 1 1 auto;
}
widget-definition-choice-102020 .dfc-change-head {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 0.45rem;
  margin: 0;
}
widget-definition-choice-102020 .dfc-change-name {
  font-family: monospace;
  font-weight: 600;
}
widget-definition-choice-102020 .dfc-change-kind,
widget-definition-choice-102020 .dfc-change-was {
  font-size: 0.8rem;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-breaking {
  padding: 0.05rem 0.4rem;
  font-size: 0.72rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  border-radius: 0.25rem;
  color: var(--collab-warning, #f59e0b);
  border: 1px solid var(--collab-warning, #f59e0b);
}
widget-definition-choice-102020 .dfc-change-purpose {
  margin: 0.25rem 0 0;
  line-height: 1.35;
}
widget-definition-choice-102020 .dfc-hint,
widget-definition-choice-102020 .dfc-blocking {
  margin: 0.4rem 0 0;
  font-size: 0.82rem;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-definition-choice-102020 .dfc-blocking {
  color: var(--collab-warning, #f59e0b);
}
widget-definition-choice-102020 .dfc-footer {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
widget-definition-choice-102020 .dfc-btn {
  padding: 0.4rem 0.9rem;
  border-radius: 0.4rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  cursor: pointer;
  font-size: 0.85rem;
}
widget-definition-choice-102020 .dfc-btn[disabled] {
  opacity: 0.5;
  cursor: not-allowed;
}
widget-definition-choice-102020 .dfc-confirm {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-primary, #3b82f6);
  color: #fff;
}
widget-definition-choice-102020 .dfc-empty {
  padding: 0.8rem;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
`);
        this.value = null;
        this.readonly = false;
        this.selection = [];
        this.initialized = false;
        this.msg = messages['en'];
    }
    toggle(index) {
        if (this.readonly)
            return;
        this.selection = toggleSelection(this.selection, index);
    }
    finish(action) {
        const value = this.value;
        if (!value)
            return;
        const detail = {
            value: buildDefinitionResult(value.changes, this.selection, action),
            action,
        };
        this.dispatchEvent(new CustomEvent('clarification-finish', { detail, bubbles: true, composed: true }));
    }
    /** `remove` and `rename` are the two that break a page already written against this molecule. */
    isBreaking(change) {
        return change.op === 'remove' || change.op === 'rename';
    }
    renderToday() {
        const current = this.value.current;
        const line = (label, names) => html `
      <li>
        <span class="dfc-today-kind">${label}</span>
        <span class="dfc-today-names">${names.length ? names.join(', ') : this.msg.none}</span>
      </li>
    `;
        return html `
      <ul class="dfc-today">
        ${line(this.msg.slots, current.slots)}
        ${line(this.msg.properties, current.properties)}
        ${line(this.msg.events, current.events)}
      </ul>
    `;
    }
    renderChange(change, index) {
        const on = this.selection[index];
        const breaking = this.isBreaking(change);
        const label = this.msg[changeLabelKey(change)] || changeLabelKey(change);
        return html `
      <li class="dfc-change ${on ? 'is-on' : ''} ${breaking ? 'is-breaking' : ''}" @click=${() => this.toggle(index)}>
        <span class="dfc-check ${on ? 'is-on' : ''}"></span>
        <div class="dfc-change-body">
          <p class="dfc-change-head">
            <code class="dfc-change-name">${change.name}</code>
            <span class="dfc-change-kind">${label}</span>
            ${change.previousName ? html `<span class="dfc-change-was">${this.msg.wasCalled} <code>${change.previousName}</code></span>` : nothing}
            ${breaking ? html `<span class="dfc-breaking">${this.msg.breaking}</span>` : nothing}
          </p>
          <p class="dfc-change-purpose">${change.purpose}</p>
        </div>
      </li>
    `;
    }
    render() {
        const value = this.value;
        // The chrome follows the run's language, not the document's — see imMessageKey.
        this.msg = messages[imMessageKey(value?.userLanguage, Object.keys(messages), this.getMessageKey(messages))];
        if (!value)
            return html `<div class="dfc-empty">No clarification.</div>`;
        if (!this.initialized) {
            this.selection = initialSelection(value.changes);
            this.initialized = true;
        }
        const blocking = definitionBlockingIssues(value.changes, this.selection);
        const canConfirm = canConfirmDefinition(value.changes, this.selection);
        return html `
      <div class="dfc">
        <div class="dfc-header">
          <h3 class="dfc-title">${value.title || this.msg.title}</h3>
          <p class="dfc-intro">${this.msg.intro}</p>
          <p class="dfc-tag"><strong>${value.tag}</strong></p>
          ${value.request ? html `
            <p class="dfc-request"><span class="dfc-label">${this.msg.requestLabel}:</span> ${value.request}</p>
          ` : nothing}
          ${value.reason ? html `<p class="dfc-reason">${value.reason}</p>` : nothing}
        </div>

        <div class="dfc-section">
          <p class="dfc-label">${this.msg.todayLabel}</p>
          ${this.renderToday()}
        </div>

        <div class="dfc-section">
          <p class="dfc-label">${this.msg.changesLabel}</p>
          <ul class="dfc-changes">
            ${value.changes.map((change, index) => this.renderChange(change, index))}
          </ul>
          <p class="dfc-hint">${this.msg.dropHint}</p>
        </div>

        ${blocking.includes('no_change') ? html `<p class="dfc-blocking">${this.msg.noChange}</p>` : nothing}

        <div class="dfc-footer">
          <button class="dfc-btn dfc-cancel" @click=${() => this.finish('cancel')}>${this.msg.cancel}</button>
          <button class="dfc-btn dfc-confirm" ?disabled=${!canConfirm || this.readonly} @click=${() => this.finish('continue')}>
            ${this.msg.confirm}
          </button>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetDefinitionChoice102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetDefinitionChoice102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetDefinitionChoice102020.prototype, "selection", void 0);
__decorate([
    state()
], WidgetDefinitionChoice102020.prototype, "initialized", void 0);
WidgetDefinitionChoice102020 = __decorate([
    customElement('widget-definition-choice-102020')
], WidgetDefinitionChoice102020);
export { WidgetDefinitionChoice102020 };
