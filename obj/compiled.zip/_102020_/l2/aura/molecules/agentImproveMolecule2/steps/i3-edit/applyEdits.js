/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i3-edit/applyEdits.ts" enhancement="_blank"/>
function fail(index, artifact, message) {
    return `edit ${index + 1} (${artifact}): ${message}`;
}
/** A short, unambiguous quote of the failing `find`, for the retry to recognise. */
function quote(text, max = 60) {
    const oneLine = text.replace(/\s+/g, ' ').trim();
    return oneLine.length > max ? `${oneLine.slice(0, max)}…` : oneLine;
}
function countOccurrences(haystack, needle) {
    if (!needle)
        return 0;
    let count = 0;
    let index = haystack.indexOf(needle);
    while (index !== -1) {
        count++;
        index = haystack.indexOf(needle, index + needle.length);
    }
    return count;
}
/**
 * Applies the edits in order onto a copy of the current files.
 *
 * Order matters and is the model's: a later `replace` sees the result of an earlier one. That is
 * what lets two edits touch neighbouring lines without one invalidating the other's `find`.
 *
 * Nothing is written on any error — the caller gets the full error list and retries the whole set.
 */
export function applyEdits(files, edits) {
    const working = new Map();
    const touched = new Set();
    const errors = [];
    const applied = [];
    if (!edits.length)
        return { changed: new Map(), errors: ['no edits were produced'], applied };
    edits.forEach((edit, index) => {
        const state = files.get(edit.artifact);
        if (!state) {
            errors.push(fail(index, edit.artifact, `'${edit.artifact}' is not an artifact of this molecule`));
            return;
        }
        const current = working.has(edit.artifact) ? working.get(edit.artifact) : state.source;
        if (edit.op === 'create') {
            if (state.present) {
                errors.push(fail(index, edit.artifact, 'the file already exists — use replace or append, never create'));
                return;
            }
            if (!edit.content.trim()) {
                errors.push(fail(index, edit.artifact, 'create with empty content'));
                return;
            }
            working.set(edit.artifact, edit.content);
            touched.add(edit.artifact);
            applied.push(`${edit.artifact}: created`);
            return;
        }
        if (!state.present) {
            errors.push(fail(index, edit.artifact, `the file does not exist — ${edit.op} needs something to ${edit.op === 'append' ? 'append to' : 'find'}`));
            return;
        }
        if (edit.op === 'append') {
            if (!edit.content.trim()) {
                errors.push(fail(index, edit.artifact, 'append with empty content'));
                return;
            }
            const separator = current.endsWith('\n') ? '' : '\n';
            working.set(edit.artifact, `${current}${separator}${edit.content.replace(/\n*$/, '\n')}`);
            touched.add(edit.artifact);
            applied.push(`${edit.artifact}: appended ${edit.content.split('\n').length} line(s)`);
            return;
        }
        // replace
        const find = edit.find || '';
        if (!find) {
            errors.push(fail(index, edit.artifact, 'replace without `find`'));
            return;
        }
        const occurrences = countOccurrences(current, find);
        if (occurrences === 0) {
            errors.push(fail(index, edit.artifact, `\`find\` does not occur in the file — copy it verbatim, whitespace included: "${quote(find)}"`));
            return;
        }
        if (occurrences > 1) {
            errors.push(fail(index, edit.artifact, `\`find\` occurs ${occurrences} times — extend it until it is unique: "${quote(find)}"`));
            return;
        }
        if (find === edit.content) {
            errors.push(fail(index, edit.artifact, '`find` and `content` are identical — this edit changes nothing'));
            return;
        }
        working.set(edit.artifact, current.replace(find, () => edit.content));
        touched.add(edit.artifact);
        applied.push(`${edit.artifact}: ${edit.why.trim() || 'replaced a block'}`);
    });
    if (errors.length)
        return { changed: new Map(), errors, applied: [] };
    // A file whose content came out identical is not reported as changed: writing it would bump its
    // timestamp and make the summary claim work that did not happen.
    const changed = new Map();
    for (const kind of touched) {
        const after = working.get(kind);
        if (after !== files.get(kind).source)
            changed.set(kind, after);
    }
    if (!changed.size)
        return { changed, errors: ['every edit applied but the content is unchanged'], applied };
    return { changed, errors: [], applied };
}
/** The `/// <mls …>` line, which must survive every edit byte-for-byte. */
export function mlsHeaderOf(source) {
    return (source.match(/^\s*\/\/\/\s*<mls\b.*$/m) || [''])[0].trim();
}
