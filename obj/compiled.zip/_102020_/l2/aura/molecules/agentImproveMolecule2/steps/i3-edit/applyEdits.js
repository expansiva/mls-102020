/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i3-edit/applyEdits.ts" enhancement="_blank"/>
function fail(index, artifact, message) {
    return `edit ${index + 1} (${artifact}): ${message}`;
}
/** A short, unambiguous quote of the failing `find`, for the retry to recognise. */
function quote(text, max = 60) {
    const oneLine = text.replace(/\s+/g, ' ').trim();
    return oneLine.length > max ? `${oneLine.slice(0, max)}…` : oneLine;
}
function countOccurrences(haystack, needle) {
    if (!needle)
        return 0;
    let count = 0;
    let index = haystack.indexOf(needle);
    while (index !== -1) {
        count++;
        index = haystack.indexOf(needle, index + needle.length);
    }
    return count;
}
/**
 * WHITESPACE-TOLERANT MATCHING, and it is not a convenience — it is the difference between this
 * step working and not working.
 *
 * MEASURED 2026-08-10, after the first real run failed on exactly this: 32 of the 153 molecules in
 * mls-102040 have COLLAPSED INDENTATION — every indented line sits at exactly ONE space, whatever
 * its nesting depth. ml-hierarchy-tree.ts is one of them: 367 lines at one space, 38 at zero.
 *
 * A code model shown ` private parseNodes() {` and told to copy it verbatim re-indents it to two or
 * four spaces. That is the strongest normalization instinct such a model has, and no amount of
 * prompt insistence reliably beats it — the first run burned both attempts on it.
 *
 * So the exact match is tried FIRST (byte-precise, the common case), and only on a miss does the
 * text get matched ignoring whitespace RUNS. The span replaced is the one really found in the file,
 * so untouched bytes stay untouched either way, and an ambiguous match is still refused.
 */
function flexiblePattern(find) {
    const escaped = find
        .trim()
        .split(/\s+/)
        .map(chunk => chunk.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
        .join('\\s+');
    return new RegExp(escaped, 'g');
}
function findFlexible(haystack, find) {
    const matches = [...haystack.matchAll(flexiblePattern(find))];
    const first = matches[0];
    return {
        count: matches.length,
        start: first?.index ?? -1,
        end: first ? first.index + first[0].length : -1,
    };
}
/**
 * Applies the edits in order onto a copy of the current files.
 *
 * Order matters and is the model's: a later `replace` sees the result of an earlier one. That is
 * what lets two edits touch neighbouring lines without one invalidating the other's `find`.
 *
 * Nothing is written on any error — the caller gets the full error list and retries the whole set.
 */
export function applyEdits(files, edits) {
    const working = new Map();
    const touched = new Set();
    const errors = [];
    const applied = [];
    if (!edits.length)
        return { changed: new Map(), errors: ['no edits were produced'], applied };
    edits.forEach((edit, index) => {
        const state = files.get(edit.artifact);
        if (!state) {
            errors.push(fail(index, edit.artifact, `'${edit.artifact}' is not an artifact of this molecule`));
            return;
        }
        const current = working.has(edit.artifact) ? working.get(edit.artifact) : state.source;
        if (edit.op === 'create') {
            if (state.present) {
                errors.push(fail(index, edit.artifact, 'the file already exists — use replace or append, never create'));
                return;
            }
            if (!edit.content.trim()) {
                errors.push(fail(index, edit.artifact, 'create with empty content'));
                return;
            }
            working.set(edit.artifact, edit.content);
            touched.add(edit.artifact);
            applied.push(`${edit.artifact}: created`);
            return;
        }
        if (!state.present) {
            errors.push(fail(index, edit.artifact, `the file does not exist — ${edit.op} needs something to ${edit.op === 'append' ? 'append to' : 'find'}`));
            return;
        }
        if (edit.op === 'append') {
            if (!edit.content.trim()) {
                errors.push(fail(index, edit.artifact, 'append with empty content'));
                return;
            }
            const separator = current.endsWith('\n') ? '' : '\n';
            working.set(edit.artifact, `${current}${separator}${edit.content.replace(/\n*$/, '\n')}`);
            touched.add(edit.artifact);
            applied.push(`${edit.artifact}: appended ${edit.content.split('\n').length} line(s)`);
            return;
        }
        // replace
        const find = edit.find || '';
        if (!find) {
            errors.push(fail(index, edit.artifact, 'replace without `find`'));
            return;
        }
        if (find.trim() === edit.content.trim()) {
            errors.push(fail(index, edit.artifact, '`find` and `content` are identical — this edit changes nothing'));
            return;
        }
        const exact = countOccurrences(current, find);
        if (exact === 1) {
            working.set(edit.artifact, current.replace(find, () => edit.content));
            touched.add(edit.artifact);
            applied.push(`${edit.artifact}: ${edit.why.trim() || 'replaced a block'}`);
            return;
        }
        if (exact > 1) {
            errors.push(fail(index, edit.artifact, `\`find\` occurs ${exact} times — extend it until it is unique: "${quote(find)}"`));
            return;
        }
        // No exact hit. Try again ignoring whitespace runs — see flexiblePattern for why this is the
        // normal case and not the exception.
        const loose = findFlexible(current, find);
        if (loose.count === 0) {
            errors.push(fail(index, edit.artifact, `\`find\` does not occur in the file, not even ignoring whitespace — the text itself is not there: "${quote(find)}"`));
            return;
        }
        if (loose.count > 1) {
            errors.push(fail(index, edit.artifact, `\`find\` occurs ${loose.count} times — extend it until it is unique: "${quote(find)}"`));
            return;
        }
        // Only the span really found is replaced, so everything around it keeps its own bytes — the
        // file's indentation is left exactly as odd as it was.
        working.set(edit.artifact, current.slice(0, loose.start) + edit.content.trim() + current.slice(loose.end));
        touched.add(edit.artifact);
        applied.push(`${edit.artifact}: ${edit.why.trim() || 'replaced a block'} (whitespace-tolerant match)`);
    });
    if (errors.length)
        return { changed: new Map(), errors, applied: [] };
    // A file whose content came out identical is not reported as changed: writing it would bump its
    // timestamp and make the summary claim work that did not happen.
    const changed = new Map();
    for (const kind of touched) {
        const after = working.get(kind);
        if (after !== files.get(kind).source)
            changed.set(kind, after);
    }
    if (!changed.size)
        return { changed, errors: ['every edit applied but the content is unchanged'], applied };
    return { changed, errors: [], applied };
}
/** The `/// <mls …>` line, which must survive every edit byte-for-byte. */
export function mlsHeaderOf(source) {
    return (source.match(/^\s*\/\/\/\s*<mls\b.*$/m) || [''])[0].trim();
}
