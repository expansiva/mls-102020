/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i4-inherit/widgetInheritChoice.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// "Inherit Choice" widget: the human decides WHERE a fix goes on an inherited shell.
//
// A separate widget from n2-plan's on purpose (flow.json): that one confirms REQUIREMENTS, this one
// presents three options whose CONSEQUENCES differ, and the consequence is what the user needs
// before clicking — not after.
//
// The three are not equal and the widget must not present them as if they were:
//   - `.less` keeps the shell inheriting everything;
//   - an override makes the shell stop inheriting THAT member forever, which the card says out
//     loud, and says louder for render();
//   - `parent` writes nothing at all and ends the run with an instruction.
//
// No Shadow DOM (StateLitElement) — styles live in the sibling .less scoped under the tag.
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { applyInheritMember, applyInheritWhere, buildInheritResult, canConfirmInherit, inheritBlockingIssues, isExpensiveOverride, isOverrideAvailable, offerableMembers, unreachableForDisplay, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i4-inherit/widgetInheritChoiceLogic.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Onde aplicar a correção',
    intro: 'Esta molécula herda de outra, que vive em outro projeto. O agente nunca altera o código do pai — escolha onde a correção entra aqui.',
    shellOf: 'Herda de',
    suggestion: 'Sugestão',
    lessTitle: 'Só estilo, no .less desta molécula',
    lessBody: 'A correção é visual e cabe na folha própria da casca. Continua herdando tudo do pai.',
    overrideTitle: 'Sobrescrever um membro aqui',
    overrideBody: 'Resolve qualquer coisa. Em troca, esta casca PARA DE HERDAR esse membro: uma correção futura na base não chega mais aqui.',
    overrideExpensive: 'Sobrescrever render() abre mão de todo o markup do pai. Nenhuma das 84 cascas existentes faz isso.',
    parentTitle: 'A correção é do componente base',
    parentBody: 'Nada será alterado. O agente encerra e informa qual arquivo abrir no projeto da base — é onde este pedido deve ser feito.',
    memberLabel: 'Membro a sobrescrever',
    memberPlaceholder: 'nome do membro no pai',
    alreadyOverridden: 'já sobrescrito aqui',
    costProperty: 'propriedade',
    costMethod: 'método',
    parentUnreadable: 'O código do pai não pôde ser lido daqui; digite o nome do membro.',
    noLess: 'Esta molécula ainda não tem .less. Escolher esta opção faz o agente criar um.',
    needMember: 'Escolha o membro a sobrescrever.',
    unreachableLabel: 'O pai também tem estes, e nenhuma subclasse alcança:',
    unreachableMore: 'e mais',
    whyPrivate: 'privado: override não compila',
    whyModuleConst: 'constante de módulo: não é membro de classe',
    unreachableHint: 'Se o que precisa mudar está num destes, nenhuma sobrescrita aqui resolve — a correção é do componente base.',
    overrideUnavailable: 'Indisponível: nenhum membro do pai pode carregar esta mudança. Os que existem ou são privados, ou são constantes de módulo, ou só compõem membros privados — sobrescrever qualquer um compilaria sem mudar nada.',
    cancel: 'Cancelar',
    confirm: 'Confirmar',
};
const message_en = {
    title: 'Where the fix goes',
    intro: 'This molecule inherits from another, living in a different project. The agent never changes the parent — choose where the fix goes here.',
    shellOf: 'Inherits from',
    suggestion: 'Suggestion',
    lessTitle: 'Style only, in this molecule\'s .less',
    lessBody: 'The fix is visual and fits the shell\'s own sheet. It keeps inheriting everything from the parent.',
    overrideTitle: 'Override a member here',
    overrideBody: 'Solves anything. In exchange, this shell STOPS INHERITING that member: a later fix in the base no longer reaches it.',
    overrideExpensive: 'Overriding render() gives up all of the parent\'s markup. None of the 84 existing shells does this.',
    parentTitle: 'The fix belongs to the base component',
    parentBody: 'Nothing will be changed. The agent ends and tells you which file to open in the base project — that is where this request belongs.',
    memberLabel: 'Member to override',
    memberPlaceholder: 'member name in the parent',
    alreadyOverridden: 'already overridden here',
    costProperty: 'property',
    costMethod: 'method',
    parentUnreadable: 'The parent source could not be read from here; type the member name.',
    noLess: 'This molecule has no .less yet. Choosing this makes the agent create one.',
    needMember: 'Choose the member to override.',
    unreachableLabel: 'The parent also has these, and no subclass can reach them:',
    unreachableMore: 'and',
    whyPrivate: 'private: an override does not compile',
    whyModuleConst: 'module-scope constant: not a class member',
    unreachableHint: 'If what has to change lives in one of these, no override here solves it — the fix belongs to the base component.',
    overrideUnavailable: 'Unavailable: no member of the parent can carry this change. The ones that exist are private, module-scope constants, or methods that only compose private members — overriding any of them would compile and change nothing.',
    cancel: 'Cancel',
    confirm: 'Confirm',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let WidgetInheritChoice102020 = class WidgetInheritChoice102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-inherit-choice-102020 {
  display: block;
}
widget-inherit-choice-102020 .ihc {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
  padding: 1rem;
}
widget-inherit-choice-102020 .ihc-title {
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
}
widget-inherit-choice-102020 .ihc-intro,
widget-inherit-choice-102020 .ihc-parent,
widget-inherit-choice-102020 .ihc-reason {
  margin: 0.35rem 0 0;
  font-size: 0.85rem;
  opacity: 0.85;
}
widget-inherit-choice-102020 .ihc-parent code {
  padding: 0.05rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--collab-surface-2, rgba(127, 127, 127, 0.12));
}
widget-inherit-choice-102020 .ihc-parent-ref {
  display: block;
  font-size: 0.75rem;
  opacity: 0.7;
}
widget-inherit-choice-102020 .ihc-reason {
  font-style: italic;
}
widget-inherit-choice-102020 .ihc-options {
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
widget-inherit-choice-102020 .ihc-option {
  padding: 0.7rem 0.85rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  border-radius: 0.5rem;
  cursor: pointer;
}
widget-inherit-choice-102020 .ihc-option:hover {
  border-color: var(--collab-primary, #3b82f6);
}
widget-inherit-choice-102020 .ihc-option.is-selected {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-surface-2, rgba(59, 130, 246, 0.06));
}
widget-inherit-choice-102020 .ihc-option.is-unavailable {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-inherit-choice-102020 .ihc-option.is-unavailable:hover {
  border-color: var(--collab-border, rgba(127, 127, 127, 0.35));
}
widget-inherit-choice-102020 .ihc-option.is-unavailable .ihc-radio {
  opacity: 0.4;
}
widget-inherit-choice-102020 .ihc-unavailable {
  margin: 0.4rem 0 0;
  font-size: 0.8rem;
  line-height: 1.35;
  color: var(--collab-text-muted, rgba(127, 127, 127, 0.95));
}
widget-inherit-choice-102020 .ihc-option-parent {
  border-style: dashed;
}
widget-inherit-choice-102020 .ihc-option-head {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
widget-inherit-choice-102020 .ihc-radio {
  width: 0.85rem;
  height: 0.85rem;
  flex: none;
  border: 2px solid var(--collab-border, rgba(127, 127, 127, 0.55));
  border-radius: 50%;
}
widget-inherit-choice-102020 .ihc-radio.is-on {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-primary, #3b82f6);
  box-shadow: inset 0 0 0 2px var(--collab-surface, #fff);
}
widget-inherit-choice-102020 .ihc-option-title {
  font-weight: 600;
  font-size: 0.9rem;
}
widget-inherit-choice-102020 .ihc-badge {
  padding: 0.05rem 0.4rem;
  border-radius: 999px;
  font-size: 0.7rem;
  background: var(--collab-primary, #3b82f6);
  color: var(--collab-on-primary, #fff);
}
widget-inherit-choice-102020 .ihc-option-body {
  margin: 0.35rem 0 0 1.35rem;
  font-size: 0.82rem;
  opacity: 0.85;
}
widget-inherit-choice-102020 .ihc-member {
  margin: 0.6rem 0 0 1.35rem;
}
widget-inherit-choice-102020 .ihc-member-label {
  display: block;
  font-size: 0.78rem;
  font-weight: 600;
  margin-bottom: 0.35rem;
}
widget-inherit-choice-102020 .ihc-member-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
}
widget-inherit-choice-102020 .ihc-member-item {
  display: flex;
  align-items: baseline;
  gap: 0.35rem;
  padding: 0.25rem 0.5rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  border-radius: 0.35rem;
  background: transparent;
  cursor: pointer;
  font-size: 0.8rem;
}
widget-inherit-choice-102020 .ihc-member-item.is-on {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-surface-2, rgba(59, 130, 246, 0.1));
}
widget-inherit-choice-102020 .ihc-member-item.is-expensive {
  border-style: dashed;
  border-color: var(--collab-warning, #d97706);
}
widget-inherit-choice-102020 .ihc-member-name {
  font-family: var(--collab-font-mono, monospace);
}
widget-inherit-choice-102020 .ihc-member-kind,
widget-inherit-choice-102020 .ihc-member-note {
  font-size: 0.7rem;
  opacity: 0.7;
}
widget-inherit-choice-102020 .ihc-member-input {
  width: 100%;
  padding: 0.3rem 0.5rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  border-radius: 0.35rem;
  background: transparent;
  font-family: var(--collab-font-mono, monospace);
  font-size: 0.8rem;
}
widget-inherit-choice-102020 .ihc-hint,
widget-inherit-choice-102020 .ihc-warning,
widget-inherit-choice-102020 .ihc-blocking {
  margin: 0.4rem 0 0;
  font-size: 0.78rem;
}
widget-inherit-choice-102020 .ihc-hint {
  opacity: 0.7;
}
widget-inherit-choice-102020 .ihc-warning,
widget-inherit-choice-102020 .ihc-blocking {
  color: var(--collab-warning, #d97706);
}
widget-inherit-choice-102020 .ihc-unreachable {
  margin: 0.6rem 0 0;
  padding-top: 0.5rem;
  border-top: 1px dashed var(--collab-border, rgba(127, 127, 127, 0.35));
}
widget-inherit-choice-102020 .ihc-unreachable-label {
  margin: 0;
  font-size: 0.78rem;
  opacity: 0.7;
}
widget-inherit-choice-102020 .ihc-unreachable-list {
  margin: 0.3rem 0 0;
  padding-left: 1rem;
  font-size: 0.78rem;
  opacity: 0.7;
}
widget-inherit-choice-102020 .ihc-unreachable-list li {
  margin: 0.1rem 0;
}
widget-inherit-choice-102020 .ihc-unreachable-list code {
  text-decoration: line-through;
}
widget-inherit-choice-102020 .ihc-unreachable-why {
  margin-left: 0.4rem;
  opacity: 0.85;
}
widget-inherit-choice-102020 .ihc-footer {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
widget-inherit-choice-102020 .ihc-btn {
  padding: 0.35rem 0.9rem;
  border-radius: 0.35rem;
  border: 1px solid var(--collab-border, rgba(127, 127, 127, 0.35));
  background: transparent;
  cursor: pointer;
  font-size: 0.85rem;
}
widget-inherit-choice-102020 .ihc-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
widget-inherit-choice-102020 .ihc-confirm {
  border-color: var(--collab-primary, #3b82f6);
  background: var(--collab-primary, #3b82f6);
  color: var(--collab-on-primary, #fff);
}
widget-inherit-choice-102020 .ihc-empty {
  padding: 1rem;
  opacity: 0.7;
}
`);
        this.value = null;
        this.readonly = false;
        this.data = { where: 'less', member: '' };
        this.initialized = false;
        this.msg = messages['en'];
    }
    choose(where) {
        if (this.readonly)
            return;
        this.data = applyInheritWhere(this.data, where);
    }
    pickMember(member) {
        if (this.readonly)
            return;
        this.data = applyInheritMember(this.data, member);
    }
    finish(action) {
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: { value: buildInheritResult(this.data, action), action },
            bubbles: true,
            composed: true,
        }));
    }
    /**
     * `unavailable` is not the same as "not selected": the option is shown, greyed and unclickable,
     * with the reason under it. Hiding it would leave the user wondering whether an override was
     * considered; offering it would let them choose something that cannot work (2026-08-14).
     */
    renderOption(where, title, body, extra = nothing, unavailable = false) {
        const selected = !unavailable && this.data.where === where;
        return html `
      <div
        class="ihc-option ${selected ? 'is-selected' : ''} ${unavailable ? 'is-unavailable' : ''} ihc-option-${where}"
        @click=${() => { if (!unavailable)
            this.choose(where); }}>
        <div class="ihc-option-head">
          <span class="ihc-radio ${selected ? 'is-on' : ''}"></span>
          <span class="ihc-option-title">${title}</span>
          ${!unavailable && this.value?.suggested.where === where ? html `<span class="ihc-badge">${this.msg.suggestion}</span>` : nothing}
        </div>
        <p class="ihc-option-body">${body}</p>
        ${unavailable
            ? html `<p class="ihc-unavailable">${this.msg.overrideUnavailable}</p>${this.renderUnreachable()}`
            : (selected ? extra : nothing)}
      </div>
    `;
    }
    renderMemberPicker() {
        const value = this.value;
        const offered = offerableMembers(value);
        const expensive = isExpensiveOverride(this.data.member);
        return html `
      <div class="ihc-member">
        <label class="ihc-member-label">${this.msg.memberLabel}</label>
        ${offered.length ? html `
          <div class="ihc-member-list">
            ${offered.map(member => html `
              <button
                class="ihc-member-item ${this.data.member === member.name ? 'is-on' : ''} ${isExpensiveOverride(member.name) ? 'is-expensive' : ''}"
                @click=${(event) => { event.stopPropagation(); this.pickMember(member.name); }}>
                <span class="ihc-member-name">${member.name}</span>
                <span class="ihc-member-kind">${member.kind === 'property' ? this.msg.costProperty : this.msg.costMethod}</span>
                ${member.alreadyOverridden ? html `<span class="ihc-member-note">${this.msg.alreadyOverridden}</span>` : nothing}
              </button>
            `)}
          </div>
        ` : html `
          <p class="ihc-hint">${this.msg.parentUnreadable}</p>
          <input
            class="ihc-member-input"
            .value=${this.data.member}
            placeholder=${this.msg.memberPlaceholder}
            @click=${(event) => event.stopPropagation()}
            @input=${(event) => this.pickMember(event.target.value)}>
        `}
        ${expensive ? html `<p class="ihc-warning">${this.msg.overrideExpensive}</p>` : nothing}
        ${this.renderUnreachable()}
      </div>
    `;
    }
    /**
     * What the parent has and cannot be overridden. The human is the one choosing a member now, and a
     * two-name list with no explanation reads as "the parent has nothing worth overriding" when the
     * truth is that the interesting members are private. Same facts the model gets — see the step's
     * CHANGELOG, 2026-08-13.
     */
    renderUnreachable() {
        const { shown, hiddenCount } = unreachableForDisplay(this.value);
        if (!shown.length)
            return nothing;
        return html `
      <div class="ihc-unreachable">
        <p class="ihc-unreachable-label">${this.msg.unreachableLabel}</p>
        <ul class="ihc-unreachable-list">
          ${shown.map(member => html `
            <li>
              <code>${member.name}</code>
              <span class="ihc-unreachable-why">${member.why === 'private' ? this.msg.whyPrivate : this.msg.whyModuleConst}</span>
            </li>
          `)}
          ${hiddenCount ? html `<li class="ihc-unreachable-more">${this.msg.unreachableMore} ${hiddenCount}</li>` : nothing}
        </ul>
        <p class="ihc-hint">${this.msg.unreachableHint}</p>
      </div>
    `;
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)];
        const value = this.value;
        if (!value)
            return html `<div class="ihc-empty">No clarification.</div>`;
        // The model's suggestion is the starting point, not the answer. It is applied once, so a
        // re-render never drags the user's own choice back to it.
        if (!this.initialized) {
            this.data = { where: value.suggested.where, member: value.suggested.member };
            this.initialized = true;
        }
        const blocking = inheritBlockingIssues(this.data, value);
        const canConfirm = canConfirmInherit(this.data, value);
        return html `
      <div class="ihc">
        <div class="ihc-header">
          <h3 class="ihc-title">${value.title || this.msg.title}</h3>
          <p class="ihc-intro">${this.msg.intro}</p>
          <p class="ihc-parent">
            <strong>${value.tag}</strong> · ${this.msg.shellOf} <code>${value.parentClassName}</code>
            <span class="ihc-parent-ref">${value.parentReference}</span>
          </p>
          ${value.suggestionReason ? html `<p class="ihc-reason">${value.suggestionReason}</p>` : nothing}
        </div>

        <div class="ihc-options">
          ${this.renderOption('less', this.msg.lessTitle, this.msg.lessBody, value.hasLess ? nothing : html `<p class="ihc-hint">${this.msg.noLess}</p>`)}
          ${this.renderOption('override', this.msg.overrideTitle, this.msg.overrideBody, this.renderMemberPicker(), !isOverrideAvailable(value) && value.overridableMembers.length > 0)}
          ${this.renderOption('parent', this.msg.parentTitle, this.msg.parentBody)}
        </div>

        ${blocking.includes('no_member') || blocking.includes('unknown_member')
            ? html `<p class="ihc-blocking">${this.msg.needMember}</p>` : nothing}

        <div class="ihc-footer">
          <button class="ihc-btn ihc-cancel" @click=${() => this.finish('cancel')}>${this.msg.cancel}</button>
          <button class="ihc-btn ihc-confirm" ?disabled=${!canConfirm || this.readonly} @click=${() => this.finish('continue')}>
            ${this.msg.confirm}
          </button>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetInheritChoice102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetInheritChoice102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetInheritChoice102020.prototype, "data", void 0);
__decorate([
    state()
], WidgetInheritChoice102020.prototype, "initialized", void 0);
WidgetInheritChoice102020 = __decorate([
    customElement('widget-inherit-choice-102020')
], WidgetInheritChoice102020);
export { WidgetInheritChoice102020 };
