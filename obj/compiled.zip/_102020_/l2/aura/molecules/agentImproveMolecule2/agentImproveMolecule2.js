/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/agentImproveMolecule2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { isBareMention, stripAgentMention } from '/_102020_/l2/aura/molecules/shared/mentionEntry.js';
import { isRecord, parseMaybeJson } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmFs.js';
import { nmRunKey } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmContext.js';
import { nmParseStepArgs, nmUpdateStatusIntent } from '/_102020_/l2/aura/molecules/agentNewMolecule2/helpers/nmSteps.js';
import { IM_AGENT_FOLDER, IM_AGENT_NAME, imDoneAnchor, } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.js';
import { getImRootPlan, normalizeImRootPlan } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imRootPlan.js';
import { checkImClassification } from '/_102020_/l2/aura/molecules/agentImproveMolecule2/steps/i1-locate/gate.js';
const AGENT_NAME = IM_AGENT_NAME;
/** The router is handled by the root itself, so it has no agent of its own. */
const ROUTER_PLAN_ID = 'i2r-route';
/**
 * Step agents that EXIST. A route naming anything absent fails readably instead of planting a
 * step whose agent cannot be resolved — which surfaces at runtime as a dead tree node.
 */
const STEP_AGENTS = {
    'i1-locate': 'agentIm2Locate',
    'i2-triage': 'agentIm2Triage',
    'i2a-definition': 'agentIm2Definition',
    'i3-edit': 'agentIm2Edit',
    'i4-inherit': 'agentIm2Inherit',
    'i5-playground': 'agentIm2Playground',
    'i6-index': 'agentIm2Index',
    'i7-summary': 'agentIm2Summary',
};
/**
 * flow.json.routes, as data. Phase 1 is common to every route and is not listed here.
 *
 * ⚠️ ROUTE A IS AN EDIT, NOT A REBUILD (2026-08-14). It was specced as a handoff to
 * agentNewMolecule2 and blocked for that reason since 2026-08-06: NM2 refuses to overwrite an
 * existing molecule, and route A acts on one by definition. Editing in place dissolves the problem
 * and reuses steps that already exist — i3 writes `.defs.ts` and `.ts`, i5 regenerates the
 * playground because the surface moved, i6 follows. Only the checkpoint was missing.
 *
 * ⚠️ WHETHER ANY OTHER ROUTE REACHES the active branch of i5 and i6 went back and forth twice on
 * 2026-08-14. Where it landed: route B moved the surface once, on `ml-combobox`, by declaring a slot
 * the group already named — a real defect fix. Route E, added 2026-08-18, reaches i5 by explicit
 * request. What route A is for is what it always said: an INTENTIONAL change of what the molecule
 * promises. The group contract fixes that surface, so a legitimate route A here usually implies the
 * group contract moving first — by hand, outside this agent.
 */
const ROUTE_STEPS = {
    A: ['i2a-definition', 'i3-edit', 'i5-playground', 'i6-index', 'i7-summary'],
    B: ['i3-edit', 'i5-playground', 'i6-index', 'i7-summary'],
    C: ['i4-inherit', 'i3-edit', 'i5-playground', 'i6-index', 'i7-summary'],
    D: [],
    // ROUTE E — regenerate a DERIVED artifact. No i3: the molecule itself is not touched, so there is
    // nothing to edit. i5 rewrites the playground, i6 follows it (the 2026-08-05 rule), i7 closes.
    E: ['i5-playground', 'i6-index', 'i7-summary'],
};
/**
 * Steps declared by a route and not implemented yet.
 *
 * They are SKIPPED, not planted, and the run says so at the end. The alternative — planting them —
 * puts a node in the tree whose agent does not resolve, which reads to the user as a crash rather
 * than as "this part is not built".
 *
 * Empty since 2026-08-14, when route A was built. The mechanism stays: it is what keeps a
 * half-declared route from reading as a crash, and the next route added will want it.
 */
const NOT_BUILT = {};
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: IM_AGENT_FOLDER,
        agentDescription: 'Changes an existing molecule from a prose request: triages it into a minor edit, an inherited-shell fix with a checkpoint, or a rebuild, and keeps the contract, the playground and the group index in step',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
        scope: ['l2_preview'],
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    let prompt;
    if (context.isTest) {
        const testData = JSON.parse(userPrompt || '{}');
        prompt = (testData.prompt || '').trim();
    }
    else {
        const text = stripAgentMention(userPrompt, agent.agentName);
        prompt = isBareMention(text) ? '' : text;
    }
    if (prompt.length < 5) {
        throw new Error(`[${AGENT_NAME}] say what to change and on which molecule, e.g. '@@${AGENT_NAME} ml-data-table: the pagination looks disabled, the buttons are too faded'`);
    }
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: rootPlanSystemPrompt },
                { type: 'human', content: JSON.stringify({ prompt }) },
            ],
            taskTitle: 'Improve molecule',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { flowName: AGENT_NAME, prompt },
        },
    };
    return [addMessageAI];
}
/** PHASE 1 — the classification landed. Plant i1, i2 and the router. */
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const plan = normalizeImRootPlan(step.interaction?.payload?.[0]);
        if (!plan.validInput) {
            return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', plan.reason || 'Invalid input')];
        }
        // Fail here rather than one step later: the classification gate is shared with i1-locate, so
        // prose that names no molecule is refused before anything searches 31 groups for it.
        const gate = checkImClassification(plan);
        if (!gate.ok) {
            return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', gate.errors.join('\n'))];
        }
        const runKey = nmRunKey(plan.runKey || plan.target, 'improve');
        const titles = readTitles(step.interaction?.payload?.[0]);
        return [
            addStep(context, step, {
                planId: 'i1-locate',
                agentName: STEP_AGENTS['i1-locate'],
                title: titles['i1-locate'] || 'i1-locate',
                dependsOn: [],
                runKey,
                first: true,
            }),
            addStep(context, step, {
                planId: 'i2-triage',
                agentName: STEP_AGENTS['i2-triage'],
                title: titles['i2-triage'] || 'i2-triage',
                dependsOn: [imDoneAnchor('i1-locate')],
                runKey,
            }),
            // The router. Handled by this agent's beforePromptStep, which plants the branch.
            addStep(context, step, {
                planId: ROUTER_PLAN_ID,
                agentName: AGENT_NAME,
                title: titles[ROUTER_PLAN_ID] || 'route',
                dependsOn: [imDoneAnchor('i2-triage')],
                runKey,
            }),
        ];
    }
    catch (error) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
/**
 * PHASE 2 — the router. Deterministic, no LLM: it reads i2's result and plants that branch.
 *
 * It is a hook on the ROOT and not a step agent of its own because it holds no logic of its own —
 * it is the routing table, and the table belongs where the tree is planted.
 */
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsedArgs = nmParseStepArgs(args ?? step.prompt);
    if (parsedArgs.planId !== ROUTER_PLAN_ID) {
        throw new Error(`[${AGENT_NAME}] unexpected step '${parsedArgs.planId || '(none)'}' — the root only handles ${ROUTER_PLAN_ID}`);
    }
    const runKey = parsedArgs.runKey || getImRootPlan(context).runKey;
    const decision = readTriageResult(context);
    if (!decision.route) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', 'the triage result could not be read — no route to plant')];
    }
    const route = decision.route;
    const planned = ROUTE_STEPS[route] || [];
    // Route D wrote nothing and has nothing to plant: the rationale IS the answer.
    if (!planned.length) {
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', decision.rationale || `route ${route}: nothing to do`, 'input_output')];
    }
    // A route whose FIRST step is missing cannot start at all. No route is in that state since route A
    // was built (2026-08-14), and the branch stays because it is the one that keeps a half-declared
    // route from reading as a crash.
    //
    // The message carries WHY this route was chosen, and it must. Without it the user is told "the
    // route is not built" and has no way to tell a correct classification from a mis-routing — which is
    // the first thing they need to know, because one of the two is a missing feature and the other is a
    // defect in the triage prompt.
    const firstMissing = NOT_BUILT[planned[0]];
    if (firstMissing) {
        const because = [
            decision.rationale ? `Why route ${route}: ${decision.rationale}` : '',
            decision.definitionElements.length
                ? `What it says changes in the public definition: ${decision.definitionElements.join('; ')}`
                : '',
            'If that reading is wrong — nothing in the public definition (slots, properties, events) actually changes — say so and the request is a route B edit.',
        ].filter(Boolean).join('\n');
        return [nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', `${firstMissing}\n\n${because}`)];
    }
    const runnable = planned.filter(planId => !NOT_BUILT[planId] && STEP_AGENTS[planId]);
    const skipped = planned.filter(planId => NOT_BUILT[planId]);
    const intents = [];
    let previous = null;
    for (const planId of runnable) {
        intents.push(addStep(context, step, {
            planId,
            agentName: STEP_AGENTS[planId],
            title: planId,
            dependsOn: previous ? [imDoneAnchor(previous)] : [],
            runKey,
            first: !previous,
        }));
        previous = planId;
    }
    // No silent truncation: a step this route declares and cannot run is named to the user.
    const note = skipped.length
        ? `route ${route} — ${runnable.join(' → ')}\n${skipped.map(planId => NOT_BUILT[planId]).join('\n')}`
        : `route ${route} — ${runnable.join(' → ')}`;
    intents.push(nmUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', note, 'input_output'));
    return intents;
}
// ---- helpers ----
function addStep(context, parent, args) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parent.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: args.title,
            // 'waiting_human_input' runs immediately; 'waiting_dependency' waits on the anchors.
            status: args.first ? 'waiting_human_input' : 'waiting_dependency',
            nextSteps: [],
            agentName: args.agentName,
            prompt: JSON.stringify({ planId: args.planId, runKey: args.runKey }),
            rags: [],
            planning: {
                planId: args.planId,
                dependsOn: args.dependsOn,
                executionMode: 'sequential',
                executionHost: 'client',
            },
        },
    };
}
/** i2-triage's answer, read from the anchor result it planted. */
function readTriageResult(context) {
    const anchor = imDoneAnchor('i2-triage');
    const found = getAllSteps(context.task?.iaCompressed?.nextSteps).find(item => item.type === 'result' && item.planning?.planId === anchor);
    const parsed = parseMaybeJson(found?.result);
    if (!isRecord(parsed))
        return { route: null, rationale: '', definitionElements: [] };
    const route = String(parsed.route || '').trim().toUpperCase();
    return {
        // ⚠️ DERIVED from ROUTE_STEPS, never a second list. Until 2026-08-18 this was a literal
        // ['A','B','C','D']: route E was added to ImRoute, to the i2 gate and to ROUTE_STEPS, and the
        // triage answered E correctly — then this line rejected it as unreadable and the run died on "no
        // route to plant". One truth, one place; the table below already knows every route there is.
        route: Object.keys(ROUTE_STEPS).includes(route) ? route : null,
        rationale: typeof parsed.rationale === 'string' ? parsed.rationale : '',
        // On route A these ARE the argument: they name the slots, properties or events that changed.
        definitionElements: Array.isArray(parsed.definitionElements)
            ? parsed.definitionElements.filter((item) => typeof item === 'string')
            : [],
    };
}
function readTitles(payload) {
    const parsed = parseMaybeJson(payload);
    const record = isRecord(parsed) ? parsed : {};
    const result = isRecord(parseMaybeJson(record.result)) ? parseMaybeJson(record.result) : record;
    const titles = parseMaybeJson(result.titles);
    if (!isRecord(titles))
        return {};
    const out = {};
    for (const [key, value] of Object.entries(titles)) {
        if (typeof value === 'string' && value.trim())
            out[key] = value.trim();
    }
    return out;
}
const rootPlanSystemPrompt = `
<!-- modelType: classifier -->

You are the entry point of a flow that CHANGES a molecule (a web component) that already exists.

This is a cheap classification. You do not decide what to change or how — later steps do, reading the code. You only read the prose.

Tasks:
1. validInput: false ONLY when the prompt is clearly not a request to change an existing UI component (e.g. it asks to CREATE a new component, or asks for a backend routine, a document, or is unintelligible). When it asks to create something new, say so in reason and name @@agentNewMolecule2. Everything else is validated later by deterministic code — do NOT over-reject.
2. target: the molecule the user is talking about, as 'ml-<name>' or '<group>/ml-<name>'. Copy the name as written; do not correct or complete it. If the prose names no molecule, set validInput false and say so.
3. runKey: a short kebab-case slug naming the intent (e.g. 'pagination-colors', 'detail-slot'). It names a work folder. Max 40 characters, ascii letters/digits/dashes.
4. userLanguage: detect from the prompt ('pt' | 'en' | ...); default 'pt' when ambiguous.
5. title: a SHORT task title in the detected language.
6. titles: SHORT step titles in the detected language for each planId:
   i1-locate (find the molecule and read its files), i2-triage (decide how to handle the change), i2r-route (plan the steps), i3-edit (apply the change), i4-inherit (ask where the fix goes), i5-playground (update the demo page), i6-index (update the group page), i7-summary (summary and coherence report).

## Output format
You must return the object strictly as JSON
export type Output = {
  type: 'flexible';
  result: {
    validInput: boolean;
    reason?: string;
    target: string;
    runKey: string;
    userLanguage: string;
    title: string;
    titles: {
      'i1-locate': string;
      'i2-triage': string;
      'i2r-route': string;
      'i3-edit': string;
      'i4-inherit': string;
      'i5-playground': string;
      'i6-index': string;
      'i7-summary': string;
    };
  };
};
`;
//#endregion OutputSection
