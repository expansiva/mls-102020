/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imTypes.ts" enhancement="_blank"/>
// Types and constants for agentImproveMolecule2. Pure — no I/O, no mls.* access.
//
// Everything about GENERATING artifact content is imported from agentNewMolecule2/helpers
// (nmTemplates, nmFs, nmTypes, nmLayoutAxes). This file only declares what is specific to
// CHANGING a molecule that already exists. See flow.json.principles.
export const IM_MAX_ATTEMPTS = 2;
/** The root agent. Steps find the root's own step (and its classification) by this name. */
export const IM_AGENT_NAME = 'agentImproveMolecule2';
export const IM_AGENT_FOLDER = 'aura/molecules/agentImproveMolecule2';
/** The agent lives in 102020 whatever project it is acting ON. */
export const IM_AGENT_PROJECT = 102020;
/** Artifacts a later step can CREATE when absent — i5-playground and i6-index do exactly that. */
export const IM_CREATABLE_ARTIFACTS = ['less', 'html', 'groupIndex'];
export const IM_PLAN_IDS = [
    'i1-locate',
    'i2-triage',
    'i2a-rebuild-handoff',
    'i4-inherit',
    'i3-edit',
    'i5-playground',
    'i6-index',
    'i7-summary',
];
/**
 * 'i1-locate' -> 'i1-done'. Same anchor convention as agentNewMolecule2: downstream steps depend
 * ONLY on these anchors, never on a step id, so a route that never plants a step never deadlocks
 * a step in another route (flow.json.routes).
 */
export function imDoneAnchor(planId) {
    return `${planId.split('-')[0]}-done`;
}
export function imGateOk() {
    return { ok: true, errors: [] };
}
export function imGateFail(...errors) {
    return { ok: false, errors: errors.filter(Boolean) };
}
