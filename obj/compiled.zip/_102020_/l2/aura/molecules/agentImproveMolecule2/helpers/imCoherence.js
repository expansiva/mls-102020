/// <mls fileReference="_102020_/l2/aura/molecules/agentImproveMolecule2/helpers/imCoherence.ts" enhancement="_blank"/>
/** `slotTags = ['Caption', 'TableHeader', …]` — the truth about what the molecule declares. */
export function readSlotTags(tsSource) {
    const m = tsSource.match(/slotTags[^=]*=\s*\[([^\]]*)\]/);
    if (!m)
        return [];
    return [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]);
}
/** Slot names the molecule's code actually READS, by any of the three paths. */
export function readSlotsUsed(tsSource) {
    const used = new Set();
    const re = /(?:getSlotContent|getSlot|getSlots|getSlotAttr|hasSlot|hasSlotContent|renderLiveSlot|getLiveSlot|getSlotClass)\('([^']+)'/g;
    for (const m of tsSource.matchAll(re))
        used.add(m[1]);
    // renderLiveSlotFrom takes an ELEMENT, not a tag — the slot it projects is whichever one the
    // element came from, so it cannot be attributed by name here. Callers must treat a molecule
    // using it as "reads by element" and not report its slots as unused.
    return [...used];
}
/** True when the molecule projects by element, which makes per-name attribution impossible. */
export function usesElementProjection(tsSource) {
    return /renderLiveSlotFrom\s*\(/.test(tsSource);
}
/** Slot names mentioned in the defs `skill` text. Deliberately loose: the defs is prose. */
export function readSlotsNamedInDefs(defsSource, candidates) {
    const found = [];
    for (const tag of candidates) {
        const re = new RegExp(`\\b${tag}\\b`);
        if (re.test(defsSource))
            found.push(tag);
    }
    return found;
}
/** Slot names the GROUP contract declares, from its creation skill text. */
export function readSlotTagsFromGroupSkill(creationSkill) {
    const m = creationSkill.match(/slotTags\s*=\s*\[([^\]]*)\]/);
    if (!m)
        return [];
    return [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]);
}
/**
 * GATE 1 — the defs must agree with the code and with the group contract.
 *
 * Catches the 2026-08-05 case: the .defs.ts of ml-lazy-record-detail-table described the PREVIOUS
 * design, omitted the `Detail` slot the code was already reading, and asserted "does not introduce
 * slots beyond the groupViewTable contract" while introducing one. Three errors in one file, and
 * nothing in the system noticed.
 */
export function gateDefsCoherence(defsSource, tsSource, groupCreationSkill, reference) {
    const findings = [];
    const declared = readSlotTags(tsSource);
    if (declared.length === 0)
        return findings;
    const namedInDefs = readSlotsNamedInDefs(defsSource, declared);
    for (const tag of declared) {
        if (!namedInDefs.includes(tag)) {
            findings.push({
                gate: 'defs-x-slottags-x-contract',
                severity: 'preexisting',
                reference,
                message: `the code declares the slot '${tag}' and the .defs.ts never mentions it — the playground slot list is generated from the defs, so this produces a demo where '${tag}' is missing`,
            });
        }
    }
    const groupSlots = readSlotTagsFromGroupSkill(groupCreationSkill);
    if (groupSlots.length > 0) {
        for (const tag of declared) {
            if (!groupSlots.includes(tag)) {
                findings.push({
                    gate: 'defs-x-slottags-x-contract',
                    severity: 'preexisting',
                    reference,
                    message: `the slot '${tag}' is not in the group contract — either it belongs in the group's creation.ts, or the molecule should not declare it`,
                });
            }
        }
    }
    // The self-contradiction that hid the other two for weeks.
    const claimsNoNewSlots = /does not introduce slots/i.test(defsSource);
    const introduces = groupSlots.length > 0 && declared.some((t) => !groupSlots.includes(t));
    if (claimsNoNewSlots && introduces) {
        findings.push({
            gate: 'defs-x-slottags-x-contract',
            severity: 'preexisting',
            reference,
            message: `the .defs.ts states it introduces no slots beyond the group contract, and it does — the claim is false as written`,
        });
    }
    return findings;
}
/**
 * GATE 2 — every declared slot must actually be read by the code.
 *
 * Catches the 9 molecules that declare a slot they never read: groupentertext/ml-address-field
 * declares Label, Helper, Prefix and Suffix and reads NONE of them, and 8 more declare `Trigger`
 * without rendering it. Writing <Label> into them does nothing, silently.
 *
 * Two of those 8 carry the reason in a code comment — `'Trigger', // not used in table variant but
 * kept for contract` — so the finding is worded as a question, not an accusation: it may be
 * deliberate, and the user decides.
 */
export function gateDeclaredVsUsed(tsSource, reference) {
    const declared = readSlotTags(tsSource);
    if (declared.length === 0)
        return [];
    const used = readSlotsUsed(tsSource);
    const byElement = usesElementProjection(tsSource);
    return declared
        .filter((tag) => !used.includes(tag))
        .map((tag) => ({
        gate: 'declared-x-used',
        severity: 'preexisting',
        reference,
        message: byElement
            ? `the slot '${tag}' is declared and never read by name; this molecule also projects by element (renderLiveSlotFrom), so confirm it is reached that way — otherwise a consumer writing <${tag}> gets nothing, silently`
            : `the slot '${tag}' is declared and never read — a consumer writing <${tag}> gets nothing, silently. If that is deliberate ("kept for contract"), say so in a comment`,
    }));
}
/**
 * The report rendered by i7-summary.
 *
 * `previousTsSource` marks findings the CURRENT run introduced. v1 does not act differently on
 * them — everything is reported — but the distinction is recorded, because the moment it becomes
 * useful is the moment the agent starts writing incoherent artifacts of its own (flow.json
 * coherenceReport.notCovered).
 */
export function buildCoherenceReport(input, now) {
    const findings = [
        ...gateDefsCoherence(input.defsSource, input.tsSource, input.groupCreationSkill, input.reference),
        ...gateDeclaredVsUsed(input.tsSource, input.reference),
    ];
    if (input.previousTsSource !== undefined && input.previousDefsSource !== undefined) {
        const before = new Set([
            ...gateDefsCoherence(input.previousDefsSource, input.previousTsSource, input.groupCreationSkill, input.reference),
            ...gateDeclaredVsUsed(input.previousTsSource, input.reference),
        ].map((f) => `${f.gate}|${f.message}`));
        for (const finding of findings) {
            if (!before.has(`${finding.gate}|${finding.message}`))
                finding.severity = 'introduced';
        }
    }
    return { findings, checkedAt: now };
}
