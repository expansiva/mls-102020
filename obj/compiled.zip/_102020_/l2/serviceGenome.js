/// <mls fileReference="_102020_/l2/serviceGenome.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getState, setState, subscribe, unsubscribe } from '/_102027_/l2/collabState.js';
import { getTokens } from '/_102027_/l2/designSystemBase.js';
import { skills as listOfGroups } from '/_102020_/l2/skills/molecules/index.js';
import { replaceComponentTag } from '/_102020_/l2/previewTextEditor.js';
import { convertFileToTag } from '/_102020_/l2/utils.js';
import '/_102027_/l2/collabSelectKnob.js';
import '/_102020_/l2/plugins/selectLayout.js';
import '/_102020_/l2/plugins/selectDesignSystem.js';
import '/_102020_/l2/plugins/selectMolecule.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    svcTitle: 'Genome',
    layout: 'Layout',
    designSystem: 'Design System',
    molecules: 'Molecules',
};
const messages = {
    en: message_en,
    pt: {
        svcTitle: 'Genome',
        layout: 'Layout',
        designSystem: 'Design System',
        molecules: 'Moléculas',
    },
    es: {
        svcTitle: 'Genome',
        layout: 'Layout',
        designSystem: 'Design System',
        molecules: 'Moléculas',
    },
};
// ─── Static configs ───────────────────────────────────────────────────
const LAYOUT_CONFIG = {
    key: 'layout',
    min: 0,
    max: 4,
    labels: { 0: 'All', 1: 'standard', 2: 'compact', 3: 'tabs', 4: 'sidebar' },
};
const DISABLED_CONFIG = (key) => ({
    key,
    min: 1,
    max: 1,
    labels: {},
    disabled: true,
});
// ─── Service ─────────────────────────────────────────────────────────
let ServiceGenome102020 = class ServiceGenome102020 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-genome-102020 {
  display: block;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  font-size: 14px;
  height: 100%;
  overflow: auto;
}
service-genome-102020 * {
  box-sizing: border-box;
}
service-genome-102020 .sg-presets::-webkit-scrollbar {
  width: 4px;
}
service-genome-102020 .sg-presets::-webkit-scrollbar-track {
  background: transparent;
}
service-genome-102020 .sg-presets::-webkit-scrollbar-thumb {
  background: theme('colors.gray.300');
  border-radius: 4px;
}
.dark service-genome-102020 .sg-presets::-webkit-scrollbar-thumb,
service-genome-102020.dark .sg-presets::-webkit-scrollbar-thumb {
  background: theme('colors.gray.700');
}
`);
        this.details = {
            icon: '&#xf568',
            state: 'foreground',
            position: 'right',
            tooltip: 'Genome',
            visible: true,
            widget: '_102020_serviceGenome',
            level: [3],
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: undefined,
            onClickMain: this.onClickMain.bind(this),
        };
        // ─── State ────────────────────────────────────────────────────────
        this.msg = message_en;
        this._layoutValue = 0;
        this._currentPageFile = null;
        this._dsValue = 1;
        this._moleculesValue = null;
        this._selectedKnob = 'layout';
        this._dsConfig = {
            key: 'designSystem', min: 1, max: 2, labels: { 1: 'Default', 2: '+' },
        };
        this._moleculesConfig = DISABLED_CONFIG('molecules');
        this._selectedMoleculeGroup = '';
        this._selectedMoleculeGroupDescription = '';
        this._selectedMoleculeFiles = [];
        this._oldSelectedTag = '';
        this._moleculeError = '';
        this._moleculeReplaceMode = 'selected';
        this._actualPage = null;
        this._onFileActionGenome = (ev) => {
            if (!ev.desc)
                return;
            try {
                const fa = JSON.parse(ev.desc);
                if (fa.action !== 'open' || fa.position !== 'left')
                    return;
                // @ts-ignore
                const file = mls.actual[this.level]?.left ?? null;
                this._updateCurrentPage(file);
                // @ts-ignore
                this.requestUpdate();
            }
            catch { /* ignore */ }
        };
    }
    onClickMain(_op) { }
    onServiceClick(_visible, _reinit, _el) {
        this._initDesignSystemKnob();
        // @ts-ignore
        const file = mls.actual[3]?.left ?? null;
        this._updateCurrentPage(file);
    }
    // ─── Preview state subscription ───────────────────────────────────
    handleIcaStateChange(key, value) {
        if (key === 'previewL3.selectedTagName') {
            this._oldSelectedTag = getState('previewL3.selectedTagName');
            this._onPreviewSelectedElementChanged(value);
        }
    }
    // ─── Design System ────────────────────────────────────────────────
    async _initDesignSystemKnob() {
        // @ts-ignore
        if (!mls.actualProject)
            return;
        // @ts-ignore
        const projectDS = await getTokens(mls.actualProject);
        const labels = { 0: 'All' };
        projectDS.forEach((ds, i) => { labels[i + 1] = ds.themeName; });
        labels[projectDS.length + 1] = '+';
        this._dsConfig = {
            key: 'designSystem',
            min: 0,
            max: projectDS.length + 1,
            labels,
        };
        if (this._dsValue === null || this._dsValue > this._dsConfig.max) {
            this._dsValue = 0;
        }
        // @ts-ignore
        this.requestUpdate();
    }
    // ─── Molecule Logic ───────────────────────────────────────────────
    _getMolecules() {
        // @ts-ignore
        const files = Object.values(mls.stor.files);
        const htmlFiles = files.filter((f) => f.extension === '.html' && f.folder.startsWith('molecules') && f.shortName !== 'index');
        const folderMap = new Map();
        for (const f of htmlFiles) {
            const key = f.folder.replace(/^molecules\//, '').toLowerCase();
            if (!folderMap.has(key))
                folderMap.set(key, []);
            folderMap.get(key).push(f);
        }
        return folderMap;
    }
    _isWebComponent(tag) {
        return !!(tag && typeof tag === 'string' && tag.includes('-'));
    }
    _extractGroupFromTag(tag) {
        if (!tag.includes('-'))
            return null;
        return tag.split('-')[0];
    }
    _onPreviewSelectedElementChanged(tag) {
        const isWC = this._isWebComponent(tag);
        const groupsMolecules = this._getMolecules();
        const actualGroup = this._extractGroupFromTag(tag);
        if (!isWC || !actualGroup || !groupsMolecules.get(actualGroup)) {
            this._moleculesConfig = DISABLED_CONFIG('molecules');
            this._moleculesValue = null;
            this._selectedMoleculeGroup = '';
            this._selectedMoleculeGroupDescription = '';
            this._selectedMoleculeFiles = [];
            this._moleculeError = '';
            if (this._selectedKnob === 'molecules')
                this._selectedKnob = 'layout';
            // @ts-ignore
            this.requestUpdate();
            return;
        }
        const widgetsFromGroup = groupsMolecules.get(actualGroup);
        // @ts-ignore
        const groupDescription = listOfGroups.find((item) => item.name.toLowerCase() === actualGroup)?.description || '';
        const labels = {};
        widgetsFromGroup.forEach((item, i) => { labels[i + 1] = item.shortName; });
        this._moleculesConfig = {
            key: 'molecules',
            min: 1,
            max: widgetsFromGroup.length,
            labels,
            disabled: false,
        };
        const currentMoleculeName = tag.replace(`${actualGroup}-`, '');
        let currentIndex = widgetsFromGroup.findIndex((item) => item.shortName.toLowerCase() === currentMoleculeName.toLowerCase());
        if (currentIndex === -1) {
            currentIndex = widgetsFromGroup.findIndex((item) => currentMoleculeName.toLowerCase().includes(item.shortName.toLowerCase()) ||
                item.shortName.toLowerCase().includes(currentMoleculeName.toLowerCase()));
        }
        if (currentIndex !== -1) {
            this._moleculesValue = currentIndex + 1;
        }
        else if (this._moleculesValue === null || !labels[this._moleculesValue]) {
            this._moleculesValue = 1;
        }
        this._selectedMoleculeGroup = actualGroup;
        this._selectedMoleculeGroupDescription = groupDescription;
        this._selectedMoleculeFiles = widgetsFromGroup;
        this._moleculeError = '';
        // @ts-ignore
        this.requestUpdate();
    }
    async _onMoleculesChanged(value) {
        if (!value || !this._actualPage)
            return;
        const selectedFile = this._selectedMoleculeFiles[value - 1];
        if (!selectedFile)
            return;
        this._moleculeError = '';
        const selector = getState('previewL3.selectedElement');
        const newTag = convertFileToTag(selectedFile);
        const tsModel = this._actualPage;
        const source = tsModel.model.getValue();
        const result = replaceComponentTag(this._oldSelectedTag, newTag, source, selector, this._moleculeReplaceMode);
        if (!result.success) {
            this._moleculeError = 'Could not replace the molecule in the source.';
            // @ts-ignore
            this.requestUpdate();
            return;
        }
        tsModel.model.pushEditOperations([], [{ range: tsModel.model.getFullModelRange(), text: result.newSource || source }], () => null);
        this._oldSelectedTag = newTag;
        setState('preview.pendingReselect', newTag);
        // @ts-ignore
        mls.editor.forceModelUpdate(tsModel.model);
    }
    // ─── Knob helpers ─────────────────────────────────────────────────
    get _knobValues() {
        return {
            layout: this._layoutValue,
            designSystem: this._dsValue,
            molecules: this._moleculesValue,
        };
    }
    _getKnobConfig(key) {
        switch (key) {
            case 'layout': return LAYOUT_CONFIG;
            case 'designSystem': return this._dsConfig;
            case 'molecules': return this._moleculesConfig;
            default: return DISABLED_CONFIG(key);
        }
    }
    _setKnobValue(key, value) {
        switch (key) {
            case 'layout':
                this._layoutValue = value;
                break;
            case 'designSystem':
                this._dsValue = value;
                break;
            case 'molecules':
                this._moleculesValue = value;
                this._onMoleculesChanged(value);
                return;
        }
        // @ts-ignore
        this.requestUpdate();
    }
    _onKnobChange(key, e) {
        this._selectedKnob = key;
        this._setKnobValue(key, e.detail.value);
    }
    _onKnobClick(key) {
        this._selectedKnob = key;
        // @ts-ignore
        this.requestUpdate();
    }
    // ─── Lifecycle ────────────────────────────────────────────────────
    _updateCurrentPage(file) {
        this._currentPageFile = file;
        if (!file) {
            this._actualPage = null;
            return;
        }
        // @ts-ignore
        const key = mls.editor.getKeyModel(file.project, file.shortName, file.folder, file.level);
        // @ts-ignore
        this._actualPage = mls.editor.models[key]?.ts ?? null;
    }
    connectedCallback() {
        super.connectedCallback();
        subscribe('previewL3.selectedTagName', this);
        this._initDesignSystemKnob();
        // @ts-ignore
        mls.events.addEventListener([this.level], ['FileAction'], this._onFileActionGenome);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe('previewL3.selectedTagName', this);
        // @ts-ignore
        mls.events.removeEventListener([this.level], ['FileAction'], this._onFileActionGenome);
    }
    firstUpdated() {
        // @ts-ignore
        const file = mls.actual[this.level]?.left ?? null;
        this._updateCurrentPage(file);
    }
    // ─── Render ───────────────────────────────────────────────────────
    createRenderRoot() { return this; }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="flex flex-col min-h-full bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-200">
                ${this._renderKnobRow()}
                ${this._renderDetailsRow()}
            </div>
        `;
    }
    // ─── Knob Row ─────────────────────────────────────────────────────
    _renderKnobRow() {
        return html `
            <div class="
                flex items-center justify-center
                px-2 py-3
                border-b border-gray-200 dark:border-gray-800
                gap-0
            " style="--knob-scale: 0.5">
                ${this._renderKnobItem('layout')}
                ${this._renderKnobItem('designSystem')}
                ${this._renderKnobItem('molecules')}
            </div>
        `;
    }
    _renderKnobItem(key) {
        const config = this._getKnobConfig(key);
        const value = this._knobValues[key];
        const isContext = this._selectedKnob === key;
        const isDisabled = config.disabled ?? false;
        const label = this.msg[key] || key;
        return html `
            <div class="flex flex-col items-center gap-0.5 ${isDisabled ? 'opacity-30' : ''}">
                <collab-select-knob-102027
                    .min=${config.min}
                    .max=${config.max}
                    .value=${value}
                    .step=${1}
                    .active=${true}
                    .disabled=${isDisabled}
                    .selected=${isContext}
                    .showTicks=${false}
                    @knob-change=${(e) => this._onKnobChange(key, e)}
                ></collab-select-knob-102027>

                <div
                    class="flex flex-col items-center gap-0.5 cursor-pointer"
                    @click=${() => this._onKnobClick(key)}
                >
                    <span class="
                        text-[9px] font-semibold uppercase tracking-wider
                        ${isContext
            ? 'text-gray-700 dark:text-gray-200'
            : 'text-gray-400 dark:text-gray-600'}
                        transition-colors duration-200
                    ">${label}</span>

                    <div class="
                        w-full h-0.5 rounded-full
                        transition-all duration-200
                        ${isContext
            ? 'bg-cyan-400 shadow-[0_0_4px_1px_rgba(34,211,238,0.6),0_0_8px_2px_rgba(34,211,238,0.3)]'
            : 'bg-transparent'}
                    "></div>
                </div>
            </div>
        `;
    }
    // ─── Details Row ──────────────────────────────────────────────────
    _renderDetailsRow() {
        return html `
            <div class="flex flex-col flex-1">
                <div class="flex flex-col gap-3 px-4 py-4 flex-1"
                    @select-layout=${(e) => this._setKnobValue('layout', e.detail.value)}
                    @select-molecule=${(e) => this._setKnobValue('molecules', e.detail.value)}
                    @molecule-replace-mode=${(e) => { this._moleculeReplaceMode = e.detail.value; this.requestUpdate(); }}
                >
                    ${this._renderContextStatusArea()}
                </div>
            </div>
        `;
    }
    _renderContextStatusArea() {
        switch (this._selectedKnob) {
            case 'layout':
                return html `
                    <plugins--select-layout-102020
                        .value=${this._layoutValue}
                        .pageFile=${this._currentPageFile}
                    ></plugins--select-layout-102020>
                `;
            case 'designSystem':
                return html `
                    <plugins--select-design-system-102020
                        .projectSelected=${true}
                        .value=${this._dsValue}
                        .labels=${this._dsConfig.labels}
                        .min=${this._dsConfig.min}
                        .max=${this._dsConfig.max}
                    ></plugins--select-design-system-102020>
                `;
            case 'molecules':
                return html `
                    <plugins--select-molecule-102020
                        .group=${this._selectedMoleculeGroup}
                        .description=${this._selectedMoleculeGroupDescription}
                        .files=${this._selectedMoleculeFiles}
                        .value=${this._moleculesValue}
                        .replaceMode=${this._moleculeReplaceMode}
                        .error=${this._moleculeError}
                    ></plugins--select-molecule-102020>
                `;
            default:
                return nothing;
        }
    }
};
__decorate([
    state()
], ServiceGenome102020.prototype, "msg", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_layoutValue", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_currentPageFile", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_dsValue", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_moleculesValue", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_selectedKnob", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_dsConfig", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_moleculesConfig", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_selectedMoleculeGroup", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_selectedMoleculeGroupDescription", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_selectedMoleculeFiles", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_oldSelectedTag", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_moleculeError", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_moleculeReplaceMode", void 0);
__decorate([
    state()
], ServiceGenome102020.prototype, "_actualPage", void 0);
ServiceGenome102020 = __decorate([
    customElement('service-genome-102020')
], ServiceGenome102020);
export { ServiceGenome102020 };
