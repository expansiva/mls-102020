/// <mls fileReference="_102020_/l2/agentAssistant/agentAssistant.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { parseUserText } from '/_102020_/l2/agentAssistant/helpers/asEntry.js';
import { asLabelsFor } from '/_102020_/l2/agentAssistant/helpers/asLabels.js';
import { AS_AGENT_FOLDER, AS_AGENT_PROJECT, actualProject } from '/_102020_/l2/agentAssistant/helpers/asStor.js';
import { AS_AGENT_NAME, AS_INTERPRET_AGENT, AS_INTERPRET_PLAN_ID, } from '/_102020_/l2/agentAssistant/helpers/asIds.js';
import { updateStatusIntent, } from '/_102020_/l2/agentAssistant/helpers/asSteps.js';
export function createAgent() {
    return {
        agentName: AS_AGENT_NAME,
        agentProject: AS_AGENT_PROJECT,
        agentFolder: AS_AGENT_FOLDER,
        agentDescription: 'Runs an action of this app from a sentence: understands it, asks what is missing and confirms before executing',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const userText = context.isTest
        ? String(JSON.parse(userPrompt || '{}').prompt || '').trim()
        : parseUserText(userPrompt, agent.agentName, raw => mls.common.safeParseArgs(raw));
    const labels = asLabelsFor(navigatorLanguage());
    if (!userText)
        return statusTask(agent, context, labels.emptyPrompt);
    const project = actualProject();
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentAssistant bootstrap. The root LLM is skipped (skipRootLLM); the interpret step makes the call.' },
                { type: 'human', content: userText },
            ],
            taskTitle: userText.length > 60 ? `${userText.slice(0, 57)}...` : userText,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { flowName: AS_AGENT_NAME, userText, project: String(project) },
        },
    };
    const interpret = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: labels.stepInterpret,
        status: 'waiting_human_input',
        nextSteps: [],
        agentName: AS_INTERPRET_AGENT,
        prompt: JSON.stringify({ planId: AS_INTERPRET_PLAN_ID }),
        rags: [],
        planning: { planId: AS_INTERPRET_PLAN_ID, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, rootChildIntent(context, interpret)];
}
// With skipRootLLM the root has no call of its own: its hooks only close it.
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    return [updateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    return [updateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
function rootChildIntent(context, step) {
    // the task does not exist yet: the backend binds these to the task the add-message-ai creates
    return { type: 'add-step', messageId: '', threadId: context.message.threadId, taskId: '', parentStepId: 1, step };
}
function statusTask(agent, context, message) {
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{ type: 'system', content: 'agentAssistant status.' }, { type: 'human', content: message }],
            taskTitle: message.slice(0, 60),
            threadId: context.message.threadId,
            userMessage: context.message.content,
        },
    };
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: message,
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, rootChildIntent(context, result)];
}
function navigatorLanguage() {
    return typeof navigator !== 'undefined' && typeof navigator.language === 'string' ? navigator.language : 'en';
}
