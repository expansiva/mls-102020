/// <mls fileReference="_102020_/l2/agentAssistant/helpers/asManual.ts" enhancement="_blank"/>
import { asArray, asRecord, asString } from '/_102020_/l2/agentAssistant/helpers/asCatalog.js';
import { extractExportedObject } from '/_102020_/l2/agentAssistant/helpers/asSource.js';
export function buildManual(sources) {
    return { modules: sources.map(readModule).filter((item) => !!item) };
}
function readModule(sources) {
    const moduleDef = asRecord(extractExportedObject(sources.moduleDef));
    const access = asRecord(extractExportedObject(sources.access));
    const actors = asArray(access.actors).map(asRecord).map(actor => ({
        id: asString(actor.actorId),
        title: asString(actor.title) || asString(actor.actorId),
        description: asString(actor.description),
    })).filter(actor => actor.id);
    const rulesRaw = asRecord(asRecord(extractExportedObject(sources.rules)).rules);
    const rules = Object.entries(rulesRaw)
        .map(([id, value]) => ({ id, text: typeof value === 'string' ? value : asString(asRecord(value).statement) || asString(asRecord(value).description) }))
        .filter(rule => rule.text);
    const journeys = sources.journeys.map(text => readJourney(sources.module, text)).filter((item) => !!item);
    const pages = readPages(sources, actors);
    const title = asString(moduleDef.title);
    if (!title && !pages.length && !journeys.length)
        return null;
    return { module: sources.module, title: title || sources.module, actors, rules, pages, journeys };
}
function readJourney(module, text) {
    const raw = asRecord(extractExportedObject(text));
    const journeyId = asString(raw.journeyId);
    const business = asRecord(raw.business);
    if (!journeyId || !asString(business.title))
        return null;
    const outcome = asRecord(business.outcome);
    return {
        module,
        journeyId,
        title: asString(business.title),
        actor: asString(business.actorRef),
        goal: asString(business.goal),
        steps: asArray(business.steps).map(asRecord).map(step => ({
            title: asString(step.title),
            description: asString(step.description),
            kind: asString(step.kind),
            entity: asString(step.entity),
            effect: asString(step.effect),
            transitionRef: asString(step.transitionRef),
        })),
        outcome: asString(outcome.statement),
        evidence: asArray(outcome.evidence).map(asString).filter(Boolean),
    };
}
function readPages(sources, actors) {
    const menu = asRecord(safeJson(sources.menuJson));
    const authorities = asRecord(menu.authorities);
    const actorTitle = (actorKey) => {
        const id = actorKey.replace(/^actor:/, '');
        return actors.find(actor => actor.id === id)?.title || id;
    };
    const visibleTo = (pageId) => Object.entries(authorities)
        .filter(([, pageIds]) => asArray(pageIds).includes(pageId))
        .map(([actorKey]) => actorTitle(actorKey));
    const routesByPage = new Map();
    for (const text of sources.controllers) {
        const data = asRecord(asRecord(extractExportedObject(text)).data);
        const pageId = asString(data.pageId);
        if (!pageId)
            continue;
        routesByPage.set(pageId, asArray(data.handlers).map(handler => asString(asRecord(handler).route)).filter(Boolean));
    }
    const defsByPage = new Map(sources.pageDefs.map(item => [item.pageId, asRecord(asRecord(extractExportedObject(item.text)).definition ?? extractExportedObject(item.text))]));
    const pages = [];
    const walk = (nodes, hub) => {
        for (const rawNode of nodes) {
            const node = asRecord(rawNode);
            const kind = asString(node.kind);
            const id = asString(node.id);
            const label = asString(node.label) || id;
            if (kind === 'hub') {
                walk(asArray(node.children), label);
                continue;
            }
            if (kind !== 'page' || !id)
                continue;
            const def = defsByPage.get(id) || {};
            pages.push({
                module: sources.module,
                pageId: id,
                label,
                hub,
                texts: asArray(node.organisms).map(item => asString(asRecord(item).text)).filter(Boolean),
                actors: visibleTo(id),
                intent: asString(def.intent),
                sections: asArray(def.sections).map(section => asString(asRecord(section).purpose)).filter(Boolean),
                routes: routesByPage.get(id) || [],
            });
        }
    };
    walk(asArray(menu.tree), '');
    return pages;
}
// ---- what the interpret call sees: short, every module (with or without backend) ----
export function manualIndex(manual) {
    return {
        modules: manual.modules.map(item => ({ module: item.module, title: item.title })),
        pages: manual.modules.flatMap(item => item.pages.map(page => ({ module: item.module, pageId: page.pageId, label: page.hub ? `${page.hub} › ${page.label}` : page.label }))),
        journeys: manual.modules.flatMap(item => item.journeys.map(journey => ({ module: item.module, journeyId: journey.journeyId, title: journey.title, actor: actorTitleOf(item, journey.actor) }))),
    };
}
export function hasManualContent(manual) {
    return !!manual && manual.modules.length > 0;
}
// ---- what the answer call receives: only the chosen items, with everything they need ----
export const AS_MANUAL_CONTEXT_MAX = 20000;
export function manualContext(manual, selection, catalog) {
    const empty = !selection.modules.length && !selection.pages.length && !selection.journeys.length;
    if (empty)
        return clip(JSON.stringify({ overview: manual.modules.map(overviewOf) }, null, 1));
    const journeys = selection.journeys
        .map(ref => findModule(manual, ref.module)?.journeys.find(item => item.journeyId === ref.journeyId))
        .filter((item) => !!item);
    const pageKeys = new Set(selection.pages.map(ref => `${ref.module}/${ref.pageId}`));
    // a journey brings the screens where its actions happen
    for (const journey of journeys) {
        for (const page of pagesOfJourney(manual, journey, catalog))
            pageKeys.add(`${page.module}/${page.pageId}`);
    }
    const moduleIds = new Set([...selection.modules, ...journeys.map(item => item.module), ...[...pageKeys].map(key => key.split('/')[0])]);
    const modules = [...moduleIds].map(id => findModule(manual, id)).filter((item) => !!item).map(module => ({
        module: module.module,
        title: module.title,
        actors: module.actors.map(actor => ({ title: actor.title, does: actor.description })),
        rules: module.rules.map(rule => rule.text),
        screens: module.pages
            .filter(page => pageKeys.has(`${page.module}/${page.pageId}`) || (selection.modules.includes(module.module) && !pageKeys.size))
            .map(page => pageDetail(module, page, catalog)),
        journeys: journeys.filter(item => item.module === module.module).map(journey => ({
            title: journey.title,
            who: actorTitleOf(module, journey.actor),
            goal: journey.goal,
            steps: journey.steps.map(step => ({ title: step.title, description: step.description })),
            whereTheActionsHappen: pagesOfJourney(manual, journey, catalog).map(page => screenName(page)),
            outcome: journey.outcome,
            youWillSee: journey.evidence,
        })),
        ...(selection.modules.includes(module.module) ? { allJourneys: module.journeys.map(item => item.title) } : {}),
    }));
    return clip(JSON.stringify({ modules }, null, 1));
}
export function pagesOfJourney(manual, journey, catalog) {
    const module = findModule(manual, journey.module);
    if (!module || !catalog)
        return [];
    const routes = new Set();
    for (const step of journey.steps) {
        // the contract's `writes` uses the journey's own vocabulary: Entity.create | Entity.update | Entity.<transition>
        const operation = step.transitionRef || step.effect;
        if (!step.entity || !operation)
            continue;
        const writes = `${step.entity}.${operation}`;
        for (const command of catalog.commands) {
            if (command.module === journey.module && command.writes === writes)
                routes.add(command.route);
        }
    }
    return module.pages.filter(page => page.routes.some(route => routes.has(route)));
}
function pageDetail(module, page, catalog) {
    const commands = (catalog?.commands || []).filter(command => page.routes.includes(command.route));
    return {
        screen: screenName(page),
        whoSeesIt: page.actors,
        whatItIsFor: page.intent || page.texts.join(' '),
        parts: page.sections.length ? page.sections : page.texts,
        actions: commands.map(command => actionOf(command)),
    };
}
function actionOf(command) {
    return {
        does: command.purpose,
        fields: command.inputs.filter(input => input.role !== 'version' && !(input.role === 'ref' && input.path === 'id')).map(input => ({
            field: input.label,
            required: input.required,
            ...(input.enumValues.length ? { options: input.enumValues.map(item => item.label) } : {}),
            ...(input.role === 'ref' ? { pick: input.ref } : {}),
        })),
    };
}
function overviewOf(module) {
    return {
        module: module.title,
        who: module.actors.map(actor => actor.title),
        screens: module.pages.map(page => screenName(page)),
        tasks: module.journeys.map(journey => journey.title),
    };
}
function screenName(page) {
    return page.hub ? `${page.hub} › ${page.label}` : page.label;
}
function actorTitleOf(module, actorId) {
    return module.actors.find(actor => actor.id === actorId)?.title || actorId;
}
function findModule(manual, module) {
    return manual.modules.find(item => item.module === module);
}
function clip(text) {
    return text.length <= AS_MANUAL_CONTEXT_MAX ? text : `${text.slice(0, AS_MANUAL_CONTEXT_MAX)}... (truncated)`;
}
function safeJson(text) {
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
