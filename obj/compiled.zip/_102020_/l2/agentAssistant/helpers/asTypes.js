/// <mls fileReference="_102020_/l2/agentAssistant/helpers/asTypes.ts" enhancement="_blank"/>
export const AS_STATE_SCHEMA = 'agentAssistant-state-v4';
