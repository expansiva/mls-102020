/// <mls fileReference="_102020_/l2/agentAssistant/helpers/asBff.ts" enhancement="_blank"/>
export const execBffCall = async (routine, params) => {
    let response;
    try {
        response = await fetch('/execBff', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ routine, params, meta: { source: 'http' } }),
        });
    }
    catch (error) {
        return unavailable(error instanceof Error ? error.message : String(error));
    }
    let body;
    try {
        body = await response.json();
    }
    catch {
        return unavailable(`HTTP ${response.status} without a JSON body (is this page served by the app runtime?)`);
    }
    return normalizeBffResponse(body, response.status);
};
export function normalizeBffResponse(body, status) {
    if (typeof body !== 'object' || body === null)
        return unavailable(`HTTP ${status}: unexpected response`);
    const record = body;
    const rawError = record.error;
    const error = typeof rawError === 'object' && rawError !== null
        ? {
            code: String(rawError.code ?? 'ERROR'),
            message: String(rawError.message ?? ''),
            details: rawError.details,
        }
        : null;
    return { ok: record.ok === true, data: record.data ?? null, error: record.ok === true ? null : error || { code: `HTTP_${status}`, message: '' } };
}
function unavailable(message) {
    return { ok: false, data: null, error: { code: 'BFF_UNAVAILABLE', message } };
}
