/// <mls fileReference="_102020_/l2/agentNewSolution2/agentNewSolution2Requirements.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAgentStepByAgentName, getAllSteps, notifyTaskChange } from '/_102027_/l2/aiAgentHelper.js';
import { getExistingModuleFolders } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { getRecommendOutput, } from '/_102020_/l2/agentNewSolution2/agentNs2Recommend.js';
export function createAgent() {
    return {
        agentName: 'agentNewSolution2Requirements',
        agentProject: 102020,
        agentFolder: 'agentNewSolution2',
        agentDescription: 'Collect initial requirements + implementation decisions for Stage 1',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    if (!context.task)
        throw new Error(`(${agent.agentName})[beforePromptStep] task invalid`);
    const initialPlan = getInitialPlan(context);
    return [{
            type: 'prompt_ready',
            args,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt: systemPrompt.replace('{{folders}}', Array.from(getExistingModuleFolders()).join(', ')),
            humanPrompt: `## Initial user prompt\n${initialPlan.userPrompt}\n\n## Initial plan\n${JSON.stringify(initialPlan, null, 2)}\n`,
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error('[afterPromptStep] invalid params');
    const payload = step.interaction?.payload?.[0];
    if (!payload)
        throw new Error('[afterPromptStep] missing payload');
    if (payload.type === 'result')
        return [updateStatus(context, parentStep, step, hookSequential, 'failed')];
    if (payload.type !== 'clarification' || !payload.json)
        throw new Error(`[afterPromptStep] invalid payload: ${JSON.stringify(payload)}`);
    return []; // keep the clarification payload; beforeClarificationStep renders it
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error('[beforeClarificationStep] invalid task');
    await import('/_102025_/l2/widgetQuestionsForClarification.js');
    const parsed = parseJson(json);
    const planId = step.planning?.planId || parsed.planId;
    if (planId === 'req-implementation-decisions')
        return renderDecisions(agent, context, parentStep, step, hookSequential);
    const div = document.createElement('div');
    const el = document.createElement('widget-questions-for-clarification-102025');
    el.value = {
        taskId: context.task.PK,
        stepId: step.stepId,
        title: parsed.title,
        legends: parsed.legends || [],
        userLanguage: parsed.userLanguage || '',
        questions: parsed.questions,
    };
    el.setAttribute('mode', 'new');
    el.addEventListener('clarification-finish', (event) => {
        const { detail } = event;
        applyClarificationResult(agent, context, parentStep, step, hookSequential, detail.value, detail.action).catch(error => console.error(`[${agent.agentName}] ${error?.message || error}`));
    });
    div.appendChild(el);
    return div;
}
function renderDecisions(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error('[renderDecisions] invalid task');
    const clarification = buildDecisionClarification(getRecommendOutput(context));
    const div = document.createElement('div');
    const el = document.createElement('widget-questions-for-clarification-102025');
    el.value = {
        taskId: context.task.PK,
        stepId: step.stepId,
        title: clarification.title,
        legends: clarification.legends,
        userLanguage: clarification.userLanguage,
        questions: clarification.questions,
    };
    el.setAttribute('mode', 'new');
    el.addEventListener('clarification-finish', (event) => {
        const { detail } = event;
        applyDecisionResult(agent, context, parentStep, step, hookSequential, detail.value, detail.action).catch(error => console.error(`[${agent.agentName}] ${error?.message || error}`));
    });
    div.appendChild(el);
    return div;
}
async function applyClarificationResult(agent, context, parentStep, step, hookSequential, value, action) {
    if (!context.task)
        throw new Error('[applyClarificationResult] task invalid');
    const status = action === 'continue' ? 'completed' : 'failed';
    const intents = [updateStatus(context, parentStep, step, hookSequential, status)];
    if (action === 'continue') {
        const answer = normalizeAnswer(value);
        intents.unshift(resultStep(context, parentStep, 'req-clarification-answer', ['org-requirements'], answer.title, answer));
        const planned = findStepByPlanId(context.task, 'req-clarification-answer');
        if (planned)
            intents.push(updateStatus(context, parentStep, planned, hookSequential, 'completed'));
    }
    await applyAndContinue(agent, context, intents, action);
}
async function applyDecisionResult(agent, context, parentStep, step, hookSequential, value, action) {
    if (!context.task)
        throw new Error('[applyDecisionResult] task invalid');
    const status = action === 'continue' ? 'completed' : 'failed';
    const intents = [updateStatus(context, parentStep, step, hookSequential, status)];
    if (action === 'continue') {
        const decision = normalizeDecision(value, getRecommendOutput(context));
        intents.unshift(resultStep(context, parentStep, 'req-implementation-decisions', ['req-recommend-implementations'], decision.title, decision));
    }
    await applyAndContinue(agent, context, intents, action);
}
async function applyAndContinue(agent, context, intents, action) {
    const response = await mls.api.msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200)
        throw new Error(response?.msg || 'Error applying clarification result');
    const ret = response;
    context.task = ret.task;
    if (ret.message)
        context.message = ret.message;
    notifyTaskChange(context);
    const queue = context.task.iaCompressed?.queueFrontEnd || [];
    if (action === 'continue' && queue.some(hook => hook.type !== 'pooling')) {
        const { continuePoolingTask } = await import('/_102027_/l2/aiAgentOrchestration.js');
        await continuePoolingTask(context);
    }
}
// ── intents ────────────────────────────────────────────────────────────────────
function resultStep(context, parentStep, planId, dependsOn, stepTitle, result) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify(result, null, 2),
            planning: { planId, dependsOn, executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
function updateStatus(context, parentStep, step, hookSequential, status) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
    };
}
// ── decision building ────────────────────────────────────────────────────────────
function buildDecisionClarification(output) {
    const questions = {};
    output.result.recommendations.forEach((recommendation, index) => {
        questions[questionId(recommendation, index)] = {
            type: 'select',
            question: `${recommendation.title} [${recommendation.artifactType}]\n${recommendation.description}\nMotivo: ${recommendation.reason}\nPadrao: ${recommendation.defaultPriority}.`,
            answer: recommendation.defaultPriority || recommendation.priority,
            options: [
                { id: 'now', label: 'now' },
                { id: 'soon', label: 'soon' },
                { id: 'later', label: 'later' },
                { id: 'never', label: 'never' },
            ],
        };
    });
    return {
        title: 'Decisoes de implementacao',
        userLanguage: '',
        questions,
        legends: ['Revise as recomendacoes e ajuste a prioridade.', 'Use "never" para recusar uma recomendacao nesta solucao.'],
    };
}
function normalizeDecision(value, output) {
    const decisions = output.result.recommendations.map((recommendation, index) => {
        const decidedPriority = normalizePriority(value.questions?.[questionId(recommendation, index)]?.answer, recommendation.defaultPriority || recommendation.priority);
        return {
            recommendationId: recommendation.recommendationId,
            artifactType: recommendation.artifactType,
            title: recommendation.title,
            decidedPriority,
            accepted: decidedPriority !== 'never',
            reason: recommendation.reason,
        };
    });
    return {
        title: value.title || 'Decisoes de implementacao',
        userLanguage: value.userLanguage || '',
        decisions,
    };
}
function questionId(recommendation, index) {
    return `recommendation_${index}_${recommendation.recommendationId.replace(/[^a-zA-Z0-9]+/g, '_').toLowerCase() || 'item'}`;
}
function normalizePriority(value, fallback) {
    return value === 'now' || value === 'soon' || value === 'later' || value === 'never' ? value : fallback;
}
function normalizeAnswer(value) {
    return {
        title: value.title || 'Initial requirements answer',
        userLanguage: value.userLanguage || '',
        answers: Object.fromEntries(Object.entries(value.questions || {}).map(([key, question]) => [key, question.answer ?? ''])),
    };
}
// ── helpers / types ────────────────────────────────────────────────────────────
function parseJson(value) {
    if (typeof value !== 'string')
        return value || {};
    const trimmed = value.trim();
    return trimmed ? JSON.parse(trimmed) : {};
}
function findStepByPlanId(task, planId) {
    return getAllSteps(task.iaCompressed?.nextSteps).find(step => step.planning?.planId === planId) || null;
}
function getInitialPlan(context) {
    if (!context.task)
        throw new Error('[getInitialPlan] task invalid');
    const rootStep = getAgentStepByAgentName(context.task, 'agentNewSolution2');
    const payload = rootStep?.interaction?.payload?.[0];
    const result = payload?.type === 'flexible' ? payload.result : undefined;
    if (!result || typeof result.userPrompt !== 'string')
        throw new Error('[getInitialPlan] initial plan not found');
    return result;
}
export function getRequirementsClarificationAnswer(context) {
    if (!context.task)
        throw new Error('[getRequirementsClarificationAnswer] task invalid');
    const reqStep = getAgentStepByAgentName(context.task, 'agentNewSolution2Requirements');
    const answerStep = (reqStep?.nextSteps || []).find(s => s.type === 'result' && s.planning?.planId === 'req-clarification-answer');
    if (!answerStep?.result)
        throw new Error('[getRequirementsClarificationAnswer] clarification answer not found');
    return JSON.parse(answerStep.result);
}
export function getImplementationDecisionResult(context) {
    if (!context.task)
        throw new Error('[getImplementationDecisionResult] task invalid');
    const step = getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.type === 'result' && item.planning?.planId === 'req-implementation-decisions' && item.result);
    if (!step?.result)
        throw new Error('[getImplementationDecisionResult] implementation decisions not found');
    const parsed = JSON.parse(step.result);
    if (!parsed || !Array.isArray(parsed.decisions))
        throw new Error('[getImplementationDecisionResult] invalid implementation decisions');
    return parsed;
}
export function hasAcceptedNow(decisions, artifactType) {
    return decisions.decisions.some(item => item.artifactType === artifactType && item.accepted && item.decidedPriority === 'now');
}
const systemPrompt = `
<!-- modelType: codepro -->

You are the first requirements clarification agent for the collab.codes "newSolution2" flow (Stage 1).

Generate ONE small first clarification. Do not ask about architecture, plugins, workflows, MDM, or
implementation details yet. Use the same language as the user. Every question needs a useful default
in its "answer" field.

If the request is invalid for a module or solution, return:
{ "type": "result", "result": "Short error message in the user's language" }

For a valid request, return:
{
  "type": "clarification",
  "json": {
    "userLanguage": "ISO code such as pt-BR or en",
    "title": "Clarification 1/2",
    "questions": {
      "languages": { "type": "open", "question": "", "answer": "" },
      "moduleName": { "type": "open", "question": "", "answer": "" },
      "roles": { "type": "open", "question": "", "answer": "" },
      "publicTarget": { "type": "open", "question": "", "answer": "" },
      "mainGoal": { "type": "open", "question": "", "answer": "" },
      "openQuestion1": { "type": "open", "question": "", "answer": "" }
    },
    "legends": [ "Localized note: this is the first clarification.", "Localized note: detailed planning comes later." ]
  }
}

Existing modules: {{folders}}

## Output format
Return only valid JSON in the structure:
export type Output =
  | { type: 'clarification'; json: RequirementsClarification }
  | { type: 'result'; result: string };

export interface RequirementsClarification {
  userLanguage: string;
  title: string;
  questions: Record<string, RequirementsQuestion>;
  legends: string[];
}

export interface RequirementsQuestion {
  type: 'open' | 'select' | 'boolean';
  question: string;
  answer: string | boolean;
  options?: { id: string; label: string }[];
}
`;
