/// <mls fileReference="_102020_/l2/agentNewSolution2/agentNewSolution2Domain.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
export function createAgent() {
    return {
        agentName: 'agentNewSolution2Domain',
        agentProject: 102020,
        agentFolder: 'agentNewSolution2',
        agentDescription: 'Container for the domain phase (ontology + rules)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error('[agentNewSolution2Domain] task invalid');
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed')];
}
