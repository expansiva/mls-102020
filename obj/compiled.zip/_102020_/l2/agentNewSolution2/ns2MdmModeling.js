/// <mls fileReference="_102020_/l2/agentNewSolution2/ns2MdmModeling.ts" enhancement="_blank"/>
import { L4_CONTEXT_ORIGIN_CATALOG } from '/_102029_/l2/runtimeConfigTypes.js';
export const MDM_SUBTYPES = [
    'Person',
    'Company',
    'Product',
    'Service',
    'Location',
    'AssetGeneric',
    'AssetVehicle',
    'AssetProperty',
    'AssetEquipment',
    'Animal',
    'BankAccount',
    'Document',
    'ContactChannel',
];
export const MDM_RELATIONSHIP_TYPES = [
    'Owns',
    'Employs',
    'OffersProduct',
    'OffersService',
    'StocksAt',
    'Teaches',
    'HappensAt',
    'FranchiseOf',
    'BelongsToGroup',
    'PartOfUnit',
    'ManagedBy',
    'ReportsTo',
    'AssignedTo',
    'Attends',
    'SuppliesProduct',
    'PartnersWith',
    'Family',
    'GuardianOf',
    'CustomerOf',
    'SupplierOf',
    'MemberOf',
    'HoldsAccount',
    'SubsidiaryOf',
    'LocatedAt',
    'Signed',
    'HasContact',
];
export const STRUCTURAL_RELATIONSHIP_TYPES = ['partOf'];
export const L4_RELATIONSHIP_TYPES = [...MDM_RELATIONSHIP_TYPES, ...STRUCTURAL_RELATIONSHIP_TYPES];
export const MDM_ANCHOR_SOURCES = ['ontologyEntity', 'runtimeContext'];
export const MDM_RUNTIME_ANCHOR_ORIGIN_REFS = [
    ...L4_CONTEXT_ORIGIN_CATALOG.businessContext,
    ...L4_CONTEXT_ORIGIN_CATALOG.currentWorkspace,
];
export function collectMdmModelingIssues(input) {
    const issues = [];
    const entityIds = new Set(Object.keys(input.entities || {}));
    for (const [entityId, raw] of Object.entries(input.entities || {})) {
        if (!isRecord(raw))
            continue;
        validateEntity(input.moduleName, entityId, raw, entityIds, issues);
    }
    for (const raw of input.relationships || [])
        validateRelationship(raw, entityIds, issues);
    return issues;
}
function validateEntity(moduleName, entityId, entity, entityIds, issues) {
    const ownership = readString(entity.ownership);
    const kind = readString(entity.kind);
    const isMdm = ownership === 'mdmOwned' || kind === 'mdm';
    const where = `entity ${entityId}`;
    if (!readString(entity.modelingDecision)) {
        issues.push({ severity: 'error', code: 'entity.modelingDecision.missing', message: `${where}: missing modelingDecision explaining why it is MDM, embedded or local/module-owned` });
    }
    if (!isMdm) {
        if (readString(entity.moduleType) || readString(entity.mdmSubtype) || entity.anchor !== undefined) {
            issues.push({ severity: 'warning', code: 'entity.mdmMetadata.unused', message: `${where}: MDM metadata is present but entity is not kind=mdm/ownership=mdmOwned` });
        }
        return;
    }
    if (ownership !== 'mdmOwned') {
        issues.push({ severity: 'error', code: 'mdm.ownership.invalid', message: `${where}: kind=mdm must use ownership=mdmOwned` });
    }
    if (kind !== 'mdm') {
        issues.push({ severity: 'error', code: 'mdm.kind.invalid', message: `${where}: ownership=mdmOwned must use kind=mdm` });
    }
    const moduleType = readString(entity.moduleType);
    if (!moduleType) {
        issues.push({ severity: 'error', code: 'mdm.moduleType.missing', message: `${where}: MDM entity must declare moduleType in <moduleId>.<type> format` });
    }
    else {
        if (!/^[a-z][A-Za-z0-9]*\.[A-Z][A-Za-z0-9]*$/.test(moduleType)) {
            issues.push({ severity: 'error', code: 'mdm.moduleType.invalid', message: `${where}: moduleType '${moduleType}' must be formatted as <moduleId>.<PascalType>` });
        }
        if (moduleName && !moduleType.startsWith(`${moduleName}.`)) {
            issues.push({ severity: 'error', code: 'mdm.moduleType.moduleMismatch', message: `${where}: moduleType '${moduleType}' must start with '${moduleName}.'` });
        }
    }
    const subtype = readString(entity.mdmSubtype);
    if (!subtype) {
        issues.push({ severity: 'error', code: 'mdm.subtype.missing', message: `${where}: MDM entity must declare mdmSubtype` });
    }
    else if (!isMdmSubtype(subtype)) {
        issues.push({ severity: 'error', code: 'mdm.subtype.invalid', message: `${where}: mdmSubtype '${subtype}' is not a 102034 MDM subtype` });
    }
    const requiresAnchor = entity.requiresAnchor === true;
    if (requiresAnchor && !isRecord(entity.anchor)) {
        issues.push({ severity: 'error', code: 'mdm.anchor.missing', message: `${where}: requiresAnchor=true but no anchor was declared` });
    }
    if (isRecord(entity.anchor))
        validateAnchor(where, entity.anchor, entityIds, issues);
}
function validateAnchor(where, anchor, entityIds, issues) {
    const entityId = readString(anchor.entityId);
    const relationshipType = readString(anchor.relationshipType);
    const source = readString(anchor.source) || 'ontologyEntity';
    const originRef = readString(anchor.originRef);
    if (!isMdmAnchorSource(source)) {
        issues.push({ severity: 'error', code: 'mdm.anchor.source.invalid', message: `${where}: anchor.source '${source || '?'}' must be one of ${MDM_ANCHOR_SOURCES.join(', ')}` });
    }
    if (!entityId) {
        issues.push({ severity: 'error', code: 'mdm.anchor.entity.missing', message: `${where}: anchor.entityId is required as the semantic anchor label` });
    }
    else if (source === 'ontologyEntity' && !entityIds.has(entityId)) {
        issues.push({ severity: 'error', code: 'mdm.anchor.entity.unknown', message: `${where}: anchor.entityId '${entityId}' does not resolve to an ontology entity` });
    }
    if (source === 'runtimeContext') {
        if (!originRef) {
            issues.push({ severity: 'error', code: 'mdm.anchor.origin.missing', message: `${where}: runtimeContext anchor must declare originRef` });
        }
        else if (!isRuntimeAnchorOriginRef(originRef)) {
            issues.push({ severity: 'error', code: 'mdm.anchor.origin.invalid', message: `${where}: runtimeContext originRef '${originRef}' must be one of ${MDM_RUNTIME_ANCHOR_ORIGIN_REFS.join(', ')}` });
        }
    }
    if (!relationshipType || !isMdmRelationshipType(relationshipType)) {
        issues.push({ severity: 'error', code: 'mdm.anchor.relationship.invalid', message: `${where}: anchor.relationshipType '${relationshipType || '?'}' must be a 102034 MDM relationship type` });
    }
    if (!readString(anchor.description)) {
        issues.push({ severity: 'error', code: 'mdm.anchor.description.missing', message: `${where}: anchor must explain why this relationship scopes the MDM entity` });
    }
}
function validateRelationship(raw, entityIds, issues) {
    if (!isRecord(raw))
        return;
    const relationshipId = readString(raw.relationshipId) || '?';
    const type = readString(raw.type);
    if (!type || !isL4RelationshipType(type)) {
        issues.push({ severity: 'error', code: 'relationship.type.invalid', message: `relationship ${relationshipId}: type '${type || '?'}' must be a known MDM relationship type or structural partOf` });
    }
    for (const key of ['fromEntity', 'toEntity']) {
        const value = readString(raw[key]);
        if (!value || !entityIds.has(value)) {
            issues.push({ severity: 'error', code: 'relationship.entity.unknown', message: `relationship ${relationshipId}: ${key} '${value || '?'}' does not resolve to an ontology entity` });
        }
    }
    if (!readString(raw.decisionReason)) {
        issues.push({ severity: 'error', code: 'relationship.decisionReason.missing', message: `relationship ${relationshipId}: missing decisionReason explaining why '${type || '?'}' is the right relationship` });
    }
}
function isMdmSubtype(value) {
    return MDM_SUBTYPES.includes(value);
}
function isMdmRelationshipType(value) {
    return MDM_RELATIONSHIP_TYPES.includes(value);
}
function isL4RelationshipType(value) {
    return L4_RELATIONSHIP_TYPES.includes(value);
}
function isMdmAnchorSource(value) {
    return MDM_ANCHOR_SOURCES.includes(value);
}
export function isRuntimeAnchorOriginRef(value) {
    return MDM_RUNTIME_ANCHOR_ORIGIN_REFS.includes(value);
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : '';
}
