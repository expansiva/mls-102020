/// <mls fileReference="_102020_/l2/agentNewSolution2/agentNewSolution2Final.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAgentStepByAgentName, getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { createUpdateStatusIntent, getInitialPlanSummary, isRecord, optionalString } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
import { clearRunArtifacts, getApprovedModuleName, journeysFileInfo, readBehaviorHealthReport, readOperationDefs, readWorkflowDefs, saveDefsArtifact, writeProcessRun, } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution2/ns2Plan.js';
import { computeBehaviorHealthReport } from '/_102020_/l2/agentNewSolution2/agentValidateBehaviorModel.js';
import { getImplementationDecisionResult } from '/_102020_/l2/agentNewSolution2/agentNewSolution2Requirements.js';
const AGENT_NAME = 'agentNewSolution2Final';
const ROOT_AGENT_NAME = 'agentNewSolution2';
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102020, agentFolder: 'agentNewSolution2', agentDescription: 'Stage-1 handoff: freeze, record the run and finish automatically', visibility: 'private', beforePromptStep, openStepView };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error('[agentNewSolution2Final] task invalid');
    // This agent is wired ONLY to the final-resume step (the org-handoff container is a separate
    // no-LLM agent so it does not expose openStepView). The planId guard stays defensive.
    const planId = step.planning?.planId;
    if (planId === 'final-resume')
        return autoFinish(context, parentStep, step, hookSequential);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed')];
}
/** The whole finish runs inside this hook and returns intents — no UI round-trip, so it cannot
 * silently stall the way a clarification handler could. */
async function autoFinish(context, parentStep, step, hookSequential) {
    const moduleName = getApprovedModuleName(context) || normalizeModuleFolderName(String((getInitialPlanSummary(context).moduleName) || 'module'), 'module');
    let report;
    try {
        report = await computeBehaviorHealthReport(context);
    }
    catch (error) {
        console.warn(`[${AGENT_NAME}] health report failed`, error);
    }
    try {
        await writeJourneys(moduleName);
    }
    catch (error) {
        console.warn(`[${AGENT_NAME}] writeJourneys failed`, error);
    }
    try {
        await writeProcessRun(moduleName, buildRun(context, report, moduleName));
    }
    catch (error) {
        console.warn(`[${AGENT_NAME}] writeProcessRun failed`, error);
    }
    try {
        await clearRunArtifacts(moduleName);
    }
    catch (error) {
        console.warn(`[${AGENT_NAME}] clearRunArtifacts failed`, error);
    }
    // Complete final-resume (cleaning its payload), then the org-handoff container, then the root, and
    // clean every other completed step. We complete the container explicitly (its sibling behavior-
    // validate is already terminal and final-resume is completed in this same batch) so the task never
    // hangs on a passive parent waiting to auto-complete.
    const rootStep = getAgentStepByAgentName(context.task, ROOT_AGENT_NAME);
    const intents = [updateStatus(context, parentStep, step, hookSequential, 'completed', 'input_output')];
    if (rootStep && parentStep && parentStep.stepId !== rootStep.stepId)
        intents.push(updateStatus(context, rootStep, parentStep, hookSequential, 'completed'));
    if (rootStep)
        intents.push(updateStatus(context, rootStep, rootStep, hookSequential, 'completed'));
    intents.push(...buildCleanupIntents(context, hookSequential, step.stepId));
    return intents;
}
function buildRun(context, report, moduleName) {
    const initialPlan = getInitialPlanSummary(context);
    const nextSteps = [
        { id: 'stage2-experience', kind: 'workflowExperience', title: 'Etapa 2 — Experiencia', description: 'Telas + BFF a partir dos l4/workflows e l4/operations.', status: 'pending' },
        { id: 'stage3-backend', kind: 'backendImplementation', title: 'Etapa 3 — Backend', description: 'Persistencia + implementacao a partir das ontology/operations l4.', status: 'pending' },
    ];
    return {
        runId: `newSolution2-${moduleName}`,
        kind: 'newSolution2-behavior',
        startedAt: new Date().toISOString(),
        finishedAt: new Date().toISOString(),
        initialPrompt: String(initialPlan.userPrompt || ''),
        userLanguage: String(initialPlan.userLanguage || ''),
        decisions: safe(() => getImplementationDecisionResult(context).decisions) || [],
        openDetails: Array.isArray(initialPlan.openDetails) ? initialPlan.openDetails : [],
        healthReport: report ?? null,
        nextSteps,
    };
}
/** Derived, read-only view: consolidates the stories embedded in workflows + operations. */
async function writeJourneys(moduleName) {
    const journeys = [];
    for (const w of await readWorkflowDefs()) {
        const id = optionalString(w.workflowId);
        if (id)
            journeys.push({ journeyId: id, owner: `workflow:${id}`, title: optionalString(w.title) || id, ...storyOf(w) });
    }
    for (const o of await readOperationDefs()) {
        const id = optionalString(o.operationId);
        if (id)
            journeys.push({ journeyId: id, owner: `operation:${id}`, title: optionalString(o.title) || id, ...storyOf(o) });
    }
    await saveDefsArtifact(journeysFileInfo(moduleName), `${moduleName}Journeys`, {
        moduleName,
        note: 'Derivado das stories embutidas em workflows/operations (visao consolidada, nao fonte).',
        journeys,
    });
}
function storyOf(def) {
    const s = isRecord(def.story) ? def.story : {};
    return { actor: optionalString(s.actor) || '', goal: optionalString(s.goal) || '', soThat: optionalString(s.soThat) || '', steps: Array.isArray(s.steps) ? s.steps : [], outcome: optionalString(s.outcome) || '' };
}
/** One cleaner update-status per completed agent/result step that still carries a payload. */
function buildCleanupIntents(context, hookSequential, skipStepId) {
    if (!context.task)
        return [];
    const steps = getAllSteps(context.task.iaCompressed?.nextSteps);
    const parentOf = buildParentMap(steps);
    const intents = [];
    for (const s of steps) {
        if (s.stepId === skipStepId)
            continue;
        if (s.type !== 'agent' && s.type !== 'result')
            continue;
        if (s.status !== 'completed')
            continue;
        if (!(s.interaction?.payload?.length))
            continue;
        intents.push({
            type: 'update-status',
            hookSequential,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            parentStepId: parentOf.get(s.stepId) ?? s.stepId,
            stepId: s.stepId,
            status: 'completed',
            cleaner: 'input_output',
        });
    }
    return intents;
}
function buildParentMap(steps) {
    const map = new Map();
    for (const s of steps) {
        for (const child of s.nextSteps || [])
            map.set(child.stepId, s.stepId);
        for (const child of s.interaction?.payload || [])
            if (child && typeof child.stepId === 'number')
                map.set(child.stepId, s.stepId);
    }
    return map;
}
async function openStepView(agent, context, step) {
    const moduleName = getApprovedModuleName(context) || 'module';
    const report = await readBehaviorHealthReport(moduleName);
    const div = document.createElement('div');
    const title = document.createElement('h3');
    title.textContent = 'Etapa 1 — modelo de comportamento congelado';
    const pre = document.createElement('pre');
    pre.textContent = report ? JSON.stringify(report, null, 2) : 'Modelo congelado em l4. Relatorio de saude indisponivel.';
    div.append(title, pre);
    return div;
}
function updateStatus(context, parentStep, step, hookSequential, status, cleaner) {
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
    };
    if (cleaner)
        intent.cleaner = cleaner;
    return intent;
}
function safe(fn) {
    try {
        return fn();
    }
    catch {
        return undefined;
    }
}
