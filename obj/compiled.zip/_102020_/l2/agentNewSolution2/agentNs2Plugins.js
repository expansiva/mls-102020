/// <mls fileReference="_102020_/l2/agentNewSolution2/agentNs2Plugins.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createPromptReadyIntent, createUpdateStatusIntent, getPlannerOutput, optionalString, } from '/_102020_/l2/agentNewSolution2/ns2Shared.js';
import { createPlannerToolSchema, extractPlannerOutput } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
import { saveAgentTrace } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { pluginsResultSchema } from '/_102020_/l2/agentNewSolution2/ns2Schemas.js';
import { getFinalizeOutput } from '/_102020_/l2/agentNewSolution2/agentNs2Finalize.js';
const AGENT_NAME = 'agentNs2Plugins';
const TOOL_NAME = 'submitPluginsPlan';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the plugin references.', pluginsResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102020, agentFolder: 'agentNewSolution2', agentDescription: 'Plan external plugin references', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[${AGENT_NAME}] args invalid`);
    const fp = getFinalizeOutput(context).result;
    const human = `## Plugin signals\n${JSON.stringify(fp.approvedArtifacts.plugins, null, 2)}\n`;
    return [createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const output = extractPlannerOutput(payload, config);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = `${AGENT_NAME} returned failed`;
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${AGENT_NAME}] ${traceMsg}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg)];
}
export function getPluginsOutput(context) {
    try {
        return getPlannerOutput(context, AGENT_NAME, config);
    }
    catch {
        return null;
    }
}
const config = { toolName: TOOL_NAME, normalizeResult };
function normalizeResult(value) {
    const result = assertRecord(value, 'result');
    const plugins = assertArray(result.plugins || [], 'result.plugins').map((item, index) => {
        const p = assertRecord(item, `result.plugins[${index}]`);
        return {
            pluginId: assertString(p.pluginId, `result.plugins[${index}].pluginId`),
            title: optionalString(p.title) || '',
            brand: optionalString(p.brand) || '',
            resolution: p.resolution === 'draft' ? 'draft' : 'existing',
            reason: optionalString(p.reason),
        };
    });
    return { plugins };
}
const systemPrompt = `
<!-- modelType: codeinstruct -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} for the collab.codes "newSolution2" flow (Stage 1).
Plan external plugins as REFERENCES. Reuse an existing plugin by brand before drafting a new one.

Call the "{{toolName}}" tool with: status, result, questions, trace. Do not return prose.

In result.plugins, each: pluginId (camelCase), title, brand, resolution ('existing'|'draft'), reason.
Empty array allowed when no external integration is needed.

`;
