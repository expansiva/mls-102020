/// <mls fileReference="_102020_/l2/agentNewSolution2/ns2Extract.ts" enhancement="_blank"/>
// Self-contained planner-output toolkit for agentNewSolution2 (Stage 1).
// Two responsibilities:
//  1. Build the JSON-schema-backed tool the LLM must call (collab-llm enforces strict tool args).
//  2. Robustly extract + locally validate that tool output against the same schema.
// The local validator mirrors the schema sent to the model, so a structurally-correct tool call
// is accepted regardless of how the provider wrapped it (raw args, OpenAI tool_calls, nested
// flexible envelope, ...). Keep this file dependency-free: it is the spine every agent relies on.
export const PLANNER_SCHEMA_VERSION = '2026-06-25';
const plannerResultSchemasByToolName = {};
/**
 * Build the single tool the agent forces the model to call. The arguments are the planner
 * envelope { status, result, questions, trace } with `result` constrained by the agent's schema.
 */
export function createPlannerToolSchema(toolName, description, resultSchema) {
    plannerResultSchemasByToolName[toolName] = resultSchema;
    return {
        type: 'function',
        function: {
            name: toolName,
            description,
            parameters: {
                type: 'object',
                additionalProperties: false,
                required: ['status', 'result', 'questions', 'trace'],
                properties: {
                    status: { enum: ['ok', 'needs_input', 'failed'] },
                    result: resultSchema,
                    questions: { type: 'array', items: { type: 'string' } },
                    trace: { type: 'array', items: { type: 'string' } },
                },
            },
        },
    };
}
export function extractPlannerOutput(payload, config) {
    const value = parseMaybeJson(payload);
    if (!isRecord(value))
        throw new Error('tool payload must be an object');
    if (value.type === 'result')
        throw new Error(String(value.result || 'agent returned a result error'));
    const direct = tryNormalizeEnvelope(value, config);
    if (direct)
        return direct;
    if (value.type === 'flexible') {
        const flexibleResult = parseMaybeJson(value.result);
        const fromFlexible = tryNormalizeEnvelope(flexibleResult, config);
        if (fromFlexible)
            return fromFlexible;
        const fromFlexibleTool = tryExtractToolArguments(flexibleResult, config);
        if (fromFlexibleTool)
            return fromFlexibleTool;
    }
    const fromTool = tryExtractToolArguments(value, config);
    if (fromTool)
        return fromTool;
    const fromOpenAI = tryExtractOpenAIToolCall(value, config);
    if (fromOpenAI)
        return fromOpenAI;
    throw new Error(`payload does not contain a recognized ${config.toolName} tool output`);
}
function tryExtractOpenAIToolCall(value, config) {
    const toolCalls = value.tool_calls;
    if (!Array.isArray(toolCalls) || toolCalls.length === 0)
        return null;
    const call = toolCalls.find(item => {
        const record = isRecord(item) ? item : null;
        const fn = record && isRecord(record.function) ? record.function : null;
        return fn?.name === config.toolName;
    });
    if (!isRecord(call) || !isRecord(call.function))
        return null;
    return normalizeToolArguments(call.function.arguments, config);
}
function tryExtractToolArguments(value, config) {
    const record = parseMaybeJson(value);
    if (!isRecord(record))
        return null;
    if (record.toolName !== config.toolName)
        return null;
    return normalizeToolArguments(record.arguments, config);
}
function normalizeToolArguments(value, config, depth = 0) {
    const args = parseMaybeJson(value);
    if (!isRecord(args))
        throw new Error('tool arguments must be an object');
    if (args.result !== undefined && !isToolWrapper(args.result, config.toolName)) {
        return normalizeEnvelope(args, config);
    }
    const direct = tryNormalizeEnvelope(args, config);
    if (direct)
        return direct;
    const resultValue = parseMaybeJson(args.result);
    const nested = tryNormalizeEnvelope(resultValue, config);
    if (nested)
        return nested;
    if (args.arguments !== undefined && depth < 3) {
        try {
            return normalizeToolArguments(args.arguments, config, depth + 1);
        }
        catch {
            // fall through
        }
    }
    throw new Error(`tool arguments do not contain ${config.toolName} output`);
}
/** Accept any object that carries `result` (with optional status/questions/trace siblings). */
function tryNormalizeEnvelope(value, config) {
    const output = parseMaybeJson(value);
    if (!isRecord(output))
        return null;
    if (output.result === undefined)
        return null;
    if (isToolWrapper(output.result, config.toolName))
        return null;
    try {
        return normalizeEnvelope(output, config);
    }
    catch {
        return null;
    }
}
function normalizeEnvelope(output, config) {
    const pre = config.preNormalizeResult ? config.preNormalizeResult(output.result) : output.result;
    validatePlannerResultSchema(pre, config);
    return {
        status: output.status === undefined ? 'ok' : assertPlannerStatus(output.status, 'status'),
        result: config.normalizeResult(pre),
        questions: normalizeStringList(output.questions, 'questions'),
        trace: normalizeStringList(output.trace, 'trace'),
    };
}
function isToolWrapper(value, toolName) {
    const record = parseMaybeJson(value);
    return isRecord(record) && record.toolName === toolName && record.arguments !== undefined;
}
function validatePlannerResultSchema(value, config) {
    const schema = plannerResultSchemasByToolName[config.toolName];
    if (!schema)
        return;
    validateJsonSchema(value, schema, 'result');
}
/** Minimal JSON-schema validator covering the subset used by ns2Schemas (object/array/enum/const/type). */
export function validateJsonSchema(value, schema, path) {
    if (!isRecord(schema))
        return;
    const anyOf = schema.anyOf;
    if (Array.isArray(anyOf)) {
        const errors = [];
        for (const option of anyOf) {
            try {
                validateJsonSchema(value, option, path);
                return;
            }
            catch (error) {
                errors.push(error instanceof Error ? error.message : String(error));
            }
        }
        throw new Error(`${path} must match one allowed schema: ${errors.join('; ')}`);
    }
    if (schema.const !== undefined && value !== schema.const) {
        throw new Error(`${path} must be ${JSON.stringify(schema.const)}`);
    }
    if (Array.isArray(schema.enum) && !schema.enum.includes(value)) {
        throw new Error(`${path} must be one of ${schema.enum.map(item => JSON.stringify(item)).join(', ')}`);
    }
    if (schema.type !== undefined)
        validateJsonSchemaType(value, schema.type, path);
    if (schema.type === 'object' || schema.properties !== undefined || schema.required !== undefined) {
        if (!isRecord(value))
            throw new Error(`${path} must be an object`);
        const required = schema.required;
        if (Array.isArray(required)) {
            for (const key of required) {
                if (typeof key === 'string' && value[key] === undefined)
                    throw new Error(`${path}.${key} is required`);
            }
        }
        const properties = isRecord(schema.properties) ? schema.properties : {};
        for (const [key, propertySchema] of Object.entries(properties)) {
            if (value[key] !== undefined)
                validateJsonSchema(value[key], propertySchema, `${path}.${key}`);
        }
        const additionalProperties = schema.additionalProperties;
        if (additionalProperties === false) {
            for (const key of Object.keys(value)) {
                if (properties[key] === undefined)
                    throw new Error(`${path}.${key} is not allowed`);
            }
        }
        else if (isRecord(additionalProperties)) {
            for (const key of Object.keys(value)) {
                if (properties[key] === undefined)
                    validateJsonSchema(value[key], additionalProperties, `${path}.${key}`);
            }
        }
    }
    if (schema.type === 'array' || schema.items !== undefined) {
        if (!Array.isArray(value))
            throw new Error(`${path} must be an array`);
        if (typeof schema.minItems === 'number' && value.length < schema.minItems) {
            throw new Error(`${path} must have at least ${schema.minItems} item(s)`);
        }
        if (schema.items !== undefined) {
            value.forEach((item, index) => validateJsonSchema(item, schema.items, `${path}[${index}]`));
        }
    }
}
function validateJsonSchemaType(value, type, path) {
    const types = Array.isArray(type) ? type : [type];
    const ok = types.some(item => {
        if (item === 'array')
            return Array.isArray(value);
        if (item === 'object')
            return isRecord(value);
        if (item === 'integer')
            return Number.isInteger(value);
        if (item === 'number')
            return typeof value === 'number';
        if (item === 'string')
            return typeof value === 'string';
        if (item === 'boolean')
            return typeof value === 'boolean';
        if (item === 'null')
            return value === null;
        return true;
    });
    if (!ok)
        throw new Error(`${path} must be ${types.join(' or ')}`);
}
export function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const trimmed = value.trim();
    if (!trimmed)
        return value;
    if (!trimmed.startsWith('{') && !trimmed.startsWith('['))
        return value;
    try {
        return JSON.parse(trimmed);
    }
    catch {
        return value;
    }
}
export function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
export function assertRecord(value, path) {
    if (!isRecord(value))
        throw new Error(`${path} must be an object`);
    return value;
}
export function assertArray(value, path) {
    if (!Array.isArray(value))
        throw new Error(`${path} must be an array`);
    return value;
}
export function assertString(value, path) {
    if (typeof value !== 'string' || value.trim().length === 0)
        throw new Error(`${path} must be a non-empty string`);
    return value.trim();
}
export function optionalString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
export function optionalStringArray(value) {
    if (!Array.isArray(value))
        return undefined;
    return value.filter((item) => typeof item === 'string' && item.trim().length > 0).map(item => item.trim());
}
export function normalizeStringList(value, path) {
    if (value === undefined || value === null)
        return [];
    if (Array.isArray(value))
        return value.map((item, index) => normalizeStringListItem(item, `${path}[${index}]`));
    if (isRecord(value)) {
        return Object.entries(value).map(([key, item]) => normalizeStringListItem(item, `${path}.${key}`) || key);
    }
    return [assertString(value, path)];
}
function normalizeStringListItem(value, path) {
    if (typeof value === 'string')
        return value.trim();
    if (typeof value === 'number' || typeof value === 'boolean')
        return String(value);
    if (isRecord(value)) {
        const parts = [value.title, value.question, value.description, value.reason, value.message]
            .map(part => optionalString(part))
            .filter((part) => !!part);
        return parts.length > 0 ? parts.join(' - ') : JSON.stringify(value);
    }
    throw new Error(`${path} must be a string-compatible value`);
}
export function assertPriority(value, path) {
    if (value === 'now' || value === 'soon' || value === 'later' || value === 'never')
        return value;
    throw new Error(`${path} must be now, soon, later, or never`);
}
function assertPlannerStatus(value, path) {
    if (value === 'ok' || value === 'needs_input' || value === 'failed')
        return value;
    throw new Error(`${path} must be ok, needs_input, or failed`);
}
