/// <mls fileReference="_102020_/l2/agentNewSolution2/ns2DeterministicRepairs.ts" enhancement="_blank"/>
import { isRuntimeAnchorOriginRef } from '/_102020_/l2/agentNewSolution2/ns2MdmModeling.js';
export function repairMdmEntityDefinition(def, moduleName) {
    const isMdm = def.kind === 'mdm' || def.ownership === 'mdmOwned';
    if (!isMdm)
        return;
    def.kind = 'mdm';
    def.ownership = 'mdmOwned';
    if (moduleName && !def.moduleType?.startsWith(`${moduleName}.`)) {
        def.moduleType = `${moduleName}.${def.entityId}`;
    }
    repairRuntimeContextAnchor(def);
}
export function repairRuntimeAnchorRelationships(plan) {
    const entities = plan.ontology?.entities || {};
    const entityIds = new Set(Object.keys(entities).filter(Boolean));
    const runtimeAnchorPairs = new Set();
    for (const [entityId, rawEntity] of Object.entries(entities)) {
        if (!isRecord(rawEntity))
            continue;
        const entity = rawEntity;
        if (!entity.entityId)
            entity.entityId = entityId;
        const anchor = repairRuntimeContextAnchor(entity);
        const anchorEntityId = typeof anchor?.entityId === 'string' ? anchor.entityId : '';
        if (!anchorEntityId || entityIds.has(anchorEntityId))
            continue;
        if (anchor?.source === 'runtimeContext') {
            runtimeAnchorPairs.add(`${entityId}\u0000${anchorEntityId}`);
            runtimeAnchorPairs.add(`${anchorEntityId}\u0000${entityId}`);
        }
    }
    if (runtimeAnchorPairs.size === 0)
        return;
    plan.relationships = (plan.relationships || []).filter((relationship) => {
        if (!isRecord(relationship))
            return true;
        const fromEntity = typeof relationship.fromEntity === 'string' ? relationship.fromEntity : '';
        const toEntity = typeof relationship.toEntity === 'string' ? relationship.toEntity : '';
        return !runtimeAnchorPairs.has(`${fromEntity}\u0000${toEntity}`);
    });
}
export function repairComposedInputs(def, ontology, relationships) {
    if (def.kind !== 'create' && def.kind !== 'update')
        return;
    const root = stripField(def.entity);
    const writeEntities = new Set((def.writes || []).map(stripField));
    const inputEntities = new Set((def.inputs || []).map(input => stripField(input.fieldRef)));
    const usedInputIds = new Set((def.inputs || []).map(input => input.inputId));
    for (const relationship of relationships) {
        if (!isRecord(relationship))
            continue;
        if (relationship.type !== 'partOf' || relationship.toEntity !== root)
            continue;
        const child = typeof relationship.fromEntity === 'string' ? relationship.fromEntity : '';
        if (!child || !writeEntities.has(child) || inputEntities.has(child))
            continue;
        const childKind = typeof ontology[child]?.kind === 'string' ? ontology[child].kind : '';
        const inputId = uniqueInputId(`${lowerFirst(child)}Items`, usedInputIds);
        def.inputs.push({
            inputId,
            fieldRef: child,
            required: true,
            source: childKind === 'event' ? 'systemDefault' : 'userInput',
            description: childKind === 'event'
                ? `System-generated composed ${child} records written with the ${root} command.`
                : `Composed ${child} collection submitted with the ${root} command.`,
        });
    }
}
export function repairRuntimeAnchorReferences(def, ontology) {
    const runtimeAnchors = new Map();
    for (const entity of Object.values(ontology)) {
        const anchor = isRecord(entity.anchor) ? entity.anchor : null;
        const entityId = typeof anchor?.entityId === 'string' ? anchor.entityId : '';
        const originRef = typeof anchor?.originRef === 'string' ? anchor.originRef : '';
        if (anchor?.source === 'runtimeContext' && entityId && isRuntimeAnchorOriginRef(originRef)) {
            runtimeAnchors.set(entityId, originRef);
        }
    }
    if (runtimeAnchors.size === 0)
        return;
    const touched = new Map();
    const filterRefs = (refs) => (refs || []).filter((ref) => {
        const alias = stripField(ref);
        const originRef = runtimeAnchors.get(alias);
        if (!originRef)
            return true;
        touched.set(alias, originRef);
        return false;
    });
    def.reads = filterRefs(def.reads);
    def.writes = filterRefs(def.writes);
    if (touched.size === 0)
        return;
    if (!Array.isArray(def.contextResolution))
        def.contextResolution = [];
    for (const [alias, originRef] of touched) {
        if (def.contextResolution.some(item => item.originRef === originRef && item.targetRef === originRef)) {
            continue;
        }
        def.contextResolution.push({
            targetRef: originRef,
            source: contextSourceForOriginRef(originRef),
            originRef,
            description: `Resolve runtime anchor ${alias} from ${originRef}.`,
        });
    }
}
function stripField(ref) {
    return ref.includes('.') ? ref.split('.')[0] : ref;
}
function lowerFirst(value) {
    return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
}
function uniqueInputId(base, used) {
    if (!used.has(base)) {
        used.add(base);
        return base;
    }
    let suffix = 2;
    while (used.has(`${base}${suffix}`))
        suffix += 1;
    const inputId = `${base}${suffix}`;
    used.add(inputId);
    return inputId;
}
function contextSourceForOriginRef(originRef) {
    return originRef.slice(0, originRef.indexOf('.'));
}
function repairRuntimeContextAnchor(def) {
    const anchor = isRecord(def.anchor) ? def.anchor : undefined;
    const originRef = typeof anchor?.originRef === 'string' ? anchor.originRef : '';
    if (anchor && isRuntimeAnchorOriginRef(originRef)) {
        anchor.source = 'runtimeContext';
    }
    return anchor;
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
