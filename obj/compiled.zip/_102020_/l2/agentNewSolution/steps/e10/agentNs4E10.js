import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102020_/l2/agentNewSolution/helpers/ns4StepTree.js';
import { isNs4Pipeline, markNs4E10Approved, markNs4E10Failed, markNs4E10PipelineDefect, markNs4E10Running, markNs4E10RuntimeFailed, markNs4FastHandoff, markNs4ModuleE10Approved, } from '/_102020_/l2/agentNewSolution/helpers/ns4Core.js';
import { readNs4ApprovedJourneys, readNs4ApprovedOntology } from '/_102020_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts.js';
import { ns4ClassicContractFile, ns4WorkspaceModelFile, ns4OperationFile, ns4SiteMapFile, readNs4Text, ns4AccessMatrixFile, ns4JourneyIndexFile, ns4OntologyIndexFile, ns4RulesFile, ns4UseCaseFile, ns4UseCaseIndexFile, ns4WorkflowFile, ns4WorkflowIndexFile, ns4WorkspaceFile, readNs4DefsJson, readNs4L5Config, readNs4Module, readNs4Pipeline, writeNs4E10ValidationReport, writeNs4L5Config, writeNs4Module, writeNs4Pipeline, writeNs4Process, writeNs4TodoBackend, writeNs4TodoFrontend, readNs4L5Project, writeNs4L5Project, } from '/_102020_/l2/agentNewSolution/helpers/ns4Fs.js';
import { applyPlatformBlockDefaults, buildProjectsBlock, buildWorkspaceDependencies, collectProjectJsonIssues, collectPublishableConfigIssues, ensureProjectAppEnv, ensureProjectModule, ensureProjectType, readProjectTypeFromProjectJson, } from '/_102020_/l2/agentNewSolution/steps/e10/publishable.js';
import { compileNs4E10Delivery } from '/_102020_/l2/agentNewSolution/steps/e10/contracts.js';
import { validateNs4E10 } from '/_102020_/l2/agentNewSolution/steps/e10/gate.js';
import { agentBuildTrace } from '/_102020_/l2/agentNewSolution/helpers/ns4BuildStamp.js';
import { NS4_FAST_HANDOFF_AGENT, NS4_FAST_HANDOFF_PLAN_ID, decideNs4FastHandoff, isNs4FastMode, sendNs4FastHandoff, } from '/_102020_/l2/agentNewSolution/helpers/ns4FastHandoff.js';
import { buildNsRunSummary, saveNsRunSummary } from '/_102020_/l2/agentNewSolution/helpers/nsPipelineRun.js';
import { addMessage as sendThreadMessage } from '/_102025_/l2/collabMessagesHelper.js';
export async function beforeNs4E10PromptStep(_agent, context, parent, step, hookSequential, args) {
    let moduleName = '';
    let reportPath = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const pipeline = await requirePipeline(moduleName);
        if (pipeline.steps.e9?.status !== 'approved')
            throw new Error(`E10 requires approved E9 artifacts for ${moduleName}.`);
        await writeNs4Pipeline(markNs4E10Running(pipeline));
        const sources = await loadSources(moduleName);
        const report = await validateNs4E10(sources);
        reportPath = await writeNs4E10ValidationReport(moduleName, report);
        if (report.finalStatus !== 'passed') {
            const message = formatErrors(report);
            const failed = await requirePipeline(moduleName);
            await writeNs4Pipeline(report.pipelineDefect
                ? markNs4E10PipelineDefect(failed, message, reportPath)
                : markNs4E10Failed(failed, message, report.repairStep || 'e8-workspaces', reportPath));
            await persistNsRunSummary(context, moduleName, 'failed', message);
            return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
        }
        const delivery = await compileNs4E10Delivery(sources, report, await readNs4L5Config(), mls.actualProject || 0);
        const artifactPaths = [reportPath];
        artifactPaths.push(await writeNs4TodoFrontend(moduleName, delivery.todoFrontend));
        artifactPaths.push(await writeNs4TodoBackend(moduleName, delivery.todoBackend));
        artifactPaths.push(await writeNs4Process(moduleName, delivery.process));
        // THE PUBLISHABLE l5. Everything below is derived or validated — never invented: the blocks that were
        // typed in by hand the first time a module went live (dependencies, projects, the platform blocks)
        // are exactly what is filled or NAMED here, at delivery time, instead of failing later inside the
        // publish with nothing pointing at the cause.
        const projectId = mls.actualProject || 0;
        const dependencies = mls.l5.getProjectDependencies(projectId, false);
        const publishIssues = [];
        const config = { ...delivery.config };
        config.workspaceDependencies = buildWorkspaceDependencies(dependencies);
        const projectsBlock = buildProjectsBlock(config.projects, projectId, dependencies, await collectProjectTypes(projectId, dependencies));
        config.projects = projectsBlock.projects;
        publishIssues.push(...projectsBlock.issues);
        if (!config.defaultProjectId)
            config.defaultProjectId = String(projectId);
        const withBlocks = applyPlatformBlockDefaults(config);
        publishIssues.push(...withBlocks.issues);
        artifactPaths.push(await writeNs4L5Config(withBlocks.config));
        publishIssues.push(...collectPublishableConfigIssues(withBlocks.config, moduleName, dependencies));
        // l5/project.json belongs to the STUDIO/organization: E10 never rewrites tuned fields. It adds
        // appEnv/projectType when absent, and puts the module name back after `/rebuild all` stripped it.
        // Checklist runs AFTER that write — checking the pre-strip snapshot was a false positive.
        const projectJson = await readNs4L5Project();
        if (!projectJson) {
            publishIssues.push(...collectProjectJsonIssues(projectJson, moduleName));
        }
        else {
            const withAppEnv = ensureProjectAppEnv(projectJson);
            const withType = ensureProjectType(withAppEnv.projectJson, 'client');
            const withModule = ensureProjectModule(withType.projectJson, moduleName);
            if (withAppEnv.changed || withType.changed || withModule.changed) {
                artifactPaths.push(await writeNs4L5Project(withModule.projectJson));
            }
            publishIssues.push(...collectProjectJsonIssues(withModule.projectJson, moduleName));
        }
        const module = await readNs4Module(moduleName);
        if (!module)
            throw new Error(`Module artifact not found for ${moduleName}.`);
        const approvedAt = new Date().toISOString();
        await writeNs4Module(moduleName, markNs4ModuleE10Approved(module, 'auto', approvedAt));
        await writeNs4Pipeline(markNs4E10Approved(await requirePipeline(moduleName), 'auto', approvedAt, reportPath, artifactPaths));
        const mutationParent = mutableParent(context, parent, step);
        const already = getAllSteps(context.task?.iaCompressed?.nextSteps).some(item => item.planning?.planId === 'e10-result');
        const handoff = await dispatchChangeBackendHandoff(context, moduleName);
        const extra = already ? [] : [result(context, mutationParent, moduleName)];
        const base = already
            ? 'E10 automatic completion was already recorded.'
            : `E10 validation passed; ${artifactPaths.length - 1} L5 delivery artifacts were written and the solution was completed automatically.${publishIssues.length ? ` PUBLISH CHECKLIST (${publishIssues.length}): ${publishIssues.slice(0, 8).join('; ')}` : ' Publish checklist clean.'}`;
        const extraDegradations = handoff.degradation ? [handoff.degradation] : [];
        const summaryVerdict = extraDegradations.length || publishIssues.length ? 'degraded' : 'completed';
        await persistNsRunSummary(context, moduleName, summaryVerdict, `${base}${handoff.note}`, extraDegradations);
        return [...extra,
            status(context, mutationParent, step, hookSequential, 'completed', `${base}${handoff.note}${await agentBuildTrace('[agentNs4E10]')}`, 'input_output')];
    }
    catch (error) {
        const message = errorMessage(error);
        if (moduleName)
            await runtimeFail(moduleName, message, reportPath);
        if (moduleName)
            await persistNsRunSummary(context, moduleName, 'failed', message);
        return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function afterNs4E10PromptStep(_agent, context, parent, step, hookSequential) {
    const message = 'E10 is deterministic and must never receive an LLM response.';
    try {
        const parsed = resolveArgs(context, step.prompt);
        await runtimeFail(parsed.moduleName, message);
    }
    catch { /* trace is authoritative */ }
    return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
}
async function loadSources(moduleName) {
    const [journeys, ontology, journeyIndex, access, ontologyIndex, rules, useCaseIndex, workflowIndex, model] = await Promise.all([
        readNs4ApprovedJourneys(moduleName), readNs4ApprovedOntology(moduleName), readRequired(ns4JourneyIndexFile(moduleName), 'journey index'),
        readRequired(ns4AccessMatrixFile(moduleName), 'access matrix'),
        readRequired(ns4OntologyIndexFile(moduleName), 'ontology index'), readRequired(ns4RulesFile(moduleName), 'rules'),
        readRequired(ns4UseCaseIndexFile(moduleName), 'use-case index'),
        readRequired(ns4WorkflowIndexFile(moduleName), 'workflow index'),
        readApprovedModel(moduleName),
    ]);
    const [useCases, workflows] = await Promise.all([
        Promise.all(useCaseIndex.useCases.map(entry => readRequired(ns4UseCaseFile(moduleName, entry.useCaseId), `use case ${entry.useCaseId}`))),
        Promise.all(workflowIndex.workflows.map(entry => readRequired(ns4WorkflowFile(moduleName, entry.workflowId), `workflow ${entry.workflowId}`))),
    ]);
    // What E9 actually wrote, read back from L4: the staleness check compares it to a fresh compilation.
    const saved = {
        workspaces: await Promise.all(model.workspaces.map(workspace => readRequired(ns4WorkspaceFile(moduleName, workspace.workspaceId), `workspace ${workspace.workspaceId}`))),
        operations: await Promise.all(model.operations.map(operation => readRequired(ns4OperationFile(moduleName, operation.operationId), `operation ${operation.operationId}`))),
        contracts: await Promise.all(model.workspaces.flatMap(workspace => workspace.bffCalls.map(async (call) => ({
            workspaceId: workspace.workspaceId, bffId: call.bffId, route: `${moduleName}.${workspace.workspaceId}.${call.bffId}`,
            source: await readRequiredText(ns4ClassicContractFile(moduleName, workspace.workspaceId, call.bffId), `contract ${workspace.workspaceId}--${call.bffId}`),
        })))),
        siteMap: await readRequired(ns4SiteMapFile(moduleName), 'site map'),
    };
    return {
        moduleName, userLanguage: model.userLanguage, journeys, journeyIndex, ontology, ontologyIndex, rules, access,
        useCases, useCaseIndex, workflows, workflowIndex, model, saved,
    };
}
async function readApprovedModel(moduleName) {
    const parsed = await readNs4DefsJson(ns4WorkspaceModelFile(moduleName), true);
    if (!parsed || parsed.planId !== 'e8-workspace-model' || parsed.moduleName !== moduleName) {
        throw new Error(`Approved E8 workspace model not found for ${moduleName}.`);
    }
    return parsed;
}
async function readRequiredText(file, label) {
    const raw = await readNs4Text(file, true);
    if (typeof raw !== 'string' || !raw.trim())
        throw new Error(`Unable to read approved ${label}.`);
    return raw;
}
async function readRequired(file, label) {
    let failure = '';
    for (let attempt = 0; attempt < 2; attempt += 1)
        try {
            const value = await readNs4DefsJson(file, true);
            if (value)
                return value;
        }
        catch (error) {
            failure = errorMessage(error);
        }
    throw new Error(`Unable to read approved ${label}: ${failure || 'invalid artifact'}`);
}
async function collectProjectTypes(projectId, dependencies) {
    const typeById = {};
    for (const id of [...new Set([projectId, ...dependencies])]) {
        if (!Number.isFinite(id) || id <= 0)
            continue;
        try {
            const type = readProjectTypeFromProjectJson(await readNs4L5Project(id));
            if (type)
                typeById[String(id)] = type;
        }
        catch {
            // Another project's project.json may be missing or unreadable; the lib+finding fallback remains.
        }
    }
    return typeById;
}
async function dispatchChangeBackendHandoff(context, moduleName) {
    try {
        const pipeline = await requirePipeline(moduleName);
        const already = Boolean(pipeline.fastHandoff)
            || getAllSteps(context.task?.iaCompressed?.nextSteps).some(item => item.planning?.planId === NS4_FAST_HANDOFF_PLAN_ID);
        const decision = decideNs4FastHandoff({
            fast: isNs4FastMode(context.task?.iaCompressed?.longMemory),
            success: pipeline.status === 'complete' && pipeline.steps.e10?.status === 'approved',
            alreadyDispatched: already,
            moduleName,
        });
        if (!decision.dispatch) {
            return { note: already && isNs4FastMode(context.task?.iaCompressed?.longMemory) ? '; changeBackend: already dispatched' : '', degradation: null };
        }
        return sendNs4FastHandoff({
            threadId: context.message?.threadId,
            message: decision.message,
            send: async (threadId, message) => { await sendThreadMessage(threadId, message); },
            persist: () => writeNs4Pipeline(markNs4FastHandoff(pipeline, NS4_FAST_HANDOFF_AGENT, decision.message)).then(() => undefined),
        });
    }
    catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        return {
            note: `; changeBackend: DISPATCH FAILED (${reason})`,
            degradation: { at: new Date().toISOString(), kind: 'fast-handoff-dispatch', reason },
        };
    }
}
function resolveArgs(context, value) {
    const root = parse(value);
    const moduleName = isRecord(root) && text(root.moduleName) ? text(root.moduleName) : findE9Module(context) || memory(context, 'resumeModule');
    if (!isRecord(root) || root.planId !== 'e10-validation' || !moduleName)
        throw new Error('Invalid E10 step arguments or missing E9 module handoff.');
    return { planId: 'e10-validation', moduleName };
}
function findE9Module(context) { const anchor = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e9-result'); const value = anchor?.type === 'result' ? parse(anchor.result) : null; return isRecord(value) ? text(value.moduleName) : ''; }
async function requirePipeline(moduleName) { const pipeline = await readNs4Pipeline(moduleName); if (!isNs4Pipeline(pipeline))
    throw new Error(`agentNewSolution v33 pipeline not found for ${moduleName}.`); return pipeline; }
async function persistNsRunSummary(context, moduleName, verdict, reason, extraDegradations = []) {
    try {
        const pipeline = await readNs4Pipeline(moduleName);
        await saveNsRunSummary(buildNsRunSummary({
            pipeline: isNs4Pipeline(pipeline) ? pipeline : null,
            moduleName,
            longMemory: context.task?.iaCompressed?.longMemory,
            verdict,
            reason,
            extraDegradations,
        }));
    }
    catch { /* the run summary must never fail E10 */ }
}
async function runtimeFail(moduleName, message, reportPath = '') { try {
    const pipeline = await readNs4Pipeline(moduleName);
    if (isNs4Pipeline(pipeline))
        await writeNs4Pipeline(markNs4E10RuntimeFailed(pipeline, message, reportPath || undefined));
}
catch { /* task trace remains fallback */ } }
function result(context, parent, moduleName) { return addStep(context, parent, { type: 'result', stepId: 0, interaction: null, stepTitle: 'Finished solution approved', status: 'completed', nextSteps: [], result: JSON.stringify({ moduleName, completedStep: 'e10-validation', nextStep: 'complete', approved: true }, null, 2), planning: { planId: 'e10-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' } }); }
function addStep(context, parent, step) { return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, step }; }
function status(context, parent, step, hookSequential, state, traceMsg, cleaner) { return { type: 'update-status', hookSequential, messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, stepId: step.stepId, status: state, traceMsg, cleaner }; }
function mutableParent(context, parent, step) { return resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parent, step); }
function formatErrors(report) { return report.errors.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n'); }
function parse(value) { if (typeof value !== 'string')
    return value; try {
    return JSON.parse(value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
}
catch {
    return value;
} }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function memory(context, key) { const value = context.task?.iaCompressed?.longMemory?.[key]; return typeof value === 'string' ? value.trim() : ''; }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
