/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e5-behavior/contractsEmit.ts" enhancement="_blank"/>
import { writeStorTextAtomic } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { buildNsContractSet } from '/_102020_/l2/agentNewSolution/helpers/nsContracts.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution/helpers/nsIds.js';
const NS_CONTRACT_LOCATIONS = [
    { level: 4, folder: m => `${m}/contracts`, fileRef: (m, p, op) => `_${p}_/l4/${m}/contracts/${op}.ts` },
    { level: 1, folder: m => `${m}/contracts`, fileRef: (m, p, op) => `_${p}_/l1/${m}/contracts/${op}.ts` },
    { level: 2, folder: m => `${m}/web/contracts`, fileRef: (m, p, op) => `_${p}_/l2/${m}/web/contracts/${op}.ts` },
];
export async function emitNsContracts(moduleName, operations) {
    const module = normalizeModuleFolderName(moduleName);
    const project = mls.actualProject || 0;
    const written = [];
    for (const location of NS_CONTRACT_LOCATIONS) {
        const entries = operations.map(op => {
            const data = op;
            const operationId = String(data.operationId);
            return {
                data,
                fileRef: location.fileRef(module, project, operationId),
                // note always points at the operation def (the single source), regardless of mirror location
                sourceRef: `_${project}_/l4/${module}/operations/${operationId}.defs.ts`,
            };
        });
        const results = buildNsContractSet(entries);
        for (const result of results) {
            const folder = location.folder(module);
            await writeStorTextAtomic({ project, level: location.level, folder, shortName: result.operationId, extension: '.ts' }, result.tsSource);
            await writeStorTextAtomic({ project, level: location.level, folder, shortName: result.operationId, extension: '.d.ts' }, result.dtsSource);
            written.push(`l${location.level}/${folder}/${result.operationId}.ts`);
        }
    }
    return written;
}
