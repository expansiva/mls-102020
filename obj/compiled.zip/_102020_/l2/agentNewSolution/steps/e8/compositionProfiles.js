/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e8/compositionProfiles.ts" enhancement="_blank"/>
export const NS4_E8_COMPOSITION_PROFILES = {
    default: {
        profileId: 'default',
        contentOrganisms: false,
        hostedCommands: true,
        tiles: true,
        crud: true,
    },
    contentLanding: {
        profileId: 'contentLanding',
        contentOrganisms: true,
        hostedCommands: true,
        tiles: true,
        crud: false,
    },
};
export function ns4E8CompositionProfile(categoryRef) {
    return NS4_E8_COMPOSITION_PROFILES[categoryRef] || NS4_E8_COMPOSITION_PROFILES.default;
}
