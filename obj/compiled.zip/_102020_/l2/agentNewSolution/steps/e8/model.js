/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e8/model.ts" enhancement="_blank"/>
export const NS4_E8_MODEL_VERSION = '2026-08-14-ns4-e8-model-v1';
