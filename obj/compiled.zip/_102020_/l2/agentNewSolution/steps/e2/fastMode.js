export function isNs4E2FastMode(context) {
    return context.task?.iaCompressed?.longMemory?.fastMode === 'true';
}
