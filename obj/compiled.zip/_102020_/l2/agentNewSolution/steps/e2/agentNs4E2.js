/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e2/agentNs4E2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102020_/l2/agentNewSolution/helpers/ns4StepTree.js';
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { showNs4ClarificationError } from '/_102020_/l2/agentNewSolution/helpers/ns4Clarification.js';
import { createNs4E2CoverageJudgeStep, createNs4E2CoverageRepairStep, createNs4E2GateRepairStep, createNs4E2Step, plainNs4StepTitle, isNs4Pipeline, markNs4E2Approved, markNs4E2Failed, markNs4E2Running, markNs4E2WaitingHuman, markNs4E2ImpactStale, markNs4ModuleE2Approved, NS4_AUTOMATED_JUDGE_ICON, } from '/_102020_/l2/agentNewSolution/helpers/ns4Core.js';
import { readNs4AgentText, readNs4DefsJson, readNs4Text, readNs4Module, readNs4Pipeline, ns4E2DraftFile, ns4JourneyIndexFile, writeNs4E2Draft, writeNs4E2VersionedDraft, writeNs4E2ImpactReport, writeNs4Journey, writeNs4JourneyIndex, writeNs4Module, writeNs4Pipeline, } from '/_102020_/l2/agentNewSolution/helpers/ns4Fs.js';
import { buildNs4JourneyArtifacts, buildNs4E2ImpactReport, buildNs4JourneyIndex, buildNs4PolicyDecisionSelections, normalizeNs4E2Review, } from '/_102020_/l2/agentNewSolution/steps/e2/contracts.js';
import { validateNs4E2PolicySelections, validateNs4E2Review } from '/_102020_/l2/agentNewSolution/steps/e2/gate.js';
import { resolveNs4E2HookArgs } from '/_102020_/l2/agentNewSolution/steps/e2/hookArgs.js';
import { isNs4E2FastMode } from '/_102020_/l2/agentNewSolution/steps/e2/fastMode.js';
import { formatNs4E2CoverageRepairFeedback, applyNs4E2PolicyDecisionImpacts, normalizeNs4E2CoverageVerdict, resolveNs4E2CoverageFindings, resolveNs4E2CoverageJudgeFailure, validateNs4E2CoverageVerdict, } from '/_102020_/l2/agentNewSolution/steps/e2/coverageJudge.js';
import { applyNs4E2CoveragePatch, normalizeNs4E2CoveragePatch, validateNs4E2CoveragePatch, } from '/_102020_/l2/agentNewSolution/steps/e2/coverageRepair.js';
import { analyzeNs4E2MechanicalCoverage, NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL, } from '/_102020_/l2/agentNewSolution/steps/e2/coverageSignals.js';
const MAX_E2_GATE_REPAIRS = 1;
const MAX_E2_COVERAGE_REPAIRS = 1;
const MAX_E2_JUDGE_ATTEMPTS = 2;
export async function beforeNs4E2PromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution:e2] task invalid');
    const hookArgs = resolveNs4E2HookArgs(args, step.prompt);
    let moduleName = '';
    try {
        const parsed = resolveE2Args(context, hookArgs);
        moduleName = parsed.moduleName;
        const moduleArtifact = await readNs4Module(moduleName);
        const pipeline = await readNs4Pipeline(moduleName);
        if (!moduleArtifact || !isNs4Pipeline(pipeline) || pipeline.steps.e1.status !== 'approved') {
            throw new Error(`E1 approved artifacts not found for ${moduleName}.`);
        }
        const reviewRound = parsed.reviewRound || pipeline.steps.e2?.reviewRound || 1;
        if (parsed.stage === 'coverageJudge') {
            const draft = await readDraftFromStorage(moduleName);
            if (!draft)
                throw new Error(`E2 draft not found for coverage judge in ${moduleName}.`);
            const normalizedDraft = normalizeNs4E2Review(draft, moduleName);
            const mechanicalCoverage = analyzeNs4E2MechanicalCoverage(normalizedDraft);
            const judgePrompt = await readNs4AgentText('steps/e2', 'coverageJudge');
            return [{
                    type: 'prompt_ready',
                    args: hookArgs,
                    messageId: context.message.orderAt,
                    threadId: context.message.threadId,
                    taskId: context.task.PK,
                    hookSequential,
                    parentStepId: parentStep.stepId,
                    systemPrompt: judgePrompt,
                    humanPrompt: [
                        '## Approved E1 coverage contract',
                        JSON.stringify(compactE1CoverageContract(moduleArtifact), null, 2),
                        '',
                        '## Original module request',
                        pipeline.sourcePrompt,
                        '',
                        '## Complete E2 journey draft to judge',
                        JSON.stringify(normalizedDraft, null, 2),
                        '',
                        '## Mechanical whole-module coverage report',
                        JSON.stringify(mechanicalCoverage, null, 2),
                        '',
                        `## Required review round\n${reviewRound}`,
                    ].join('\n'),
                }];
        }
        if (parsed.stage === 'coverageRepair') {
            const draft = await readDraftFromStorage(moduleName);
            if (!draft)
                throw new Error(`E2 draft not found for coverage repair in ${moduleName}.`);
            if (!parsed.coverageFeedback)
                throw new Error(`E2 coverage feedback not found for ${moduleName}.`);
            const [repairPrompt, platform] = await Promise.all([
                readNs4AgentText('steps/e2', 'coverageRepair'),
                readNs4AgentText('skills', 'platform'),
            ]);
            return [{
                    type: 'prompt_ready',
                    args: hookArgs,
                    messageId: context.message.orderAt,
                    threadId: context.message.threadId,
                    taskId: context.task.PK,
                    hookSequential,
                    parentStepId: parentStep.stepId,
                    systemPrompt: repairPrompt.replace('{{platformSkill}}', platform),
                    humanPrompt: [
                        '## Approved E1 coverage contract',
                        JSON.stringify(compactE1CoverageContract(moduleArtifact), null, 2),
                        '',
                        '## Complete current E2 draft (read-only base)',
                        JSON.stringify(draft, null, 2),
                        '',
                        `## Required review round\n${parsed.reviewRound || 1}`,
                        '',
                        `## Mandatory semantic coverage repair\n${parsed.coverageFeedback}`,
                    ].join('\n'),
                }];
        }
        const previousDraft = parsed.adjustment || parsed.gateFeedback || parsed.coverageFeedback || parsed.policyDecisionSelections?.length
            ? await readDraftFromStorage(moduleName)
            : null;
        const [prompt, platform] = await Promise.all([
            readNs4AgentText('steps/e2', 'prompt'),
            readNs4AgentText('skills', 'platform'),
        ]);
        const humanPrompt = [
            '## Approved E1 module contract',
            JSON.stringify(moduleArtifact, null, 2),
            '',
            `## Required review round\n${reviewRound}`,
            previousDraft ? `## Previous E2 draft\n${JSON.stringify(previousDraft, null, 2)}` : '',
            parsed.adjustment ? `## Human adjustment request\n${parsed.adjustment}` : '',
            parsed.policyDecisionSelections?.length ? `## Human policy selections that the complete replacement MUST honor\n${JSON.stringify(parsed.policyDecisionSelections, null, 2)}` : '',
            parsed.gateFeedback ? `## Deterministic gate repair required\n${parsed.gateFeedback}` : '',
            parsed.coverageFeedback ? `## Semantic coverage repair required\n${parsed.coverageFeedback}` : '',
        ].filter(Boolean).join('\n');
        return [{
                type: 'prompt_ready',
                args: hookArgs,
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task.PK,
                hookSequential,
                parentStepId: parentStep.stepId,
                systemPrompt: prompt.replace('{{platformSkill}}', platform),
                humanPrompt,
            }];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordNs4E2Failure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
export async function afterNs4E2PromptStep(agent, context, parentStep, step, hookSequential) {
    let moduleName = '';
    try {
        const args = resolveE2Args(context, step.prompt);
        moduleName = args.moduleName;
        const pipeline = await requirePipeline(moduleName);
        await writeNs4Pipeline(markNs4E2Running(pipeline, args.reviewRound || pipeline.steps.e2?.reviewRound || 1));
        if (args.stage === 'coverageJudge') {
            return await afterNs4E2CoverageJudge(context, parentStep, step, hookSequential, args, pipeline);
        }
        const payload = unwrapPayload(step.interaction?.payload?.[0]);
        let review;
        if (args.stage === 'coverageRepair') {
            const round = args.reviewRound || pipeline.steps.e2?.reviewRound || 1;
            const storedDraft = normalizeNs4E2Review(await readDraftFromStorage(args.moduleName), args.moduleName);
            const mechanicalCoverage = analyzeNs4E2MechanicalCoverage(storedDraft);
            const allowNoOp = mechanicalCoverage.findings.some(finding => finding.signalId === NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL) && args.coverageIssueIds?.includes(NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL) === true;
            const patch = normalizeNs4E2CoveragePatch(payload, args.moduleName, round);
            const patchValidation = validateNs4E2CoveragePatch(patch, args.moduleName, round, allowNoOp);
            if (!patchValidation.ok) {
                return await retryInvalidCoveragePatch(context, parentStep, step, hookSequential, args, pipeline, patchValidation.errors);
            }
            review = applyNs4E2CoveragePatch(storedDraft, patch);
        }
        else {
            if (!isRecord(payload) || payload.planId !== 'e2-review') {
                const message = readE2FailureMessage(payload);
                await recordNs4E2Failure(moduleName, message);
                return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
            }
            review = normalizeNs4E2Review(payload, args.moduleName);
            review.moduleName = args.moduleName;
            review.reviewRound = args.reviewRound || review.reviewRound;
        }
        const structuralGate = validateNs4E2Review(review);
        const selectionGate = validateNs4E2PolicySelections(review, args.policyDecisionSelections || [], true);
        const gate = {
            ok: structuralGate.ok && selectionGate.ok,
            issues: [...structuralGate.issues, ...selectionGate.issues],
        };
        if (!gate.ok) {
            const message = gate.issues.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n');
            const gateRepairAttempt = args.gateRepairAttempt || 0;
            const coverageRepairAttempt = args.coverageRepairAttempt || 0;
            if (gateRepairAttempt < MAX_E2_GATE_REPAIRS) {
                await writeNs4E2Draft(moduleName, review);
                const repairParent = findMutableParentStep(context, parentStep, step);
                const repairStep = createNs4E2GateRepairStep(moduleName, review.reviewRound, gateRepairAttempt + 1, coverageRepairAttempt, message, pipeline.presentation.stepTitles['e2-journeys'], args.coverageIssueIds, args.policyDecisionSelections);
                return [
                    addStep(context, repairParent, repairStep),
                    gateRepairResultStep(context, repairParent, moduleName, review.reviewRound, gateRepairAttempt + 1, coverageRepairAttempt, message),
                    updateStatus(context, repairParent, step, hookSequential, 'completed', `E2 gate requested structural repair ${gateRepairAttempt + 1}.`, 'input_output'),
                ];
            }
            await recordNs4E2Failure(moduleName, message);
            return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
        }
        const draftPath = await writeNs4E2Draft(args.moduleName, review);
        await writeNs4E2VersionedDraft(args.moduleName, review.reviewRound, review);
        const judgeParent = findMutableParentStep(context, parentStep, step);
        const judgeStep = createNs4E2CoverageJudgeStep(moduleName, review.reviewRound, args.coverageRepairAttempt || 0, 1, pipeline.presentation.stepTitles['e2-journeys'], args.coverageIssueIds);
        return [
            addStep(context, judgeParent, judgeStep),
            updateStatus(context, judgeParent, step, hookSequential, 'completed', `E2 structural gate passed; coverage judge scheduled for ${draftPath}.`, 'input_output'),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordNs4E2Failure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
async function afterNs4E2CoverageJudge(context, parentStep, step, hookSequential, args, pipeline) {
    const round = args.reviewRound || pipeline.steps.e2?.reviewRound || 1;
    const judgeAttempt = args.judgeAttempt || 1;
    const coverageRepairAttempt = args.coverageRepairAttempt || 0;
    const judgeParent = findMutableParentStep(context, parentStep);
    const payload = unwrapPayload(step.interaction?.payload?.[0]);
    const storedDraft = await readDraftFromStorage(args.moduleName);
    const originalReview = normalizeNs4E2Review(storedDraft, args.moduleName);
    const mechanicalCoverage = analyzeNs4E2MechanicalCoverage(originalReview);
    const verdict = normalizeNs4E2CoverageVerdict(payload, args.moduleName, round);
    const validation = validateNs4E2CoverageVerdict(verdict, args.moduleName, round, mechanicalCoverage, originalReview);
    if (!validation.ok) {
        if (judgeAttempt < MAX_E2_JUDGE_ATTEMPTS) {
            return [
                addStep(context, judgeParent, createNs4E2CoverageJudgeStep(args.moduleName, round, coverageRepairAttempt, judgeAttempt + 1, pipeline.presentation.stepTitles['e2-journeys'], args.coverageIssueIds)),
                coverageJudgeTraceStep(context, judgeParent, round, coverageRepairAttempt, judgeAttempt, pipeline.presentation.stepTitles['e2-journeys'], { valid: false, errors: validation.errors }),
                updateStatus(context, judgeParent, step, hookSequential, 'completed', `E2 coverage judge returned an invalid verdict; retry ${judgeAttempt + 1} scheduled.`, 'input_output'),
            ];
        }
        const review = resolveNs4E2CoverageJudgeFailure(originalReview);
        return await continueNs4E2AfterCoverageJudge(context, judgeParent, step, hookSequential, args, pipeline, review, coverageJudgeTraceStep(context, judgeParent, round, coverageRepairAttempt, judgeAttempt, pipeline.presentation.stepTitles['e2-journeys'], { valid: false, errors: validation.errors }), `E2 decision coverage judge was unavailable after retry; the decision was recorded and the run continued.`);
    }
    const knownDecisionIds = new Set(originalReview.journeys.flatMap(journey => journey.policyDecisions.map(decision => decision.decisionId)));
    const unknownImpact = verdict.policyDecisionImpacts.find(impact => !knownDecisionIds.has(impact.decisionId));
    if (unknownImpact) {
        const message = `E2 coverage judge returned impact for unknown policy decision ${unknownImpact.decisionId}.`;
        await recordNs4E2Failure(args.moduleName, message);
        return [updateStatus(context, judgeParent, step, hookSequential, 'failed', message)];
    }
    let review = applyNs4E2PolicyDecisionImpacts(originalReview, verdict);
    const gate = validateNs4E2Review(review);
    if (!gate.ok) {
        const message = `E2 draft changed or became invalid before coverage approval: ${gate.issues.map(issue => `${issue.code} ${issue.path}`).join(', ')}`;
        await recordNs4E2Failure(args.moduleName, message);
        return [updateStatus(context, judgeParent, step, hookSequential, 'failed', message)];
    }
    if (!verdict.complete) {
        const feedback = formatNs4E2CoverageRepairFeedback(verdict);
        const currentIssueIds = verdict.issues
            .filter(issue => issue.severity === 'blocking')
            .map(issue => issue.issueId)
            .sort();
        const repeated = sameStringSet(currentIssueIds, args.coverageIssueIds || []);
        if (!repeated && coverageRepairAttempt < MAX_E2_COVERAGE_REPAIRS) {
            return [
                addStep(context, judgeParent, createNs4E2CoverageRepairStep(args.moduleName, round, coverageRepairAttempt + 1, feedback, pipeline.presentation.stepTitles['e2-journeys'], currentIssueIds)),
                coverageJudgeTraceStep(context, judgeParent, round, coverageRepairAttempt, judgeAttempt, pipeline.presentation.stepTitles['e2-journeys'], verdict),
                updateStatus(context, judgeParent, step, hookSequential, 'completed', `E2 coverage judge requested semantic repair ${coverageRepairAttempt + 1}.`, 'input_output'),
            ];
        }
        review = resolveNs4E2CoverageFindings(review, verdict);
    }
    const trace = coverageJudgeTraceStep(context, judgeParent, round, coverageRepairAttempt, judgeAttempt, pipeline.presentation.stepTitles['e2-journeys'], verdict);
    return continueNs4E2AfterCoverageJudge(context, judgeParent, step, hookSequential, args, pipeline, review, trace);
}
async function continueNs4E2AfterCoverageJudge(context, judgeParent, step, hookSequential, args, pipeline, review, trace, statusPrefix = 'E2 coverage reviewed') {
    const round = args.reviewRound || pipeline.steps.e2?.reviewRound || 1;
    const draftPath = await writeNs4E2Draft(args.moduleName, review);
    await writeNs4E2VersionedDraft(args.moduleName, review.reviewRound, review);
    const reviewedPipeline = await requirePipeline(args.moduleName);
    await writeNs4Pipeline(markNs4E2WaitingHuman(reviewedPipeline, round, draftPath));
    if (isFast(context)) {
        const saved = await persistNs4E2(args.moduleName, review, 'auto');
        return [
            trace,
            resultStep(context, judgeParent, saved, 'E2 journeys auto-approved'),
            updateStatus(context, judgeParent, step, hookSequential, 'completed', `${statusPrefix} and ${saved.journeyCount} journeys were auto-approved.`, 'input_output'),
        ];
    }
    return [
        trace,
        clarificationReviewStep(context, judgeParent, review, pipeline.presentation.stepTitles['e2-journeys']),
        updateStatus(context, judgeParent, step, hookSequential, 'completed', `${statusPrefix}; human review opened with ${review.systemDecisions.length} assumed decision(s).`, 'input_output'),
    ];
}
async function retryInvalidCoveragePatch(context, parentStep, step, hookSequential, args, pipeline, errors) {
    const attempt = args.coverageRepairAttempt || 1;
    const message = `Invalid E2 focused coverage patch: ${errors.join(' ')}`;
    const repairParent = findMutableParentStep(context, parentStep);
    if (attempt < MAX_E2_COVERAGE_REPAIRS && args.coverageFeedback) {
        return [
            addStep(context, repairParent, createNs4E2CoverageRepairStep(args.moduleName, args.reviewRound || pipeline.steps.e2?.reviewRound || 1, attempt + 1, `${args.coverageFeedback}\nPatch-envelope retry: ${message}`, pipeline.presentation.stepTitles['e2-journeys'], args.coverageIssueIds)),
            updateStatus(context, repairParent, step, hookSequential, 'completed', `${message} Focused repair retry ${attempt + 1} scheduled.`, 'input_output'),
        ];
    }
    await recordNs4E2Failure(args.moduleName, message);
    return [updateStatus(context, repairParent, step, hookSequential, 'failed', message)];
}
export async function beforeNs4E2ClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const review = normalizeNs4E2Review(parseMaybeJson(json));
    const gate = validateNs4E2Review(review);
    if (!gate.ok) {
        const message = gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n');
        await recordNs4E2Failure(review.moduleName, message);
        throw new Error(message);
    }
    await import('/_102020_/l2/agentNewSolution/widgets/widgetNs4Journeys.js');
    const element = document.createElement('widget-ns4-journeys-102020');
    element.value = review;
    element.addEventListener('ns4-journeys-review', (event) => {
        const detail = event.detail;
        void applyNs4E2Review(context, parentStep, step, hookSequential, detail)
            .catch(error => { showNs4ClarificationError(element, error); console.error(`[${agent.agentName}] ${errorMessage(error)}`); });
    });
    return element;
}
async function applyNs4E2Review(context, parentStep, step, hookSequential, event) {
    if (!context.task)
        throw new Error('[agentNewSolution:e2] task invalid');
    const mutationParent = findMutableParentStep(context, parentStep);
    if (event.action === 'cancel')
        throw new Error('Cancelamento terminal ainda depende de suporte explícito do collab-messages; esta revisão foi mantida aberta sem alterar o pipeline.');
    if (event.action === 'approve') {
        const selectionGate = validateNs4E2PolicySelections(event.review, event.policyDecisionSelections, true);
        if (!selectionGate.ok)
            throw new Error(selectionGate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
        const saved = await persistNs4E2(event.review.moduleName, event.review, 'human', event.policyDecisionSelections);
        await applyIntents(context, [
            resultStep(context, mutationParent, saved, 'E2 journeys approved'),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
        ]);
    }
    else {
        if (!event.adjustment.trim() && !event.policyDecisionSelections.some(selection => {
            const decision = event.review.journeys.flatMap(journey => journey.policyDecisions).find(item => item.decisionId === selection.decisionId);
            return decision && decision.chosen !== selection.selectedChoice;
        }))
            throw new Error('Adjustment request or a different policy selection is required.');
        const nextRound = event.review.reviewRound + 1;
        const pipeline = await requirePipeline(event.review.moduleName);
        await writeNs4E2Draft(event.review.moduleName, event.review);
        await writeNs4E2VersionedDraft(event.review.moduleName, event.review.reviewRound, event.review);
        await writeNs4Pipeline(markNs4E2Running(pipeline, nextRound));
        await applyIntents(context, [
            addStep(context, mutationParent, createNs4E2Step(event.review.moduleName, nextRound, event.adjustment, [], undefined, event.policyDecisionSelections)),
            adjustmentResultStep(context, mutationParent, event.review.moduleName, event.review.reviewRound, event.adjustment),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
        ]);
    }
    await continuePoolingTask(context);
}
function findMutableParentStep(context, parentStep, phaseStep) {
    return resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parentStep, phaseStep);
}
async function persistNs4E2(moduleName, review, approvedBy, requestedSelections = []) {
    const gate = validateNs4E2Review(review);
    if (!gate.ok)
        throw new Error(gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const moduleArtifact = await readNs4Module(moduleName);
    const pipeline = await requirePipeline(moduleName);
    if (!moduleArtifact || moduleArtifact.module.moduleName !== moduleName)
        throw new Error(`Invalid module artifact for ${moduleName}.`);
    const artifacts = await buildNs4JourneyArtifacts(review);
    const previousIndex = await readNs4DefsJson(ns4JourneyIndexFile(moduleName));
    const artifactPaths = [];
    for (const artifact of artifacts)
        artifactPaths.push(await writeNs4Journey(moduleName, artifact.journeyId, artifact));
    const approvedAt = new Date().toISOString();
    const selections = buildNs4PolicyDecisionSelections(review, requestedSelections, approvedBy, approvedAt);
    const index = buildNs4JourneyIndex(moduleName, review, artifacts, artifactPaths, approvedBy, approvedAt, selections);
    const indexPath = await writeNs4JourneyIndex(moduleName, index);
    const impactReport = buildNs4E2ImpactReport(moduleName, previousIndex, artifacts, approvedAt, review);
    const impactReportPath = await writeNs4E2ImpactReport(moduleName, impactReport);
    const invalidated = impactReport.changes.length > 0;
    await writeNs4Module(moduleName, markNs4ModuleE2Approved(moduleArtifact, approvedBy, approvedAt, invalidated));
    const approvedPipeline = markNs4E2Approved(pipeline, approvedBy, [...artifactPaths, indexPath, impactReportPath], approvedAt);
    await writeNs4Pipeline(markNs4E2ImpactStale(approvedPipeline, invalidated, approvedAt));
    return { moduleName, journeyCount: artifacts.length, artifactPaths, indexPath };
}
async function requirePipeline(moduleName) {
    const pipeline = await readNs4Pipeline(moduleName);
    if (!isNs4Pipeline(pipeline))
        throw new Error(`agentNewSolution pipeline not found for ${moduleName}.`);
    return pipeline;
}
async function recordNs4E2Failure(moduleName, failure) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readNs4Pipeline(moduleName);
        if (isNs4Pipeline(pipeline))
            await writeNs4Pipeline(markNs4E2Failed(pipeline, failure));
    }
    catch {
        // The step trace remains the fallback when the pipeline itself cannot be read or written.
    }
}
async function readDraftFromStorage(moduleName) {
    const raw = await readNs4Text(ns4E2DraftFile(moduleName), false);
    try {
        return raw.trim() ? JSON.parse(raw) : null;
    }
    catch {
        return null;
    }
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId, step,
    };
}
function resultStep(context, parentStep, saved, title) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: title, status: 'completed', nextSteps: [],
        result: JSON.stringify({ ...saved, completedStep: 'e2-journeys', nextStep: 'e3-access-matrix' }, null, 2),
        planning: { planId: 'e2-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function clarificationReviewStep(context, parentStep, review, title) {
    return addStep(context, parentStep, {
        type: 'clarification', stepId: 0, interaction: null,
        stepTitle: plainNs4StepTitle(title), status: 'pending', nextSteps: [],
        json: JSON.stringify(review),
        planning: {
            planId: `e2-review-round-${review.reviewRound}`,
            dependsOn: [], executionMode: 'sequential', executionHost: 'client',
        },
    });
}
function coverageJudgeTraceStep(context, parentStep, round, coverageRepairAttempt, judgeAttempt, title, result) {
    const cleanTitle = title.trim().replace(/^[👤🔎]\s*/u, '');
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: `${NS4_AUTOMATED_JUDGE_ICON} ${cleanTitle}`,
        status: 'completed', nextSteps: [], result: JSON.stringify(result, null, 2),
        planning: {
            planId: `e2-coverage-judge-result-${round}-${coverageRepairAttempt}-${judgeAttempt}`,
            dependsOn: [], executionMode: 'manual_later', executionHost: 'client',
        },
    });
}
function adjustmentResultStep(context, parentStep, moduleName, round, adjustment) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: `E2 changes requested after round ${round}`, status: 'completed', nextSteps: [],
        result: JSON.stringify({ moduleName, reviewRound: round, adjustment }, null, 2),
        planning: { planId: `e2-adjustment-request-${Date.now()}`, dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function isFast(context) { return isNs4E2FastMode(context); }
function gateRepairResultStep(context, parentStep, moduleName, round, gateRepairAttempt, coverageRepairAttempt, gateFeedback) {
    return addStep(context, parentStep, {
        type: 'result', stepId: 0, interaction: null, stepTitle: `E2 structural repair ${gateRepairAttempt}`,
        status: 'completed', nextSteps: [], result: JSON.stringify({
            moduleName, reviewRound: round, gateRepairAttempt, coverageRepairAttempt, gateFeedback,
        }, null, 2),
        planning: {
            planId: `e2-gate-repair-${round}-${coverageRepairAttempt}-${gateRepairAttempt}`,
            dependsOn: [], executionMode: 'manual_later', executionHost: 'client',
        },
    });
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return {
        type: 'update-status', hookSequential, messageId: context.message.orderAt,
        threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
        stepId: step.stepId, status, ...(traceMsg ? { traceMsg } : {}), ...(cleaner ? { cleaner } : {}),
    };
}
async function applyIntents(context, intents) {
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200)
        throw new Error(response?.msg || 'Error applying E2 intents.');
    const applied = response;
    context.task = applied.task;
    if (applied.message)
        context.message = applied.message;
}
function parseE2Args(value) {
    const parsed = parseMaybeJson(value);
    if (!isRecord(parsed) || parsed.planId !== 'e2-journeys') {
        throw new Error('Invalid E2 step arguments.');
    }
    return {
        planId: 'e2-journeys',
        ...(parsed.stage === 'coverageJudge' || parsed.stage === 'coverageRepair'
            ? { stage: parsed.stage }
            : {}),
        ...(typeof parsed.moduleName === 'string' && parsed.moduleName.trim() ? { moduleName: parsed.moduleName.trim() } : {}),
        ...(typeof parsed.adjustment === 'string' && parsed.adjustment.trim() ? { adjustment: parsed.adjustment.trim() } : {}),
        ...(typeof parsed.reviewRound === 'number' ? { reviewRound: parsed.reviewRound } : {}),
        ...(typeof parsed.gateRepairAttempt === 'number' ? { gateRepairAttempt: parsed.gateRepairAttempt } : {}),
        ...(typeof parsed.coverageRepairAttempt === 'number' ? { coverageRepairAttempt: parsed.coverageRepairAttempt } : {}),
        ...(typeof parsed.judgeAttempt === 'number' ? { judgeAttempt: parsed.judgeAttempt } : {}),
        ...(typeof parsed.gateFeedback === 'string' && parsed.gateFeedback.trim() ? { gateFeedback: parsed.gateFeedback.trim() } : {}),
        ...(typeof parsed.coverageFeedback === 'string' && parsed.coverageFeedback.trim() ? { coverageFeedback: parsed.coverageFeedback.trim() } : {}),
        ...(Array.isArray(parsed.coverageIssueIds)
            ? { coverageIssueIds: parsed.coverageIssueIds.filter((value) => typeof value === 'string' && !!value.trim()).map(value => value.trim()) }
            : {}),
        ...(Array.isArray(parsed.policyDecisionSelections)
            ? { policyDecisionSelections: parsed.policyDecisionSelections.map(item => isRecord(item) ? ({
                    decisionId: typeof item.decisionId === 'string' ? item.decisionId.trim() : '',
                    selectedChoice: typeof item.selectedChoice === 'string' ? item.selectedChoice.trim() : '',
                }) : null).filter((item) => !!item?.decisionId && !!item.selectedChoice) }
            : {}),
    };
}
function resolveE2Args(context, value) {
    const parsed = parseE2Args(value);
    const moduleName = parsed.moduleName || findE1ModuleName(context) || memoryString(context, 'resumeModule');
    if (!moduleName)
        throw new Error('E1 module result not found for E2.');
    return { ...parsed, moduleName };
}
function findE1ModuleName(context) {
    const result = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e1-result');
    if (!result || result.type !== 'result' || !result.result)
        return '';
    const parsed = parseMaybeJson(result.result);
    return isRecord(parsed) && typeof parsed.moduleName === 'string' ? parsed.moduleName.trim() : '';
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function compactE1CoverageContract(moduleArtifact) {
    return {
        module: moduleArtifact.module,
        businessScope: moduleArtifact.businessScope,
        declaredConstraints: moduleArtifact.declaredConstraints,
        solutionStrategy: { mode: moduleArtifact.solutionStrategy.mode },
        localization: {
            productLanguages: moduleArtifact.localization.productLanguages,
            defaultLanguage: moduleArtifact.localization.defaultLanguage,
        },
    };
}
function sameStringSet(left, right) {
    if (!left.length || left.length !== right.length)
        return false;
    const expected = new Set(right);
    return left.every(value => expected.has(value));
}
function unwrapPayload(value) {
    const parsed = parseMaybeJson(value);
    if (isRecord(parsed) && parsed.type === 'flexible')
        return parseMaybeJson(parsed.result);
    return parsed;
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function readE2FailureMessage(payload) {
    if (isRecord(payload) && payload.type === 'result' && typeof payload.result === 'string' && payload.result.trim()) {
        return payload.result.trim();
    }
    return 'E2 returned an invalid internal review payload.';
}
