/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e2-journeys/widgetNsJourneys.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { nsPipelineArtifactFileInfo, readJsonArtifact, } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { buildNsJourneysReviewPayload, emptyNsJourneysWidgetEdits, hasNsJourneysWidgetEdits, NS_E2_PRIORITIES, parseNsBusinessRulesText, sameStringArray, serializeNsBusinessRules, } from '/_102020_/l2/agentNewSolution/steps/e2-journeys/widgetNsJourneysLogic.js';
const messages_en = {
    title: 'User journeys',
    subtitle: 'Review E2 journeys before design and build start.',
    loading: 'Loading journeys...',
    noArtifact: 'No E2 journey artifact found.',
    searchPlaceholder: 'Search journeys, actors, features...',
    allActors: 'All actors',
    version: 'Version',
    newModule: 'New module',
    changeModule: 'Production change',
    journeysFound: 'journeys found',
    actorMap: 'Journey map by actor',
    actors: 'actors',
    journeys: 'journeys',
    features: 'Features',
    steps: 'steps',
    goal: 'Goal',
    soThat: 'So that',
    trigger: 'Trigger',
    outcome: 'Expected result',
    overview: 'Overview',
    businessRules: 'Business rules',
    notes: 'Notes',
    rulesHelp: 'One business rule per line. The artifact is not written by this widget.',
    notesPlaceholder: 'Notes for this journey.',
    featureCatalog: 'Feature catalog',
    priority: 'Priority',
    usedBy: 'Used by',
    noChanges: 'No pending changes.',
    changesPreview: 'Change preview',
    adjustmentTitle: 'Request change by prompt',
    adjustmentPlaceholder: 'Describe the smallest change needed in these journeys.',
    requestAdjustment: 'Request adjustment',
    approve: 'Approve version',
    approveWithChanges: 'Approve with changes',
    readOnly: 'Read only',
    history: 'Iterations',
    currentVersion: 'Current version',
    noJourney: 'No journey selected.',
    payload: 'Payload',
};
const messages_ptBR = {
    title: 'Jornadas do usuário',
    subtitle: 'Revise as jornadas E2 antes do design e da construção.',
    loading: 'Carregando jornadas...',
    noArtifact: 'Artefato E2 de jornadas não encontrado.',
    searchPlaceholder: 'Buscar jornadas, atores, funcionalidades...',
    allActors: 'Todos os atores',
    version: 'Versão',
    newModule: 'Módulo novo',
    changeModule: 'Mudança em produção',
    journeysFound: 'jornadas encontradas',
    actorMap: 'Mapa de jornadas por ator',
    actors: 'atores',
    journeys: 'jornadas',
    features: 'Funcionalidades',
    steps: 'passos',
    goal: 'Objetivo',
    soThat: 'Para que',
    trigger: 'Gatilho',
    outcome: 'Resultado esperado',
    overview: 'Visão geral',
    businessRules: 'Regras de negócio',
    notes: 'Notas',
    rulesHelp: 'Uma regra de negócio por linha. Este widget não grava o artefato.',
    notesPlaceholder: 'Notas desta jornada.',
    featureCatalog: 'Catálogo de funcionalidades',
    priority: 'Prioridade',
    usedBy: 'Usado por',
    noChanges: 'Nenhuma alteração pendente.',
    changesPreview: 'Prévia das alterações',
    adjustmentTitle: 'Solicitar alteração via prompt',
    adjustmentPlaceholder: 'Descreva a menor alteração necessária nestas jornadas.',
    requestAdjustment: 'Solicitar ajuste',
    approve: 'Aprovar versão',
    approveWithChanges: 'Aprovar com alterações',
    readOnly: 'Somente leitura',
    history: 'Iterações',
    currentVersion: 'Versão atual',
    noJourney: 'Nenhuma jornada selecionada.',
    payload: 'Payload',
};
const priorityLabelsEn = {
    now: 'Now',
    soon: 'Soon',
    later: 'Later',
    never: 'Never',
};
const priorityLabelsPtBR = {
    now: 'Agora',
    soon: 'Em breve',
    later: 'Depois',
    never: 'Nunca',
};
let WidgetNsJourneys102020 = class WidgetNsJourneys102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns-journeys-102020 {
  display: block;
  color: #18212f;
}
widget-ns-journeys-102020 .ns-journeys {
  display: grid;
  gap: 16px;
  min-width: 0;
}
widget-ns-journeys-102020 .ns-header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns-journeys-102020 .ns-breadcrumb {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 8px;
}
widget-ns-journeys-102020 h2,
widget-ns-journeys-102020 h3,
widget-ns-journeys-102020 p,
widget-ns-journeys-102020 dl,
widget-ns-journeys-102020 dd {
  margin: 0;
}
widget-ns-journeys-102020 h2 {
  font-size: 24px;
  line-height: 1.2;
}
widget-ns-journeys-102020 h3 {
  font-size: 20px;
  line-height: 1.25;
  margin-top: 8px;
}
widget-ns-journeys-102020 p {
  color: #52606d;
  line-height: 1.45;
  margin-top: 6px;
}
widget-ns-journeys-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 12px;
}
widget-ns-journeys-102020 button,
widget-ns-journeys-102020 input,
widget-ns-journeys-102020 textarea {
  font: inherit;
}
widget-ns-journeys-102020 button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
}
widget-ns-journeys-102020 button:disabled {
  cursor: not-allowed;
  opacity: 0.56;
}
widget-ns-journeys-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  min-height: 140px;
  padding: 10px 12px;
  resize: vertical;
  width: 100%;
}
widget-ns-journeys-102020 .ns-header-meta {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 148px;
}
widget-ns-journeys-102020 .ns-header-meta span,
widget-ns-journeys-102020 .ns-header-meta strong,
widget-ns-journeys-102020 .ns-pill {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 5px 9px;
}
widget-ns-journeys-102020 .ns-header-meta strong {
  background: #ecfdf5;
  color: #166534;
}
widget-ns-journeys-102020 .ns-auto-approve {
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  color: #475569;
  font-size: 13px;
  padding: 9px 12px;
}
widget-ns-journeys-102020 .ns-filters {
  align-items: end;
  display: grid;
  gap: 12px;
  grid-template-columns: minmax(240px, 1fr) minmax(280px, 2fr);
}
widget-ns-journeys-102020 .ns-search {
  display: grid;
  gap: 6px;
}
widget-ns-journeys-102020 .ns-search span,
widget-ns-journeys-102020 .ns-section-title span,
widget-ns-journeys-102020 .ns-feature small,
widget-ns-journeys-102020 .ns-journey-card small,
widget-ns-journeys-102020 .ns-review-input p,
widget-ns-journeys-102020 .ns-review-input label span {
  color: #64748b;
  font-size: 12px;
}
widget-ns-journeys-102020 .ns-search input {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  min-height: 38px;
  padding: 8px 10px;
}
widget-ns-journeys-102020 .ns-actor-filter {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
}
widget-ns-journeys-102020 .ns-actor-filter button,
widget-ns-journeys-102020 .ns-tabs button,
widget-ns-journeys-102020 .ns-priority button {
  background: #ffffff;
  color: #334155;
  padding: 8px 10px;
}
widget-ns-journeys-102020 .ns-actor-filter button.is-active,
widget-ns-journeys-102020 .ns-tabs button.is-active,
widget-ns-journeys-102020 .ns-priority button.is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #ffffff;
}
widget-ns-journeys-102020 .ns-actor-map,
widget-ns-journeys-102020 .ns-list,
widget-ns-journeys-102020 .ns-detail,
widget-ns-journeys-102020 .ns-features,
widget-ns-journeys-102020 .ns-history,
widget-ns-journeys-102020 .ns-review,
widget-ns-journeys-102020 .ns-state {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #ffffff;
}
widget-ns-journeys-102020 .ns-section-title {
  align-items: center;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  padding: 12px 14px;
}
widget-ns-journeys-102020 .ns-lanes {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  padding: 12px;
}
widget-ns-journeys-102020 .ns-lane {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 8px;
  padding: 10px;
}
widget-ns-journeys-102020 .ns-lane.is-filtered {
  border-color: #6366f1;
  box-shadow: 0 0 0 1px #6366f1 inset;
}
widget-ns-journeys-102020 .ns-lane-head {
  align-items: center;
  background: #f8fafc;
  display: flex;
  justify-content: space-between;
  padding: 8px 10px;
  text-align: left;
}
widget-ns-journeys-102020 .ns-lane-items {
  display: grid;
  gap: 6px;
}
widget-ns-journeys-102020 .ns-lane-items button {
  background: #ffffff;
  overflow: hidden;
  padding: 7px 8px;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}
widget-ns-journeys-102020 .ns-lane-items button.is-selected {
  border-color: #4338ca;
  color: #3730a3;
}
widget-ns-journeys-102020 .ns-main {
  align-items: start;
  display: grid;
  gap: 16px;
  grid-template-columns: minmax(250px, 0.82fr) minmax(0, 2fr);
}
widget-ns-journeys-102020 .ns-list {
  display: grid;
  gap: 8px;
  max-height: 760px;
  overflow: auto;
  padding: 12px;
}
widget-ns-journeys-102020 .ns-journey-card {
  background: #ffffff;
  display: grid;
  gap: 5px;
  padding: 12px;
  text-align: left;
}
widget-ns-journeys-102020 .ns-journey-card.is-selected {
  background: #f5f3ff;
  border-color: #7c3aed;
}
widget-ns-journeys-102020 .ns-journey-card span {
  color: #475569;
  font-size: 12px;
}
widget-ns-journeys-102020 .ns-journey-card small {
  display: -webkit-box;
  line-height: 1.35;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
widget-ns-journeys-102020 .ns-detail {
  display: grid;
  gap: 16px;
  padding: 16px;
}
widget-ns-journeys-102020 .ns-detail-head {
  display: flex;
  justify-content: space-between;
}
widget-ns-journeys-102020 .ns-summary {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
}
widget-ns-journeys-102020 .ns-summary div {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns-journeys-102020 .ns-summary dt {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 4px;
}
widget-ns-journeys-102020 .ns-summary dd {
  color: #1f2937;
  line-height: 1.4;
}
widget-ns-journeys-102020 .ns-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 6px;
}
widget-ns-journeys-102020 .ns-tabs button {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom-width: 0;
}
widget-ns-journeys-102020 .ns-steps {
  display: grid;
  gap: 10px;
  list-style: none;
  margin: 0;
  padding: 0;
}
widget-ns-journeys-102020 .ns-steps li {
  align-items: start;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 12px;
  grid-template-columns: auto 1fr;
  padding: 12px;
}
widget-ns-journeys-102020 .ns-step-index {
  align-items: center;
  background: #4338ca;
  border-radius: 999px;
  color: #ffffff;
  display: inline-flex;
  font-size: 13px;
  height: 28px;
  justify-content: center;
  width: 28px;
}
widget-ns-journeys-102020 .ns-step-features {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 10px;
}
widget-ns-journeys-102020 .ns-step-features span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 4px 8px;
}
widget-ns-journeys-102020 .ns-editor label {
  display: grid;
  gap: 8px;
}
widget-ns-journeys-102020 .ns-editor label span {
  color: #64748b;
  font-size: 12px;
}
widget-ns-journeys-102020 .ns-feature-grid {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  padding: 12px;
}
widget-ns-journeys-102020 .ns-feature {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 12px;
  padding: 12px;
}
widget-ns-journeys-102020 .ns-feature p {
  font-size: 13px;
}
widget-ns-journeys-102020 .ns-priority {
  display: grid;
  gap: 6px;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}
widget-ns-journeys-102020 .ns-priority button {
  overflow: hidden;
  padding-left: 6px;
  padding-right: 6px;
  text-overflow: ellipsis;
}
widget-ns-journeys-102020 .ns-review {
  display: grid;
  gap: 12px;
  padding: 14px;
}
widget-ns-journeys-102020 .ns-review-input {
  align-items: start;
  display: grid;
  gap: 14px;
  grid-template-columns: minmax(170px, 0.4fr) minmax(280px, 1fr) auto;
}
widget-ns-journeys-102020 .ns-review-input label {
  display: grid;
  gap: 4px;
}
widget-ns-journeys-102020 .ns-review-input textarea {
  min-height: 74px;
}
widget-ns-journeys-102020 .ns-review-input label span {
  text-align: right;
}
widget-ns-journeys-102020 .ns-review-buttons {
  display: flex;
  gap: 8px;
}
widget-ns-journeys-102020 .ns-review-buttons button {
  background: #ffffff;
  min-height: 40px;
  padding: 8px 12px;
  white-space: nowrap;
}
widget-ns-journeys-102020 .ns-review-buttons .ns-primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #ffffff;
}
widget-ns-journeys-102020 .ns-change-preview {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns-journeys-102020 .ns-change-preview ol {
  margin: 8px 0 0 18px;
  padding: 0;
}
widget-ns-journeys-102020 .ns-change-preview li {
  color: #475569;
  line-height: 1.4;
  margin-top: 4px;
}
widget-ns-journeys-102020 .ns-history-list {
  display: grid;
  gap: 8px;
  list-style: none;
  margin: 0;
  padding: 12px;
}
widget-ns-journeys-102020 .ns-history-list li {
  align-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 8px;
  grid-template-columns: auto 1fr auto auto;
  padding: 9px 10px;
}
widget-ns-journeys-102020 .ns-history-list span,
widget-ns-journeys-102020 .ns-history-list time {
  color: #64748b;
  font-size: 12px;
}
widget-ns-journeys-102020 .ns-state {
  padding: 14px;
}
widget-ns-journeys-102020 .ns-state--error {
  background: #fef2f2;
  border-color: #fecaca;
  color: #991b1b;
}
@media (max-width: 900px) {
  widget-ns-journeys-102020 .ns-header,
  widget-ns-journeys-102020 .ns-filters,
  widget-ns-journeys-102020 .ns-main,
  widget-ns-journeys-102020 .ns-review-input {
    grid-template-columns: 1fr;
  }
  widget-ns-journeys-102020 .ns-header,
  widget-ns-journeys-102020 .ns-review-input {
    display: grid;
  }
  widget-ns-journeys-102020 .ns-history-list li {
    grid-template-columns: 1fr;
  }
  widget-ns-journeys-102020 .ns-header-meta,
  widget-ns-journeys-102020 .ns-actor-filter {
    align-items: flex-start;
    justify-content: flex-start;
  }
  widget-ns-journeys-102020 .ns-review-buttons {
    flex-wrap: wrap;
  }
}
`);
        this.value = null;
        this._loading = true;
        this._artifact = null;
        this._error = '';
        this._search = '';
        this._selectedActorId = 'all';
        this._selectedJourneyId = '';
        this._activeTab = 'overview';
        this._adjustment = '';
        this._featurePriorities = {};
        this._businessRuleTexts = {};
        this._journeyNotes = {};
        this._changeLog = [];
        this._autoApproveRemainingSeconds = 0;
        this._loadedFor = '';
        this._changeSequence = 0;
        this._autoApproveTimer = null;
        this._autoApproveTimerKey = '';
        this._autoApproveCancelledFor = '';
    }
    async connectedCallback() {
        super.connectedCallback();
        await this._load();
    }
    disconnectedCallback() {
        this._clearAutoApproveTimer();
        super.disconnectedCallback();
    }
    updated(changed) {
        super.updated(changed);
        const loadKey = this._loadKey();
        if (changed.has('value')) {
            if (loadKey !== this._loadedFor)
                void this._load();
            else
                this._syncAutoApproveTimer();
        }
    }
    get _config() {
        return this.value && !isJourneysArtifact(this.value) ? this.value : {};
    }
    get _msg() {
        const base = this._artifact?.userLanguage === 'pt-BR' ? messages_ptBR : messages_en;
        return { ...base, ...(this._config.uiLabels || {}) };
    }
    get _priorityLabels() {
        return this._artifact?.userLanguage === 'pt-BR' ? priorityLabelsPtBR : priorityLabelsEn;
    }
    get _readOnly() {
        return !!this._config.readOnly;
    }
    async _load() {
        const loadKey = this._loadKey();
        this._loadedFor = loadKey;
        this._loading = true;
        this._error = '';
        this._clearAutoApproveTimer();
        this._resetReviewState();
        try {
            const artifact = this._artifactFromValue();
            if (artifact) {
                this._setArtifact(artifact);
                return;
            }
            const moduleName = this._config.moduleName;
            if (!moduleName) {
                this._setArtifact(null);
                return;
            }
            const fileInfo = nsPipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json');
            if (this._config.project)
                fileInfo.project = this._config.project;
            this._setArtifact(await readJsonArtifact(fileInfo, false));
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
            this._setArtifact(null);
        }
        finally {
            this._loading = false;
        }
    }
    render() {
        const m = this._msg;
        if (this._loading)
            return html `<section class="ns-journeys"><div class="ns-state">${m.loading}</div></section>`;
        if (this._error)
            return html `<section class="ns-journeys"><div class="ns-state ns-state--error">${this._error}</div></section>`;
        if (!this._artifact)
            return html `<section class="ns-journeys"><div class="ns-state">${m.noArtifact}</div></section>`;
        const artifact = this._artifact;
        const visibleJourneys = this._visibleJourneys(artifact);
        const selectedJourney = this._selectedJourney(artifact, visibleJourneys);
        return html `
      <section
        class="ns-journeys"
        @click=${() => this._cancelAutoApprove()}
        @focusin=${() => this._cancelAutoApprove()}
        @input=${() => this._cancelAutoApprove()}
        @keydown=${() => this._cancelAutoApprove()}
      >
        ${this._renderHeader(artifact)}
        ${this._renderAutoApproveCounter()}
        ${this._renderFilters(artifact, visibleJourneys)}
        ${this._renderActorMap(artifact)}
        <div class="ns-main">
          ${this._renderJourneyList(artifact, visibleJourneys, selectedJourney)}
          ${selectedJourney ? this._renderJourneyDetail(artifact, selectedJourney) : html `<div class="ns-detail"><div class="ns-state">${m.noJourney}</div></div>`}
        </div>
        ${this._renderFeatureCatalog(artifact)}
        ${this._renderHistory(artifact)}
        ${this._renderReviewBar(artifact)}
      </section>
    `;
    }
    _renderHeader(artifact) {
        const m = this._msg;
        const mode = this._config.mode === 'change-module' ? m.changeModule : m.newModule;
        return html `
      <header class="ns-header">
        <div>
          <div class="ns-breadcrumb">${artifact.moduleName} / E2 / ${m.title}</div>
          <h2>${m.title}</h2>
          <p>${m.subtitle}</p>
        </div>
        <div class="ns-header-meta">
          <span>${mode}</span>
          <strong>${m.version} v${artifact.version}</strong>
          ${this._readOnly ? html `<span>${m.readOnly}</span>` : nothing}
        </div>
      </header>
    `;
    }
    _renderAutoApproveCounter() {
        if (this._autoApproveRemainingSeconds <= 0)
            return nothing;
        const text = this._artifact?.userLanguage === 'pt-BR'
            ? `Auto-aprovando em ${this._autoApproveRemainingSeconds}s...`
            : `Auto-approving in ${this._autoApproveRemainingSeconds}s...`;
        return html `<div class="ns-auto-approve" role="status">${text}</div>`;
    }
    _renderFilters(artifact, visibleJourneys) {
        const m = this._msg;
        return html `
      <section class="ns-filters">
        <label class="ns-search">
          <span>${visibleJourneys.length} ${m.journeysFound}</span>
          <input
            .value=${this._search}
            placeholder=${m.searchPlaceholder}
            @input=${(event) => { this._search = event.target.value; }}
          />
        </label>
        <div class="ns-actor-filter" role="group" aria-label=${m.actorMap}>
          <button class=${this._selectedActorId === 'all' ? 'is-active' : ''} @click=${() => { this._selectedActorId = 'all'; }}>
            ${m.allActors}
          </button>
          ${artifact.actors.map(actor => html `
            <button class=${this._selectedActorId === actor.actorId ? 'is-active' : ''} @click=${() => { this._selectedActorId = actor.actorId; }}>
              ${actor.name}
            </button>
          `)}
        </div>
      </section>
    `;
    }
    _renderActorMap(artifact) {
        const m = this._msg;
        return html `
      <section class="ns-actor-map">
        <div class="ns-section-title">
          <strong>${m.actorMap}</strong>
          <span>${artifact.actors.length} ${m.actors} / ${artifact.journeys.length} ${m.journeys}</span>
        </div>
        <div class="ns-lanes">
          ${artifact.actors.map(actor => {
            const journeys = artifact.journeys.filter(journey => journey.actorId === actor.actorId);
            return html `
              <div class=${this._selectedActorId === actor.actorId ? 'ns-lane is-filtered' : 'ns-lane'}>
                <button class="ns-lane-head" @click=${() => { this._selectedActorId = actor.actorId; }}>
                  <span>${actor.name}</span>
                  <strong>${journeys.length}</strong>
                </button>
                <div class="ns-lane-items">
                  ${journeys.map(journey => html `
                    <button
                      class=${this._selectedJourneyId === journey.journeyId ? 'is-selected' : ''}
                      @click=${() => this._selectJourney(journey.journeyId)}
                    >
                      ${journey.title}
                    </button>
                  `)}
                </div>
              </div>
            `;
        })}
        </div>
      </section>
    `;
    }
    _renderJourneyList(artifact, journeys, selectedJourney) {
        const m = this._msg;
        const actorById = new Map(artifact.actors.map(actor => [actor.actorId, actor]));
        return html `
      <aside class="ns-list">
        ${journeys.map(journey => {
            const actor = actorById.get(journey.actorId);
            return html `
            <button
              class=${selectedJourney?.journeyId === journey.journeyId ? 'ns-journey-card is-selected' : 'ns-journey-card'}
              @click=${() => this._selectJourney(journey.journeyId)}
            >
              <strong>${journey.title}</strong>
              <span>${actor?.name || journey.actorId} &middot; ${journey.steps.length} ${m.steps}</span>
              <small>${journey.outcome}</small>
            </button>
          `;
        })}
      </aside>
    `;
    }
    _renderJourneyDetail(artifact, journey) {
        const m = this._msg;
        const actor = artifact.actors.find(item => item.actorId === journey.actorId);
        return html `
      <main class="ns-detail">
        <header class="ns-detail-head">
          <div>
            <span class="ns-pill">${actor?.name || journey.actorId}</span>
            <h3>${journey.title}</h3>
            <code>${journey.journeyId}</code>
          </div>
        </header>

        <dl class="ns-summary">
          ${this._renderDefinition(m.goal, journey.goal)}
          ${journey.soThat ? this._renderDefinition(m.soThat, journey.soThat) : nothing}
          ${journey.trigger ? this._renderDefinition(m.trigger, journey.trigger) : nothing}
          ${this._renderDefinition(m.outcome, journey.outcome)}
        </dl>

        <nav class="ns-tabs" role="tablist">
          ${this._renderTab('overview', m.overview)}
          ${this._renderTab('rules', m.businessRules)}
          ${this._renderTab('notes', m.notes)}
        </nav>

        ${this._activeTab === 'overview' ? this._renderOverview(artifact, journey) : nothing}
        ${this._activeTab === 'rules' ? this._renderRules(journey) : nothing}
        ${this._activeTab === 'notes' ? this._renderNotes(journey) : nothing}
      </main>
    `;
    }
    _renderDefinition(label, value) {
        return html `<div><dt>${label}</dt><dd>${value}</dd></div>`;
    }
    _renderTab(tab, label) {
        return html `
      <button
        role="tab"
        aria-selected=${this._activeTab === tab ? 'true' : 'false'}
        class=${this._activeTab === tab ? 'is-active' : ''}
        @click=${() => { this._activeTab = tab; }}
      >
        ${label}
      </button>
    `;
    }
    _renderOverview(artifact, journey) {
        const featureById = new Map(artifact.features.map(feature => [feature.featureId, feature]));
        return html `
      <ol class="ns-steps">
        ${journey.steps.map((step, index) => html `
          <li>
            <span class="ns-step-index">${index + 1}</span>
            <div>
              <strong>${step.title}</strong>
              <p>${step.intent}</p>
              ${step.result ? html `<small>${step.result}</small>` : nothing}
              ${this._renderStepFeatures(step, featureById)}
            </div>
          </li>
        `)}
      </ol>
    `;
    }
    _renderStepFeatures(step, featureById) {
        if (step.featureRefs.length === 0)
            return html ``;
        return html `
      <div class="ns-step-features">
        ${step.featureRefs.map(ref => {
            const feature = featureById.get(ref);
            return html `<span>${feature?.title || ref}</span>`;
        })}
      </div>
    `;
    }
    _renderRules(journey) {
        const m = this._msg;
        return html `
      <section class="ns-editor">
        <label>
          <span>${m.rulesHelp}</span>
          <textarea
            .value=${this._businessRulesText(journey)}
            ?disabled=${this._readOnly}
            @input=${(event) => this._onRulesInput(journey, event)}
            @change=${(event) => this._onRulesCommit(journey, event)}
          ></textarea>
        </label>
      </section>
    `;
    }
    _renderNotes(journey) {
        const m = this._msg;
        return html `
      <section class="ns-editor">
        <label>
          <span>${m.notes}</span>
          <textarea
            .value=${this._currentNotes(journey)}
            placeholder=${m.notesPlaceholder}
            ?disabled=${this._readOnly}
            @input=${(event) => this._onNotesInput(journey, event)}
            @change=${(event) => this._onNotesCommit(journey, event)}
          ></textarea>
        </label>
      </section>
    `;
    }
    _renderFeatureCatalog(artifact) {
        const m = this._msg;
        const actorById = new Map(artifact.actors.map(actor => [actor.actorId, actor]));
        return html `
      <section class="ns-features">
        <div class="ns-section-title">
          <strong>${m.featureCatalog}</strong>
          <span>${artifact.features.length} ${m.features}</span>
        </div>
        <div class="ns-feature-grid">
          ${artifact.features.map(feature => html `
            <article class="ns-feature">
              <div>
                <strong>${feature.title}</strong>
                <code>${feature.featureId}</code>
                ${feature.description ? html `<p>${feature.description}</p>` : nothing}
                <small>${m.usedBy}: ${feature.actorIds.map(actorId => actorById.get(actorId)?.name || actorId).join(', ')}</small>
              </div>
              ${this._renderPrioritySelector(feature)}
            </article>
          `)}
        </div>
      </section>
    `;
    }
    _renderPrioritySelector(feature) {
        const m = this._msg;
        const current = this._currentPriority(feature);
        return html `
      <div class="ns-priority" aria-label=${`${m.priority}: ${feature.title}`}>
        ${NS_E2_PRIORITIES.map(priority => html `
          <button
            class=${current === priority ? 'is-active' : ''}
            aria-pressed=${current === priority ? 'true' : 'false'}
            ?disabled=${this._readOnly}
            @click=${() => this._setFeaturePriority(feature, priority)}
          >
            ${this._priorityLabels[priority]}
          </button>
        `)}
      </div>
    `;
    }
    _renderReviewBar(artifact) {
        const m = this._msg;
        const edits = this._currentEdits();
        const hasReviewInput = hasNsJourneysWidgetEdits(edits) || !!this._adjustment.trim();
        return html `
      <section class="ns-review">
        <div class="ns-review-input">
          <div>
            <strong>${m.adjustmentTitle}</strong>
            <p>${m.payload}: <code>checkpoint-journeys-answer</code></p>
          </div>
          <label>
            <textarea
              .value=${this._adjustment}
              maxlength="1000"
              placeholder=${m.adjustmentPlaceholder}
              ?disabled=${this._readOnly}
              @input=${(event) => { this._adjustment = event.target.value; }}
            ></textarea>
            <span>${this._adjustment.length} / 1000</span>
          </label>
          <div class="ns-review-buttons">
            <button ?disabled=${this._readOnly || !hasReviewInput} @click=${() => this._submitReview(artifact, 'adjust')}>
              ${m.requestAdjustment}
            </button>
            <button class="ns-primary" ?disabled=${this._readOnly} @click=${() => this._submitReview(artifact, 'approve')}>
              ${hasNsJourneysWidgetEdits(edits) ? m.approveWithChanges : m.approve}
            </button>
          </div>
        </div>
        <div class="ns-change-preview">
          <strong>${m.changesPreview}</strong>
          ${this._changeLog.length === 0
            ? html `<p>${m.noChanges}</p>`
            : html `<ol>${this._changeLog.slice(-6).map(change => html `<li>${change.summary}</li>`)}</ol>`}
        </div>
      </section>
    `;
    }
    _renderHistory(artifact) {
        const m = this._msg;
        const items = this._historyItems(artifact);
        return html `
      <section class="ns-history">
        <div class="ns-section-title">
          <strong>${m.history}</strong>
          <span>${m.version} v${artifact.version}</span>
        </div>
        <ol class="ns-history-list">
          ${items.map(item => html `
            <li>
              <strong>v${item.version}</strong>
              <span>${item.summary}</span>
              ${item.createdAt ? html `<time>${item.createdAt}</time>` : nothing}
              ${item.status ? html `<code>${item.status}</code>` : nothing}
            </li>
          `)}
        </ol>
      </section>
    `;
    }
    _historyItems(artifact) {
        const current = {
            version: artifact.version,
            createdAt: artifact.createdAt,
            summary: this._msg.currentVersion,
            status: 'current',
        };
        const history = this._config.history || [];
        if (history.length === 0)
            return [current];
        return history.some(item => item.version === artifact.version) ? history : [current, ...history];
    }
    _setArtifact(artifact) {
        this._artifact = artifact;
        this._selectedJourneyId = artifact?.journeys[0]?.journeyId || '';
        this._syncAutoApproveTimer();
    }
    _artifactFromValue() {
        if (isJourneysArtifact(this.value))
            return this.value;
        if (isJourneysArtifact(this._config.artifact))
            return this._config.artifact;
        return null;
    }
    _loadKey() {
        const artifact = this._artifactFromValue();
        if (artifact)
            return `${artifact.moduleName}:${artifact.version}:${artifact.createdAt}`;
        return `${this._config.project || mls.actualProject || 0}:${this._config.moduleName || ''}`;
    }
    _resetReviewState() {
        this._adjustment = '';
        this._featurePriorities = {};
        this._businessRuleTexts = {};
        this._journeyNotes = {};
        this._changeLog = [];
        this._activeTab = 'overview';
    }
    _visibleJourneys(artifact) {
        const actorById = new Map(artifact.actors.map(actor => [actor.actorId, actor]));
        const featureById = new Map(artifact.features.map(feature => [feature.featureId, feature]));
        const term = this._search.trim().toLowerCase();
        return artifact.journeys.filter(journey => {
            if (this._selectedActorId !== 'all' && journey.actorId !== this._selectedActorId)
                return false;
            if (!term)
                return true;
            return this._matchesSearch(journey, actorById.get(journey.actorId), featureById, term);
        });
    }
    _matchesSearch(journey, actor, featureById, term) {
        const featureText = journey.steps
            .flatMap(step => step.featureRefs.map(ref => featureById.get(ref)?.title || ref))
            .join(' ');
        const text = [
            journey.title,
            journey.goal,
            journey.soThat,
            journey.trigger,
            journey.outcome,
            actor?.name,
            actor?.description,
            featureText,
        ].filter(Boolean).join(' ').toLowerCase();
        return text.includes(term);
    }
    _selectedJourney(artifact, visibleJourneys) {
        const selected = visibleJourneys.find(journey => journey.journeyId === this._selectedJourneyId);
        return selected || visibleJourneys[0] || artifact.journeys[0] || null;
    }
    _selectJourney(journeyId) {
        this._selectedJourneyId = journeyId;
        this._activeTab = 'overview';
    }
    _currentPriority(feature) {
        return this._featurePriorities[feature.featureId] || feature.priority;
    }
    _setFeaturePriority(feature, priority) {
        if (this._readOnly || this._currentPriority(feature) === priority)
            return;
        const before = this._currentPriority(feature);
        const next = { ...this._featurePriorities };
        if (priority === feature.priority)
            delete next[feature.featureId];
        else
            next[feature.featureId] = priority;
        this._featurePriorities = next;
        this._recordChange('featurePriorityChanged', feature.featureId, before, priority, `${feature.title}: ${this._priorityLabels[before]} -> ${this._priorityLabels[priority]}`);
    }
    _businessRulesText(journey) {
        return this._businessRuleTexts[journey.journeyId] ?? serializeNsBusinessRules(journey.businessRules);
    }
    _onRulesInput(journey, event) {
        this._businessRuleTexts = {
            ...this._businessRuleTexts,
            [journey.journeyId]: event.target.value,
        };
    }
    _onRulesCommit(journey, event) {
        if (this._readOnly)
            return;
        const text = event.target.value;
        const rules = parseNsBusinessRulesText(text);
        if (sameStringArray(rules, journey.businessRules)) {
            const next = { ...this._businessRuleTexts };
            delete next[journey.journeyId];
            this._businessRuleTexts = next;
            return;
        }
        this._recordChange('journeyBusinessRulesChanged', journey.journeyId, journey.businessRules, rules, `${journey.title}: ${this._msg.businessRules}`);
    }
    _currentNotes(journey) {
        return this._journeyNotes[journey.journeyId] ?? journey.notes;
    }
    _onNotesInput(journey, event) {
        this._journeyNotes = {
            ...this._journeyNotes,
            [journey.journeyId]: event.target.value,
        };
    }
    _onNotesCommit(journey, event) {
        if (this._readOnly)
            return;
        const notes = event.target.value.trim();
        if (notes === journey.notes) {
            const next = { ...this._journeyNotes };
            delete next[journey.journeyId];
            this._journeyNotes = next;
            return;
        }
        this._recordChange('journeyNotesChanged', journey.journeyId, journey.notes, notes, `${journey.title}: ${this._msg.notes}`);
    }
    _currentEdits() {
        const edits = emptyNsJourneysWidgetEdits();
        edits.featurePriorities = { ...this._featurePriorities };
        Object.keys(this._businessRuleTexts).forEach(journeyId => {
            edits.journeyBusinessRules[journeyId] = parseNsBusinessRulesText(this._businessRuleTexts[journeyId] || '');
        });
        Object.keys(this._journeyNotes).forEach(journeyId => {
            edits.journeyNotes[journeyId] = (this._journeyNotes[journeyId] || '').trim();
        });
        return edits;
    }
    _recordChange(kind, targetId, before, after, summary) {
        const change = {
            id: `${kind}-${Date.now()}-${++this._changeSequence}`,
            at: new Date().toISOString(),
            kind,
            targetId,
            summary,
            before,
            after,
        };
        this._changeLog = [...this._changeLog, change];
        this._emitChange(change);
        return change;
    }
    _emitChange(change) {
        if (!this._artifact)
            return;
        const detail = {
            type: 'checkpoint-journeys-change',
            moduleName: this._artifact.moduleName,
            version: this._artifact.version,
            change,
            changes: [...this._changeLog],
            edits: this._currentEdits(),
        };
        this.dispatchEvent(new CustomEvent('ns-journeys-change', {
            detail,
            bubbles: true,
            composed: true,
        }));
    }
    _submitReview(artifact, action) {
        this._cancelAutoApprove();
        const edits = this._currentEdits();
        if (action === 'adjust' && !hasNsJourneysWidgetEdits(edits) && !this._adjustment.trim())
            return;
        this._recordChange('reviewSubmitted', 'checkpoint-journeys', null, { action, adjustment: this._adjustment.trim(), edits }, action === 'approve' ? this._msg.approve : this._msg.requestAdjustment);
        const payload = buildNsJourneysReviewPayload({
            artifact,
            action,
            adjustment: this._adjustment,
            edits,
            changes: this._changeLog,
        });
        this.dispatchEvent(new CustomEvent('ns-journeys-review', {
            detail: payload,
            bubbles: true,
            composed: true,
        }));
    }
    _syncAutoApproveTimer() {
        const seconds = this._autoAcceptSeconds();
        const key = this._autoApproveKey(seconds);
        if (!this._artifact || this._readOnly || seconds <= 0 || this._autoApproveCancelledFor === key) {
            this._clearAutoApproveTimer();
            return;
        }
        if (this._autoApproveTimer !== null && this._autoApproveTimerKey === key)
            return;
        this._clearAutoApproveTimer();
        this._autoApproveTimerKey = key;
        this._autoApproveRemainingSeconds = seconds;
        this._autoApproveTimer = window.setInterval(() => {
            this._autoApproveRemainingSeconds = Math.max(0, this._autoApproveRemainingSeconds - 1);
            if (this._autoApproveRemainingSeconds === 0) {
                const artifact = this._artifact;
                this._clearAutoApproveTimer();
                if (artifact)
                    this._submitReview(artifact, 'approve');
            }
        }, 1000);
    }
    _cancelAutoApprove() {
        const seconds = this._autoAcceptSeconds();
        if (seconds > 0)
            this._autoApproveCancelledFor = this._autoApproveKey(seconds);
        this._clearAutoApproveTimer();
    }
    _clearAutoApproveTimer() {
        if (this._autoApproveTimer !== null) {
            window.clearInterval(this._autoApproveTimer);
            this._autoApproveTimer = null;
        }
        this._autoApproveTimerKey = '';
        this._autoApproveRemainingSeconds = 0;
    }
    _autoAcceptSeconds() {
        const raw = this.value?.autoAcceptSeconds;
        return typeof raw === 'number' && Number.isFinite(raw) ? Math.max(0, Math.floor(raw)) : 0;
    }
    _autoApproveKey(seconds) {
        return `${this._artifact?.moduleName || this._config.moduleName || ''}:${this._artifact?.version || ''}:${this._artifact?.createdAt || ''}:${seconds}`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNsJourneys102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_loading", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_artifact", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_error", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_search", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_selectedActorId", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_selectedJourneyId", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_activeTab", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_adjustment", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_featurePriorities", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_businessRuleTexts", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_journeyNotes", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_changeLog", void 0);
__decorate([
    state()
], WidgetNsJourneys102020.prototype, "_autoApproveRemainingSeconds", void 0);
WidgetNsJourneys102020 = __decorate([
    customElement('widget-ns-journeys-102020')
], WidgetNsJourneys102020);
export { WidgetNsJourneys102020 };
function isJourneysArtifact(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return false;
    const candidate = value;
    return Array.isArray(candidate.actors)
        && Array.isArray(candidate.journeys)
        && Array.isArray(candidate.features)
        && typeof candidate.moduleName === 'string';
}
