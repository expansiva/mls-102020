/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e2-journeys/judge.ts" enhancement="_blank"/>
/** The e2 schema version from which a journey can declare `prerequisite` (J2 is meaningless before it). */
export const NS_E2_PREREQUISITE_SCHEMA_VERSION = '2026-08-02-ns-e2-v2';
/** 1 judge call on the first pass, 1 more on the repaired artifact. Never a third. */
export const NS_E2_MAX_JUDGE_ATTEMPTS = 2;
/** SEVERITY IS OWNED HERE. J4/J5 are genuinely interpretive: they annotate, the human decides. */
const JUDGE_SEVERITY = {
    'journey.step.locateMissing': 'error',
    'journey.prerequisite.missing': 'error',
    'journey.prerequisite.invalid': 'error',
    'journey.actor.stepMismatch': 'error',
    'entity.noReadSurface': 'warning',
    'journey.outcome.unobservable': 'warning',
};
const JUDGE_CODES = Object.keys(JUDGE_SEVERITY);
const PREREQUISITE_CODES = ['journey.prerequisite.missing', 'journey.prerequisite.invalid'];
/** Does this artifact even carry the field J2 asks about? */
export function nsE2SupportsPrerequisite(artifact) {
    return artifact.schemaVersion === NS_E2_PREREQUISITE_SCHEMA_VERSION;
}
/**
 * Turn whatever the model returned into findings this pipeline is willing to act on. Everything that
 * cannot be acted on is discarded WITH a reason.
 */
export function normalizeNsE2JudgeFindings(raw, artifact, judgeAttempt) {
    const journeys = new Map(artifact.journeys.map(journey => [journey.journeyId, journey]));
    const supportsPrerequisite = nsE2SupportsPrerequisite(artifact);
    const findings = [];
    const discarded = [];
    const seen = new Set();
    for (const item of Array.isArray(raw) ? raw : []) {
        const record = isRecord(item) ? item : {};
        const label = JSON.stringify(record).slice(0, 200);
        const code = readText(record.code);
        if (!JUDGE_CODES.includes(code)) {
            discarded.push({ reason: 'code is not in the rubric', raw: label });
            continue;
        }
        if (PREREQUISITE_CODES.includes(code) && !supportsPrerequisite) {
            discarded.push({ reason: `artifact schema ${artifact.schemaVersion} has no prerequisite field`, raw: label });
            continue;
        }
        const journeyId = readText(record.journeyId);
        if (journeyId && !journeys.has(journeyId)) {
            discarded.push({ reason: `journey ${journeyId} does not exist`, raw: label });
            continue;
        }
        // Every code except the module-wide J4 is a statement ABOUT a journey.
        if (!journeyId && code !== 'entity.noReadSurface') {
            discarded.push({ reason: 'finding names no journey', raw: label });
            continue;
        }
        const finding = {
            code,
            severity: JUDGE_SEVERITY[code],
            detail: readText(record.detail) || readText(record.message) || '(no detail)',
        };
        if (journeyId)
            finding.journeyId = journeyId;
        const stepId = readText(record.stepId);
        // A step that does not exist does not invalidate the journey-level claim — only the pointer.
        if (stepId && journeyId && journeys.get(journeyId)?.steps.some(step => step.stepId === stepId))
            finding.stepId = stepId;
        const subject = readText(record.subject);
        if (subject)
            finding.subject = subject;
        const key = `${finding.code}|${finding.journeyId || ''}|${finding.subject || ''}`;
        if (seen.has(key)) {
            discarded.push({ reason: 'duplicate of a finding already reported', raw: label });
            continue;
        }
        seen.add(key);
        findings.push(finding);
    }
    return { moduleName: artifact.moduleName, version: artifact.version, judgeAttempt, findings, discarded };
}
/**
 * `repair` = one rerun of e2 with the findings in the standard retry context. Anything else proceeds to
 * the checkpoint carrying the findings — a judge that keeps disagreeing does NOT get to block the run;
 * the human reads the annotation and decides.
 */
export function decideNsE2JudgeOutcome(input) {
    if (input.annotateOnly)
        return 'proceed';
    if (input.judgeAttempt >= NS_E2_MAX_JUDGE_ATTEMPTS)
        return 'proceed';
    return input.findings.some(finding => finding.severity === 'error') ? 'repair' : 'proceed';
}
export function decideNsE2NextStep(input) {
    const wantsCheckpoint = input.afterAdjustment || !input.hasCheckpoint;
    // /fast is the dev shortcut that auto-approves the checkpoint server-side: it must not pay for a
    // judge call and a possible repair round on the way there.
    if (input.fastMode)
        return wantsCheckpoint ? 'checkpoint' : 'none';
    if (input.judgeAttempt > NS_E2_MAX_JUDGE_ATTEMPTS)
        return wantsCheckpoint ? 'checkpoint' : 'none';
    return 'judge';
}
/** The findings as the e2 rerun receives them — the same channel a gate error uses. */
export function renderNsE2JudgeRetryContext(report) {
    const errors = report.findings.filter(finding => finding.severity === 'error');
    if (errors.length === 0)
        return '';
    return [
        'A review of these journeys found the problems below. Fix EXACTLY these, changing nothing else:',
        ...errors.map(finding => `- [${finding.code}] ${describeTarget(finding)}: ${finding.detail}`),
    ].join('\n');
}
/** The findings as the human reads them at the checkpoint (appended to e2-journeys.md). */
export function renderNsE2JudgeMarkdown(report) {
    if (report.findings.length === 0 && report.discarded.length === 0)
        return '';
    const lines = ['', '## Journey Review'];
    if (report.findings.length === 0)
        lines.push('- No findings.');
    for (const finding of report.findings) {
        lines.push(`- **${finding.severity}** \`${finding.code}\` ${describeTarget(finding)}: ${finding.detail}`);
    }
    if (report.discarded.length > 0) {
        lines.push(`- (${report.discarded.length} proposed finding(s) discarded as unactionable — see the trace.)`);
    }
    return lines.join('\n');
}
function describeTarget(finding) {
    const parts = [finding.journeyId, finding.stepId, finding.subject].filter(Boolean);
    return parts.length > 0 ? parts.join(' / ') : 'module';
}
export function buildNsE2JudgeStepPlan(input) {
    return {
        stepTitle: 'Review E2 journeys (automatic)',
        status: 'waiting_human_input',
        prompt: JSON.stringify({ planId: 'e2-judge', moduleName: input.moduleName, judgeAttempt: input.judgeAttempt, annotateOnly: input.annotateOnly }),
        planning: { planId: `e2-judge-${input.judgeAttempt}-${input.now}`, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
/** The repair: ONE rerun of e2 through the same `retryContext` channel a gate error uses. */
export function buildNsE2JudgeRepairStepPlan(input) {
    return {
        stepTitle: 'Rework E2 journeys (review findings)',
        status: 'waiting_human_input',
        prompt: JSON.stringify({ planId: 'e2-journeys', moduleName: input.moduleName, retryContext: input.retryContext, judgeAttempt: input.judgeAttempt }),
        planning: { planId: `e2-journeys-review-${input.now}`, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
/** Compact view handed to the judge: the narrative it must reason about, without the catalog noise. */
export function summarizeNsE2ForJudge(artifact) {
    return {
        schemaVersion: artifact.schemaVersion,
        userLanguage: artifact.userLanguage,
        declaresPrerequisite: nsE2SupportsPrerequisite(artifact),
        actors: artifact.actors.map(actor => ({ actorId: actor.actorId, name: actor.name, description: actor.description })),
        journeys: artifact.journeys.map(summarizeJourneyForJudge),
    };
}
function summarizeJourneyForJudge(journey) {
    const summary = {
        journeyId: journey.journeyId,
        actorId: journey.actorId,
        title: journey.title,
        goal: journey.goal,
        outcome: journey.outcome,
        steps: journey.steps.map(step => ({ stepId: step.stepId, title: step.title, intent: step.intent, result: step.result })),
        businessRules: journey.businessRules,
    };
    if (journey.prerequisite)
        summary.prerequisite = journey.prerequisite;
    return summary;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function readText(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : '';
}
