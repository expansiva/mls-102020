/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e5/gate.ts" enhancement="_blank"/>
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
export function collectNs4ReferencedRuleIds(sources) {
    return [...new Set([
            ...sources.journeys.journeys.flatMap(journey => journey.business.useRules),
            ...sources.access.grants.flatMap(grant => grant.useRules),
            ...sources.ontology.entities.flatMap(entity => entity.useRules),
        ])].sort();
}
export function validateNs4E5Review(review, sources) {
    const issues = [];
    const add = (code, path, message) => issues.push({ code, path, message });
    if (review.moduleName !== sources.module.module.moduleName)
        add('NS4_E5_MODULE', 'moduleName', 'Must match the approved module.');
    const ruleIds = new Set();
    review.rules.forEach((rule, index) => {
        const path = `rules[${index}]`;
        if (!MEMBER_ID.test(rule.id))
            add('NS4_E5_RULE_ID', `${path}.id`, 'Must be a lower-camel id.');
        if (ruleIds.has(rule.id))
            add('NS4_E5_RULE_DUPLICATE', `${path}.id`, `Duplicate rule ${rule.id}.`);
        if (rule.id)
            ruleIds.add(rule.id);
        if (!rule.description)
            add('NS4_E5_RULE_DESCRIPTION', `${path}.description`, 'Business description is required.');
    });
    for (const ruleId of collectNs4ReferencedRuleIds(sources)) {
        if (!ruleIds.has(ruleId))
            add('NS4_E5_RULE_REFERENCE_MISSING', 'rules', `Referenced rule ${ruleId} has no description.`);
    }
    return { ok: issues.length === 0, issues };
}
