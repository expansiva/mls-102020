/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e5/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution/steps/e2/contracts.js';
export const NS4_RULES_SCHEMA_VERSION = '2026-08-09-ns4-rules-v2';
export function normalizeNs4E5Review(value, fallbackModule = '') {
    const root = record(value);
    return {
        planId: 'e5-rules-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business rules',
        reviewRound: positiveInteger(root.reviewRound, 1),
        rules: array(root.rules).map(item => {
            const rule = record(item);
            return { id: text(rule.id), description: text(rule.description) };
        }),
        changeSummary: strings(root.changeSummary),
    };
}
export async function buildNs4RulesArtifact(review, approvedBy, approvedAt) {
    const rulesHash = await sha256Ns4(review.rules);
    return {
        schemaVersion: NS4_RULES_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        rules: review.rules,
        rulesHash,
        approvedBy,
        approvedAt,
        realization: { status: 'pending', compiledFromRulesHash: rulesHash },
    };
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
