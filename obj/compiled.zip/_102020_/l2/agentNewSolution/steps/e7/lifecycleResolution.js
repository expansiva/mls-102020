/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e7/lifecycleResolution.ts" enhancement="_blank"/>
export function createNs4E7LifecycleResolutionReview(moduleName, issues) {
    return {
        planId: 'e7-lifecycle-resolution', moduleName,
        findings: issues.filter(issue => !!issue.repairOptions).map((issue, index) => ({
            ...issue, findingId: `${issue.code}:${issue.path}:${index}`,
        })),
    };
}
