/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e6-journey-map/agentNsJourneyMap.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { isRecord, listExistingModuleFolders, NS_AGENT_FOLDER, nsL2File, nsOperationsFolder, nsPipelineArtifactFileInfo, nsWorkflowsFolder, parseMaybeJson, readJsonArtifact, readStorText, writeDefsArtifact, writeMarkdownArtifact, } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution/helpers/nsIds.js';
import { runNsGate } from '/_102020_/l2/agentNewSolution/helpers/nsGate.js';
import { buildNsToolInstruction, createNsToolSchema, extractNsToolOutput, } from '/_102020_/l2/agentNewSolution/helpers/nsLlm.js';
import { nsAgentStepIntent, nsFindMutableParentStep, nsResultStepIntent, nsUpdateStatusIntent, } from '/_102020_/l2/agentNewSolution/helpers/nsSteps.js';
import { approveNsStep, createNsPipeline, markNsStepRunning, readNsPipeline, writeNsPipeline, } from '/_102020_/l2/agentNewSolution/helpers/nsPipeline.js';
import { writeNsTrace } from '/_102020_/l2/agentNewSolution/helpers/nsTrace.js';
import { readActors } from '/_102020_/l2/agentNewSolution/helpers/nsActors.js';
import { deriveE6WorkspaceKinds, prepareE6JourneyMap, renderE6Markdown, repairE6WorkflowIds, validateE6Invariants, } from '/_102020_/l2/agentNewSolution/steps/e6-journey-map/gate.js';
const AGENT_NAME = 'agentNsJourneyMap';
const STEP_ID = 'e6-journey-map';
const DONE_ANCHOR = 'e6-done';
const MAP_TOOL = 'submitNsJourneyMap';
const STEP_FOLDER = `${NS_AGENT_FOLDER}/steps/e6-journey-map`;
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: STEP_FOLDER,
        agentDescription: 'E6 - consolidated journey map (workspaces, landings, edges) for agentNewSolution',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const hookArgs = args || step.prompt || JSON.stringify({ planId: STEP_ID });
    const parsedArgs = parseE6Args(hookArgs);
    return [await buildMapPrompt(context, parentStep, hookSequential, parsedArgs, hookArgs)];
}
async function buildMapPrompt(context, parentStep, hookSequential, parsedArgs, hookArgs) {
    const inputs = await loadE6Inputs(parsedArgs.moduleName);
    const workflowSummaries = await summarizeWorkflowDefs(inputs.moduleName, inputs.classification);
    const operationSummaries = await summarizeOperationDefs(inputs.moduleName, inputs.classification);
    const schema = await readE6Schema();
    const prompt = await readNsText('steps/e6-journey-map', 'prompt', '.md', true);
    const journeysView = buildJourneysView(inputs.journeys);
    const humanPrompt = [
        '## E5 classification (frozen, primary source)',
        JSON.stringify(inputs.classification, null, 2),
        '',
        '## Saved workflow definitions (summaries)',
        JSON.stringify(workflowSummaries, null, 2),
        '',
        '## Saved operation definitions (summaries)',
        JSON.stringify(operationSummaries, null, 2),
        '',
        '## Actor roster (the only valid actor ids)',
        inputs.rosterActorIds.join(', '),
        '',
        '## Declared entity ids (the only valid entity values)',
        inputs.model.entities.map(entity => entity.entityId).join(', '),
        '',
        '## E2 journeys (navigation source: who starts where and who hands off to whom)',
        JSON.stringify(journeysView, null, 2),
        '',
        `## userLanguage: ${inputs.journeys.userLanguage}`,
        parsedArgs.retryContext ? `\n## Gate retry context (fix exactly these problems)\n${parsedArgs.retryContext}\n` : '',
    ].filter(Boolean).join('\n');
    return {
        type: 'prompt_ready',
        args: hookArgs,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: `${prompt.split('{{toolName}}').join(MAP_TOOL)}\n\n${buildNsToolInstruction(MAP_TOOL, 'the E5 classification artifact is missing or unusable')}`,
        humanPrompt,
        tools: [createNsToolSchema(MAP_TOOL, 'Submit the E6 consolidated journey map.', schema)],
        toolChoice: { type: 'function', function: { name: MAP_TOOL } },
    };
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    const mutationParent = nsFindMutableParentStep(context, parentStep);
    const parsedArgs = parseE6Args(step.prompt);
    try {
        return await handleMapResult(context, mutationParent, step, hookSequential, parsedArgs);
    }
    catch (error) {
        const traceMsg = error instanceof Error ? error.message : String(error);
        if (parsedArgs.moduleName) {
            await writeNsTrace(normalizeModuleFolderName(parsedArgs.moduleName), STEP_ID, AGENT_NAME, parsedArgs.retryAttempt || 1, { stepId: step.stepId }, traceMsg);
        }
        return [nsUpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', traceMsg)];
    }
}
async function handleMapResult(context, mutationParent, step, hookSequential, parsedArgs) {
    const inputs = await loadE6Inputs(parsedArgs.moduleName);
    const moduleName = inputs.moduleName;
    const output = extractNsToolOutput(step.interaction?.payload?.[0], MAP_TOOL);
    if (output.status === 'failed') {
        return [nsUpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', output.trace.join('\n') || 'E6 journey map returned failed')];
    }
    // Deterministic attaches: moduleName + note come from code, never from the LLM.
    // Workspace kind is derived from the classification facts FIRST (the LLM label is not
    // trusted — see deriveE6WorkspaceKinds), then workflowIds are inferred for workflow pages.
    const artifact = repairE6WorkflowIds(deriveE6WorkspaceKinds(prepareE6JourneyMap(output.result, { moduleName }), inputs.classification), inputs.classification);
    const gateContext = {
        moduleName,
        classificationWorkflowIds: inputs.classification.workflows.map(workflow => workflow.workflowId),
        classificationOperationIds: inputs.classification.operations.map(operation => operation.operationId),
        rosterActorIds: inputs.rosterActorIds,
        entityIds: inputs.model.entities.map(entity => entity.entityId),
        nowCapabilityActorIds: computeNowCapabilityActorIds(inputs.classification, inputs.journeys),
        operationFacts: await buildE6OperationFacts(moduleName, inputs.classification),
    };
    const gateInputs = {
        e2CreatedAt: inputs.journeys.createdAt,
        classificationWorkflowIds: gateContext.classificationWorkflowIds,
        classificationOperationIds: gateContext.classificationOperationIds,
        retryContext: parsedArgs.retryContext || '',
    };
    const schema = await readE6Schema();
    let pipeline = await readNsPipeline(moduleName) || createNsPipeline(moduleName);
    pipeline = markNsStepRunning(pipeline, STEP_ID, gateInputs);
    const gate = await runNsGate({
        stepId: STEP_ID,
        schema,
        artifact,
        inputs: gateInputs,
        pipeline,
        validate: item => validateE6Invariants(item, gateContext),
    });
    if (gate.pipeline)
        pipeline = gate.pipeline;
    const attempt = parsedArgs.retryAttempt || gate.attempts;
    if (!gate.ok) {
        await writeNsPipeline(pipeline);
        const traceMsg = gate.errors.map(issue => `${issue.code}: ${issue.message}`).join('\n');
        await writeNsTrace(moduleName, STEP_ID, AGENT_NAME, attempt, { artifact, gate, retryContext: gate.retryContext }, traceMsg);
        // Keep the pipeline alive on attempt 1: 'failed' would fail the whole task and orphan the retry
        // (downstream depends only on the 'e6-done' anchor, so completing this run unlocks nothing).
        if (attempt < 2) {
            return [
                nsAgentStepIntent(context, mutationParent, {
                    agentName: AGENT_NAME,
                    stepTitle: 'Retry E6 journey map gate',
                    planId: `e6-journey-map-retry-${Date.now()}`,
                    prompt: { planId: STEP_ID, moduleName, retryAttempt: 2, retryContext: gate.retryContext || traceMsg },
                }),
                nsUpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', `gate failed (attempt ${attempt}), retrying | ${traceMsg}`, 'input_output'),
            ];
        }
        return [nsUpdateStatusIntent(context, mutationParent, step, hookSequential, 'failed', traceMsg)];
    }
    pipeline = approveNsStep(pipeline, STEP_ID, 'auto');
    await writeNsPipeline(pipeline);
    await writeDefsArtifact({ project: mls.actualProject || 0, level: 4, folder: `${moduleName}/journeys`, shortName: `${moduleName}Journeys`, extension: '.defs.ts' }, `${moduleName}Journeys`, {
        moduleName: artifact.moduleName,
        note: artifact.note,
        workspaces: artifact.workspaces,
        landings: artifact.landings,
        navigationEdges: artifact.navigationEdges,
    });
    await writeMarkdownArtifact(nsPipelineArtifactFileInfo(moduleName, 'e6-journey-map', '.md'), renderE6Markdown(artifact, { generatedAt: new Date().toISOString() }));
    await writeNsTrace(moduleName, STEP_ID, AGENT_NAME, attempt, { artifact, gate });
    return [
        nsResultStepIntent(context, mutationParent, {
            planId: DONE_ANCHOR,
            dependsOn: [STEP_ID],
            stepTitle: 'Journey map ready',
            result: { type: DONE_ANCHOR, moduleName, workspaces: artifact.workspaces.map(workspace => workspace.workspaceId) },
        }),
        nsUpdateStatusIntent(context, mutationParent, step, hookSequential, 'completed', `e6-journey-map approved for ${moduleName} (${artifact.workspaces.length} workspaces)`, 'input_output'),
    ];
}
// ---------------------------------------------------------------------------
// inputs
// ---------------------------------------------------------------------------
async function loadE6Inputs(requestedModule) {
    const moduleName = await resolveE6Module(requestedModule);
    const journeys = await readJsonArtifact(nsPipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), true);
    if (!journeys)
        throw new Error(`[${AGENT_NAME}] e2-journeys.json not found for ${moduleName}`);
    const classification = await readJsonArtifact(nsPipelineArtifactFileInfo(moduleName, 'e5-classification', '.json'), true);
    if (!classification)
        throw new Error(`[${AGENT_NAME}] e5-classification.json not found for ${moduleName}`);
    const model = await readJsonArtifact(nsPipelineArtifactFileInfo(moduleName, 'e3-model', '.json'), true);
    if (!model)
        throw new Error(`[${AGENT_NAME}] e3-model.json not found for ${moduleName}`);
    const actorsRules = await readJsonArtifact(nsPipelineArtifactFileInfo(moduleName, 'e4-actors-rules', '.json'), true);
    if (!actorsRules)
        throw new Error(`[${AGENT_NAME}] e4-actors-rules.json not found for ${moduleName}`);
    return {
        moduleName,
        journeys,
        classification: {
            workflows: Array.isArray(classification.workflows) ? classification.workflows : [],
            operations: Array.isArray(classification.operations) ? classification.operations : [],
        },
        model,
        rosterActorIds: readRosterActorIds(actorsRules),
    };
}
async function resolveE6Module(requested) {
    if (requested)
        return normalizeModuleFolderName(requested);
    for (const moduleName of listExistingModuleFolders()) {
        const pipeline = await readNsPipeline(moduleName);
        if (!pipeline)
            continue;
        const e5 = pipeline.steps['e5-workflows-operations'];
        const e6 = pipeline.steps[STEP_ID];
        if (e5?.status === 'approved' && (!e6 || e6.status !== 'approved' || e6.dirty))
            return moduleName;
    }
    throw new Error(`[${AGENT_NAME}] no module with approved E5 waiting for E6`);
}
function readRosterActorIds(input) {
    const record = isRecord(input) ? input : {};
    const actors = Array.isArray(record.actors) ? record.actors.filter(isRecord) : [];
    return actors.map(actor => readString(actor.actorId)).filter((actorId) => !!actorId);
}
// Actors owning at least one behavior whose featureRefs include a 'now'-priority E2 feature.
function computeNowCapabilityActorIds(classification, journeys) {
    const nowFeatureIds = new Set(journeys.features.filter(feature => feature.priority === 'now').map(feature => feature.featureId));
    const actorIds = new Set();
    for (const workflow of classification.workflows) {
        if ((workflow.featureRefs || []).some(featureId => nowFeatureIds.has(featureId)))
            actorIds.add(workflow.actorId);
    }
    for (const operation of classification.operations) {
        if ((operation.featureRefs || []).some(featureId => nowFeatureIds.has(featureId)))
            actorIds.add(operation.actorId);
    }
    return [...actorIds];
}
// Slim journeys view for the prompt: actors, per-journey steps and feature priorities only.
function buildJourneysView(journeys) {
    return {
        actors: journeys.actors,
        journeys: journeys.journeys.map(journey => ({
            journeyId: journey.journeyId,
            actorId: journey.actorId,
            title: journey.title,
            goal: journey.goal,
            steps: journey.steps.map(item => ({ stepId: item.stepId, title: item.title, featureRefs: item.featureRefs })),
            outcome: journey.outcome,
        })),
        features: journeys.features.map(feature => ({
            featureId: feature.featureId,
            title: feature.title,
            priority: feature.priority,
            actorIds: feature.actorIds,
        })),
    };
}
// ---------------------------------------------------------------------------
// saved defs summaries
// ---------------------------------------------------------------------------
async function summarizeWorkflowDefs(moduleName, classification) {
    const summaries = [];
    for (const workflow of classification.workflows) {
        const defs = await readJsonDefs(nsWorkflowsFolder(moduleName), workflow.workflowId);
        summaries.push({
            id: workflow.workflowId,
            title: readString(defs?.title) || workflow.title,
            actor: workflow.actorId,
            entity: workflow.primaryEntity,
            kind: 'workflow',
            pageId: readString(defs?.pageId) || workflow.workflowId,
            storySteps: summarizeStory(defs?.story),
        });
    }
    return summaries;
}
async function summarizeOperationDefs(moduleName, classification) {
    const summaries = [];
    for (const operation of classification.operations) {
        const defs = await readJsonDefs(nsOperationsFolder(moduleName), operation.operationId);
        summaries.push({
            id: operation.operationId,
            title: readString(defs?.title) || operation.title,
            actor: operation.actorId,
            entity: operation.entity,
            kind: readString(defs?.kind) || operation.kind,
            pageId: readString(defs?.pageId) || operation.workflowId || operation.operationId,
            storySteps: summarizeStory(defs?.story),
        });
    }
    return summaries;
}
// Per-operation facts for the deterministic organism gates (detailPanel/batchAction). Read from the
// frozen operation defs so the gate stays pure — an operation whose def is absent simply has no fact
// entry, and the gate errors (organism.fact.missing) rather than silently skipping the check.
const PUBLIC_INPUT_SOURCES = new Set(['userInput', 'selectedEntity', 'routeParam']);
async function buildE6OperationFacts(moduleName, classification) {
    const facts = {};
    for (const operation of classification.operations) {
        const defs = await readJsonDefs(nsOperationsFolder(moduleName), operation.operationId);
        if (!defs)
            continue;
        const accessPattern = isRecord(defs.accessPattern) ? defs.accessPattern : {};
        const inputs = Array.isArray(defs.inputs) ? defs.inputs : [];
        facts[operation.operationId] = {
            accessPatternKind: readEnumValue(accessPattern.kind, ['list', 'getById', 'lookup', 'commandInput'], 'commandInput'),
            selection: readEnumValue(accessPattern.selection, ['none', 'single', 'multiple'], 'none'),
            opKind: readEnumValue(defs.kind, ['create', 'update', 'delete', 'query', 'view'], 'view'),
            hasPublicInput: inputs.some(input => isRecord(input) && typeof input.source === 'string' && PUBLIC_INPUT_SOURCES.has(input.source)),
            // D6 back-compat: new defs carry `actors`, legacy defs carry singular `actor`. Fall back to the
            // classification actorId when a def is missing the field entirely.
            actors: readActors(defs).length ? readActors(defs) : [operation.actorId].filter(Boolean),
        };
    }
    return facts;
}
function readEnumValue(value, allowed, fallback) {
    return typeof value === 'string' && allowed.includes(value) ? value : fallback;
}
// Defs files are `export const x = {...} as const;` — extract the JSON block
// (same convention as agentNsOntology.readJsonDefs).
async function readJsonDefs(folder, shortName) {
    const raw = await readStorText({ project: mls.actualProject || 0, level: 4, folder, shortName, extension: '.defs.ts' }, false);
    if (!raw.trim())
        return null;
    const start = raw.indexOf('= {');
    const end = raw.lastIndexOf('} as const;');
    if (start < 0 || end < 0)
        return null;
    const parsed = parseMaybeJson(raw.slice(start + 2, end + 1));
    return isRecord(parsed) ? parsed : null;
}
// Stories may be a string, an array of strings or an array of step records.
function summarizeStory(value) {
    const story = parseMaybeJson(value);
    if (typeof story === 'string')
        return story.trim() ? [truncateLine(story)] : [];
    if (isRecord(story))
        return summarizeStory(story.steps);
    if (!Array.isArray(story))
        return [];
    return story.slice(0, 8)
        .map(item => {
        if (typeof item === 'string')
            return truncateLine(item);
        if (isRecord(item)) {
            return truncateLine(readString(item.title) || readString(item.intent) || readString(item.description) || readString(item.text) || '');
        }
        return '';
    })
        .filter(Boolean);
}
function truncateLine(value) {
    const clean = value.replace(/\s+/g, ' ').trim();
    return clean.length > 160 ? `${clean.slice(0, 159).trim()}...` : clean;
}
// ---------------------------------------------------------------------------
// misc
// ---------------------------------------------------------------------------
async function readE6Schema() {
    const raw = await readNsText('schemas', 'e6-journey-map.schema', '.json', true);
    const parsed = parseMaybeJson(raw);
    if (!isRecord(parsed))
        throw new Error(`[${AGENT_NAME}] invalid schema e6-journey-map.schema`);
    return parsed;
}
async function readNsText(folder, shortName, extension, required = false) {
    return readStorText(nsL2File(`${NS_AGENT_FOLDER}/${folder}`, shortName, extension), required);
}
function parseE6Args(value) {
    const parsed = parseMaybeJson(value);
    if (!isRecord(parsed))
        return {};
    return {
        planId: readString(parsed.planId),
        moduleName: readString(parsed.moduleName),
        retryAttempt: typeof parsed.retryAttempt === 'number' ? parsed.retryAttempt : undefined,
        retryContext: readString(parsed.retryContext),
    };
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
