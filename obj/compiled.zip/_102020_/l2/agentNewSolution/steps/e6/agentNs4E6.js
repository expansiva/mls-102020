/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e6/agentNs4E6.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102020_/l2/agentNewSolution/helpers/ns4StepTree.js';
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { createNs4E6Step, isNs4Pipeline, markNs4E6Approved, markNs4E6Failed, markNs4E6Running, markNs4E6WaitingHuman, markNs4ModuleE6Approved, plainNs4StepTitle, } from '/_102020_/l2/agentNewSolution/helpers/ns4Core.js';
import { showNs4ClarificationError } from '/_102020_/l2/agentNewSolution/helpers/ns4Clarification.js';
import { readNs4ApprovedJourneys, readNs4ApprovedOntology, } from '/_102020_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts.js';
import { ns4E6DraftFile, ns4RulesFile, readNs4AgentText, readNs4DefsJson, readNs4Module, readNs4Pipeline, readNs4Text, writeNs4Composition, writeNs4E6Approved, writeNs4E6Draft, writeNs4Module, writeNs4Pipeline, } from '/_102020_/l2/agentNewSolution/helpers/ns4Fs.js';
import { buildNs4CompositionArtifact, normalizeNs4E6Review, } from '/_102020_/l2/agentNewSolution/steps/e6/contracts.js';
import { validateNs4E6Review } from '/_102020_/l2/agentNewSolution/steps/e6/gate.js';
const MAX_REPAIRS = 1;
const MAX_TRANSPORT_RETRIES = 1;
export async function beforeNs4E6PromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution:e6] task invalid');
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const pipeline = await requirePipeline(moduleName);
        if (pipeline.steps.e5?.status !== 'approved')
            throw new Error(`E5 approved pipeline not found for ${moduleName}.`);
        const [source, prompt, previous] = await Promise.all([
            readCompactSource(moduleName), readNs4AgentText('steps/e6', 'prompt'), readDraft(moduleName),
        ]);
        const round = parsed.reviewRound || pipeline.steps.e6?.reviewRound || 1;
        const humanPrompt = [
            `## Required identity\nmoduleName=${moduleName}; reviewRound=${round}; userLanguage=${source.userLanguage}`,
            `## Compact approved L4\n${JSON.stringify(source)}`,
            parsed.adjustment ? `## Human change request\n${parsed.adjustment}` : '',
            parsed.gateFeedback ? `## Deterministic repair required\n${parsed.gateFeedback}` : '',
            previous ? `## Current proposal; preserve unrelated items\n${JSON.stringify(previous)}` : '',
        ].filter(Boolean).join('\n\n');
        return [promptReady(context, parentStep, hookSequential, args || String(step.prompt || ''), prompt, humanPrompt)];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function afterNs4E6PromptStep(agent, context, parentStep, step, hookSequential, args) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const pipeline = await requirePipeline(moduleName);
        const round = parsed.reviewRound || pipeline.steps.e6?.reviewRound || 1;
        await writeNs4Pipeline(markNs4E6Running(pipeline, round));
        const mutationParent = findParent(context, parentStep, step);
        const payload = unwrap(step.interaction?.payload?.[0]);
        if (!isRecord(payload)) {
            const failure = readPromptFailure(step, 'E6 returned no usable composition proposal.');
            const attempt = parsed.transportRetryAttempt || 0;
            if (attempt < MAX_TRANSPORT_RETRIES)
                return [
                    addStep(context, mutationParent, createNs4E6Step(moduleName, round, '', [], pipeline.presentation.stepTitles['e6-behaviors'], '', 0, attempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `E6 transport retry ${attempt + 1} scheduled: ${failure}`, 'input_output'),
                ];
            throw new Error(failure);
        }
        const module = await readNs4Module(moduleName);
        if (!module)
            throw new Error(`Module artifact not found for ${moduleName}.`);
        const review = normalizeNs4E6Review(payload, moduleName);
        review.moduleName = moduleName;
        review.userLanguage = module.presentation.userLanguage;
        review.reviewRound = round;
        const gate = validateNs4E6Review(review, module);
        const draftPath = await writeNs4E6Draft(moduleName, review);
        if (!gate.ok) {
            const feedback = formatGate(gate.issues);
            const attempt = parsed.repairAttempt || 0;
            if (attempt < MAX_REPAIRS)
                return [
                    addStep(context, mutationParent, createNs4E6Step(moduleName, round, '', [], pipeline.presentation.stepTitles['e6-behaviors'], feedback, attempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', 'E6 composition gate scheduled one bounded repair.', 'input_output'),
                ];
            throw new Error(feedback);
        }
        await writeNs4Pipeline(markNs4E6WaitingHuman(await requirePipeline(moduleName), round, draftPath));
        if (isFast(context)) {
            const saved = await persist(moduleName, review, 'auto');
            return [resultStep(context, mutationParent, saved, 'E6 composition auto-approved'),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `E6 approved ${saved.recommendationCount} recommendations.`, 'input_output')];
        }
        return [clarificationStep(context, mutationParent, review, pipeline.presentation.stepTitles['e6-behaviors']),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', 'E6 composition ready for human approval.', 'input_output')];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function beforeNs4E6ClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const review = normalizeNs4E6Review(parse(json));
    const module = await readNs4Module(review.moduleName);
    if (!module)
        throw new Error(`Module artifact not found for ${review.moduleName}.`);
    const gate = validateNs4E6Review(review, module);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    await import('/_102020_/l2/agentNewSolution/widgets/widgetNs4Composition.js');
    const element = document.createElement('widget-ns4-composition-102020');
    element.value = review;
    element.addEventListener('ns4-composition-review', (event) => {
        const detail = event.detail;
        void applyReview(context, parentStep, step, hookSequential, detail)
            .catch(error => { showNs4ClarificationError(element, error); console.error(`[${agent.agentName}] ${errorMessage(error)}`); });
    });
    return element;
}
async function applyReview(context, parentStep, step, hookSequential, event) {
    if (!context.task)
        throw new Error('[agentNewSolution:e6] task invalid');
    if (event.action === 'cancel')
        throw new Error('Cancelamento terminal ainda depende de suporte explícito do collab-messages; esta revisão foi mantida aberta sem alterar o pipeline.');
    const mutationParent = findParent(context, parentStep);
    if (event.action === 'approve') {
        const saved = await persist(event.review.moduleName, normalizeNs4E6Review(event.review), 'human');
        await applyIntents(context, [resultStep(context, mutationParent, saved, 'E6 composition approved'),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output')]);
    }
    else {
        const adjustment = event.adjustment.trim();
        if (!adjustment)
            throw new Error('Descreva a alteração desejada antes de enviar.');
        const review = normalizeNs4E6Review(event.review);
        const nextRound = review.reviewRound + 1;
        const pipeline = await requirePipeline(review.moduleName);
        await writeNs4E6Draft(review.moduleName, review);
        await writeNs4Pipeline(markNs4E6Running(pipeline, nextRound));
        await applyIntents(context, [
            addStep(context, mutationParent, createNs4E6Step(review.moduleName, nextRound, adjustment, [], pipeline.presentation.stepTitles['e6-behaviors'])),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', undefined, 'input_output'),
        ]);
    }
    await continuePoolingTask(context);
}
async function persist(moduleName, review, approvedBy) {
    const module = await readNs4Module(moduleName);
    if (!module)
        throw new Error(`Module artifact not found for ${moduleName}.`);
    const gate = validateNs4E6Review(review, module);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    const approvedAt = new Date().toISOString();
    const artifact = await buildNs4CompositionArtifact(review, approvedBy, approvedAt);
    const artifactPath = await writeNs4Composition(moduleName, artifact);
    const approvedPath = await writeNs4E6Approved(moduleName, review);
    const pipeline = await requirePipeline(moduleName);
    await writeNs4Module(moduleName, markNs4ModuleE6Approved(module, approvedBy, approvedAt));
    await writeNs4Pipeline(markNs4E6Approved(pipeline, approvedBy, [artifactPath, approvedPath], approvedAt));
    return { moduleName, recommendationCount: artifact.recommendations.length, artifactPath, approvedPath };
}
async function readCompactSource(moduleName) {
    const [module, journeys, ontology, rules] = await Promise.all([
        readNs4Module(moduleName), readNs4ApprovedJourneys(moduleName), readNs4ApprovedOntology(moduleName),
        readNs4DefsJson(ns4RulesFile(moduleName), true),
    ]);
    if (!module || !rules)
        throw new Error(`Approved E1 or E5 artifact not found for ${moduleName}.`);
    return {
        userLanguage: module.presentation.userLanguage,
        module: {
            purpose: module.module.purpose, businessScope: module.businessScope,
            declaredConstraints: module.declaredConstraints,
        },
        journeys: journeys.journeys.map(journey => ({
            journeyId: journey.journeyId, actorRef: journey.business.actorRef, goal: journey.business.goal,
            steps: journey.business.steps.map(step => ({ entity: step.entity, title: step.title, description: step.description })),
            outcome: journey.business.outcome.statement,
        })),
        ontology: ontology.entities.map(entity => ({
            entityId: entity.entityId, kind: entity.kind, description: entity.description,
            storageTarget: entity.storage.target,
        })),
        rules: rules.rules,
    };
}
async function readDraft(moduleName) {
    const raw = await readNs4Text(ns4E6DraftFile(moduleName), false);
    const parsed = parse(raw);
    return isRecord(parsed) ? normalizeNs4E6Review(parsed, moduleName) : null;
}
async function requirePipeline(moduleName) {
    const state = await readNs4Pipeline(moduleName);
    if (!isNs4Pipeline(state))
        throw new Error(`agentNewSolution pipeline not found for ${moduleName}.`);
    return state;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const state = await readNs4Pipeline(moduleName);
        if (isNs4Pipeline(state))
            await writeNs4Pipeline(markNs4E6Failed(state, error));
    }
    catch { /* task trace fallback */ }
}
function resolveArgs(context, value) {
    const root = parse(value);
    if (!isRecord(root) || root.planId !== 'e6-behaviors')
        throw new Error('Invalid E6 step arguments.');
    const moduleName = text(root.moduleName) || findE5Module(context) || memoryString(context, 'resumeModule');
    if (!moduleName)
        throw new Error('E5 module result not found for E6.');
    return { planId: 'e6-behaviors', moduleName,
        ...(number(root.reviewRound) ? { reviewRound: number(root.reviewRound) } : {}),
        ...(text(root.adjustment) ? { adjustment: text(root.adjustment) } : {}),
        ...(text(root.gateFeedback) ? { gateFeedback: text(root.gateFeedback) } : {}),
        ...(number(root.repairAttempt) ? { repairAttempt: number(root.repairAttempt) } : {}),
        ...(number(root.transportRetryAttempt) ? { transportRetryAttempt: number(root.transportRetryAttempt) } : {}) };
}
function findE5Module(context) {
    const result = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e5-result');
    const parsed = result?.type === 'result' ? parse(result.result) : null;
    return isRecord(parsed) ? text(parsed.moduleName) : '';
}
function findParent(context, parentStep, phaseStep) {
    return resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parentStep, phaseStep);
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt) {
    return { type: 'prompt_ready', args, messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', hookSequential, parentStepId: parentStep.stepId, systemPrompt, humanPrompt };
}
function addStep(context, parentStep, step) {
    return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId, step };
}
function resultStep(context, parentStep, saved, title) {
    return addStep(context, parentStep, { type: 'result', stepId: 0, interaction: null, stepTitle: title, status: 'completed', nextSteps: [],
        result: JSON.stringify({ ...saved, completedStep: 'e6-behaviors', nextStep: 'e7-realization' }, null, 2),
        planning: { planId: 'e6-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' } });
}
function clarificationStep(context, parentStep, review, title) {
    return addStep(context, parentStep, { type: 'clarification', stepId: 0, interaction: null, stepTitle: plainNs4StepTitle(title), status: 'pending', nextSteps: [], json: JSON.stringify(review),
        planning: { planId: `e6-composition-review-round-${review.reviewRound}`, dependsOn: [], executionMode: 'sequential', executionHost: 'client' } });
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return { type: 'update-status', hookSequential, messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId, stepId: step.stepId, status,
        ...(traceMsg ? { traceMsg } : {}), ...(cleaner ? { cleaner } : {}) };
}
async function applyIntents(context, intents) {
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200)
        throw new Error(response?.msg || 'Error applying E6 intents.');
    const applied = response;
    context.task = applied.task;
    if (applied.message)
        context.message = applied.message;
}
function unwrap(value) { const root = parse(value); return isRecord(root) && root.type === 'flexible' ? parse(root.result) : root; }
function parse(value) { if (typeof value !== 'string')
    return value; const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''); try {
    return JSON.parse(clean);
}
catch {
    return value;
} }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function readPromptFailure(step, fallback) { const trace = Array.isArray(step.interaction?.trace) ? step.interaction.trace.map(String) : []; const failure = [...trace].reverse().find(line => /429 Too Many Requests|Error invoking Collab LLM proxy|AI request failed/i.test(line)); return failure ? `${fallback} ${failure}` : fallback; }
function formatGate(issues) { return issues.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n'); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function number(value) { return typeof value === 'number' && Number.isInteger(value) && value >= 0 ? value : 0; }
function memoryString(context, key) { const value = context.task?.iaCompressed?.longMemory?.[key]; return typeof value === 'string' ? value.trim() : ''; }
function isFast(context) { return memoryString(context, 'fastMode') === 'true'; }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
