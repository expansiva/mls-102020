/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e3/hookArgs.ts" enhancement="_blank"/>
export function resolveNs4E3HookArgs(args, prompt) {
    if (typeof args === 'string')
        return args;
    if (typeof prompt === 'string')
        return prompt;
    return '';
}
