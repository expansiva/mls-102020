/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e4/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102020_/l2/agentNewSolution/steps/e2/contracts.js';
import { resolveNs4Findings, } from '/_102020_/l2/agentNewSolution/helpers/ns4Resolve.js';
export const NS4_ONTOLOGY_SCHEMA_VERSION = '2026-08-11-ns4-ontology-v6';
export function normalizeNs4E4Review(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const entities = array(root.entities).map(item => normalizeEntity(item, moduleName));
    const incoming = normalizeSystemDecisions(root.systemDecisions);
    const review = {
        planId: 'e4-ontology-review',
        moduleName,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business ontology',
        reviewRound: positiveInteger(root.reviewRound, 1),
        solutionMode: 'new',
        businessDomain: text(root.businessDomain),
        entities,
        relationships: array(root.relationships).map(item => {
            const relationship = record(item);
            const fromEntity = text(relationship.fromEntity) || text(relationship.sourceEntity) || text(relationship.from);
            const toEntity = text(relationship.toEntity) || text(relationship.targetEntity) || text(relationship.to);
            const realization = normalizeRelationshipRealization(relationship.realization, fromEntity, toEntity);
            return {
                relationshipId: text(relationship.relationshipId),
                fromEntity,
                toEntity,
                type: relationshipType(relationship.type),
                required: relationship.required === true,
                description: text(relationship.description),
                persistence: { mode: relationshipPersistenceMode(entities, fromEntity, toEntity) },
                ...(realization ? { realization } : {}),
            };
        }),
        changeSummary: strings(root.changeSummary),
        systemDecisions: incoming,
    };
    return applyClosedDomainLabelBackfill(review);
}
/** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
export function humanizeNs4EnumCode(code) {
    const words = String(code || '').replace(/[_-]+/g, ' ').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim().split(/\s+/u);
    if (!words[0])
        return code;
    const first = words[0].charAt(0).toUpperCase() + words[0].slice(1).toLowerCase();
    return [first, ...words.slice(1).map(word => word.toLowerCase())].join(' ');
}
function applyClosedDomainLabelBackfill(review) {
    const findings = closedDomainLabelFindings(review);
    if (!findings.length)
        return review;
    const resolution = resolveNs4Findings(review, findings);
    const byId = new Map((review.systemDecisions || []).map(decision => [decision.decisionId, decision]));
    resolution.systemDecisions.forEach(decision => byId.set(decision.decisionId, decision));
    return { ...resolution.artifact, systemDecisions: [...byId.values()] };
}
function closedDomainLabelFindings(review) {
    const findings = [];
    review.entities.forEach(entity => {
        // Plan drafts have no fields yet — do not poison the entity workers with humanized English.
        if (!entity.fields.length)
            return;
        if (entity.lifecycleStates.length) {
            const { missing } = completeEnumLabels(entity.lifecycleStates, entity.lifecycleLabels);
            if (missing.length)
                findings.push(lifecycleLabelFinding(entity.entityId, entity.lifecycleStates));
        }
        entity.fields.forEach(field => {
            const codes = field.enum || [];
            if (!codes.length || isLifecycleStatusField(field, entity))
                return;
            const { missing } = completeEnumLabels(codes, field.enumLabels);
            if (missing.length)
                findings.push(fieldEnumLabelFinding(entity.entityId, field.fieldId, codes));
        });
    });
    return findings;
}
function lifecycleLabelFinding(entityId, codes) {
    return {
        classification: 'C',
        findingRef: `e4.lifecycleLabels.backfill:${entityId}`,
        stage: 'e4',
        question: `Entity ${entityId} is missing lifecycleLabels for one or more states.`,
        deterministicChoice: 'humanizeMissingCodes',
        alternatives: ['authorUserLanguageLabels'],
        changeHint: 'Emit lifecycleLabels in the user language next to lifecycleStates. This run filled the gap with a humanized code so the UI is never raw camelCase.',
        apply: artifact => ({
            ...artifact,
            entities: artifact.entities.map(entity => {
                if (entity.entityId !== entityId)
                    return entity;
                const { labels } = completeEnumLabels(codes, entity.lifecycleLabels);
                return { ...entity, lifecycleLabels: labels };
            }),
        }),
    };
}
function fieldEnumLabelFinding(entityId, fieldId, codes) {
    return {
        classification: 'C',
        findingRef: `e4.enumLabels.backfill:${entityId}.${fieldId}`,
        stage: 'e4',
        question: `Entity ${entityId} field ${fieldId} is missing enumLabels for one or more codes.`,
        deterministicChoice: 'humanizeMissingCodes',
        alternatives: ['authorUserLanguageLabels'],
        changeHint: 'Emit enumLabels in the user language next to the enum constraint. Status uses lifecycleLabels — do not duplicate it on the status field.',
        apply: artifact => ({
            ...artifact,
            entities: artifact.entities.map(entity => {
                if (entity.entityId !== entityId)
                    return entity;
                return {
                    ...entity,
                    fields: entity.fields.map(field => {
                        if (field.fieldId !== fieldId)
                            return field;
                        const { labels } = completeEnumLabels(codes, field.enumLabels);
                        return { ...field, enumLabels: labels };
                    }),
                };
            }),
        }),
    };
}
function completeEnumLabels(codes, existing) {
    const byCode = new Map();
    const extras = [];
    const codeSet = new Set(codes);
    (existing || []).forEach(entry => {
        if (!entry.code)
            return;
        if (!codeSet.has(entry.code))
            extras.push(entry);
        else if (entry.label)
            byCode.set(entry.code, entry.label);
    });
    const missing = [];
    const labels = codes.map(code => {
        const have = byCode.get(code);
        if (have)
            return { code, label: have };
        missing.push(code);
        return { code, label: humanizeNs4EnumCode(code) };
    });
    return { labels: extras.length ? [...labels, ...extras] : labels, missing };
}
function isLifecycleStatusField(field, entity) {
    return isStatusFieldId(field.fieldId) && entity.lifecycleStates.length > 0;
}
function normalizeSystemDecisions(value) {
    return array(value).map(item => {
        const decision = record(item);
        return {
            decisionId: text(decision.decisionId), stage: text(decision.stage), question: text(decision.question),
            chosen: text(decision.chosen), alternatives: strings(decision.alternatives), decidedBy: 'system',
            findingRef: text(decision.findingRef), changeHint: text(decision.changeHint),
        };
    }).filter(decision => decision.decisionId && decision.stage && decision.question && decision.chosen && decision.findingRef);
}
export function normalizeNs4E4PlanDraft(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const full = normalizeNs4E4Review({
        ...root,
        moduleName,
        entities: array(root.entities).map(item => ({ ...record(item), fields: [], useRules: [] })),
    }, moduleName);
    return {
        planId: 'e4-ontology-plan',
        moduleName,
        userLanguage: full.userLanguage,
        title: full.title,
        reviewRound: full.reviewRound,
        solutionMode: 'new',
        businessDomain: full.businessDomain,
        entities: full.entities.map(({ fields, useRules, ...entity }) => entity),
        relationships: full.relationships,
        changeSummary: full.changeSummary,
    };
}
export function normalizeNs4E4EntityDraft(value, moduleName, reviewRound, entityId) {
    const root = record(value);
    const normalized = normalizeEntity({
        entityId,
        fields: root.fields,
        useRules: root.useRules,
    }, moduleName);
    return {
        planId: 'e4-ontology-entity',
        moduleName,
        reviewRound,
        entityId,
        // The worker tool schema is strict and owns no union key: the entity draft is the worker's own
        // contract, so the derived union is stripped back out here and lives only in the review artifact.
        fields: stripNs4DerivedFieldUnions(normalized.fields),
        useRules: normalized.useRules,
    };
}
export function stripNs4DerivedFieldUnions(value) {
    if (Array.isArray(value)) {
        return value.map(item => {
            const { enum: _union, ...field } = record(item);
            return field;
        });
    }
    const source = record(value);
    if (!Array.isArray(source.fields))
        return value;
    const { statusEnum: _states, ...entity } = source;
    return { ...entity, fields: stripNs4DerivedFieldUnions(source.fields) };
}
export function assembleNs4E4Review(plan, details) {
    const byEntity = new Map(details.map(detail => [detail.entityId, detail]));
    return normalizeNs4E4Review({
        ...plan,
        planId: 'e4-ontology-review',
        entities: plan.entities.map(entity => ({
            ...entity,
            fields: byEntity.get(entity.entityId)?.fields || [],
            useRules: byEntity.get(entity.entityId)?.useRules || [],
        })),
    }, plan.moduleName);
}
export function normalizeNs4E4RelationshipBindings(value, moduleName, reviewRound) {
    const root = record(value);
    return {
        planId: 'e4-relationship-bindings',
        moduleName: text(root.moduleName) || moduleName,
        reviewRound: positiveInteger(root.reviewRound, reviewRound),
        bindings: array(root.bindings).map(item => {
            const binding = record(item);
            return {
                relationshipId: text(binding.relationshipId),
                realization: normalizeRelationshipRealization(binding.realization, '', '') || {
                    kind: 'derived', ownerEntity: '',
                    from: { entityId: '', fieldIds: [] }, to: { entityId: '', fieldIds: [] }, description: '',
                },
            };
        }),
    };
}
export function applyNs4E4RelationshipBindings(review, draft) {
    const bindings = new Map(draft.bindings.map(binding => [binding.relationshipId, binding.realization]));
    return normalizeNs4E4Review({
        ...review,
        relationships: review.relationships.map(relationship => ({
            ...relationship,
            ...(bindings.has(relationship.relationshipId) ? { realization: bindings.get(relationship.relationshipId) } : {}),
        })),
    }, review.moduleName);
}
export async function buildNs4OntologyArtifacts(review, approvedBy, approvedAt) {
    const relationships = requireResolvedRelationships(review.relationships);
    const ontologyHash = await sha256Ns4({
        solutionMode: review.solutionMode,
        businessDomain: review.businessDomain,
        entities: review.entities,
        relationships,
    });
    const entities = review.entities.map(entity => ({
        schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        solutionMode: review.solutionMode,
        ...entity,
        ontologyHash,
        approvedBy,
        approvedAt,
    }));
    return {
        entities,
        index: {
            schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
            moduleName: review.moduleName,
            userLanguage: review.userLanguage,
            solutionMode: review.solutionMode,
            title: review.title,
            businessDomain: review.businessDomain,
            entities: review.entities.map(entity => ({
                entityId: entity.entityId,
                title: entity.title,
                kind: entity.kind,
                storage: {
                    target: entity.storage.target,
                    scope: entity.storage.scope,
                    ...(entity.storage.idField ? { idField: entity.storage.idField } : {}),
                    ...(entity.storage.mdmType ? { mdmType: entity.storage.mdmType } : {}),
                },
                definitionRef: `l4/${review.moduleName}/ontology/${entity.entityId}.defs.ts`,
            })),
            relationships,
            ontologyHash,
            approvedBy,
            approvedAt,
            realization: { status: 'pending', compiledFromOntologyHash: ontologyHash },
            ...(review.systemDecisions?.length ? { systemDecisions: review.systemDecisions } : {}),
        },
    };
}
function requireResolvedRelationships(relationships) {
    return relationships.map(relationship => {
        if (!relationship.realization) {
            throw new Error(`Relationship ${relationship.relationshipId || '<unknown>'} has no field realization.`);
        }
        return { ...relationship, realization: relationship.realization };
    });
}
/** A status field is the one the lifecycle names; the suffix is the only stable structural marker. */
function isStatusFieldId(fieldId) {
    return /(^|[a-z0-9])status$/i.test(fieldId);
}
/**
 * Reads the literal values out of an enum constraint. The constraint value is authored as free text,
 * so the three shapes the generators actually produce are all accepted: a JSON array, a
 * comma-separated list and a pipe-separated list. Anything else yields no values, and the field
 * simply stays without a union.
 */
function enumValues(constraints) {
    const raw = constraints.find(constraint => constraint.kind === 'enum')?.value || '';
    if (!raw)
        return [];
    const trimmed = raw.trim();
    if (trimmed.startsWith('[')) {
        try {
            const parsed = JSON.parse(trimmed);
            if (Array.isArray(parsed))
                return unique(parsed.map(item => text(item)));
        }
        catch { /* not JSON: fall through to the separated forms */ }
    }
    const separator = trimmed.includes('|') ? '|' : ',';
    return unique(trimmed.replace(/^[[(]|[\])]$/g, '').split(separator).map(item => text(item).replace(/^['"]|['"]$/g, '')));
}
function unique(values) {
    return [...new Set(values.filter(Boolean))];
}
function enumLabels(value) {
    return array(value).map(item => {
        const entry = record(item);
        return { code: text(entry.code), label: text(entry.label) };
    }).filter(entry => entry.code || entry.label);
}
function party(value) {
    return value === 'person' || value === 'organization' || value === 'none' ? value : undefined;
}
function normalizeEntity(value, moduleName) {
    const entity = record(value);
    const sourceRefs = record(entity.sourceRefs);
    const storage = record(entity.storage);
    const entityId = text(entity.entityId);
    const kind = entityKind(entity.kind);
    const entityOwnership = ownership(entity.ownership);
    const lifecycleStates = strings(entity.lifecycleStates);
    const fields = array(entity.fields).map(item => {
        const field = record(item);
        const fieldId = text(field.fieldId);
        const constraints = array(field.constraints).map(constraintValue => {
            const constraint = record(constraintValue);
            return {
                constraintId: text(constraint.constraintId),
                kind: constraintKind(constraint.kind),
                value: text(constraint.value),
                description: text(constraint.description),
                source: constraintSource(constraint.source),
            };
        });
        const declared = enumValues(constraints);
        const values = declared.length ? declared : (isStatusFieldId(fieldId) ? lifecycleStates : []);
        return {
            fieldId,
            title: text(field.title),
            type: fieldType(field.type),
            required: field.required === true,
            description: text(field.description),
            constraints,
            ...(values.length ? { enum: values } : {}),
            ...(enumLabels(field.enumLabels).length ? { enumLabels: enumLabels(field.enumLabels) } : {}),
        };
    });
    const target = storageTarget(storage.target, kind, entityOwnership);
    const idField = text(storage.idField)
        || fields.find(field => field.required && /Id$/.test(field.fieldId))?.fieldId
        || '';
    return {
        entityId,
        title: text(entity.title),
        description: text(entity.description),
        kind,
        ownership: entityOwnership,
        // ABSENT when the model did not declare it (or declared something outside the vocabulary), never
        // defaulted to 'none': defaulting would answer the party question on the model's behalf and the gate
        // would have nothing to complain about — which is the exact silence that let a person become a table.
        ...(party(entity.party) ? { party: party(entity.party) } : {}),
        ...(entity.cardinality === 'singleton' ? { cardinality: 'singleton' } : {}),
        sourceRefs: {
            journeyIds: strings(sourceRefs.journeyIds),
            featureIds: strings(sourceRefs.featureIds),
            authorityRefs: strings(sourceRefs.authorityRefs),
        },
        fields,
        lifecycleStates,
        ...(lifecycleStates.length ? { statusEnum: lifecycleStates } : {}),
        ...(enumLabels(entity.lifecycleLabels).length ? { lifecycleLabels: enumLabels(entity.lifecycleLabels) } : {}),
        ...(text(entity.initialState) ? { initialState: text(entity.initialState) } : {}),
        ...(strings(entity.terminalStates).length ? { terminalStates: strings(entity.terminalStates) } : {}),
        lifecyclePredicates: array(entity.lifecyclePredicates).map(item => {
            const predicate = record(item);
            return {
                predicateId: text(predicate.predicateId),
                description: text(predicate.description),
                stateIds: strings(predicate.stateIds),
                source: constraintSource(predicate.source),
            };
        }),
        useRules: strings(entity.useRules),
        storage: {
            target,
            scope: storageScope(storage.scope, target),
            ...(idField && (target === 'mdm' || target === 'moduleDatabase') ? { idField } : {}),
            ...(target === 'mdm' ? { mdmType: text(storage.mdmType) || `${moduleName}.${entityId}` } : {}),
            notes: text(storage.notes),
        },
    };
}
function storageTarget(value, kind, entityOwnership) {
    if (value === 'mdm' || value === 'moduleDatabase' || value === 'derived'
        || value === 'external' || value === 'embedded')
        return value;
    if (entityOwnership === 'external')
        return 'external';
    if (kind === 'mdm')
        return 'mdm';
    if (kind === 'projection')
        return 'derived';
    if (kind === 'valueObject')
        return 'embedded';
    return 'moduleDatabase';
}
function storageScope(value, target) {
    if (value === 'organization' || value === 'module' || value === 'platform' || value === 'none')
        return value;
    if (target === 'mdm')
        return 'organization';
    if (target === 'moduleDatabase')
        return 'module';
    if (target === 'external')
        return 'platform';
    return 'none';
}
function entityKind(value) {
    if (value === 'event' || value === 'supporting' || value === 'mdm' || value === 'projection' || value === 'valueObject')
        return value;
    return 'core';
}
function ownership(value) {
    if (value === 'external' || value === 'derived')
        return value;
    return 'moduleOwned';
}
function fieldType(value) {
    if (value === 'uuid' || value === 'text' || value === 'number' || value === 'integer' || value === 'boolean'
        || value === 'money' || value === 'date' || value === 'datetime' || value === 'json')
        return value;
    return 'string';
}
function constraintKind(value) {
    if (value === 'min' || value === 'max' || value === 'minLength' || value === 'maxLength'
        || value === 'pattern' || value === 'enum' || value === 'format' || value === 'unique')
        return value;
    return 'custom';
}
function constraintSource(value) {
    if (value === 'database' || value === 'journey' || value === 'user' || value === 'legacyCode')
        return value;
    return 'inferred';
}
function relationshipType(value) {
    if (value === 'oneToOne' || value === 'manyToOne' || value === 'manyToMany')
        return value;
    return 'oneToMany';
}
function relationshipPersistenceMode(entities, fromEntity, toEntity) {
    const from = entities.find(entity => entity.entityId === fromEntity)?.storage.target;
    const to = entities.find(entity => entity.entityId === toEntity)?.storage.target;
    if (from === 'embedded' || to === 'embedded')
        return 'embedded';
    if (from === 'external' || to === 'external')
        return 'externalReference';
    if (from === 'derived' || to === 'derived')
        return 'derivedJoin';
    if (from === 'mdm' && to === 'mdm')
        return 'mdmRelationship';
    if ((from === 'mdm' && to === 'moduleDatabase') || (from === 'moduleDatabase' && to === 'mdm')) {
        return 'crossStoreReference';
    }
    return 'moduleReference';
}
function normalizeRelationshipRealization(value, fallbackFromEntity, fallbackToEntity) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return undefined;
    const realization = record(value);
    const from = record(realization.from);
    const to = record(realization.to);
    return {
        kind: relationshipRealizationKind(realization.kind),
        ownerEntity: text(realization.ownerEntity),
        from: { entityId: text(from.entityId) || fallbackFromEntity, fieldIds: strings(from.fieldIds) },
        to: { entityId: text(to.entityId) || fallbackToEntity, fieldIds: strings(to.fieldIds) },
        description: text(realization.description),
    };
}
function relationshipRealizationKind(value) {
    if (value === 'fieldCollection' || value === 'mdmRelationship' || value === 'derived'
        || value === 'externalReference' || value === 'embedded')
        return value;
    return 'fieldReference';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
