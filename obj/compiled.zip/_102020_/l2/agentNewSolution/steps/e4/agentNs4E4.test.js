import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createNs4E4FinalizeStep, createNs4E4RelationshipBindingStep, createNs4E4RepairStep, createNs4Pipeline, NS4_E4_MAX_PARALLEL, markNs4E1Approved, markNs4E2Approved, markNs4E2Running, markNs4E2WaitingHuman, markNs4E3Approved, markNs4E3Running, markNs4E4Approved, markNs4E4Failed, markNs4E4Running, markNs4E4WaitingHuman, resolveNs4ExistingAction, } from '/_102020_/l2/agentNewSolution/helpers/ns4Core.js';
import { normalizeNs4BusinessObjectId, normalizeNs4E2Review, } from '/_102020_/l2/agentNewSolution/steps/e2/contracts.js';
import { normalizeNs4E3Review } from '/_102020_/l2/agentNewSolution/steps/e3/contracts.js';
import { assembleNs4E4Review, applyNs4E4RelationshipBindings, buildNs4OntologyArtifacts, normalizeNs4E4EntityDraft, stripNs4DerivedFieldUnions, normalizeNs4E4PlanDraft, normalizeNs4E4RelationshipBindings, normalizeNs4E4Review, } from '/_102020_/l2/agentNewSolution/steps/e4/contracts.js';
import { validateNs4E4EntityDraft, validateNs4E4Plan, validateNs4E4RelationshipBindings, validateNs4E4Review, } from '/_102020_/l2/agentNewSolution/steps/e4/gate.js';
import { resolveNs4E4HookArgs, resolveNs4E4InvocationArgs } from '/_102020_/l2/agentNewSolution/steps/e4/hookArgs.js';
const journeys = normalizeNs4E2Review({
    moduleName: 'buildFlowFsm', userLanguage: 'en', reviewRound: 1,
    journeys: [{
            journeyId: 'manageProjects', business: {
                actorRef: 'projectManager', title: 'Manage projects', goal: 'Manage a selected project.', entry: { mode: 'coldStart' }, useRules: [],
                steps: [{
                        stepId: 'selectProject', kind: 'locate', entity: 'Project', title: 'Select a project.', description: 'Project selected.', featureRefs: ['projectManagement'],
                    }], outcome: { statement: 'Project available.', evidence: ['Project selected.'] },
            },
        }],
    features: [{ featureId: 'projectManagement', title: 'Projects', priority: 'now', journeyStepRefs: ['manageProjects.selectProject'] }],
});
const access = normalizeNs4E3Review({
    moduleName: 'buildFlowFsm', userLanguage: 'en', reviewRound: 1,
    profiles: [{ profileId: 'projectManager', title: 'Project manager', kind: 'internal', description: 'Manager.', actorRefs: ['projectManager'], landingIntent: 'Select projects.' }],
    authorities: [
        { authorityRef: 'buildflow:projectread', title: 'Read projects', description: 'Read projects.', journeyStepRefs: ['manageProjects.selectProject'], informationNeeds: [] },
        { authorityRef: 'buildflow:clientprojectview', title: 'Client project summary', description: 'Published summary.', journeyStepRefs: [], informationNeeds: ['Published client project summary'] },
    ],
    grants: [{
            profileRef: 'projectManager', authorityRef: 'buildflow:projectread', reason: 'Manage projects.',
            dataScope: { mode: 'assigned', description: 'Assigned projects.' },
            disclosure: { mode: 'fullRecord', description: 'Full project record.', allowedInformation: [], deniedInformation: [] }, useRules: [],
        }],
});
const reviewInput = {
    planId: 'e4-ontology-review', moduleName: 'buildFlowFsm', userLanguage: 'en', title: 'Business ontology',
    reviewRound: 1, solutionMode: 'new', businessDomain: 'Construction operations',
    entities: [
        {
            entityId: 'Project', title: 'Project', description: 'A construction engagement.', kind: 'core', ownership: 'moduleOwned', party: 'none',
            sourceRefs: { journeyIds: ['manageProjects'], featureIds: ['projectManagement'], authorityRefs: ['buildflow:projectread'] },
            fields: [
                { fieldId: 'projectId', title: 'Project id', type: 'uuid', required: true, description: 'Stable id.', constraints: [{ constraintId: 'uniqueProjectId', kind: 'unique', value: 'true', description: 'Unique id.', source: 'inferred' }] },
                { fieldId: 'name', title: 'Name', type: 'string', required: true, description: 'Project name.', constraints: [] },
            ], lifecycleStates: [], useRules: [], storage: {
                target: 'moduleDatabase', scope: 'module', idField: 'projectId', notes: 'Transactional module persistence.',
            },
        },
        {
            entityId: 'ClientProjectSummary', title: 'Client project summary', description: 'Published related-project projection.', kind: 'projection', ownership: 'derived', party: 'none',
            sourceRefs: { journeyIds: [], featureIds: [], authorityRefs: ['buildflow:clientprojectview'] },
            fields: [{ fieldId: 'projectId', title: 'Project id', type: 'uuid', required: true, description: 'Related project.', constraints: [] }],
            lifecycleStates: [], useRules: [], storage: { target: 'derived', scope: 'none', notes: 'Derived from published project data.' },
        },
    ],
    relationships: [{
            relationshipId: 'summaryDescribesProject', fromEntity: 'ClientProjectSummary', toEntity: 'Project',
            type: 'manyToOne', required: true, description: 'Summary belongs to its related project.',
            realization: {
                kind: 'derived', ownerEntity: 'ClientProjectSummary',
                from: { entityId: 'ClientProjectSummary', fieldIds: ['projectId'] },
                to: { entityId: 'Project', fieldIds: ['projectId'] },
                description: 'The published projection is derived by matching its projectId to Project.projectId.',
            },
        }],
    changeSummary: ['Initial proposal.'],
};
test('E4 preserves hook args byte-for-byte', () => {
    const original = '{"planId":"e4-ontology","reviewRound":2,"solutionMode":"new"}';
    assert.equal(resolveNs4E4HookArgs(undefined, original), original);
    assert.equal(resolveNs4E4HookArgs(original, '{}'), original);
});
test('E4 reconstructs base invocation when a parallel child has only entity hook args', () => {
    const hookArgs = resolveNs4E4HookArgs('entity:Client', undefined);
    assert.equal(hookArgs, 'entity:Client');
    assert.deepEqual(JSON.parse(resolveNs4E4InvocationArgs(hookArgs, 'Client')), {
        planId: 'e4-ontology', solutionMode: 'new',
    });
});
test('E4 bounded repair step carries gate feedback under a unique open plan id', () => {
    const step = createNs4E4RepairStep('buildFlowFsm', 2, 1, 'OperationsPortfolio is disconnected');
    assert.equal(step.planning?.planId, 'e4-ontology-round-2-repair-1');
    assert.equal(step.status, 'waiting_human_input');
    assert.doesNotMatch(String(step.stepTitle), /^👤/u);
    assert.match(String(step.prompt), /OperationsPortfolio is disconnected/);
});
test('E4 uses the proven 20-slot ontology fan-out and a dependency-bound finalizer', () => {
    assert.equal(NS4_E4_MAX_PARALLEL, 20);
    const step = createNs4E4FinalizeStep('buildFlowFsm', 2, ['e4-ontology-round-2-entities-1'], 1, 0);
    assert.equal(step.planning?.planId, 'e4-ontology-round-2-finalize-1-0');
    assert.deepEqual(step.planning?.dependsOn, ['e4-ontology-round-2-entities-1']);
    assert.equal(step.status, 'waiting_dependency');
    assert.match(String(step.prompt), /"stage":"finalize"/);
    const source = readFileSync(new URL('agentNs4E4.ts', import.meta.url), 'utf8');
    assert.match(source, /parallel\.step\.planning\?\.planId/);
    assert.doesNotMatch(source, /createNs4E4FinalizeStep\(args\.moduleName, reviewRound, \[currentPlanId\]/);
});
test('E4 schedules a dedicated relationship binding pass with bounded repair state', () => {
    const initial = createNs4E4RelationshipBindingStep('buildFlowFsm', 2);
    assert.equal(initial.planning?.planId, 'e4-ontology-round-2-relationship-binding-0');
    assert.match(String(initial.prompt), /"stage":"bindRelationships"/);
    const repair = createNs4E4RelationshipBindingStep('buildFlowFsm', 2, 1, 'unknown projectRef');
    assert.equal(repair.planning?.planId, 'e4-ontology-round-2-relationship-binding-1');
    assert.match(String(repair.prompt), /unknown projectRef/);
});
test('every E4 LLM prompt declares an active model alias explicitly', () => {
    for (const file of ['prompt.md', 'promptEntity.md', 'promptRelationships.md']) {
        const prompt = readFileSync(new URL(file, import.meta.url), 'utf8');
        assert.match(prompt, /<!--\s*modelType:\s*reasoning\s*-->/, `${file} must not fall back to the inactive cost alias`);
    }
});
test('E4 overview freezes global decisions and entity detail reassembles the final review', () => {
    const full = normalizeNs4E4Review(reviewInput);
    const plan = normalizeNs4E4PlanDraft(reviewInput);
    assert.deepEqual(validateNs4E4Plan(plan, journeys, access), { ok: true, issues: [] });
    assert.ok(plan.entities.every(entity => !('fields' in entity) && !('useRules' in entity)));
    const details = full.entities.map(entity => normalizeNs4E4EntityDraft(entity, full.moduleName, full.reviewRound, entity.entityId));
    assert.ok(details.every(detail => validateNs4E4EntityDraft(plan, detail).ok));
    assert.deepEqual(assembleNs4E4Review(plan, details), full);
});
test('E2 and E4 share canonical PascalCase business object ids', () => {
    assert.equal(normalizeNs4BusinessObjectId('Project portfolio'), 'ProjectPortfolio');
    assert.equal(normalizeNs4BusinessObjectId('Worker or subcontractor'), 'WorkerOrSubcontractor');
    assert.equal(normalizeNs4BusinessObjectId('WorkTask'), 'WorkTask');
    const spacedJourneys = structuredClone(journeys);
    spacedJourneys.journeys[0].business.steps[0].entity = 'Project portfolio';
    const normalizedJourneys = normalizeNs4E2Review(spacedJourneys);
    assert.equal(normalizedJourneys.journeys[0].business.steps[0].entity, 'ProjectPortfolio');
    const matchingPlan = structuredClone(reviewInput);
    matchingPlan.entities[0].entityId = 'ProjectPortfolio';
    matchingPlan.entities[0].storage.idField = 'projectPortfolioId';
    matchingPlan.relationships[0].toEntity = 'ProjectPortfolio';
    assert.deepEqual(validateNs4E4Plan(normalizeNs4E4PlanDraft(matchingPlan), normalizedJourneys, access), {
        ok: true, issues: [],
    });
});
test('E4 accepts a connected greenfield ontology covering journeys and access information', () => {
    const review = normalizeNs4E4Review(reviewInput);
    assert.deepEqual(validateNs4E4Review(review, journeys, access), { ok: true, issues: [] });
});
test('E4 plan may defer field binding but the final review may not', () => {
    const input = structuredClone(reviewInput);
    delete input.relationships[0].realization;
    assert.deepEqual(validateNs4E4Plan(normalizeNs4E4PlanDraft(input), journeys, access), { ok: true, issues: [] });
    const gate = validateNs4E4Review(normalizeNs4E4Review(input), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_RELATIONSHIP_REALIZATION'));
});
test('E4 applies exactly one field-checked binding per frozen relationship', () => {
    const input = structuredClone(reviewInput);
    delete input.relationships[0].realization;
    const unbound = normalizeNs4E4Review(input);
    const bindings = normalizeNs4E4RelationshipBindings({
        moduleName: 'buildFlowFsm', reviewRound: 1,
        bindings: [{
                relationshipId: 'summaryDescribesProject', realization: {
                    kind: 'derived', ownerEntity: 'ClientProjectSummary',
                    from: { entityId: 'ClientProjectSummary', fieldIds: ['projectId'] },
                    to: { entityId: 'Project', fieldIds: ['projectId'] },
                    description: 'Derived by the shared project identity.',
                },
            }],
    }, 'buildFlowFsm', 1);
    assert.deepEqual(validateNs4E4RelationshipBindings(unbound, bindings, journeys, access), { ok: true, issues: [] });
    assert.equal(applyNs4E4RelationshipBindings(unbound, bindings).relationships[0].realization?.to.fieldIds[0], 'projectId');
    bindings.bindings[0].realization.from.fieldIds = ['inventedProjectId'];
    const broken = validateNs4E4RelationshipBindings(unbound, bindings, journeys, access);
    assert.ok(broken.issues.some(issue => issue.code === 'NS4_E4_RELATIONSHIP_FIELD_UNKNOWN'));
});
test('E4 accepts a required foreign-key binding owned by either semantic endpoint', () => {
    const input = structuredClone(reviewInput);
    input.entities[1].kind = 'supporting';
    input.entities[1].ownership = 'moduleOwned';
    input.entities[1].fields = [
        { fieldId: 'summaryId', title: 'Summary id', type: 'uuid', required: true, description: 'Stable summary id.', constraints: [] },
        { fieldId: 'projectRef', title: 'Project reference', type: 'uuid', required: true, description: 'Owning project.', constraints: [] },
    ];
    input.entities[1].storage = {
        target: 'moduleDatabase', scope: 'module', idField: 'summaryId', notes: 'Module-owned published snapshot.',
    };
    input.relationships[0].realization = {
        kind: 'fieldReference', ownerEntity: 'ClientProjectSummary',
        from: { entityId: 'ClientProjectSummary', fieldIds: ['projectRef'] },
        to: { entityId: 'Project', fieldIds: ['projectId'] },
        description: 'ClientProjectSummary.projectRef references Project.projectId.',
    };
    const review = normalizeNs4E4Review(input);
    assert.deepEqual(validateNs4E4Review(review, journeys, access), { ok: true, issues: [] });
    assert.equal(review.relationships[0].persistence.mode, 'moduleReference');
});
test('E4 freezes named lifecycle meanings as exact reusable state predicates', () => {
    const input = structuredClone(reviewInput);
    input.entities[0].lifecycleStates = ['notStarted', 'inProgress', 'completed', 'cancelled'];
    input.entities[0].initialState = 'notStarted';
    input.entities[0].terminalStates = ['completed', 'cancelled'];
    input.entities[0].fields.push({
        fieldId: 'status', title: 'Status', type: 'string', required: true, description: 'Task status.',
        constraints: [{
                constraintId: 'taskStatus', kind: 'enum',
                value: '["notStarted","inProgress","completed","cancelled"]',
                description: 'Supported states.', source: 'journey',
            }],
    });
    input.entities[0].lifecyclePredicates = [{
            predicateId: 'unfinishedWorkTask',
            description: 'A work task is unfinished while not started or in progress.',
            stateIds: ['notStarted', 'inProgress'], source: 'journey',
        }];
    const review = normalizeNs4E4Review(input);
    const plan = normalizeNs4E4PlanDraft(input);
    assert.deepEqual(validateNs4E4Review(review, journeys, access), { ok: true, issues: [] });
    assert.deepEqual(plan.entities[0].lifecyclePredicates, review.entities[0].lifecyclePredicates);
    assert.deepEqual(validateNs4E4Plan(plan, journeys, access), { ok: true, issues: [] });
    assert.deepEqual(review.entities[0].lifecyclePredicates[0].stateIds, ['notStarted', 'inProgress']);
    input.entities[0].lifecyclePredicates[0].stateIds.push('unknown');
    const broken = validateNs4E4Review(normalizeNs4E4Review(input), journeys, access);
    assert.ok(broken.issues.some(issue => issue.code === 'NS4_E4_LIFECYCLE_PREDICATE_STATE'));
});
test('E4 requires an explicit non-terminal initial lifecycle state', () => {
    const input = structuredClone(reviewInput);
    input.entities[0].lifecycleStates = ['draft', 'published'];
    input.entities[0].fields.push({ fieldId: 'status', title: 'Status', type: 'string', required: true, description: 'Lifecycle status.', constraints: [] });
    input.entities[0].terminalStates = ['published'];
    let gate = validateNs4E4Review(normalizeNs4E4Review(input), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_LIFECYCLE_INITIAL_REQUIRED'));
    input.entities[0].initialState = 'missing';
    gate = validateNs4E4Review(normalizeNs4E4Review(input), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_LIFECYCLE_INITIAL_STATE'));
    input.entities[0].initialState = 'published';
    gate = validateNs4E4Review(normalizeNs4E4Review(input), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_LIFECYCLE_INITIAL_TERMINAL'));
});
test('E4 rejects an access information need omitted from ontology traceability', () => {
    const broken = structuredClone(reviewInput);
    broken.entities[1].sourceRefs.authorityRefs = [];
    const gate = validateNs4E4Review(normalizeNs4E4Review(broken), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_INFORMATION_COVERAGE'));
});
test('E4 rejects a required journey business object omitted from the ontology overview', () => {
    const missingObjectJourneys = structuredClone(journeys);
    missingObjectJourneys.journeys[0].business.steps.push({
        stepId: 'publishClientStatus', kind: 'act', entity: 'PublishedClientStatus',
        title: 'Publish the client status package.', description: 'The client status package is published.',
        featureRefs: [],
    });
    const gate = validateNs4E4Plan(normalizeNs4E4PlanDraft(reviewInput), missingObjectJourneys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_REQUIRED_CONTEXT_OBJECT'
        && issue.message.includes('PublishedClientStatus')));
});
test('E4 rejects disconnected business entities', () => {
    const broken = structuredClone(reviewInput);
    broken.relationships = [];
    const gate = validateNs4E4Review(normalizeNs4E4Review(broken), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_ENTITY_ORPHAN'));
});
test('E4 normalizes common relationship endpoint aliases into the canonical contract', () => {
    const aliased = structuredClone(reviewInput);
    const relationship = aliased.relationships[0];
    relationship.sourceEntity = relationship.fromEntity;
    relationship.targetEntity = relationship.toEntity;
    delete relationship.fromEntity;
    delete relationship.toEntity;
    const normalized = normalizeNs4E4Review(aliased);
    assert.equal(normalized.relationships[0].fromEntity, 'ClientProjectSummary');
    assert.equal(normalized.relationships[0].toEntity, 'Project');
    assert.equal(normalized.relationships[0].persistence.mode, 'derivedJoin');
});
test('E4 creates one entity artifact plus an index with the same frozen hash', async () => {
    const review = normalizeNs4E4Review(reviewInput);
    const artifacts = await buildNs4OntologyArtifacts(review, 'human', '2026-08-05T18:00:00.000Z');
    assert.equal(artifacts.entities.length, 2);
    assert.match(artifacts.index.ontologyHash, /^sha256:[a-f0-9]{64}$/);
    assert.ok(artifacts.entities.every(entity => entity.ontologyHash === artifacts.index.ontologyHash));
    assert.equal(artifacts.index.entities[0].definitionRef, 'l4/buildFlowFsm/ontology/Project.defs.ts');
    assert.equal(artifacts.index.entities[0].storage.target, 'moduleDatabase');
});
test('E4 accepts explicit organization MDM routing and exposes it in the ontology index', async () => {
    const mdmInput = structuredClone(reviewInput);
    mdmInput.entities[0].kind = 'mdm';
    mdmInput.entities[0].storage = {
        target: 'mdm', scope: 'organization', idField: 'projectId', mdmType: 'buildFlowFsm.Project',
        notes: 'Stable organization project master reused by transactions and reports.',
    };
    const review = normalizeNs4E4Review(mdmInput);
    assert.deepEqual(validateNs4E4Review(review, journeys, access), { ok: true, issues: [] });
    const artifacts = await buildNs4OntologyArtifacts(review, 'human', '2026-08-05T18:00:00.000Z');
    assert.equal(artifacts.index.entities[0].storage.mdmType, 'buildFlowFsm.Project');
    assert.equal(artifacts.index.relationships[0].persistence.mode, 'derivedJoin');
});
test('E4 rejects an MDM entity routed to a local transactional table', () => {
    const broken = structuredClone(reviewInput);
    broken.entities[0].kind = 'mdm';
    const gate = validateNs4E4Review(normalizeNs4E4Review(broken), journeys, access);
    assert.ok(gate.issues.some(issue => issue.code === 'NS4_E4_STORAGE_TARGET'));
});
// PARTY POLICY (18/ago/2026). The three checks exist because the buildFlowFsm run obeyed the prose and
// still put people in a local table: Client and Project went to MDM, FieldWorker (a person, `core` +
// `external`) became a seeded module table duplicating the organization's users.
test('E4 requires the party declaration and routes every party to MDM', () => {
    const missing = structuredClone(reviewInput);
    const gate = validateNs4E4Review(normalizeNs4E4Review(missing), journeys, access);
    // reviewInput declares party on both entities, so the baseline is silent…
    assert.ok(!gate.issues.some(issue => issue.code === 'NS4_E4_PARTY_MISSING'), JSON.stringify(gate.issues));
    // …and an entity whose party the model did not declare (or declared outside the vocabulary) is named.
    delete missing.entities[0].party;
    missing.entities[1].party = 'people';
    const undeclared = validateNs4E4Review(normalizeNs4E4Review(missing), journeys, access);
    assert.equal(undeclared.issues.filter(issue => issue.code === 'NS4_E4_PARTY_MISSING').length, 2);
    // A person kept in the module database is the FieldWorker defect, now blocking.
    const person = structuredClone(reviewInput);
    person.entities[0].party = 'person';
    const routed = validateNs4E4Review(normalizeNs4E4Review(person), journeys, access);
    const issue = routed.issues.find(each => each.code === 'NS4_E4_PARTY_STORAGE');
    assert.ok(issue, JSON.stringify(routed.issues));
    assert.match(issue.message, /master data of the organization/u);
    assert.match(issue.message, /platformUserId/u);
});
test('E4 rejects kind core with ownership external — the combination the policy never defined', () => {
    const broken = structuredClone(reviewInput);
    broken.entities[0].ownership = 'external';
    broken.entities[0].storage = { target: 'external', scope: 'platform', notes: 'Platform user reference.' };
    const gate = validateNs4E4Review(normalizeNs4E4Review(broken), journeys, access);
    const issue = gate.issues.find(each => each.code === 'NS4_E4_OWNERSHIP_EXTERNAL_CORE');
    assert.ok(issue, JSON.stringify(gate.issues));
    assert.match(issue.message, /external-reference field \(platformUserId\)/u);
});
test('E4 flags an ownership rule when the entity has no owner field (petShop customerCanViewOnlyOwnPets)', () => {
    const broken = structuredClone(reviewInput);
    broken.entities[0].useRules = ['customerCanViewOnlyOwnPets'];
    const gate = validateNs4E4Review(normalizeNs4E4Review(broken), journeys, access);
    const issue = gate.issues.find(item => item.code === 'NS4_E4_OWNER_RELATION');
    assert.ok(issue, JSON.stringify(gate.issues));
    assert.match(issue.message, /customerCanViewOnlyOwnPets/);
    assert.match(issue.message, /Project/);
    const withField = structuredClone(reviewInput);
    withField.entities[0].useRules = ['customerCanViewOnlyOwnPets'];
    withField.entities[0].fields.push({
        fieldId: 'customerId', title: 'Customer', type: 'uuid', required: true, description: 'Owner of the record.', constraints: [],
    });
    const ok = validateNs4E4Review(normalizeNs4E4Review(withField), journeys, access);
    assert.ok(!ok.issues.some(item => item.code === 'NS4_E4_OWNER_RELATION'), JSON.stringify(ok.issues));
});
test('E4 carries the party declaration into the entity artifact', async () => {
    const input = structuredClone(reviewInput);
    input.entities[0].kind = 'mdm';
    input.entities[0].party = 'organization';
    input.entities[0].storage = {
        target: 'mdm', scope: 'organization', idField: 'projectId', mdmType: 'buildFlowFsm.Project',
        notes: 'Organization master record.',
    };
    const review = normalizeNs4E4Review(input);
    assert.deepEqual(validateNs4E4Review(review, journeys, access), { ok: true, issues: [] });
    const artifacts = await buildNs4OntologyArtifacts(review, 'human', '2026-08-18T12:00:00.000Z');
    assert.equal(artifacts.entities[0].party, 'organization');
});
test('E4 lifecycle resumes an E3-approved current flow and advances to E5', () => {
    const e1 = markNs4E1Approved(createNs4Pipeline('buildFlowFsm', 'prompt'), 'human', 'module.defs.ts');
    const e2 = markNs4E2Approved(markNs4E2WaitingHuman(markNs4E2Running(e1, 1), 1, 'e2.json'), 'human', ['journey.ts']);
    const e3 = markNs4E3Approved(markNs4E3Running(e2, 1), 'human', 'access.defs.ts');
    assert.equal(resolveNs4ExistingAction(true, e3, true), 'resume-e4');
    const waiting = markNs4E4WaitingHuman(markNs4E4Running(e3, 2), 2, 'e4.json');
    assert.equal(waiting.steps.e4?.solutionMode, 'new');
    const failed = markNs4E4Failed(waiting, 'provider timeout');
    assert.equal(failed.steps.e4?.error, 'provider timeout');
    const approved = markNs4E4Approved(waiting, 'human', ['Project.defs.ts', 'index.defs.ts']);
    assert.equal(approved.nextStep, 'e5-rules');
    assert.equal(resolveNs4ExistingAction(true, approved, true), 'resume-e5');
    assert.equal(markNs4E4Running(approved, 3), approved);
    assert.equal(markNs4E4WaitingHuman(approved, 3, 'late-draft.json'), approved);
    assert.equal(markNs4E4Failed(approved, 'late duplicate callback'), approved);
});
test('an enumerated field carries its literal values, in every shape the generators author', () => {
    const withUnions = structuredClone(reviewInput);
    const entity = withUnions.entities[0];
    entity.lifecycleStates = ['draft', 'active', 'closed'];
    entity.fields = [
        ...entity.fields,
        { fieldId: 'status', title: 'Status', type: 'string', required: true, description: 'Estado.', constraints: [] },
        { fieldId: 'impactType', title: 'Impacto', type: 'string', required: true, description: 'Impacto.',
            constraints: [{ constraintId: 'impactTypeEnum', kind: 'enum', value: '["cost","schedule","both"]', description: 'Custo, prazo ou ambos.', source: 'journey' }] },
        { fieldId: 'channel', title: 'Canal', type: 'string', required: false, description: 'Canal.',
            constraints: [{ constraintId: 'channelEnum', kind: 'enum', value: 'email, portal, phone', description: 'Canais aceitos.', source: 'journey' }] },
        { fieldId: 'priority', title: 'Prioridade', type: 'string', required: false, description: 'Prioridade.',
            constraints: [{ constraintId: 'priorityEnum', kind: 'enum', value: 'low|medium|high', description: 'Níveis.', source: 'journey' }] },
        { fieldId: 'note', title: 'Nota', type: 'text', required: false, description: 'Nota livre.', constraints: [] },
    ];
    const review = normalizeNs4E4Review(withUnions);
    const normalized = review.entities[0];
    const fieldOf = (fieldId) => normalized.fields.find(field => field.fieldId === fieldId);
    // The lifecycle is the union of a status field even when nobody wrote the constraint.
    assert.deepEqual(normalized.statusEnum, ['draft', 'active', 'closed']);
    assert.deepEqual(fieldOf('status')?.enum, ['draft', 'active', 'closed']);
    // JSON array, comma-separated and pipe-separated are all authored in practice.
    assert.deepEqual(fieldOf('impactType')?.enum, ['cost', 'schedule', 'both']);
    assert.deepEqual(fieldOf('channel')?.enum, ['email', 'portal', 'phone']);
    assert.deepEqual(fieldOf('priority')?.enum, ['low', 'medium', 'high']);
    // A field without a union stays without one; the constraint is never invented.
    assert.equal('enum' in (fieldOf('note') || {}), false);
    // The constraint remains the human-readable rule; the union does not replace it.
    assert.equal(fieldOf('impactType')?.constraints[0].kind, 'enum');
    // Re-reading an already-derived artifact derives the same values: the emission is idempotent.
    assert.deepEqual(normalizeNs4E4Review(review).entities[0], normalized);
});
test('an entity without lifecycle carries no statusEnum', () => {
    const review = normalizeNs4E4Review(structuredClone(reviewInput));
    const stateless = review.entities.find(entity => !entity.lifecycleStates.length);
    assert.ok(stateless, 'the fixture has a stateless entity');
    assert.equal('statusEnum' in stateless, false);
});
test('the derived union never reaches the strict entity worker, and always reaches the emitted artifact', async () => {
    const source = structuredClone(reviewInput);
    const entity = source.entities[0];
    entity.lifecycleStates = ['draft', 'active'];
    entity.fields = [...entity.fields, { fieldId: 'status', title: 'Status', type: 'string', required: true, description: 'Estado.',
            constraints: [{ constraintId: 'statusEnum', kind: 'enum', value: '["draft","active"]', description: 'Rascunho ou ativo.', source: 'journey' }] }];
    // The worker contract owns no union key (schemas/e4-entity-worker.schema.json is strict), so the
    // persisted entity draft must not carry one back into the repair prompt.
    const draft = normalizeNs4E4EntityDraft({ fields: entity.fields, useRules: entity.useRules }, source.moduleName, 1, entity.entityId);
    assert.equal(draft.fields.some(field => 'enum' in field), false);
    // An approved entity echoed as "previous entity" is stripped the same way.
    const review = normalizeNs4E4Review(source);
    const built = await buildNs4OntologyArtifacts(review, 'auto', '2026-08-14T00:00:00.000Z');
    const artifact = built.entities.find(item => item.entityId === entity.entityId);
    const echoed = stripNs4DerivedFieldUnions(artifact);
    assert.equal(echoed.fields.some((field) => 'enum' in field), false);
    assert.equal('statusEnum' in echoed, false);
    // The emitted artifact is what the frontend parses: it reads data.statusEnum and data.fields[].enum.
    assert.deepEqual(artifact.statusEnum, ['draft', 'active']);
    assert.deepEqual(artifact.fields.find(field => field.fieldId === 'status')?.enum, ['draft', 'active']);
});
