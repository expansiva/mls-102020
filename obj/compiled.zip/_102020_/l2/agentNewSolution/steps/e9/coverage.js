/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e9/coverage.ts" enhancement="_blank"/>
export const NS4_USECASE_DROP_UNREFERENCED = 'no workspace references the step';
export const NS4_USECASE_DROP_DUPLICATE = 'uniqueBy discarded a duplicate operationId';
export function compareE7ToOperations(input) {
    const approved = uniqueIds(input.approved.map(item => item.useCaseId).filter(Boolean));
    const byId = new Map(input.approved.filter(item => item.useCaseId).map(item => [item.useCaseId, item]));
    const emitted = new Set(input.emittedOperationIds.filter(Boolean));
    const hosted = new Set(input.hostedStepRefs || []);
    const notEmitted = [];
    const reasons = {};
    for (const useCaseId of approved) {
        if (emitted.has(useCaseId))
            continue;
        notEmitted.push(useCaseId);
        const reason = dropReason(byId.get(useCaseId)?.compiledFrom || [], hosted);
        if (reason)
            reasons[useCaseId] = reason;
    }
    const dropped = {
        notEmitted,
        approved: approved.length,
        emitted: emitted.size,
        ...(Object.keys(reasons).length ? { reasons } : {}),
    };
    if (notEmitted.length === 0)
        return { useCases: 'ok', approved: dropped.approved, emitted: dropped.emitted };
    return { useCases: 'degraded', useCasesDropped: dropped };
}
export function useCaseCoverageLogLine(verdict) {
    // English: this line lands in the step status the user reads in the studio.
    const approved = verdict.useCases === 'ok' ? verdict.approved : verdict.useCasesDropped.approved;
    const emitted = verdict.useCases === 'ok' ? verdict.emitted : verdict.useCasesDropped.emitted;
    const notEmitted = verdict.useCases === 'ok' ? 0 : verdict.useCasesDropped.notEmitted.length;
    return `${approved} approved, ${emitted} emitted, ${notEmitted} not emitted`;
}
/** Strip a prior-run `degraded` first. A clean emit leaves no `useCases` / `useCasesDropped` on disk. */
export function applyNs4UseCaseCoverage(state, verdict) {
    const { useCases: _useCases, useCasesDropped: _dropped, ...rest } = state;
    if (verdict.useCases === 'ok')
        return rest;
    return { ...rest, useCases: 'degraded', useCasesDropped: verdict.useCasesDropped };
}
function dropReason(compiledFrom, hosted) {
    if (!compiledFrom.length || hosted.size === 0)
        return undefined;
    if (!compiledFrom.some(ref => hosted.has(ref)))
        return NS4_USECASE_DROP_UNREFERENCED;
    return NS4_USECASE_DROP_DUPLICATE;
}
function uniqueIds(values) {
    return [...new Set(values)].sort((left, right) => left.localeCompare(right));
}
