/// <mls fileReference="_102020_/l2/agentNewSolution/steps/e9/classic.ts" enhancement="_blank"/>
export const NS4_CLASSIC_WORKSPACE_VERSION = '2026-08-14-ns4-classic-workspace-v6';
/** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
export function ns4ClassicFrom(operationId, member) {
    return `${operationId}.${member}`;
}
export function transposeNs4ClassicOperation(model, operation, ontology) {
    const entity = ontology.entities.find(item => item.entityId === operation.entityRef);
    const owner = model.workspaces.find(workspace => workspace.bffCalls.some(call => call.operationId === operation.operationId));
    const call = owner?.bffCalls.find(item => item.operationId === operation.operationId);
    const list = operation.accessPattern.kind === 'list';
    const outputFields = (entity?.fields || []).map(field => ({
        name: field.fieldId, type: classicType(field.type), required: field.required,
        fieldRef: `${operation.entityRef}.${field.fieldId}`,
    }));
    return {
        operationId: operation.operationId,
        title: operation.title,
        actors: owner?.actors || [],
        entity: operation.entityRef,
        kind: operation.kind === 'query' ? 'query' : operation.accessPattern.kind,
        reads: operation.entityRefs,
        writes: operation.kind === 'command' ? [operation.entityRef] : [],
        rulesApplied: operation.useRules,
        story: {
            actor: owner?.actors[0] || '', goal: operation.title,
            steps: operation.story, outcome: operation.story[operation.story.length - 1] || operation.title,
        },
        accessPattern: {
            kind: operation.accessPattern.kind,
            description: operation.title,
            entity: operation.entityRef,
            keyField: `${operation.entityRef}.${identityFieldOf(entity)}`,
            // Pagination stays declared as none until a call actually projects the page meta; a shape the
            // module never emits would only make the wire lie about itself.
            pagination: 'none',
            selection: list ? 'single' : 'none',
            output: outputFields.map(field => field.fieldRef),
        },
        outputShape: { kind: list ? 'list' : 'object', fields: outputFields },
        inputs: operation.inputs.map(input => ({
            inputId: input.inputId,
            fieldRef: `${input.fieldRef.entityId}.${input.fieldRef.fieldId}`,
            required: input.required,
            source: input.source,
            description: input.description,
        })),
        ...(operation.mdm ? { mdm: operation.mdm } : {}),
        pageId: owner?.workspaceId || '',
        commandName: call?.bffId || operation.operationId,
        bffName: call?.bffId || operation.operationId,
    };
}
export function transposeNs4ClassicWorkspace(model, workspace, operations, ontology, sliceHash) {
    const bffCalls = workspace.bffCalls.map(call => transposeCall(model, workspace.workspaceId, call, operations.get(call.operationId), ontology));
    return {
        workspaceId: workspace.workspaceId,
        title: workspace.title,
        actors: workspace.actors.length ? workspace.actors : workspace.profileRefs,
        kind: workspace.kind,
        entity: workspace.entity,
        ...(workspace.workflowId ? { workflowId: workspace.workflowId } : {}),
        bffCalls,
        sections: workspace.sections.map(section => ({
            sectionId: section.sectionId,
            intent: section.intent,
            organisms: section.organisms.map(organism => ({
                role: organism.role,
                ...(organism.dataSource ? { dataSource: organism.dataSource } : {}),
                ...(organism.action ? { action: organism.action } : {}),
                ...(organism.usage ? { usage: organism.usage } : {}),
            })),
        })),
        operationIds: [...new Set(workspace.bffCalls.map(call => call.operationId))].sort(),
        purpose: workspace.purpose,
        presentation: {
            categoryRef: workspace.categoryRef,
            confidence: 10,
            classificationNote: `Derived from the ${workspace.tier} tier of the approved E8 model; the category is structural, not a guess.`,
        },
        sliceHash,
    };
}
function transposeCall(model, workspaceId, call, operation, ontology) {
    const entity = ontology.entities.find(item => item.entityId === call.entityRef);
    const list = call.outputKind === 'paginated' || operation?.accessPattern.kind === 'list';
    const fields = (entity?.fields || []).map(field => ({
        name: field.fieldId,
        from: ns4ClassicFrom(call.operationId, list ? `$items.${field.fieldId}` : field.fieldId),
        type: classicType(field.type),
        required: field.required,
    }));
    return {
        bffId: call.bffId,
        kind: call.kind,
        uses: [{ operationId: call.operationId }],
        input: (operation?.inputs || []).map(input => ({
            name: input.inputId,
            from: ns4ClassicFrom(call.operationId, input.inputId),
            ...(input.required ? { required: true } : {}),
            source: input.source,
            // `source` alone is an unusable label: the consumer needs the call the picker reads FROM, and it
            // is the one thing only this workspace knows. Absent when the value is not chosen on the page.
            ...(inputSourceOf(call, input.inputId) ? { sourceRef: inputSourceOf(call, input.inputId) } : {}),
            // 2. The type comes from the ontology field the input names, never from a lucky match against
            // an output projection path (a list output is `$items.`-prefixed and would never match).
            type: classicType(fieldTypeOf(ontology, input.fieldRef.entityId, input.fieldRef.fieldId)),
        })),
        // One call carries at most one collection: composition is several calls on one page.
        output: { kind: list ? 'list' : 'object', fields },
        route: `${model.moduleName}.${workspaceId}.${call.bffId}`,
    };
}
function inputSourceOf(call, inputId) {
    return (call.inputSources || []).find(entry => entry.inputId === inputId)?.bffId || '';
}
function fieldTypeOf(ontology, entityId, fieldId) {
    return ontology.entities.find(entity => entity.entityId === entityId)
        ?.fields.find(field => field.fieldId === fieldId)?.type || 'string';
}
/** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
export function buildNs4ClassicContractSource(args) {
    const pascal = upperCamel(args.call.bffId);
    const inputFields = args.call.input.map(input => `  ${input.name}${input.required ? '' : '?'}: ${tsType(input.type)};`);
    const outputFields = args.call.output.fields.map(field => `  ${field.name}${field.required ? '' : '?'}: ${tsType(field.type)};`);
    return [
        `/// <mls fileReference="${args.fileRef}" enhancement="_blank"/>`,
        '',
        `// GENERATED MECHANICALLY from ${args.sourceRef} — DO NOT EDIT.`,
        `// Contract of record: bffCall ${args.call.bffId} (${args.call.kind}); Output kind=${args.call.output.kind}; route ${args.call.route}.`,
        '',
        `export interface ${pascal}Input {`,
        ...(inputFields.length ? inputFields : ['  // sem inputs públicos (resolvidos por contexto)']),
        '}',
        '',
        `export interface ${pascal}Output {`,
        ...(outputFields.length ? outputFields : ['  // sem projeção declarada']),
        '}',
        '',
        `export const ${args.call.bffId}Route = '${args.call.route}' as const;`,
        '',
    ].join('\n');
}
export function buildNs4ClassicSiteMap(model, classic) {
    const byId = new Map(model.workspaces.map(workspace => [workspace.workspaceId, workspace]));
    const hub = model.workspaces.find(workspace => workspace.tier === 'hub');
    return {
        moduleName: model.moduleName,
        note: 'Site map (permanent page index) — workspaces, landings and advisory edges. Detail (sections/organisms/bffCalls) lives per-workspace under workspaces/.',
        workspaces: classic.map(workspace => ({
            workspaceId: workspace.workspaceId, title: workspace.title, actors: workspace.actors,
            kind: workspace.kind, entity: workspace.entity, operationIds: workspace.operationIds, purpose: workspace.purpose,
        })),
        landings: model.landings.map(landing => ({
            actorId: landing.profileRef, workspaceId: landing.workspaceId,
            reason: byId.get(landing.workspaceId)?.purpose || '',
        })),
        // A journey is reached from the hub that anchors it, never from the menu: the edge records that,
        // with the prominence and order the composition chose — this is where the hub template reads them.
        navigationEdges: [
            ...model.workspaces.flatMap(workspace => (workspace.navigation || [])
                .filter(target => byId.has(target.targetWorkspaceId))
                .map(target => ({
                from: workspace.workspaceId, to: target.targetWorkspaceId, operationId: '',
                description: target.label, prominence: target.prominence, order: target.order,
            }))),
            // A tile the hub reads still links to the page that owns it, so the projection stays reachable.
            ...(hub ? (hub.hubCatalogue?.items || [])
                .filter(item => item.kind !== 'action' && item.kind !== 'pending'
                && byId.has(item.targetRef) && item.targetRef !== hub.workspaceId)
                .map(item => ({ from: hub.workspaceId, to: item.targetRef, operationId: '', description: item.label }))
                : []),
        ],
        workspaceIds: classic.map(workspace => workspace.workspaceId),
    };
}
function identityFieldOf(entity) {
    return entity?.storage.idField || entity?.fields.find(field => /Id$/.test(field.fieldId))?.fieldId || '';
}
function classicType(type) {
    if (type === 'number' || type === 'integer' || type === 'money')
        return 'number';
    if (type === 'boolean')
        return 'boolean';
    return 'string';
}
function tsType(type) {
    return type === 'number' || type === 'boolean' ? type : 'string';
}
function upperCamel(value) {
    return value ? value.slice(0, 1).toUpperCase() + value.slice(1) : '';
}
/** The whole transposition: what E9 writes to L4 from an approved E8 model. */
export async function compileNs4ClassicL4(model, ontology) {
    const operations = new Map(model.operations.map(operation => [operation.operationId, operation]));
    const workspaces = [];
    for (const workspace of model.workspaces) {
        const sliceHash = await hashNs4Slice({ workspaceId: workspace.workspaceId, bffCalls: workspace.bffCalls, sections: workspace.sections });
        workspaces.push(transposeNs4ClassicWorkspace(model, workspace, operations, ontology, sliceHash));
    }
    const contracts = workspaces.flatMap(workspace => workspace.bffCalls.map(call => ({
        workspaceId: workspace.workspaceId, bffId: call.bffId, route: call.route,
        source: buildNs4ClassicContractSource({
            moduleName: model.moduleName, workspaceId: workspace.workspaceId, call,
            fileRef: `_${'{project}'}_/l4/${model.moduleName}/contracts/${workspace.workspaceId}.${call.bffId}.defs.ts`,
            sourceRef: `l4/${model.moduleName}/workspaces/${workspace.workspaceId}.defs.ts`,
        }),
    })));
    return {
        workspaces,
        operations: model.operations.map(operation => transposeNs4ClassicOperation(model, operation, ontology)),
        contracts,
        siteMap: buildNs4ClassicSiteMap(model, workspaces),
    };
}
async function hashNs4Slice(value) {
    const bytes = new TextEncoder().encode(JSON.stringify(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return `sha256:${[...new Uint8Array(digest)].slice(0, 4).map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
