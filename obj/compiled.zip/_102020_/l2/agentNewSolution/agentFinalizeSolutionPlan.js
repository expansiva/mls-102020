/// <mls fileReference="_102020_/l2/agentNewSolution/agentFinalizeSolutionPlan.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, createPlannerPromptReadyIntent, createPlannerToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, findStepByPlanId, getPlannerOutput, getPlanningContextSnapshot, hasAcceptedNowArtifact, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { saveNewSolutionAgentTracePayload } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
import { getBlueprintReviewOutput } from '/_102020_/l2/agentNewSolution/agentBlueprintReview.js';
import { getSolutionBlueprintOutput } from '/_102020_/l2/agentNewSolution/agentSolutionBlueprint.js';
export function createAgent() {
    return {
        agentName: 'agentFinalizeSolutionPlan',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Finalize the solution plan after blueprint review',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const FINALIZE_SOLUTION_PLAN_TOOL_NAME = 'submitFinalSolutionPlan';
export const FINALIZE_SOLUTION_PLAN_STEP_ID = '08-finalize-solution-plan';
const FINALIZE_SOLUTION_PLAN_ALIASES = [FINALIZE_SOLUTION_PLAN_STEP_ID, 'plan-finalize-solution-plan'];
const finalizeSolutionPlanToolSchema = createPlannerToolSchema(FINALIZE_SOLUTION_PLAN_TOOL_NAME, 'Submit the final solution plan after applying blueprint review findings.', FINALIZE_SOLUTION_PLAN_STEP_ID, {
    type: 'object',
    additionalProperties: false,
    required: ['module', 'actors', 'capabilities', 'ontology', 'rules', 'relationships', 'userActions', 'approvedArtifacts', 'decisions', 'deferredItems'],
    properties: {
        module: { type: 'object', additionalProperties: true },
        actors: { type: 'array', items: { type: 'object', additionalProperties: true } },
        capabilities: { type: 'array', items: { type: 'object', additionalProperties: true } },
        ontology: {
            type: 'object',
            additionalProperties: false,
            required: ['entities'],
            properties: {
                entities: { type: 'object', additionalProperties: true },
            },
        },
        rules: { type: 'array', items: { type: 'object', additionalProperties: true } },
        relationships: { type: 'array', items: { type: 'object', additionalProperties: true } },
        userActions: { type: 'array', items: { type: 'object', additionalProperties: true } },
        approvedArtifacts: {
            type: 'object',
            additionalProperties: false,
            required: ['pages', 'workflows', 'plugins', 'agents', 'horizontalModules', 'mdm', 'metricTables', 'metricDashboards', 'usecaseEntities'],
            properties: {
                pages: { type: 'array', items: { type: 'object', additionalProperties: true } },
                workflows: { type: 'array', items: { type: 'object', additionalProperties: true } },
                plugins: { type: 'array', items: { type: 'object', additionalProperties: true } },
                agents: { type: 'array', items: { type: 'object', additionalProperties: true } },
                horizontalModules: { type: 'array', items: { type: 'object', additionalProperties: true } },
                mdm: { type: 'array', items: { type: 'object', additionalProperties: true } },
                metricTables: { type: 'array', items: { type: 'object', additionalProperties: true } },
                metricDashboards: { type: 'array', items: { type: 'object', additionalProperties: true } },
                usecaseEntities: { type: 'array', items: { type: 'object', additionalProperties: true } },
            },
        },
        decisions: { type: 'array', items: { type: 'object', additionalProperties: true } },
        deferredItems: { type: 'array', items: { type: 'object', additionalProperties: true } },
    },
});
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentFinalizeSolutionPlan](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const snapshot = getPlanningContextSnapshot(context);
    const blueprint = getSolutionBlueprintOutput(context);
    const review = getBlueprintReviewOutput(context);
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(FINALIZE_SOLUTION_PLAN_TOOL_NAME), buildHumanPrompt(args, blueprint, review, snapshot), finalizeSolutionPlanToolSchema, FINALIZE_SOLUTION_PLAN_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const output = extractFinalizeSolutionPlanOutput(payload);
        validateFinalizeSolutionPlanOutput(output, context);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentFinalizeSolutionPlan returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentFinalizeSolutionPlan returned status needs_input; keeping corrected plan draft.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    const intents = [
        createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? 'input' : undefined),
    ];
    if (status === 'completed') {
        const blueprintStep = findStepByPlanId(context, 'plan-solution-blueprint');
        if (blueprintStep?.type === 'agent') {
            intents.push(createPlannerUpdateStatusIntent(context, parentStep, blueprintStep, hookSequential, 'completed', undefined, 'input_output'));
        }
    }
    return intents;
}
export function getFinalizeSolutionPlanOutput(context) {
    return getPlannerOutput(context, 'agentFinalizeSolutionPlan', finalizeSolutionPlanConfig, output => validateFinalizeSolutionPlanOutput(output, context));
}
function extractFinalizeSolutionPlanOutput(payload) {
    return extractPlannerOutput(payload, finalizeSolutionPlanConfig);
}
const finalizeSolutionPlanConfig = {
    toolName: FINALIZE_SOLUTION_PLAN_TOOL_NAME,
    stepId: FINALIZE_SOLUTION_PLAN_STEP_ID,
    stepIdAliases: FINALIZE_SOLUTION_PLAN_ALIASES,
    normalizeResult: normalizeFinalSolutionPlanResult,
};
function normalizeFinalSolutionPlanResult(value) {
    const result = assertRecord(value, 'result');
    const ontology = assertRecord(result.ontology, 'result.ontology');
    const approvedArtifacts = assertRecord(result.approvedArtifacts, 'result.approvedArtifacts');
    return {
        module: assertRecord(result.module, 'result.module'),
        actors: assertArray(result.actors, 'result.actors'),
        capabilities: assertArray(result.capabilities, 'result.capabilities'),
        ontology: {
            entities: assertRecord(ontology.entities, 'result.ontology.entities'),
        },
        rules: assertArray(result.rules, 'result.rules'),
        relationships: assertArray(result.relationships, 'result.relationships'),
        userActions: assertArray(result.userActions, 'result.userActions'),
        approvedArtifacts: {
            pages: assertArray(approvedArtifacts.pages, 'result.approvedArtifacts.pages'),
            workflows: assertArray(approvedArtifacts.workflows, 'result.approvedArtifacts.workflows'),
            plugins: assertArray(approvedArtifacts.plugins, 'result.approvedArtifacts.plugins'),
            agents: assertArray(approvedArtifacts.agents, 'result.approvedArtifacts.agents'),
            horizontalModules: assertArray(approvedArtifacts.horizontalModules, 'result.approvedArtifacts.horizontalModules'),
            mdm: assertArray(approvedArtifacts.mdm, 'result.approvedArtifacts.mdm'),
            metricTables: assertArray(approvedArtifacts.metricTables, 'result.approvedArtifacts.metricTables'),
            metricDashboards: assertArray(approvedArtifacts.metricDashboards, 'result.approvedArtifacts.metricDashboards'),
            usecaseEntities: assertArray(approvedArtifacts.usecaseEntities, 'result.approvedArtifacts.usecaseEntities'),
        },
        decisions: assertArray(result.decisions, 'result.decisions'),
        deferredItems: assertArray(result.deferredItems, 'result.deferredItems'),
    };
}
function validateFinalizeSolutionPlanOutput(output, context) {
    const snapshot = getPlanningContextSnapshot(context);
    if (output.status === 'ok' && output.result.approvedArtifacts.mdm.length === 0)
        throw new Error('final solution plan must keep MDM');
    if (output.status === 'ok' && snapshot.initialMetricsRequested) {
        if (output.result.approvedArtifacts.metricTables.length === 0)
            throw new Error('initial metrics requested, but final plan has no metricTables');
        if (output.result.approvedArtifacts.metricDashboards.length === 0)
            throw new Error('initial metrics requested, but final plan has no metricDashboards');
    }
    if (output.status === 'ok' && hasAcceptedNowArtifact(snapshot.implementationDecisions, 'usecaseEntity') && output.result.approvedArtifacts.usecaseEntities.length === 0) {
        throw new Error('accepted usecaseEntity planning, but final plan has no usecaseEntities');
    }
    if (output.status === 'needs_input' && output.questions.length === 0)
        throw new Error('needs_input final plan must include questions');
}
function buildHumanPrompt(args, blueprint, review, snapshot) {
    return `## Planned step args
${args}

## Solution blueprint
${JSON.stringify(blueprint, null, 2)}

## Blueprint review
${JSON.stringify(review, null, 2)}

## Accepted implementation decisions
${JSON.stringify(snapshot.implementationDecisions, null, 2)}

## Initial metrics/dashboard requested
${snapshot.initialMetricsRequested}
`;
}
const systemPrompt = `
<!-- modelType: codepro -->

You are agentFinalizeSolutionPlan for the collab.codes "newSolution" flow.
Apply the blueprint review and produce the final solution plan.
Use the same language as the user for labels, descriptions, questions, and trace.
Use English camelCase identifiers for ids and PascalCase for entity names.

## Tool mode
Call the "{{toolName}}" tool with the complete structured result.
Do not return prose.

## Rules
- Fix all review issues with severity "error".
- Keep later items in deferredItems.
- Do not remove MDM.
- Do not remove approved initial metrics/dashboard.
- Do not remove layer_3 usecase planning when BFF commands, writes, lifecycle changes, or metric updates exist.
- Keep rules centralized in rules with stable ruleId values.
- Page definitions and BFF commands must reference rules by ruleId.
- Do not continue if an error cannot be fixed from available context; return status "needs_input" with questions.

## Content Memory
actualDate: 2026-06-05
userName: Wagner
taskName: newModule
flowName: newSolution
`;
