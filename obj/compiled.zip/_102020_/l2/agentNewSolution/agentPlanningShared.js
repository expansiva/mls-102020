/// <mls fileReference="_102020_/l2/agentNewSolution/agentPlanningShared.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAgentStepByAgentName, getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { getDiscoverSolutionScopeOutput, wantsInitialMetricsDashboard, } from '/_102020_/l2/agentNewSolution/agentDiscoverSolutionScope.js';
import { getRecommendImplementationsOutput, } from '/_102020_/l2/agentNewSolution/agentRecommendImplementations.js';
import { getRequirementsClarificationAnswer, } from '/_102020_/l2/agentNewSolution/agentNewSolutionRequirements.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution/agentNewSolutionPlan.js';
import { extractPlannerOutput, parseMaybeJson, PLANNER_SCHEMA_VERSION as PLANNER_SCHEMA_VERSION_VALUE, } from '/_102020_/l2/agentNewSolution/agentPlanningExtract.js';
import { readSavedPlanArtifactDataList } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
export { PLANNER_SCHEMA_VERSION, assertArray, assertPriority, assertRecord, assertString, assertStringArray, createPlannerToolSchema, createPlannerVariableToolSchema, extractPlannerOutput, isRecord, normalizeStringList, optionalString, parseMaybeJson, } from '/_102020_/l2/agentNewSolution/agentPlanningExtract.js';
export function createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, toolSchema, toolName) {
    if (!context.task)
        throw new Error('[createPlannerPromptReadyIntent] task invalid');
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [toolSchema],
        toolChoice: {
            type: 'function',
            function: { name: toolName },
        },
    };
}
export function createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
    if (cleaner)
        intent.cleaner = cleaner;
    return intent;
}
export function getPlannerOutput(context, agentName, config, validate) {
    if (!context.task)
        throw new Error('[getPlannerOutput] task invalid');
    const agentStep = getAgentStepByAgentName(context.task, agentName);
    if (!agentStep)
        throw new Error(`[getPlannerOutput] ${agentName} step not found`);
    const payload = agentStep.interaction?.payload?.[0];
    if (!payload)
        throw new Error(`[getPlannerOutput] ${agentName} payload not found`);
    const output = extractPlannerOutput(payload, config);
    validate?.(output);
    return output;
}
export function getPlannerOutputs(context, agentName, config, validate) {
    if (!context.task)
        throw new Error('[getPlannerOutputs] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    const outputs = [];
    for (const step of allSteps) {
        if (step.type !== 'agent' || step.agentName !== agentName)
            continue;
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            continue;
        const output = extractPlannerOutput(payload, config);
        validate?.(output);
        outputs.push(output);
    }
    return outputs;
}
/**
 * TODO-FINAL-010/023: read fan-out definition outputs preferring task payloads, falling back
 * to the saved .defs.ts artifacts when the payload was cleared with cleaner="input_output".
 * Saved artifacts are reconstructed into PlannerOutput via config.normalizeResult; task payloads
 * override file copies (more recent within the same run). Results are deduped/sorted by getId.
 */
export async function getPlannerOutputsWithFileFallback(context, agentName, artifactType, config, getId, validate) {
    const byId = new Map();
    for (const data of await readSavedPlanArtifactDataList(context, artifactType)) {
        let output;
        try {
            output = {
                runId: 'from-file',
                stepId: config.stepId,
                schemaVersion: PLANNER_SCHEMA_VERSION_VALUE,
                status: 'ok',
                result: config.normalizeResult(data),
                questions: [],
                trace: [],
            };
            validate?.(output);
        }
        catch {
            continue;
        }
        byId.set(getId(output), output);
    }
    for (const output of getPlannerOutputs(context, agentName, config, validate)) {
        byId.set(getId(output), output);
    }
    return [...byId.values()].sort((a, b) => getId(a).localeCompare(getId(b)));
}
export function findStepByPlanId(context, planId) {
    if (!context.task)
        throw new Error('[findStepByPlanId] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.planning?.planId === planId) || null;
}
export function createDynamicAgentStepIntent(context, parentStep, agentName, planId, stepTitle, args, parentInsertStep) {
    const parentPlanning = parentStep.planning;
    const dependencyPlanId = parentPlanning?.dynamicSource?.sourcePlanId || parentPlanning?.planId || '';
    const insertParent = parentInsertStep || parentStep;
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: insertParent.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName,
            prompt: args,
            rags: [],
            planning: {
                planId,
                dependsOn: dependencyPlanId ? [dependencyPlanId] : [],
                executionMode: 'sequential',
                executionHost: 'client',
            },
        },
    };
}
export function createParallelDynamicAgentStepIntent(context, parentStep, agentName, planId, stepTitle, args, maxParallel = 5) {
    if (!context.task)
        throw new Error('[createParallelDynamicAgentStepIntent] task invalid');
    if (args.length === 0)
        throw new Error('[createParallelDynamicAgentStepIntent] args empty');
    const parentPlanning = parentStep.planning;
    const dependencyPlanId = parentPlanning?.dynamicSource?.sourcePlanId || parentPlanning?.planId || '';
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: {
                input: [{
                        type: 'system',
                        content: '<!-- modelType: codeinstruct -->',
                    }],
                cost: 0,
                trace: [`queued ${args.length} parallel dynamic args for ${agentName}`],
                payload: null,
            },
            stepTitle,
            status: 'in_progress',
            nextSteps: [],
            agentName,
            prompt: JSON.stringify({ planId }),
            rags: [],
            planning: {
                planId,
                dependsOn: dependencyPlanId ? [dependencyPlanId] : [],
                executionMode: 'parallel_dynamic',
                executionHost: 'client',
                dynamicSource: parentPlanning?.dynamicSource,
            },
        },
        executionMode: {
            type: 'parallel',
            args,
            maxParallel,
        },
    };
}
// TODO-FINAL-023 / TODO-FINAL-024: critic/repair checkpoint support for plan indices.
export const CRITIC_PLAN_INDEX_AGENT_NAME = 'agentCriticPlanIndex';
export const REPAIR_PLAN_INDEX_AGENT_NAME = 'agentRepairPlanIndex';
export const MAX_PLAN_INDEX_CRITIC_ATTEMPTS = 3; // initial critic + up to 2 repair/critic rounds
export function buildPlanIndexReviewArgs(indexName, attempt) {
    return JSON.stringify({ indexName, attempt });
}
export function parsePlanIndexReviewArgs(args) {
    const parsed = parseMaybeJson(args || '');
    if (!isRecordValue(parsed))
        throw new Error(`[parsePlanIndexReviewArgs] invalid args: ${args}`);
    const indexName = typeof parsed.indexName === 'string' ? parsed.indexName : '';
    const attempt = typeof parsed.attempt === 'number' && parsed.attempt > 0 ? parsed.attempt : 1;
    if (!indexName)
        throw new Error(`[parsePlanIndexReviewArgs] missing indexName in args: ${args}`);
    return { indexName, attempt };
}
export function repairPlanIndexToolName(indexName) {
    const safe = indexName.replace(/[^a-zA-Z0-9]/g, '');
    return `submitRepaired${safe.charAt(0).toUpperCase()}${safe.slice(1)}`;
}
/**
 * Creates the critic step as a direct child of the index step.
 * The index step must stay non-terminal (in_progress) while critic/repair children run,
 * so downstream steps that depend on the index planId remain locked until approval.
 */
export function createPlanIndexReviewStepIntent(context, indexStep, agentName, indexName, attempt, stepTitle) {
    const kind = agentName === REPAIR_PLAN_INDEX_AGENT_NAME ? 'repair' : 'critic';
    return createDynamicAgentStepIntent(context, indexStep, agentName, `plan-index-${kind}:${indexName}:${attempt}`, stepTitle, buildPlanIndexReviewArgs(indexName, attempt));
}
/** Intents returned by an index agent to hold the step open and start the critic checkpoint. */
export function createHoldIndexForReviewIntents(context, parentStep, indexStep, hookSequential, indexName) {
    return [
        createPlannerUpdateStatusIntent(context, parentStep, indexStep, hookSequential, 'in_progress', `index generated; waiting critic/repair checkpoint for ${indexName} (TODO-FINAL-023/024)`),
        createPlanIndexReviewStepIntent(context, indexStep, CRITIC_PLAN_INDEX_AGENT_NAME, indexName, 1, `Review ${indexName} (critic 1)`),
    ];
}
export function findParentStepOfStep(context, stepId) {
    if (!context.task)
        throw new Error('[findParentStepOfStep] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    for (const step of allSteps) {
        if (step.nextSteps?.some(child => child.stepId === stepId))
            return step;
        if (step.interaction?.payload?.some(child => child.stepId === stepId))
            return step;
    }
    return null;
}
export function findLatestPlanIndexReviewStep(context, agentName, indexName, onlyCompleted = true) {
    if (!context.task)
        throw new Error('[findLatestPlanIndexReviewStep] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    let latest = null;
    for (const step of allSteps) {
        if (step.type !== 'agent')
            continue;
        const agentStep = step;
        if (agentStep.agentName !== agentName)
            continue;
        if (onlyCompleted && agentStep.status !== 'completed')
            continue;
        try {
            const args = parsePlanIndexReviewArgs(agentStep.prompt);
            if (args.indexName !== indexName)
                continue;
        }
        catch {
            continue;
        }
        if (!latest || agentStep.stepId > latest.stepId)
            latest = agentStep;
    }
    return latest;
}
/**
 * TODO-FINAL-024: read a plan index output preferring the latest completed repaired version.
 * Falls back to the original index agent payload when no repair step exists.
 */
export function getPlannerOutputWithRepair(context, sourceAgentName, indexName, config, validate) {
    const repairStep = findLatestPlanIndexReviewStep(context, REPAIR_PLAN_INDEX_AGENT_NAME, indexName, true);
    const repairPayload = repairStep?.interaction?.payload?.[0];
    if (repairPayload) {
        const repairConfig = {
            ...config,
            toolName: repairPlanIndexToolName(indexName),
            stepId: `repair:${indexName}`,
            stepIdAliases: [config.stepId, ...(config.stepIdAliases || []), `repair:${indexName}`],
        };
        const output = extractPlannerOutput(repairPayload, repairConfig);
        validate?.(output);
        return output;
    }
    return getPlannerOutput(context, sourceAgentName, config, validate);
}
function isRecordValue(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
export function getPlanningContextSnapshot(context) {
    const clarificationAnswer = getRequirementsClarificationAnswer(context);
    return {
        initialPlan: getInitialNewSolutionPlanSummary(context),
        clarificationAnswer,
        discoveredScope: getDiscoverSolutionScopeOutput(context),
        recommendations: getRecommendImplementationsOutput(context),
        implementationDecisions: getImplementationDecisionResult(context),
        initialMetricsRequested: wantsInitialMetricsDashboard(clarificationAnswer),
    };
}
export function getInitialNewSolutionPlanSummary(context) {
    if (!context.task)
        throw new Error('[getInitialNewSolutionPlanSummary] task invalid');
    const agentStep = getAgentStepByAgentName(context.task, 'agentNewSolution');
    const payload = agentStep?.interaction?.payload?.[0];
    const result = payload?.type === 'flexible' ? payload.result : undefined;
    if (!result || typeof result !== 'object')
        throw new Error('[getInitialNewSolutionPlanSummary] initial plan not found');
    if (!result.userPrompt || typeof result.userPrompt !== 'string')
        throw new Error('[getInitialNewSolutionPlanSummary] user prompt not found');
    result.moduleName = normalizeModuleFolderName(result.moduleName, result.userPrompt);
    return result;
}
export function getImplementationDecisionResult(context) {
    if (!context.task)
        throw new Error('[getImplementationDecisionResult] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    const step = allSteps.find(item => item.type === 'result' &&
        item.planning?.planId === 'req-implementation-decisions' &&
        item.result);
    if (!step?.result)
        throw new Error('[getImplementationDecisionResult] implementation decisions not found');
    const parsed = parseMaybeJson(step.result);
    if (!parsed || !Array.isArray(parsed.decisions))
        throw new Error('[getImplementationDecisionResult] invalid implementation decisions');
    return parsed;
}
export function hasAcceptedArtifact(decisions, artifactType) {
    return decisions.decisions.some(item => item.artifactType === artifactType && item.accepted && item.decidedPriority !== 'never');
}
export function hasAcceptedNowArtifact(decisions, artifactType) {
    return decisions.decisions.some(item => item.artifactType === artifactType && item.accepted && item.decidedPriority === 'now');
}
