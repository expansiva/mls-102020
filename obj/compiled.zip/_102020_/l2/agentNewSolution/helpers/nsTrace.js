/// <mls fileReference="_102020_/l2/agentNewSolution/helpers/nsTrace.ts" enhancement="_blank"/>
import { nsTraceFileInfo, writeJsonArtifact } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { normalizeNsId } from '/_102020_/l2/agentNewSolution/helpers/nsIds.js';
export async function writeNsTrace(moduleName, stepId, agentName, attempt, payload, error) {
    const shortName = `${normalizeNsId(stepId)}-${normalizeNsId(agentName)}-${String(attempt).padStart(2, '0')}`;
    const record = {
        savedAt: new Date().toISOString(),
        stepId,
        agentName,
        attempt,
        payload,
        ...(error ? { error } : {}),
    };
    return writeJsonArtifact(nsTraceFileInfo(moduleName, shortName), record);
}
