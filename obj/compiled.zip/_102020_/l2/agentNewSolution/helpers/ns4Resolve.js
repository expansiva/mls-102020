/// <mls fileReference="_102020_/l2/agentNewSolution/helpers/ns4Resolve.ts" enhancement="_blank"/>
/**
 * The single NS4 semantic-resolution boundary. Type A remains unresolved,
 * Type B records the generator's existing choice, and Type C applies its
 * caller-supplied mechanical patch before recording the decision.
 */
export function resolveNs4Findings(artifact, findings) {
    let resolvedArtifact = artifact;
    const systemDecisions = [];
    const unresolved = [];
    findings.forEach(finding => {
        if (finding.classification === 'A') {
            unresolved.push(finding);
            return;
        }
        if (finding.classification === 'C')
            resolvedArtifact = finding.apply(resolvedArtifact);
        const chosen = finding.classification === 'B' ? finding.defaultChoice : finding.deterministicChoice;
        systemDecisions.push({
            decisionId: finding.decisionId || finding.findingRef,
            stage: finding.stage,
            question: finding.question,
            chosen,
            alternatives: unique([chosen, ...finding.alternatives]),
            decidedBy: 'system',
            findingRef: finding.findingRef,
            changeHint: finding.changeHint,
        });
    });
    return { artifact: resolvedArtifact, systemDecisions, unresolved };
}
function unique(values) {
    return [...new Set(values.map(value => value.trim()).filter(Boolean))];
}
