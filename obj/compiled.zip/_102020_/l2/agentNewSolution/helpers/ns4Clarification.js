/// <mls fileReference="_102020_/l2/agentNewSolution/helpers/ns4Clarification.ts" enhancement="_blank"/>
export function setNs4ClarificationFeedback(element, feedback) {
    const widget = element;
    if (typeof widget.setFeedback === 'function') {
        widget.setFeedback(feedback);
        return;
    }
    widget.msgError = feedback?.kind === 'error' ? feedback.message : '';
    widget.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
    widget.requestUpdate?.();
}
export function setNs4ClarificationSubmitting(element, submitting) {
    const widget = element;
    if (typeof widget.setSubmitting === 'function') {
        widget.setSubmitting(submitting);
        return;
    }
    if ('submitting' in widget)
        widget.submitting = submitting;
    widget.requestUpdate?.();
}
export function showNs4ClarificationError(element, error, issues) {
    const message = error instanceof Error ? error.message : String(error);
    setNs4ClarificationSubmitting(element, false);
    setNs4ClarificationFeedback(element, { kind: 'error', message, ...(issues?.length ? { issues } : {}) });
}
