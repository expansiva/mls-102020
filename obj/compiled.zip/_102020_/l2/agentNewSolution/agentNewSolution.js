/// <mls fileReference="_102020_/l2/agentNewSolution/agentNewSolution.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { isRecord, listExistingModuleFolders, nsPipelineArtifactFileInfo, parseMaybeJson, readJsonArtifact, } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { readNsPipeline } from '/_102020_/l2/agentNewSolution/helpers/nsPipeline.js';
import { parseNsFastMode, parseNsRebuildMode } from '/_102020_/l2/agentNewSolution/helpers/nsFastMode.js';
export const NS_PLAN_IDS = [
    'e1-clarification', 'e1-clarification-answer', 'e1-draft', 'checkpoint-draft', 'e2-journeys', 'checkpoint-journeys',
    'checkpoint-journeys-answer',
    'e3-ontology', 'e4-actors-rules-refs', 'e5-workflows-operations', 'e6-journey-map', 'e7-validation-summary',
];
export function createAgent() {
    return {
        agentName: 'agentNewSolution',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Spec-first step pipeline to create a module',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
        beforeClarificationStep,
    };
}
// Bump on every deploy so the console confirms the running build is the latest one.
export const NS_AGENT_BUILD = 'build-20 (2026-07-21) all $id are valid https:// URIs (Grok/xAI rejected the bare collab.codes/... uri-reference)';
async function beforePromptImplicit(agent, context, userPrompt) {
    console.log(`[ns-build] agentNewSolution ${NS_AGENT_BUILD}`);
    // /fast (D5): auto-accept the human clarifications. /rebuild (newSolution_18): clean the module's
    // l4+l5 before regenerating. Both flags ride longMemory; the tokens are stripped so the LLM sees a
    // clean prompt (same idea as agentChangeFrontend's cliCommand).
    const fastParsed = parseNsFastMode((userPrompt || '').trim());
    const rebuildParsed = parseNsRebuildMode(fastParsed.prompt);
    const normalized = rebuildParsed.prompt;
    const fastMemory = {
        ...(fastParsed.fast ? { fastMode: 'true' } : {}),
        ...(rebuildParsed.rebuild ? { rebuild: 'true' } : {}),
    };
    // Empty "@@newSolution" (the runtime strips the mention) means resume the first module whose
    // Phase 1 is incomplete, so the user does not repeat the clarification they already answered.
    if (!normalized) {
        const resume = await findResumableNsModule();
        if (resume)
            return [buildRootMessageAI(agent, context, resume.sourcePrompt, { ...fastMemory, resumeModule: resume.moduleName, resumeTarget: resume.target })];
    }
    return [buildRootMessageAI(agent, context, normalized || '(empty prompt)', fastMemory)];
}
function buildRootMessageAI(agent, context, content, extraMemory) {
    return {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt.replace('{{planIds}}', NS_PLAN_IDS.join(', ')) },
                { type: 'human', content },
            ],
            taskTitle: 'new Solution',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'newSolution', flowName: 'agentNewSolution', ...extraMemory },
        },
    };
}
export const NS_PHASE2_PLAN_IDS = [
    'e3-ontology', 'e4-actors-rules-refs', 'e5-workflows-operations', 'e6-journey-map', 'e7-validation-summary',
];
// Scan modules in the active project and return the first one whose Phase 1 artifacts are not done.
// A step counts as done when it was approved or its last gate passed (the human checkpoint that
// freezes it is layered on top and does not change which step must run next).
async function findResumableNsModule() {
    for (const moduleName of listExistingModuleFolders()) {
        const pipeline = await readNsPipeline(moduleName);
        if (!pipeline)
            continue;
        const target = resolveResumeTarget(pipeline);
        // Resume re-enters at E2, at the E2 human checkpoint, or at the next unapproved phase-2 step.
        // E1 needs the clarification that the fresh flow owns, so it is not rebuilt from resume.
        if (!target || target === 'e1-draft')
            continue;
        const draft = await readJsonArtifact(nsPipelineArtifactFileInfo(moduleName, 'e1-draft', '.json'), false);
        if (!draft)
            continue;
        return { moduleName, sourcePrompt: readString(draft.sourcePrompt) || moduleName, target };
    }
    return null;
}
function resolveResumeTarget(pipeline) {
    const e1 = pipeline.steps['e1-draft'];
    const e2 = pipeline.steps['e2-journeys'];
    const checkpoint = pipeline.steps['checkpoint-journeys'];
    if (!e1 || !(e1.status === 'approved' || e1.lastGate?.ok))
        return 'e1-draft';
    if (!e2 || !(e2.status === 'approved' || e2.lastGate?.ok))
        return 'e2-journeys';
    if (!checkpoint || checkpoint.status !== 'approved')
        return 'checkpoint-journeys';
    for (const planId of NS_PHASE2_PLAN_IDS) {
        const stepState = pipeline.steps[planId];
        if (!stepState || stepState.status !== 'approved' || stepState.dirty)
            return planId;
    }
    return null;
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const rootPlan = normalizeRootPlan(step.interaction?.payload?.[0]);
        const resumeModule = readString(context.task?.iaCompressed?.longMemory?.resumeModule);
        if (resumeModule) {
            const resumeTarget = normalizeResumeTarget(readString(context.task?.iaCompressed?.longMemory?.resumeTarget));
            return buildResumeTree(resumeModule, resumeTarget, rootPlan).map(resumeStep => ({
                type: 'add-step',
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: step.stepId,
                step: resumeStep,
            }));
        }
        const addSteps = buildPlannedTree(rootPlan, rootPlan.validPrompt).map(plannedStep => ({
            type: 'add-step',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: step.stepId,
            step: plannedStep,
        }));
        if (!rootPlan.validPrompt) {
            return [
                ...addSteps,
                updateStatus(context, parentStep, step, hookSequential, 'failed', rootPlan.invalidReason || 'Invalid or insufficient prompt.'),
            ];
        }
        return addSteps;
    }
    catch (error) {
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const parsed = parseStepJson(json);
    if (parsed.planId !== 'e1-clarification') {
        throw new Error(`[agentNewSolution] unsupported clarification ${parsed.planId || '(missing)'}`);
    }
    const rootPlan = getRootPlan(context);
    const clarification = rootPlan.clarification;
    await import('/_102025_/l2/widgetQuestionsForClarification.js');
    const el = document.createElement('widget-questions-for-clarification-102025');
    el.value = {
        taskId: context.task?.PK || '',
        stepId: step.stepId,
        title: clarification.title,
        legends: clarification.legends,
        userLanguage: clarification.userLanguage,
        questions: clarification.questions,
    };
    el.setAttribute('mode', 'new');
    el.addEventListener('clarification-finish', (event) => {
        const detail = event.detail;
        void applyInitialClarification(context, parentStep, step, hookSequential, detail.value, detail.action);
    });
    return el;
}
function buildPlannedTree(plan, includePhase2) {
    const title = (planId) => getTitle(plan, planId);
    // Only TWO human interactions (PropostaAgentNewSolution §8): (1) the opening clarification and
    // (2) the journeys checkpoint (E2). E1 (rascunho / understanding contract) runs AUTOMATICALLY -
    // its green gate auto-approves and the pipeline goes straight to E2 (e2-journeys dependsOn e1-draft).
    // There is no draft-approval checkpoint.
    const phase1 = [
        agentStep('e1-clarification', 'agentNsDraft', title('e1-clarification'), [], 'waiting_human_input'),
        agentStep('e1-draft', 'agentNsDraft', title('e1-draft'), ['e1-clarification-answer'], 'waiting_dependency'),
    ];
    if (!includePhase2)
        return phase1;
    return [
        ...phase1,
        agentStep('e2-journeys', 'agentNsJourneys', title('e2-journeys'), ['e1-draft'], 'waiting_dependency'),
        agentStep('checkpoint-journeys', 'agentNsJourneys', title('checkpoint-journeys'), ['e2-journeys'], 'waiting_dependency'),
        ...buildPhase2Steps(plan),
    ];
}
// Phase-2 steps depend on the previous step's 'eN-done' anchor result (NOT on the agent step planId):
// retries/adjustment runs have dynamic planIds and unlockWaitingDependencySteps only unlocks on a
// COMPLETED step per planId, so whichever run passes the gate emits the anchor and the chain moves on.
export function buildPhase2Steps(plan) {
    const title = (planId) => getTitle(plan, planId);
    return [
        agentStep('e3-ontology', 'agentNsOntology', title('e3-ontology'), ['checkpoint-journeys-answer'], 'waiting_dependency'),
        agentStep('e4-actors-rules-refs', 'agentNsActorsRules', title('e4-actors-rules-refs'), ['e3-done'], 'waiting_dependency'),
        agentStep('e5-workflows-operations', 'agentNsBehavior', title('e5-workflows-operations'), ['e4-done'], 'waiting_dependency'),
        agentStep('e6-journey-map', 'agentNsJourneyMap', title('e6-journey-map'), ['e5-done'], 'waiting_dependency'),
        agentStep('e7-validation-summary', 'agentNsValidation', title('e7-validation-summary'), ['e6-done'], 'waiting_dependency'),
    ];
}
// Single-call LLM steps (not the human clarifications, not the fan-out children) set
// onFailure='wait_after_prompt' so the agent's afterPromptStep runs even when the LLM CALL itself
// fails (no payload) — the step can then retry once instead of the framework killing the whole task
// (P2/newSolution_14: task3 died at e6 on one transient LLM failure with no retry). The fan-out
// children keep the default (their finalize repair round is the net).
const NS_LLM_CALL_STEPS = new Set(['e1-draft', 'e2-journeys', 'e3-ontology', 'e4-actors-rules-refs', 'e5-workflows-operations', 'e6-journey-map']);
function agentStep(planId, agentName, stepTitle, dependsOn, status) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        agentName,
        prompt: JSON.stringify({ planId }),
        rags: [],
        ...(NS_LLM_CALL_STEPS.has(planId) ? { onFailure: 'wait_after_prompt' } : {}),
        planning: { planId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
function clarificationStep(planId, stepTitle, dependsOn, json, status) {
    const jsonRecord = isRecord(json) ? json : {};
    return {
        type: 'clarification',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        json: JSON.stringify({ planId, ...jsonRecord }),
        planning: { planId, dependsOn, executionMode: 'sequential', executionHost: 'client' },
    };
}
// Resume tree: a single ready agent step. It must NOT be `waiting_dependency`:
// collab-messages only re-evaluates dependencies when some step COMPLETES (addTaskAISteps ->
// unlockWaitingDependencySteps), so a waiting_dependency step added on its own would stay parked with
// no hook. A single, non-waiting_dependency agent step gets its beforePromptStep enqueued immediately
// (addTaskAISteps, isIntentionsSteps branch). The agent resolves artifacts from disk, so no
// clarification/draft steps need to be rebuilt.
function buildResumeTree(moduleName, target = 'e2-journeys', plan) {
    // Phase-2 resume: rebuild the chain from the target step on. The FIRST step must NOT be
    // waiting_dependency (nothing completes in a fresh task to unlock it); the following steps keep
    // their eN-done anchor dependencies, which the preceding steps emit in this new task. Every step
    // carries moduleName so the agents skip the module scan.
    if (NS_PHASE2_PLAN_IDS.includes(target)) {
        const phase2 = plan ? buildPhase2Steps(plan) : buildPhase2Steps(normalizeRootPlanForResume());
        const startIndex = phase2.findIndex(step => step.planning?.planId === target);
        return phase2.slice(startIndex < 0 ? 0 : startIndex).map((step, index) => {
            const prompt = JSON.stringify({ planId: step.planning?.planId, moduleName });
            if (index === 0) {
                return { ...step, status: 'waiting_human_input', prompt, planning: { ...step.planning, dependsOn: [] } };
            }
            return { ...step, prompt };
        });
    }
    if (target === 'checkpoint-journeys') {
        return [
            {
                type: 'agent',
                stepId: 0,
                interaction: null,
                stepTitle: defaultTitles['checkpoint-journeys'],
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: 'agentNsJourneys',
                prompt: JSON.stringify({ planId: 'checkpoint-journeys', moduleName }),
                rags: [],
                planning: { planId: 'checkpoint-journeys', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
            },
        ];
    }
    return [
        {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: defaultTitles['e2-journeys'],
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: 'agentNsJourneys',
            prompt: JSON.stringify({ planId: 'e2-journeys', moduleName }),
            rags: [],
            planning: { planId: 'e2-journeys', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
        },
    ];
}
function normalizeResumeTarget(value) {
    if (value === 'checkpoint-journeys' || value === 'e1-draft' || value === 'e2-journeys')
        return value;
    if (value && NS_PHASE2_PLAN_IDS.includes(value))
        return value;
    return 'e2-journeys';
}
// Resume runs still execute the root LLM call, so localized titles normally come from it; this
// fallback only guards the path where the payload is unusable.
function normalizeRootPlanForResume() {
    return normalizeRootPlan({ userPrompt: '(resume)', validPrompt: true });
}
async function applyInitialClarification(context, parentStep, step, hookSequential, value, action) {
    if (!context.task)
        throw new Error('[agentNewSolution] task invalid');
    const status = action === 'continue' ? 'completed' : 'failed';
    const intents = [updateStatus(context, parentStep, step, hookSequential, status)];
    if (action === 'continue') {
        const answer = normalizeClarificationAnswer(value);
        intents.unshift(resultStep(context, parentStep, 'e1-clarification-answer', ['e1-clarification'], answer.title, answer));
    }
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200) {
        throw new Error(response?.msg || 'Error applying clarification');
    }
    const ret = response;
    context.task = ret.task;
    if (ret.message)
        context.message = ret.message;
    if (action === 'continue')
        await continuePoolingTask(context);
}
function resultStep(context, parentStep, planId, dependsOn, stepTitle, result) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify(result, null, 2),
            planning: { planId, dependsOn, executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
}
export function getRootPlan(context) {
    if (!context.task)
        throw new Error('[getRootPlan] task invalid');
    const root = getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.type === 'agent' && item.agentName === 'agentNewSolution');
    const payload = root?.interaction?.payload?.[0];
    return normalizeRootPlan(payload);
}
export function getInitialClarificationAnswer(context) {
    const step = findStepByPlanId(context, 'e1-clarification-answer');
    if (!step?.result)
        return null;
    const parsed = parseMaybeJson(step.result);
    return isRecord(parsed) ? parsed : null;
}
function findStepByPlanId(context, planId) {
    if (!context.task)
        return null;
    return getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.planning?.planId === planId) || null;
}
function normalizeRootPlan(payload) {
    const parsed = parseMaybeJson(payload);
    const result = isRecord(parsed) && parsed.type === 'flexible' ? parseMaybeJson(parsed.result) : parsed;
    const record = isRecord(result) ? result : {};
    const prompt = readString(record.userPrompt) || '';
    const userLanguage = readString(record.userLanguage) || 'en';
    const titles = isRecord(record.titles) ? record.titles : {};
    const uiLabels = isRecord(record.uiLabels) ? record.uiLabels : {};
    return {
        userLanguage,
        validPrompt: record.validPrompt !== false && prompt.trim().length >= 5,
        userPrompt: prompt,
        invalidReason: readString(record.invalidReason),
        titles,
        uiLabels,
        clarification: normalizeClarification(record.clarification, userLanguage, titles['e1-clarification'], prompt),
    };
}
function normalizeClarification(value, userLanguage, title, userPrompt = '') {
    const record = isRecord(value) ? value : {};
    const fallbackQuestions = defaultQuestions(userLanguage, userPrompt);
    const rawQuestions = isRecord(record.questions) ? record.questions : fallbackQuestions;
    const questions = normalizeClarificationQuestions(rawQuestions, fallbackQuestions);
    return {
        userLanguage: readString(record.userLanguage) || userLanguage,
        title: readString(record.title) || title || 'Clarification 1',
        legends: Array.isArray(record.legends) ? record.legends.filter((item) => typeof item === 'string') : [],
        questions,
    };
}
function normalizeClarificationQuestions(rawQuestions, fallbackQuestions) {
    const normalized = {};
    for (const [key, fallback] of Object.entries(fallbackQuestions)) {
        const question = rawQuestions[key] || fallback;
        const text = readString(question.question) || fallback.question;
        const answer = question.answer === undefined || question.answer === '' ? fallback.answer : question.answer;
        normalized[key] = {
            ...question,
            type: question.type || fallback.type,
            question: text,
            answer,
            ...(question.options || fallback.options ? { options: question.options || fallback.options } : {}),
        };
    }
    for (const [key, question] of Object.entries(rawQuestions)) {
        if (normalized[key])
            continue;
        const text = readString(question.question) || key;
        normalized[key] = {
            ...question,
            type: question.type || 'open',
            question: text,
            answer: question.answer === undefined ? '' : question.answer,
        };
    }
    return normalized;
}
function normalizeClarificationAnswer(value) {
    return {
        title: value.title || 'Clarification 1',
        userLanguage: value.userLanguage || '',
        answers: Object.fromEntries(Object.entries(value.questions || {}).map(([key, question]) => [key, question.answer ?? ''])),
    };
}
function defaultQuestions(userLanguage, userPrompt = '') {
    const defaults = deriveClarificationDefaults(userPrompt, userLanguage);
    return {
        moduleName: { type: 'open', question: 'What short module name do you want?', answer: defaults.moduleName },
        mainActors: { type: 'open', question: 'Who uses this module day to day?', answer: defaults.mainActors },
        mainGoal: { type: 'open', question: 'What main outcome should this module deliver?', answer: defaults.mainGoal },
        boundaries: { type: 'open', question: 'What should stay out of this module for now?', answer: defaults.boundaries },
    };
}
function deriveClarificationDefaults(userPrompt, userLanguage) {
    const prompt = userPrompt.replace(/\s+/g, ' ').trim();
    const portuguese = prefersPortuguese(prompt, userLanguage);
    const moduleName = extractFirstMatch(prompt, [
        /(?:chamado|chamada|called|named)\s+["']?([A-Za-z][\w-]{1,48})/i,
        /(?:app|module|modulo|módulo|solucao|solução)\s+([A-Za-z][\w-]{1,48})/i,
    ]) || 'module';
    const mainGoal = extractSection(prompt, ['Foco:', 'Focus:', 'Objetivo:', 'Goal:']) || truncateText(prompt, 220);
    const mainActors = extractSection(prompt, ['Atores:', 'Actors:', 'Usuários:', 'Usuarios:', 'Users:'])
        || inferActorsFromPrompt(prompt, portuguese);
    const boundaries = extractSection(prompt, ['Fora de escopo:', 'Out of scope:', 'Limites:', 'Boundaries:'])
        || (portuguese
            ? 'Usar apenas o escopo de negócio descrito no prompt; adiar detalhes de implementação, banco de dados e layout para etapas posteriores.'
            : 'Use only the business scope described in the prompt; defer implementation details, database design, and page layout until later steps.');
    return { moduleName, mainActors, mainGoal, boundaries };
}
function inferActorsFromPrompt(prompt, portuguese) {
    const lower = prompt.toLowerCase();
    if (lower.includes('cafe') || lower.includes('café') || lower.includes('cafeteria') || lower.includes('lanchonete')) {
        return portuguese ? 'Atendente/operador de POS, equipe de cozinha e gestor da loja.' : 'Attendant/POS operator, kitchen staff, and store manager.';
    }
    return portuguese ? 'Principais usuários de negócio descritos no prompt.' : 'Primary business users described by the prompt.';
}
function prefersPortuguese(prompt, userLanguage) {
    const text = `${userLanguage} ${prompt}`.toLowerCase();
    return text.includes('pt-br') || text.includes('portugu') || text.includes('módulo') || text.includes('solução');
}
function extractFirstMatch(text, patterns) {
    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1])
            return match[1].trim();
    }
    return undefined;
}
function extractSection(text, labels) {
    for (const label of labels) {
        const index = text.toLowerCase().indexOf(label.toLowerCase());
        if (index < 0)
            continue;
        const after = text.slice(index + label.length).trim();
        const stop = after.search(/\s(?:Entidades principais|Telas chave|Funcionalidade LLM|Foco|Entities|Screens|Key screens|LLM feature|Focus|linguagem|language):/i);
        return truncateText((stop >= 0 ? after.slice(0, stop) : after).trim(), 240);
    }
    return undefined;
}
function truncateText(text, maxLength) {
    const clean = text.trim();
    if (clean.length <= maxLength)
        return clean;
    return `${clean.slice(0, maxLength - 1).trim()}...`;
}
function getTitle(plan, planId) {
    const custom = plan.titles?.[planId];
    if (typeof custom === 'string' && custom.trim().length > 0 && custom.trim().length < 140)
        return custom.trim();
    return defaultTitles[planId];
}
function parseStepJson(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
const defaultTitles = {
    'e1-clarification': 'Clarify the initial request',
    'e1-clarification-answer': 'Initial clarification answer',
    'e1-draft': 'Draft understanding',
    'checkpoint-draft': 'Approve draft', 'e2-journeys': 'Map journeys and features',
    'checkpoint-journeys': 'Approve journeys',
    'checkpoint-journeys-answer': 'Journeys approval answer',
    'e3-ontology': 'Plan ontology',
    'e4-actors-rules-refs': 'Plan actors, rules and references',
    'e5-workflows-operations': 'Plan workflows and operations',
    'e6-journey-map': 'Consolidate journey map', 'e7-validation-summary': 'Validate and summarize',
};
const systemPrompt = `
<!-- modelType: classifier -->

Initialize collab.codes agentNewSolution. Validate whether the prompt asks for a business module or
solution. Use the user's language for visible titles and clarification questions.

Return JSON only: { "type": "flexible", "result": { "userLanguage": "pt-BR|en|...", "validPrompt":
true, "invalidReason": "", "userPrompt": "...", "titles": { "plan id": "localized title" },
"uiLabels": { "draftTitle": "", "approve": "", "adjust": "", "adjustmentPlaceholder": "",
"approving": "", "adjusting": "", "approved": "", "loading": "", "noDraft": "", "gateOk": "",
"gateFailed": "", "adjustDraftStepTitle": "", "blockingClarificationTitle": "" },
"clarification": { "userLanguage": "...", "title": "Clarification 1", "legends": ["..."],
"questions": { "moduleName": { "type": "open", "question": "", "answer": "" }, "mainActors":
{ "type": "open", "question": "", "answer": "" }, "mainGoal": { "type": "open", "question": "",
"answer": "" }, "boundaries": { "type": "open", "question": "", "answer": "" } } } } }

Rules: invalid/vague prompts set validPrompt=false and invalidReason, but still produce clarification.
Include titles for these plan ids and UI labels in the user's language. Do not invent dependencies or
phase-2 executable agents. Do not ask architecture, ontology, page, database or workflow questions in
clarification 1. Every clarification question must include a visible, useful default answer derived
from the user's prompt; use an empty answer only when the prompt provides no safe default.

{{planIds}}
`;
