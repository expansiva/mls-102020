var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102020_/l2/agentNewSolution/widgetNsDraft.ts" enhancement="_102027_/l2/enhancementLit"/>
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { nsPipelineArtifactFileInfo, readJsonArtifact, readStorText, } from '/_102020_/l2/agentNewSolution/helpers/nsFs.js';
import { approveNsStep, createNsPipeline, readNsPipeline, writeNsPipeline, } from '/_102020_/l2/agentNewSolution/helpers/nsPipeline.js';
const message_en = {
    title: 'Understanding draft',
    approve: 'Approve',
    adjust: 'Adjust',
    adjustmentPlaceholder: 'Describe the smallest change needed in this draft.',
    approving: 'Approving...',
    adjusting: 'Requesting adjustment...',
    approved: 'Approved. The next step can run.',
    loading: 'Loading...',
    noDraft: 'No E1 draft artifact found.',
    gateOk: 'Gate passed',
    gateFailed: 'Gate failed',
    adjustDraftStepTitle: 'Adjust draft',
};
let WidgetNsDraft102020 = class WidgetNsDraft102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns-draft-102020 {
  display: block;
  color: #1f2933;
}
widget-ns-draft-102020 .ns-draft {
  display: flex;
  flex-direction: column;
  gap: 14px;
  max-width: 980px;
}
widget-ns-draft-102020 .ns-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  border-bottom: 1px solid #d9e2ec;
  padding-bottom: 10px;
}
widget-ns-draft-102020 h3 {
  margin: 0;
  font-size: 18px;
  line-height: 1.25;
}
widget-ns-draft-102020 p {
  margin: 4px 0 0;
  color: #52606d;
}
widget-ns-draft-102020 p span {
  font-family: monospace;
  color: #334e68;
}
widget-ns-draft-102020 .ns-gate {
  border-radius: 6px;
  font-size: 12px;
  padding: 4px 8px;
  white-space: nowrap;
}
widget-ns-draft-102020 .ns-gate--ok {
  background: #e3f9e5;
  color: #0f5132;
}
widget-ns-draft-102020 .ns-gate--bad,
widget-ns-draft-102020 .ns-error {
  background: #ffe3e3;
  color: #9b1c1c;
}
widget-ns-draft-102020 .ns-md {
  background: #f8fafc;
  border: 1px solid #d9e2ec;
  border-radius: 8px;
  color: #243b53;
  font-family: inherit;
  line-height: 1.45;
  margin: 0;
  overflow: auto;
  padding: 14px;
  white-space: pre-wrap;
}
widget-ns-draft-102020 .ns-actions {
  display: grid;
  gap: 10px;
}
widget-ns-draft-102020 textarea {
  border: 1px solid #bcccdc;
  border-radius: 8px;
  font: inherit;
  min-height: 78px;
  padding: 10px;
  resize: vertical;
}
widget-ns-draft-102020 .ns-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
}
widget-ns-draft-102020 button {
  border: 1px solid #9fb3c8;
  border-radius: 8px;
  cursor: pointer;
  font: inherit;
  padding: 8px 14px;
}
widget-ns-draft-102020 button:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}
widget-ns-draft-102020 .ns-primary {
  background: #186faf;
  border-color: #186faf;
  color: white;
}
widget-ns-draft-102020 .ns-secondary {
  background: white;
  color: #243b53;
}
widget-ns-draft-102020 .ns-state,
widget-ns-draft-102020 .ns-done {
  border-radius: 8px;
  padding: 12px;
}
widget-ns-draft-102020 .ns-done {
  background: #e3f9e5;
  color: #0f5132;
}
`);
        this.value = null;
        this._loading = true;
        this._artifact = null;
        this._markdown = '';
        this._pipeline = null;
        this._adjustment = '';
        this._busy = null;
        this._done = false;
        this._error = '';
        this._loadedFor = '';
    }
    async connectedCallback() {
        super.connectedCallback();
        await this._load();
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('value') && this.value && this.value.moduleName !== this._loadedFor)
            void this._load();
    }
    get _msg() {
        return { ...message_en, ...(this.value?.uiLabels || {}) };
    }
    async _load() {
        if (!this.value?.moduleName)
            return;
        this._loadedFor = this.value.moduleName;
        this._loading = true;
        this._error = '';
        try {
            this._artifact = await readJsonArtifact(nsPipelineArtifactFileInfo(this.value.moduleName, 'e1-draft', '.json'), false);
            this._markdown = await readStorText(nsPipelineArtifactFileInfo(this.value.moduleName, 'e1-draft', '.md'), false);
            this._pipeline = await readNsPipeline(this.value.moduleName);
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._loading = false;
        }
    }
    render() {
        const m = this._msg;
        if (this._loading)
            return html `<div class="ns-draft"><div class="ns-state">${m.loading}</div></div>`;
        if (this._error)
            return html `<div class="ns-draft"><div class="ns-state ns-error">${this._error}</div></div>`;
        if (!this._artifact)
            return html `<div class="ns-draft"><div class="ns-state">${m.noDraft}</div></div>`;
        return html `
      <section class="ns-draft">
        <header class="ns-head">
          <div>
            <h3>${m.title}</h3>
            <p>${this._artifact.moduleTitle} <span>${this._artifact.moduleName}</span></p>
          </div>
          ${this._renderGate()}
        </header>
        <pre class="ns-md">${this._markdown}</pre>
        ${this._done ? html `<div class="ns-done">${m.approved}</div>` : this._renderActions()}
      </section>
    `;
    }
    _renderGate() {
        const m = this._msg;
        const gate = this._pipeline?.steps['e1-draft']?.lastGate;
        if (!gate)
            return html ``;
        return html `<span class="ns-gate ${gate.ok ? 'ns-gate--ok' : 'ns-gate--bad'}">${gate.ok ? m.gateOk : m.gateFailed}</span>`;
    }
    _renderActions() {
        const m = this._msg;
        return html `
      <div class="ns-actions">
        <textarea
          .value=${this._adjustment}
          placeholder=${m.adjustmentPlaceholder}
          @input=${(event) => { this._adjustment = event.target.value; }}
          ?disabled=${!!this._busy}
        ></textarea>
        <div class="ns-buttons">
          <button class="ns-secondary" ?disabled=${!!this._busy || !this._adjustment.trim()} @click=${() => this._onAdjust()}>
            ${this._busy === 'adjust' ? m.adjusting : m.adjust}
          </button>
          <button class="ns-primary" ?disabled=${!!this._busy} @click=${() => this._onApprove()}>
            ${this._busy === 'approve' ? m.approving : m.approve}
          </button>
        </div>
      </div>
    `;
    }
    async _onApprove() {
        if (!this.value || !this._artifact || this._busy)
            return;
        this._busy = 'approve';
        this._error = '';
        try {
            const pipeline = approveNsStep(this._pipeline || await readNsPipeline(this._artifact.moduleName) || this._newPipelineFallback(), 'e1-draft', 'human');
            await writeNsPipeline(pipeline);
            this._pipeline = pipeline;
            // Write the answer result (completes checkpoint-draft via children + unlocks e2-journeys),
            // then complete the review clarification. Order matters: the result is added while the parent
            // agent is still open.
            await this._applyIntents([this._checkpointAnswerStep(), this._checkpointStatus('completed', 'checkpoint-draft approved')]);
            this._done = true;
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._busy = null;
        }
    }
    async _onAdjust() {
        if (!this.value || !this._artifact || this._busy || !this._adjustment.trim())
            return;
        this._busy = 'adjust';
        this._error = '';
        try {
            const addStep = {
                type: 'add-step',
                messageId: this.value.messageId,
                threadId: this.value.threadId,
                taskId: this.value.taskId,
                parentStepId: this.value.rerunParentStepId,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    stepTitle: this._msg.adjustDraftStepTitle,
                    status: 'waiting_human_input',
                    nextSteps: [],
                    agentName: 'agentNsDraft',
                    prompt: JSON.stringify({ planId: 'e1-draft', adjustment: this._adjustment.trim(), previousModuleName: this._artifact.moduleName }),
                    rags: [],
                    planning: { planId: `e1-draft-adjustment-${Date.now()}`, dependsOn: ['checkpoint-draft'], executionMode: 'sequential', executionHost: 'client' },
                },
            };
            await this._applyIntents([addStep, this._checkpointStatus('completed', 'checkpoint-draft adjustment requested')]);
            this._done = true;
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._busy = null;
        }
    }
    _checkpointAnswerStep() {
        const v = this.value;
        return {
            type: 'add-step',
            messageId: v.messageId,
            threadId: v.threadId,
            taskId: v.taskId,
            parentStepId: v.parentStepId,
            step: {
                type: 'result',
                stepId: 0,
                interaction: null,
                stepTitle: 'Draft approved',
                status: 'completed',
                nextSteps: [],
                result: JSON.stringify({ planId: 'checkpoint-draft-answer', moduleName: this._artifact?.moduleName ?? v.moduleName, approved: true }),
                planning: { planId: 'checkpoint-draft-answer', dependsOn: ['checkpoint-draft'], executionMode: 'manual_later', executionHost: 'client' },
            },
        };
    }
    _checkpointStatus(status, traceMsg) {
        const v = this.value;
        return {
            type: 'update-status',
            hookSequential: v.hookSequential,
            messageId: v.messageId,
            threadId: v.threadId,
            taskId: v.taskId,
            parentStepId: v.parentStepId,
            stepId: v.stepId,
            status,
            traceMsg,
            cleaner: 'input_output',
        };
    }
    async _applyIntents(intents) {
        const response = await msgApplyIntents({ userId: this.value.senderId, intents });
        if (!response || response.statusCode !== 200) {
            throw new Error(response?.msg || 'Error applying checkpoint action');
        }
        const ret = response;
        if (!ret.message)
            throw new Error('No message returned after checkpoint action');
        const context = { task: ret.task, message: ret.message, isTest: ret.task?.iaCompressed?.isTest || false };
        await continuePoolingTask(context);
    }
    _newPipelineFallback() {
        return createNsPipeline(this._artifact?.moduleName || 'module');
    }
};
__decorate([
    property({ type: Object })
], WidgetNsDraft102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_loading", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_artifact", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_markdown", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_pipeline", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_adjustment", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_busy", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_done", void 0);
__decorate([
    state()
], WidgetNsDraft102020.prototype, "_error", void 0);
WidgetNsDraft102020 = __decorate([
    customElement('widget-ns-draft-102020')
], WidgetNsDraft102020);
export { WidgetNsDraft102020 };
