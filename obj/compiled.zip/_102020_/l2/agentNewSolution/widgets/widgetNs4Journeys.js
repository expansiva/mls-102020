/// <mls fileReference="_102020_/l2/agentNewSolution/widgets/widgetNs4Journeys.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Journeys102020 = class WidgetNs4Journeys102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-journeys-102020 {
  display: block;
  color: #18212f;
}
widget-ns4-journeys-102020 * {
  box-sizing: border-box;
}
widget-ns4-journeys-102020 h2,
widget-ns4-journeys-102020 h3,
widget-ns4-journeys-102020 h4,
widget-ns4-journeys-102020 p,
widget-ns4-journeys-102020 dl,
widget-ns4-journeys-102020 dd {
  margin: 0;
}
widget-ns4-journeys-102020 h2 {
  font-size: 24px;
  line-height: 1.2;
}
widget-ns4-journeys-102020 h3 {
  font-size: 20px;
  line-height: 1.25;
  margin-top: 4px;
}
widget-ns4-journeys-102020 h4 {
  font-size: 14px;
}
widget-ns4-journeys-102020 p {
  color: #52606d;
  line-height: 1.45;
}
widget-ns4-journeys-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 12px;
}
widget-ns4-journeys-102020 ul {
  margin: 8px 0 0;
  padding-left: 20px;
}
widget-ns4-journeys-102020 li {
  line-height: 1.45;
  margin: 5px 0;
}
widget-ns4-journeys-102020 button,
widget-ns4-journeys-102020 textarea,
widget-ns4-journeys-102020 select {
  font: inherit;
}
widget-ns4-journeys-102020 button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
}
widget-ns4-journeys-102020 button:disabled {
  cursor: not-allowed;
  opacity: 0.56;
}
widget-ns4-journeys-102020 button:focus-visible,
widget-ns4-journeys-102020 textarea:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-journeys-102020 .ns4-journeys {
  display: grid;
  gap: 16px;
  min-width: 0;
}
widget-ns4-journeys-102020 .ns4-header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-journeys-102020 .ns4-breadcrumb {
  color: #4f46e5;
  font-size: 12px;
  font-weight: 650;
  margin-bottom: 5px;
}
widget-ns4-journeys-102020 .ns4-header p {
  margin-top: 6px;
}
widget-ns4-journeys-102020 .ns4-header-meta {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 148px;
}
widget-ns4-journeys-102020 .ns4-header-meta span,
widget-ns4-journeys-102020 .ns4-header-meta strong,
widget-ns4-journeys-102020 .ns4-pill {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 5px 9px;
}
widget-ns4-journeys-102020 .ns4-header-meta strong {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-journeys-102020 .ns4-feedback {
  border: 1px solid;
  border-radius: 8px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-journeys-102020 .ns4-feedback strong {
  font-size: 13px;
}
widget-ns4-journeys-102020 .ns4-feedback span,
widget-ns4-journeys-102020 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-journeys-102020 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-journeys-102020 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-journeys-102020 .ns4-system-decisions {
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
}
widget-ns4-journeys-102020 .ns4-system-decisions > summary {
  cursor: pointer;
  font-weight: 700;
  padding: 12px 14px;
}
widget-ns4-journeys-102020 .ns4-system-decisions > div {
  border-top: 1px solid #e2e8f0;
  display: grid;
  gap: 8px;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-system-decisions article {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 7px;
  display: grid;
  gap: 5px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 .ns4-system-decisions small {
  color: #64748b;
}
widget-ns4-journeys-102020 .ns4-filters {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
widget-ns4-journeys-102020 .ns4-filters > summary {
  align-items: center;
  cursor: pointer;
  display: flex;
  font-weight: 700;
  justify-content: space-between;
  list-style: none;
  padding: 12px 14px;
}
widget-ns4-journeys-102020 .ns4-filters > summary::-webkit-details-marker {
  display: none;
}
widget-ns4-journeys-102020 .ns4-filters > summary::after {
  color: #64748b;
  content: '⌄';
  font-size: 16px;
}
widget-ns4-journeys-102020 .ns4-filters[open] > summary {
  border-bottom: 1px solid #e2e8f0;
}
widget-ns4-journeys-102020 .ns4-filters[open] > summary::after {
  transform: rotate(180deg);
}
widget-ns4-journeys-102020 .ns4-filter-content {
  display: grid;
  gap: 12px;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-actor-filter {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
widget-ns4-journeys-102020 .ns4-actor-filter button,
widget-ns4-journeys-102020 .ns4-tabs button {
  background: #fff;
  color: #334155;
  padding: 8px 10px;
}
widget-ns4-journeys-102020 .ns4-actor-filter button {
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-actor-filter button.is-active,
widget-ns4-journeys-102020 .ns4-tabs button.is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-journeys-102020 .ns4-actor-map,
widget-ns4-journeys-102020 .ns4-list,
widget-ns4-journeys-102020 .ns4-detail,
widget-ns4-journeys-102020 .ns4-review {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
widget-ns4-journeys-102020 .ns4-section-title {
  align-items: center;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  padding: 12px 14px;
}
widget-ns4-journeys-102020 .ns4-section-title span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-journeys-102020 .ns4-lanes {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-lane {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 8px;
  min-width: 0;
  padding: 10px;
}
widget-ns4-journeys-102020 .ns4-lane.is-filtered {
  border-color: #6366f1;
  box-shadow: 0 0 0 1px #6366f1 inset;
}
widget-ns4-journeys-102020 .ns4-lane-head {
  align-items: center;
  background: #f8fafc;
  display: grid;
  gap: 8px;
  grid-template-columns: minmax(0, 1fr) auto;
  padding: 8px 10px;
  text-align: left;
}
widget-ns4-journeys-102020 .ns4-lane-head span {
  min-width: 0;
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-lane-items {
  display: grid;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-lane-items button {
  background: #fff;
  overflow: hidden;
  padding: 7px 8px;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}
widget-ns4-journeys-102020 .ns4-lane-items button.is-selected {
  border-color: #4338ca;
  color: #3730a3;
}
widget-ns4-journeys-102020 .ns4-main {
  align-items: stretch;
  display: grid;
  gap: 16px;
  grid-template-columns: minmax(360px, 440px) minmax(0, 1fr);
  height: min(72vh, 760px);
  min-height: 440px;
}
widget-ns4-journeys-102020 .ns4-list {
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  min-height: 0;
  min-width: 0;
  overflow: hidden;
}
widget-ns4-journeys-102020 .ns4-list-items {
  display: grid;
  gap: 8px;
  min-width: 0;
  overflow-y: auto;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-journey-card {
  background: #fff;
  display: grid;
  gap: 7px;
  max-width: 100%;
  min-width: 0;
  padding: 14px;
  text-align: left;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-journey-card:hover {
  border-color: #a5b4fc;
}
widget-ns4-journeys-102020 .ns4-journey-card.is-selected {
  background: #f5f3ff;
  border-color: #7c3aed;
}
widget-ns4-journeys-102020 .ns4-journey-card span {
  color: #475569;
  font-size: 12px;
}
widget-ns4-journeys-102020 .ns4-journey-card strong,
widget-ns4-journeys-102020 .ns4-journey-card span,
widget-ns4-journeys-102020 .ns4-journey-card code {
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-journey-card small {
  color: #64748b;
  display: grid;
  gap: 2px;
  line-height: 1.35;
  overflow-wrap: anywhere;
}
widget-ns4-journeys-102020 .ns4-journey-card small em {
  color: #475569;
  font-size: 11px;
  font-style: normal;
  font-weight: 700;
  text-transform: uppercase;
}
widget-ns4-journeys-102020 .ns4-detail {
  align-content: start;
  display: grid;
  gap: 16px;
  min-height: 0;
  overflow-y: auto;
  padding: 16px;
}
widget-ns4-journeys-102020 .ns4-detail-head {
  align-items: flex-start;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-journeys-102020 .ns4-policy-decisions {
  display: grid;
  gap: 12px;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-policy-selector {
  display: grid;
  gap: 5px;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-policy-selector > span {
  color: #475569;
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-journeys-102020 .ns4-policy-selector select {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  color: #1f2937;
  min-width: 0;
  padding: 9px 10px;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-policy-impact {
  align-items: start;
  background: #fffbeb;
  border: 1px solid #fbbf24;
  border-radius: 7px;
  color: #92400e;
  display: grid;
  font-size: 12px;
  gap: 8px;
  grid-template-columns: auto minmax(0, 1fr);
  line-height: 1.4;
  padding: 8px 10px;
}
widget-ns4-journeys-102020 .ns4-policy-impact > span:first-child {
  color: #b45309;
  font-size: 15px;
  line-height: 1;
}
widget-ns4-journeys-102020 .ns4-policy-impact > span:last-child {
  display: grid;
  gap: 2px;
}
widget-ns4-journeys-102020 .ns4-policy-impact strong {
  font-size: 11px;
  text-transform: uppercase;
}
widget-ns4-journeys-102020 .ns4-no-policy {
  color: #64748b;
  font-size: 13px;
}
widget-ns4-journeys-102020 .ns4-summary,
widget-ns4-journeys-102020 .ns4-context-grid {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-journeys-102020 .ns4-summary > div,
widget-ns4-journeys-102020 .ns4-context-grid > section,
widget-ns4-journeys-102020 .ns4-two-columns > div {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 dt {
  color: #64748b;
  font-size: 12px;
  margin-bottom: 4px;
}
widget-ns4-journeys-102020 dd {
  color: #1f2937;
  line-height: 1.4;
}
widget-ns4-journeys-102020 .ns4-tabs {
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-tabs button {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom-width: 0;
}
widget-ns4-journeys-102020 .ns4-steps-section {
  display: grid;
  gap: 10px;
}
widget-ns4-journeys-102020 .ns4-steps {
  display: grid;
  gap: 10px;
  list-style: none;
  margin: 0;
  padding: 0;
}
widget-ns4-journeys-102020 .ns4-steps li {
  align-items: start;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 12px;
  grid-template-columns: auto 1fr;
  margin: 0;
  padding: 12px;
}
widget-ns4-journeys-102020 .ns4-step-index {
  align-items: center;
  background: #4338ca;
  border-radius: 999px;
  color: #fff;
  display: inline-flex;
  font-size: 13px;
  height: 28px;
  justify-content: center;
  width: 28px;
}
widget-ns4-journeys-102020 .ns4-step-title {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
widget-ns4-journeys-102020 .ns4-step-title > span {
  color: #4338ca;
  font-size: 11px;
  text-transform: uppercase;
}
widget-ns4-journeys-102020 .ns4-steps p,
widget-ns4-journeys-102020 .ns4-steps small {
  color: #52606d;
  display: block;
  margin-top: 5px;
}
widget-ns4-journeys-102020 .ns4-rules {
  display: grid;
  gap: 12px;
}
widget-ns4-journeys-102020 .ns4-rules > p {
  font-size: 13px;
}
widget-ns4-journeys-102020 .ns4-rules > ol {
  display: grid;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}
widget-ns4-journeys-102020 .ns4-rules > ol li {
  align-items: start;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  display: grid;
  gap: 10px;
  grid-template-columns: auto 1fr;
  margin: 0;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 .ns4-outcome {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 12px;
}
widget-ns4-journeys-102020 .ns4-outcome p {
  margin-top: 6px;
}
widget-ns4-journeys-102020 .ns4-review {
  display: grid;
  gap: 12px;
  padding: 14px;
}
widget-ns4-journeys-102020 .ns4-review label,
widget-ns4-journeys-102020 .ns4-review label span {
  display: grid;
  gap: 6px;
}
widget-ns4-journeys-102020 .ns4-review label > span {
  color: #64748b;
  font-size: 12px;
}
widget-ns4-journeys-102020 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  min-height: 100px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-review > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-journeys-102020 button {
  padding: 9px 14px;
}
widget-ns4-journeys-102020 button.secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-journeys-102020 button.secondary.is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-journeys-102020 button.primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-journeys-102020 button.cancel {
  background: #fff;
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-journeys-102020 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-journeys-102020 .ns4-cancel-dialog {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-journeys-102020 .ns4-cancel-dialog p {
  color: #475569;
}
widget-ns4-journeys-102020 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-journeys-102020 .ns4-cancel-dialog button {
  background: #fff;
  padding: 9px 12px;
}
widget-ns4-journeys-102020 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 760px) {
  widget-ns4-journeys-102020 .ns4-main,
  widget-ns4-journeys-102020 .ns4-summary,
  widget-ns4-journeys-102020 .ns4-context-grid {
    grid-template-columns: 1fr;
  }
  widget-ns4-journeys-102020 .ns4-main {
    height: auto;
    min-height: 0;
  }
  widget-ns4-journeys-102020 .ns4-list {
    max-height: none;
  }
  widget-ns4-journeys-102020 .ns4-list-items {
    overflow: visible;
  }
  widget-ns4-journeys-102020 .ns4-detail {
    overflow: visible;
  }
  widget-ns4-journeys-102020 .ns4-header {
    display: grid;
  }
  widget-ns4-journeys-102020 .ns4-header-meta {
    align-items: flex-start;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedActorRef = 'all';
        this.selectedJourneyId = '';
        this.activeTab = 'steps';
        this.selectedPolicyOptions = {};
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    labels() {
        const pt = this.value?.userLanguage?.toLowerCase().startsWith('pt');
        return pt ? {
            subtitle: 'Estas jornadas serão a fonte de verdade permanente do produto.',
            actor: 'Ator', goal: 'Objetivo', steps: 'Passos',
            rules: 'Regras', outcome: 'Resultado e evidências', filters: 'Filtros', impact: 'Impacto', noPolicyDecision: 'Nenhuma decisão de política foi informada para esta jornada.',
            journeys: 'Jornadas', journeysFound: 'jornadas encontradas', selectJourney: 'Selecione uma jornada para revisar.',
            allActors: 'Todos os atores', actorMap: 'Mapa de jornadas por ator', actors: 'atores', overview: 'Visão geral', actual: '(atual)',
            rulesHelp: 'Regras que devem continuar verdadeiras em toda execução desta jornada.',
            adjustment: 'O que deve mudar?', placeholder: 'Descreva a alteração necessária sem reescrever o que já está correto.',
            requestChanges: 'Pedir mudanças', approve: 'Aprovar jornadas', round: 'Revisão', step: 'Etapa', of: 'de',
            adjustmentRequired: 'Escreva o que precisa mudar antes de solicitar uma nova versão.',
            processingApproval: 'Validando jornadas…', processingChanges: 'Preparando nova revisão…', processingCancel: 'Cancelando execução…',
            revise: 'Revise os itens abaixo', cancel: 'Cancelar execução', cancelTitle: 'Cancelar esta execução?',
            cancelText: 'O processamento será encerrado. O histórico e os artefatos já aprovados serão preservados.', keepWorking: 'Continuar trabalhando',
            assumedDecisions: 'Decisões assumidas', changeHint: 'Como alterar depois',
        } : {
            subtitle: 'These journeys will become the permanent source of truth for the product.',
            actor: 'Actor', goal: 'Goal', steps: 'Steps',
            rules: 'Rules', outcome: 'Outcome and evidence', filters: 'Filters', impact: 'Impact', noPolicyDecision: 'No policy decision was provided for this journey.',
            journeys: 'Journeys', journeysFound: 'journeys found', selectJourney: 'Select a journey to review.',
            allActors: 'All actors', actorMap: 'Journey map by actor', actors: 'actors', overview: 'Overview', actual: '(actual)',
            rulesHelp: 'Rules that must remain true in every execution of this journey.',
            adjustment: 'What should change?', placeholder: 'Describe the needed change without rewriting what is already correct.',
            requestChanges: 'Request changes', approve: 'Approve journeys', round: 'Review', step: 'Step', of: 'of',
            adjustmentRequired: 'Describe what must change before requesting another version.',
            processingApproval: 'Validating journeys…', processingChanges: 'Preparing a new review…', processingCancel: 'Cancelling execution…',
            revise: 'Review the items below', cancel: 'Cancel execution', cancelTitle: 'Cancel this execution?',
            cancelText: 'Processing will end. The history and approved artifacts will be preserved.', keepWorking: 'Keep working',
            assumedDecisions: 'Assumed decisions', changeHint: 'How to change later',
        };
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
        this.feedbackFocusPending = feedback?.kind === 'error';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const labels = this.labels();
        const policyChanges = this.policyChanges();
        const adjustment = this.submissionAdjustment(policyChanges);
        if (action === 'requestChanges' && !adjustment) {
            this.setFeedback({ kind: 'error', message: labels.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? labels.processingApproval : action === 'cancel' ? labels.processingCancel : labels.processingChanges });
        this.feedbackScrollPending = true;
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-journeys-review', {
            detail: { action, adjustment, review: this.value, policyDecisionSelections: this.policyDecisionSelections() },
            bubbles: true,
            composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback(labels) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">
      ${error ? html `<strong>${labels.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>
      ${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}
    </section>`;
    }
    renderCancelDialog(labels) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-journeys-cancel-title" @keydown=${this.trapCancel}>
      <h3 id="ns4-journeys-cancel-title">${labels.cancelTitle}</h3><p>${labels.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${labels.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${labels.cancel}</button></div>
    </section></div>`;
    }
    render() {
        if (!this.value)
            return html `<div class="ns4-empty">No E2 review available.</div>`;
        const labels = this.labels();
        const actorRefs = [...new Set(this.value.journeys.map(item => item.business.actorRef))];
        const visibleJourneys = this.value.journeys.filter(item => this.selectedActorRef === 'all' || item.business.actorRef === this.selectedActorRef);
        const journey = visibleJourneys.find(item => item.journeyId === this.selectedJourneyId) || visibleJourneys[0] || this.value.journeys[0];
        const hasChanges = Boolean(this.adjustment.trim()) || this.policyChanges().length > 0;
        if (!journey)
            return html `<div class="ns4-empty">${labels.selectJourney}</div>`;
        const journeyView = this.view(journey);
        return html `
      <section class="ns4-journeys">
        <header class="ns4-header">
          <div>
            <div class="ns4-breadcrumb">${labels.step} 2 ${labels.of} 6 · ${labels.journeys}</div>
            <h2>${this.value.title}</h2>
            <p>${labels.subtitle}</p>
          </div>
          <div class="ns4-header-meta">
            <span>${labels.round} ${this.value.reviewRound}</span>
            <strong>${this.value.journeys.length} ${labels.journeysFound}</strong>
          </div>
        </header>
        ${this.renderFeedback(labels)}
        ${this.value.systemDecisions.length ? html `
          <details class="ns4-system-decisions">
            <summary>${labels.assumedDecisions} (${this.value.systemDecisions.length})</summary>
            <div>${this.value.systemDecisions.map(decision => html `
              <article>
                <strong>${decision.question}</strong>
                <p>${decision.chosen}</p>
                <small><b>${labels.changeHint}:</b> ${decision.changeHint}</small>
              </article>
            `)}</div>
          </details>
        ` : ''}

        <details class="ns4-filters">
          <summary>${labels.filters}</summary>
          <div class="ns4-filter-content">
            <div class="ns4-actor-filter" role="group" aria-label=${labels.actorMap}>
              <button class=${this.selectedActorRef === 'all' ? 'is-active' : ''} @click=${() => this.selectActor('all', this.value?.journeys || [])}>${labels.allActors}</button>
              ${actorRefs.map(actorRef => html `
                <button class=${this.selectedActorRef === actorRef ? 'is-active' : ''} @click=${() => this.selectActor(actorRef, this.value?.journeys || [])}>${this.actorLabel(actorRef)}</button>
              `)}
            </div>
            <section class="ns4-actor-map">
              <div class="ns4-section-title"><strong>${labels.actorMap}</strong><span>${actorRefs.length} ${labels.actors} / ${this.value.journeys.length} ${labels.journeys}</span></div>
              <div class="ns4-lanes">
                ${actorRefs.map(actorRef => {
            const actorJourneys = this.value?.journeys.filter(item => item.business.actorRef === actorRef) || [];
            return html `
                    <div class="ns4-lane ${this.selectedActorRef === actorRef ? 'is-filtered' : ''}">
                      <button class="ns4-lane-head" @click=${() => this.selectActor(actorRef, actorJourneys)}><span>${this.actorLabel(actorRef)}</span><strong>${actorJourneys.length}</strong></button>
                      <div class="ns4-lane-items">${actorJourneys.map(item => html `
                        <button class=${item.journeyId === journey.journeyId ? 'is-selected' : ''} @click=${() => this.selectJourney(item.journeyId)}>${item.business.title}</button>
                      `)}</div>
                    </div>
                  `;
        })}
              </div>
            </section>
          </div>
        </details>

        <div class="ns4-main">
          <aside class="ns4-list">
            <div class="ns4-section-title"><strong>${labels.journeys}</strong><span>${visibleJourneys.length} ${labels.journeysFound}</span></div>
            <div class="ns4-list-items">
              ${visibleJourneys.map(item => html `
                <button class="ns4-journey-card ${item.journeyId === journey.journeyId ? 'is-selected' : ''}"
                  @click=${() => this.selectJourney(item.journeyId)}>
                  <code>${item.journeyId}</code>
                  <strong>${item.business.title}</strong>
                  <span>${this.actorLabel(item.business.actorRef)}</span>
                  <small><em>${labels.goal}</em>${item.business.goal}</small>
                </button>
              `)}
            </div>
          </aside>

          <article class="ns4-detail">
            <div class="ns4-detail-head">${this.renderPolicySelector(journeyView, labels)}</div>

            <nav class="ns4-tabs" role="tablist">
              ${this.renderTab('steps', labels.steps)}
              ${this.renderTab('overview', labels.overview)}
              ${this.renderTab('rules', labels.rules)}
              ${this.renderTab('outcome', labels.outcome)}
            </nav>

            ${this.activeTab === 'steps' ? this.renderSteps(journeyView, labels)
            : this.activeTab === 'overview' ? this.renderOverview(journeyView, labels)
                : this.activeTab === 'rules' ? this.renderRules(journeyView, labels)
                    : this.renderOutcome(journeyView, labels)}
          </article>
        </div>

        <footer class="ns4-review">
          <label><span>${labels.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${labels.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${labels.cancel}</button>
            <button class="secondary ${hasChanges ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasChanges} @click=${() => this.submit('requestChanges')}>${labels.requestChanges}</button>
            <button class="primary ${hasChanges ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasChanges} @click=${() => this.submit('approve')}>${labels.approve}</button>
          </div>
        </footer>
        ${this.renderCancelDialog(labels)}
      </section>
    `;
    }
    selectActor(actorRef, journeys) {
        this.selectedActorRef = actorRef;
        this.selectedJourneyId = journeys.find(item => actorRef === 'all' || item.business.actorRef === actorRef)?.journeyId || '';
        this.activeTab = 'steps';
    }
    actorLabel(actorRef) {
        const readable = actorRef.replace(/([a-z])([A-Z])/g, '$1 $2');
        return `${readable.slice(0, 1).toUpperCase()}${readable.slice(1)}`;
    }
    selectJourney(journeyId) {
        this.selectedJourneyId = journeyId;
        this.activeTab = 'steps';
    }
    view(journey) { return journey; }
    policyChanges() {
        return (this.value?.journeys || []).flatMap(journey => {
            const view = this.view(journey);
            return (view.policyDecisions || []).flatMap(decision => {
                const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
                const selectedValue = this.selectedPolicyOptions[selectionKey];
                if (!selectedValue || selectedValue === `${decision.decisionId}:actual`)
                    return [];
                const alternativeIndex = Number(selectedValue.split(':').at(-1));
                const selectedChoice = decision.alternatives[alternativeIndex];
                if (!selectedChoice)
                    return [];
                return [{
                        journeyId: journey.journeyId,
                        journeyTitle: view.business.title,
                        decisionId: decision.decisionId,
                        question: decision.question,
                        generatedChoice: decision.chosen,
                        selectedChoice,
                        impact: decision.impact,
                    }];
            });
        });
    }
    submissionAdjustment(policyChanges) {
        const requestedDecisions = policyChanges.length ? [
            'Human-selected policy decisions:',
            ...policyChanges.map(change => [
                `- Journey: ${change.journeyId} — ${change.journeyTitle}`,
                `  Question: ${change.question}`,
                `  Generated choice: ${change.generatedChoice}`,
                `  Human selected: ${change.selectedChoice}`,
                change.impact ? `  Impact: ${change.impact}` : '',
            ].filter(Boolean).join('\n')),
        ].join('\n') : '';
        return [this.adjustment.trim(), requestedDecisions].filter(Boolean).join('\n\n');
    }
    policyDecisionSelections() {
        return (this.value?.journeys || []).flatMap(journey => {
            const view = this.view(journey);
            return (view.policyDecisions || []).map(decision => {
                const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
                const selected = this.selectedPolicyOptions[selectionKey] || `${decision.decisionId}:actual`;
                const alternativeIndex = selected === `${decision.decisionId}:actual` ? -1 : Number(selected.split(':').at(-1));
                return { decisionId: decision.decisionId, selectedChoice: alternativeIndex < 0 ? decision.chosen : decision.alternatives[alternativeIndex] || decision.chosen };
            });
        });
    }
    renderPolicySelector(journey, labels) {
        const decisions = journey.policyDecisions || [];
        if (!decisions.length)
            return html `<p class="ns4-no-policy">${labels.noPolicyDecision}</p>`;
        return html `<section class="ns4-policy-decisions">${decisions.map(decision => {
            const actualValue = `${decision.decisionId}:actual`;
            const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
            const options = [actualValue, ...decision.alternatives.map((_alternative, index) => `${decision.decisionId}:alternative:${index}`)];
            const selected = options.includes(this.selectedPolicyOptions[selectionKey]) ? this.selectedPolicyOptions[selectionKey] : actualValue;
            return html `<label class="ns4-policy-selector"><span>${decision.question}</span><select ?disabled=${this.submitting || this.readonly} @change=${(event) => {
                this.selectedPolicyOptions = { ...this.selectedPolicyOptions, [selectionKey]: event.target.value };
            }}>
        <option value=${actualValue} .selected=${selected === actualValue}>${labels.actual} ${decision.chosen}</option>
        ${decision.alternatives.map((alternative, index) => {
                const value = `${decision.decisionId}:alternative:${index}`;
                return html `<option value=${value} .selected=${selected === value}>${alternative}</option>`;
            })}
      </select>${decision.impact ? html `<p class="ns4-policy-impact"><span aria-hidden="true">⚠</span><span><strong>${labels.impact}</strong>${decision.impact}</span></p>` : ''}</label>`;
        })}</section>`;
    }
    renderTab(tab, label) {
        return html `<button role="tab" aria-selected=${this.activeTab === tab ? 'true' : 'false'} class=${this.activeTab === tab ? 'is-active' : ''} @click=${() => { this.activeTab = tab; }}>${label}</button>`;
    }
    renderOverview(journey, labels) {
        return html `
      <dl class="ns4-summary">
        <div><dt>${labels.actor}</dt><dd>${this.actorLabel(journey.business.actorRef)}</dd></div>
        <div><dt>${labels.goal}</dt><dd>${journey.business.goal}</dd></div>
      </dl>
    `;
    }
    renderSteps(journey, labels) {
        return html `
      <section class="ns4-steps-section">
        <h4>${labels.steps}</h4>
        <ol class="ns4-steps">${journey.business.steps.map((step, index) => html `
          <li>
            <span class="ns4-step-index">${index + 1}</span>
            <div>
              <div class="ns4-step-title"><span>${step.kind}</span><strong>${step.title}</strong><code>${step.entity}</code></div>
              <p>${step.description}</p>
            </div>
          </li>
        `)}</ol>
      </section>
    `;
    }
    renderRules(journey, labels) {
        return html `
      <section class="ns4-rules">
        <p>${labels.rulesHelp}</p>
        <ol>${(journey.business.useRules || []).map(ruleId => html `<li><code>${ruleId}</code></li>`)}</ol>
      </section>
    `;
    }
    renderOutcome(journey, labels) {
        return html `<section class="ns4-outcome"><h4>${labels.outcome}</h4><p>${journey.business.outcome.statement}</p><ul>${journey.business.outcome.evidence.map(item => html `<li>${item}</li>`)}</ul></section>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Journeys102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Journeys102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "selectedActorRef", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "selectedJourneyId", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "activeTab", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "selectedPolicyOptions", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Journeys102020.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Journeys102020.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Journeys102020.prototype, "msgOk", void 0);
WidgetNs4Journeys102020 = __decorate([
    customElement('widget-ns4-journeys-102020')
], WidgetNs4Journeys102020);
export { WidgetNs4Journeys102020 };
