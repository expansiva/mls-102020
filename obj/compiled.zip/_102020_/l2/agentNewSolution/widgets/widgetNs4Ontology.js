/// <mls fileReference="_102020_/l2/agentNewSolution/widgets/widgetNs4Ontology.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const labels = {
    en: {
        subtitle: 'Review the business data, constraints and relationships that frontend and backend will share.', step: 'Step', of: 'of',
        round: 'Review', mode: 'New solution', changes: 'Changes in this round', entities: 'Entities',
        fields: 'Fields', relationships: 'Relationships', lifecycle: 'Lifecycle', ruleRefs: 'Rule references', overview: 'Overview', descriptions: 'Descriptions',
        source: 'Traceability', storage: 'Persistence destination', required: 'Required', optional: 'Optional', constraints: 'Field rules',
        persistenceMap: 'Persistence map', persistenceHint: 'Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.',
        targetMdm: 'MDM · base records', targetModuleDatabase: 'Module database · transactions', targetDerived: 'Derived · no own table',
        targetExternal: 'External · platform owned', targetEmbedded: 'Embedded · owned value', scope: 'Scope', mdmType: 'MDM type', idField: 'Identifier', reason: 'Reason',
        fieldRulesHint: 'Click a field name or description to edit it in place.', crossStore: 'Cross-store',
        sourceRelationships: 'As origin', destinationRelationships: 'As destination', noRelationships: 'No relationships for this table.', implementation: 'Field binding', editInPlace: 'Click to edit',
        direct: 'Direct description edits', directHint: 'Titles and descriptions are safe to edit here. Structural changes use the separate request panel.',
        entityTitle: 'Entity title', entityDescription: 'Entity description', fieldTitle: 'Field title', fieldDescription: 'Field description',
        structural: 'What should change?', structuralHint: 'Use the LLM for entities, fields, types, relationships, lifecycle or constraints.',
        placeholder: 'Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.',
        request: 'Generate another proposal', approve: 'Approve ontology', requiredAdjustment: 'Describe the structural change first.', empty: 'No ontology proposal available.', processingApproval: 'Validating ontology…', processingChanges: 'Preparing a new review…', processingCancel: 'Cancelling execution…', revise: 'Review the items below', cancel: 'Cancel execution', cancelTitle: 'Cancel this execution?', cancelText: 'Processing will end. The history and approved artifacts will be preserved.', keepWorking: 'Keep working',
    },
    pt: {
        subtitle: 'Revise os dados de negócio, restrições e relacionamentos compartilhados pelo frontend e backend.', step: 'Etapa', of: 'de',
        round: 'Revisão', mode: 'Solução nova', changes: 'Alterações desta revisão', entities: 'Entidades',
        fields: 'Campos', relationships: 'Relacionamentos', lifecycle: 'Ciclo de vida', ruleRefs: 'Referências de regras', overview: 'Visão geral', descriptions: 'Descrições',
        source: 'Rastreabilidade', storage: 'Destino da persistência', required: 'Obrigatório', optional: 'Opcional', constraints: 'Regras do campo',
        persistenceMap: 'Mapa de persistência', persistenceHint: 'Confirme onde cada entidade será armazenada antes de aprovar. Selecione uma entidade para ver o motivo e os campos.',
        targetMdm: 'MDM · cadastros base', targetModuleDatabase: 'Banco do módulo · transações', targetDerived: 'Derivado · sem tabela própria',
        targetExternal: 'Externo · mantido pela plataforma', targetEmbedded: 'Embutido · valor do proprietário', scope: 'Escopo', mdmType: 'Tipo MDM', idField: 'Identificador', reason: 'Motivo',
        fieldRulesHint: 'Clique no nome ou na descrição de um campo para editá-lo na própria tabela.', crossStore: 'Entre armazenamentos',
        sourceRelationships: 'Como origem', destinationRelationships: 'Como destino', noRelationships: 'Nenhum relacionamento para esta tabela.', implementation: 'Vínculo entre campos', editInPlace: 'Clique para editar',
        direct: 'Edições diretas de descrição', directHint: 'Títulos e descrições podem ser editados aqui. Mudanças estruturais usam o painel separado.',
        entityTitle: 'Título da entidade', entityDescription: 'Descrição da entidade', fieldTitle: 'Título do campo', fieldDescription: 'Descrição do campo',
        structural: 'O que deve mudar?', structuralHint: 'Use a LLM para entidades, campos, tipos, relacionamentos, ciclos ou restrições.',
        placeholder: 'Exemplo: adicione uma projeção publicada do uso de materiais para o cliente, relacionada ao projeto e sem custos internos.',
        request: 'Gerar nova proposta', approve: 'Aprovar ontologia', requiredAdjustment: 'Descreva primeiro a alteração estrutural.', empty: 'Nenhuma proposta de ontologia disponível.', processingApproval: 'Validando ontologia…', processingChanges: 'Preparando nova revisão…', processingCancel: 'Cancelando execução…', revise: 'Revise os itens abaixo', cancel: 'Cancelar execução', cancelTitle: 'Cancelar esta execução?', cancelText: 'O processamento será encerrado. O histórico e os artefatos já aprovados serão preservados.', keepWorking: 'Continuar trabalhando',
    },
    es: {
        subtitle: 'Revise los datos de negocio, restricciones y relaciones compartidos por frontend y backend.', step: 'Paso', of: 'de',
        round: 'Revisión', mode: 'Solución nueva', changes: 'Cambios de esta revisión', entities: 'Entidades',
        fields: 'Campos', relationships: 'Relaciones', lifecycle: 'Ciclo de vida', ruleRefs: 'Referencias de reglas', overview: 'Resumen', descriptions: 'Descripciones',
        source: 'Trazabilidad', storage: 'Destino de persistencia', required: 'Obligatorio', optional: 'Opcional', constraints: 'Reglas del campo',
        persistenceMap: 'Mapa de persistencia', persistenceHint: 'Confirme dónde vive cada entidad antes de aprobar. Seleccione una entidad para revisar su motivo y campos.',
        targetMdm: 'MDM · datos maestros', targetModuleDatabase: 'Base del módulo · transacciones', targetDerived: 'Derivado · sin tabla propia',
        targetExternal: 'Externo · mantenido por la plataforma', targetEmbedded: 'Embebido · valor del propietario', scope: 'Alcance', mdmType: 'Tipo MDM', idField: 'Identificador', reason: 'Motivo',
        fieldRulesHint: 'Haga clic en el nombre o la descripción de un campo para editarlo en la tabla.', crossStore: 'Entre almacenamientos',
        sourceRelationships: 'Como origen', destinationRelationships: 'Como destino', noRelationships: 'No hay relaciones para esta tabla.', implementation: 'Vínculo entre campos', editInPlace: 'Haga clic para editar',
        direct: 'Ediciones directas de descripción', directHint: 'Títulos y descripciones se editan aquí. Los cambios estructurales usan el panel separado.',
        entityTitle: 'Título de la entidad', entityDescription: 'Descripción de la entidad', fieldTitle: 'Título del campo', fieldDescription: 'Descripción del campo',
        structural: '¿Qué debe cambiar?', structuralHint: 'Use la LLM para entidades, campos, tipos, relaciones, ciclos o restricciones.',
        placeholder: 'Ejemplo: agregue una proyección publicada del uso de materiales para el cliente, relacionada con el proyecto y sin costos internos.',
        request: 'Generar otra propuesta', approve: 'Aprobar ontología', requiredAdjustment: 'Describa primero el cambio estructural.', empty: 'No hay propuesta de ontología.', processingApproval: 'Validando ontología…', processingChanges: 'Preparando una nueva revisión…', processingCancel: 'Cancelando la ejecución…', revise: 'Revise los elementos a continuación', cancel: 'Cancelar ejecución', cancelTitle: '¿Cancelar esta ejecución?', cancelText: 'El procesamiento terminará. Se conservarán el historial y los artefactos aprobados.', keepWorking: 'Seguir trabajando',
    },
};
let WidgetNs4Ontology102020 = class WidgetNs4Ontology102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-ontology-102020 {
  --ns4-bg: var(--color-background-primary, #ffffff);
  --ns4-bg-soft: var(--color-background-secondary, #f8fafc);
  --ns4-text: var(--color-text-primary, #172033);
  --ns4-muted: var(--color-text-secondary, #52606d);
  --ns4-subtle: var(--ct-text-tertiary, #64748b);
  --ns4-border: var(--color-border-secondary, #cbd5e1);
  --ns4-border-soft: var(--color-border-tertiary, #e2e8f0);
  --ns4-accent: #4f46e5;
  --ns4-accent-bg: #eef2ff;
  --ns4-accent-text: #3730a3;
  background: var(--ns4-bg);
  color: var(--ns4-text);
  display: block;
}
widget-ns4-ontology-102020 * {
  box-sizing: border-box;
}
widget-ns4-ontology-102020 h2,
widget-ns4-ontology-102020 h3,
widget-ns4-ontology-102020 h4,
widget-ns4-ontology-102020 p,
widget-ns4-ontology-102020 dl,
widget-ns4-ontology-102020 dd {
  margin: 0;
}
widget-ns4-ontology-102020 ul {
  margin: 7px 0 0;
  padding-left: 19px;
}
widget-ns4-ontology-102020 li {
  line-height: 1.45;
  margin: 3px 0;
}
widget-ns4-ontology-102020 code {
  color: var(--ns4-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
widget-ns4-ontology-102020 button,
widget-ns4-ontology-102020 textarea {
  font: inherit;
}
widget-ns4-ontology-102020 button:focus-visible,
widget-ns4-ontology-102020 textarea:focus-visible,
widget-ns4-ontology-102020 .ns4-inline-edit:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-ontology-102020 textarea {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  color: var(--ns4-text);
  min-height: 84px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-ontology-102020 .ns4-ontology {
  background: var(--ns4-bg);
  display: grid;
  gap: 18px;
}
widget-ns4-ontology-102020 h2,
widget-ns4-ontology-102020 h3,
widget-ns4-ontology-102020 h4,
widget-ns4-ontology-102020 strong,
widget-ns4-ontology-102020 dd,
widget-ns4-ontology-102020 td {
  color: var(--ns4-text);
}
widget-ns4-ontology-102020 .ns4-ontology > header {
  align-items: flex-start;
  border-bottom: 1px solid var(--ns4-border-soft);
  display: flex;
  gap: 16px;
  justify-content: space-between;
  padding-bottom: 15px;
}
widget-ns4-ontology-102020 .ns4-ontology > header p {
  color: var(--ns4-subtle);
  line-height: 1.45;
  margin-top: 5px;
  max-width: 720px;
}
widget-ns4-ontology-102020 .ns4-ontology > header .ns4-step {
  color: var(--ns4-accent);
  font-size: 12px;
  font-weight: 650;
  margin: 0 0 5px;
}
widget-ns4-ontology-102020 .ns4-review {
  background: var(--ns4-accent-bg);
  border-radius: 999px;
  color: var(--ns4-accent-text);
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-ontology-102020 .ns4-feedback {
  border: 1px solid;
  border-radius: 10px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-ontology-102020 .ns4-feedback strong,
widget-ns4-ontology-102020 .ns4-feedback span,
widget-ns4-ontology-102020 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-ontology-102020 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-ontology-102020 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-ontology-102020 .ns4-workbench {
  align-items: stretch;
  display: grid;
  gap: 22px;
  grid-template-columns: minmax(190px, 230px) minmax(0, 1fr);
  height: min(72vh, 760px);
  min-height: 440px;
  min-width: 0;
}
widget-ns4-ontology-102020 aside {
  border-right: 1px solid var(--ns4-border-soft);
  display: grid;
  align-content: start;
  gap: 7px;
  min-height: 0;
  min-width: 0;
  overflow-y: auto;
  padding-right: 15px;
}
widget-ns4-ontology-102020 aside h3 {
  margin-bottom: 3px;
}
widget-ns4-ontology-102020 aside button {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 8px;
  cursor: pointer;
  display: grid;
  gap: 3px;
  max-width: 100%;
  min-width: 0;
  padding: 9px;
  text-align: left;
  width: 100%;
}
widget-ns4-ontology-102020 aside button strong,
widget-ns4-ontology-102020 aside button small,
widget-ns4-ontology-102020 aside button .ns4-nav-target {
  max-width: 100%;
  overflow-wrap: anywhere;
}
widget-ns4-ontology-102020 aside button:hover {
  background: var(--ns4-bg-soft);
}
widget-ns4-ontology-102020 aside button small {
  color: var(--ns4-subtle);
}
widget-ns4-ontology-102020 aside button.selected {
  background: var(--ns4-accent-bg);
  border-color: #818cf8;
  color: var(--ns4-accent-text);
}
widget-ns4-ontology-102020 .ns4-nav-target {
  border-radius: 999px;
  font-size: 10px;
  justify-self: start;
  margin-top: 2px;
  padding: 3px 6px;
}
widget-ns4-ontology-102020 aside .ns4-nav-target {
  background: transparent;
  border-color: transparent !important;
  padding: 0;
}
widget-ns4-ontology-102020 .target-mdm {
  background: #ecfdf5;
  border-color: #86efac !important;
  color: #166534;
}
widget-ns4-ontology-102020 .target-moduleDatabase {
  background: #eff6ff;
  border-color: #93c5fd !important;
  color: #1d4ed8;
}
widget-ns4-ontology-102020 .target-derived {
  background: #faf5ff;
  border-color: #d8b4fe !important;
  color: #7e22ce;
}
widget-ns4-ontology-102020 .target-external {
  background: #fff7ed;
  border-color: #fdba74 !important;
  color: #9a3412;
}
widget-ns4-ontology-102020 .target-embedded {
  background: #f8fafc;
  border-color: #cbd5e1 !important;
  color: #475569;
}
widget-ns4-ontology-102020 main {
  align-content: start;
  display: grid;
  gap: 14px;
  min-height: 0;
  min-width: 0;
  overflow-y: auto;
}
widget-ns4-ontology-102020 .ns4-entity-head {
  align-items: flex-start;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-ontology-102020 .ns4-entity-head h3 {
  font-size: 19px;
}
widget-ns4-ontology-102020 .ns4-target-badge {
  border: 1px solid;
  border-radius: 999px;
  font-size: 11px;
  padding: 4px 8px;
  white-space: nowrap;
}
widget-ns4-ontology-102020 .ns4-tabs {
  border-bottom: 1px solid var(--ns4-border-soft);
  display: flex;
  gap: 4px;
  overflow-x: auto;
}
widget-ns4-ontology-102020 .ns4-tabs button {
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  color: var(--ns4-subtle);
  cursor: pointer;
  padding: 9px 11px;
  white-space: nowrap;
}
widget-ns4-ontology-102020 .ns4-tabs button.selected {
  border-bottom-color: var(--ns4-accent);
  color: var(--ns4-accent);
  font-weight: 650;
}
widget-ns4-ontology-102020 .ns4-section-title p {
  color: var(--ns4-subtle);
  line-height: 1.4;
  margin-top: 4px;
}
widget-ns4-ontology-102020 .ns4-table-scroll {
  overflow-x: auto;
}
widget-ns4-ontology-102020 table {
  border-collapse: collapse;
  min-width: 900px;
  width: 100%;
}
widget-ns4-ontology-102020 th,
widget-ns4-ontology-102020 td {
  border-bottom: 1px solid var(--ns4-border-soft);
  padding: 10px 8px;
  text-align: left;
  vertical-align: top;
}
widget-ns4-ontology-102020 th {
  color: var(--ns4-subtle);
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-ontology-102020 td {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-ontology-102020 td > span:not(.ns4-inline-edit):not(.ns4-edit-marker) {
  background: var(--ns4-accent-bg);
  border-radius: 999px;
  color: var(--ns4-accent-text);
  display: inline-block;
  font-size: 11px;
  margin: 2px;
  padding: 4px 7px;
}
widget-ns4-ontology-102020 td > span em {
  color: var(--ns4-subtle);
  font-style: normal;
  margin-left: 3px;
}
widget-ns4-ontology-102020 .ns4-inline-edit {
  border-bottom: 1px dashed #a5b4fc;
  cursor: text;
  display: inline;
  outline: 0;
}
widget-ns4-ontology-102020 .ns4-inline-edit:focus {
  background: var(--ns4-accent-bg);
  border-bottom-color: var(--ns4-accent);
  box-shadow: 0 1px 0 var(--ns4-accent);
}
widget-ns4-ontology-102020 .ns4-description-edit {
  color: var(--ns4-muted);
}
widget-ns4-ontology-102020 .ns4-edit-marker {
  color: var(--ns4-accent);
  font-size: 11px;
  margin-left: 5px;
  user-select: none;
}
widget-ns4-ontology-102020 .ns4-overview {
  display: grid;
  gap: 16px;
}
widget-ns4-ontology-102020 .ns4-overview dl {
  border-left: 3px solid #c7d2fe;
  display: grid;
  gap: 10px;
  padding-left: 12px;
}
widget-ns4-ontology-102020 .ns4-overview dt {
  color: var(--ns4-subtle);
  font-size: 11px;
}
widget-ns4-ontology-102020 .ns4-overview dd {
  font-size: 13px;
  line-height: 1.45;
  margin-top: 2px;
  overflow-wrap: anywhere;
}
widget-ns4-ontology-102020 .ns4-entity-details {
  border-top: 1px solid var(--ns4-border-soft);
  display: grid;
  gap: 18px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  padding-top: 14px;
}
widget-ns4-ontology-102020 .ns4-entity-details h3 {
  font-size: 13px;
  margin-bottom: 6px;
}
widget-ns4-ontology-102020 .ns4-entity-details em {
  color: var(--ns4-subtle);
  font-size: 11px;
}
widget-ns4-ontology-102020 .ns4-relationships {
  display: grid;
  gap: 24px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-ontology-102020 .ns4-relationship-group h3 {
  font-size: 13px;
  margin-bottom: 8px;
}
widget-ns4-ontology-102020 .ns4-relationship-list {
  border-top: 1px solid var(--ns4-border-soft);
}
widget-ns4-ontology-102020 .ns4-relationship-list article {
  border-bottom: 1px solid var(--ns4-border-soft);
  display: grid;
  gap: 3px;
  padding: 10px 0;
}
widget-ns4-ontology-102020 .ns4-relationship-list article p {
  color: var(--ns4-muted);
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-ontology-102020 .ns4-cross-store {
  background: #fef3c7;
  border-radius: 999px;
  color: #92400e;
  font-size: 10px;
  justify-self: start;
  padding: 3px 7px;
}
widget-ns4-ontology-102020 .ns4-no-relationships {
  color: var(--ns4-subtle);
  font-size: 13px;
}
widget-ns4-ontology-102020 .ns4-descriptions {
  border-left: 3px solid #c7d2fe;
  padding-left: 14px;
}
widget-ns4-ontology-102020 .ns4-descriptions code {
  display: block;
  margin-top: 4px;
}
widget-ns4-ontology-102020 .ns4-descriptions p {
  color: var(--ns4-muted);
  line-height: 1.55;
  margin-top: 12px;
  max-width: 760px;
}
widget-ns4-ontology-102020 .ns4-footer {
  border-top: 1px solid var(--ns4-border);
  display: grid;
  gap: 10px;
  padding-top: 15px;
}
widget-ns4-ontology-102020 .ns4-footer label {
  display: grid;
  gap: 6px;
}
widget-ns4-ontology-102020 .ns4-footer label > span {
  color: var(--ns4-muted);
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-ontology-102020 .ns4-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-ontology-102020 .ns4-actions button {
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-ontology-102020 .ns4-actions button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
widget-ns4-ontology-102020 .ns4-actions .secondary {
  background: var(--ns4-bg);
  color: var(--ns4-text);
}
widget-ns4-ontology-102020 .ns4-actions .primary {
  background: var(--ns4-bg);
  color: var(--ns4-text);
}
widget-ns4-ontology-102020 .ns4-actions .is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-ontology-102020 .ns4-actions .cancel {
  background: var(--ns4-bg);
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-ontology-102020 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-ontology-102020 .ns4-cancel-dialog {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  color: var(--ns4-text);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-ontology-102020 .ns4-cancel-dialog p {
  color: var(--ns4-muted);
}
widget-ns4-ontology-102020 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-ontology-102020 .ns4-cancel-dialog button {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  color: var(--ns4-text);
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-ontology-102020 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 820px) {
  widget-ns4-ontology-102020 .ns4-ontology > header,
  widget-ns4-ontology-102020 .ns4-workbench,
  widget-ns4-ontology-102020 .ns4-relationships {
    display: grid;
    grid-template-columns: 1fr;
  }
  widget-ns4-ontology-102020 .ns4-workbench {
    height: auto;
    min-height: 0;
  }
  widget-ns4-ontology-102020 aside {
    border-bottom: 1px solid var(--ns4-border-soft);
    border-right: 0;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    overflow: visible;
    padding-bottom: 14px;
    padding-right: 0;
  }
  widget-ns4-ontology-102020 aside h3 {
    grid-column: 1 / -1;
  }
  widget-ns4-ontology-102020 main {
    overflow: visible;
  }
  widget-ns4-ontology-102020 .ns4-entity-details {
    grid-template-columns: 1fr;
  }
  widget-ns4-ontology-102020 .ns4-actions {
    display: grid;
  }
}
@media (prefers-color-scheme: dark) {
  widget-ns4-ontology-102020 {
    --ns4-bg: #0f141b;
    --ns4-bg-soft: #171e27;
    --ns4-text: #f1f5f9;
    --ns4-muted: #b8c4d3;
    --ns4-subtle: #9baabd;
    --ns4-border: #64748b;
    --ns4-border-soft: #344152;
    --ns4-accent: #a5b4fc;
    --ns4-accent-bg: #25294a;
    --ns4-accent-text: #c7d2fe;
  }
  widget-ns4-ontology-102020 .ns4-feedback.is-error {
    background: #3b1721;
    border-color: #fb7185;
    color: #fecdd3;
  }
  widget-ns4-ontology-102020 .ns4-feedback.is-ok {
    background: #103226;
    border-color: #4ade80;
    color: #bbf7d0;
  }
  widget-ns4-ontology-102020 .ns4-actions .cancel {
    border-color: #ef4444;
    color: #fca5a5;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.selectedEntityId = '';
        this.activeTab = 'fields';
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return labels.pt;
        if (language.startsWith('es'))
            return labels.es;
        return labels.en;
    }
    selectedEntity() {
        return this.value?.entities.find(item => item.entityId === this.selectedEntityId) || this.value?.entities[0];
    }
    selectEntity(entityId) {
        this.selectedEntityId = entityId;
        this.activeTab = 'fields';
    }
    storageLabel(target, text) {
        if (target === 'mdm')
            return text.targetMdm;
        if (target === 'moduleDatabase')
            return text.targetModuleDatabase;
        if (target === 'derived')
            return text.targetDerived;
        if (target === 'external')
            return text.targetExternal;
        return text.targetEmbedded;
    }
    updateEntity(patch) {
        const selected = this.selectedEntity();
        if (!this.value || !selected || this.readonly)
            return;
        this.value = { ...this.value, entities: this.value.entities.map(entity => entity.entityId === selected.entityId ? { ...entity, ...patch } : entity) };
    }
    updateField(fieldId, patch) {
        const selected = this.selectedEntity();
        if (!selected)
            return;
        this.updateEntity({ fields: selected.fields.map(field => field.fieldId === fieldId ? { ...field, ...patch } : field) });
    }
    updateInlineField(fieldId, property, event) {
        const value = event.currentTarget.innerText.trim();
        this.updateField(fieldId, property === 'title' ? { title: value } : { description: value });
    }
    finishInlineEdit(event) {
        if (event.key !== 'Enter' || event.shiftKey)
            return;
        event.preventDefault();
        event.currentTarget.blur();
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
        this.feedbackFocusPending = feedback?.kind === 'error';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: this.text().requiredAdjustment });
            return;
        }
        const text = this.text();
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.feedbackScrollPending = true;
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-ontology-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-ontology-cancel-title" @keydown=${this.trapCancel}><h3 id="ns4-ontology-cancel-title">${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const entity = this.selectedEntity();
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `
      <section class="ns4-ontology">
        <header>
          <div><p class="ns4-step">${text.step} 4 ${text.of} 6</p><h2>${this.value.title}</h2><p>${text.subtitle}</p></div>
          <span class="ns4-review">${text.round} ${this.value.reviewRound}</span>
        </header>
        ${this.renderFeedback(text)}

        <div class="ns4-workbench">
          <aside aria-label=${text.entities}>
            <h3>${text.entities}</h3>
            ${this.value.entities.map(item => html `<button class=${entity?.entityId === item.entityId ? 'selected' : ''}
              @click=${() => this.selectEntity(item.entityId)}><strong>${item.title}</strong><small>${item.entityId}</small>
              <span class="ns4-nav-target target-${item.storage.target}">${this.storageLabel(item.storage.target, text)}</span></button>`)}
          </aside>
          ${entity ? this.renderEntity(entity, text) : ''}
        </div>

        <footer class="ns4-footer">
          <label><span>${text.structural}</span><textarea .value=${this.adjustment} placeholder=${text.placeholder} ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}></textarea>
          </label>
          <div class="ns4-actions">
            <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
            <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.request}</button>
            <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
          </div>
        </footer>
        ${this.renderCancelDialog(text)}
      </section>`;
    }
    renderEntity(entity, text) {
        return html `<main>
      <div class="ns4-entity-head"><div><h3>${entity.title}</h3><code>${entity.entityId} · ${entity.kind} · ${entity.ownership}</code></div>
        <span class="ns4-target-badge target-${entity.storage.target}">${this.storageLabel(entity.storage.target, text)}</span></div>
      <div class="ns4-tabs">
        <button class=${this.activeTab === 'fields' ? 'selected' : ''} @click=${() => { this.activeTab = 'fields'; }}>${text.fields}</button>
        <button class=${this.activeTab === 'overview' ? 'selected' : ''} @click=${() => { this.activeTab = 'overview'; }}>${text.overview}</button>
        <button class=${this.activeTab === 'relationships' ? 'selected' : ''} @click=${() => { this.activeTab = 'relationships'; }}>${text.relationships}</button>
        <button class=${this.activeTab === 'descriptions' ? 'selected' : ''} @click=${() => { this.activeTab = 'descriptions'; }}>${text.descriptions}</button>
      </div>
      ${this.activeTab === 'fields' ? this.renderFields(entity, text) : ''}
      ${this.activeTab === 'overview' ? this.renderOverview(entity, text) : ''}
      ${this.activeTab === 'relationships' ? this.renderRelationships(entity, text) : ''}
      ${this.activeTab === 'descriptions' ? this.renderDescriptions(entity, text) : ''}
    </main>`;
    }
    renderFields(entity, text) {
        return html `<section class="ns4-fields"><div class="ns4-section-title"><h3>${text.fields}</h3><p>${text.fieldRulesHint}</p></div><div class="ns4-table-scroll"><table>
      <thead><tr><th>Id</th><th>${text.fieldTitle}</th><th>${text.fieldDescription}</th><th>Type</th><th>Mode</th><th>${text.constraints}</th></tr></thead>
      <tbody>${entity.fields.map(field => html `<tr><td><code>${field.fieldId}</code></td>
        <td><span class="ns4-inline-edit" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.editInPlace}
          @blur=${(event) => this.updateInlineField(field.fieldId, 'title', event)} @keydown=${this.finishInlineEdit}>${field.title}</span>${this.readonly ? '' : html `<span class="ns4-edit-marker" aria-hidden="true">✎</span>`}</td>
        <td><span class="ns4-inline-edit ns4-description-edit" contenteditable=${this.readonly ? 'false' : 'true'} title=${text.editInPlace}
          @blur=${(event) => this.updateInlineField(field.fieldId, 'description', event)} @keydown=${this.finishInlineEdit}>${field.description}</span>${this.readonly ? '' : html `<span class="ns4-edit-marker" aria-hidden="true">✎</span>`}</td>
        <td><code>${field.type}</code></td><td>${field.required ? text.required : text.optional}</td>
        <td>${field.constraints.map(constraint => html `<span title=${constraint.description}>${constraint.kind}: ${constraint.value} <em>${constraint.source}</em></span>`)}</td></tr>`)}</tbody>
    </table></div></section>`;
    }
    renderOverview(entity, text) {
        return html `<section class="ns4-overview"><dl>
      <div><dt>${text.source}</dt><dd>${[...entity.sourceRefs.journeyIds, ...entity.sourceRefs.featureIds, ...entity.sourceRefs.authorityRefs].join(', ') || '—'}</dd></div>
      <div><dt>${text.storage}</dt><dd><strong>${this.storageLabel(entity.storage.target, text)}</strong> · ${text.scope}: ${entity.storage.scope}</dd></div>
      ${entity.storage.idField ? html `<div><dt>${text.idField}</dt><dd><code>${entity.storage.idField}</code></dd></div>` : ''}
      ${entity.storage.mdmType ? html `<div><dt>${text.mdmType}</dt><dd><code>${entity.storage.mdmType}</code></dd></div>` : ''}
      <div><dt>${text.reason}</dt><dd>${entity.storage.notes || '—'}</dd></div></dl>
      <div class="ns4-entity-details"><article><h3>${text.lifecycle}</h3><p>${this.lifecycleLine(entity) || '—'}</p></article>
        <article><h3>${text.ruleRefs}</h3><ul>${entity.useRules.map(ruleId => html `<li><code>${ruleId}</code></li>`)}</ul></article></div>
    </section>`;
    }
    renderRelationships(entity, text) {
        const origin = this.value.relationships.filter(item => item.fromEntity === entity.entityId);
        const destination = this.value.relationships.filter(item => item.toEntity === entity.entityId);
        return html `<section class="ns4-relationships"><div class="ns4-relationship-group"><h3>${text.sourceRelationships}</h3>
      ${this.renderRelationshipList(origin, text)}</div><div class="ns4-relationship-group"><h3>${text.destinationRelationships}</h3>${this.renderRelationshipList(destination, text)}</div></section>`;
    }
    renderRelationshipList(relationships, text) {
        return relationships.length ? html `<div class="ns4-relationship-list">${relationships.map(relationship => {
            const from = this.value.entities.find(item => item.entityId === relationship.fromEntity);
            const to = this.value.entities.find(item => item.entityId === relationship.toEntity);
            const crossStore = !!from && !!to && from.storage.target !== to.storage.target;
            const realization = relationship.realization;
            const fromFields = realization?.from.fieldIds.join(', ') || '∅';
            const toFields = realization?.to.fieldIds.join(', ') || '∅';
            return html `<article><strong>${relationship.fromEntity} → ${relationship.toEntity}</strong><code>${relationship.type} · ${relationship.persistence.mode}</code>
        ${realization ? html `<p><strong>${text.implementation}:</strong> <code>${realization.kind}</code> ·
          <code>${relationship.fromEntity}.${fromFields}</code> → <code>${relationship.toEntity}.${toFields}</code></p>` : ''}
        ${crossStore ? html `<span class="ns4-cross-store">${text.crossStore}</span>` : ''}<p>${relationship.description}</p>
        ${realization ? html `<p>${realization.description}</p>` : ''}</article>`;
        })}</div>` : html `<p class="ns4-no-relationships">${text.noRelationships}</p>`;
    }
    renderDescriptions(entity, text) {
        return html `<section class="ns4-descriptions"><h3>${entity.title}</h3><code>${entity.entityId}</code><p>${entity.description || '—'}</p></section>`;
    }
    lifecycleLine(entity) {
        return entity.lifecycleStates.map(code => {
            const label = entity.lifecycleLabels?.find(item => item.code === code)?.label;
            return label && label !== code ? `${label} (${code})` : code;
        }).join(' → ');
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Ontology102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Ontology102020.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "selectedEntityId", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "activeTab", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Ontology102020.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Ontology102020.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Ontology102020.prototype, "msgOk", void 0);
WidgetNs4Ontology102020 = __decorate([
    customElement('widget-ns4-ontology-102020')
], WidgetNs4Ontology102020);
export { WidgetNs4Ontology102020 };
