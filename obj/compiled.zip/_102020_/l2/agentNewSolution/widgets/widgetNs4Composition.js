/// <mls fileReference="_102020_/l2/agentNewSolution/widgets/widgetNs4Composition.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4Composition102020 = class WidgetNs4Composition102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-composition-102020 {
  color: #172033;
  display: block;
}
widget-ns4-composition-102020 * {
  box-sizing: border-box;
}
widget-ns4-composition-102020 h2,
widget-ns4-composition-102020 h3,
widget-ns4-composition-102020 p {
  margin: 0;
}
widget-ns4-composition-102020 button,
widget-ns4-composition-102020 textarea {
  font: inherit;
}
widget-ns4-composition-102020 button:focus-visible,
widget-ns4-composition-102020 textarea:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-composition-102020 button:disabled,
widget-ns4-composition-102020 textarea:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-composition-102020 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  overflow-wrap: anywhere;
}
widget-ns4-composition-102020 textarea {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  color: #172033;
  min-height: 86px;
  padding: 9px;
  resize: vertical;
  width: 100%;
}
widget-ns4-composition-102020 .ns4-composition {
  display: grid;
  gap: 16px;
}
widget-ns4-composition-102020 header {
  align-items: flex-start;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  gap: 16px;
  justify-content: space-between;
  padding-bottom: 14px;
}
widget-ns4-composition-102020 .ns4-step {
  color: #4f46e5;
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 5px;
}
widget-ns4-composition-102020 header div > p:last-child {
  color: #64748b;
  line-height: 1.45;
  margin-top: 5px;
}
widget-ns4-composition-102020 header > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-composition-102020 .ns4-summary {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  color: #334155;
  line-height: 1.5;
  padding: 14px;
}
widget-ns4-composition-102020 .ns4-recommendations {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-composition-102020 .ns4-recommendations article {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  display: grid;
  gap: 9px;
  padding: 14px;
}
widget-ns4-composition-102020 .ns4-recommendations article > div {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: space-between;
}
widget-ns4-composition-102020 .kind,
widget-ns4-composition-102020 .decision {
  border-radius: 999px;
  font-size: 11px;
  padding: 4px 7px;
}
widget-ns4-composition-102020 .kind {
  background: #eef2ff;
  color: #3730a3;
}
widget-ns4-composition-102020 .decision.include {
  background: #ecfdf5;
  color: #166534;
}
widget-ns4-composition-102020 .decision.defer {
  background: #fff7ed;
  color: #9a3412;
}
widget-ns4-composition-102020 .ns4-recommendations h3 {
  font-size: 16px;
}
widget-ns4-composition-102020 .ns4-recommendations article p {
  color: #475569;
  line-height: 1.45;
}
widget-ns4-composition-102020 .ns4-empty-state {
  align-items: center;
  background: #ecfdf5;
  border: 1px solid #86efac;
  border-radius: 10px;
  color: #166534;
  display: flex;
  gap: 10px;
  grid-column: 1 / -1;
  padding: 16px;
}
widget-ns4-composition-102020 .ns4-feedback {
  border: 1px solid;
  border-radius: 10px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-composition-102020 .ns4-feedback strong,
widget-ns4-composition-102020 .ns4-feedback span,
widget-ns4-composition-102020 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-composition-102020 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-composition-102020 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-composition-102020 footer {
  border-top: 1px solid #c7d2fe;
  display: grid;
  gap: 10px;
  padding-top: 15px;
}
widget-ns4-composition-102020 footer label {
  display: grid;
  gap: 6px;
}
widget-ns4-composition-102020 footer label > span {
  color: #475569;
  font-size: 12px;
  font-weight: 650;
}
widget-ns4-composition-102020 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-composition-102020 footer button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  color: #334155;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-composition-102020 footer .cancel {
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-composition-102020 footer .is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-composition-102020 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.56);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-composition-102020 .ns4-cancel-dialog {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-composition-102020 .ns4-cancel-dialog p {
  color: #475569;
}
widget-ns4-composition-102020 .ns4-cancel-dialog > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-composition-102020 .ns4-cancel-dialog button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-composition-102020 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (prefers-color-scheme: dark) {
  widget-ns4-composition-102020 {
    color: #e5edf8;
  }
  widget-ns4-composition-102020 code {
    color: #cbd5e1;
  }
  widget-ns4-composition-102020 textarea {
    background: #111827;
    border-color: #64748b;
    color: #f8fafc;
  }
  widget-ns4-composition-102020 textarea::placeholder {
    color: #94a3b8;
  }
  widget-ns4-composition-102020 header {
    border-color: #475569;
  }
  widget-ns4-composition-102020 header div > p:last-child,
  widget-ns4-composition-102020 footer label > span {
    color: #cbd5e1;
  }
  widget-ns4-composition-102020 header > span,
  widget-ns4-composition-102020 .kind {
    background: #312e81;
    color: #e0e7ff;
  }
  widget-ns4-composition-102020 .ns4-summary {
    background: #111827;
    border-color: #475569;
    color: #e2e8f0;
  }
  widget-ns4-composition-102020 .ns4-recommendations article {
    background: #111827;
    border-color: #475569;
  }
  widget-ns4-composition-102020 .ns4-recommendations article p {
    color: #cbd5e1;
  }
  widget-ns4-composition-102020 .decision.include {
    background: #14532d;
    color: #dcfce7;
  }
  widget-ns4-composition-102020 .decision.defer {
    background: #7c2d12;
    color: #ffedd5;
  }
  widget-ns4-composition-102020 .ns4-empty-state {
    background: #14532d;
    border-color: #22c55e;
    color: #dcfce7;
  }
  widget-ns4-composition-102020 footer {
    border-color: #475569;
  }
  widget-ns4-composition-102020 footer button {
    background: #111827;
    border-color: #64748b;
    color: #f8fafc;
  }
  widget-ns4-composition-102020 footer .cancel {
    border-color: #ef4444;
    color: #fecaca;
  }
  widget-ns4-composition-102020 footer .is-active {
    background: #6366f1;
    border-color: #818cf8;
  }
  widget-ns4-composition-102020 .ns4-cancel-dialog {
    background: #111827;
    border: 1px solid #475569;
    color: #f8fafc;
  }
  widget-ns4-composition-102020 .ns4-cancel-dialog p {
    color: #cbd5e1;
  }
}
@media (max-width: 650px) {
  widget-ns4-composition-102020 header {
    display: grid;
  }
  widget-ns4-composition-102020 .ns4-recommendations {
    grid-template-columns: 1fr;
  }
  widget-ns4-composition-102020 footer > div {
    display: grid;
  }
  widget-ns4-composition-102020 footer .cancel {
    margin-right: 0;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.msgError = '';
        this.msgOk = '';
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.cancelOrigin = null;
    }
    text() {
        const language = this.value?.userLanguage?.toLowerCase() || 'en';
        if (language.startsWith('pt'))
            return {
                step: '👤 Etapa 6 de 6 — Módulos adicionais e plugins', review: 'Revisão',
                empty: 'Nenhum módulo horizontal ou plugin adicional foi recomendado.',
                horizontalModule: 'Módulo horizontal', plugin: 'Plugin', include: 'Incluir', defer: 'Deixar para depois',
                adjustment: 'Quer mudar alguma coisa?', placeholder: 'Exemplo: adicione, remova ou adie uma recomendação e explique o motivo.',
                request: 'Gerar nova proposta', approve: 'Aprovar análise', cancel: 'Cancelar execução',
                adjustmentRequired: 'Descreva a alteração antes de gerar outra proposta.',
                processingApproval: 'Validando análise…', processingChanges: 'Preparando nova revisão…', processingCancel: 'Cancelando execução…',
                revise: 'Revise os itens abaixo', cancelTitle: 'Cancelar esta execução?',
                cancelText: 'O processamento será encerrado. Os artefatos já aprovados serão preservados.', keepWorking: 'Continuar trabalhando',
                hint: 'Esta revisão é conservadora: uma lista vazia significa que o módulo pode seguir sem componentes adicionais.',
            };
        if (language.startsWith('es'))
            return {
                step: '👤 Paso 6 de 6 — Módulos adicionales y plugins', review: 'Revisión',
                empty: 'No se recomendó ningún módulo horizontal ni plugin adicional.',
                horizontalModule: 'Módulo horizontal', plugin: 'Plugin', include: 'Incluir', defer: 'Dejar para después',
                adjustment: '¿Desea cambiar algo?', placeholder: 'Ejemplo: agregue, quite o aplace una recomendación y explique el motivo.',
                request: 'Generar otra propuesta', approve: 'Aprobar análisis', cancel: 'Cancelar ejecución',
                adjustmentRequired: 'Describa el cambio antes de generar otra propuesta.',
                processingApproval: 'Validando análisis…', processingChanges: 'Preparando otra revisión…', processingCancel: 'Cancelando ejecución…',
                revise: 'Revise los elementos siguientes', cancelTitle: '¿Cancelar esta ejecución?',
                cancelText: 'El procesamiento terminará. Los artefactos aprobados serán preservados.', keepWorking: 'Seguir trabajando',
                hint: 'Esta revisión es conservadora: una lista vacía significa que el módulo puede continuar sin componentes adicionales.',
            };
        return {
            step: '👤 Step 6 of 6 — Additional modules and plugins', review: 'Review',
            empty: 'No additional horizontal module or plugin was recommended.',
            horizontalModule: 'Horizontal module', plugin: 'Plugin', include: 'Include', defer: 'Defer',
            adjustment: 'Would you like to change anything?', placeholder: 'Example: add, remove or defer a recommendation and explain why.',
            request: 'Generate another proposal', approve: 'Approve analysis', cancel: 'Cancel execution',
            adjustmentRequired: 'Describe the change before generating another proposal.',
            processingApproval: 'Validating analysis…', processingChanges: 'Preparing another review…', processingCancel: 'Cancelling execution…',
            revise: 'Review the items below', cancelTitle: 'Cancel this execution?',
            cancelText: 'Processing will end. Approved artifacts will be preserved.', keepWorking: 'Keep working',
            hint: 'This review is conservative: an empty list means the module can proceed without additional components.',
        };
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-composition-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `<section class="ns4-composition">
      <header><div><p class="ns4-step">${text.step}</p><h2>${this.value.title}</h2><p>${text.hint}</p></div><span>${text.review} ${this.value.reviewRound}</span></header>
      ${this.renderFeedback(text)}
      <section class="ns4-summary"><p>${this.value.analysisSummary}</p></section>
      <section class="ns4-recommendations">
        ${this.value.recommendations.length ? this.value.recommendations.map(item => html `<article>
          <div><span class="kind">${item.kind === 'horizontalModule' ? text.horizontalModule : text.plugin}</span><span class="decision ${item.decision}">${item.decision === 'include' ? text.include : text.defer}</span></div>
          <h3>${item.title}</h3><p>${item.purpose}</p><code>${item.id}</code>
        </article>`) : html `<div class="ns4-empty-state"><strong>✓</strong><p>${text.empty}</p></div>`}
      </section>
      <footer><label><span>${text.adjustment}</span><textarea .value=${this.adjustment} placeholder=${text.placeholder}
        ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label><div>
        <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
        <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.request}</button>
        <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
      </div></footer>${this.renderCancelDialog(text)}
    </section>`;
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true"><h3>${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Composition102020.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Composition102020.prototype, "readonly", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Composition102020.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Composition102020.prototype, "msgOk", void 0);
__decorate([
    state()
], WidgetNs4Composition102020.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Composition102020.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Composition102020.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Composition102020.prototype, "cancelOpen", void 0);
WidgetNs4Composition102020 = __decorate([
    customElement('widget-ns4-composition-102020')
], WidgetNs4Composition102020);
export { WidgetNs4Composition102020 };
