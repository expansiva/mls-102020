/// <mls fileReference="_102020_/l2/agentNewSolution/agentPlanPlugins.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertPriority, assertRecord, assertString, createHoldIndexForReviewIntents, createPlannerPromptReadyIntent, createPlannerVariableToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, getPlannerOutputWithRepair, getPlanningContextSnapshot, hasAcceptedArtifact, normalizeStringList, optionalString, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { getFinalizeSolutionPlanOutput } from '/_102020_/l2/agentNewSolution/agentFinalizeSolutionPlan.js';
import { saveNewSolutionAgentTracePayload, saveNewSolutionPlanArtifacts } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentPlanPlugins',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Plan approved external plugins for the final solution',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const PLAN_PLUGINS_TOOL_NAME = 'submitPluginPlan';
export const PLAN_PLUGINS_STEP_ID = '11-plan-plugins';
const PLAN_PLUGINS_ALIASES = [PLAN_PLUGINS_STEP_ID, 'plan-plugins'];
export const PLAN_PLUGINS_RESULT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['plugins'],
    properties: {
        plugins: {
            type: 'array',
            items: {
                type: 'object',
                additionalProperties: false,
                required: [
                    'pluginId',
                    'provider',
                    'priority',
                    'reason',
                    'events',
                    'requiredCredentials',
                    'inputData',
                    'outputData',
                    'webhooks',
                    'risks',
                    'questions',
                    'resolution',
                    'pluginDefsFileRef',
                    'moduleConnectionDefsFileRef',
                ],
                properties: {
                    pluginId: { type: 'string' },
                    provider: { type: 'string' },
                    priority: { enum: ['now', 'soon', 'later', 'never'] },
                    reason: { type: 'string' },
                    events: { type: 'array', items: { type: 'string' } },
                    requiredCredentials: { type: 'array', items: { type: 'string' } },
                    inputData: { type: 'array', items: { type: 'string' } },
                    outputData: { type: 'array', items: { type: 'string' } },
                    webhooks: { type: 'array', items: { type: 'string' } },
                    risks: { type: 'array', items: { type: 'string' } },
                    questions: { type: 'array', items: { type: 'string' } },
                    resolution: { enum: ['existing', 'create_draft'] },
                    pluginDefsFileRef: { type: 'string' },
                    moduleConnectionDefsFileRef: { type: 'string' },
                    sourceProject: { type: 'number' },
                },
            },
        },
    },
};
const planPluginsToolSchema = createPlannerVariableToolSchema(PLAN_PLUGINS_TOOL_NAME, 'Submit external plugin planning for the newSolution final plan.', PLAN_PLUGINS_RESULT_SCHEMA);
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentPlanPlugins](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const finalPlan = getFinalizeSolutionPlanOutput(context);
    const snapshot = getPlanningContextSnapshot(context);
    const moduleName = getFinalPlanModuleName(finalPlan);
    const catalog = await buildRuntimePluginCatalog(finalPlan, snapshot);
    const inventory = await buildPluginInventory(moduleName, catalog);
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(PLAN_PLUGINS_TOOL_NAME), buildHumanPrompt(args, finalPlan, snapshot, catalog, inventory), planPluginsToolSchema, PLAN_PLUGINS_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlanPluginsOutput(payload);
        validatePlanPluginsOutput(output, context);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentPlanPlugins returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentPlanPlugins returned status needs_input; keeping plugin plan draft.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    // TODO-FINAL-023/024: hold the step open and run critic/repair before approving the plugin plan.
    // The incremental artifact save moves to the critic approval path (possibly with a repaired plan).
    if (status === 'completed' && output && output.status === 'ok') {
        return createHoldIndexForReviewIntents(context, parentStep, step, hookSequential, 'pluginPlan');
    }
    if (status === 'completed' && output)
        await saveNewSolutionPlanArtifacts(context, agent.agentName, step, output);
    return [createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? 'input' : undefined)];
}
export function getPlanPluginsOutput(context) {
    // TODO-FINAL-024: prefer the latest repaired index when a repair step exists.
    return getPlannerOutputWithRepair(context, 'agentPlanPlugins', 'pluginPlan', planPluginsConfig, output => validatePlanPluginsOutput(output, context));
}
function extractPlanPluginsOutput(payload) {
    return extractPlannerOutput(payload, planPluginsConfig);
}
export const planPluginsConfig = {
    toolName: PLAN_PLUGINS_TOOL_NAME,
    stepId: PLAN_PLUGINS_STEP_ID,
    stepIdAliases: PLAN_PLUGINS_ALIASES,
    normalizeResult: normalizePlanPluginsResult,
};
export function normalizePlanPluginsResult(value) {
    const result = assertRecord(value, 'result');
    return {
        plugins: assertArray(result.plugins, 'result.plugins').map((item, index) => normalizePlugin(item, `result.plugins[${index}]`)),
    };
}
function normalizePlugin(value, path) {
    const item = assertRecord(value, path);
    return {
        pluginId: assertString(item.pluginId, `${path}.pluginId`),
        provider: assertString(item.provider, `${path}.provider`),
        priority: assertPriority(item.priority, `${path}.priority`),
        reason: assertString(item.reason, `${path}.reason`),
        events: assertArray(item.events, `${path}.events`).map((value, index) => assertString(value, `${path}.events[${index}]`)),
        requiredCredentials: assertArray(item.requiredCredentials, `${path}.requiredCredentials`).map((value, index) => assertString(value, `${path}.requiredCredentials[${index}]`)),
        inputData: assertArray(item.inputData, `${path}.inputData`).map((value, index) => assertString(value, `${path}.inputData[${index}]`)),
        outputData: assertArray(item.outputData, `${path}.outputData`).map((value, index) => assertString(value, `${path}.outputData[${index}]`)),
        webhooks: assertArray(item.webhooks, `${path}.webhooks`).map((value, index) => assertString(value, `${path}.webhooks[${index}]`)),
        risks: assertArray(item.risks, `${path}.risks`).map((value, index) => assertString(value, `${path}.risks[${index}]`)),
        questions: normalizeStringList(item.questions, `${path}.questions`),
        resolution: normalizePluginResolution(item.resolution, `${path}.resolution`) || 'create_draft',
        pluginDefsFileRef: optionalString(item.pluginDefsFileRef, `${path}.pluginDefsFileRef`) || '',
        moduleConnectionDefsFileRef: optionalString(item.moduleConnectionDefsFileRef, `${path}.moduleConnectionDefsFileRef`) || '',
        sourceProject: optionalNumber(item.sourceProject, `${path}.sourceProject`),
    };
}
export function validatePlanPluginsOutput(output, context) {
    const finalPlan = getFinalizeSolutionPlanOutput(context);
    const snapshot = getPlanningContextSnapshot(context);
    const catalog = buildRuntimePluginCatalogSync(finalPlan, snapshot);
    const allowedById = new Map(catalog.plugins.map(item => [item.pluginId, item]));
    const moduleName = getFinalPlanModuleName(finalPlan);
    const inventory = buildPluginInventorySync(moduleName, catalog);
    const inventoryById = new Map(inventory.plugins.map(item => [item.pluginId, item]));
    const acceptedPluginDecisions = getAcceptedPluginDecisions(snapshot);
    for (const plugin of output.result.plugins) {
        const catalogItem = allowedById.get(plugin.pluginId);
        if (!catalogItem)
            throw new Error(`unknown pluginId: ${plugin.pluginId}`);
        if (toPluginId(catalogItem.provider) !== toPluginId(plugin.provider))
            throw new Error(`plugin provider mismatch for ${plugin.pluginId}: ${plugin.provider}`);
        const expected = inventoryById.get(plugin.pluginId);
        if (!expected)
            throw new Error(`missing plugin inventory for ${plugin.pluginId}`);
        plugin.resolution = plugin.resolution || expected.resolution;
        plugin.pluginDefsFileRef = plugin.pluginDefsFileRef || expected.pluginDefsFileRef;
        plugin.moduleConnectionDefsFileRef = plugin.moduleConnectionDefsFileRef || expected.moduleConnectionDefsFileRef;
        plugin.sourceProject = plugin.sourceProject ?? expected.sourceProject;
        if (plugin.resolution !== expected.resolution)
            throw new Error(`invalid resolution for ${plugin.pluginId}: ${plugin.resolution}`);
        if (plugin.pluginDefsFileRef !== expected.pluginDefsFileRef)
            throw new Error(`invalid pluginDefsFileRef for ${plugin.pluginId}: ${plugin.pluginDefsFileRef}`);
        if (plugin.moduleConnectionDefsFileRef !== expected.moduleConnectionDefsFileRef)
            throw new Error(`invalid moduleConnectionDefsFileRef for ${plugin.pluginId}: ${plugin.moduleConnectionDefsFileRef}`);
        if (expected.resolution === 'existing' && plugin.sourceProject !== expected.sourceProject) {
            throw new Error(`invalid sourceProject for existing plugin ${plugin.pluginId}: ${plugin.sourceProject}`);
        }
    }
    if (output.status === 'ok' && acceptedPluginDecisions.length > 0 && output.result.plugins.length === 0 && output.questions.length > 0) {
        const normalizedTrace = 'Status normalized to needs_input because accepted plugins were blocked and top-level questions were returned.';
        output.status = 'needs_input';
        if (!output.trace.includes(normalizedTrace))
            output.trace.push(normalizedTrace);
    }
    if (output.status === 'ok' && hasAcceptedArtifact(snapshot.implementationDecisions, 'plugin') && output.result.plugins.length === 0) {
        throw new Error('plugin was accepted, but plugins output is empty');
    }
    const hasPluginQuestions = output.result.plugins.some(plugin => plugin.questions.length > 0);
    if (output.status === 'needs_input' && output.questions.length === 0 && !hasPluginQuestions) {
        throw new Error('needs_input plugin plan must include top-level or per-plugin questions');
    }
}
function buildHumanPrompt(args, finalPlan, snapshot, catalog, inventory) {
    const promptContext = buildPluginPromptContext(args, finalPlan, snapshot, catalog, inventory);
    return `## Planned step args
${args}

## Plugin planning context
${JSON.stringify(promptContext, null, 2)}
`;
}
async function buildRuntimePluginCatalog(finalPlan, snapshot) {
    const actualProject = getActualProject();
    try {
        await mls.stor.loadProjectdependenciesInfoIfNeed(actualProject);
    }
    catch {
        // The sync dependency list is enough when dependencies are already loaded.
    }
    return buildRuntimePluginCatalogSync(finalPlan, snapshot);
}
function buildRuntimePluginCatalogSync(finalPlan, snapshot) {
    const actualProject = getActualProject();
    const searchProjects = getPluginSearchProjects(actualProject);
    const byId = new Map();
    for (const item of discoverExistingPluginCatalogItems(searchProjects)) {
        byId.set(item.pluginId, item);
    }
    for (const item of discoverApprovedPluginCatalogItems(finalPlan, snapshot)) {
        if (!byId.has(item.pluginId))
            byId.set(item.pluginId, item);
    }
    return {
        schemaVersion: '2026-06-02',
        plugins: Array.from(byId.values()).sort((a, b) => a.pluginId.localeCompare(b.pluginId)),
    };
}
function discoverExistingPluginCatalogItems(searchProjects) {
    const byId = new Map();
    for (const file of Object.values(mls.stor.files)) {
        if (!searchProjects.includes(file.project))
            continue;
        if (file.level !== 2 || file.shortName !== 'plugin' || file.extension !== '.defs.ts')
            continue;
        const pluginId = getPluginIdFromPluginFolder(file.folder);
        if (!pluginId || byId.has(pluginId))
            continue;
        byId.set(pluginId, {
            pluginId,
            provider: toProviderName(pluginId),
            artifactType: 'plugin',
            capabilities: [],
            requiredCredentials: [],
        });
    }
    return Array.from(byId.values());
}
function discoverApprovedPluginCatalogItems(finalPlan, snapshot) {
    const candidates = [
        ...finalPlan.result.approvedArtifacts.plugins,
        ...getAcceptedPluginDecisions(snapshot),
    ];
    const byId = new Map();
    candidates.forEach((candidate, index) => {
        const item = normalizePluginCatalogCandidate(candidate, `pluginCandidate[${index}]`);
        if (item && !byId.has(item.pluginId))
            byId.set(item.pluginId, item);
    });
    return Array.from(byId.values());
}
function normalizePluginCatalogCandidate(value, path) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return null;
    const record = value;
    const pluginId = getPluginIdFromCandidate(record, path);
    if (!pluginId)
        return null;
    return {
        pluginId,
        provider: getProviderFromCandidate(record, pluginId, path),
        artifactType: 'plugin',
        capabilities: normalizeStringList(record.capabilities, `${path}.capabilities`),
        requiredCredentials: normalizeStringList(record.requiredCredentials, `${path}.requiredCredentials`),
    };
}
async function buildPluginInventory(moduleName, catalog) {
    const actualProject = getActualProject();
    try {
        await mls.stor.loadProjectdependenciesInfoIfNeed(actualProject);
    }
    catch {
        // The sync dependency list is enough when dependencies are already loaded.
    }
    return buildPluginInventorySync(moduleName, catalog);
}
function buildPluginInventorySync(moduleName, catalog) {
    const actualProject = getActualProject();
    const searchProjects = getPluginSearchProjects(actualProject);
    return {
        actualProject,
        moduleName,
        searchProjects,
        plugins: catalog.plugins.map(plugin => {
            const existing = findExistingPlugin(plugin.pluginId, searchProjects);
            const existingAsReusablePlugin = existing && !isCurrentPlanDraftPlugin(existing, actualProject);
            return {
                pluginId: plugin.pluginId,
                provider: plugin.provider,
                resolution: existingAsReusablePlugin ? 'existing' : 'create_draft',
                exists: !!existing,
                sourceProject: existingAsReusablePlugin ? existing.project : undefined,
                pluginDefsFileRef: existingAsReusablePlugin ? existing.fileRef : buildPluginDefsFileRef(actualProject, plugin.pluginId),
                moduleConnectionDefsFileRef: buildModuleConnectionDefsFileRef(actualProject, moduleName, plugin.pluginId),
            };
        }),
    };
}
function findExistingPlugin(pluginId, searchProjects) {
    for (const project of searchProjects) {
        const fileInfo = {
            project,
            level: 2,
            folder: `plugins/${pluginId}`,
            shortName: 'plugin',
            extension: '.defs.ts',
        };
        const key = mls.stor.getKeyToFile(fileInfo);
        const file = mls.stor.files[key];
        if (file && file.status !== 'deleted') {
            return {
                project,
                fileRef: buildPluginDefsFileRef(project, pluginId),
                status: file.status,
                inLocalStorage: file.inLocalStorage,
            };
        }
    }
    return null;
}
function isCurrentPlanDraftPlugin(existing, actualProject) {
    return existing.project === actualProject && existing.inLocalStorage && existing.status !== 'nochange';
}
function getPluginIdFromPluginFolder(folder) {
    const match = /^plugins\/([^/]+)$/.exec(folder);
    if (!match)
        return null;
    const pluginId = toPluginId(match[1]);
    return pluginId || null;
}
function getPluginSearchProjects(actualProject) {
    const dependencies = mls.l5.getProjectDependencies(actualProject, false) || [];
    return Array.from(new Set([actualProject, ...dependencies]));
}
function buildPluginDefsFileRef(project, pluginId) {
    return `_${project}_/l2/plugins/${pluginId}/plugin.defs.ts`;
}
function buildModuleConnectionDefsFileRef(project, moduleName, pluginId) {
    return `_${project}_/l2/${moduleName}/plugins/${pluginId}.defs.ts`;
}
function getActualProject() {
    return mls.actualProject || 0;
}
function getFinalPlanModuleName(finalPlan) {
    return assertString(finalPlan.result.module.moduleName, 'result.module.moduleName');
}
function buildPluginPromptContext(args, finalPlan, snapshot, catalog, inventory) {
    return {
        args,
        module: finalPlan.result.module,
        approvedPluginArtifacts: summarizeObjects(finalPlan.result.approvedArtifacts.plugins),
        acceptedPluginDecisions: summarizeObjects(getAcceptedPluginDecisions(snapshot)),
        approvedWorkflowArtifacts: summarizeObjects(finalPlan.result.approvedArtifacts.workflows),
        approvedAgentArtifacts: summarizeObjects(finalPlan.result.approvedArtifacts.agents),
        approvedHorizontalModules: summarizeObjects(finalPlan.result.approvedArtifacts.horizontalModules),
        capabilities: summarizeObjects(finalPlan.result.capabilities),
        implementationDecisions: snapshot.implementationDecisions.decisions.filter(decision => isPluginRelevantDecision(decision)),
        pluginCatalog: catalog,
        pluginInventory: inventory,
    };
}
function getAcceptedPluginDecisions(snapshot) {
    return snapshot.implementationDecisions.decisions.filter(decision => decision.artifactType === 'plugin' && decision.accepted && decision.decidedPriority !== 'never');
}
function summarizeObjects(items) {
    return items.map(item => {
        if (!item || typeof item !== 'object' || Array.isArray(item))
            return item;
        const record = item;
        const summary = {};
        for (const key of ['pluginId', 'artifactId', 'signal', 'workflowId', 'agentId', 'horizontalModuleId', 'capabilityId', 'title', 'description', 'reason', 'priority', 'actor']) {
            if (record[key] !== undefined)
                summary[key] = record[key];
        }
        return Object.keys(summary).length > 0 ? summary : item;
    });
}
function isPluginRelevantDecision(decision) {
    if (['plugin', 'agent', 'horizontalModule', 'workflow'].includes(decision.artifactType))
        return true;
    const text = [decision.title, decision.description, decision.reason].join(' ').toLowerCase();
    return /plugin|integracao|integration|provider|pagamento|payment|mensagem|message|comunicacao|communication|notifica|notification|webhook/.test(text);
}
function getPluginIdFromCandidate(record, path) {
    const explicit = optionalString(record.pluginId, `${path}.pluginId`)
        || optionalString(record.providerId, `${path}.providerId`)
        || optionalString(record.integrationId, `${path}.integrationId`);
    if (explicit)
        return toPluginId(explicit);
    const provider = inferProviderFromText(record, path);
    if (provider)
        return toPluginId(provider);
    const idSource = optionalString(record.recommendationId, `${path}.recommendationId`)
        || optionalString(record.artifactId, `${path}.artifactId`)
        || optionalString(record.signal, `${path}.signal`)
        || optionalString(record.itemId, `${path}.itemId`);
    return idSource ? toPluginId(stripPluginSuffix(idSource)) : null;
}
function getProviderFromCandidate(record, pluginId, path) {
    return optionalString(record.provider, `${path}.provider`)
        || optionalString(record.providerName, `${path}.providerName`)
        || inferProviderFromText(record, path)
        || toProviderName(pluginId);
}
function inferProviderFromText(record, path) {
    const text = [
        optionalString(record.title, `${path}.title`),
        optionalString(record.description, `${path}.description`),
        optionalString(record.reason, `${path}.reason`),
        optionalString(record.decision, `${path}.decision`),
    ].filter((item) => !!item).join(' ');
    const match = /(?:\bvia\b|\bcom\b|\busing\b)\s+([a-zA-Z][a-zA-Z0-9._-]*)/.exec(text);
    return match ? match[1] : null;
}
function stripPluginSuffix(value) {
    return value.replace(/(?:Plugin|Integration|Provider)$/i, '');
}
function toPluginId(value) {
    const words = toAsciiWords(value);
    if (words.length === 0)
        return '';
    return words.map((word, index) => index === 0 ? word.toLowerCase() : capitalize(word.toLowerCase())).join('');
}
function toProviderName(value) {
    const words = toAsciiWords(value);
    if (words.length === 0)
        return value;
    return words.map(word => capitalize(word.toLowerCase())).join(' ');
}
function toAsciiWords(value) {
    return value
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
        .replace(/[^a-zA-Z0-9]+/g, ' ')
        .trim()
        .split(/\s+/)
        .filter(Boolean);
}
function capitalize(value) {
    return value.charAt(0).toUpperCase() + value.slice(1);
}
function normalizePluginResolution(value, path) {
    if (value === undefined || value === null || value === '')
        return undefined;
    if (value === 'existing' || value === 'create_draft')
        return value;
    throw new Error(`${path} must be existing or create_draft`);
}
function optionalNumber(value, path) {
    if (value === undefined || value === null || value === '')
        return undefined;
    if (typeof value === 'number' && Number.isFinite(value))
        return value;
    if (typeof value === 'string' && value.trim()) {
        const parsed = Number(value);
        if (Number.isFinite(parsed))
            return parsed;
    }
    throw new Error(`${path} must be a number`);
}
const systemPrompt = `
<!-- modelType: codeinstruct -->

You are agentPlanPlugins for the collab.codes "newSolution" flow.
Plan external plugins from the reduced plugin planning context, implementation decisions, plugin catalog, and plugin inventory.
Use the same language as the user for reasons, risks, questions, and trace.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Rules
- Use only pluginId and provider values from the provided plugin catalog.
- Use pluginInventory as the source of truth for resolution, pluginDefsFileRef, moduleConnectionDefsFileRef, and sourceProject.
- When pluginInventory marks a plugin as existing, return resolution "existing" and preserve sourceProject.
- When pluginInventory marks a plugin as create_draft, return resolution "create_draft"; the later defs save step will create l2/plugins/{pluginId}/plugin.defs.ts with draft status.
- Every acceptedPluginDecisions item with decidedPriority other than "never" must be planned when it has a matching pluginCatalog/pluginInventory item.
- Missing l2/plugins/{pluginId}/plugin.defs.ts is not a blocker; use the pluginInventory create_draft resolution instead of asking whether the catalog can be updated.
- Never return status "ok" with an empty plugins array when acceptedPluginDecisions is not empty.
- If pluginCatalog/pluginInventory is inconsistent and an accepted plugin cannot be planned, return status "needs_input", plugins: [], and a top-level question with the concrete missing pluginId/provider.
- moduleConnectionDefsFileRef must point to l2/{moduleName}/plugins/{pluginId}.defs.ts.
- Put plugin-specific questions in plugins[].questions. Use top-level questions only for general blockers.
- Do not hard-code plugin providers or priorities from a sample domain.
- A plugin can be "now" only when the approved MVP depends on that external integration.
- A plugin can be "soon" or "later" when it is useful for a future workflow, agent, notification, payment, document, or operational improvement.
- Do not plan a plugin as required for MVP unless implementation decisions approve it as "now".
- Communication plugins may be planned only when reminders, alerts, approvals, contact, follow-ups, or communication workflows justify them.
- Return an empty array when no external plugin is justified.
`;
