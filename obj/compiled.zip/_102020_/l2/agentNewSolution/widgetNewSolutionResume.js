/// <mls fileReference="_102020_/l2/agentNewSolution/widgetNewSolutionResume.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { createThread, getTemporaryContext, getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { executeBeforePrompt, loadAgent, continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { readNewSolutionProcess, writeNewSolutionProcessRun, deleteNewSolutionTraceFolder, } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
// Target agent (mention) used to open the task for each next-step kind. Blank by default — to be
// filled once the corresponding agents exist. Example: NEXT_STEP_AGENTS.horizontalModule =
// '@@agentImproveModule'. When blank, the task is opened with just the descriptive prompt.
const NEXT_STEP_AGENTS = {
    horizontalModule: '',
    plugin: '',
    materialize: '',
};
// Texts longer than this (in bytes) are collapsed behind a "see more" toggle.
const SEE_MORE_BYTES = 100;
/// **collab_i18n_start**
const message_en = {
    title: 'Final planning summary',
    prompt: 'Initial prompt',
    decisions: 'Decisions',
    openDetails: 'Open details',
    health: 'Health report',
    nextSteps: 'Next steps',
    seeMore: 'see more',
    seeLess: 'see less',
    none: 'Nothing here.',
    passed: 'Passed',
    failed: 'Has issues',
    errors: 'errors',
    warnings: 'warnings',
    readyToSave: 'Ready to save defs',
    notReady: 'Not ready to save defs',
    clearTraces: 'Clear traces (delete this run\'s trace files)',
    finish: 'Finish',
    finishing: 'Finishing…',
    finished: 'Finished. You can close this screen.',
    loading: 'Loading…',
    noRun: 'No process run found for this module yet.',
    taskOpened: 'task opened',
};
const message_ptbr = {
    title: 'Resumo final do planejamento',
    prompt: 'Prompt inicial',
    decisions: 'Decisões',
    openDetails: 'Pontos em aberto',
    health: 'Relatório de saúde',
    nextSteps: 'Próximos passos',
    seeMore: 'ver mais',
    seeLess: 'ver menos',
    none: 'Nada por aqui.',
    passed: 'Aprovado',
    failed: 'Com pendências',
    errors: 'erros',
    warnings: 'avisos',
    readyToSave: 'Pronto para salvar defs',
    notReady: 'Ainda não pronto para salvar defs',
    clearTraces: 'Limpar traces (apagar os arquivos de trace desta execução)',
    finish: 'Encerrar',
    finishing: 'Encerrando…',
    finished: 'Encerrado. Você já pode fechar esta tela.',
    loading: 'Carregando…',
    noRun: 'Nenhuma execução de processo encontrada para este módulo ainda.',
    taskOpened: 'task aberta',
};
const messages = { en: message_en, 'pt-br': message_ptbr };
/// **collab_i18n_end**
let WidgetNewSolutionResume102020 = class WidgetNewSolutionResume102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-new-solution-resume-102020 {
  display: block;
  font-size: 14px;
  color: var(--text-primary-color, #e2e2e2);
}
widget-new-solution-resume-102020 .ns-resume {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 8px 4px;
}
widget-new-solution-resume-102020 .ns-title {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}
widget-new-solution-resume-102020 .ns-state {
  padding: 16px;
  opacity: 0.8;
}
widget-new-solution-resume-102020 .ns-error {
  color: var(--error-color, #e57373);
}
widget-new-solution-resume-102020 .ns-muted {
  opacity: 0.65;
  margin: 4px 0;
}
widget-new-solution-resume-102020 .ns-section {
  border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
  border-radius: 8px;
  padding: 4px 10px;
  background: var(--bg-secondary-color, rgba(255, 255, 255, 0.03));
}
widget-new-solution-resume-102020 .ns-section-head {
  cursor: pointer;
  font-weight: 600;
  padding: 6px 0;
  user-select: none;
}
widget-new-solution-resume-102020 .ns-section-body {
  padding: 6px 0 10px;
}
widget-new-solution-resume-102020 .ns-prompt {
  white-space: pre-wrap;
  margin: 0 0 6px;
  line-height: 1.45;
}
widget-new-solution-resume-102020 .ns-link {
  background: none;
  border: none;
  color: var(--active-color, #4f9dff);
  cursor: pointer;
  padding: 0;
  font-size: 13px;
  text-decoration: underline;
}
widget-new-solution-resume-102020 .ns-list {
  margin: 0;
  padding-left: 18px;
}
widget-new-solution-resume-102020 .ns-list li {
  margin: 3px 0;
}
widget-new-solution-resume-102020 .ns-health-head {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 8px;
}
widget-new-solution-resume-102020 .ns-badge {
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
  font-weight: 600;
}
widget-new-solution-resume-102020 .ns-badge--ok {
  background: rgba(76, 175, 80, 0.18);
  color: #7ed085;
}
widget-new-solution-resume-102020 .ns-badge--bad {
  background: rgba(229, 115, 115, 0.18);
  color: #e57373;
}
widget-new-solution-resume-102020 .ns-counts {
  opacity: 0.8;
  font-size: 13px;
}
widget-new-solution-resume-102020 .ns-ready {
  font-size: 12px;
}
widget-new-solution-resume-102020 .ns-ready--ok {
  color: #7ed085;
}
widget-new-solution-resume-102020 .ns-ready--no {
  opacity: 0.7;
}
widget-new-solution-resume-102020 .ns-issues {
  margin: 4px 0;
  padding-left: 14px;
  list-style: none;
}
widget-new-solution-resume-102020 .ns-issues li {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 3px 0;
  border-left: 3px solid transparent;
  padding-left: 8px;
}
widget-new-solution-resume-102020 .ns-issues--error li {
  border-left-color: #e57373;
}
widget-new-solution-resume-102020 .ns-issues--warning li {
  border-left-color: #e0b040;
}
widget-new-solution-resume-102020 .ns-issue-code {
  font-family: monospace;
  font-size: 12px;
  opacity: 0.85;
}
widget-new-solution-resume-102020 .ns-issue-msg {
  flex: 1 1 200px;
}
widget-new-solution-resume-102020 .ns-issue-path {
  font-family: monospace;
  font-size: 11px;
  opacity: 0.6;
}
widget-new-solution-resume-102020 .ns-next {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
widget-new-solution-resume-102020 .ns-next-item {
  border: 1px solid var(--border-color, rgba(255, 255, 255, 0.1));
  border-radius: 6px;
  padding: 8px 10px;
}
widget-new-solution-resume-102020 .ns-next-item label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}
widget-new-solution-resume-102020 .ns-next-item--opened {
  opacity: 0.7;
}
widget-new-solution-resume-102020 .ns-next-kind {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  opacity: 0.6;
}
widget-new-solution-resume-102020 .ns-next-title {
  font-weight: 600;
}
widget-new-solution-resume-102020 .ns-next-desc {
  font-size: 13px;
  opacity: 0.8;
  margin: 4px 0 0 24px;
}
widget-new-solution-resume-102020 .ns-next-agent {
  font-family: monospace;
  font-size: 12px;
  opacity: 0.55;
  margin: 4px 0 0 24px;
}
widget-new-solution-resume-102020 .ns-next-opened {
  font-size: 12px;
  color: #7ed085;
  margin-left: 24px;
}
widget-new-solution-resume-102020 .ns-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  margin-top: 4px;
}
widget-new-solution-resume-102020 .ns-clear {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}
widget-new-solution-resume-102020 .ns-finish {
  padding: 8px 18px;
  border: none;
  border-radius: 6px;
  background: var(--active-color, #4f9dff);
  color: #fff;
  font-weight: 600;
  cursor: pointer;
}
widget-new-solution-resume-102020 .ns-finish:disabled {
  opacity: 0.5;
  cursor: default;
}
widget-new-solution-resume-102020 .ns-done {
  padding: 10px;
  border-radius: 6px;
  background: rgba(76, 175, 80, 0.15);
  color: #7ed085;
}
`);
        this.value = null;
        this._loading = true;
        this._run = null;
        this._health = null;
        this._clearTraces = true;
        this._selected = new Set();
        this._promptExpanded = false;
        this._finishing = false;
        this._finished = false;
        this._error = null;
        this._loadedFor = null;
    }
    async connectedCallback() {
        super.connectedCallback();
        await this._load();
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('value') && this.value && this.value.moduleId !== this._loadedFor) {
            void this._load();
        }
    }
    get _msg() {
        const lang = (this._run?.userLanguage || document.documentElement.lang || 'en').toLowerCase();
        return lang.startsWith('pt') ? messages['pt-br'] : messages.en;
    }
    // ── Load ────────────────────────────────────────────────────────────────────
    async _load() {
        if (!this.value)
            return;
        this._loadedFor = this.value.moduleId;
        this._loading = true;
        this._error = null;
        try {
            const process = await readNewSolutionProcess(this.value.moduleId);
            const run = process?.runs?.length
                ? (process.runs.find(r => r.runId === 'newSolution') || process.runs[process.runs.length - 1])
                : null;
            this._run = run;
            this._health = run?.healthReport || (await this._readHealthFallback());
            // Default: all still-pending next steps are selected.
            this._selected = new Set((run?.nextSteps || []).filter(s => s.status !== 'dismissed').map(s => s.id));
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._loading = false;
        }
    }
    async _readHealthFallback() {
        try {
            if (!this.value)
                return null;
            const fileInfo = {
                project: mls.actualProject || 0,
                level: 2,
                folder: `${this.value.moduleId}/trace`,
                shortName: 'plan-health-report',
                extension: '.json',
            };
            const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
            if (!file)
                return null;
            const raw = await file.getContent();
            if (typeof raw !== 'string')
                return null;
            const doc = JSON.parse(raw);
            return doc?.report || null;
        }
        catch {
            return null;
        }
    }
    // ── Render ──────────────────────────────────────────────────────────────────
    render() {
        const m = this._msg;
        if (this._loading)
            return html `<div class="ns-resume"><div class="ns-state">${m.loading}</div></div>`;
        if (this._error)
            return html `<div class="ns-resume"><div class="ns-state ns-error">${this._error}</div></div>`;
        if (!this._run)
            return html `<div class="ns-resume"><div class="ns-state">${m.noRun}</div></div>`;
        return html `
      <div class="ns-resume">
        <h3 class="ns-title">${m.title}</h3>
        ${this._renderPrompt()}
        ${this._renderDecisions()}
        ${this._renderOpenDetails()}
        ${this._renderHealth()}
        ${this._renderNextSteps()}
        ${this._renderActions()}
      </div>
    `;
    }
    _section(title, body, open = false) {
        return html `
      <details class="ns-section" ?open=${open}>
        <summary class="ns-section-head">${title}</summary>
        <div class="ns-section-body">${body}</div>
      </details>
    `;
    }
    _renderPrompt() {
        const m = this._msg;
        const text = this._run?.initialPrompt || '';
        const isLong = new TextEncoder().encode(text).length > SEE_MORE_BYTES;
        const shown = isLong && !this._promptExpanded ? `${text.slice(0, SEE_MORE_BYTES)}…` : text;
        const body = html `
      <p class="ns-prompt">${shown || m.none}</p>
      ${isLong ? html `
        <button class="ns-link" @click=${() => { this._promptExpanded = !this._promptExpanded; }}>
          ${this._promptExpanded ? m.seeLess : m.seeMore}
        </button>` : nothing}
    `;
        return this._section(m.prompt, body, true);
    }
    _renderDecisions() {
        const m = this._msg;
        const decisions = (this._run?.decisions || []);
        const body = decisions.length === 0
            ? html `<p class="ns-muted">${m.none}</p>`
            : html `<ul class="ns-list">${decisions.map(d => html `<li>${this._decisionLabel(d)}</li>`)}</ul>`;
        return this._section(`${m.decisions} (${decisions.length})`, body);
    }
    _decisionLabel(d) {
        if (typeof d === 'string')
            return d;
        const title = typeof d.title === 'string' ? d.title : '';
        const decided = typeof d.decidedPriority === 'string' ? ` — ${d.decidedPriority}` : '';
        return title ? `${title}${decided}` : JSON.stringify(d);
    }
    _renderOpenDetails() {
        const m = this._msg;
        const items = this._run?.openDetails || [];
        const body = items.length === 0
            ? html `<p class="ns-muted">${m.none}</p>`
            : html `<ul class="ns-list">${items.map(i => html `
          <li><strong>${i.title}</strong>${i.description ? html `: ${i.description}` : nothing}</li>`)}</ul>`;
        return this._section(`${m.openDetails} (${items.length})`, body);
    }
    _renderHealth() {
        const m = this._msg;
        const h = this._health;
        if (!h)
            return this._section(m.health, html `<p class="ns-muted">${m.none}</p>`);
        const summary = h.summary || {};
        const issues = h.issues || [];
        const errors = issues.filter(i => i.severity === 'error');
        const warnings = issues.filter(i => i.severity === 'warning');
        const passed = !!summary.passed;
        const body = html `
      <div class="ns-health-head">
        <span class="ns-badge ${passed ? 'ns-badge--ok' : 'ns-badge--bad'}">${passed ? m.passed : m.failed}</span>
        <span class="ns-counts">${summary.errorCount ?? errors.length} ${m.errors} · ${summary.warningCount ?? warnings.length} ${m.warnings}</span>
        <span class="ns-ready ${h.readyToSaveDefs ? 'ns-ready--ok' : 'ns-ready--no'}">${h.readyToSaveDefs ? m.readyToSave : m.notReady}</span>
      </div>
      ${this._renderIssues(errors, 'error')}
      ${this._renderIssues(warnings, 'warning')}
    `;
        return this._section(m.health, body, !passed);
    }
    _renderIssues(issues, severity) {
        if (issues.length === 0)
            return html ``;
        return html `
      <ul class="ns-issues ns-issues--${severity}">
        ${issues.map(i => html `
          <li>
            <span class="ns-issue-code">${i.code}</span>
            <span class="ns-issue-msg">${i.message}</span>
            ${i.path ? html `<span class="ns-issue-path">${i.path}</span>` : nothing}
          </li>`)}
      </ul>
    `;
    }
    _renderNextSteps() {
        const m = this._msg;
        const steps = this._run?.nextSteps || [];
        const body = steps.length === 0
            ? html `<p class="ns-muted">${m.none}</p>`
            : html `<ul class="ns-next">${steps.map(s => this._renderNextStep(s))}</ul>`;
        return this._section(`${m.nextSteps} (${steps.length})`, body, steps.length > 0);
    }
    _renderNextStep(step) {
        const m = this._msg;
        const mention = NEXT_STEP_AGENTS[step.kind] || '';
        const checked = this._selected.has(step.id);
        const opened = step.status === 'taskOpened';
        return html `
      <li class="ns-next-item ${opened ? 'ns-next-item--opened' : ''}">
        <label>
          <input
            type="checkbox"
            ?checked=${checked}
            ?disabled=${this._finishing || this._finished || opened}
            @change=${(e) => this._toggleStep(step.id, e.target.checked)}
          />
          <span class="ns-next-kind">${step.kind}</span>
          <span class="ns-next-title">${step.title}</span>
        </label>
        ${step.description ? html `<div class="ns-next-desc">${step.description}</div>` : nothing}
        <div class="ns-next-agent">${mention ? `${mention} …` : '@@… '}</div>
        ${opened ? html `<span class="ns-next-opened">${m.taskOpened}${step.taskId ? `: ${step.taskId}` : ''}</span>` : nothing}
      </li>
    `;
    }
    _renderActions() {
        const m = this._msg;
        // View/maintenance mode: the run already finished (reopened via the step list). No "Encerrar".
        if (this._finished || this._run?.finishedAt)
            return html `<div class="ns-done">${m.finished}</div>`;
        return html `
      <div class="ns-actions">
        <label class="ns-clear">
          <input
            type="checkbox"
            ?checked=${this._clearTraces}
            ?disabled=${this._finishing}
            @change=${(e) => { this._clearTraces = e.target.checked; }}
          />
          ${m.clearTraces}
        </label>
        <button class="ns-finish" ?disabled=${this._finishing} @click=${() => this._onFinish()}>
          ${this._finishing ? m.finishing : m.finish}
        </button>
      </div>
    `;
    }
    // ── Events ──────────────────────────────────────────────────────────────────
    _toggleStep(id, checked) {
        const next = new Set(this._selected);
        if (checked)
            next.add(id);
        else
            next.delete(id);
        this._selected = next;
    }
    async _onFinish() {
        if (!this.value || !this._run || this._finishing)
            return;
        this._finishing = true;
        try {
            const run = this._run;
            const moduleId = this.value.moduleId;
            // 1. Open a task for each selected next step; mark the rest dismissed. (Permanent record.)
            for (const step of run.nextSteps) {
                if (step.status === 'taskOpened')
                    continue;
                if (this._selected.has(step.id)) {
                    const taskId = await this._openNextStepTask(step);
                    step.status = 'taskOpened';
                    if (taskId)
                        step.taskId = taskId;
                }
                else {
                    step.status = 'dismissed';
                }
            }
            run.finishedAt = new Date().toISOString();
            await writeNewSolutionProcessRun(moduleId, run);
            // 2. Clear traces (after permanent files are written). Default deletes l2/{module}/trace/*.
            if (this._clearTraces) {
                await deleteNewSolutionTraceFolder(moduleId);
            }
            // 3. Complete the "Dados finais" clarification step (and clean its input/output).
            const ret = await this._completeClarificationStep();
            // 4. Clean leftover step inputs/outputs now that everything permanent is saved.
            if (ret?.task)
                await this._cleanLeftoverPayloads(ret.task);
            // 5. Close the root agentNewSolution step — the flow ends here. Coverage no longer closes it
            // (the final "Revendo plano" step is sequential, so the flow continues to this screen).
            if (ret?.task)
                await this._closeRoot(ret.task);
            this._finished = true;
            this._run = { ...run };
        }
        catch (error) {
            this._error = error instanceof Error ? error.message : String(error);
        }
        finally {
            this._finishing = false;
        }
    }
    async _openNextStepTask(step) {
        try {
            const mention = NEXT_STEP_AGENTS[step.kind] || '';
            const prompt = `${mention} ${step.title}: ${step.description}`.trim();
            const thread = await createThread(`newSolution:${this.value.moduleId}:${step.id}`, [], 'company');
            if (!thread)
                return undefined;
            const userId = getUserId();
            if (!userId)
                return undefined;
            const context = getTemporaryContext(thread.threadId, userId, prompt);
            const agentName = mention.startsWith('@@') ? mention.slice(2).trim().split(/\s+/)[0] : '';
            if (agentName) {
                const agent = await loadAgent(agentName);
                if (agent)
                    await executeBeforePrompt(agent, context);
            }
            setTimeout(() => {
                mls.events?.fire?.([2], ['collabMessages'], JSON.stringify({ type: 'thread-open', threadId: thread.threadId, taskId: '' }));
            }, 300);
            return thread.threadId;
        }
        catch (error) {
            console.warn('[widgetNewSolutionResume](openNextStepTask) failed', error);
            return undefined;
        }
    }
    async _completeClarificationStep() {
        const v = this.value;
        const intent = {
            type: 'update-status',
            hookSequential: v.hookSequential ?? 0,
            messageId: v.messageId,
            threadId: v.threadId,
            taskId: v.taskId,
            parentStepId: v.parentStepId,
            stepId: v.stepId,
            status: 'completed',
            cleaner: 'input_output',
        };
        const response = await mls.api.msgApplyIntents({ userId: v.senderId, intents: [intent] });
        if (!response || response.statusCode !== 200) {
            throw new Error(response?.msg || 'Error finishing resume step');
        }
        const ret = response;
        await this._continuePooling(ret);
        return ret;
    }
    // Issue cleaner='input_output' for every completed step that still carries a payload, except the
    // root agentNewSolution step (its flexible payload holds moduleName/prompt, reused on reopen).
    async _cleanLeftoverPayloads(task) {
        try {
            const v = this.value;
            const tree = task.iaCompressed?.nextSteps || [];
            const parentOf = this._buildParentMap(tree);
            const intents = [];
            for (const step of getAllSteps(tree)) {
                const s = step;
                if (s.stepId === v.stepId)
                    continue;
                if (s.status !== 'completed')
                    continue;
                if (!s.interaction?.payload)
                    continue;
                if (s.type === 'agent' && s.agentName === 'agentNewSolution')
                    continue;
                const parentStepId = parentOf.get(s.stepId);
                if (parentStepId === undefined)
                    continue;
                intents.push({
                    type: 'update-status',
                    hookSequential: 0,
                    messageId: v.messageId,
                    threadId: v.threadId,
                    taskId: v.taskId,
                    parentStepId,
                    stepId: s.stepId,
                    status: 'completed',
                    cleaner: 'input_output',
                });
            }
            if (intents.length === 0)
                return;
            await mls.api.msgApplyIntents({ userId: v.senderId, intents });
        }
        catch (error) {
            console.warn('[widgetNewSolutionResume](cleanLeftoverPayloads) failed', error);
        }
    }
    // Completes the root agentNewSolution step (plan-only flow ends at this screen). It is a
    // top-level agent step, so intentUpdateStatus uses self-parent (its own stepId) as the agent
    // parent — same pattern agentNewSolution uses for its own status updates.
    async _closeRoot(task) {
        try {
            const v = this.value;
            const root = getAllSteps(task.iaCompressed?.nextSteps || []).find(s => s.type === 'agent' && s.agentName === 'agentNewSolution');
            if (!root || root.status === 'completed')
                return;
            await mls.api.msgApplyIntents({
                userId: v.senderId,
                intents: [{
                        type: 'update-status',
                        hookSequential: 0,
                        messageId: v.messageId,
                        threadId: v.threadId,
                        taskId: v.taskId,
                        parentStepId: root.stepId,
                        stepId: root.stepId,
                        status: 'completed',
                        traceMsg: 'plan-only: root agentNewSolution closed after the final resume screen (Encerrar).',
                    }],
            });
        }
        catch (error) {
            console.warn('[widgetNewSolutionResume](closeRoot) failed', error);
        }
    }
    _buildParentMap(tree) {
        const map = new Map();
        const walk = (nodes, parentId) => {
            for (const node of nodes) {
                const id = node.stepId;
                if (parentId !== null)
                    map.set(id, parentId);
                const children = node.nextSteps || [];
                if (children.length)
                    walk(children, id);
            }
        };
        walk(tree, null);
        return map;
    }
    async _continuePooling(ret) {
        try {
            const queue = ret.task?.iaCompressed?.queueFrontEnd || [];
            const hasHook = queue.some(hook => hook.type !== 'pooling');
            if (!hasHook)
                return;
            const context = { message: ret.message, task: ret.task };
            await continuePoolingTask(context);
        }
        catch (error) {
            console.warn('[widgetNewSolutionResume](continuePooling) failed', error);
        }
    }
};
__decorate([
    property({ type: Object })
], WidgetNewSolutionResume102020.prototype, "value", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_loading", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_run", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_health", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_clearTraces", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_selected", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_promptExpanded", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_finishing", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_finished", void 0);
__decorate([
    state()
], WidgetNewSolutionResume102020.prototype, "_error", void 0);
WidgetNewSolutionResume102020 = __decorate([
    customElement('widget-new-solution-resume-102020')
], WidgetNewSolutionResume102020);
export { WidgetNewSolutionResume102020 };
