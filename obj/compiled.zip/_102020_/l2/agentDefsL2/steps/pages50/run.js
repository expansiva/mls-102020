/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/run.ts" enhancement="_blank"/>
import { sha256Text } from '/_102020_/l2/agentDefsL2/steps/contracts30/run.js';
import { readD2Input } from '/_102020_/l2/agentDefsL2/steps/input20/io.js';
import { readD2SharedManifest, readD2SharedSource } from '/_102020_/l2/agentDefsL2/steps/shared40/io.js';
import { assertD2MoleculeCandidates, resolveD2MoleculeSelection } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.js';
import { D2_PAGE_TECHNICAL_SKILL, d2PageUnitContextHash, resolveD2PageCategory } from '/_102020_/l2/agentDefsL2/steps/pages50/categoryContext.js';
import { D2_PAGES_VERSION } from '/_102020_/l2/agentDefsL2/steps/pages50/contracts.js';
import { gateD2Pages } from '/_102020_/l2/agentDefsL2/steps/pages50/gate.js';
import { assertD2RenderedPage, renderD2Page } from '/_102020_/l2/agentDefsL2/steps/pages50/render.js';
import { d2PageDisplayPath, readD2PageSource, readD2PagesResult, writeD2PageSource, writeD2PagesManifest, writeD2PagesResult } from '/_102020_/l2/agentDefsL2/steps/pages50/io.js';
export async function getD2PagesContext(identity, snapshot, pageId) {
    const page = snapshot.selection.pages.find(item => item.pageId === pageId && snapshot.selection.writePageIds.includes(item.pageId));
    if (!page)
        throw new Error(`D2_PAGES_PAGE_NOT_SELECTED: ${pageId}`);
    const source = await readD2SharedSource(identity, pageId);
    const match = /export const definition = ([\s\S]*?) as const;/.exec(source);
    if (!match)
        throw new Error(`D2_PAGES_SHARED_INVALID: ${pageId}`);
    let shared;
    try {
        shared = JSON.parse(match[1]);
    }
    catch {
        throw new Error(`D2_PAGES_SHARED_INVALID: ${pageId}`);
    }
    return { page, shared };
}
export async function approveD2PagesUnit(identity, snapshot, pageId, judgment, inventory, port, pageSkills, attempt, verifySources = async () => undefined) {
    const dependency = await assertD2PagesDependencies(identity, snapshot, pageId, verifySources);
    const { page, shared } = await getD2PagesContext(identity, snapshot, pageId);
    const requested = [...new Set(judgment.presentations.flatMap(item => item.groupIds))];
    const molecules = await resolveD2MoleculeSelection(port, inventory, requested);
    assertD2MoleculeCandidates(molecules, judgment.presentations.flatMap(item => item.moleculeRecommendations));
    const groupSkills = new Map(molecules.groups.map(group => [group.groupId, [group.indexPipelineReference, group.usageContractPipelineReference]]));
    const groupCandidates = new Map(molecules.groups.map(group => [group.groupId, new Set(group.molecules.map(item => item.tag))]));
    const rendered = gateD2Pages(identity.module, page, shared, judgment, groupSkills, pageSkills, groupCandidates);
    const sources = Object.fromEntries(rendered.map(item => { const source = renderD2Page(item); assertD2RenderedPage(source); return [item.device, source]; }));
    const category = resolveD2PageCategory(pageSkills, judgment.category.categoryRef);
    const skillHashes = { [D2_PAGE_TECHNICAL_SKILL]: pageSkills.skillHashes[D2_PAGE_TECHNICAL_SKILL], [category.skillReference]: pageSkills.skillHashes[category.skillReference] };
    const moleculeRecommendations = Object.fromEntries(judgment.presentations.map(item => [item.device, { reason: item.moleculeReason, recommendations: item.moleculeRecommendations }]));
    return persistD2PagesUnit(identity, snapshot, pageId, sources, rendered.map(item => item.pipeline[0].id), attempt, dependency.sourceHash, verifySources, { contextHash: await d2PageUnitContextHash(pageSkills, judgment.category.categoryRef), catalogHash: pageSkills.catalogHash, skillHashes, categoryRef: judgment.category.categoryRef, categoryReason: judgment.category.reason, categoryEvidenceRefs: judgment.category.evidenceRefs, moleculeRecommendations });
}
const DIRECT_RECEIPT = { contextHash: 'direct-test-context', catalogHash: 'direct-test-catalog', skillHashes: {}, categoryRef: 'bespoke', categoryReason: 'Direct persistence fixture.', categoryEvidenceRefs: ['fixture'], moleculeRecommendations: { desktop: { reason: 'fixture', recommendations: [] }, mobile: { reason: 'fixture', recommendations: [] } } };
export async function persistD2PagesUnit(identity, snapshot, pageId, sources, itemIds, attempt, expectedSharedHash, verifySources = async () => undefined, receipt = DIRECT_RECEIPT) {
    const dependency = await assertD2PagesDependencies(identity, snapshot, pageId, verifySources);
    if (expectedSharedHash && dependency.sourceHash !== expectedSharedHash)
        throw new Error(`D2_PAGES_SHARED_CHANGED: ${pageId}`);
    const prior = await readD2PagesResult(identity, pageId);
    if (prior?.status === 'approved' && prior.snapshotHash === snapshot.snapshotHash && prior.contextHash === receipt.contextHash) {
        for (const device of ['desktop', 'mobile']) {
            if (await sha256Text(await readD2PageSource(identity, pageId, device)) !== prior.sourceHashes[device])
                throw new Error(`D2_PAGES_APPROVED_SOURCE_CHANGED: ${pageId}/${device}`);
        }
        return prior;
    }
    const sourceHashes = { desktop: await sha256Text(sources.desktop), mobile: await sha256Text(sources.mobile) };
    for (const device of ['desktop', 'mobile']) {
        await assertD2PagesDependencies(identity, snapshot, pageId, verifySources);
        if (await sha256Text(await readD2PageSource(identity, pageId, device)) !== sourceHashes[device])
            await writeD2PageSource(identity, pageId, device, sources[device]);
        if (await sha256Text(await readD2PageSource(identity, pageId, device)) !== sourceHashes[device])
            throw new Error(`D2_PAGES_WRITE_HASH_MISMATCH: ${pageId}/${device}`);
    }
    await assertD2PagesDependencies(identity, snapshot, pageId, verifySources);
    const result = { schemaVersion: D2_PAGES_VERSION, ...identity, pageId, status: 'approved', snapshotHash: snapshot.snapshotHash, sharedHash: dependency.sourceHash, ...receipt, sourceHashes, artifactPaths: { desktop: d2PageDisplayPath(identity, pageId, 'desktop'), mobile: d2PageDisplayPath(identity, pageId, 'mobile') }, pipelineItemIds: { desktop: itemIds[0], mobile: itemIds[1] }, attempts: attempt };
    await writeD2PagesResult(identity, result);
    return result;
}
export async function findReusableD2PagesUnits(identity, snapshot, verifySources = async () => undefined, expectedContext) {
    const units = [];
    await assertSnapshot(identity, snapshot.snapshotHash);
    await verifySources();
    for (const pageId of [...snapshot.selection.writePageIds].sort()) {
        const dependency = await assertD2PagesDependencies(identity, snapshot, pageId, verifySources);
        const unit = await readD2PagesResult(identity, pageId);
        if (!unit || unit.status !== 'approved' || unit.snapshotHash !== snapshot.snapshotHash || unit.sharedHash !== dependency.sourceHash)
            continue;
        let expectedContextHash = typeof expectedContext === 'string' ? expectedContext : undefined;
        if (expectedContext && typeof expectedContext !== 'string') {
            try {
                expectedContextHash = await d2PageUnitContextHash(expectedContext, unit.categoryRef);
            }
            catch {
                continue;
            }
        }
        if (expectedContextHash !== undefined && unit.contextHash !== expectedContextHash)
            continue;
        let valid = true;
        for (const device of ['desktop', 'mobile']) {
            if (await sha256Text(await readD2PageSource(identity, pageId, device)) !== unit.sourceHashes?.[device])
                valid = false;
        }
        if (!valid)
            continue;
        units.push(unit);
    }
    await assertSnapshot(identity, snapshot.snapshotHash);
    await verifySources();
    await assertSnapshot(identity, snapshot.snapshotHash);
    return units;
}
export async function finalizeD2PagesBarrier(identity, snapshot, verifySources = async () => undefined, expectedContext) {
    const units = await findReusableD2PagesUnits(identity, snapshot, verifySources, expectedContext);
    if (units.length !== snapshot.selection.writePageIds.length)
        return null;
    await assertSnapshot(identity, snapshot.snapshotHash);
    await verifySources();
    await assertSnapshot(identity, snapshot.snapshotHash);
    for (const unit of units) {
        const dependency = await assertD2PagesDependencies(identity, snapshot, unit.pageId, verifySources);
        if (dependency.sourceHash !== unit.sharedHash)
            return null;
        for (const device of ['desktop', 'mobile'])
            if (await sha256Text(await readD2PageSource(identity, unit.pageId, device)) !== unit.sourceHashes[device])
                return null;
    }
    const manifest = { schemaVersion: D2_PAGES_VERSION, ...identity, status: 'approved', snapshotHash: snapshot.snapshotHash, units };
    await writeD2PagesManifest(identity, manifest);
    return manifest;
}
export async function assertD2PagesDependencies(identity, snapshot, pageId, verifySources = async () => undefined) {
    await assertSnapshot(identity, snapshot.snapshotHash);
    await verifySources();
    await assertSnapshot(identity, snapshot.snapshotHash);
    const manifest = await readD2SharedManifest(identity);
    const unit = manifest?.units.find(item => item.pageId === pageId);
    if (!manifest || manifest.status !== 'approved' || manifest.snapshotHash !== snapshot.snapshotHash || !unit)
        throw new Error(`D2_PAGES_SHARED_BARRIER_MISSING: ${pageId}`);
    const sourceHash = await sha256Text(await readD2SharedSource(identity, pageId));
    if (sourceHash !== unit.sourceHash)
        throw new Error(`D2_PAGES_SHARED_HASH_MISMATCH: ${pageId}`);
    return { unit, sourceHash };
}
async function assertSnapshot(identity, hash) { if ((await readD2Input(identity))?.snapshotHash !== hash)
    throw new Error('D2_PAGES_STALE_RUN'); }
