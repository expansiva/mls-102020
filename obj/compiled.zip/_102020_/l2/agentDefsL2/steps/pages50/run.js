/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/run.ts" enhancement="_blank"/>
import { readJson, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { buildD2Page11WithExperience, gateD2Page11, gateD2Page11Pair } from '/_102020_/l2/agentDefsL2/helpers/page11Gate.js';
import { renderD2Page11Definition } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import { gateD2MoleculeRoles, moleculeDecisionContext } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeSelection.js';
export const D2_PAGES_VERSION = '2026-09-30-agent-defs-l2-pages-v2';
export const D2_PAGE11_NEEDS_VERSION = '2026-09-30-agent-defs-l2-page11-needs-v1';
export const D2_PAGES_PROMPT_LIMIT_CHARS = 160000;
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function menuOrigins(page, definition) {
    const assigned = new Set();
    return page.organisms.map((raw, sourceIndex) => {
        const item = record(raw);
        const kind = text(item.kind);
        const organismId = definition ? Object.entries(definition.organisms).find(([id, value]) => value.kind === kind && !assigned.has(id))?.[0] ?? '' : `organism${sourceIndex + 1}`;
        assigned.add(organismId);
        return { organismId, sourceIndex, kind, text: text(item.text) };
    });
}
function owned(identity, pageId) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/pages50`, shortName: pageId, extension: '.json' }; }
export function sourceInfo(identity, pageId, device) { return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' }; }
export function needsInfo(identity, pageId, device) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' }; }
/** A page fingerprint avoids invalidating its receipt when another page changes. */
export async function pageUnitInputHash(context) {
    const { page, artifacts } = context;
    const needsPage = record(artifacts.needs).pages?.find(item => text(record(item).pageId) === page.pageId) ?? null;
    const contextText = JSON.stringify({ page, needsPage });
    const entities = Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => contextText.includes(id)));
    const journeys = Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]]));
    const entityIds = new Set(Object.keys(entities));
    for (const row of [...page.reads, ...page.writes, ...(record(needsPage).reads ?? []), ...(record(needsPage).writes ?? [])]) {
        const entity = text(record(row).entity);
        if (entity)
            entityIds.add(entity);
    }
    for (const binding of page.operationBindings ?? [])
        entityIds.add(binding.entityId);
    const actors = new Set(page.actors);
    const grants = (record(artifacts.access).grants ?? [])
        .filter(raw => actors.has(text(record(raw).actorRef)) && (record(raw).entityRefs ?? []).some(id => entityIds.has(text(id))))
        .map(raw => {
        const grant = record(raw);
        const disclosure = record(grant.disclosure);
        return canonicalValue({ ...grant,
            entityRefs: [...(grant.entityRefs ?? [])].sort(),
            disclosure: { ...disclosure,
                ...(Array.isArray(disclosure.allowedFields) ? { allowedFields: [...disclosure.allowedFields].sort() } : {}),
                ...(Array.isArray(disclosure.deniedFields) ? { deniedFields: [...disclosure.deniedFields].sort() } : {}),
            }, });
    })
        .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
    return sha256Text(JSON.stringify(canonicalValue({ page, needsPage, entities, journeys,
        userLanguage: text(record(artifacts.menu).userLanguage) || 'en', grants })));
}
function canonicalValue(value) {
    if (Array.isArray(value))
        return value.map(canonicalValue);
    if (value && typeof value === 'object') {
        const source = value;
        return Object.fromEntries(Object.keys(source).sort().map(key => [key, canonicalValue(source[key])]));
    }
    return value;
}
export function buildD2PagesDecisionPrompt(context, repair) {
    const { page, artifacts } = context;
    const payload = {
        page: { pageId: page.pageId, label: page.label, actors: page.actors, authorityRefs: page.authorityRefs,
            ancestors: page.ancestors, organisms: menuOrigins(page), reads: page.reads, writes: page.writes,
            journeys: Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]])),
            userLanguage: text(record(artifacts.menu).userLanguage) || 'en' },
        menu: artifacts.menu, needs: artifacts.needs,
        ontology: Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => JSON.stringify([page.reads, page.writes, page.organisms]).includes(id))),
        access: artifacts.access, categories: context.template.categories,
        designSystem: context.designSystem,
        moleculeResearch: JSON.parse(moleculeDecisionContext(context.selectedGroups, context.groups)),
        repair: repair ?? null,
    };
    const prompt = JSON.stringify(payload);
    if (prompt.length > D2_PAGES_PROMPT_LIMIT_CHARS)
        throw new Error(`D2_PAGE11_PROMPT_LIMIT: ${prompt.length} > ${D2_PAGES_PROMPT_LIMIT_CHARS}`);
    return { prompt, chars: prompt.length };
}
const productionWriter = { writeSource: writeSourceText, writeJson };
export async function approveD2PagesUnit(context, raw, promptChars, repairPromptChars = 0, writer = productionWriter) {
    const category = text(record(record(raw.desktop).definition).template && record(record(record(raw.desktop).definition).template).category);
    if (!category || category !== text(record(record(record(raw.mobile).definition).template).category))
        throw new Error('D2_PAGE11_DEVICE_CATEGORY');
    if (!text(raw.categoryReason))
        throw new Error('D2_PAGE11_CATEGORY_REASON');
    const selectedTemplate = await context.template.select(category);
    const definitions = {
        desktop: buildD2Page11WithExperience(raw.desktop.definition, context.template.categories),
        mobile: buildD2Page11WithExperience(raw.mobile.definition, context.template.categories),
    };
    const needs = { desktop: buildD2Page11Needs(raw.desktop.needs), mobile: buildD2Page11Needs(raw.mobile.needs) };
    const menu = context.artifacts.menu;
    const needPages = record(context.artifacts.needs).pages;
    if (!Array.isArray(needPages))
        throw new Error('D2_PAGE11_SOURCE_NEEDS');
    const sources = { pageId: context.page.pageId, actor: context.page.actors[0], menu,
        needsPages: needPages, entities: context.artifacts.entities,
        access: context.artifacts.access, categories: context.template.categories,
        templatePaths: context.template.templatePaths, moleculeTags: new Set(context.groups.flatMap(group => group.tags)),
        promptTokens: Math.ceil(Math.max(promptChars, repairPromptChars) / 4) };
    const origins = menuOrigins(context.page, definitions.desktop);
    const groupsByOrganism = Object.fromEntries(origins.map(origin => [origin.organismId, context.selectedGroups[`organism${origin.sourceIndex + 1}`] ?? []]));
    if (!context.page.actors.length)
        throw new Error('D2_PAGE11_ACTOR_MISSING');
    const kindMismatch = Object.keys(definitions.desktop.organisms).filter(id => definitions.mobile.organisms[id]?.kind !== definitions.desktop.organisms[id].kind);
    const issues = [...gateD2Page11Pair(definitions.desktop, definitions.mobile),
        ...kindMismatch.map(id => ({ code: 'D2_PAGE11_DEVICE_KIND', path: `organisms.${id}`, message: `Organism ${id} has different kinds across devices.` })),
        ...['desktop', 'mobile'].flatMap(device => [
            ...context.page.actors.flatMap(actor => gateD2Page11(definitions[device], needs[device], { ...sources, actor })),
            ...gateD2MoleculeRoles(definitions[device].molecules, groupsByOrganism, context.groups).map(message => ({ code: 'D2_MOLECULE_ROLE_UNSELECTED', path: device, message })),
        ])];
    if (issues.length)
        throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    if (origins.some(origin => !origin.organismId))
        throw new Error('D2_PAGE11_MENU_ORIGIN_MISSING');
    const sourcesText = Object.fromEntries(['desktop', 'mobile'].map(device => [device, renderD2Page11Definition({ ...context.identity, pageId: context.page.pageId, device }, definitions[device])]));
    const needsText = Object.fromEntries(['desktop', 'mobile'].map(device => [device, JSON.stringify(needs[device])]));
    const receipt = {
        schemaVersion: D2_PAGES_VERSION, needsVersion: D2_PAGE11_NEEDS_VERSION, ...context.identity, pageId: context.page.pageId,
        inputHash: context.snapshot.snapshotHash,
        unitInputHash: await pageUnitInputHash(context),
        template: { category, experience: selectedTemplate.experience, reason: `${raw.categoryReason} ${selectedTemplate.reason}`, reference: selectedTemplate.reference, hash: selectedTemplate.hash, catalogHash: await sha256Text(context.template.catalog) },
        designSystemHash: await sha256Text(context.designSystem),
        moleculeInventoryHash: context.inventory.sourceHash, moleculeHashes: context.moleculeHashes, moleculeGroupAssessments: context.groupAssessments,
        skillHash: await sha256Text(context.skill), promptHash: await sha256Text(context.prompt), promptChars, repairPromptChars,
        sourceHashes: { desktop: await sha256Text(sourcesText.desktop), mobile: await sha256Text(sourcesText.mobile) },
        needsHashes: { desktop: await sha256Text(needsText.desktop), mobile: await sha256Text(needsText.mobile) },
        menuOrigins: origins,
    };
    for (const device of ['desktop', 'mobile']) {
        await writer.writeSource(sourceInfo(context.identity, context.page.pageId, device), sourcesText[device]);
        await writer.writeJson(needsInfo(context.identity, context.page.pageId, device), needs[device]);
    }
    await writer.writeJson(owned(context.identity, context.page.pageId), receipt);
    return receipt;
}
export async function readD2PagesReceipt(identity, pageId) { return readJson(owned(identity, pageId)); }
