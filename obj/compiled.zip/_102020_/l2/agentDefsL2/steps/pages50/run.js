/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/run.ts" enhancement="_blank"/>
import { readJson, readSourceText, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { grantShowsPath } from '/_102020_/l2/helpers/defsInput/grantDisclosure.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { d2NormalizeWriteKey, d2WriteKey } from '/_102020_/l2/helpers/defsInput/writeKey.js';
import { buildD2Page11WithExperience, parseD2Page11TemplateReference, gateD2Page11, gateD2Page11Pair } from '/_102020_/l2/agentDefsL2/helpers/page11Gate.js';
import { d2Page11KeepingHistory, renderD2Page11Definition } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import { d2BffL4Slice } from '/_102020_/l2/agentDefsL2/helpers/d2Bff.js';
import { gateD2MoleculeRoles, moleculeDecisionContext } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeSelection.js';
export const D2_PAGES_VERSION = '2026-09-30-agent-defs-l2-pages-v2.1';
export const D2_PAGE11_NEEDS_VERSION = '2026-09-30-agent-defs-l2-page11-needs-v1';
export const D2_PAGES_PROMPT_LIMIT_CHARS = 640000;
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function menuOrigins(page, definition) {
    const assigned = new Set();
    return page.organisms.map((raw, sourceIndex) => {
        const item = record(raw);
        const kind = text(item.kind);
        const organismId = definition ? Object.entries(definition.organisms).find(([id, value]) => value.kind === kind && !assigned.has(id))?.[0] ?? '' : `organism${sourceIndex + 1}`;
        assigned.add(organismId);
        return { organismId, sourceIndex, kind, text: text(item.text) };
    });
}
function owned(identity, pageId) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/pages50`, shortName: pageId, extension: '.json' }; }
export function sourceInfo(identity, pageId, device) { return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' }; }
export function needsInfo(identity, pageId, device) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' }; }
/** A page fingerprint avoids invalidating its receipt when another page changes. */
export async function pageUnitInputHash(context) {
    const { page, artifacts } = context;
    const needsPage = record(artifacts.needs).pages?.find(item => text(record(item).pageId) === page.pageId) ?? null;
    const contextText = JSON.stringify({ page, needsPage });
    const entities = Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => contextText.includes(id)));
    const journeys = Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]]));
    const entityIds = new Set(Object.keys(entities));
    for (const row of [...page.reads, ...page.writes, ...(record(needsPage).reads ?? []), ...(record(needsPage).writes ?? [])]) {
        const entity = text(record(row).entity);
        if (entity)
            entityIds.add(entity);
    }
    for (const binding of page.operationBindings ?? [])
        entityIds.add(binding.entityId);
    const actors = new Set(page.actors);
    const grants = (record(artifacts.access).grants ?? [])
        .filter(raw => actors.has(text(record(raw).actorRef)) && (record(raw).entityRefs ?? []).some(id => entityIds.has(text(id))))
        .map(raw => {
        const grant = record(raw);
        const disclosure = record(grant.disclosure);
        return canonicalValue({ ...grant,
            entityRefs: [...(grant.entityRefs ?? [])].sort(),
            disclosure: { ...disclosure,
                ...(Array.isArray(disclosure.allowedFields) ? { allowedFields: [...disclosure.allowedFields].sort() } : {}),
                ...(Array.isArray(disclosure.deniedFields) ? { deniedFields: [...disclosure.deniedFields].sort() } : {}),
            }, });
    })
        .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
    return sha256Text(JSON.stringify(canonicalValue({ page, needsPage, entities, journeys,
        userLanguage: text(record(artifacts.menu).userLanguage) || 'en', grants })));
}
function canonicalValue(value) {
    if (Array.isArray(value))
        return value.map(canonicalValue);
    if (value && typeof value === 'object') {
        const source = value;
        return Object.fromEntries(Object.keys(source).sort().map(key => [key, canonicalValue(source[key])]));
    }
    return value;
}
export function d2PageChoiceEnums(context) {
    const pageIds = [];
    const walk = (nodes) => {
        for (const raw of nodes) {
            const node = record(raw);
            if (text(node.kind) === 'page' && text(node.id))
                pageIds.push(text(node.id));
            walk(Array.isArray(node.children) ? node.children : []);
        }
    };
    walk(Array.isArray(record(context.artifacts.menu).tree) ? record(context.artifacts.menu).tree : []);
    return {
        writeKeys: d2PageWriteKeys(context.page),
        categories: [...context.template.categories.filter(item => item.experiences?.page11 || item.experiences?.page21).map(item => item.categoryId), 'bespoke'],
        kinds: [...new Set(context.page.organisms.map(raw => text(record(raw).kind)).filter(Boolean))],
        // A submit has no target: '' is the value for it.
        targets: ['', ...new Set(pageIds)],
        tags: [...new Set(context.groups.flatMap(group => group.tags))],
    };
}
/** The exact write keys of the page; a submit writes one of them (schema enum and prompt list). */
export function d2PageWriteKeys(page) {
    return [...new Set(page.writes.map(raw => {
            const row = record(raw);
            return d2WriteKey({ entity: text(row.entity), operation: text(row.operation), transitionRef: text(row.transitionRef) });
        }))];
}
function pageWrites(page) {
    return page.writes.map(raw => { const row = record(raw); return { entity: text(row.entity), operation: text(row.operation), transitionRef: text(row.transitionRef) }; });
}
/** `Entity.transition` from the answer resolves to the page's only transition of that entity, or is refused naming the keys. */
function normalizeSubmitWrites(needs, writes) {
    const root = record(needs);
    const organisms = record(root.organisms);
    return { ...root, organisms: Object.fromEntries(Object.entries(organisms).map(([id, raw]) => {
            const unit = record(raw);
            const submits = Array.isArray(unit.submits) ? unit.submits.map(item => {
                const submit = record(item);
                return typeof submit.write === 'string' ? { ...submit, write: d2NormalizeWriteKey(submit.write, writes) } : submit;
            }) : unit.submits;
            return [id, { ...unit, submits }];
        })) };
}
/** One entity on the page: bare paths gain its prefix. A read no page actor can see is dropped; edits stay. */
export function normalizeNeedsPaths(needs, page, entities, grants) {
    void entities;
    const cited = new Set();
    for (const row of [...page.reads, ...page.writes]) {
        const entity = text(record(row).entity);
        if (entity)
            cited.add(entity);
    }
    const only = cited.size === 1 ? [...cited][0] : '';
    const prefixed = [];
    const removed = [];
    const root = record(needs);
    const organisms = record(root.organisms);
    const next = { ...root, organisms: Object.fromEntries(Object.entries(organisms).map(([id, raw]) => {
            const unit = record(raw);
            const list = (key, dropUnseen) => {
                if (!Array.isArray(unit[key]))
                    return unit[key];
                const kept = [];
                for (const item of unit[key]) {
                    if (typeof item !== 'string') {
                        kept.push(item);
                        continue;
                    }
                    const path = only && !/^[A-Z]/u.test(item) ? `${only}.${item}` : item;
                    if (path !== item)
                        prefixed.push(path);
                    const entityId = path.split('.')[0];
                    if (dropUnseen && /^[A-Z]/u.test(path) && !page.actors.some(actor => grants.some(rawGrant => {
                        const grant = record(rawGrant);
                        if (text(grant.actorRef) !== actor)
                            return false;
                        if (!(grant.entityRefs ?? []).some(ref => text(ref) === entityId))
                            return false;
                        const disclosure = record(grant.disclosure);
                        return grantShowsPath({
                            mode: text(disclosure.mode),
                            ...(Array.isArray(disclosure.allowedFields) ? { allowedFields: disclosure.allowedFields.map(text) } : {}),
                            ...(Array.isArray(disclosure.deniedFields) ? { deniedFields: disclosure.deniedFields.map(text) } : {}),
                        }, path);
                    }))) {
                        removed.push(path);
                        continue;
                    }
                    kept.push(path);
                }
                return kept;
            };
            return [id, { ...unit, reads: list('reads', true), edits: list('edits', false) }];
        })) };
    console.info(`pages50 ${page.pageId}: prefixed ${JSON.stringify(prefixed)}; removed ${JSON.stringify(removed)}`);
    return next;
}
export function buildD2PagesDecisionPrompt(context, repair, approved) {
    const { page, artifacts } = context;
    const payload = {
        page: { pageId: page.pageId, label: page.label, actors: page.actors, authorityRefs: page.authorityRefs,
            ancestors: page.ancestors, organisms: menuOrigins(page), reads: page.reads, writes: page.writes, writeKeys: d2PageWriteKeys(page),
            journeys: Object.fromEntries(page.journeyRefs.map(id => [id, artifacts.journeys[id]])),
            userLanguage: text(record(artifacts.menu).userLanguage) || 'en' },
        menu: artifacts.menu,
        // Other pages only matter for the writes a navigate may cover; this page keeps its full needs.
        needs: { pages: (record(artifacts.needs).pages ?? []).map(raw => {
                const row = record(raw);
                return text(row.pageId) === page.pageId ? row : { pageId: row.pageId, writes: row.writes };
            }) },
        ontology: d2BffL4Slice(Object.fromEntries(Object.entries(artifacts.entities).filter(([id]) => JSON.stringify([page.reads, page.writes, page.organisms]).includes(id))), (artifacts.rules ?? {}), page, []).entities,
        // Disclosure is checked against the page actors' grants only.
        access: { grants: (record(artifacts.access).grants ?? []).filter(raw => page.actors.includes(text(record(raw).actorRef))) },
        categories: context.template.categories.map(item => {
            const row = item;
            return { categoryId: row.categoryId, name: row.name, description: row.description, typicalEntities: row.typicalEntities };
        }),
        moleculeResearch: JSON.parse(moleculeDecisionContext(context.selectedGroups, context.groups)),
        // d2_71: a regeneration starts from the approved page11 and changes only what the reason asks.
        approved: approved ? { desktop: { definition: approved.definitions.desktop, needs: approved.needs.desktop }, mobile: { definition: approved.definitions.mobile, needs: approved.needs.mobile } } : null,
        regeneration: approved ? { reason: d2RegenerationReason(context, approved) } : null,
        repair: repair ?? null,
    };
    const prompt = JSON.stringify(payload);
    if (prompt.length > D2_PAGES_PROMPT_LIMIT_CHARS)
        throw new Error(`D2_PAGE11_PROMPT_LIMIT: ${prompt.length} > ${D2_PAGES_PROMPT_LIMIT_CHARS}`);
    return { prompt, chars: prompt.length };
}
const productionWriter = { writeSource: writeSourceText, writeJson, readSource: info => readSourceText(info).catch(() => null) };
/** Every page11 gate the approval runs, for an answer or for an approved page11 under the current inputs. */
export function d2PageIssues(context, definitions, needs, promptChars = 0, chosenCategory) {
    const menu = context.artifacts.menu;
    const needPages = record(context.artifacts.needs).pages;
    if (!Array.isArray(needPages))
        throw new Error('D2_PAGE11_SOURCE_NEEDS');
    const sources = { pageId: context.page.pageId, actor: context.page.actors[0], pageActors: context.page.actors, menu,
        needsPages: needPages, entities: context.artifacts.entities,
        access: context.artifacts.access, categories: context.template.categories,
        templatePaths: context.template.templatePaths, templateOptions: context.template.templateOptions, ...(chosenCategory ? { chosenCategory } : {}),
        moleculeTags: new Set(context.groups.flatMap(group => group.tags)),
        promptTokens: Math.ceil(promptChars / 4) };
    const origins = menuOrigins(context.page, definitions.desktop);
    const groupsByOrganism = Object.fromEntries(origins.map(origin => [origin.organismId, context.selectedGroups[`organism${origin.sourceIndex + 1}`] ?? []]));
    const kindMismatch = Object.keys(definitions.desktop.organisms).filter(id => definitions.mobile.organisms[id]?.kind !== definitions.desktop.organisms[id].kind);
    const issues = [...gateD2Page11Pair(definitions.desktop, definitions.mobile),
        ...kindMismatch.map(id => ({ code: 'D2_PAGE11_DEVICE_KIND', path: `organisms.${id}`, message: `Organism ${id} has different kinds across devices.` })),
        ...['desktop', 'mobile'].flatMap(device => [
            ...context.page.actors.flatMap(actor => gateD2Page11(definitions[device], needs[device], { ...sources, actor })),
            ...gateD2MoleculeRoles(definitions[device].molecules, groupsByOrganism, context.groups).map(message => ({ code: 'D2_MOLECULE_ROLE_UNSELECTED', path: device, message })),
        ])];
    const seen = new Set();
    return issues.filter(issue => {
        const key = `${issue.code}\u0000${issue.path}\u0000${issue.message}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
}
/** Molecule tags a page11 chose, with the organisms that use each. */
export function d2ChosenMolecules(definitions) {
    const chosen = new Map();
    for (const definition of Object.values(definitions)) {
        for (const [organismId, choices] of Object.entries(definition.molecules)) {
            for (const choice of choices)
                for (const tag of [choice.preferred, choice.alternative]) {
                    if (tag)
                        chosen.set(tag, (chosen.get(tag) ?? new Set()).add(organismId));
                }
        }
    }
    return chosen;
}
/**
 * Why an approved page11 is regenerated: what its current gate refuses, the molecules it chose that left the catalog,
 * and the writes the page gained or lost. The answer keeps everything else (ids, prose, molecules).
 */
export function d2RegenerationReason(context, approved) {
    const reasons = [];
    const tags = new Set(context.groups.flatMap(group => group.tags));
    for (const [tag, organisms] of d2ChosenMolecules(approved.definitions)) {
        if (!tags.has(tag))
            reasons.push(`molecule ${tag} is no longer in the catalog; change it only in ${[...organisms].sort().join(', ')}`);
    }
    const pageKeys = new Set(d2PageWriteKeys(context.page));
    const submitted = new Set(Object.values(approved.needs).flatMap(needs => Object.values(needs.organisms).flatMap(unit => unit.submits.map(submit => submit.write))));
    for (const key of pageKeys)
        if (!submitted.has(key))
            reasons.push(`the page now writes ${key}; add its submit (or navigate) and keep the rest`);
    for (const key of submitted)
        if (!pageKeys.has(key))
            reasons.push(`the page no longer writes ${key}; remove its submit and keep the rest`);
    for (const issue of d2PageIssues(context, approved.definitions, approved.needs)) {
        if (issue.code === 'D2_PAGE11_WRITE_UNCOVERED' || issue.code === 'D2_PAGE11_SUBMIT_WRITE' || issue.code === 'D2_PAGE11_MOLECULE_UNKNOWN')
            continue;
        reasons.push(`${issue.code} at ${issue.path}: ${issue.message}`);
    }
    if (!reasons.length)
        reasons.push('the generator or the page inputs changed; keep the approved page11 unless a gate refuses it');
    return [...new Set(reasons)];
}
/**
 * The template an approved page11 keeps on regeneration (TASK genome-ux-4, decision 5): when the answer keeps the
 * approved category and the approved template is an allowed alternative of it (experienceIndex.json, chosen by the
 * user), that template and its experience stay instead of the category default. Otherwise null: the code derives the
 * default, as for a page made from scratch.
 */
export function d2KeptPage11Template(context, approved, category) {
    if (!approved || category === 'bespoke')
        return null;
    const desktop = approved.definitions.desktop.template;
    const mobile = approved.definitions.mobile.template;
    if (desktop.category !== mobile.category || desktop.experience !== mobile.experience)
        return null;
    if (parseD2Page11TemplateReference(desktop.category)?.categoryId !== category)
        return null;
    const option = context.template.templateOptions?.get(category)?.find(item => item.reference === desktop.category);
    if (!option || option.isDefault || option.experience !== desktop.experience)
        return null;
    return { category: option.reference, experience: option.experience };
}
export async function approveD2PagesUnit(context, raw, promptChars, repairPromptChars = 0, writer = productionWriter, approved = null) {
    const category = text(record(record(raw.desktop).definition).template && record(record(record(raw.desktop).definition).template).category);
    if (!category || category !== text(record(record(record(raw.mobile).definition).template).category))
        throw new Error('D2_PAGE11_DEVICE_CATEGORY');
    if (!text(raw.categoryReason))
        throw new Error('D2_PAGE11_CATEGORY_REASON');
    // The LLM answers the category; the code derives the template, or keeps the approved alternative (d2KeptPage11Template).
    const kept = d2KeptPage11Template(context, approved, category);
    const selectedTemplate = await context.template.select(category, kept?.category);
    const definitions = {
        desktop: buildD2Page11WithExperience(raw.desktop.definition, context.template.categories, kept),
        mobile: buildD2Page11WithExperience(raw.mobile.definition, context.template.categories, kept),
    };
    const writes = pageWrites(context.page);
    const grants = (record(context.artifacts.access).grants ?? []).filter(raw => context.page.actors.includes(text(record(raw).actorRef)));
    const needs = {
        desktop: buildD2Page11Needs(normalizeSubmitWrites(normalizeNeedsPaths(raw.desktop.needs, context.page, context.artifacts.entities, grants), writes)),
        mobile: buildD2Page11Needs(normalizeSubmitWrites(normalizeNeedsPaths(raw.mobile.needs, context.page, context.artifacts.entities, grants), writes)),
    };
    if (!context.page.actors.length)
        throw new Error('D2_PAGE11_ACTOR_MISSING');
    const issues = d2PageIssues(context, definitions, needs, Math.max(promptChars, repairPromptChars), category);
    if (issues.length)
        throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    const origins = menuOrigins(context.page, definitions.desktop);
    if (origins.some(origin => !origin.organismId))
        throw new Error('D2_PAGE11_MENU_ORIGIN_MISSING');
    const sourcesText = Object.fromEntries(['desktop', 'mobile'].map(device => [device, renderD2Page11Definition({ ...context.identity, pageId: context.page.pageId, device }, definitions[device])]));
    const needsText = Object.fromEntries(['desktop', 'mobile'].map(device => [device, JSON.stringify(needs[device])]));
    const receipt = {
        schemaVersion: D2_PAGES_VERSION, needsVersion: D2_PAGE11_NEEDS_VERSION, ...context.identity, pageId: context.page.pageId,
        inputHash: context.snapshot.snapshotHash,
        unitInputHash: await pageUnitInputHash(context),
        template: { category, experience: selectedTemplate.experience, reason: `${raw.categoryReason} ${selectedTemplate.reason}`, reference: selectedTemplate.reference, hash: selectedTemplate.hash, catalogHash: await sha256Text(context.template.catalog) },
        moleculeInventoryHash: context.inventory.sourceHash, moleculeHashes: context.moleculeHashes, moleculeGroupAssessments: context.groupAssessments,
        skillHash: await sha256Text(context.skill), promptHash: await sha256Text(context.prompt), promptChars, repairPromptChars,
        sourceHashes: { desktop: await sha256Text(sourcesText.desktop), mobile: await sha256Text(sourcesText.mobile) },
        needsHashes: { desktop: await sha256Text(needsText.desktop), mobile: await sha256Text(needsText.mobile) },
        menuOrigins: origins,
    };
    for (const device of ['desktop', 'mobile']) {
        // The receipt hashes the definition alone (d2Page11Hash), so the history carried over does not change it.
        const info = sourceInfo(context.identity, context.page.pageId, device);
        const previous = writer.readSource ? await writer.readSource(info) : null;
        await writer.writeSource(info, d2Page11KeepingHistory(sourcesText[device], previous));
        await writer.writeJson(needsInfo(context.identity, context.page.pageId, device), needs[device]);
    }
    await writer.writeJson(owned(context.identity, context.page.pageId), receipt);
    return receipt;
}
export async function readD2PagesReceipt(identity, pageId) { return readJson(owned(identity, pageId)); }
