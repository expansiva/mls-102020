/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.ts" enhancement="_blank"/>
import { chFileRefFromImport } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';
import { sha256Text } from '/_102020_/l2/agentDefsL2/steps/contracts30/run.js';
export const D2_MOLECULE_RECEIPT_VERSION = '2026-09-23-agent-defs-l2-molecule-receipt-v2';
export class D2MoleculeContextError extends Error {
    constructor(code, message) {
        super(`${code}: ${message}`);
        this.code = code;
        this.name = 'D2MoleculeContextError';
    }
}
export async function buildD2MoleculeInventory(port, explicitCatalogProject = null) {
    const discovery = await port.discover(explicitCatalogProject);
    if (discovery.error) {
        if (/more than one catalog/iu.test(discovery.error)) {
            throw new D2MoleculeContextError('D2_MOLECULE_CATALOG_AMBIGUOUS', discovery.error);
        }
        return emptyInventory(discovery, discovery.error);
    }
    if (discovery.project === null)
        return emptyInventory(discovery, 'No molecule catalog is available to this project.');
    const loaded = await port.readLevel1(discovery.project);
    if (!loaded.level1)
        throw new D2MoleculeContextError('D2_MOLECULE_CATALOG_UNREADABLE', loaded.error);
    const groups = inventoryGroups(loaded.level1.groups, loaded.level1.skill);
    const context = renderInventoryContext(loaded.level1.project, groups);
    const read = { role: 'inventory', reference: loaded.level1.reference, via: loaded.level1.via, sha256: await sha256Text(JSON.stringify({ groups: loaded.level1.groups, skill: loaded.level1.skill, theme: loaded.level1.theme })) };
    const inventoryBytes = utf8Bytes(context);
    return {
        consumerProject: discovery.activeProject, catalogProject: loaded.level1.project,
        selectedBy: discovery.selectedBy,
        directDeps: [...discovery.directDeps], resolvedDeps: [...discovery.resolvedDeps], candidates: [...discovery.candidates],
        reason: groups.length ? null : 'The selected catalog publishes no usable molecule group.',
        groups,
        context,
        metrics: { inventoryBytes, totalBytes: inventoryBytes, reads: [read] },
    };
}
export async function resolveD2MoleculeSelection(port, inventory, selectedGroupIds, candidateContext) {
    const selected = canonicalSelection(inventory.groups, selectedGroupIds);
    const groups = [];
    const reads = [...inventory.metrics.reads];
    for (const entry of selected) {
        const indexPipelineReference = normalizeD2MlsReference(entry.indexReference);
        const cached = candidateContext?.catalogs.find(item => item.reference === entry.indexReference);
        const loaded = cached ? { catalog: cached, error: '' } : await port.readGroup(entry.indexReference);
        if (!loaded.catalog)
            throw new D2MoleculeContextError('D2_MOLECULE_INDEX_UNREADABLE', `${entry.groupId}: ${loaded.error}`);
        if (loaded.catalog.group !== entry.groupId) {
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_MISMATCH', `${entry.indexReference} exports '${loaded.catalog.group}', expected '${entry.groupId}'`);
        }
        reads.push({ role: 'group-index', reference: entry.indexReference, via: loaded.catalog.via, sha256: await sha256Text(JSON.stringify(loaded.catalog)) });
        const usageLiteral = loaded.catalog.usageContract;
        if (!usageLiteral)
            throw new D2MoleculeContextError('D2_MOLECULE_USAGE_MISSING', `${entry.indexReference} exports no usageContract reference`);
        const usageContractPipelineReference = normalizeD2MlsReference(usageLiteral);
        const usage = await port.readUsageContract(usageLiteral);
        if (!usage.contract?.skill.trim()) {
            throw new D2MoleculeContextError('D2_MOLECULE_USAGE_UNREADABLE', `${entry.groupId}: ${usage.error || usageLiteral}`);
        }
        reads.push({ role: 'usage-contract', reference: usageLiteral, via: usage.contract.via, sha256: await sha256Text(usage.contract.skill) });
        groups.push({
            groupId: entry.groupId,
            indexReference: entry.indexReference,
            indexPipelineReference,
            indexVia: loaded.catalog.via,
            usageContractReference: usageLiteral,
            usageContractPipelineReference,
            usageContractVia: usage.contract.via,
            molecules: loaded.catalog.molecules,
            scenarios: loaded.catalog.scenarios,
            groupSkill: loaded.catalog.skill,
            usageSkill: usage.contract.skill,
        });
    }
    const context = JSON.stringify({ moleculeGroups: groups }, null, 2);
    const selectedBytes = utf8Bytes(context);
    return {
        groups,
        pipelineSkills: dedupe(groups.flatMap(group => [group.indexPipelineReference, group.usageContractPipelineReference])),
        context,
        metrics: {
            inventoryBytes: inventory.metrics.inventoryBytes,
            selectedBytes,
            totalBytes: inventory.metrics.inventoryBytes + selectedBytes,
            reads,
        },
    };
}
export async function buildD2MoleculeCandidateContext(port, inventory) {
    const groups = [];
    const catalogs = [];
    const reads = [];
    for (const entry of inventory.groups) {
        const loaded = await port.readGroup(entry.indexReference);
        if (!loaded.catalog)
            throw new D2MoleculeContextError('D2_MOLECULE_INDEX_UNREADABLE', `${entry.groupId}: ${loaded.error}`);
        if (loaded.catalog.group !== entry.groupId)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_MISMATCH', `${entry.indexReference} exports '${loaded.catalog.group}', expected '${entry.groupId}'`);
        catalogs.push(loaded.catalog);
        reads.push({ role: 'group-index', reference: entry.indexReference, via: loaded.catalog.via, sha256: await sha256Text(JSON.stringify(loaded.catalog)) });
        const tags = new Set(loaded.catalog.molecules.map(item => item.tag));
        const scenarios = loaded.catalog.scenarios.map(item => {
            const candidates = dedupe(item.recommended);
            for (const candidate of candidates)
                if (!tags.has(candidate))
                    throw new D2MoleculeContextError('D2_MOLECULE_CANDIDATE_UNKNOWN', `${entry.groupId}: ${candidate}`);
            return { scenario: item.scenario, candidates };
        });
        groups.push({ groupId: entry.groupId, scenarios });
    }
    const context = JSON.stringify({ moleculeCandidates: { instruction: 'Recommend at least one listed exact candidate for each organism with a compatible group. An empty recommendation is valid only for static content or when no listed group matches its capabilities; never claim the catalog is empty when groups are listed.', groups } }, null, 2);
    return { groups, context, catalogs, reads };
}
export async function prepareD2MoleculeContext(port, explicitCatalogProject = null) {
    const inventory = await buildD2MoleculeInventory(port, explicitCatalogProject);
    const candidates = await buildD2MoleculeCandidateContext(port, inventory);
    return { inventory, candidates, receipt: await buildD2MoleculeReceipt(inventory, candidates) };
}
export async function buildD2MoleculeReceipt(inventory, candidates, selection) {
    const selectedGroupIds = selection?.groups.map(group => group.groupId) ?? [];
    const sources = dedupeReads([...inventory.metrics.reads, ...candidates.reads, ...(selection?.metrics.reads.filter(read => read.role === 'usage-contract') ?? [])]);
    const absent = inventory.catalogProject === null;
    const outcome = absent ? 'catalog-absent' : selection ? (selectedGroupIds.length ? 'catalog-selection' : 'catalog-valid-no-match') : 'catalog-available';
    const code = absent ? 'D2_MOLECULE_CATALOG_ABSENT' : selection ? (selectedGroupIds.length ? 'D2_MOLECULE_SELECTION' : 'D2_MOLECULE_VALID_NO_MATCH') : 'D2_MOLECULE_CATALOG_AVAILABLE';
    const reason = absent ? (inventory.reason || 'No molecule catalog is available to this project.') : selection ? (selectedGroupIds.length ? `Selected ${selectedGroupIds.length} catalog group(s).` : 'The catalog is valid; this page selected no matching group.') : `Catalog exposes ${inventory.groups.length} group(s) to the worker.`;
    const discovery = {
        directDeps: canonicalProjectVector(inventory.directDeps, inventory.consumerProject),
        resolvedDeps: canonicalProjectVector(inventory.resolvedDeps, inventory.consumerProject),
        candidates: canonicalProjectVector(inventory.candidates),
    };
    assertD2MoleculeDiscovery(inventory.consumerProject, inventory.catalogProject, inventory.selectedBy, discovery);
    const discoveryHash = await sha256Text(JSON.stringify({ consumerProject: inventory.consumerProject, catalogProject: inventory.catalogProject, selectedBy: inventory.selectedBy, ...discovery }));
    const base = { schemaVersion: D2_MOLECULE_RECEIPT_VERSION, consumerProject: inventory.consumerProject, catalogProject: inventory.catalogProject, selectedBy: inventory.selectedBy, outcome, code, reason, groupCount: inventory.groups.length, candidateCount: candidates.groups.reduce((sum, group) => sum + group.scenarios.reduce((count, scenario) => count + scenario.candidates.length, 0), 0), selectedGroupIds, discovery, discoveryHash, sources };
    return { ...base, contextHash: await sha256Text(JSON.stringify(base)) };
}
export async function assertD2MoleculeReceiptIntegrity(receipt) {
    if (receipt.schemaVersion !== D2_MOLECULE_RECEIPT_VERSION)
        throw new D2MoleculeContextError('D2_MOLECULE_RECEIPT_VERSION', String(receipt.schemaVersion));
    assertD2MoleculeDiscovery(receipt.consumerProject, receipt.catalogProject, receipt.selectedBy, receipt.discovery);
    const discoveryHash = await sha256Text(JSON.stringify({ consumerProject: receipt.consumerProject, catalogProject: receipt.catalogProject, selectedBy: receipt.selectedBy, ...receipt.discovery }));
    if (discoveryHash !== receipt.discoveryHash)
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_HASH', `${receipt.discoveryHash} != ${discoveryHash}`);
    const { contextHash: _contextHash, ...base } = receipt;
    const contextHash = await sha256Text(JSON.stringify(base));
    if (contextHash !== receipt.contextHash)
        throw new D2MoleculeContextError('D2_MOLECULE_RECEIPT_HASH', `${receipt.contextHash} != ${contextHash}`);
}
export function assertD2MoleculeCandidates(selection, recommendations) {
    const byGroup = new Map(selection.groups.map(group => [group.groupId, new Set(group.molecules.map(item => item.tag))]));
    for (const recommendation of recommendations) {
        const candidates = byGroup.get(recommendation.groupId);
        if (!candidates)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_UNKNOWN', `recommendation uses unselected group '${recommendation.groupId}'`);
        for (const candidate of recommendation.candidates)
            if (!candidates.has(candidate))
                throw new D2MoleculeContextError('D2_MOLECULE_CANDIDATE_UNKNOWN', `${recommendation.groupId}: ${candidate}`);
    }
}
export function normalizeD2MlsReference(reference) {
    const parsed = chFileRefFromImport(reference);
    const unsafeFolder = parsed?.folder.split('/').some(part => !part || part === '.' || part === '..');
    if (!parsed || !parsed.folder || parsed.level !== 2 || unsafeFolder) {
        throw new D2MoleculeContextError('D2_MOLECULE_REF_INVALID', `invalid level-2 MLS reference '${reference}'`);
    }
    return `_${parsed.project}_/l${parsed.level}/${parsed.folder}/${parsed.shortName}${parsed.extension}`;
}
export function inventoryGroups(groups, skill) {
    const purposes = purposeByGroup(skill);
    return groups.map(group => {
        const purpose = purposes.get(group.name);
        if (!purpose)
            throw new D2MoleculeContextError('D2_MOLECULE_PURPOSE_MISSING', `catalog documents no purpose for '${group.name}'`);
        return { groupId: group.name, purpose, moleculeCount: group.molecules, indexReference: group.indexDefs };
    });
}
function canonicalSelection(groups, requested) {
    const byFolded = new Map();
    for (const group of groups) {
        const key = group.groupId.trim().toLowerCase();
        byFolded.set(key, [...(byFolded.get(key) ?? []), group]);
    }
    const chosen = [];
    const seen = new Set();
    for (const raw of requested) {
        const matches = byFolded.get(raw.trim().toLowerCase()) ?? [];
        if (!matches.length)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_UNKNOWN', `selected group '${raw}' is not in the compact inventory`);
        if (matches.length > 1)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_AMBIGUOUS', `selected group '${raw}' matches ${matches.map(item => item.groupId).join(', ')}`);
        if (!seen.has(matches[0].groupId)) {
            seen.add(matches[0].groupId);
            chosen.push(matches[0]);
        }
    }
    return chosen;
}
function assertD2MoleculeDiscovery(consumerProject, catalogProject, selectedBy, discovery) {
    for (const [name, values] of Object.entries(discovery)) {
        if (!Array.isArray(values) || values.some(value => !Number.isSafeInteger(value)) || new Set(values).size !== values.length) {
            throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_VECTOR', name);
        }
    }
    if (discovery.directDeps.includes(consumerProject) || discovery.resolvedDeps.includes(consumerProject))
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_VECTOR', 'dependency vectors contain the consumer project');
    if (catalogProject === null) {
        if (selectedBy !== null)
            throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'a missing catalog cannot have selectedBy');
        return;
    }
    if (!discovery.candidates.includes(catalogProject))
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'catalogProject is absent from candidates');
    if (discovery.candidates.some(project => project !== consumerProject && !discovery.directDeps.includes(project)))
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'candidate is neither local nor a direct dependency');
    if (selectedBy === 'local' && catalogProject !== consumerProject)
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'local catalogProject differs from consumerProject');
    if (selectedBy === 'dependency' && !discovery.directDeps.includes(catalogProject))
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'dependency catalogProject is absent from directDeps');
    if (!selectedBy)
        throw new D2MoleculeContextError('D2_MOLECULE_DISCOVERY_SELECTION', 'selected catalog has no selectedBy');
}
function canonicalProjectVector(values, excluded) {
    const seen = new Set();
    const canonical = [];
    for (const value of values) {
        if (value === excluded || seen.has(value))
            continue;
        seen.add(value);
        canonical.push(value);
    }
    return canonical;
}
function purposeByGroup(skill) {
    const out = new Map();
    const pattern = /^###\s+(\S+)\s+\(\d+ molecules\)\s*\n+([^\n]+)/gmu;
    for (const match of skill.matchAll(pattern))
        out.set(match[1], match[2].trim());
    return out;
}
function renderInventoryContext(project, groups) {
    return JSON.stringify({
        moleculeCatalog: {
            project,
            instruction: 'Select zero or more useful groupId values. Do not select a visual variant here.',
            groups,
        },
    }, null, 2);
}
function emptyInventory(discovery, reason) {
    const context = JSON.stringify({ moleculeCatalog: { groups: [], reason } }, null, 2);
    const inventoryBytes = utf8Bytes(context);
    return { consumerProject: discovery.activeProject, catalogProject: null, selectedBy: discovery.selectedBy, directDeps: [...discovery.directDeps], resolvedDeps: [...discovery.resolvedDeps], candidates: [...discovery.candidates], reason, groups: [], context, metrics: { inventoryBytes, totalBytes: inventoryBytes, reads: [] } };
}
function dedupe(values) { return [...new Set(values)]; }
function dedupeReads(values) { return [...new Map(values.map(read => [`${read.role}\0${read.reference}`, read])).values()].sort((a, b) => `${a.role}\0${a.reference}`.localeCompare(`${b.role}\0${b.reference}`)); }
function utf8Bytes(value) { return new TextEncoder().encode(value).byteLength; }
