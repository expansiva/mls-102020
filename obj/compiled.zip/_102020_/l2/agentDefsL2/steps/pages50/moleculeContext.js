/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.ts" enhancement="_blank"/>
import { chFileRefFromImport } from '/_102020_/l2/aura/molecules/agentChooseMolecules/helpers/chTypes.js';
export class D2MoleculeContextError extends Error {
    constructor(code, message) {
        super(`${code}: ${message}`);
        this.code = code;
        this.name = 'D2MoleculeContextError';
    }
}
export async function buildD2MoleculeInventory(port, explicitCatalogProject = null) {
    const discovery = await port.discover(explicitCatalogProject);
    if (discovery.error) {
        if (/more than one catalog/iu.test(discovery.error)) {
            throw new D2MoleculeContextError('D2_MOLECULE_CATALOG_AMBIGUOUS', discovery.error);
        }
        return emptyInventory(discovery.selectedBy, discovery.error);
    }
    if (discovery.project === null)
        return emptyInventory(discovery.selectedBy, 'No molecule catalog is available to this project.');
    const loaded = await port.readLevel1(discovery.project);
    if (!loaded.level1)
        throw new D2MoleculeContextError('D2_MOLECULE_CATALOG_UNREADABLE', loaded.error);
    const groups = inventoryGroups(loaded.level1.groups, loaded.level1.skill);
    const context = renderInventoryContext(loaded.level1.project, groups);
    const read = { role: 'inventory', reference: loaded.level1.reference, via: loaded.level1.via };
    const inventoryBytes = utf8Bytes(context);
    return {
        catalogProject: loaded.level1.project,
        selectedBy: discovery.selectedBy,
        reason: groups.length ? null : 'The selected catalog publishes no usable molecule group.',
        groups,
        context,
        metrics: { inventoryBytes, totalBytes: inventoryBytes, reads: [read] },
    };
}
export async function resolveD2MoleculeSelection(port, inventory, selectedGroupIds) {
    const selected = canonicalSelection(inventory.groups, selectedGroupIds);
    const groups = [];
    const reads = [...inventory.metrics.reads];
    for (const entry of selected) {
        const indexPipelineReference = normalizeD2MlsReference(entry.indexReference);
        const loaded = await port.readGroup(entry.indexReference);
        if (!loaded.catalog)
            throw new D2MoleculeContextError('D2_MOLECULE_INDEX_UNREADABLE', `${entry.groupId}: ${loaded.error}`);
        if (loaded.catalog.group !== entry.groupId) {
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_MISMATCH', `${entry.indexReference} exports '${loaded.catalog.group}', expected '${entry.groupId}'`);
        }
        reads.push({ role: 'group-index', reference: entry.indexReference, via: loaded.catalog.via });
        const usageLiteral = loaded.catalog.usageContract;
        if (!usageLiteral)
            throw new D2MoleculeContextError('D2_MOLECULE_USAGE_MISSING', `${entry.indexReference} exports no usageContract reference`);
        const usageContractPipelineReference = normalizeD2MlsReference(usageLiteral);
        const usage = await port.readUsageContract(usageLiteral);
        if (!usage.contract?.skill.trim()) {
            throw new D2MoleculeContextError('D2_MOLECULE_USAGE_UNREADABLE', `${entry.groupId}: ${usage.error || usageLiteral}`);
        }
        reads.push({ role: 'usage-contract', reference: usageLiteral, via: usage.contract.via });
        groups.push({
            groupId: entry.groupId,
            indexReference: entry.indexReference,
            indexPipelineReference,
            indexVia: loaded.catalog.via,
            usageContractReference: usageLiteral,
            usageContractPipelineReference,
            usageContractVia: usage.contract.via,
            molecules: loaded.catalog.molecules,
            scenarios: loaded.catalog.scenarios,
            groupSkill: loaded.catalog.skill,
            usageSkill: usage.contract.skill,
        });
    }
    const context = JSON.stringify({ moleculeGroups: groups }, null, 2);
    const selectedBytes = utf8Bytes(context);
    return {
        groups,
        pipelineSkills: dedupe(groups.flatMap(group => [group.indexPipelineReference, group.usageContractPipelineReference])),
        context,
        metrics: {
            inventoryBytes: inventory.metrics.inventoryBytes,
            selectedBytes,
            totalBytes: inventory.metrics.inventoryBytes + selectedBytes,
            reads,
        },
    };
}
export function normalizeD2MlsReference(reference) {
    const parsed = chFileRefFromImport(reference);
    const unsafeFolder = parsed?.folder.split('/').some(part => !part || part === '.' || part === '..');
    if (!parsed || !parsed.folder || parsed.level !== 2 || unsafeFolder) {
        throw new D2MoleculeContextError('D2_MOLECULE_REF_INVALID', `invalid level-2 MLS reference '${reference}'`);
    }
    return `_${parsed.project}_/l${parsed.level}/${parsed.folder}/${parsed.shortName}${parsed.extension}`;
}
export function inventoryGroups(groups, skill) {
    const purposes = purposeByGroup(skill);
    return groups.map(group => {
        const purpose = purposes.get(group.name);
        if (!purpose)
            throw new D2MoleculeContextError('D2_MOLECULE_PURPOSE_MISSING', `catalog documents no purpose for '${group.name}'`);
        return { groupId: group.name, purpose, moleculeCount: group.molecules, indexReference: group.indexDefs };
    });
}
function canonicalSelection(groups, requested) {
    const byFolded = new Map();
    for (const group of groups) {
        const key = group.groupId.trim().toLowerCase();
        byFolded.set(key, [...(byFolded.get(key) ?? []), group]);
    }
    const chosen = [];
    const seen = new Set();
    for (const raw of requested) {
        const matches = byFolded.get(raw.trim().toLowerCase()) ?? [];
        if (!matches.length)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_UNKNOWN', `selected group '${raw}' is not in the compact inventory`);
        if (matches.length > 1)
            throw new D2MoleculeContextError('D2_MOLECULE_GROUP_AMBIGUOUS', `selected group '${raw}' matches ${matches.map(item => item.groupId).join(', ')}`);
        if (!seen.has(matches[0].groupId)) {
            seen.add(matches[0].groupId);
            chosen.push(matches[0]);
        }
    }
    return chosen;
}
function purposeByGroup(skill) {
    const out = new Map();
    const pattern = /^###\s+(\S+)\s+\(\d+ molecules\)\s*\n+([^\n]+)/gmu;
    for (const match of skill.matchAll(pattern))
        out.set(match[1], match[2].trim());
    return out;
}
function renderInventoryContext(project, groups) {
    return JSON.stringify({
        moleculeCatalog: {
            project,
            instruction: 'Select zero or more useful groupId values. Do not select a visual variant here.',
            groups,
        },
    }, null, 2);
}
function emptyInventory(selectedBy, reason) {
    const context = JSON.stringify({ moleculeCatalog: { groups: [], reason } }, null, 2);
    const inventoryBytes = utf8Bytes(context);
    return { catalogProject: null, selectedBy, reason, groups: [], context, metrics: { inventoryBytes, totalBytes: inventoryBytes, reads: [] } };
}
function dedupe(values) { return [...new Set(values)]; }
function utf8Bytes(value) { return new TextEncoder().encode(value).byteLength; }
