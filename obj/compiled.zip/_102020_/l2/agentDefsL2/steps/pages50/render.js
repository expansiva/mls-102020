/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/render.ts" enhancement="_blank"/>
export function renderD2Page(page) {
    return `export const descriptions = ${JSON.stringify(page.descriptions, null, 2)} as const;\n\nexport const pipeline = ${JSON.stringify(page.pipeline, null, 2)} as const;\n`;
}
export function parseD2RenderedPage(source) {
    const descriptions = parseExport(source, 'descriptions');
    const pipeline = parseExport(source, 'pipeline');
    if (!Array.isArray(descriptions) || !Array.isArray(pipeline))
        throw new Error('D2_PAGES_CONSUMER_SHAPE');
    for (const raw of descriptions) {
        const item = record(raw);
        exactKeys(item, ['organismId', 'kind', 'description', 'contentRef', 'capabilityRefs', 'moleculeRecommendations']);
        if (!text(item.organismId) || !text(item.kind) || !text(item.description) || !text(item.contentRef) || !stringArray(item.capabilityRefs) || !Array.isArray(item.moleculeRecommendations))
            throw new Error('D2_PAGES_CONSUMER_SHAPE');
        for (const rawRecommendation of item.moleculeRecommendations) {
            const recommendation = record(rawRecommendation);
            exactKeys(recommendation, ['groupId', 'candidates', 'reason']);
            if (!text(recommendation.groupId) || !text(recommendation.reason) || !stringArray(recommendation.candidates) || !recommendation.candidates.length)
                throw new Error('D2_PAGES_CONSUMER_SHAPE');
        }
    }
    return { descriptions: descriptions, pipeline };
}
function exactKeys(value, allowed) { if (Object.keys(value).some(key => !allowed.includes(key)))
    throw new Error('D2_PAGES_CONSUMER_SHAPE'); }
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function stringArray(value) { return Array.isArray(value) && value.every(item => typeof item === 'string' && item.trim()); }
export function assertD2RenderedPage(source) {
    const parsed = parseD2RenderedPage(source);
    if (parsed.pipeline.length !== 1)
        throw new Error('D2_PAGES_PIPELINE_COUNT');
    const exports = [...source.matchAll(/export const\s+([A-Za-z0-9_]+)/gu)].map(match => match[1]);
    if (exports.join(',') !== 'descriptions,pipeline')
        throw new Error(`D2_PAGES_EXPORTS: ${exports.join(',')}`);
    if (/<\/?[a-z][^>]*>|```(?:html|css)/iu.test(source))
        throw new Error('D2_PAGES_MARKUP_FORBIDDEN');
}
function parseExport(source, name) {
    const match = new RegExp(`export const ${name} = ([\\s\\S]*?) as const;`).exec(source);
    if (!match)
        throw new Error(`D2_PAGES_EXPORT_MISSING: ${name}`);
    try {
        return JSON.parse(match[1]);
    }
    catch {
        throw new Error(`D2_PAGES_EXPORT_INVALID: ${name}`);
    }
}
