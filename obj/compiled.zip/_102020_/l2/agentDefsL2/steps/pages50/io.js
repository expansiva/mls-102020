/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/io.ts" enhancement="_blank"/>
import { displayPath, readJson, readSourceText, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
export function d2PageFile(identity, pageId, device) { return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: safe(pageId), extension: '.defs.ts' }; }
export function d2PagesResultFile(identity, pageId) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/pages50/results`, shortName: safe(pageId), extension: '.json' }; }
export function d2PagesManifestFile(identity) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2`, shortName: 'pages', extension: '.json' }; }
export function d2PageDisplayPath(identity, pageId, device) { return displayPath(d2PageFile(identity, pageId, device)); }
export async function readD2PageSource(identity, pageId, device) { try {
    return await readSourceText(d2PageFile(identity, pageId, device));
}
catch {
    return '';
} }
export async function writeD2PageSource(identity, pageId, device, source) { await writeSourceText(d2PageFile(identity, pageId, device), source); }
export async function readD2PagesResult(identity, pageId) { return readJson(d2PagesResultFile(identity, pageId)); }
export async function writeD2PagesResult(identity, value) { if (JSON.stringify(await readD2PagesResult(identity, value.pageId)) !== JSON.stringify(value))
    await writeJson(d2PagesResultFile(identity, value.pageId), value); }
export async function readD2PagesManifest(identity) { return readJson(d2PagesManifestFile(identity)); }
export async function writeD2PagesManifest(identity, value) { if (JSON.stringify(await readD2PagesManifest(identity)) !== JSON.stringify(value))
    await writeJson(d2PagesManifestFile(identity), value); }
function safe(value) { if (!/^[a-z][A-Za-z0-9_-]*$/.test(value))
    throw new Error(`D2_PAGES_PAGE_ID_UNSAFE: ${value}`); return value; }
