/// <mls fileReference="_102020_/l2/agentDefsL2/steps/pages50/contracts.ts" enhancement="_blank"/>
export const D2_PAGES_VERSION = '2026-09-23-agent-defs-l2-pages-v2';
export const D2_PAGES_JUDGMENT_VERSION = '2026-09-23-agent-defs-l2-pages-judgment-v2';
export function buildD2PagePipeline(moduleName, pageId, device, categoryRef, skills) {
    const base = `l2/${moduleName}/web/${device}/page11/${pageId}`;
    return {
        id: `${pageId}__${device}__page11`, type: 'l2_page', defPath: `${base}.defs.ts`, outputPath: `${base}.ts`,
        dependsFiles: [`l2/${moduleName}/web/shared/${pageId}.ts`], dependsOn: [`${pageId}__l2_shared`], categoryRef, skills: [...new Set(skills)],
    };
}
export function knownD2PageCapabilities(shared) {
    return [...new Set([
            ...shared.actions.map(item => item.actionId),
            ...shared.states.map(item => item.stateKey),
            ...shared.scenaries.map(item => item.value),
        ])].sort();
}
