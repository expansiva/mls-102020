/// <mls fileReference="_102020_/l2/agentDefsL2/steps/contracts70/agentD2Contracts70.ts" enhancement="_blank"/>
import { readD2Input } from '/_102020_/l2/helpers/defsInput/io.js';
import { D2_CONTRACTS70_AGENT_NAME, markD2StepApproved, parseD2StepInvocation, readD2Pipeline } from '/_102020_/l2/agentDefsL2/helpers/d2Core.js';
import { addD2Step, d2Result, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { executeD2Contracts70, productionContractsPort } from '/_102020_/l2/agentDefsL2/steps/contracts70/run.js';
export function createAgent() {
    return {
        agentName: D2_CONTRACTS70_AGENT_NAME, agentProject: 102020, agentFolder: 'agentDefsL2/steps/contracts70',
        agentDescription: 'Render one BFF contract per page from the approved shared', visibility: 'private', beforePromptStep,
    };
}
export async function beforePromptStep(_agent, context, parentStep, step, hookSequential, argsOrPort) {
    try {
        const port = typeof argsOrPort === 'object' ? argsOrPort : await productionContractsPort(parsedIdentity(argsOrPort || step.prompt || ''));
        const result = await executeD2Contracts70(port);
        if (typeof argsOrPort !== 'object') {
            const identity = parsedIdentity(step.prompt || '');
            const snapshot = await readD2Input(identity);
            if (!snapshot)
                throw new Error('D2_CONTRACTS_INPUT_MISSING');
            const pipeline = await readD2Pipeline(identity);
            if (pipeline)
                await markD2StepApproved(identity, 'contracts70', [...result.wrote, ...result.reused].map(pageId => `l2/${identity.module}/web/contracts/${pageId}.defs.ts`), snapshot.snapshotHash);
        }
        return [
            addD2Step(context, parentStep.stepId, d2Result('Contracts ready', JSON.stringify({ completedStep: 'contracts70', nextStep: 'finalize80', wrote: result.wrote, reused: result.reused }), 'contracts70-done')),
            updateD2Status(context, parentStep, step, hookSequential, 'completed', `contracts70 wrote ${result.wrote.length} and reused ${result.reused.length}.`),
        ];
    }
    catch (error) {
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
function parsedIdentity(raw) {
    const parsed = parseD2StepInvocation(raw, Number(mls.actualProject || 0));
    if (parsed.kind === 'refusal')
        throw new Error(parsed.diagnostic);
    return parsed;
}
