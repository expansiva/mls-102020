/// <mls fileReference="_102020_/l2/agentDefsL2/steps/finalize80/agentD2Finalize.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { D2_FINALIZE_AGENT_NAME, parseD2StepInvocation } from '/_102020_/l2/agentDefsL2/helpers/d2Core.js';
import { updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { finalizeD2Pages } from '/_102020_/l2/agentDefsL2/steps/finalize80/run.js';
export function createAgent() {
    return { agentName: D2_FINALIZE_AGENT_NAME, agentProject: 102020, agentFolder: 'agentDefsL2/steps/finalize80', agentDescription: 'Compile and close page11, shared and contract definitions', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const parsed = parseD2StepInvocation(args || step.prompt || '', Number(mls.actualProject || 0));
    if (parsed.kind === 'refusal')
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', parsed.diagnostic)];
    try {
        const result = await finalizeD2Pages(parsed);
        return [updateD2Status(context, parentStep, step, hookSequential, result.report.status === 'complete' ? 'completed' : 'failed', result.report.status === 'complete' ? `finalize80 complete: ${result.report.artifactPaths.length} defs.` : result.report.pending.join('; '))];
    }
    catch (error) {
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
