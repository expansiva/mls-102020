/// <mls fileReference="_102020_/l2/agentDefsL2/steps/bff55/run.ts" enhancement="_blank"/>
import { displayPath, readJson, readSourceText, writeJson } from '/_102035_/l2/solution/fs.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { readD2Input, readD2InputBundle, assertD2InputSourcesStable } from '/_102020_/l2/helpers/defsInput/io.js';
import { d2WriteKey } from '/_102020_/l2/helpers/defsInput/writeKey.js';
import { parseD2Page11Definition } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import { buildD2BffDesign, checkD2Bff, d2BffAccess, d2ContractsTypeName, d2CoverageObligation, d2BffL4Slice, d2MenuPages, d2PageJourneySteps, d2PageSubmits, normalizeD2BffDesign, D2_BFF_TYPE_PATTERN, D2_BFF_UPDATE_MODES, } from '/_102020_/l2/agentDefsL2/helpers/d2Bff.js';
import { d2SharedDeriveIssues, deriveD2Shared } from '/_102020_/l2/agentDefsL2/helpers/d2SharedDerive.js';
export const D2_BFF_VERSION = '2026-10-04-agent-defs-l2-bff-v2';
export const D2_BFF_REFUSAL_VERSION = '2026-10-04-agent-defs-l2-bff-refusal';
export const D2_BFF_PROMPT_LIMIT_CHARS = 640000;
export const D2_BFF_SYSTEM_PREFIX = `<!-- modelType: reasoning -->
<!-- reasoningEffort: high -->
<!-- x-tool-strict: true -->`;
export function bffDesignInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/bff`, shortName: pageId, extension: '.json' };
}
export function bffReceiptInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/bff55`, shortName: pageId, extension: '.json' };
}
function page11Info(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' };
}
function draftInfo(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' };
}
/** The page grants as the prompt reads them: page actors only. */
function pageGrants(context) {
    return context.grants.filter(grant => context.need.actors.includes(grant.actorRef)).map(grant => ({
        grantId: grant.grantId, actor: grant.actorRef, entityRefs: grant.entityRefs, dataScope: grant.dataScope?.mode ?? '',
        disclosure: grant.disclosure.mode, ...(grant.disclosure.allowedFields ? { allowedFields: grant.disclosure.allowedFields } : {}),
        ...(grant.disclosure.deniedFields?.length ? { deniedFields: grant.disclosure.deniedFields } : {}),
    }));
}
function pageWrites(need) {
    return need.writes.flatMap(write => {
        try {
            return [{ key: d2WriteKey(write), operation: write.operation, ...(write.transitionRef ? { transitionRef: write.transitionRef } : {}) }];
        }
        catch {
            return [];
        }
    });
}
/** Everything A reads except the prompt text: its hash decides reuse. */
function unitInput(context) {
    const pageOf = (device) => ({
        intent: context.page11[device].intent,
        sections: context.page11[device].sections.map(section => ({ id: section.id, priority: section.priority, purpose: section.purpose, organisms: section.organisms })),
        organisms: context.page11[device].organisms,
    });
    return {
        pageId: context.pageId,
        userLanguage: context.userLanguage,
        actors: context.need.actors,
        page11: { desktop: pageOf('desktop'), mobile: pageOf('mobile') },
        page11Needs: { desktop: context.drafts.desktop.organisms, mobile: context.drafts.mobile.organisms },
        writes: pageWrites(context.need),
        submits: [...d2PageSubmits(context)].map(([intent, write]) => ({ intent, write })),
        l4: d2BffL4Slice(context.entities, context.rules, context.need, [context.drafts.desktop, context.drafts.mobile]),
        coverage: d2CoverageObligation([context.drafts.desktop, context.drafts.mobile], context.entities),
        journeys: context.journeys,
        journeySteps: d2PageJourneySteps(context.need, context.menu),
        menuPages: d2MenuPages(context.menu),
        grants: pageGrants(context),
    };
}
export async function bffUnitInputHash(context) {
    return sha256Text(JSON.stringify(unitInput(context)));
}
export function buildD2BffPrompt(context, repair) {
    const humanPrompt = JSON.stringify({ ...unitInput(context), approved: context.approved, repair: repair ?? null });
    const systemPrompt = `${D2_BFF_SYSTEM_PREFIX}\n\n${context.prompt}`;
    const chars = systemPrompt.length + humanPrompt.length;
    if (chars > D2_BFF_PROMPT_LIMIT_CHARS)
        throw new Error(`D2_BFF_PROMPT_LIMIT: ${chars}`);
    return { systemPrompt, humanPrompt, chars };
}
/**
 * The tool schema says what the parser requires, no more and no less (d2_74). The host fills every property, so an
 * optional closed list carries the neutral '' (a page without writes gets [''], never a free string).
 */
export function bffSchemaFor(context) {
    const slice = d2BffL4Slice(context.entities, context.rules, context.need, [context.drafts.desktop, context.drafts.mobile]);
    const paths = Object.values(slice.entities).flatMap(entity => (entity.fields).map(field => field.path));
    const branches = new Set();
    for (const path of paths) {
        const parts = path.split('.');
        for (let i = 2; i < parts.length; i += 1)
            branches.add(parts.slice(0, i).join('.'));
    }
    const enumOf = (values) => (values.length ? { type: 'string', enum: [...new Set(values)] } : { type: 'string' });
    const optionalEnum = (values) => ({ type: 'string', enum: ['', ...new Set(values)] });
    const origin = row(['kind', 'paths'], { kind: { type: 'string', enum: ['field', 'aggregate', 'context'] }, paths: { type: 'array', items: enumOf([...paths, ...branches]) } });
    const leaf = row(['name', 'type', 'origin'], { name: { type: 'string' }, type: { type: 'string', pattern: D2_BFF_TYPE_PATTERN }, optional: { type: 'boolean' }, paginated: { type: 'boolean' }, origin });
    const submits = [...d2PageSubmits(context).keys()];
    const organisms = [...new Set([...Object.keys(context.page11.desktop.organisms), ...Object.keys(context.page11.mobile.organisms)])];
    const bindings = row(['organisms', 'commands', 'selections', 'journeys', 'updates'], {
        updates: { type: 'array', items: row(['endpoint', 'state', 'mode'], { endpoint: { type: 'string' }, state: { type: 'string', pattern: '^[a-z][A-Za-z0-9]*\\.[a-z][A-Za-z0-9]*$' }, mode: { type: 'string', enum: [...D2_BFF_UPDATE_MODES] } }) },
        organisms: { type: 'array', items: row(['organism', 'reads'], { organism: enumOf(organisms), reads: { type: 'string', pattern: '^[a-z][A-Za-z0-9]*\\.[a-z][A-Za-z0-9]*$' } }) },
        commands: { type: 'array', items: row(['endpoint', 'refreshes'], { endpoint: { type: 'string' }, refreshes: { type: 'array', items: { type: 'string' } } }) },
        selections: { type: 'array', items: row(['organism', 'via'], { organism: enumOf(organisms), via: row(['kind', 'ref'], { kind: { type: 'string', enum: ['query', 'list'] }, ref: { type: 'string' } }) }) },
        journeys: { type: 'array', items: row(['step', 'organisms', 'endpoints'], {
                step: enumOf(d2PageJourneySteps(context.need, context.menu)), organisms: { type: 'array', items: enumOf(organisms) },
                endpoints: { type: 'array', items: { type: 'string' } }, continuesIn: optionalEnum(d2MenuPages(context.menu)),
            }) },
    });
    return row(['types', 'endpoints', 'bindings'], {
        types: { type: 'array', items: row(['name', 'fields'], { name: { type: 'string' }, description: { type: 'string' }, fields: { type: 'array', items: leaf } }) },
        endpoints: { type: 'array', items: row(['id', 'kind', 'when', 'input', 'output', 'rules', 'jsdoc'], {
                id: { type: 'string' },
                kind: { type: 'string', enum: ['qry', 'cmd'] },
                when: enumOf(['onLoad', 'interaction', ...submits]),
                writes: optionalEnum(pageWrites(context.need).map(item => item.key)),
                input: { type: 'array', items: leaf },
                output: { type: 'array', items: leaf },
                rules: { type: 'array', items: enumOf(Object.keys(slice.rules)) },
                jsdoc: row(['purpose', 'input', 'processing', 'output'], { purpose: { type: 'string' }, input: { type: 'string' }, processing: { type: 'string' }, output: { type: 'string' } }),
            }) },
        bindings,
    });
}
const row = (required, properties) => ({ type: 'object', additionalProperties: false, required, properties });
const productionWriter = { writeJson };
/**
 * B: the answer passes the tool format (field leaves take the ontology name and type) and the fact checks, and the
 * shared code derives from it passes D (d2_75): a binding that leaves an organism unfed goes back to A. Otherwise the
 * whole list of findings is the refusal.
 */
export function d2BffApproved(context, raw) {
    const format = [];
    const design = normalizeD2BffDesign(buildD2BffDesign(raw, format), context.entities, d2ContractsTypeName(context.pageId));
    const issues = [...format, ...checkD2Bff(design, context)];
    if (!issues.length) {
        const access = d2BffAccess(design, context.need, context.grants);
        const input = { ...context, design, access: { actors: access.actors, grants: access.grants }, siblings: [] };
        issues.push(...d2SharedDeriveIssues(input, deriveD2Shared(input)));
    }
    if (issues.length)
        throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    return design;
}
export async function approveD2BffUnit(context, raw, promptChars, repairPromptChars = 0, writer = productionWriter) {
    const design = d2BffApproved(context, raw);
    const receipt = {
        schemaVersion: D2_BFF_VERSION, ...context.identity, pageId: context.pageId, inputHash: context.inputHash,
        unitInputHash: await bffUnitInputHash(context), promptHash: await sha256Text(context.prompt),
        promptChars, repairPromptChars, designHash: await sha256Text(JSON.stringify(design)),
    };
    await writer.writeJson(bffDesignInfo(context.identity, context.pageId), design);
    await writer.writeJson(bffReceiptInfo(context.identity, context.pageId), receipt);
    return receipt;
}
export async function readD2BffReceipt(identity, pageId) {
    const value = await readJson(bffReceiptInfo(identity, pageId));
    return value?.schemaVersion === D2_BFF_VERSION ? value : null;
}
export async function readD2BffRefusal(identity, pageId) {
    const value = await readJson(bffReceiptInfo(identity, pageId));
    return value?.schemaVersion === D2_BFF_REFUSAL_VERSION ? value : null;
}
/**
 * The design on disk as it was written (d2_77): it was normalized once, before writing, and is never parsed again (the
 * saved form is the design, not the tool answer). null only when no receipt approves a design; a missing, unreadable or
 * changed file is an error that names the cause.
 */
export async function readApprovedD2Bff(identity, pageId, port = { readReceipt: readD2BffReceipt, readDesign: readJson }) {
    const receipt = await port.readReceipt(identity, pageId);
    if (!receipt)
        return null;
    const where = displayPath(bffDesignInfo(identity, pageId));
    let design;
    try {
        design = await port.readDesign(bffDesignInfo(identity, pageId));
    }
    catch (error) {
        throw new Error(`D2_BFF_APPROVED_UNREADABLE: ${where}: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (design === null || design === undefined)
        throw new Error(`D2_BFF_APPROVED_MISSING: ${where} is absent although its receipt approves a design.`);
    const hash = await sha256Text(JSON.stringify(design));
    if (hash !== receipt.designHash)
        throw new Error(`D2_BFF_APPROVED_CHANGED: ${where} hashes to ${hash}, its receipt approves ${receipt.designHash}.`);
    return design;
}
export async function loadD2BffContext(identity, pageId) {
    const snapshot = await readD2Input(identity);
    if (!snapshot)
        throw new Error('D2_BFF_INPUT_MISSING');
    const bundle = await readD2InputBundle(identity);
    await assertD2InputSourcesStable(bundle);
    if (!snapshot.selection.writePageIds.includes(pageId))
        throw new Error(`D2_BFF_PAGE_NOT_SELECTED: ${pageId}`);
    const devices = ['desktop', 'mobile'];
    const texts = await Promise.all(devices.map(device => readSourceText(page11Info(identity, pageId, device))));
    const drafts = await Promise.all(devices.map(device => readJson(draftInfo(identity, pageId, device))));
    if (texts.some(text => !text) || drafts.some(draft => !draft))
        throw new Error(`D2_BFF_PAGE11_MISSING: ${pageId}`);
    const prompt = await readSourceText({ project: 102020, level: 2, folder: 'agentDefsL2/steps/bff55', shortName: 'prompt', extension: '.md' });
    const artifacts = bundle.artifacts;
    const need = artifacts.needs.pages.find(item => item.pageId === pageId);
    if (!need)
        throw new Error(`D2_BFF_NEEDS_PAGE: ${pageId}`);
    return {
        ...d2BffContextFrom({
            pageId, page11Text: { desktop: texts[0], mobile: texts[1] }, drafts: { desktop: drafts[0], mobile: drafts[1] },
            need, menu: artifacts.menu, module: artifacts.module, entities: artifacts.entities,
            access: artifacts.access, rules: artifacts.rules, journeys: artifacts.journeys,
        }),
        identity, inputHash: snapshot.snapshotHash, prompt, approved: await readApprovedD2Bff(identity, pageId),
    };
}
/** The pure part of the context: the page pair and the L4 slices it needs. */
export function d2BffContextFrom(input) {
    const linked = Object.entries(input.menu.meta?.journeys ?? {}).filter(([, pages]) => pages.includes(input.pageId)).map(([id]) => id).sort();
    const journeys = linked.flatMap(journeyId => {
        const value = input.journeys[journeyId];
        return value ? [{ journeyId, business: value.business ?? value }] : [];
    });
    return {
        pageId: input.pageId,
        userLanguage: input.menu.userLanguage || input.module?.userLanguage || 'en',
        page11: { desktop: parseD2Page11Definition(input.page11Text.desktop).definition, mobile: parseD2Page11Definition(input.page11Text.mobile).definition },
        page11Text: input.page11Text,
        drafts: { desktop: buildD2Page11Needs(input.drafts.desktop), mobile: buildD2Page11Needs(input.drafts.mobile) },
        draftText: { desktop: JSON.stringify(input.drafts.desktop), mobile: JSON.stringify(input.drafts.mobile) },
        need: input.need,
        menu: input.menu,
        entities: input.entities,
        grants: (input.access?.grants ?? []),
        rules: (input.rules?.rules ?? {}),
        journeys,
    };
}
