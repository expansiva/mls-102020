/// <mls fileReference="_102020_/l2/agentDefsL2/steps/finalize60/io.ts" enhancement="_blank"/>
import { diskFileInfo, readJson, writeJson } from '/_102035_/l2/solution/fs.js';
function owned(identity, shortName) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/finalize60`, shortName, extension: '.json' }; }
export function d2FinalizeReportFile(identity) { return owned(identity, 'report'); }
export function d2OwnershipFile(identity) { return owned(identity, 'ownership'); }
export async function readD2FinalizeReport(identity) { return readJson(d2FinalizeReportFile(identity)); }
export async function readD2Ownership(identity) { return readJson(d2OwnershipFile(identity)); }
export async function writeD2FinalizeReport(identity, value) { if (JSON.stringify(await readD2FinalizeReport(identity)) === JSON.stringify(value))
    return false; await writeJson(d2FinalizeReportFile(identity), value); return true; }
export async function writeD2Ownership(identity, value) { if (JSON.stringify(await readD2Ownership(identity)) === JSON.stringify(value))
    return false; await writeJson(d2OwnershipFile(identity), value); return true; }
export function d2InfoForPath(identity, path) {
    const match = /^l2\/([^/]+)\/(.+)\/([^/]+)(\.defs\.ts)$/.exec(path);
    if (!match || match[1] !== identity.module)
        throw new Error(`D2_FINALIZE_PATH_OUTSIDE_MODULE: ${path}`);
    return { project: identity.project, level: 2, folder: `${identity.module}/${match[2]}`, shortName: match[3], extension: match[4] };
}
export async function deleteD2Owned(info) { const { deleteFile } = await import('/_102027_/l2/libStor.js'); await deleteFile(diskFileInfo(info)); }
