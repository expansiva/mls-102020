/// <mls fileReference="_102020_/l2/agentDefsL2/steps/finalize60/contracts.ts" enhancement="_blank"/>
export const D2_FINALIZE_VERSION = '2026-09-21-agent-defs-l2-finalize-v1';
