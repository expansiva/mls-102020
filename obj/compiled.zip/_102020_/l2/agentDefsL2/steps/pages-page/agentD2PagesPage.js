import { readJson, readSourceText } from '/_102035_/l2/solution/fs.js';
import { D2_PAGES_PAGE_AGENT_NAME, markD2StepApproved, markD2StepFailed, moduleTokenOk } from '/_102020_/l2/agentDefsL2/helpers/d2Core.js';
import { addD2Step, d2Result, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { readD2Input, readD2InputBundle, assertD2InputSourcesStable } from '/_102020_/l2/agentDefsL2/steps/input20/io.js';
import { prepareD2MoleculeContext } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeContext.js';
import { d2MoleculeCatalogPort } from '/_102020_/l2/agentDefsL2/steps/pages50/moleculeCatalog.js';
import { buildD2PageSkillsContext } from '/_102020_/l2/agentDefsL2/steps/pages50/categoryContext.js';
import { d2PageSkillPort, d2TemplatePort } from '/_102020_/l2/agentDefsL2/steps/pages50/categoryCatalog.js';
import { parseD2PagesJudgment } from '/_102020_/l2/agentDefsL2/steps/pages50/gate.js';
import { approveD2PagesUnit, finalizeD2PagesBarrier, getD2PagesContext } from '/_102020_/l2/agentDefsL2/steps/pages50/run.js';
import { deriveD2PageOrganisms, resolveD2PageScenarioState, resolveD2PageScenarioSurfaces } from '/_102020_/l2/agentDefsL2/steps/pages50/contracts.js';
export function createAgent() { return { agentName: D2_PAGES_PAGE_AGENT_NAME, agentProject: 102020, agentFolder: 'agentDefsL2/steps/pages-page', agentDescription: 'Describe desktop and mobile presentations for one page with one bounded repair', visibility: 'private', beforePromptStep, afterPromptStep }; }
export async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    let identity = null;
    try {
        const rawArgs = args || step.prompt || '';
        const parsed = parseArgs(rawArgs);
        identity = { project: parsed.project, module: parsed.module };
        const snapshot = await readD2Input(identity);
        if (!snapshot)
            throw new Error('D2_PAGES_INPUT_MISSING');
        const bundle = await readD2InputBundle(identity);
        await assertD2InputSourcesStable(bundle);
        const [{ page, shared }, molecular, pageSkills, prompt, schema] = await Promise.all([
            getD2PagesContext(identity, snapshot, parsed.pageId), prepareD2MoleculeContext(d2MoleculeCatalogPort),
            buildD2PageSkillsContext(d2PageSkillPort),
            readSourceText({ project: 102020, level: 2, folder: 'agentDefsL2/steps/pages50', shortName: 'prompt', extension: '.md' }),
            readJson({ project: 102020, level: 2, folder: 'agentDefsL2/schemas', shortName: 'pagesJudgmentV3', extension: '.json' }),
        ]);
        if (!schema)
            throw new Error('D2_PAGES_SCHEMA_MISSING');
        if (molecular.receipt.contextHash !== parsed.moleculeContextHash)
            throw new Error(`D2_MOLECULE_CONTEXT_CHANGED: ${parsed.pageId}`);
        const journeys = page.journeyRefs.map(id => bundle.artifacts.journeys[id]).filter(Boolean);
        const templateCatalog = await d2TemplatePort.discover();
        const templateGuidance = { targetPage: 'page11', orientationPage: 'page21', sources: templateCatalog, precedence: 'Shared, DTOs, L4 rules and grants prevail. The selected Markdown reference and hash will be derived from the chosen category; no implicit style preference.' };
        const humanPrompt = JSON.stringify({ page: { pageId: page.pageId, label: page.label, userLanguage: text(record(bundle.artifacts.menu).userLanguage) || 'en', actors: page.actors, ancestors: page.ancestors, authorityRefs: page.authorityRefs, journeys, relevantRules: relevantRules(bundle.artifacts.rules, [...page.authorityRefs, ...page.journeyRefs, page.pageId]), operations: page.operationBindings || [], organisms: deriveD2PageOrganisms(page), reads: page.reads, writes: page.writes }, shared, sceneSurface: { state: resolveD2PageScenarioState(shared), scenaries: resolveD2PageScenarioSurfaces(shared) }, pageCategoryCatalog: JSON.parse(pageSkills.context), moleculeInventory: JSON.parse(molecular.inventory.context), moleculeCandidates: JSON.parse(molecular.candidates.context), moleculeProvenance: molecular.receipt, repair: parsed.feedback ? { feedback: parsed.feedback, previous: parsed.previous } : null }, null, 2);
        const tool = { type: 'function', function: { name: 'submitD2Pages', description: 'Submit page intent and one validated description per source organism for desktop and mobile.', parameters: schema } };
        return [{ type: 'prompt_ready', args: rawArgs, messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', hookSequential, parentStepId: parentStep.stepId, systemPrompt: prompt, humanPrompt: `${humanPrompt}\n\n${JSON.stringify({ templateGuidance })}`, tools: [tool], toolChoice: { type: 'function', function: { name: tool.function.name } } }];
    }
    catch (error) {
        const diagnostic = error instanceof Error ? error.message : String(error);
        if (identity)
            await markD2StepFailed(identity, 'pages50', diagnostic);
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', diagnostic)];
    }
}
export async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const parsed = parseArgs(step.prompt || '');
    const identity = { project: parsed.project, module: parsed.module };
    try {
        const judgment = parseD2PagesJudgment(unwrapD2PagesToolPayload(step.interaction?.payload?.[0]));
        const snapshot = await readD2Input(identity);
        if (!snapshot)
            throw new Error('D2_PAGES_INPUT_MISSING');
        const bundle = await readD2InputBundle(identity);
        await assertD2InputSourcesStable(bundle);
        const verify = () => assertD2InputSourcesStable(bundle);
        const [prepared, pageSkills] = await Promise.all([prepareD2MoleculeContext(d2MoleculeCatalogPort), buildD2PageSkillsContext(d2PageSkillPort)]);
        if (prepared.receipt.contextHash !== parsed.moleculeContextHash)
            throw new Error(`D2_MOLECULE_CONTEXT_CHANGED: ${parsed.pageId}`);
        const molecular = { port: d2MoleculeCatalogPort, prepared };
        await approveD2PagesUnit(identity, snapshot, parsed.pageId, judgment, molecular, pageSkills, parsed.attempt, verify, parsed.moleculeContextHash);
        const refreshed = await prepareD2MoleculeContext(d2MoleculeCatalogPort);
        const manifest = await finalizeD2PagesBarrier(identity, snapshot, verify, pageSkills, { port: d2MoleculeCatalogPort, prepared: refreshed });
        const intents = [];
        if (manifest) {
            await markD2StepApproved(identity, 'pages50', manifest.units.flatMap(unit => Object.values(unit.artifactPaths)), snapshot.snapshotHash);
            intents.push(addD2Step(context, parentStep.stepId, d2Result('Pages ready', JSON.stringify({ ...identity, completedStep: 'pages50', nextStep: 'finalize60', pages: manifest.units.length, defs: manifest.units.length * 2 }), 'pages50-done')));
        }
        intents.push(updateD2Status(context, parentStep, step, hookSequential, 'completed', `pages50 ${parsed.pageId} approved (${manifest ? 'barrier complete' : 'waiting siblings'}).`));
        return intents;
    }
    catch (error) {
        const diagnostic = error instanceof Error ? error.message : String(error);
        if (parsed.attempt < 2) {
            const repair = { ...parsed, attempt: 2, feedback: diagnostic, previous: unwrapD2PagesToolPayload(step.interaction?.payload?.[0]) };
            return [addD2Step(context, parentStep.stepId, { type: 'agent', stepId: 0, interaction: null, stepTitle: `Repair pages ${parsed.pageId}`, status: 'waiting_human_input', nextSteps: [], agentName: D2_PAGES_PAGE_AGENT_NAME, prompt: JSON.stringify(repair), rags: [], planning: { planId: `pages50-repair-${parsed.pageId}-a2`, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' } }), updateD2Status(context, parentStep, step, hookSequential, 'completed', `pages50 ${parsed.pageId} scheduled its only repair: ${diagnostic}`)];
        }
        await markD2StepFailed(identity, 'pages50', `D2_PAGES_REPAIR_LIMIT ${parsed.pageId}: ${diagnostic}`);
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', `D2_PAGES_REPAIR_LIMIT ${parsed.pageId}: ${diagnostic}`)];
    }
}
function parseArgs(value) { let raw; try {
    raw = JSON.parse(String(value));
}
catch {
    throw new Error('D2_PAGES_ARGS_INVALID');
} const item = record(raw); const parsed = { project: Number(item.project), module: text(item.module), pageId: text(item.pageId), attempt: Number(item.attempt), moleculeContextHash: text(item.moleculeContextHash), feedback: text(item.feedback), previous: item.previous }; if (!Number.isSafeInteger(parsed.project) || parsed.project !== Number(mls.actualProject || 0) || !moduleTokenOk(parsed.module) || !/^[a-z][A-Za-z0-9_-]*$/.test(parsed.pageId) || ![1, 2].includes(parsed.attempt) || !/^sha256:[a-f0-9]{64}$/u.test(parsed.moleculeContextHash))
    throw new Error('D2_PAGES_ARGS_INVALID'); return parsed; }
export function unwrapD2PagesToolPayload(value) {
    const root = record(value);
    if (root.type === 'flexible') {
        const result = record(root.result);
        if (text(result.toolName) !== 'submitD2Pages')
            throw new Error('D2_PAGES_TOOL_MISMATCH');
        if (!Object.prototype.hasOwnProperty.call(result, 'arguments'))
            throw new Error('D2_PAGES_SCHEMA_TRUNCATED');
        return parseCandidate(result.arguments);
    }
    return parseCandidate(root.arguments ?? root.payload ?? root);
}
function parseCandidate(candidate) { if (typeof candidate !== 'string')
    return candidate; try {
    return JSON.parse(candidate);
}
catch {
    throw new Error('D2_PAGES_SCHEMA_TRUNCATED');
} }
function relevantRules(value, refs) { const source = record(record(value).rules); const needles = new Set(refs.filter(Boolean)); if (Array.isArray(source))
    return source.filter(item => needles.has(text(record(item).ruleId))); return Object.entries(source).filter(([id]) => needles.has(id)).map(([ruleId, description]) => ({ ruleId, description })); }
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
