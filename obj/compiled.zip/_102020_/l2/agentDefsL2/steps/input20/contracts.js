/// <mls fileReference="_102020_/l2/agentDefsL2/steps/input20/contracts.ts" enhancement="_blank"/>
export const D2_INPUT_VERSION = '2026-09-21-agent-defs-l2-input-v1';
export const D2_INPUT_REPORT_VERSION = '2026-09-21-agent-defs-l2-input-report-v1';
export class D2InputValidationError extends Error {
    constructor(problems) {
        super(problems.map(problem => `${problem.code}: ${problem.message}`).join('; ') || 'input validation failed');
        this.problems = problems;
        this.name = 'D2InputValidationError';
    }
}
