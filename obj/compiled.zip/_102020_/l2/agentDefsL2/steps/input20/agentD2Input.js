/// <mls fileReference="_102020_/l2/agentDefsL2/steps/input20/agentD2Input.ts" enhancement="_blank"/>
import { D2_INPUT_AGENT_NAME, markD2StepApproved, markD2StepFailed, parseD2StepInvocation } from '/_102020_/l2/agentDefsL2/helpers/d2Core.js';
import { addD2Step, d2Result, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { buildD2InputSnapshot } from '/_102020_/l2/helpers/defsInput/gate.js';
import { assertD2InputSourcesStable, readD2Input, readD2InputBundle, writeAcceptedD2Input, writeRefusedD2Input } from '/_102020_/l2/helpers/defsInput/io.js';
import { D2InputValidationError } from '/_102020_/l2/helpers/defsInput/contracts.js';
export function createAgent() {
    return { agentName: D2_INPUT_AGENT_NAME, agentProject: 102020, agentFolder: 'agentDefsL2/steps/input20', agentDescription: 'Validate and freeze page11 input without an LLM call', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const parsed = parseD2StepInvocation(args || step.prompt || '', Number(mls.actualProject || 0));
    if (parsed.kind === 'refusal')
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', parsed.diagnostic)];
    const identity = { project: parsed.project, module: parsed.module };
    try {
        const previous = await readD2Input(identity);
        const bundle = await readD2InputBundle(identity);
        const snapshot = await buildD2InputSnapshot(identity, bundle.artifacts, previous);
        await assertD2InputSourcesStable(bundle);
        const persisted = await writeAcceptedD2Input(identity, snapshot);
        await markD2StepApproved(identity, 'input20', [`l2/${identity.module}/pipeline/agentDefsL2/input.json`], snapshot.snapshotHash);
        const result = JSON.stringify({ ...identity, completedStep: 'input20', nextStep: 'pages50', snapshotHash: snapshot.snapshotHash, writePages: snapshot.selection.writePageIds.length, reused: persisted.reused });
        return [addD2Step(context, parentStep.stepId, d2Result('Inputs ready', result, 'input20-done')),
            updateD2Status(context, parentStep, step, hookSequential, 'completed', `input20 accepted ${snapshot.selection.pages.length} page(s), snapshot ${snapshot.snapshotHash}`)];
    }
    catch (error) {
        const problems = error instanceof D2InputValidationError ? error.problems : [{ severity: 'error', code: 'INPUT_READ_FAILURE', file: 'input20', message: error instanceof Error ? error.message : String(error) }];
        await writeRefusedD2Input(identity, problems);
        const diagnostic = problems.map(problem => `${problem.code}: ${problem.message}`).join('; ');
        await markD2StepFailed(identity, 'input20', diagnostic);
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', diagnostic)];
    }
}
