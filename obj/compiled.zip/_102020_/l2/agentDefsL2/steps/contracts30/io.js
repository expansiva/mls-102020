/// <mls fileReference="_102020_/l2/agentDefsL2/steps/contracts30/io.ts" enhancement="_blank"/>
import { displayPath, readJson, readSourceText, writeJson, writeSourceText, } from '/_102035_/l2/solution/fs.js';
export function d2ContractFile(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/contracts`, shortName: safePageId(pageId), extension: '.defs.ts' };
}
export function d2ContractDraftFile(identity, pageId) {
    return ownedFile(identity, 'drafts', safePageId(pageId));
}
export function d2ContractResultFile(identity, pageId) {
    return ownedFile(identity, 'results', safePageId(pageId));
}
export function d2ContractsManifestFile(identity) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2`, shortName: 'contracts', extension: '.json' };
}
export async function readD2ContractSource(identity, pageId) {
    try {
        return await readSourceText(d2ContractFile(identity, pageId));
    }
    catch {
        return '';
    }
}
export async function writeD2ContractSource(identity, pageId, source) {
    await writeSourceText(d2ContractFile(identity, pageId), source);
}
export async function readD2ContractDraft(identity, pageId) {
    return readJson(d2ContractDraftFile(identity, pageId));
}
export async function writeD2ContractDraft(identity, draft) {
    if (sameJson(await readD2ContractDraft(identity, draft.pageId), draft))
        return;
    await writeJson(d2ContractDraftFile(identity, draft.pageId), draft);
}
export async function readD2ContractResult(identity, pageId) {
    return readJson(d2ContractResultFile(identity, pageId));
}
export async function writeD2ContractResult(identity, result) {
    if (sameJson(await readD2ContractResult(identity, result.pageId), result))
        return;
    await writeJson(d2ContractResultFile(identity, result.pageId), result);
}
export async function readD2ContractsManifest(identity) {
    return readJson(d2ContractsManifestFile(identity));
}
/** Downstream phases consume only a complete barrier for their exact immutable input snapshot. */
export async function readApprovedD2ContractsManifest(identity, snapshotHash) {
    const manifest = await readD2ContractsManifest(identity);
    return manifest?.status === 'approved' && manifest.snapshotHash === snapshotHash ? manifest : null;
}
export async function writeD2ContractsManifest(identity, manifest) {
    if (sameJson(await readD2ContractsManifest(identity), manifest))
        return;
    await writeJson(d2ContractsManifestFile(identity), manifest);
}
export function d2ContractDisplayPath(identity, pageId) {
    return displayPath(d2ContractFile(identity, pageId));
}
function ownedFile(identity, kind, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/contracts30/${kind}`, shortName: pageId, extension: '.json' };
}
function safePageId(value) {
    if (!/^[a-z][A-Za-z0-9_-]*$/.test(value))
        throw new Error(`D2_CONTRACT_PAGE_ID_UNSAFE: ${value}`);
    return value;
}
function sameJson(left, right) { return JSON.stringify(left) === JSON.stringify(right); }
