export function renderD2Shared(definition, pipeline) {
    return `export const definition = ${JSON.stringify(definition, null, 2)} as const;\n\nexport const pipeline = ${JSON.stringify(pipeline, null, 2)} as const;\n`;
}
