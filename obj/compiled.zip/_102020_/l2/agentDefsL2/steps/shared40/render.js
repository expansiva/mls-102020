import { d2Header } from '/_102020_/l2/agentDefsL2/helpers/d2Header.js';
export function renderD2Shared(definition, pipeline, project) {
    return `${d2Header(pipeline.defPath, project)}\n\nexport const definition = ${JSON.stringify(definition, null, 2)} as const;\n\nexport const pipeline = ${JSON.stringify([pipeline], null, 2)} as const;\n`;
}
export function parseD2RenderedShared(source) {
    const definition = parseExport(source, 'definition');
    const pipeline = parseExport(source, 'pipeline');
    if (!definition || typeof definition !== 'object' || Array.isArray(definition) || !Array.isArray(pipeline))
        throw new Error('D2_SHARED_CONSUMER_SHAPE');
    return { definition: definition, pipeline: pipeline };
}
function parseExport(source, name) {
    const match = new RegExp(`export const ${name} = ([\\s\\S]*?) as const;`).exec(source);
    if (!match)
        throw new Error(`D2_SHARED_EXPORT_MISSING: ${name}`);
    try {
        return JSON.parse(match[1]);
    }
    catch {
        throw new Error(`D2_SHARED_EXPORT_INVALID: ${name}`);
    }
}
