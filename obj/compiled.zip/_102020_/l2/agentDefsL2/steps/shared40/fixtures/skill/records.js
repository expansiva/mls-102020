import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { deleteRecordRoute, listRecordsRoute } from '/_102020_/l2/agentDefsL2/steps/shared40/fixtures/skill/records.defs.js';
export class RecordsShared extends StateLitElement {
    constructor() {
        super(...arguments);
        this.pageStatus = 'idle';
        this.scenary = 'base';
        this.selectedRecordId = null;
        this.listRecordsResult = [];
        this.listRecordsStatus = 'idle';
        this.listRecordsError = null;
        this.deleteRecordStatus = 'idle';
        this.deleteRecordError = null;
    }
    async listRecords() {
        this.listRecordsStatus = 'loading';
        const params = {};
        const response = await execBff(listRecordsRoute, params, { mode: 'silent' });
        if (!response.ok) {
            this.listRecordsError = response.error?.message || 'Request failed.';
            this.listRecordsStatus = 'error';
            return;
        }
        this.listRecordsResult = response.data ?? [];
        setState('ui.records.listRecords.result', this.listRecordsResult);
        this.listRecordsStatus = 'success';
    }
    enterDeleteRecordScenario() {
        if (!this.selectedRecordId) {
            this.deleteRecordError = 'Select a record first.';
            return;
        }
        this.scenary = 'deleteRecord';
        setState('ui.records.scenary', this.scenary);
    }
    async deleteRecord() {
        const id = this.selectedRecordId;
        if (!id) {
            this.deleteRecordError = 'Select a record first.';
            return;
        }
        await runBlockingUiAction(async (signal) => {
            this.deleteRecordStatus = 'loading';
            const params = { id };
            const response = await execBff(deleteRecordRoute, params, { mode: 'blocking', signal });
            if (!response.ok) {
                this.deleteRecordError = response.error?.message || 'Request failed.';
                this.deleteRecordStatus = 'error';
                return;
            }
            this.deleteRecordStatus = 'success';
            await this.listRecords();
        }, { mode: 'blocking' });
    }
    connectedCallback() {
        super.connectedCallback();
        this.selectedRecordId = getState('ui.records.deleteRecord.input.id') ?? null;
        subscribe(['ui.records.deleteRecord.input.id'], this);
        void this.listRecords();
    }
    disconnectedCallback() { unsubscribe(['ui.records.deleteRecord.input.id'], this); super.disconnectedCallback(); }
    handleIcaStateChange(key, value) {
        if (key === 'ui.records.deleteRecord.input.id')
            this.selectedRecordId = typeof value === 'string' ? value : null;
        this.requestUpdate();
    }
}
