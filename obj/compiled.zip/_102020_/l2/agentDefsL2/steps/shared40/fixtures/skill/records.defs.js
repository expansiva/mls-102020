export const listRecordsRoute = 'fixture.records.qryListRecords';
export const deleteRecordRoute = 'fixture.records.cmdDeleteRecord';
