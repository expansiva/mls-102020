export const listItemsRoute = 'fixture.catalog.qryListItems';
export const deleteItemRoute = 'fixture.catalog.cmdDeleteItem';
export const updateItemRoute = 'fixture.catalog.cmdUpdateItem';
