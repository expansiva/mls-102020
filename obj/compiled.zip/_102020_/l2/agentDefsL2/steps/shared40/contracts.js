/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared40/contracts.ts" enhancement="_blank"/>
export const D2_SHARED_VERSION = '2026-09-24-agent-defs-l2-shared-v3';
export const D2_SHARED_JUDGMENT_VERSION = '2026-09-21-agent-defs-l2-shared-judgment-v1';
export const D2_SHARED_SKILL = '_102020_/l2/agentDefsL2/skills/genD2SharedTs.ts';
export const D2_SHARED_RUNTIME_CONTEXT = '_102029_.d.ts';
export const D2_SHARED_KEYS = ['schemaVersion', 'moduleName', 'pageId', 'pageName', 'baseClassName', 'routePattern', 'contractRef', 'states', 'actions', 'scenaries', 'initialLoads', 'dataBindings'];
export function buildD2SharedDefinition(moduleName, page, contract, judgment) {
    const states = [
        { stateKey: `ui.${page.pageId}.pageStatus`, name: 'pageStatus', kind: 'pageStatus', defaultValue: 'idle', valueSet: ['idle', 'loading', 'empty', 'success', 'error'] },
        { stateKey: `ui.${page.pageId}.scenary`, name: 'scenary', kind: 'uiScenary', defaultValue: 'base', valueSet: judgment.scenaries.map(item => item.value) },
    ];
    const behavior = new Map(judgment.actionBehaviors.map(item => [item.actionId, item]));
    const actions = [];
    const dataBindings = [];
    for (const call of contract.calls) {
        const prefix = `ui.${page.pageId}.${call.callName}`;
        const inputStates = flatten(call.input).map(field => {
            const stateKey = `${prefix}.input.${field.path.replace(/^[^.]+\./, '').replace(/\./g, '_').replace('$', '')}`;
            const selected = isSelectedEntity(call, field);
            const snapshot = field.writePrecondition;
            const editable = !selected && !snapshot;
            states.push({ stateKey, name: field.name, kind: 'input', defaultValue: null, actionRef: call.callName, contractRef: `${call.callPascal}Input.${field.path}`, source: selected || snapshot ? 'selectedEntity' : 'userInput', presentation: snapshot ? 'hidden' : selected ? 'selection' : 'form', editable, required: field.required });
            if (editable)
                actions.push({ actionId: `set${call.callPascal}${field.path.split('.').slice(1).map(part => pascal(part.replace(/^\$/, ''))).join('')}`, kind: 'stateSetter', inputStateKeys: [], outputStateKeys: [stateKey], statusStateKey: '', errorStateKey: '', refreshActionIds: [], stateKey });
            return stateKey;
        });
        const statusStateKey = `${prefix}.status`;
        const errorStateKey = `${prefix}.error`;
        const resultStateKey = `${prefix}.result`;
        states.push({ stateKey: statusStateKey, name: `${call.callName}Status`, kind: 'actionStatus', defaultValue: 'idle', valueSet: ['idle', 'loading', 'success', 'error'], actionRef: call.callName }, { stateKey: errorStateKey, name: `${call.callName}Error`, kind: 'actionError', defaultValue: null, actionRef: call.callName }, { stateKey: resultStateKey, name: `${call.callName}Result`, kind: call.operation === 'list' || call.operation === 'get' ? 'queryResult' : 'commandOutput', defaultValue: call.outputShape === 'array' ? [] : null, actionRef: call.callName, contractRef: `${call.callPascal}Output`, outputShape: call.outputShape });
        const item = behavior.get(call.callName);
        const kind = call.operation === 'list' || call.operation === 'get' ? 'query' : 'command';
        actions.push({ actionId: call.callName, kind, commandRef: call.callName, routeRef: call.routeName, inputTypeRef: `${call.callPascal}Input`, outputTypeRef: `${call.callPascal}Output`, inputStateKeys: inputStates, outputStateKeys: [resultStateKey], statusStateKey, errorStateKey, refreshActionIds: item?.refreshActionIds || [], ...(item?.destructive && item.confirmation ? { confirmation: { required: true, ...item.confirmation } } : {}) });
        const snapshotPreconditions = buildSnapshotPreconditions(page.pageId, contract, call);
        dataBindings.push({ actionId: call.callName, kind, routeRef: call.routeName, inputTypeRef: `${call.callPascal}Input`, outputTypeRef: `${call.callPascal}Output`, inputStateKeys: inputStates, resultStateKey, ...(snapshotPreconditions.length ? { snapshotPreconditions } : {}) });
    }
    return {
        schemaVersion: D2_SHARED_VERSION, moduleName, pageId: page.pageId, pageName: page.label,
        baseClassName: `${pascal(page.pageId)}Shared`, routePattern: routeOf(page),
        contractRef: { defPath: `l2/${moduleName}/web/contracts/${page.pageId}.defs.ts`, calls: contract.calls.map(call => ({ actionId: call.callName, routeConst: call.routeName, inputType: `${call.callPascal}Input`, outputType: `${call.callPascal}Output` })) },
        states, actions, scenaries: judgment.scenaries,
        initialLoads: judgment.initialLoadActionIds.map(actionId => ({ actionId, stateKey: `ui.${page.pageId}.${actionId}.result` })),
        dataBindings,
    };
}
export function buildD2SharedPipeline(moduleName, pageId) {
    return { id: `${pageId}__l2_shared`, type: 'l2_shared', defPath: `l2/${moduleName}/web/shared/${pageId}.defs.ts`, outputPath: `l2/${moduleName}/web/shared/${pageId}.ts`, dependsFiles: [`l2/${moduleName}/web/contracts/${pageId}.defs.ts`, D2_SHARED_RUNTIME_CONTEXT], dependsOn: [], skills: [D2_SHARED_SKILL] };
}
export function suggestedD2SharedJudgment(page, contract) {
    const queries = contract.calls.filter(call => call.operation === 'list' || call.operation === 'get');
    const commands = contract.calls.filter(call => call.operation !== 'list' && call.operation !== 'get');
    const base = queries.find(call => call.operation === 'list') || queries[0] || contract.calls[0];
    return {
        schemaVersion: D2_SHARED_JUDGMENT_VERSION, pageId: page.pageId,
        scenaries: [{ value: 'base', kind: 'base', actionId: base?.callName || '', preconditions: [] }, ...commands.filter(call => !isObviouslyDestructive(call.callName)).map(call => ({ value: call.callName, kind: 'command', actionId: call.callName, preconditions: selectedKeys(page.pageId, call) }))],
        initialLoadActionIds: queries.filter(call => flatten(call.input).every(field => !field.required)).map(call => call.callName),
        actionBehaviors: contract.calls.map(call => ({ actionId: call.callName, refreshActionIds: call.operation === 'list' || call.operation === 'get' ? [] : queries.map(query => query.callName), destructive: isObviouslyDestructive(call.callName), ...(isObviouslyDestructive(call.callName) ? { confirmation: { title: 'Confirm action', description: 'Confirm this destructive action before continuing.' } } : {}) })),
    };
}
export function d2SharedPreconditionStateKeysByAction(page, contract) {
    return Object.fromEntries(contract.calls.map(call => [
        call.callName,
        flatten(call.input).map(field => inputStateKey(page.pageId, call, field)),
    ]));
}
export function flatten(fields) { return fields.flatMap(field => [field, ...flatten(field.children)]); }
export function inputStateKey(pageId, call, field) { return `ui.${pageId}.${call.callName}.input.${field.path.replace(/^[^.]+\./, '').replace(/\./g, '_').replace('$', '')}`; }
export function captureD2SelectedSnapshot(binding, selectedIdentity, result, active) {
    if (selectedIdentity === null || selectedIdentity === undefined)
        return null;
    if (active?.selectedIdentity === selectedIdentity && validScalar(active.value, binding.valueScalar))
        return active.value;
    const rows = Array.isArray(result) ? result : result && typeof result === 'object' ? [result] : [];
    const selected = rows.find(row => readPath(row, binding.identityPath) === selectedIdentity);
    const value = selected ? readPath(selected, binding.valuePath) : undefined;
    return validScalar(value, binding.valueScalar) ? value : null;
}
export function missingD2SnapshotPreconditions(binding, state) {
    return (binding.snapshotPreconditions ?? []).filter(item => !validScalar(state[item.inputStateKey], item.valueScalar)).map(item => item.inputStateKey);
}
function buildSnapshotPreconditions(pageId, contract, call) {
    const fields = flatten(call.input).filter(field => field.writePrecondition);
    if (!fields.length)
        return [];
    const identity = flatten(call.input).find(field => isSelectedEntity(call, field));
    const source = contract.calls.find(candidate => (candidate.operation === 'list' || candidate.operation === 'get')
        && candidate.entityId === call.entityId
        && fields.every(field => flatten(candidate.output).some(output => output.path === field.path))
        && identity && flatten(candidate.output).some(output => output.path === identity.path));
    if (!identity || !source)
        throw new Error(`D2_SHARED_WRITE_PRECONDITION_SOURCE_MISSING: ${call.callName}`);
    return fields.map(field => ({
        inputStateKey: inputStateKey(pageId, call, field),
        selectedIdentityStateKey: inputStateKey(pageId, call, identity),
        sourceActionId: source.callName,
        resultStateKey: `ui.${pageId}.${source.callName}.result`,
        identityPath: identity.path.replace(/^[^.]+\./, ''),
        valuePath: field.path.replace(/^[^.]+\./, ''),
        valueScalar: field.scalar,
        capture: 'onSelection',
        missing: 'blockCommandPreserveEdit',
    }));
}
function readPath(value, dotted) {
    return dotted.split('.').reduce((current, part) => current && typeof current === 'object' ? current[part] : undefined, value);
}
function validScalar(value, scalar) {
    if (value === null || value === undefined)
        return false;
    return scalar === 'object' ? typeof value === 'object' : typeof value === scalar;
}
function selectedKeys(pageId, call) { return flatten(call.input).filter(field => isSelectedEntity(call, field) && field.required).map(field => inputStateKey(pageId, call, field)); }
function isSelectedEntity(call, field) { return field.derived && field.name === 'id' && (call.operation === 'get' || call.operation === 'update' || call.operation === 'transition'); }
export function isObviouslyDestructive(actionId) { return /^(delete|remove|cancel|revoke|deactivate|archive)/i.test(actionId); }
function routeOf(page) { return `/${[...page.ancestors.map(item => item.id), page.pageId].map(segment => segment.replace(/[^A-Za-z0-9_-]/g, '')).filter(Boolean).join('/')}`; }
function pascal(value) { return value.replace(/[^A-Za-z0-9]+(.)/g, (_all, next) => next.toUpperCase()).replace(/^./, first => first.toUpperCase()); }
