/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared40/gate.ts" enhancement="_blank"/>
import { D2_SHARED_JUDGMENT_VERSION, D2_SHARED_KEYS, D2_SHARED_RUNTIME_CONTEXT, D2_SHARED_SKILL, buildD2SharedDefinition, inputLeaves, inputStateKey, isObviouslyDestructive } from '/_102020_/l2/agentDefsL2/steps/shared40/contracts.js';
import { parseD2RenderedShared } from '/_102020_/l2/agentDefsL2/steps/shared40/render.js';
export function parseD2SharedJudgment(value) {
    const root = record(value);
    if (root.schemaVersion !== D2_SHARED_JUDGMENT_VERSION)
        fail('D2_SHARED_SCHEMA_VERSION');
    for (const key of Object.keys(root))
        if (!['schemaVersion', 'pageId', 'scenaries', 'initialLoadActionIds', 'actionBehaviors'].includes(key))
            fail(`D2_SHARED_SCHEMA_UNKNOWN_KEY: ${key}`);
    if (!Array.isArray(root.scenaries) || !Array.isArray(root.initialLoadActionIds) || !Array.isArray(root.actionBehaviors))
        fail('D2_SHARED_SCHEMA_TRUNCATED');
    if (typeof root.pageId !== 'string' || !root.pageId)
        fail('D2_SHARED_SCHEMA_PAGE_ID');
    for (const raw of root.scenaries) {
        const scene = record(raw);
        if (Object.keys(scene).some(key => !['value', 'kind', 'actionId', 'preconditions'].includes(key)))
            fail('D2_SHARED_SCHEMA_UNKNOWN_SCENARY_KEY');
        if (typeof scene.value !== 'string' || typeof scene.actionId !== 'string' || !['base', 'detail', 'command'].includes(String(scene.kind)) || !stringArray(scene.preconditions))
            fail('D2_SHARED_SCHEMA_SCENARY');
    }
    if (!stringArray(root.initialLoadActionIds))
        fail('D2_SHARED_SCHEMA_INITIAL_LOADS');
    for (const raw of root.actionBehaviors) {
        const behavior = record(raw);
        if (Object.keys(behavior).some(key => !['actionId', 'refreshActionIds', 'destructive', 'confirmation'].includes(key)))
            fail('D2_SHARED_SCHEMA_UNKNOWN_BEHAVIOR_KEY');
        if (typeof behavior.actionId !== 'string' || typeof behavior.destructive !== 'boolean' || !stringArray(behavior.refreshActionIds))
            fail('D2_SHARED_SCHEMA_BEHAVIOR');
    }
    return root;
}
export function gateD2Shared(moduleName, page, contract, judgment) {
    const errors = [];
    const callById = new Map(contract.calls.map(call => [call.callName, call]));
    const behaviorById = new Map(judgment.actionBehaviors.map(item => [item.actionId, item]));
    const operationBindings = page.operationBindings ?? [];
    const operationBindingRoutes = operationBindings.map(item => `${item.route}\0${item.actorRef}`);
    if (new Set(operationBindingRoutes).size !== operationBindingRoutes.length)
        errors.push('D2_SHARED_OPERATION_BINDING_DUPLICATE');
    for (const call of contract.calls) {
        const matches = operationBindings.filter(item => item.route === call.route);
        if (!matches.length && call.operation !== 'get' && call.operation !== 'list')
            errors.push(`D2_SHARED_OPERATION_BINDING_COVERAGE: ${call.route}`);
        if (matches.some(item => item.entityId !== call.entityId || item.operation !== call.operation))
            errors.push(`D2_SHARED_OPERATION_BINDING_MISMATCH: ${call.route}`);
        const signatures = matches.map(item => JSON.stringify(item.inputFields.map(field => [field.path, field.origin, field.required]).sort()));
        if (new Set(signatures).size > 1)
            errors.push(`D2_SHARED_OPERATION_BINDING_AMBIGUOUS: ${call.route}`);
    }
    if (judgment.pageId !== page.pageId)
        errors.push('D2_SHARED_PAGE_CHANGED');
    if (behaviorById.size !== contract.calls.length || contract.calls.some(call => !behaviorById.has(call.callName)))
        errors.push('D2_SHARED_ACTION_COVERAGE');
    for (const behavior of judgment.actionBehaviors) {
        const call = callById.get(behavior.actionId);
        if (!call)
            errors.push(`D2_SHARED_ACTION_UNKNOWN: ${behavior.actionId}`);
        for (const refresh of behavior.refreshActionIds) {
            const cited = callById.get(refresh);
            if (!cited || (cited.operation !== 'list' && cited.operation !== 'get'))
                errors.push(`D2_SHARED_REFRESH_NOT_QUERY: ${behavior.actionId} -> ${refresh}`);
        }
        if (behavior.destructive && (!behavior.confirmation?.title || !behavior.confirmation.description))
            errors.push(`D2_SHARED_DESTRUCTIVE_CONFIRMATION: ${behavior.actionId}`);
        if (isObviouslyDestructive(behavior.actionId) && !behavior.destructive)
            errors.push(`D2_SHARED_DESTRUCTIVE_UNMARKED: ${behavior.actionId}`);
        if (!behavior.destructive && behavior.confirmation)
            errors.push(`D2_SHARED_CONFIRMATION_UNUSED: ${behavior.actionId}`);
    }
    const scenes = new Set();
    if (!judgment.scenaries.some(item => item.kind === 'base' && item.value === 'base'))
        errors.push('D2_SHARED_BASE_SCENARY_MISSING');
    for (const scene of judgment.scenaries) {
        if (!scene.value || scenes.has(scene.value))
            errors.push(`D2_SHARED_SCENARY_DUPLICATE: ${scene.value}`);
        scenes.add(scene.value);
        if (!callById.has(scene.actionId) && !(scene.kind === 'base' && !scene.actionId && !scene.preconditions.length && !contract.calls.length))
            errors.push(`D2_SHARED_SCENARY_ACTION_UNKNOWN: ${scene.actionId}`);
        if (behaviorById.get(scene.actionId)?.destructive && scene.kind === 'command')
            errors.push(`D2_SHARED_DESTRUCTIVE_SCENARY: ${scene.actionId}`);
        const sceneCall = callById.get(scene.actionId);
        const knownStates = new Set(sceneCall ? inputLeaves(sceneCall.input).map(field => inputStateKey(page.pageId, sceneCall, field)) : []);
        for (const state of scene.preconditions)
            if (!knownStates.has(state))
                errors.push(`D2_SHARED_PRECONDITION_UNKNOWN: ${state}`);
    }
    for (const actionId of judgment.initialLoadActionIds) {
        const call = callById.get(actionId);
        if (!call || (call.operation !== 'list' && call.operation !== 'get')) {
            errors.push(`D2_SHARED_INITIAL_LOAD_NOT_QUERY: ${actionId}`);
            continue;
        }
        const unavailable = inputLeaves(call.input).filter(field => {
            const input = operationBindings.find(item => item.route === call.route)?.inputFields.find(item => item.path === field.path);
            return (input?.required ?? field.required) && input?.origin !== 'server' && !field.writePrecondition && !field.path.endsWith('$page');
        });
        if (unavailable.length)
            errors.push(`D2_SHARED_INITIAL_LOAD_INPUT_UNAVAILABLE: ${actionId} ${unavailable.map(field => field.path).join(',')}`);
    }
    assertUnique(judgment.initialLoadActionIds, 'D2_SHARED_INITIAL_LOAD_DUPLICATE', errors);
    if (errors.length)
        throw new Error(errors.join('\n'));
    const definition = buildD2SharedDefinition(moduleName, page, contract, judgment);
    if (Object.keys(definition).join('\0') !== D2_SHARED_KEYS.join('\0'))
        fail('D2_SHARED_DEFINITION_KEYS');
    assertUnique(definition.states.map(item => item.stateKey), 'D2_SHARED_STATE_ID_DUPLICATE', errors);
    assertUnique(definition.actions.map(item => item.actionId), 'D2_SHARED_ACTION_ID_DUPLICATE', errors);
    assertUnique([...definition.states.map(item => item.memberName), ...definition.actions.map(item => item.methodName), ...definition.scenaries.map(item => item.methodName || '')], 'D2_SHARED_MEMBER_COLLISION', errors);
    const inherited = new Set(['stateKeys', 'updateStateKeys', 'createRenderRoot', 'connectedCallback', 'disconnectedCallback', 'firstUpdated', 'updated', 'handleIcaStateChange', 'connectMonitoring', 'render', 'requestUpdate', 'update', 'performUpdate', 'willUpdate', 'shouldUpdate']);
    for (const name of [...definition.states.map(item => item.memberName), ...definition.actions.map(item => item.methodName), ...definition.scenaries.map(item => item.methodName || '')]) {
        if (inherited.has(name))
            errors.push(`D2_SHARED_MEMBER_INHERITED: ${name}`);
    }
    const actions = new Set(definition.actions.map(item => item.actionId));
    const states = new Map(definition.states.map(item => [item.stateKey, item]));
    const bindings = new Map(definition.dataBindings.map(item => [item.actionId, item]));
    for (const binding of definition.dataBindings) {
        if (!actions.has(binding.actionId))
            errors.push(`D2_SHARED_BINDING_ACTION_UNKNOWN: ${binding.actionId}`);
        for (const snapshot of binding.snapshotPreconditions ?? []) {
            const token = states.get(snapshot.inputStateKey);
            const identity = states.get(snapshot.selectedIdentityStateKey);
            const source = bindings.get(snapshot.sourceActionId);
            if (!token || token.source !== 'selectedEntity' || token.presentation !== 'hidden' || token.editable !== false || token.required !== true)
                errors.push(`D2_SHARED_WRITE_PRECONDITION_STATE_INVALID: ${snapshot.inputStateKey}`);
            if (!identity || identity.source !== 'selectedEntity')
                errors.push(`D2_SHARED_WRITE_PRECONDITION_IDENTITY_INVALID: ${snapshot.selectedIdentityStateKey}`);
            if (!source || source.kind !== 'query' || source.resultStateKey !== snapshot.resultStateKey)
                errors.push(`D2_SHARED_WRITE_PRECONDITION_SOURCE_INVALID: ${snapshot.sourceActionId}`);
            if (snapshot.capture !== 'onSelection' || snapshot.missing !== 'blockCommandPreserveEdit' || !snapshot.identityPath || !snapshot.valuePath || !['string', 'number', 'boolean', 'object'].includes(snapshot.valueScalar))
                errors.push(`D2_SHARED_WRITE_PRECONDITION_POLICY_INVALID: ${snapshot.inputStateKey}`);
        }
    }
    if (errors.length)
        throw new Error(errors.join('\n'));
    return definition;
}
export function assertD2RenderedShared(source) {
    const exports = [...source.matchAll(/export const\s+([A-Za-z0-9_]+)/gu)].map(match => match[1]);
    if (exports.join(',') !== 'definition,pipeline')
        fail('D2_SHARED_RENDER_EXPORTS');
    const { definition, pipeline } = parseD2RenderedShared(source);
    if (pipeline.length !== 1)
        fail('D2_SHARED_PIPELINE_COUNT');
    const renderedDefinition = record(definition);
    const renderedContract = record(renderedDefinition.contractRef);
    const moduleName = typeof renderedDefinition.moduleName === 'string' ? renderedDefinition.moduleName : '';
    const pageId = typeof renderedDefinition.pageId === 'string' ? renderedDefinition.pageId : '';
    const contractPath = typeof renderedContract.defPath === 'string' ? renderedContract.defPath : '';
    if (!moduleName || !pageId || contractPath !== `l2/${moduleName}/web/contracts/${pageId}.defs.ts`)
        fail('D2_SHARED_DEFINITION_SHAPE');
    const item = record(pipeline[0]);
    const header = /^\/\/\/ <mls fileReference="(?:_[0-9]+_\/)?(l2\/[^"\n]+)" enhancement="_blank"\/>\n/u.exec(source);
    if (!header || header[1] !== item.defPath || source.slice(header[0].length).split('\n').some(line => /^\s*\/\/\/\s*<mls\b/u.test(line)))
        fail('D2_HEADER_INVALID');
    const keys = Object.keys(item);
    if (keys.some(key => !['id', 'type', 'defPath', 'outputPath', 'dependsFiles', 'dependsOn', 'skills'].includes(key)) || keys.length !== 7)
        fail('D2_SHARED_PIPELINE_SHAPE');
    if (item.type !== 'l2_shared' || item.id !== `${pageId}__l2_shared` || item.defPath !== `l2/${moduleName}/web/shared/${pageId}.defs.ts` || item.outputPath !== `l2/${moduleName}/web/shared/${pageId}.ts`)
        fail('D2_SHARED_PIPELINE_ID');
    if (!Array.isArray(item.dependsOn) || item.dependsOn.length || !Array.isArray(item.dependsFiles) || item.dependsFiles.slice(0, 2).join('\0') !== `${contractPath}\0${D2_SHARED_RUNTIME_CONTEXT}` || item.dependsFiles.slice(2).some(ref => typeof ref !== 'string' || !/^(?:_[0-9]+_\/)?l4\/[A-Za-z0-9_/-]+\.(?:defs\.ts|json|ts|md)$/u.test(ref)))
        fail('D2_SHARED_PIPELINE_CONTEXT');
    if (!Array.isArray(item.skills) || item.skills.join('\0') !== D2_SHARED_SKILL)
        fail('D2_SHARED_PIPELINE_SKILL');
    if (/layoutRef|\bsections\b|\blayout\b/.test(source.slice(header[0].length)))
        fail('D2_SHARED_LAYOUT_FORBIDDEN');
}
function fail(message) { throw new Error(message); }
function assertUnique(values, code, errors) { const seen = new Set(); for (const value of values) {
    if (seen.has(value))
        errors.push(`${code}: ${value}`);
    seen.add(value);
} }
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function stringArray(value) { return Array.isArray(value) && value.every(item => typeof item === 'string'); }
