/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared40/io.ts" enhancement="_blank"/>
import { displayPath, readJson, readSourceText, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
export function d2SharedFile(identity, pageId) { return { project: identity.project, level: 2, folder: `${identity.module}/web/shared`, shortName: safe(pageId), extension: '.defs.ts' }; }
export function d2SharedResultFile(identity, pageId) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/shared40/results`, shortName: safe(pageId), extension: '.json' }; }
export function d2SharedManifestFile(identity) { return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2`, shortName: 'shared', extension: '.json' }; }
export function d2SharedDisplayPath(identity, pageId) { return displayPath(d2SharedFile(identity, pageId)); }
export async function readD2SharedSource(identity, pageId) { try {
    return await readSourceText(d2SharedFile(identity, pageId));
}
catch {
    return '';
} }
export async function writeD2SharedSource(identity, pageId, source) { await writeSourceText(d2SharedFile(identity, pageId), source); }
export async function readD2SharedResult(identity, pageId) { return readJson(d2SharedResultFile(identity, pageId)); }
export async function writeD2SharedResult(identity, result) { if (JSON.stringify(await readD2SharedResult(identity, result.pageId)) !== JSON.stringify(result))
    await writeJson(d2SharedResultFile(identity, result.pageId), result); }
export async function readD2SharedManifest(identity) { return readJson(d2SharedManifestFile(identity)); }
export async function writeD2SharedManifest(identity, manifest) { if (JSON.stringify(await readD2SharedManifest(identity)) !== JSON.stringify(manifest))
    await writeJson(d2SharedManifestFile(identity), manifest); }
function safe(value) { if (!/^[a-z][A-Za-z0-9_-]*$/.test(value))
    throw new Error(`D2_SHARED_PAGE_ID_UNSAFE: ${value}`); return value; }
