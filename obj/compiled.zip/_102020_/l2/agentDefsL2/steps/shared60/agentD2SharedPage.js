/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared60/agentD2SharedPage.ts" enhancement="_blank"/>
import { readJson, readSourceText } from '/_102035_/l2/solution/fs.js';
import { readD2Input, readD2InputBundle, assertD2InputSourcesStable } from '/_102020_/l2/helpers/defsInput/io.js';
import { D2_SHARED_PAGE_AGENT_NAME, markD2StepApproved, moduleTokenOk, readD2Pipeline } from '/_102020_/l2/agentDefsL2/helpers/d2Core.js';
import { addD2Step, d2Result, updateD2Status } from '/_102020_/l2/agentDefsL2/helpers/d2Intents.js';
import { parseD2Page11Definition } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { approveD2SharedUnit, buildD2SharedContext, buildD2SharedPrompt, draftFile, page11File, readD2SharedReceipt, sharedInfo, sharedUnitInputHash, D2_SHARED_VERSION, } from '/_102020_/l2/agentDefsL2/steps/shared60/run.js';
function parseArgs(raw) {
    let value;
    try {
        value = JSON.parse(raw);
    }
    catch {
        throw new Error('D2_SHARED_ARGS_INVALID');
    }
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('D2_SHARED_ARGS_INVALID');
    const args = value;
    if (!Number.isSafeInteger(args.project) || args.project <= 0 || !moduleTokenOk(args.module) || !/^[a-z][A-Za-z0-9_]*$/u.test(args.pageId) || ![1, 2].includes(args.attempt))
        throw new Error('D2_SHARED_ARGS_INVALID');
    return args;
}
function toolPayload(value, name) {
    const root = value && typeof value === 'object' ? value : {};
    const candidate = root.type === 'flexible' ? root.result?.arguments : root.arguments ?? root.payload ?? root;
    if (root.type === 'flexible' && root.result?.toolName !== name)
        throw new Error('D2_SHARED_TOOL_MISMATCH');
    if (typeof candidate !== 'string')
        return candidate;
    try {
        return JSON.parse(candidate);
    }
    catch {
        throw new Error('D2_SHARED_TOOL_JSON');
    }
}
export function createAgent() {
    return { agentName: D2_SHARED_PAGE_AGENT_NAME, agentProject: 102020, agentFolder: 'agentDefsL2/steps/shared60', agentDescription: 'Define one shared v2 page from the deterministic core', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function readPair(identity, pageId) {
    const devices = ['desktop', 'mobile'];
    const texts = await Promise.all(devices.map(device => readSourceText(page11File(identity, pageId, device))));
    const drafts = await Promise.all(devices.map(device => readJson(draftFile(identity, pageId, device))));
    if (texts.some(text => !text) || drafts.some(draft => !draft))
        throw new Error(`D2_SHARED_PAGE11_MISSING: ${pageId}`);
    return {
        page11Text: { desktop: texts[0], mobile: texts[1] },
        draftText: { desktop: JSON.stringify(drafts[0]), mobile: JSON.stringify(drafts[1]) },
        page11: { desktop: parseD2Page11Definition(texts[0]).definition, mobile: parseD2Page11Definition(texts[1]).definition },
        drafts: { desktop: buildD2Page11Needs(drafts[0]), mobile: buildD2Page11Needs(drafts[1]) },
    };
}
export async function contextFor(args) {
    const identity = { project: args.project, module: args.module };
    const snapshot = await readD2Input(identity);
    if (!snapshot)
        throw new Error('D2_SHARED_INPUT_MISSING');
    const bundle = await readD2InputBundle(identity);
    await assertD2InputSourcesStable(bundle);
    if (!snapshot.selection.writePageIds.includes(args.pageId))
        throw new Error(`D2_SHARED_PAGE_NOT_SELECTED: ${args.pageId}`);
    const [skill, prompt, catalog] = await Promise.all([
        readSourceText({ project: 102020, level: 2, folder: 'agentDefsL2/skills', shortName: 'genD2SharedDefinition', extension: '.ts' }),
        readSourceText({ project: 102020, level: 2, folder: 'agentDefsL2/steps/shared60', shortName: 'prompt', extension: '.md' }),
        readJson({ project: 102020, level: 4, folder: 'collabux/templates', shortName: 'categoryList', extension: '.json' }),
    ]);
    if (!catalog?.categories)
        throw new Error('D2_SHARED_CATEGORIES_MISSING');
    const ids = [...snapshot.selection.writePageIds].sort();
    const pairs = new Map();
    for (const pageId of ids)
        pairs.set(pageId, await readPair(identity, pageId));
    const own = pairs.get(args.pageId);
    if (!own)
        throw new Error(`D2_SHARED_PAGE11_MISSING: ${args.pageId}`);
    const siblings = ids.map(pageId => {
        const pair = pairs.get(pageId);
        return { pageId, desktop: pair.page11.desktop, mobile: pair.page11.mobile, draftDesktop: pair.drafts.desktop, draftMobile: pair.drafts.mobile };
    });
    const needs = bundle.artifacts.needs;
    const access = bundle.artifacts.access;
    const rules = bundle.artifacts.rules;
    const menu = bundle.artifacts.menu;
    const input = {
        module: args.module, pageId: args.pageId,
        desktop: own.page11.desktop, mobile: own.page11.mobile, draftDesktop: own.drafts.desktop, draftMobile: own.drafts.mobile,
        siblings, needsPages: needs.pages, menu, entities: bundle.artifacts.entities,
        access, rules, categories: catalog.categories,
    };
    return buildD2SharedContext(input, { identity, inputHash: snapshot.snapshotHash, ...own, skill, prompt });
}
const reusePort = {
    readReceipt: readD2SharedReceipt,
    context: contextFor,
    readShared: (identity, pageId) => readSourceText(sharedInfo(identity, pageId)),
};
export async function reusableD2Shared(identity, pageId, port = reusePort) {
    const receipt = await port.readReceipt(identity, pageId);
    if (!receipt || receipt.schemaVersion !== D2_SHARED_VERSION || receipt.project !== identity.project || receipt.module !== identity.module || receipt.pageId !== pageId)
        return false;
    try {
        const context = await port.context({ ...identity, pageId, attempt: 1 });
        if (await sha256Text(context.skill) !== receipt.skillHash || await sha256Text(context.prompt) !== receipt.promptHash)
            return false;
        const source = await port.readShared(identity, pageId);
        if (await sha256Text(source) !== receipt.sourceHash)
            return false;
        for (const device of ['desktop', 'mobile']) {
            if (await sha256Text(context.page11Text[device]) !== receipt.page11Hashes[device])
                return false;
            if (await sha256Text(context.draftText[device]) !== receipt.draftHashes[device])
                return false;
        }
        return await sharedUnitInputHash(context) === receipt.unitInputHash;
    }
    catch {
        return false;
    }
}
const promptPort = { reusable: reusableD2Shared, context: contextFor };
export async function beforePromptStep(_agent, context, parentStep, step, hookSequential, argsOrPort) {
    try {
        const port = typeof argsOrPort === 'object' ? argsOrPort : promptPort;
        const args = parseArgs(step.prompt || '');
        if (await port.reusable(args, args.pageId)) {
            return [updateD2Status(context, parentStep, step, hookSequential, 'completed', `Shared ${args.pageId} reused without an LLM call or write.`)];
        }
        const data = await port.context(args);
        const built = buildD2SharedPrompt(data, args.diagnostic ? { diagnostic: args.diagnostic, previous: args.previous } : undefined);
        return [{ type: 'prompt_ready', args: step.prompt || '', messageId: context.message.orderAt, threadId: context.message.threadId,
                taskId: context.task?.PK || '', hookSequential, parentStepId: parentStep.stepId, systemPrompt: built.systemPrompt, humanPrompt: built.humanPrompt,
                tools: [{ type: 'function', function: { name: 'submitD2Shared', description: 'Define states, functions, journeys and command returns for one shared page', parameters: sharedSchema } }],
                toolChoice: { type: 'function', function: { name: 'submitD2Shared' } } }];
    }
    catch (error) {
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', error instanceof Error ? error.message : String(error))];
    }
}
export async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const args = parseArgs(step.prompt || '');
    let response;
    try {
        response = toolPayload(step.interaction?.payload?.[0], 'submitD2Shared');
        const data = await contextFor(args);
        const built = buildD2SharedPrompt(data, args.diagnostic ? { diagnostic: args.diagnostic, previous: args.previous } : undefined);
        await approveD2SharedUnit(data, response, built.chars, args.diagnostic ? built.chars : args.repairPromptChars ?? 0);
        const snapshot = await readD2Input(data.identity);
        const ids = [...(snapshot?.selection.writePageIds ?? [])].sort();
        let allReady = Boolean(snapshot);
        for (const pageId of ids)
            if (!await reusableD2Shared(data.identity, pageId)) {
                allReady = false;
                break;
            }
        if (allReady && snapshot) {
            if (await readD2Pipeline(data.identity))
                await markD2StepApproved(data.identity, 'shared60', ids.map(pageId => `l2/${data.identity.module}/pipeline/agentDefsL2/shared60/${pageId}.json`), snapshot.snapshotHash);
            return [addD2Step(context, parentStep.stepId, d2Result('Shared ready', JSON.stringify({ ...data.identity, completedStep: 'shared60', nextStep: 'contracts70', pages: ids.length }), 'shared60-done')),
                updateD2Status(context, parentStep, step, hookSequential, 'completed', `Shared ${args.pageId} approved; all ${ids.length} pages ready.`)];
        }
        return [updateD2Status(context, parentStep, step, hookSequential, 'completed', `Shared ${args.pageId} approved.`)];
    }
    catch (error) {
        const diagnostic = error instanceof Error ? error.message : String(error);
        if (args.attempt === 1)
            return [next(context, parentStep, { ...args, attempt: 2, diagnostic, previous: response }),
                updateD2Status(context, parentStep, step, hookSequential, 'completed', `One repair scheduled for ${args.pageId}: ${diagnostic}`)];
        return [updateD2Status(context, parentStep, step, hookSequential, 'failed', `D2_SHARED_REPAIR_LIMIT: ${diagnostic}`)];
    }
}
function next(context, parentStep, args) {
    return addD2Step(context, parentStep.stepId, { type: 'agent', stepId: 0, interaction: null, stepTitle: `Shared ${args.pageId}`, status: 'waiting_human_input', nextSteps: [], agentName: D2_SHARED_PAGE_AGENT_NAME,
        prompt: JSON.stringify(args), rags: [], planning: { planId: `shared60-${args.pageId}-${args.attempt}`, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' } });
}
const row = (required, properties) => ({ type: 'object', additionalProperties: false, required, properties });
const sharedSchema = row(['states', 'functions', 'journeys', 'commandReturns'], {
    states: { type: 'array', items: row(['id', 'source', 'description'], { id: { type: 'string' }, source: { type: 'string', pattern: '^[A-Za-z][A-Za-z0-9]*(\\.[A-Za-z][A-Za-z0-9]*)*$' }, description: { type: 'string' } }) },
    functions: { type: 'array', items: row(['id', 'description'], { id: { type: 'string' }, description: { type: 'string' }, calls: { type: 'string' }, sets: { type: 'string', pattern: '^[A-Za-z][A-Za-z0-9]*$' }, updates: { type: 'array', items: { type: 'string' } }, navigate: { type: 'string' }, carries: { type: 'object', additionalProperties: { type: 'string' } } }) },
    journeys: { type: 'array', items: row(['step', 'organisms', 'functions'], { step: { type: 'string' }, organisms: { type: 'array', items: { type: 'string' } }, functions: { type: 'array', items: { type: 'string' } }, continuesIn: { type: 'string' } }) },
    commandReturns: { type: 'array', items: row(['requestId', 'returns'], { requestId: { type: 'string' }, returns: { type: 'array', items: { type: 'string' } } }) },
    formChoices: { type: 'array', items: row(['submit', 'organism'], { submit: { type: 'string' }, organism: { type: 'string' } }) },
});
