/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared60/run.ts" enhancement="_blank"/>
import { readJson, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { deriveD2PageRequests } from '/_102020_/l2/agentDefsL2/helpers/d2PageRequests.js';
import { gateD2SharedV2, renderD2SharedV2, sharedFromDerived } from '/_102020_/l2/agentDefsL2/helpers/d2SharedV2.js';
export const D2_SHARED_VERSION = '2026-10-01-agent-defs-l2-shared-v2.1';
export const D2_SHARED_PROMPT_LIMIT_CHARS = 640000;
export const D2_SHARED_SYSTEM_PREFIX = `<!-- modelType: reasoning -->
<!-- reasoningEffort: high -->
<!-- x-tool-strict: true -->`;
export function d2SharedValidSources(derived) {
    const tokens = [];
    for (const request of derived.requests) {
        // load<Key> feeds the list state sourced from load, so its returns are not a state source.
        if (request.id !== 'load' && request.lists.length > 0)
            continue;
        for (const key of request.returns)
            tokens.push(`${request.id}.${key}`);
        if (request.kind === 'cmd')
            tokens.push(`${request.id}.input`);
    }
    for (const name of Object.keys(derived.entry.params))
        tokens.push(`entry.params.${name}`);
    return tokens;
}
export function d2SharedJourneySteps(needs, menu) {
    const linked = new Set(Object.entries(menu.meta?.journeys ?? {}).filter(([, pages]) => pages.includes(needs.pageId)).map(([id]) => id));
    const steps = (needs.reads ?? []).flatMap(read => read.from.filter(item => item.startsWith('journey:')).map(item => item.slice('journey:'.length)));
    return [...new Set(steps.filter(step => linked.has(step.split('/')[0])))];
}
export function buildD2SharedContext(input, extra) {
    const derived = deriveD2PageRequests(input);
    if (derived.issues.length)
        throw new Error(derived.issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    return { ...extra, input, derived };
}
export function buildD2SharedPrompt(context, repair) {
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId);
    if (!need)
        throw new Error('D2_SHARED_NEEDS_PAGE');
    const draftOf = (device) => Object.fromEntries(Object.entries(context.drafts[device].organisms).map(([id, row]) => [id, {
            reads: row.reads, edits: row.edits, selects: row.selects, submits: row.submits,
        }]));
    const pageOf = (device) => ({
        sections: context.page11[device].sections.map(section => ({ id: section.id, organisms: section.organisms })),
        organisms: Object.fromEntries(Object.entries(context.page11[device].organisms).map(([id, row]) => [id, { kind: row.kind, intents: row.intents }])),
    });
    const human = {
        pageId: context.input.pageId,
        entry: context.derived.entry,
        forms: context.derived.forms,
        requests: context.derived.requests.map(request => ({ id: request.id, kind: request.kind, trigger: request.trigger, writes: request.writes, returns: request.returns,
            returnEntities: request.returnEntities, lists: request.lists.map(list => ({ key: list.key, filter: list.filter, loadMore: list.loadMore, organismId: list.organismId })),
            organisms: request.organisms })),
        ruleCandidates: context.derived.rules,
        ruleTexts: Object.fromEntries([...new Set(Object.values(context.derived.rules).flat())].map(id => [id, context.input.rules.rules[id] ?? ''])),
        access: { actors: context.derived.access.actors, grants: context.derived.access.grants },
        validSources: d2SharedValidSources(context.derived),
        commandReturnKeys: [...new Set(need.reads.map(read => read.entity[0].toLowerCase() + read.entity.slice(1)))],
        fixedFunctions: Object.entries(sharedFromDerived(context.derived).functions).map(([id, fn]) => ({ id, ...(fn.calls ? { calls: fn.calls } : {}), ...(fn.sets ? { sets: fn.sets } : {}) })),
        fixedStates: Object.entries(sharedFromDerived(context.derived).states).map(([id, state]) => ({ id, source: state.source })),
        journeySteps: d2SharedJourneySteps(need, context.input.menu),
        page11: { desktop: pageOf('desktop'), mobile: pageOf('mobile') },
        readsAndEdits: { desktop: draftOf('desktop'), mobile: draftOf('mobile') },
        repair: repair ?? null,
    };
    const humanPrompt = JSON.stringify(human);
    const systemPrompt = `${D2_SHARED_SYSTEM_PREFIX}\n\n${context.prompt}\n${context.skill}`;
    const chars = systemPrompt.length + humanPrompt.length;
    if (chars > D2_SHARED_PROMPT_LIMIT_CHARS)
        throw new Error(`D2_SHARED_PROMPT_LIMIT: ${chars}`);
    return { systemPrompt, humanPrompt, chars };
}
export function applyD2SharedLlm(context, raw) {
    const response = normalizeLlm(raw);
    const base = sharedFromDerived(context.derived);
    const page = context.page11.desktop;
    const draft = mergeDraft(context.drafts.desktop, context.drafts.mobile);
    const forms = {};
    // A form may serve several submits, but never two of the same write (two creates in one form).
    const used = new Set();
    for (const form of Object.values(context.derived.forms)) {
        const organismId = form.ambiguous ? choiceFor(response, form.submit, page, draft, form.entity) : form.organism;
        const write = context.derived.requests.find(item => item.id === form.submit)?.writes ?? form.submit;
        if (!organismId || used.has(`${organismId}:${write}`))
            throw new Error(`D2_SHARED_FORM_REUSE: ${form.submit}`);
        const organism = page.organisms[organismId];
        if (!organism)
            throw new Error(`D2_SHARED_FORM_MISSING: ${organismId}`);
        used.add(`${organismId}:${write}`);
        forms[form.submit] = { organism: organismId, submit: form.submit };
    }
    const requests = { ...base.requests };
    for (const row of response.commandReturns) {
        const request = requests[row.requestId];
        if (!request || request.kind !== 'cmd')
            throw new Error(`D2_SHARED_RETURNS_REQUEST: ${row.requestId}`);
        requests[row.requestId] = { ...request, returns: row.returns };
    }
    const functions = { ...base.functions };
    for (const row of response.functions) {
        const current = functions[row.id];
        const calls = current?.calls ?? row.calls;
        const updates = row.updates ?? (calls && requests[calls]?.kind === 'cmd' ? requests[calls].returns : current?.updates);
        // A fixed list function keeps the fixed list state; other functions take the answer's sets.
        const sets = base.functions[row.id]?.sets ?? row.sets;
        functions[row.id] = {
            description: row.description,
            ...(calls ? { calls } : {}),
            ...(sets ? { sets } : {}),
            ...(updates ? { updates } : {}),
            ...(row.navigate ? { navigate: row.navigate } : {}),
            ...(row.carries ? { carries: row.carries } : {}),
        };
    }
    const rules = {};
    for (const row of response.requestRules) {
        if (!requests[row.requestId] || rules[row.requestId])
            throw new Error(`D2_SHARED_RULES_REQUEST: ${row.requestId}`);
        rules[row.requestId] = [...new Set(row.rules)];
    }
    const states = { ...base.states };
    const answered = new Set();
    for (const row of response.states) {
        if (answered.has(row.id))
            throw new Error(`D2_SHARED_STATE_ID: ${row.id}`);
        answered.add(row.id);
        const fixed = base.states[row.id];
        if (fixed && row.source !== fixed.source)
            throw new Error(`D2_SHARED_STATE_FIXED: ${row.id} is the fixed list state with source ${fixed.source}; keep that source.`);
        states[row.id] = { source: fixed?.source ?? row.source, description: row.description };
    }
    return { ...base, forms, requests, states, functions, rules, journeys: response.journeys.map(row => ({
            step: row.step, organisms: row.organisms, functions: row.functions, ...(row.continuesIn ? { continuesIn: row.continuesIn } : {}),
        })) };
}
const productionWriter = { writeSource: writeSourceText, writeJson };
export async function approveD2SharedUnit(context, raw, promptChars, repairPromptChars = 0, writer = productionWriter) {
    const definition = applyD2SharedLlm(context, raw);
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId);
    if (!need)
        throw new Error('D2_SHARED_NEEDS_PAGE');
    const issues = gateD2SharedV2(definition, {
        page11: context.page11.desktop, draft: context.drafts.desktop, needs: need, menu: context.input.menu, derived: context.derived,
    });
    if (issues.length)
        throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    const source = renderD2SharedV2({ ...context.identity, pageId: context.input.pageId }, definition);
    const receipt = {
        schemaVersion: D2_SHARED_VERSION, ...context.identity, pageId: context.input.pageId,
        inputHash: context.inputHash, unitInputHash: await sharedUnitInputHash(context),
        page11Hashes: { desktop: await sha256Text(context.page11Text.desktop), mobile: await sha256Text(context.page11Text.mobile) },
        draftHashes: { desktop: await sha256Text(context.draftText.desktop), mobile: await sha256Text(context.draftText.mobile) },
        skillHash: await sha256Text(context.skill), promptHash: await sha256Text(context.prompt),
        promptChars, repairPromptChars, sourceHash: await sha256Text(source),
    };
    await writer.writeSource(sharedInfo(context.identity, context.input.pageId), source);
    await writer.writeJson(receiptInfo(context.identity, context.input.pageId), receipt);
    return receipt;
}
export async function sharedUnitInputHash(context) {
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId) ?? null;
    return sha256Text(JSON.stringify({
        pageId: context.input.pageId,
        derived: context.derived,
        page11: context.page11Text,
        drafts: context.draftText,
        journeys: d2SharedJourneySteps(need ?? { pageId: context.input.pageId, actors: [], reads: [], writes: [] }, context.input.menu),
        menuJourneys: context.input.menu.meta?.journeys ?? {},
        userLanguage: context.input.menu.userLanguage ?? '',
    }));
}
export function sharedInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/shared`, shortName: pageId, extension: '.defs.ts' };
}
export function receiptInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/shared60`, shortName: pageId, extension: '.json' };
}
export function page11File(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' };
}
export function draftFile(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' };
}
export async function readD2SharedReceipt(identity, pageId) {
    return readJson(receiptInfo(identity, pageId));
}
/** A refused page is recorded where its receipt lives; it is never reusable. */
export const D2_SHARED_REFUSAL_VERSION = '2026-10-02-agent-defs-l2-shared-refusal';
export function d2SharedRefusal(identity, pageId, taskId, diagnostic) {
    return { schemaVersion: D2_SHARED_REFUSAL_VERSION, project: identity.project, module: identity.module, pageId, taskId, diagnostic };
}
export async function readD2SharedRefusal(identity, pageId) {
    const row = await readJson(receiptInfo(identity, pageId));
    return row?.schemaVersion === D2_SHARED_REFUSAL_VERSION ? row : null;
}
/** The stage ends only when every page of this task is accepted or refused; then it passes or fails once. */
export async function settleD2Shared(taskId, port) {
    const ids = await port.pageIds();
    if (!ids)
        throw new Error('D2_SHARED_INPUT_MISSING');
    const refusals = [];
    const pending = [];
    for (const pageId of ids) {
        if (await port.reusable(pageId))
            continue;
        const refusal = await port.refusal(pageId);
        // A refusal left by an earlier task is not this run's answer: the page is being redone.
        if (refusal && refusal.taskId === taskId)
            refusals.push(refusal);
        else
            pending.push(pageId);
    }
    if (pending.length)
        return { state: 'pending', pending };
    if (refusals.length)
        return { state: 'refused', refusals };
    return { state: 'ready', pageIds: ids };
}
export function d2SharedRefusedMessage(refusals) {
    return `D2_SHARED_PAGES_REFUSED: ${refusals.map(row => `${row.pageId}: ${row.diagnostic}`).join(' || ')}`;
}
function choiceFor(response, submit, page, draft, entity) {
    const choices = (response.formChoices ?? []).filter(item => item.submit === submit);
    if (choices.length !== 1)
        throw new Error(`D2_SHARED_FORM_CHOICE: ${submit}`);
    const organismId = choices[0].organism;
    const edits = draft.organisms[organismId]?.edits ?? [];
    if (!page.organisms[organismId] || !edits.length || edits.some(path => path.split('.')[0] !== entity))
        throw new Error(`D2_SHARED_FORM_ENTITY: ${submit}`);
    return organismId;
}
function mergeDraft(left, right) {
    const organisms = { ...left.organisms };
    for (const [id, row] of Object.entries(right.organisms))
        organisms[id] = organisms[id] ?? row;
    return { organisms };
}
function normalizeLlm(raw) {
    if (!raw || !Array.isArray(raw.states) || !Array.isArray(raw.functions) || !Array.isArray(raw.journeys) || !Array.isArray(raw.commandReturns) || !Array.isArray(raw.requestRules))
        throw new Error('D2_SHARED_LLM_SHAPE');
    return raw;
}
