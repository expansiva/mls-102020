/// <mls fileReference="_102020_/l2/agentDefsL2/steps/shared60/run.ts" enhancement="_blank"/>
import { readJson, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { sha256Text } from '/_102020_/l2/helpers/hash.js';
import { deriveD2PageRequests } from '/_102020_/l2/agentDefsL2/helpers/d2PageRequests.js';
import { gateD2SharedV2, renderD2SharedV2, sharedFromDerived } from '/_102020_/l2/agentDefsL2/helpers/d2SharedV2.js';
export const D2_SHARED_VERSION = '2026-09-30-agent-defs-l2-shared-v2';
export const D2_SHARED_PROMPT_LIMIT_CHARS = 160000;
export const D2_SHARED_SYSTEM_PREFIX = `<!-- modelType: reasoning -->
<!-- reasoningEffort: high -->
<!-- x-tool-strict: true -->`;
export function d2SharedValidSources(derived) {
    const tokens = [];
    for (const request of derived.requests) {
        for (const key of request.returns)
            tokens.push(`${request.id}.${key}`);
        if (request.kind === 'cmd')
            tokens.push(`${request.id}.input`);
    }
    for (const name of Object.keys(derived.entry.params))
        tokens.push(`entry.params.${name}`);
    return tokens;
}
export function d2SharedJourneySteps(needs, menu) {
    const linked = new Set(Object.entries(menu.meta?.journeys ?? {}).filter(([, pages]) => pages.includes(needs.pageId)).map(([id]) => id));
    const steps = (needs.reads ?? []).flatMap(read => read.from.filter(item => item.startsWith('journey:')).map(item => item.slice('journey:'.length)));
    return [...new Set(steps.filter(step => linked.has(step.split('/')[0])))];
}
export function buildD2SharedContext(input, extra) {
    const derived = deriveD2PageRequests(input);
    if (derived.issues.length)
        throw new Error(derived.issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    return { ...extra, input, derived };
}
export function buildD2SharedPrompt(context, repair) {
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId);
    if (!need)
        throw new Error('D2_SHARED_NEEDS_PAGE');
    const draftOf = (device) => Object.fromEntries(Object.entries(context.drafts[device].organisms).map(([id, row]) => [id, {
            reads: row.reads, edits: row.edits, selects: row.selects, submits: row.submits,
        }]));
    const pageOf = (device) => ({
        sections: context.page11[device].sections.map(section => ({ id: section.id, organisms: section.organisms })),
        organisms: Object.fromEntries(Object.entries(context.page11[device].organisms).map(([id, row]) => [id, { kind: row.kind, intents: row.intents }])),
    });
    const human = {
        pageId: context.input.pageId,
        entry: context.derived.entry,
        forms: context.derived.forms,
        requests: context.derived.requests.map(request => ({ id: request.id, kind: request.kind, trigger: request.trigger, writes: request.writes, returns: request.returns, organisms: request.organisms })),
        rules: context.derived.rules,
        access: { actors: context.derived.access.actors, grants: context.derived.access.grants },
        validSources: d2SharedValidSources(context.derived),
        fixedFunctions: Object.entries(sharedFromDerived(context.derived).functions).map(([id, fn]) => ({ id, ...(fn.calls ? { calls: fn.calls } : {}) })),
        journeySteps: d2SharedJourneySteps(need, context.input.menu),
        page11: { desktop: pageOf('desktop'), mobile: pageOf('mobile') },
        readsAndEdits: { desktop: draftOf('desktop'), mobile: draftOf('mobile') },
        repair: repair ?? null,
    };
    const humanPrompt = JSON.stringify(human);
    const systemPrompt = `${D2_SHARED_SYSTEM_PREFIX}\n\n${context.prompt}\n${context.skill}`;
    const chars = systemPrompt.length + humanPrompt.length;
    if (chars > D2_SHARED_PROMPT_LIMIT_CHARS)
        throw new Error(`D2_SHARED_PROMPT_LIMIT: ${chars}`);
    return { systemPrompt, humanPrompt, chars };
}
export function applyD2SharedLlm(context, raw) {
    const response = normalizeLlm(raw);
    const base = sharedFromDerived(context.derived);
    const page = context.page11.desktop;
    const draft = mergeDraft(context.drafts.desktop, context.drafts.mobile);
    const forms = {};
    const used = new Set();
    for (const form of Object.values(context.derived.forms)) {
        const organismId = form.ambiguous ? choiceFor(response, form.submit, page, draft, form.entity) : form.organism;
        if (!organismId || used.has(organismId))
            throw new Error(`D2_SHARED_FORM_REUSE: ${form.submit}`);
        const organism = page.organisms[organismId];
        if (!organism)
            throw new Error(`D2_SHARED_FORM_MISSING: ${organismId}`);
        used.add(organismId);
        forms[organismId] = { organism: organismId, submit: form.submit };
    }
    const requests = { ...base.requests };
    for (const row of response.commandReturns) {
        const request = requests[row.requestId];
        if (!request || request.kind !== 'cmd')
            throw new Error(`D2_SHARED_RETURNS_REQUEST: ${row.requestId}`);
        requests[row.requestId] = { ...request, returns: row.returns };
    }
    const functions = { ...base.functions };
    for (const row of response.functions) {
        const current = functions[row.id];
        const calls = current?.calls ?? row.calls;
        const updates = row.updates ?? (calls && requests[calls]?.kind === 'cmd' ? requests[calls].returns : current?.updates);
        functions[row.id] = {
            description: row.description,
            ...(calls ? { calls } : {}),
            ...(row.sets ? { sets: row.sets } : current?.sets ? { sets: current.sets } : {}),
            ...(updates ? { updates } : {}),
            ...(row.navigate ? { navigate: row.navigate } : {}),
            ...(row.carries ? { carries: row.carries } : {}),
        };
    }
    const states = {};
    for (const row of response.states) {
        if (states[row.id])
            throw new Error(`D2_SHARED_STATE_ID: ${row.id}`);
        states[row.id] = { source: row.source, description: row.description };
    }
    return { ...base, forms, requests, states, functions, journeys: response.journeys.map(row => ({
            step: row.step, organisms: row.organisms, functions: row.functions, ...(row.continuesIn ? { continuesIn: row.continuesIn } : {}),
        })) };
}
const productionWriter = { writeSource: writeSourceText, writeJson };
export async function approveD2SharedUnit(context, raw, promptChars, repairPromptChars = 0, writer = productionWriter) {
    const definition = applyD2SharedLlm(context, raw);
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId);
    if (!need)
        throw new Error('D2_SHARED_NEEDS_PAGE');
    const issues = gateD2SharedV2(definition, {
        page11: context.page11.desktop, draft: context.drafts.desktop, needs: need, menu: context.input.menu, derived: context.derived,
    });
    if (issues.length)
        throw new Error(issues.map(issue => `${issue.code}: ${issue.message}`).join(' | '));
    const source = renderD2SharedV2({ ...context.identity, pageId: context.input.pageId }, definition);
    const receipt = {
        schemaVersion: D2_SHARED_VERSION, ...context.identity, pageId: context.input.pageId,
        inputHash: context.inputHash, unitInputHash: await sharedUnitInputHash(context),
        page11Hashes: { desktop: await sha256Text(context.page11Text.desktop), mobile: await sha256Text(context.page11Text.mobile) },
        draftHashes: { desktop: await sha256Text(context.draftText.desktop), mobile: await sha256Text(context.draftText.mobile) },
        skillHash: await sha256Text(context.skill), promptHash: await sha256Text(context.prompt),
        promptChars, repairPromptChars, sourceHash: await sha256Text(source),
    };
    await writer.writeSource(sharedInfo(context.identity, context.input.pageId), source);
    await writer.writeJson(receiptInfo(context.identity, context.input.pageId), receipt);
    return receipt;
}
export async function sharedUnitInputHash(context) {
    const need = context.input.needsPages.find(item => item.pageId === context.input.pageId) ?? null;
    return sha256Text(JSON.stringify({
        pageId: context.input.pageId,
        derived: context.derived,
        page11: context.page11Text,
        drafts: context.draftText,
        journeys: d2SharedJourneySteps(need ?? { pageId: context.input.pageId, actors: [], reads: [], writes: [] }, context.input.menu),
        menuJourneys: context.input.menu.meta?.journeys ?? {},
        userLanguage: context.input.menu.userLanguage ?? '',
    }));
}
export function sharedInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/shared`, shortName: pageId, extension: '.defs.ts' };
}
export function receiptInfo(identity, pageId) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/shared60`, shortName: pageId, extension: '.json' };
}
export function page11File(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/web/${device}/page11`, shortName: pageId, extension: '.defs.ts' };
}
export function draftFile(identity, pageId, device) {
    return { project: identity.project, level: 2, folder: `${identity.module}/pipeline/agentDefsL2/page11Needs`, shortName: `${pageId}${device === 'desktop' ? 'Desktop' : 'Mobile'}`, extension: '.json' };
}
export async function readD2SharedReceipt(identity, pageId) {
    return readJson(receiptInfo(identity, pageId));
}
function choiceFor(response, submit, page, draft, entity) {
    const choices = (response.formChoices ?? []).filter(item => item.submit === submit);
    if (choices.length !== 1)
        throw new Error(`D2_SHARED_FORM_CHOICE: ${submit}`);
    const organismId = choices[0].organism;
    const edits = draft.organisms[organismId]?.edits ?? [];
    if (!page.organisms[organismId] || !edits.length || edits.some(path => path.split('.')[0] !== entity))
        throw new Error(`D2_SHARED_FORM_ENTITY: ${submit}`);
    return organismId;
}
function mergeDraft(left, right) {
    const organisms = { ...left.organisms };
    for (const [id, row] of Object.entries(right.organisms))
        organisms[id] = organisms[id] ?? row;
    return { organisms };
}
function normalizeLlm(raw) {
    if (!raw || !Array.isArray(raw.states) || !Array.isArray(raw.functions) || !Array.isArray(raw.journeys) || !Array.isArray(raw.commandReturns))
        throw new Error('D2_SHARED_LLM_SHAPE');
    return raw;
}
