/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2Intents.ts" enhancement="_blank"/>
export function addD2Step(context, parentStepId, step, bootstrap = false) {
    return {
        type: 'add-step',
        messageId: bootstrap ? '' : context.message.orderAt,
        threadId: context.message.threadId,
        taskId: bootstrap ? '' : context.task?.PK || '',
        parentStepId,
        step,
    };
}
export function updateD2Status(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
export function d2Result(title, result, planId) {
    return {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: title,
        result,
        planning: { planId, dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    };
}
