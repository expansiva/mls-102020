/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2WriteInput.ts" enhancement="_blank"/>
/** Required relationships of an entity whose `via` is a foreign key of that entity (`Entity.field`) and `to` is present (d2_92). */
export function d2RequiredRelationTargets(entity, entityId) {
    const relationships = entity?.relationships ?? {};
    const out = [];
    for (const rel of Object.values(relationships)) {
        const required = rel.required === true || (typeof rel.required === 'string' && rel.required.trim().length > 0);
        const via = rel.via ?? '';
        const to = rel.to ?? '';
        if (required && via.length > 0 && to.length > 0 && (entityId === undefined || via.startsWith(`${entityId}.`)))
            out.push({ via, to });
    }
    return out;
}
export function d2TransitionPayload(entity, entityId, transitionRef) {
    const transition = entity?.transitions?.find(item => item.transitionId === transitionRef);
    return (transition?.payload ?? []).map(path => path.startsWith(`${entityId}.`) ? path : `${entityId}.${path}`);
}
export function d2CreateRequiredInput(entity, entityId) {
    const view = entity;
    if (!view?.record?.fields)
        return [];
    const states = new Set((view.lifecycleStates ?? []).map(item => item.state).filter(Boolean));
    const sequence = Boolean(view.capabilities?.['sequence.next']);
    const foreignKeys = new Set(Object.values(view.relationships ?? {})
        .filter(rel => (rel.required === true || (typeof rel.required === 'string' && rel.required.trim().length > 0)) && (rel.via ?? '').startsWith(`${entityId}.`))
        .map(rel => rel.via));
    const out = [];
    const walk = (fields, prefix) => {
        for (const [key, field] of Object.entries(fields)) {
            const path = `${prefix}.${key}`;
            if (field.fields) {
                walk(field.fields, path);
                continue;
            }
            if (!field.required || field.derived)
                continue;
            if (field.type === 'enum' && states.size && [...states].every(state => (field.values ?? []).some(item => (typeof item === 'string' ? item : item.value) === state)))
                continue;
            if (sequence && field.unique && field.type === 'integer')
                continue;
            if (foreignKeys.has(path))
                continue;
            out.push(path);
        }
    };
    walk(view.record.fields, entityId);
    return out;
}
