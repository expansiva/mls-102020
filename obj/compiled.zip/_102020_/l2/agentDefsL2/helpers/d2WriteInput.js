/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2WriteInput.ts" enhancement="_blank"/>
export function d2TransitionPayload(entity, entityId, transitionRef) {
    const transition = entity?.transitions?.find(item => item.transitionId === transitionRef);
    return (transition?.payload ?? []).map(path => path.startsWith(`${entityId}.`) ? path : `${entityId}.${path}`);
}
export function d2CreateRequiredInput(entity, entityId) {
    const view = entity;
    if (!view?.record?.fields)
        return [];
    const states = new Set((view.lifecycleStates ?? []).map(item => item.state).filter(Boolean));
    const sequence = Boolean(view.capabilities?.['sequence.next']);
    const foreignKeys = new Set(Object.values(view.relationships ?? {})
        .filter(rel => (rel.required === true || (typeof rel.required === 'string' && rel.required.trim().length > 0)) && (rel.via ?? '').startsWith(`${entityId}.`))
        .map(rel => rel.via));
    const out = [];
    const walk = (fields, prefix) => {
        for (const [key, field] of Object.entries(fields)) {
            const path = `${prefix}.${key}`;
            if (field.fields) {
                walk(field.fields, path);
                continue;
            }
            if (!field.required || field.derived)
                continue;
            if (field.type === 'enum' && states.size && [...states].every(state => (field.values ?? []).some(item => item.value === state)))
                continue;
            if (sequence && field.unique && field.type === 'integer')
                continue;
            if (foreignKeys.has(path))
                continue;
            out.push(path);
        }
    };
    walk(view.record.fields, entityId);
    return out;
}
