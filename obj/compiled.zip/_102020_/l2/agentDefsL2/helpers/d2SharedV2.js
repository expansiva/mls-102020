/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2SharedV2.ts" enhancement="_blank"/>
import { d2BffValueLeaves, d2PageSubmits } from '/_102020_/l2/agentDefsL2/helpers/d2Bff.js';
export function buildD2SharedV2(value) {
    const root = exact(value, ['entry', 'forms', 'requests', 'states', 'functions', 'journeys', 'rules', 'access'], 'D2_SHARED_V2_KEYS');
    const entryRow = exact(root.entry, ['params'], 'D2_SHARED_V2_ENTRY');
    const paramsRaw = object(entryRow.params, 'D2_SHARED_V2_PARAMS');
    const params = {};
    for (const [id, raw] of Object.entries(paramsRaw)) {
        const row = exact(raw, ['type', 'sources', 'effect', 'persist'], `D2_SHARED_V2_PARAM: ${id}`);
        if (typeof row.type !== 'string' || typeof row.effect !== 'string' || typeof row.persist !== 'boolean')
            throw new Error(`D2_SHARED_V2_PARAM: ${id}`);
        if (!Array.isArray(row.sources) || !row.sources.every(item => item === 'url' || item === 'localStorage'))
            throw new Error(`D2_SHARED_V2_PARAM_SOURCES: ${id}`);
        params[id] = { type: row.type, sources: row.sources, effect: row.effect, persist: row.persist };
    }
    const forms = {};
    for (const [id, raw] of Object.entries(object(root.forms, 'D2_SHARED_V2_FORMS'))) {
        const row = exact(raw, ['organism', 'submit'], `D2_SHARED_V2_FORM: ${id}`);
        if (typeof row.organism !== 'string' || typeof row.submit !== 'string')
            throw new Error(`D2_SHARED_V2_FORM: ${id}`);
        forms[id] = { organism: row.organism, submit: row.submit };
    }
    const requests = {};
    for (const [id, raw] of Object.entries(object(root.requests, 'D2_SHARED_V2_REQUESTS'))) {
        const row = object(raw, `D2_SHARED_V2_REQUEST: ${id}`);
        if (row.kind !== 'qry' && row.kind !== 'cmd')
            throw new Error(`D2_SHARED_V2_REQUEST_KIND: ${id}`);
        if (typeof row.trigger !== 'string' || !Array.isArray(row.returns) || !row.returns.every(item => typeof item === 'string'))
            throw new Error(`D2_SHARED_V2_REQUEST: ${id}`);
        if (row.kind === 'cmd' && typeof row.writes !== 'string')
            throw new Error(`D2_SHARED_V2_REQUEST_WRITES: ${id}`);
        requests[id] = { kind: row.kind, trigger: row.trigger, returns: row.returns, ...(typeof row.writes === 'string' ? { writes: row.writes } : {}) };
    }
    const states = {};
    for (const [id, raw] of Object.entries(object(root.states, 'D2_SHARED_V2_STATES'))) {
        const row = exact(raw, ['source', 'description'], `D2_SHARED_V2_STATE: ${id}`);
        if (typeof row.source !== 'string' || typeof row.description !== 'string')
            throw new Error(`D2_SHARED_V2_STATE: ${id}`);
        states[id] = { source: row.source, description: row.description };
    }
    const functions = {};
    for (const [id, raw] of Object.entries(object(root.functions, 'D2_SHARED_V2_FUNCTIONS'))) {
        const row = object(raw, `D2_SHARED_V2_FUNCTION: ${id}`);
        if (typeof row.description !== 'string')
            throw new Error(`D2_SHARED_V2_FUNCTION: ${id}`);
        functions[id] = {
            description: row.description,
            ...(typeof row.calls === 'string' ? { calls: row.calls } : {}),
            ...(typeof row.sets === 'string' ? { sets: row.sets } : {}),
            ...(Array.isArray(row.updates) ? { updates: row.updates } : {}),
            ...(typeof row.navigate === 'string' ? { navigate: row.navigate } : {}),
            ...(row.carries && typeof row.carries === 'object' && !Array.isArray(row.carries) ? { carries: row.carries } : {}),
        };
    }
    if (!Array.isArray(root.journeys))
        throw new Error('D2_SHARED_V2_JOURNEYS');
    const journeys = root.journeys.map((raw, index) => {
        const row = object(raw, `D2_SHARED_V2_JOURNEY: ${index}`);
        if (typeof row.step !== 'string' || !Array.isArray(row.organisms) || !Array.isArray(row.functions))
            throw new Error(`D2_SHARED_V2_JOURNEY: ${index}`);
        return { step: row.step, organisms: row.organisms, functions: row.functions, ...(typeof row.continuesIn === 'string' ? { continuesIn: row.continuesIn } : {}) };
    });
    const rules = {};
    for (const [id, raw] of Object.entries(object(root.rules, 'D2_SHARED_V2_RULES'))) {
        if (!Array.isArray(raw) || !raw.every(item => typeof item === 'string'))
            throw new Error(`D2_SHARED_V2_RULES: ${id}`);
        rules[id] = raw;
    }
    const access = exact(root.access, ['actors', 'grants'], 'D2_SHARED_V2_ACCESS');
    if (!Array.isArray(access.actors) || !Array.isArray(access.grants))
        throw new Error('D2_SHARED_V2_ACCESS');
    return { entry: { params }, forms, requests, states, functions, journeys, rules, access: { actors: access.actors, grants: access.grants } };
}
export function d2SharedV2Path(location) {
    return `_${location.project}_/l2/${location.module}/web/shared/${location.pageId}.defs.ts`;
}
export function renderD2SharedV2(location, value) {
    const definition = buildD2SharedV2(value);
    return `/// <mls fileReference="${d2SharedV2Path(location)}" enhancement="_blank"/>\n\nexport const definition = ${JSON.stringify(definition, null, 2)} as const;\n`;
}
export function parseD2SharedV2(source) {
    const match = /^\/\/\/ <mls fileReference="_(\d+)_\/l2\/([a-z][A-Za-z0-9]*)\/web\/shared\/([a-z][A-Za-z0-9_]*)\.defs\.ts" enhancement="_blank"\/>\n\nexport const definition = ([\s\S]+) as const;\n$/u.exec(source);
    if (!match)
        throw new Error('D2_SHARED_V2_SOURCE_SHAPE');
    let parsed;
    try {
        parsed = JSON.parse(match[4]);
    }
    catch {
        throw new Error('D2_SHARED_V2_SOURCE_JSON');
    }
    return { location: { project: Number(match[1]), module: match[2], pageId: match[3] }, definition: buildD2SharedV2(parsed) };
}
/**
 * D (d2_73): facts of the shared over the approved BFF, never its shape. Every organism is fed (what it reads is held by
 * a state whose source carries it, what it edits is a form), every function calls an endpoint that exists, every
 * intent has a function, every state is filled by a source, a function or a form; references, navigation targets and
 * journey steps exist.
 */
export function gateD2SharedV2(value, context) {
    const issues = [];
    let definition;
    try {
        definition = buildD2SharedV2(value);
    }
    catch (error) {
        return [{ code: 'D2_SHARED_V2_FORMAT', path: 'definition', message: String(error) }];
    }
    const add = (code, path, message) => { issues.push({ code, path, message }); };
    const organisms = new Map();
    for (const device of ['desktop', 'mobile']) {
        for (const [id, organism] of Object.entries(context.page11[device].organisms)) {
            const row = organisms.get(id) ?? { reads: new Set(), edits: new Set(), intents: [] };
            for (const intent of organism.intents)
                if (!row.intents.some(item => item.id === intent.id))
                    row.intents.push(intent);
            const draft = context.drafts[device].organisms[id];
            for (const path of draft?.reads ?? [])
                row.reads.add(path);
            for (const path of draft?.edits ?? [])
                row.edits.add(path);
            organisms.set(id, row);
        }
    }
    // D.4: every state is filled by a source, a function or a form.
    for (const [id, state] of Object.entries(definition.states)) {
        if (!validStateSource(id, state.source, definition))
            add('D2_SHARED_V2_STATE_SOURCE', `states.${id}`, `State ${id} source ${JSON.stringify(state.source)} is not <endpoint>.<output key>, <command>.input, entry.params.<name>, another state id, or a function whose sets is this state.`);
    }
    // D.1: what an organism reads is held by a state; what it edits belongs to a form.
    const held = new Map(Object.keys(definition.states).map(id => [id, heldPaths(id, definition, context.design)]));
    const formOrganisms = new Set(Object.values(definition.forms).map(form => form.organism));
    for (const [id, row] of organisms) {
        for (const path of row.reads) {
            if ([...held.values()].some(paths => paths.some(origin => path === origin || path.startsWith(`${origin}.`))))
                continue;
            add('D2_SHARED_V2_ORGANISM_UNFED', `organisms.${id}`, `Organism ${id} reads ${path}, and no state holds it: no state's source is an endpoint output that carries it.`);
        }
        if (row.edits.size && !formOrganisms.has(id))
            add('D2_SHARED_V2_FORM_UNBOUND', `organisms.${id}`, `Organism ${id} edits ${[...row.edits].join(', ')} and is the organism of no form.`);
    }
    // Forms bind an organism of the page to one of its submits.
    const submits = d2PageSubmits(context);
    for (const [id, form] of Object.entries(definition.forms)) {
        if (!organisms.has(form.organism))
            add('D2_SHARED_V2_FORM', `forms.${id}`, `Form ${id} names organism ${form.organism}, which is not on the page.`);
        if (!submits.has(form.submit))
            add('D2_SHARED_V2_FORM', `forms.${id}`, `Form ${id} submits ${form.submit}, which is not a submit intent of the page.`);
    }
    // D.2: functions call endpoints that exist and touch states that exist; a navigation reaches a page the actors open.
    const pageActors = new Set(context.need.actors);
    for (const [id, fn] of Object.entries(definition.functions)) {
        if (fn.calls && !definition.requests[fn.calls])
            add('D2_SHARED_V2_FUNCTION_CALL', `functions.${id}`, `Function ${id} calls ${fn.calls}, which is not an endpoint of the page.`);
        if (fn.sets && !definition.states[fn.sets])
            add('D2_SHARED_V2_FUNCTION_SET', `functions.${id}`, `Function ${id} sets ${JSON.stringify(fn.sets)}, which is not one state id.`);
        for (const target of fn.updates ?? [])
            if (!definition.states[target])
                add('D2_SHARED_V2_FUNCTION_UPDATE', `functions.${id}.updates`, `Function ${id} updates ${target}, which is not a state.`);
        if (fn.navigate && !canNavigate(context.menu, fn.navigate, pageActors))
            add('D2_SHARED_V2_FUNCTION_NAVIGATE', `functions.${id}`, `Function ${id} navigates to ${fn.navigate}, which the page actors cannot open.`);
        for (const [key, ref] of Object.entries(fn.carries ?? {})) {
            const stateId = ref.split('.')[0];
            if (!definition.states[stateId])
                add('D2_SHARED_V2_CARRIES_PATH', `functions.${id}.carries.${key}`, `Carry ${key} reads ${JSON.stringify(ref)}, and ${stateId} is not a state.`);
        }
    }
    // D.3: every submit has a function that calls its command; every navigation intent has its function.
    for (const [organismId, row] of organisms) {
        for (const intent of row.intents) {
            if (intent.kind === 'submit') {
                const command = context.design.endpoints.find(endpoint => endpoint.kind === 'cmd' && endpoint.when === intent.id);
                if (!command || !Object.values(definition.functions).some(fn => fn.calls === command.id))
                    add('D2_SHARED_V2_SUBMIT_FUNCTION', `organisms.${organismId}.intents.${intent.id}`, `Submit ${intent.id} has no function that calls its command${command ? ` ${command.id}` : ''}.`);
            }
            else if (!definition.functions[intent.id] && !Object.values(definition.functions).some(fn => fn.navigate === intent.to)) {
                add('D2_SHARED_V2_FUNCTION_MISSING', `organisms.${organismId}.intents.${intent.id}`, `Intent ${intent.id} has no function.`);
            }
        }
    }
    // Journeys: only the real steps of the page, each served by an organism or a continuation; references exist.
    const journeySteps = new Set(context.need.reads.flatMap(read => read.from.filter(item => item.startsWith('journey:')).map(item => item.slice('journey:'.length))));
    const pageJourneys = new Set(Object.entries(context.menu.meta?.journeys ?? {}).filter(([, pages]) => pages.includes(context.need.pageId)).map(([id]) => id));
    for (const step of journeySteps) {
        if (!pageJourneys.has(step.split('/')[0]))
            add('D2_SHARED_V2_JOURNEY_OUTSIDE', 'journeys', `Step ${step} is not linked to this page in the menu.`);
        if (!definition.journeys.some(item => item.step === step && (item.organisms.length || item.continuesIn)))
            add('D2_SHARED_V2_JOURNEY_UNSERVED', 'journeys', `Needs step ${step} is not served by an organism or continuesIn.`);
    }
    for (const row of definition.journeys) {
        if (!journeySteps.has(row.step))
            add('D2_SHARED_V2_JOURNEY_INVENTED', `journeys.${row.step}`, `Journey step ${row.step} is not a real step for this page.`);
        for (const organism of row.organisms)
            if (!organisms.has(organism))
                add('D2_SHARED_V2_JOURNEY_REF', `journeys.${row.step}`, `Journey step ${row.step} names organism ${organism}, which is not on the page.`);
        for (const fn of row.functions)
            if (!definition.functions[fn])
                add('D2_SHARED_V2_JOURNEY_REF', `journeys.${row.step}`, `Journey step ${row.step} names function ${fn}, which does not exist.`);
    }
    return issues;
}
/** The L4 paths a state holds, through its source: an endpoint output key or a command input, by their leaf origins. */
function heldPaths(stateId, definition, design, seen = new Set()) {
    if (seen.has(stateId))
        return [];
    seen.add(stateId);
    const source = definition.states[stateId]?.source ?? '';
    if (definition.states[source])
        return heldPaths(source, definition, design, seen);
    const dot = source.indexOf('.');
    if (dot <= 0 || source.startsWith('entry.'))
        return [];
    const endpoint = design.endpoints.find(item => item.id === source.slice(0, dot));
    const tail = source.slice(dot + 1);
    if (!endpoint)
        return [];
    const rows = tail === 'input' ? endpoint.input : endpoint.output.filter(leaf => leaf.name === tail);
    return d2BffValueLeaves(rows, design).flatMap(item => item.leaf.origin?.paths ?? []);
}
function entryParamName(source) {
    const prefix = 'entry.params.';
    if (!source.startsWith(prefix))
        return null;
    const name = source.slice(prefix.length);
    if (!name || name.includes('.'))
        return null;
    return name;
}
function validStateSource(stateId, source, definition) {
    const paramName = entryParamName(source);
    if (paramName !== null)
        return Object.prototype.hasOwnProperty.call(definition.entry.params, paramName);
    const dot = source.indexOf('.');
    if (dot > 0) {
        const requestId = source.slice(0, dot);
        const tail = source.slice(dot + 1);
        const request = definition.requests[requestId];
        if (!request || !tail || tail.includes('.'))
            return false;
        if (tail === 'input')
            return request.kind === 'cmd';
        return request.returns.includes(tail);
    }
    if (definition.states[source])
        return source !== stateId;
    return definition.functions[source]?.sets === stateId;
}
/** Menu pages the page actors can open: the navigate targets a shared function may name. */
export function d2SharedNavigablePages(menu, actors) {
    const ids = [];
    const walk = (nodes) => { for (const node of nodes) {
        if (node.kind === 'page')
            ids.push(node.id);
        walk(node.children ?? []);
    } };
    walk(menu.tree);
    return ids.filter(pageId => canNavigate(menu, pageId, new Set(actors)));
}
function canNavigate(menu, pageId, pageActors) {
    const path = menuPath(menu.tree, pageId, []);
    if (!path)
        return false;
    for (const [actor, refs] of Object.entries(menu.authorities ?? {})) {
        if (!refs.some(ref => path.includes(ref)))
            continue;
        if (pageActors.has(actor.replace(/^actor:/u, '')))
            return true;
    }
    return false;
}
function menuPath(nodes, pageId, ancestors) {
    for (const node of nodes) {
        const path = [...ancestors, node.id];
        if (node.kind === 'page' && node.id === pageId)
            return path;
        const child = menuPath(node.children ?? [], pageId, path);
        if (child)
            return child;
    }
    return null;
}
function object(value, code) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error(code);
    return value;
}
function exact(value, allowed, code) {
    const row = object(value, code);
    for (const key of Object.keys(row))
        if (!allowed.includes(key))
            throw new Error(`${code}: forbidden field ${key}`);
    for (const key of allowed)
        if (!(key in row))
            throw new Error(`${code}: missing field ${key}`);
    return row;
}
