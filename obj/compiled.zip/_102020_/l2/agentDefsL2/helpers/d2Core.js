/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2Core.ts" enhancement="_blank"/>
import { readJson, writeJson } from '/_102035_/l2/solution/fs.js';
export const D2_AGENT_NAME = 'agentDefsL2';
export const D2_ENTRY_AGENT_NAME = 'agentD2Entry';
export const D2_INPUT_AGENT_NAME = 'agentD2Input';
export const D2_CONTRACTS_AGENT_NAME = 'agentD2Contracts';
export const D2_SHARED_AGENT_NAME = 'agentD2Shared';
export const D2_SHARED_PAGE_AGENT_NAME = 'agentD2SharedPage';
export const D2_PAGES_AGENT_NAME = 'agentD2Pages';
export const D2_PAGES_PAGE_AGENT_NAME = 'agentD2PagesPage';
export const D2_FINALIZE_AGENT_NAME = 'agentD2Finalize';
export const D2_FLOW_ID = 'agentDefsL2';
export const D2_FLOW_VERSION = '2026-09-21-agent-defs-l2-flow-v3';
export const D2_PIPELINE_VERSION = '2026-09-21-agent-defs-l2-pipeline-v1';
export const D2_FLOW_STEP_IDS = [
    'entry10',
    'input20',
    'contracts30',
    'shared40',
    'pages50',
    'finalize60',
];
export const D2_STEP_DEPENDS_ON = {
    entry10: [],
    input20: ['entry10-done'],
    contracts30: ['input20-done'],
    shared40: ['contracts30-done'],
    pages50: ['shared40-done'],
    finalize60: ['pages50-done'],
};
export const D2_STEP_TITLES = {
    entry10: 'Start L2 definitions',
    input20: 'Validate inputs',
    contracts30: 'Create typed contracts',
    shared40: 'Define shared behavior',
    pages50: 'Describe desktop and mobile pages',
    finalize60: 'Validate definitions',
};
const AGENT_PREFIXES = [
    /@@\s*_102020_\/l2\/agentDefsL2/gi,
    /@@\s*_102020_agentDefsL2/gi,
    /@@\s*agentDefsL2/gi,
];
export function currentD2Project() {
    return Number(mls.actualProject || 0);
}
export function moduleTokenOk(value) {
    return /^[a-z][A-Za-z0-9]{0,59}$/.test(value) && !value.includes('..');
}
export function parseD2MessageInvocation(value, project = currentD2Project()) {
    let raw = String(value || '');
    for (const prefix of AGENT_PREFIXES)
        raw = raw.replace(prefix, ' ');
    const tokens = raw.trim().split(/\s+/).filter(Boolean);
    if (tokens.length === 1 && tokens[0].toLowerCase() === '/help')
        return { kind: 'help' };
    if (tokens.some(token => token.toLowerCase() === '/candidate')) {
        return { kind: 'refusal', diagnostic: '/candidate is not supported by agentDefsL2.' };
    }
    const flag = tokens.find(token => token.startsWith('/'));
    if (flag)
        return { kind: 'refusal', diagnostic: `Unknown flag: ${flag}.` };
    if (tokens.length !== 1) {
        return { kind: 'refusal', diagnostic: 'Pass exactly one explicit module: @@agentDefsL2 <lowerCamel>.' };
    }
    if (!Number.isSafeInteger(project) || project <= 0) {
        return { kind: 'refusal', diagnostic: 'The current project is unavailable.' };
    }
    const module = tokens[0] || '';
    if (!moduleTokenOk(module)) {
        return { kind: 'refusal', diagnostic: 'Module name must be lowerCamel and must not contain a path.' };
    }
    return { kind: 'run', project, module };
}
export function parseD2StepInvocation(value, currentProject = currentD2Project()) {
    let parsed;
    try {
        parsed = JSON.parse(String(value || '{}'));
    }
    catch {
        return { kind: 'refusal', diagnostic: 'agentDefsL2 step args must be JSON.' };
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return { kind: 'refusal', diagnostic: 'agentDefsL2 step args must be an object.' };
    }
    const raw = parsed;
    const allowed = new Set(['project', 'module']);
    const unknown = Object.keys(raw).find(key => !allowed.has(key));
    if (unknown)
        return { kind: 'refusal', diagnostic: `Unknown step arg: ${unknown}.` };
    const project = typeof raw.project === 'number' ? raw.project : Number.NaN;
    const module = typeof raw.module === 'string' ? raw.module.trim() : '';
    if (!Number.isSafeInteger(project) || project <= 0) {
        return { kind: 'refusal', diagnostic: 'agentDefsL2 step args require a positive integer project.' };
    }
    if (project !== currentProject) {
        return { kind: 'refusal', diagnostic: `Step project ${project} does not match the current project ${currentProject}.` };
    }
    if (!moduleTokenOk(module)) {
        return { kind: 'refusal', diagnostic: 'Step module must be lowerCamel and must not contain a path.' };
    }
    return { kind: 'run', project, module };
}
export function isD2StepId(value) {
    return D2_FLOW_STEP_IDS.includes(value);
}
export function d2StepIdOf(step) {
    const planId = String(step.planning?.planId || '');
    return isD2StepId(planId) ? planId : '';
}
export function createD2AgentStep(stepId, identity) {
    const dependsOn = [...D2_STEP_DEPENDS_ON[stepId]];
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: D2_STEP_TITLES[stepId],
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: stepId === 'entry10' ? D2_ENTRY_AGENT_NAME
            : stepId === 'input20' ? D2_INPUT_AGENT_NAME
                : stepId === 'contracts30' ? D2_CONTRACTS_AGENT_NAME
                    : stepId === 'shared40' ? D2_SHARED_AGENT_NAME
                        : stepId === 'pages50' ? D2_PAGES_AGENT_NAME
                            : stepId === 'finalize60' ? D2_FINALIZE_AGENT_NAME
                                : D2_AGENT_NAME,
        prompt: JSON.stringify(identity),
        rags: [],
        planning: {
            planId: stepId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function buildD2PlannedSteps(identity) {
    return D2_FLOW_STEP_IDS.map(stepId => createD2AgentStep(stepId, identity));
}
export function d2PipelineFile(identity) {
    return {
        project: identity.project,
        level: 2,
        folder: `${identity.module}/pipeline/agentDefsL2`,
        shortName: 'pipeline',
        extension: '.json',
    };
}
export async function readD2Pipeline(identity) {
    return readJson(d2PipelineFile(identity));
}
export function createD2Pipeline(identity, now) {
    const updatedAt = now.toISOString();
    return {
        schemaVersion: D2_PIPELINE_VERSION,
        flowId: D2_FLOW_ID,
        project: identity.project,
        module: identity.module,
        status: 'inProgress',
        steps: { entry10: { status: 'approved', updatedAt } },
        createdAt: updatedAt,
        updatedAt,
    };
}
export async function initializeD2Pipeline(identity, now = new Date()) {
    const existing = await readD2Pipeline(identity);
    if (existing) {
        if (existing.schemaVersion !== D2_PIPELINE_VERSION || existing.flowId !== D2_FLOW_ID || existing.project !== identity.project || existing.module !== identity.module) {
            throw new Error('Existing agentDefsL2 pipeline has a different identity. Nothing was overwritten.');
        }
        return existing;
    }
    const pipeline = createD2Pipeline(identity, now);
    await writeJson(d2PipelineFile(identity), pipeline);
    return pipeline;
}
export async function markD2Unavailable(identity, stepId, diagnostic) {
    const pipeline = await readD2Pipeline(identity);
    if (!pipeline || pipeline.status === 'complete' || pipeline.steps[stepId]?.status === 'approved')
        return;
    const updatedAt = new Date().toISOString();
    await writeJson(d2PipelineFile(identity), {
        ...pipeline,
        status: 'awaitingStep',
        awaitingStep: stepId,
        steps: { ...pipeline.steps, [stepId]: { status: 'unavailable', diagnostic, updatedAt } },
        updatedAt,
    });
}
export async function markD2StepApproved(identity, stepId, artifactPaths, snapshotHash) {
    const pipeline = await readD2Pipeline(identity);
    if (!pipeline)
        throw new Error('agentDefsL2 pipeline is missing; entry10 must run first.');
    const prior = pipeline.steps[stepId];
    if (prior?.status === 'approved' && prior.snapshotHash === snapshotHash
        && JSON.stringify(prior.artifactPaths || []) === JSON.stringify(artifactPaths))
        return;
    const updatedAt = new Date().toISOString();
    await writeJson(d2PipelineFile(identity), {
        ...pipeline,
        status: 'inProgress',
        awaitingStep: undefined,
        steps: {
            ...pipeline.steps,
            [stepId]: { status: 'approved', updatedAt, artifactPaths, ...(snapshotHash ? { snapshotHash } : {}) },
        },
        updatedAt,
    });
}
export async function markD2StepFailed(identity, stepId, diagnostic) {
    const pipeline = await readD2Pipeline(identity);
    if (!pipeline || pipeline.status === 'complete' || pipeline.steps[stepId]?.status === 'approved')
        return;
    const updatedAt = new Date().toISOString();
    await writeJson(d2PipelineFile(identity), {
        ...pipeline,
        status: 'failed',
        awaitingStep: stepId,
        steps: { ...pipeline.steps, [stepId]: { status: 'failed', diagnostic, updatedAt } },
        updatedAt,
    });
}
export async function markD2Complete(identity, artifactPaths, snapshotHash) {
    const pipeline = await readD2Pipeline(identity);
    if (!pipeline)
        throw new Error('agentDefsL2 pipeline is missing; entry10 must run first.');
    const prior = pipeline.steps.finalize60;
    if (pipeline.status === 'complete' && prior?.status === 'approved' && prior.snapshotHash === snapshotHash
        && JSON.stringify(prior.artifactPaths || []) === JSON.stringify(artifactPaths))
        return;
    const updatedAt = new Date().toISOString();
    await writeJson(d2PipelineFile(identity), {
        ...pipeline,
        status: 'complete',
        awaitingStep: undefined,
        steps: { ...pipeline.steps, finalize60: { status: 'approved', updatedAt, artifactPaths, snapshotHash } },
        updatedAt,
    });
}
/** finalize60 is the single owner allowed to revoke complete after a fresh disk-integrity check. */
export async function markD2FinalizeBlocked(identity, diagnostic, snapshotHash) {
    const pipeline = await readD2Pipeline(identity);
    if (!pipeline)
        return;
    if (pipeline.status === 'complete' && (!snapshotHash || pipeline.steps.finalize60?.snapshotHash !== snapshotHash))
        return;
    const updatedAt = new Date().toISOString();
    await writeJson(d2PipelineFile(identity), {
        ...pipeline,
        status: 'failed',
        awaitingStep: 'finalize60',
        steps: { ...pipeline.steps, finalize60: { status: 'failed', diagnostic, updatedAt, ...(snapshotHash ? { snapshotHash } : {}) } },
        updatedAt,
    });
}
export const D2_HELP = [
    'Usage: @@agentDefsL2 <lowerCamel>',
    'The module is explicit and the project comes from the current context.',
    'Available now: entry10, input20, contracts30, shared40, pages50 and finalize60.',
].join('\n');
