/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2SharedDerive.ts" enhancement="_blank"/>
import { d2WriteByKey } from '/_102020_/l2/helpers/defsInput/writeKey.js';
import { d2TransitionPayload } from '/_102020_/l2/agentDefsL2/helpers/d2WriteInput.js';
import { d2BffTypeRoot, d2PageSubmits, parseD2BffType } from '/_102020_/l2/agentDefsL2/helpers/d2Bff.js';
import { gateD2SharedV2 } from '/_102020_/l2/agentDefsL2/helpers/d2SharedV2.js';
const camel = (value) => (value ? value[0].toLowerCase() + value.slice(1) : value);
const pascal = (value) => (value ? value[0].toUpperCase() + value.slice(1) : value);
const SOURCES = ['url', 'localStorage'];
const sortedUnique = (ids) => [...new Set(ids)].sort();
export function deriveD2Shared(input) {
    const { design } = input;
    const endpoint = (id) => design.endpoints.find(item => item.id === id);
    const organisms = mergedOrganisms(input);
    const requests = {};
    const rules = {};
    for (const item of design.endpoints) {
        requests[item.id] = { kind: item.kind, trigger: item.when === 'interaction' ? item.id : item.when, ...(item.writes ? { writes: item.writes } : {}), returns: item.output.map(leaf => leaf.name) };
        rules[item.id] = item.rules;
    }
    // States: one per endpoint output key an organism reads from.
    const refs = [...new Set(design.bindings.organisms.map(row => row.reads))];
    const keyCount = new Map();
    for (const ref of refs)
        keyCount.set(ref.split('.')[1], (keyCount.get(ref.split('.')[1]) ?? 0) + 1);
    const stateOf = new Map();
    const states = {};
    for (const ref of refs) {
        const [endpointId, key] = ref.split('.');
        const id = (keyCount.get(key) ?? 0) > 1 ? `${endpointId}${pascal(key)}` : key;
        stateOf.set(ref, id);
        // d2_80: the state lists every organism that reads its source.
        const readers = design.bindings.organisms.filter(row => row.reads === ref).map(row => row.organism);
        states[id] = { source: ref, description: leafDescription(endpoint(endpointId), key, design), organisms: sortedUnique(readers) };
    }
    // Selections: the selected id lives in an entry param; the state of the selection is the item that id resolves.
    // Precedence of entry params (d2_78): a filter, then a navigation, and a selection's select: wins over both.
    const params = { ...filterParams(input), ...navigationParams(input) };
    const selected = new Set();
    const selectionState = new Map();
    for (const row of design.bindings.selections) {
        const entity = selectionEntity(row.via, design);
        if (!entity)
            continue;
        const param = `${camel(entity)}Id`;
        const target = organisms.get(row.organism)?.selects || row.organism;
        if (!selected.has(param))
            params[param] = { type: 'string', sources: SOURCES, effect: `select:${target}`, persist: true };
        selected.add(param);
        const stateId = `selected${entity}`;
        const typeName = 'query' in row.via ? outputType(endpoint(row.via.query), design) : listItemType(row.via.list, design);
        // d2_80: the selecting organism and its target, over every selection that lands in this state.
        const feeds = sortedUnique([...(states[stateId]?.organisms ?? []), row.organism, target]);
        states[stateId] = { source: `entry.params.${param}`, description: design.types.find(type => type.name === typeName)?.description || leafDescription(endpoint(('query' in row.via ? row.via.query : row.via.list).split('.')[0]), '', design), organisms: feeds };
        // The selecting organism and the one it opens both know the selected record (a navigation from either carries it).
        for (const id of [row.organism, target])
            if (!selectionState.has(id))
                selectionState.set(id, stateId);
    }
    // Functions: one per endpoint, with the endpoint's id. Destinations are only what A declared (d2_78): the state its own
    // output feeds, the updates (replace → sets; append, upsert, remove → updates, named in the description) and the
    // states of the queries a command reloads.
    const functions = {};
    const fedBy = (endpointId) => [...stateOf].filter(([ref]) => ref.split('.')[0] === endpointId).map(([, id]) => id);
    for (const item of design.endpoints) {
        const declared = design.bindings.updates.filter(row => row.endpoint === item.id && stateOf.has(row.state));
        const replaced = [...(item.kind === 'qry' ? fedBy(item.id) : []), ...declared.filter(row => row.mode === 'replace').map(row => stateOf.get(row.state))];
        const changed = declared.filter(row => row.mode !== 'replace').map(row => stateOf.get(row.state));
        const reloads = design.bindings.commands.filter(row => row.endpoint === item.id).flatMap(row => row.refreshes).flatMap(fedBy);
        const targets = [...new Set([...replaced, ...changed, ...reloads])];
        // On a paged list the change lands in its items (d2_79).
        const paged = (ref) => { const [sourceId, key] = ref.split('.'); return Boolean(endpoint(sourceId)?.output.find(leaf => leaf.name === key)?.paginated); };
        const modes = declared.filter(row => row.mode !== 'replace').map(row => `${stateOf.get(row.state)}${paged(row.state) ? '.items' : ''}: ${row.mode}`);
        functions[item.id] = {
            calls: item.id, description: modes.length ? `${item.jsdoc.purpose} (${modes.join('; ')})` : item.jsdoc.purpose,
            ...(replaced.length ? { sets: replaced[0] } : {}),
            ...(targets.filter(id => id !== replaced[0]).length ? { updates: targets.filter(id => id !== replaced[0]) } : {}),
        };
    }
    for (const [organismId, row] of organisms) {
        for (const intent of row.intents) {
            if (intent.kind !== 'navigate' || !intent.to || functions[intent.id])
                continue;
            const stateId = selectionState.get(organismId);
            const entity = stateId?.slice('selected'.length) ?? '';
            functions[intent.id] = { navigate: intent.to, description: row.text, ...(stateId ? { carries: { [`${camel(entity)}Id`]: `${stateId}.id` } } : {}) };
        }
    }
    // Form prefill: an id the form edits may come in the URL.
    const forms = deriveForms(input, organisms);
    for (const form of Object.values(forms)) {
        for (const path of organisms.get(form.organism)?.edits ?? []) {
            const name = path.split('.').slice(-1)[0];
            if (name.endsWith('Id') && !params[name])
                params[name] = { type: 'string', sources: SOURCES, effect: `prefill:${form.organism}`, persist: false };
        }
    }
    return {
        entry: { params },
        forms,
        requests,
        states,
        functions,
        journeys: design.bindings.journeys.map(row => ({ step: row.step, organisms: row.organisms, functions: row.endpoints, ...(row.continuesIn ? { continuesIn: row.continuesIn } : {}) })),
        rules,
        access: input.access,
        fields: fieldsOf(organisms),
    };
}
/** Ontology path → organisms that read or edit it, keys and ids sorted, from the drafts as written. */
function fieldsOf(organisms) {
    const byPath = new Map();
    for (const [id, row] of organisms) {
        for (const path of [...row.reads, ...row.edits])
            byPath.set(path, [...(byPath.get(path) ?? []), id]);
    }
    const fields = {};
    for (const path of [...byPath.keys()].sort())
        fields[path] = sortedUnique(byPath.get(path) ?? []);
    return fields;
}
/** D over the derived shared (d2_70): the code's own output passes its own fact checks. */
export function d2SharedDeriveIssues(input, definition) {
    return gateD2SharedV2(definition, { page11: input.page11, drafts: input.drafts, need: input.need, menu: input.menu, design: input.design, entities: input.entities });
}
function mergedOrganisms(input) {
    const out = new Map();
    for (const device of ['desktop', 'mobile']) {
        const page = input.page11[device];
        for (const [id, organism] of Object.entries(page.organisms)) {
            const draft = input.drafts[device].organisms[id] ?? { reads: [], edits: [], selects: '', submits: [] };
            const row = out.get(id) ?? { kind: organism.kind, text: organism.text, section: page.sections.find(section => section.organisms.includes(id))?.id ?? '', intents: [], reads: [], edits: [], selects: '', submits: [] };
            for (const intent of organism.intents)
                if (!row.intents.some(item => item.id === intent.id))
                    row.intents.push(intent);
            row.reads = [...new Set([...row.reads, ...draft.reads])];
            row.edits = [...new Set([...row.edits, ...draft.edits])];
            row.selects = row.selects || draft.selects;
            for (const submit of draft.submits)
                if (!row.submits.some(item => item.intentId === submit.intentId))
                    row.submits.push(submit);
            out.set(id, row);
        }
    }
    return out;
}
function outputType(item, design) {
    for (const leaf of item?.output ?? []) {
        const ref = parseD2BffType(leaf.type);
        if (ref?.base === 'ref' && d2BffTypeRoot(ref.ref, design))
            return ref.ref;
    }
    return '';
}
function listItemType(ref, design) {
    const [endpointId, key] = ref.split('.');
    const leaf = design.endpoints.find(item => item.id === endpointId)?.output.find(row => row.name === key);
    const type = leaf ? parseD2BffType(leaf.type) : null;
    return type?.base === 'ref' ? type.ref : '';
}
/** The entity a selection picks: the root of the detail the query returns, or of the list item; else the id the query takes. */
function selectionEntity(via, design) {
    if ('list' in via)
        return d2BffTypeRoot(listItemType(via.list, design), design);
    const query = design.endpoints.find(item => item.id === via.query);
    const root = d2BffTypeRoot(outputType(query, design), design);
    if (root)
        return root;
    const id = (query?.input ?? []).flatMap(leaf => (leaf.origin?.kind === 'field' ? leaf.origin.paths : [])).find(path => path.split('.').length === 2 && path.endsWith('.id'));
    return id?.split('.')[0] ?? '';
}
function leafDescription(item, key, design) {
    const leaf = item?.output.find(row => row.name === key);
    const ref = leaf ? parseD2BffType(leaf.type) : null;
    const type = ref?.base === 'ref' ? design.types.find(row => row.name === ref.ref) : undefined;
    return type?.description || item?.jsdoc.output || '';
}
/** A sibling page that navigates here from a selection opens this page with that record's id (rule 8). */
function navigationParams(input) {
    const params = {};
    const readEntities = new Set(input.need.reads.map(item => item.entity));
    for (const sibling of input.siblings) {
        if (sibling.pageId === input.pageId)
            continue;
        const draft = (id) => sibling.drafts.map(row => row.organisms[id]).find(Boolean);
        for (const [id, organism] of Object.entries(sibling.page11.organisms)) {
            for (const intent of organism.intents) {
                if (intent.kind !== 'navigate' || intent.to !== input.pageId)
                    continue;
                const selected = draft(id)?.selects;
                const target = (selected ? draft(selected) : undefined) ?? draft(id);
                const entity = target?.reads[0]?.split('.')[0] ?? '';
                if (!entity || !readEntities.has(entity))
                    continue;
                params[`${camel(entity)}Id`] = params[`${camel(entity)}Id`] ?? { type: 'string', sources: SOURCES, effect: `select:${entity}`, persist: true };
            }
        }
    }
    return params;
}
/** The inputs of the page queries that filter or page what the page shows survive a reload (rule 8). */
function filterParams(input) {
    const params = {};
    const readerOf = (ref) => input.design.bindings.organisms.find(row => row.reads === ref)?.organism;
    for (const item of input.design.endpoints.filter(row => row.kind === 'qry')) {
        // The organism that reads what the query brings: its own output, or the state it updates. No reader, no filter.
        const target = input.design.bindings.organisms.find(row => row.reads.split('.')[0] === item.id)?.organism
            ?? input.design.bindings.updates.filter(row => row.endpoint === item.id).map(row => readerOf(row.state)).find(Boolean);
        if (!target)
            continue;
        for (const leaf of item.input) {
            const path = leaf.origin?.kind === 'field' ? leaf.origin.paths[0] : '';
            if (path.split('.').length === 2 && path.endsWith('.id'))
                continue; // the selected id is the selection's param
            // An entry param is one URL name: the last segment of a nested input (d2_79).
            const name = leaf.name.split('.').slice(-1)[0];
            if (name === 'pageSize' || params[name])
                continue;
            const ref = parseD2BffType(leaf.type);
            params[name] = { type: ref?.base === 'number' || ref?.base === 'boolean' ? ref.base : 'string', sources: SOURCES, effect: `filter:${target}`, persist: true };
        }
    }
    return params;
}
/** The form of each submit is the organism that edits the input its write asks for (d2_72); a write without input has none. */
function deriveForms(input, organisms) {
    const forms = {};
    const writes = d2PageSubmits(input);
    for (const [unitId, unit] of organisms) {
        for (const submit of unit.submits) {
            const pageWrite = d2WriteByKey(input.need.writes, writes.get(submit.intentId) || submit.write);
            if (!pageWrite)
                continue;
            const entityId = pageWrite.entity;
            const payload = pageWrite.operation === 'transition' ? d2TransitionPayload(input.entities[entityId], entityId, pageWrite.transitionRef ?? '') : [];
            if (pageWrite.operation === 'transition' && !payload.length)
                continue;
            const wanted = pageWrite.operation === 'transition' ? payload : [];
            const candidates = [...organisms].filter(([, row]) => row.edits.some(path => path.split('.')[0] === entityId) && wanted.every(path => row.edits.includes(path)));
            if (!candidates.length)
                continue;
            const sameSection = candidates.filter(([id, row]) => row.section && row.section === unit.section && id !== unitId);
            // More than one candidate: the one that edits most of the entity, in page order.
            const score = ([, row]) => row.edits.filter(path => path.split('.')[0] === entityId).length;
            const pool = sameSection.length === 1 ? sameSection : candidates;
            const chosen = [...pool].sort((a, b) => score(b) - score(a))[0];
            forms[submit.intentId] = { organism: chosen[0], submit: submit.intentId };
        }
    }
    return forms;
}
