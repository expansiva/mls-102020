/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2SharedDerive.ts" enhancement="_blank"/>
import { d2BffTypeRoot, parseD2BffType } from '/_102020_/l2/agentDefsL2/helpers/d2Bff.js';
import { gateD2SharedV2 } from '/_102020_/l2/agentDefsL2/helpers/d2SharedV2.js';
const camel = (value) => (value ? value[0].toLowerCase() + value.slice(1) : value);
const pascal = (value) => (value ? value[0].toUpperCase() + value.slice(1) : value);
const SOURCES = ['url', 'localStorage'];
const URL_SOURCES = ['url'];
const sortedUnique = (ids) => [...new Set(ids)].sort();
export function deriveD2Shared(input) {
    const { design } = input;
    const endpoint = (id) => design.endpoints.find(item => item.id === id);
    const organisms = mergedOrganisms(input);
    const requests = {};
    for (const item of design.endpoints) {
        requests[item.id] = { kind: item.kind, trigger: item.when === 'interaction' ? item.id : item.when, ...(item.writes ? { writes: item.writes } : {}), returns: item.output.map(leaf => leaf.name) };
    }
    const rules = sortedUnique(design.endpoints.flatMap(item => item.rules));
    // States: one per endpoint output key an organism reads from.
    const refs = [...new Set(design.bindings.organisms.map(row => row.reads))];
    const keyCount = new Map();
    for (const ref of refs)
        keyCount.set(ref.split('.')[1], (keyCount.get(ref.split('.')[1]) ?? 0) + 1);
    const states = {};
    for (const ref of refs) {
        const [endpointId, key] = ref.split('.');
        const id = (keyCount.get(key) ?? 0) > 1 ? `${endpointId}${pascal(key)}` : key;
        // d2_80: the state lists every organism that reads its source.
        const readers = design.bindings.organisms.filter(row => row.reads === ref).map(row => row.organism);
        states[id] = { source: ref, description: leafDescription(endpoint(endpointId), key, design), organisms: sortedUnique(readers) };
    }
    // Selections: the selected id lives in an entry param; the state of the selection is the item that id resolves.
    // Precedence of entry params (d2_78): a filter, then a navigation, and a selection's select: wins over both.
    const params = { ...filterParams(input), ...navigationParams(input) };
    const selected = new Set();
    for (const row of design.bindings.selections) {
        const entity = selectionEntity(row.via, design);
        if (!entity)
            continue;
        const param = `${camel(entity)}Id`;
        const target = organisms.get(row.organism)?.selects || row.organism;
        if (!selected.has(param))
            params[param] = { type: 'string', sources: URL_SOURCES, effect: `select:${target}`, persist: false, required: false };
        selected.add(param);
        const stateId = `selected${entity}`;
        // d2_80: the selecting organism and its target, over every selection that lands in this state.
        const feeds = sortedUnique([...(states[stateId]?.organisms ?? []), row.organism, target]);
        states[stateId] = { source: `entry.params.${param}`, description: `the id of the ${entity} selected in ${row.organism}`, organisms: feeds };
    }
    // Prefill: an id an organism edits may come in the URL. Selection, navigation and filter keep their params.
    for (const [organismId, row] of organisms) {
        for (const path of row.edits) {
            const name = path.split('.').slice(-1)[0];
            if (name.endsWith('Id') && !params[name])
                params[name] = { type: 'string', sources: SOURCES, effect: `prefill:${organismId}`, persist: false, required: false };
        }
    }
    return {
        entry: { params },
        requests,
        states,
        journeys: design.bindings.journeys.map(row => ({ step: row.step, organisms: row.organisms, ...(row.continuesIn ? { continuesIn: row.continuesIn } : {}) })),
        rules,
        access: input.access,
    };
}
/** D over the derived shared (d2_70): the code's own output passes its own fact checks. */
export function d2SharedDeriveIssues(input, definition) {
    return gateD2SharedV2(definition, { page11: input.page11, drafts: input.drafts, need: input.need, menu: input.menu, design: input.design, entities: input.entities });
}
function mergedOrganisms(input) {
    const out = new Map();
    for (const device of ['desktop', 'mobile']) {
        const page = input.page11[device];
        for (const [id, organism] of Object.entries(page.organisms)) {
            const draft = input.drafts[device].organisms[id] ?? { reads: [], edits: [], selects: '', submits: [] };
            const row = out.get(id) ?? { kind: organism.kind, text: organism.text, section: page.sections.find(section => section.organisms.includes(id))?.id ?? '', intents: [], reads: [], edits: [], selects: '', submits: [] };
            for (const intent of organism.intents)
                if (!row.intents.some(item => item.id === intent.id))
                    row.intents.push(intent);
            row.reads = [...new Set([...row.reads, ...draft.reads])];
            row.edits = [...new Set([...row.edits, ...draft.edits])];
            row.selects = row.selects || draft.selects;
            for (const submit of draft.submits)
                if (!row.submits.some(item => item.intentId === submit.intentId))
                    row.submits.push(submit);
            out.set(id, row);
        }
    }
    return out;
}
function outputType(item, design) {
    for (const leaf of item?.output ?? []) {
        const ref = parseD2BffType(leaf.type);
        if (ref?.base === 'ref' && d2BffTypeRoot(ref.ref, design))
            return ref.ref;
    }
    return '';
}
function listItemType(ref, design) {
    const [endpointId, key] = ref.split('.');
    const leaf = design.endpoints.find(item => item.id === endpointId)?.output.find(row => row.name === key);
    const type = leaf ? parseD2BffType(leaf.type) : null;
    return type?.base === 'ref' ? type.ref : '';
}
/** The entity a selection picks: the root of the detail the query returns, or of the list item; else the id the query takes. */
function selectionEntity(via, design) {
    if ('list' in via)
        return d2BffTypeRoot(listItemType(via.list, design), design);
    const query = design.endpoints.find(item => item.id === via.query);
    const root = d2BffTypeRoot(outputType(query, design), design);
    if (root)
        return root;
    const id = (query?.input ?? []).flatMap(leaf => (leaf.origin?.kind === 'field' ? leaf.origin.paths : [])).find(path => path.split('.').length === 2 && path.endsWith('.id'));
    return id?.split('.')[0] ?? '';
}
function leafDescription(item, key, design) {
    const leaf = item?.output.find(row => row.name === key);
    const ref = leaf ? parseD2BffType(leaf.type) : null;
    const type = ref?.base === 'ref' ? design.types.find(row => row.name === ref.ref) : undefined;
    if (type) {
        if (ref?.list && type.description)
            return `the list of ${type.description}`;
        return type.description || '';
    }
    // A scalar key has no type of its own; the response JSDoc describes the whole output.
    return `the ${key} that ${item?.id ?? ''} returns`;
}
/** `Entity.id` among an organism's reads. A longer path, or a field that is not the id, does not count. */
function entityIdRead(reads) {
    const path = reads?.find(item => item.split('.').length === 2 && item.endsWith('.id'));
    return path?.split('.')[0] ?? '';
}
/** A sibling page that navigates here opens this page with the record's id (rule 8). The effect names the organism here that reads that entity. */
function navigationParams(input) {
    const params = {};
    const readers = mergedOrganisms(input);
    const organismFor = (entity) => {
        for (const [id, row] of readers)
            if (row.reads.some(path => path.split('.')[0] === entity))
                return id;
        return '';
    };
    for (const sibling of input.siblings) {
        if (sibling.pageId === input.pageId)
            continue;
        const draft = (id) => sibling.drafts.map(row => row.organisms[id]).find(Boolean);
        for (const [id, organism] of Object.entries(sibling.page11.organisms)) {
            for (const intent of organism.intents) {
                if (intent.kind !== 'navigate' || intent.to !== input.pageId)
                    continue;
                const source = draft(id);
                const selected = source?.selects ? draft(source.selects) : undefined;
                const target = selected ?? source;
                // The id the source reads, else the id the organism it selects reads, else the first read.
                const entity = entityIdRead(source?.reads) || entityIdRead(selected?.reads) || target?.reads[0]?.split('.')[0] || '';
                const reader = organismFor(entity);
                if (!entity || !reader)
                    continue;
                params[`${camel(entity)}Id`] = params[`${camel(entity)}Id`] ?? { type: 'string', sources: URL_SOURCES, effect: `select:${reader}`, persist: false, required: false };
            }
        }
    }
    return params;
}
/** The inputs of the onLoad queries that filter what the page shows survive a reload (rule 8). page and pageSize do not. */
function filterParams(input) {
    const params = {};
    const readerOf = (ref) => input.design.bindings.organisms.find(row => row.reads === ref)?.organism;
    for (const item of input.design.endpoints.filter(row => row.kind === 'qry' && row.when === 'onLoad')) {
        // The organism that reads what the query brings: its own output, or the state it updates. No reader, no filter.
        const target = input.design.bindings.organisms.find(row => row.reads.split('.')[0] === item.id)?.organism
            ?? input.design.bindings.updates.filter(row => row.endpoint === item.id).map(row => readerOf(row.state)).find(Boolean);
        if (!target)
            continue;
        for (const leaf of item.input) {
            const path = leaf.origin?.kind === 'field' ? leaf.origin.paths[0] : '';
            if (path.split('.').length === 2 && path.endsWith('.id'))
                continue; // the selected id is the selection's param
            // An entry param is one URL name: the last segment of a nested input (d2_79).
            const name = leaf.name.split('.').slice(-1)[0];
            if (name === 'page' || name === 'pageSize' || params[name])
                continue;
            const ref = parseD2BffType(leaf.type);
            params[name] = { type: ref?.base === 'number' || ref?.base === 'boolean' ? ref.base : 'string', sources: SOURCES, effect: `filter:${target}`, persist: true, required: leaf.optional !== true };
        }
    }
    return params;
}
