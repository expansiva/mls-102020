/// <mls fileReference="_102047_/l4/agendaClinica/rules.defs.ts" enhancement="_blank"/>
export const agendaClinicaRules = {
    "schemaVersion": "2026-09-16-ns5-rules-v2",
    "moduleName": "agendaClinica",
    "rules": {
        "transicaoConsultaValida": "A consulta só pode transitar de agendada para confirmada, de agendada ou confirmada para falta, ou de agendada ou confirmada para atendida.",
        "anotacaoObrigatoriaNoAtendimento": "O registro de uma consulta como atendida exige uma anotação do atendimento.",
        "consultaSemConflito": "Não podem existir duas consultas para o mesmo profissional na mesma data e horário."
    }
};
export default agendaClinicaRules;
