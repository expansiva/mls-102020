/// <mls fileReference="_102047_/l4/comandaRestaurante/workflows.defs.ts" enhancement="_blank"/>
export const comandaRestauranteWorkflows = {
    "schemaVersion": "2026-09-17-ns5-workflows-v3",
    "moduleName": "comandaRestaurante",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "abrirComanda",
            "inProcess": false
        },
        {
            "journeyId": "lancarItemComanda",
            "inProcess": false
        },
        {
            "journeyId": "cancelarItemComanda",
            "inProcess": false
        },
        {
            "journeyId": "fecharComanda",
            "inProcess": false
        }
    ]
};
export default comandaRestauranteWorkflows;
