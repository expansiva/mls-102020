/// <mls fileReference="_102047_/l4/controleEstoque/workflows.defs.ts" enhancement="_blank"/>
export const controleEstoqueWorkflows = {
    "schemaVersion": "2026-09-17-ns5-workflows-v3",
    "moduleName": "controleEstoque",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "cadastrarProduto",
            "inProcess": false
        },
        {
            "journeyId": "registrarMovimentacaoEstoque",
            "inProcess": false
        },
        {
            "journeyId": "acompanharSaldos",
            "inProcess": false
        },
        {
            "journeyId": "tratarAvisoSaldoBaixo",
            "inProcess": false
        }
    ]
};
export default controleEstoqueWorkflows;
