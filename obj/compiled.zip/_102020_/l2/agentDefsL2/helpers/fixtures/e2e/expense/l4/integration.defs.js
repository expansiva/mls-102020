/// <mls fileReference="_102047_/l4/reembolsoDespesas/integration.defs.ts" enhancement="_blank"/>
export const reembolsoDespesasIntegration = {
    "schemaVersion": "2026-09-12-ns5-integration-v2",
    "moduleName": "reembolsoDespesas",
    "inbound": [],
    "outbound": [
        {
            "id": "aprovarDespesa",
            "kind": "event",
            "to": "financeiro",
            "event": "aprovarDespesa",
            "on": "Despesa.aprovarDespesa",
            "description": "Publica a despesa aprovada para que o módulo financeiro possa tratá-la.",
            "entityRefs": [
                "Despesa"
            ]
        }
    ],
    "plugins": []
};
export default reembolsoDespesasIntegration;
