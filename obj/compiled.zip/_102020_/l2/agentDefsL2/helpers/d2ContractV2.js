/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2ContractV2.ts" enhancement="_blank"/>
import { renderD2ContractV2 } from '/_102020_/l2/helpers/contractV2/render.js';
export function buildD2ContractV2(derived, shared, entities) {
    const projections = [];
    for (const row of derived.projections) {
        const body = renderFields(entities[row.entityId], row, 1);
        const existing = projections.find(item => item.body === body);
        if (existing) {
            if (!existing.requestIds.includes(row.requestId))
                existing.requestIds.push(row.requestId);
        }
        else {
            projections.push({ name: `${row.entityId}${pascal(row.requestId)}`, entityId: row.entityId, requestIds: [row.requestId], body });
        }
    }
    const routes = derived.requests.map(derivedRequest => {
        const request = effectiveRequest(derivedRequest, shared, entities);
        const outputParts = request.returns.map(name => {
            const entityId = request.returnEntities[name];
            const proj = projections.find(item => item.requestIds.includes(request.id) && item.entityId === entityId)
                ?? projections.find(item => item.entityId === entityId);
            return `${name}: ${proj?.name ?? 'never'}${many(request) ? '[]' : ''}`;
        });
        for (const list of request.lists) {
            const stem = pascal(list.organismId);
            outputParts.push(`page${stem}: number`, `pageSize${stem}: number`, `hasMore${stem}: boolean`);
        }
        const input = request.kind === 'cmd' ? renderInput(entities, request.writes ?? '', request.inputPaths) : renderQueryInput(request.params);
        return {
            route: `${derived.module}.${derived.pageId}.${request.id}`,
            kind: request.kind,
            ...(request.writes ? { writes: request.writes } : {}),
            input,
            output: `{ ${outputParts.join('; ')} }`,
            meta: contractMeta(request, entities),
            rules: shared.rules[request.id] ?? [],
            access: derived.access,
        };
    });
    return { module: derived.module, pageId: derived.pageId, projections, routes };
}
export function gateD2ContractV2(definition, derived, shared, entities) {
    const issues = [];
    for (const id of Object.keys(shared.requests)) {
        if (!definition.routes.some(route => route.route.endsWith(`.${id}`)))
            issues.push({ code: 'D2_CONTRACT_V2_REQUEST_TYPE', path: id, message: `Shared request ${id} has no contract type.` });
    }
    const covered = new Set();
    for (const proj of definition.projections) {
        const rows = derived.projections.filter(row => row.entityId === proj.entityId && proj.requestIds.includes(row.requestId));
        if (!rows.length) {
            issues.push({ code: 'D2_CONTRACT_V2_PROJECTION_UNKNOWN', path: proj.name, message: `Projection ${proj.name} matches no derived row.` });
        }
        else {
            const leaves = leavesOf(proj.body);
            const seen = new Set();
            for (const leaf of leaves) {
                if (seen.has(leaf.path))
                    issues.push({ code: 'D2_CONTRACT_V2_FIELD_DUPLICATE', path: `${proj.name}.${leaf.path}`, message: `Projection ${proj.name} declares ${leaf.path} more than once.` });
                seen.add(leaf.path);
            }
            const rendered = new Set(leaves.map(item => item.path));
            const derivedSet = derivedPaths(entities[proj.entityId]);
            for (const leaf of leaves) {
                if (leaf.path !== 'id' && leaf.path !== 'version' && derivedSet.has(leaf.path) && !leaf.readonly) {
                    issues.push({ code: 'D2_CONTRACT_V2_DERIVED', path: `${proj.name}.${leaf.path}`, message: `Derived path ${leaf.path} must be readonly.` });
                }
            }
            for (const row of rows) {
                covered.add(`${row.requestId}:${row.entityId}`);
                const expected = new Set(row.paths);
                if (!sameSet(rendered, expected)) {
                    issues.push({ code: 'D2_CONTRACT_V2_FIELD_OUTSIDE', path: proj.name, message: `Projection ${proj.name} fields are not the derived path set for ${row.requestId}.` });
                }
                const hasVersion = rendered.has('version');
                if (hasVersion !== row.includeVersion) {
                    issues.push({ code: 'D2_CONTRACT_V2_VERSION', path: proj.name, message: hasVersion ? 'version is present without update or transition.' : 'version is required for update or transition.' });
                }
            }
        }
    }
    for (const row of derived.projections) {
        if (!covered.has(`${row.requestId}:${row.entityId}`)) {
            issues.push({ code: 'D2_CONTRACT_V2_PROJECTION_UNKNOWN', path: `${row.requestId}:${row.entityId}`, message: `Derived projection ${row.requestId}:${row.entityId} has no contract projection.` });
        }
    }
    for (const route of definition.routes) {
        if (route.kind === 'cmd' && route.writes) {
            const requestId = route.route.split('.').slice(2).join('.');
            const request = derived.requests.find(item => item.id === requestId);
            const entityId = route.writes.split('.')[0] ?? '';
            const operation = route.writes.split('.')[1] ?? '';
            const derivedSet = derivedPaths(entities[entityId]);
            const actual = leavesOf(route.input).map(item => item.path);
            for (const path of actual) {
                if (path !== 'id' && path !== 'version' && derivedSet.has(path))
                    issues.push({ code: 'D2_CONTRACT_V2_DERIVED', path: route.route, message: `Derived path ${path} is in the command input.` });
            }
            const expected = (request?.inputPaths ?? [])
                .filter(path => path.startsWith(`${entityId}.`))
                .map(path => path.slice(entityId.length + 1))
                .filter(path => operation !== 'create' || (path !== 'id' && path !== 'version'));
            if (!request || !sameSet(new Set(actual), new Set(expected))) {
                issues.push({ code: 'D2_CONTRACT_V2_INPUT', path: route.route, message: `Command input leaves are not the request input paths.` });
            }
        }
    }
    for (const route of definition.routes) {
        const requestId = route.route.split('.').slice(2).join('.');
        const derivedRequest = derived.requests.find(item => item.id === requestId);
        if (!derivedRequest)
            continue;
        const request = effectiveRequest(derivedRequest, shared, entities);
        if (!sameJson(route.rules, shared.rules[requestId] ?? [])) {
            issues.push({ code: 'D2_CONTRACT_V2_RULES', path: route.route, message: 'Route rules are not the rules the shared chose for this request.' });
        }
        const expected = contractMeta(request, entities);
        if (!sameJson(route.meta.output, expected.output)) {
            issues.push({ code: 'D2_CONTRACT_V2_META_OUTPUT', path: route.route, message: 'Entity output keys are missing from meta or disagree with returnEntities.' });
        }
        if (!sameJson(route.meta.lists, expected.lists)) {
            issues.push({ code: 'D2_CONTRACT_V2_META_LIST', path: route.route, message: 'A derived list is missing from meta or points at the wrong output key.' });
        }
        if (request.kind === 'qry' && !sameJson(route.meta.params, expected.params)) {
            issues.push({ code: 'D2_CONTRACT_V2_META_PARAM', path: route.route, message: 'A query param is missing from meta or filters the wrong field.' });
        }
        if (danglingMetaRef(route, request, entities)) {
            issues.push({ code: 'D2_CONTRACT_V2_META_REF', path: route.route, message: 'meta names an output key, list, or entity that does not exist.' });
        }
    }
    const renderedGate = renderD2ContractV2({ project: 1, module: definition.module, pageId: definition.pageId }, definition);
    if (renderedGate.includes('Pick<') || renderedGate.includes('Partial<')) {
        issues.push({ code: 'D2_CONTRACT_V2_LITERAL', path: 'source', message: 'Contract must use literal types only.' });
    }
    return issues;
}
/** Returns come from the shared: a command may return more entities the page reads. */
function effectiveRequest(request, shared, entities) {
    const returns = shared.requests[request.id]?.returns ?? request.returns;
    const returnEntities = {};
    for (const name of returns) {
        const entityId = request.returnEntities[name] ?? (request.kind === 'cmd' ? Object.keys(entities).find(id => camel(id) === name) : undefined);
        if (entityId)
            returnEntities[name] = entityId;
    }
    return { ...request, returns, returnEntities };
}
function many(request) {
    return request.kind === 'qry' && (request.id === 'load' || request.lists.length > 0);
}
function contractMeta(request, entities) {
    const output = {};
    for (const [key, entityId] of Object.entries(request.returnEntities)) {
        output[key] = { entity: entityId, many: many(request) };
    }
    const lists = {};
    for (const list of request.lists) {
        const stem = pascal(list.organismId);
        lists[list.organismId] = {
            key: list.key,
            page: `page${stem}`,
            pageSize: `pageSize${stem}`,
            hasMore: `hasMore${stem}`,
        };
    }
    const params = {};
    if (request.kind === 'qry') {
        for (const name of request.params)
            params[name] = paramMeta(request, name, entities);
    }
    return { output, lists, params };
}
function paramMeta(request, name, entities) {
    if (name === 'page' || name === 'pageSize') {
        const list = request.lists.find(item => item.params.includes(name));
        return { pages: list?.organismId ?? '' };
    }
    const list = request.lists.find(item => item.params.includes(name));
    const key = list ? list.key : Object.keys(request.returnEntities)[0] ?? '';
    const entityId = request.returnEntities[key] ?? '';
    const field = name === 'id' && request.id !== 'load' ? 'id' : filterField(entities[entityId], entityId, name);
    return { filters: key, field };
}
function filterField(entity, entityId, param) {
    const view = entity;
    const caps = new Set(Object.keys(view?.capabilities ?? {}));
    if (param === 'search' && caps.has('locate.byName'))
        return stripEntity(view?.displayField ?? '', entityId);
    if (caps.has('listByForeignKey')) {
        for (const rel of Object.values(view?.relationships ?? {})) {
            const via = stripEntity(rel.via ?? '', entityId);
            if (via === param || via.endsWith(`.${param}`))
                return via;
        }
    }
    if (caps.has('locate.byColumn')) {
        const indexed = indexedPaths(view?.record?.fields);
        const found = indexed.find(path => path === param || path.endsWith(`.${param}`));
        if (found)
            return found;
    }
    return '';
}
function indexedPaths(fields, prefix = '') {
    const out = [];
    for (const [key, field] of Object.entries(fields ?? {})) {
        const path = prefix ? `${prefix}.${key}` : key;
        if (field.indexed && !field.fields)
            out.push(path);
        if (field.fields)
            out.push(...indexedPaths(field.fields, path));
    }
    return out;
}
function stripEntity(path, entityId) {
    const prefix = `${entityId}.`;
    return path.startsWith(prefix) ? path.slice(prefix.length) : path;
}
function danglingMetaRef(route, request, entities) {
    for (const [key, row] of Object.entries(route.meta.output)) {
        if (!(key in request.returnEntities) || !entities[row.entity])
            return true;
    }
    for (const [id, row] of Object.entries(route.meta.lists)) {
        if (!request.lists.some(list => list.organismId === id))
            return true;
        if (!(row.key in route.meta.output))
            return true;
        const stem = pascal(id);
        if (row.page !== `page${stem}` || row.pageSize !== `pageSize${stem}` || row.hasMore !== `hasMore${stem}`)
            return true;
    }
    for (const row of Object.values(route.meta.params)) {
        if ('filters' in row && !(row.filters in route.meta.output))
            return true;
        if ('pages' in row && !(row.pages in route.meta.lists))
            return true;
    }
    return false;
}
function sameJson(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
function sameSet(left, right) {
    if (left.size !== right.size)
        return false;
    for (const item of left)
        if (!right.has(item))
            return false;
    return true;
}
function leavesOf(source) {
    const out = [];
    const stack = [];
    let i = 0;
    while (i < source.length) {
        while (i < source.length && /[\s{};,]/.test(source[i])) {
            if (source[i] === '}')
                stack.pop();
            i += 1;
        }
        if (i >= source.length)
            break;
        const readonly = source.startsWith('readonly ', i);
        if (readonly)
            i += 'readonly '.length;
        const name = /^[A-Za-z][A-Za-z0-9]*/u.exec(source.slice(i))?.[0];
        if (!name) {
            i += 1;
            continue;
        }
        i += name.length;
        while (source[i] === ' ' || source[i] === '?')
            i += 1;
        if (source[i] !== ':')
            continue;
        i += 1;
        while (source[i] === ' ')
            i += 1;
        if (source[i] === '{') {
            stack.push(name);
            i += 1;
            continue;
        }
        out.push({ path: [...stack, name].join('.'), readonly });
        let quote = '';
        while (i < source.length) {
            const ch = source[i];
            if (quote) {
                if (ch === quote)
                    quote = '';
                i += 1;
                continue;
            }
            if (ch === '\'' || ch === '"') {
                quote = ch;
                i += 1;
                continue;
            }
            if (ch === ';') {
                i += 1;
                break;
            }
            if (ch === '}')
                break;
            i += 1;
        }
    }
    return out;
}
function renderFields(entity, row, depth) {
    const indent = '  '.repeat(depth);
    const derivedSet = derivedPaths(entity);
    // id and version have one line each above; the field tree never repeats them.
    const tree = treeFromPaths(row.paths.filter(path => path !== 'id' && path !== 'version'));
    const lines = [`${indent}id: string;`];
    if (row.includeVersion)
        lines.push(`${indent}readonly version: number;`);
    if (Object.keys(tree).length)
        lines.push(renderTree(tree, entity, derivedSet, row.entityId, depth));
    return lines.filter(Boolean).join('\n');
}
function treeFromPaths(paths) {
    const root = {};
    for (const path of paths) {
        const parts = path.split('.');
        let cursor = root;
        for (let i = 0; i < parts.length; i += 1) {
            const part = parts[i];
            cursor[part] = cursor[part] ?? { children: {} };
            if (i === parts.length - 1)
                cursor[part].leaf = path;
            cursor = cursor[part].children;
        }
    }
    return root;
}
function renderTree(tree, entity, derivedSet, prefix, depth) {
    const indent = '  '.repeat(depth);
    const lines = [];
    for (const [key, node] of Object.entries(tree)) {
        const path = prefix ? `${prefix}.${key}` : key;
        const fieldPath = path.startsWith(`${entity?.entityId}.`) ? path.slice((entity.entityId?.length ?? 0) + 1) : key;
        const readonly = derivedSet.has(path) || derivedSet.has(fieldPath) ? 'readonly ' : '';
        if (node.leaf && !Object.keys(node.children).length) {
            lines.push(`${indent}${readonly}${key}: ${tsType(entity, node.leaf)};`);
        }
        else {
            lines.push(`${indent}${key}: {`);
            lines.push(renderTree(node.children, entity, derivedSet, path, depth + 1));
            lines.push(`${indent}};`);
        }
    }
    return lines.join('\n');
}
function tsType(entity, path) {
    const parts = path.split('.');
    let fields = entity?.record?.fields;
    for (const part of parts) {
        const field = fields?.[part];
        if (!field)
            return 'string';
        if (part === parts[parts.length - 1])
            return leafType(field);
        fields = field.fields;
    }
    return 'string';
}
function leafType(field) {
    if (field.type === 'enum' && field.values?.length)
        return field.values.map(item => `'${item.value}'`).join(' | ');
    if (field.type === 'boolean')
        return 'boolean';
    if (field.type === 'integer' || field.type === 'number' || field.type === 'decimal')
        return 'number';
    return 'string';
}
function derivedPaths(entity) {
    const out = new Set();
    const walk = (fields, prefix) => {
        for (const [key, field] of Object.entries(fields ?? {})) {
            const path = prefix ? `${prefix}.${key}` : key;
            if (field.derived)
                out.add(path);
            if (field.fields)
                walk(field.fields, path);
        }
    };
    walk(entity?.record?.fields, '');
    return out;
}
function renderInput(entities, writes, paths) {
    const entityId = writes.split('.')[0] ?? '';
    const operation = writes.split('.')[1] ?? '';
    const keepIdentity = operation === 'update' || operation === 'transition';
    const prefix = `${entityId}.`;
    const fields = paths
        .filter(path => path.startsWith(prefix))
        .map(path => path.slice(prefix.length))
        .filter(path => keepIdentity || (path !== 'id' && path !== 'version'));
    if (!fields.length)
        return '{}';
    return renderInline(treeFromPaths(fields), entities[entityId], '');
}
function renderInline(tree, entity, prefix) {
    const parts = [];
    for (const [key, node] of Object.entries(tree)) {
        const path = prefix ? `${prefix}.${key}` : key;
        if (node.leaf && !Object.keys(node.children).length)
            parts.push(`${key}: ${tsType(entity, node.leaf)}`);
        else
            parts.push(`${key}: ${renderInline(node.children, entity, path)}`);
    }
    return `{ ${parts.join('; ')} }`;
}
function renderQueryInput(params) {
    if (!params.length)
        return '{}';
    const types = { page: 'number', pageSize: 'number' };
    return `{ ${params.map(item => `${item}?: ${types[item] ?? 'string'}`).join('; ')} }`;
}
function pascal(value) { return value ? value[0].toUpperCase() + value.slice(1) : value; }
function camel(value) { return value ? value[0].toLowerCase() + value.slice(1) : value; }
