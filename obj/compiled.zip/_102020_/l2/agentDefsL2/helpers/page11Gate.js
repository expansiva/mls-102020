/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/page11Gate.ts" enhancement="_blank"/>
import { resolvableFieldPaths } from '/_102035_/l2/solution/ontologyPaths.js';
import { buildD2Page11Definition } from '/_102020_/l2/agentDefsL2/helpers/page11.js';
import { buildD2Page11Needs } from '/_102020_/l2/agentDefsL2/helpers/page11Needs.js';
import { d2WriteByKey, d2WriteKey } from '/_102020_/l2/helpers/defsInput/writeKey.js';
import { d2CreateRequiredInput, d2TransitionPayload } from '/_102020_/l2/agentDefsL2/helpers/d2WriteInput.js';
import { grantShowsPath } from '/_102020_/l2/helpers/defsInput/grantDisclosure.js';
const TEMPLATE_ROOT = '_102020_/l4/collabux/templates/';
/** The category folder and file of a template reference, or null when it is not one. */
export function parseD2Page11TemplateReference(reference) {
    const match = /^_102020_\/l4\/collabux\/templates\/([A-Za-z0-9_-]+)\/([A-Za-z0-9_-]+)\.md$/u.exec(reference);
    return match ? { categoryId: match[1], shortName: match[2] } : null;
}
/**
 * Templates allowed per published category: the categoryList.json default first (its experience is the derived one),
 * then each experienceIndex.json entry whose file lives in that category's folder. A missing or malformed index
 * leaves only the defaults.
 */
export function d2Page11TemplateOptions(categories, index) {
    const options = new Map();
    const indexed = index && typeof index === 'object' && !Array.isArray(index) ? index.categories : null;
    const byCategory = indexed && typeof indexed === 'object' && !Array.isArray(indexed) ? indexed : {};
    for (const item of categories) {
        const key = item.experiences?.page11 ? 'page11' : item.experiences?.page21 ? 'page21' : '';
        if (!key)
            continue;
        const list = [{ categoryId: item.categoryId, shortName: key, path: `templates/${item.categoryId}/${key}.md`,
                reference: `${TEMPLATE_ROOT}${item.categoryId}/${key}.md`, experience: deriveD2Page11Experience(item.categoryId, categories), isDefault: true }];
        const rows = byCategory[item.categoryId];
        for (const raw of Array.isArray(rows) ? rows : []) {
            const row = raw && typeof raw === 'object' ? raw : {};
            if (typeof row.experience !== 'string' || !row.experience.trim() || typeof row.file !== 'string')
                continue;
            const parsed = parseD2Page11TemplateReference(`${TEMPLATE_ROOT}${row.file}`);
            if (!parsed || parsed.categoryId !== item.categoryId || list.some(option => option.shortName === parsed.shortName))
                continue;
            list.push({ categoryId: item.categoryId, shortName: parsed.shortName, path: `templates/${item.categoryId}/${parsed.shortName}.md`,
                reference: `${TEMPLATE_ROOT}${row.file}`, experience: row.experience.trim(), isDefault: false });
        }
        options.set(item.categoryId, list);
    }
    return options;
}
export function deriveD2Page11Experience(category, categories) {
    if (category === 'bespoke')
        return 'none';
    const entry = categories.find(item => item.categoryId === category);
    if (!entry)
        throw new Error(`D2_PAGE11_CATEGORY_UNKNOWN: ${category}`);
    return entry.experiences?.page11 ?? entry.experiences?.page21 ?? 'none';
}
export function deriveD2Page11CategoryReference(category, categories) {
    if (category === 'bespoke')
        return 'bespoke';
    const entry = categories.find(item => item.categoryId === category);
    if (!entry)
        throw new Error(`D2_PAGE11_CATEGORY_UNKNOWN: ${category}`);
    const key = entry.experiences?.page11 ? 'page11' : entry.experiences?.page21 ? 'page21' : null;
    if (!key)
        throw new Error(`D2_PAGE11_CATEGORY_UNPUBLISHED: ${category}`);
    return `_102020_/l4/collabux/templates/${category}/${key}.md`;
}
/** `kept` replaces the derived default template (an approved alternative of the same category, d2 regeneration). */
export function buildD2Page11WithExperience(value, categories, kept) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('D2_PAGE11_TOOL_OBJECT');
    const root = value;
    const template = root.template;
    if (!template || typeof template !== 'object' || Array.isArray(template))
        throw new Error('D2_PAGE11_TOOL_TEMPLATE');
    const templateRow = template;
    if (Object.keys(templateRow).join('\0') !== 'category' || typeof templateRow.category !== 'string')
        throw new Error('D2_PAGE11_TOOL_CATEGORY_ONLY');
    const derived = { category: deriveD2Page11CategoryReference(templateRow.category, categories), experience: deriveD2Page11Experience(templateRow.category, categories) };
    return buildD2Page11Definition({ ...root, template: kept ?? derived });
}
export function gateD2Page11(value, draftValue, sources) {
    const issues = [];
    let definition;
    let draft;
    try {
        definition = buildD2Page11Definition(value);
    }
    catch (error) {
        return [{ code: 'D2_PAGE11_FORMAT', path: 'definition', message: String(error) }];
    }
    try {
        draft = buildD2Page11Needs(draftValue);
    }
    catch (error) {
        return [{ code: 'D2_PAGE11_NEEDS_FORMAT', path: 'page11Needs', message: String(error) }];
    }
    const add = (code, path, message) => { issues.push({ code, path, message }); };
    const sourcePage = findPage(sources.menu.tree, sources.pageId);
    if (!sourcePage)
        add('D2_PAGE11_PAGE_MISSING', 'menu', `Page ${sources.pageId} is absent from the menu.`);
    if (sourcePage && !actorsFor(sources.menu, sourcePage.path).has(sources.actor))
        add('D2_PAGE11_ACTOR_DENIED', 'menu.authorities', `Actor ${sources.actor} cannot access page ${sources.pageId}.`);
    const expectedKinds = (sourcePage?.node.organisms ?? []).map(item => item.kind).sort();
    const actualKinds = Object.values(definition.organisms).map(item => item.kind).sort();
    if (expectedKinds.join('\0') !== actualKinds.join('\0'))
        add('D2_PAGE11_ORGANISMS_MENU', 'organisms', `Organism kinds/count differ from menu page ${sources.pageId}: expected ${expectedKinds.join(', ')}; got ${actualKinds.join(', ')}.`);
    const ids = Object.keys(definition.organisms);
    const placements = new Map();
    const sectionIds = new Set();
    for (const section of definition.sections) {
        if (sectionIds.has(section.id))
            add('D2_PAGE11_SECTION_DUPLICATE', `sections.${section.id}`, `Section ${section.id} appears more than once.`);
        sectionIds.add(section.id);
        for (const id of section.organisms) {
            placements.set(id, (placements.get(id) ?? 0) + 1);
            if (!definition.organisms[id])
                add('D2_PAGE11_SECTION_UNKNOWN', `sections.${section.id}`, `Section ${section.id} names unknown organism ${id}.`);
        }
    }
    for (const id of ids)
        if (placements.get(id) !== 1)
            add('D2_PAGE11_SECTION_COVERAGE', `organisms.${id}`, `Organism ${id} must occur in exactly one section; got ${placements.get(id) ?? 0}.`);
    for (const id of Object.keys(draft.organisms))
        if (!definition.organisms[id])
            add('D2_PAGE11_NEEDS_EXTRA', `page11Needs.organisms.${id}`, `Draft contains unknown organism ${id}.`);
    for (const id of ids)
        if (!draft.organisms[id])
            add('D2_PAGE11_NEEDS_MISSING', `page11Needs.organisms.${id}`, `Draft is missing organism ${id}.`);
    const category = definition.template.category;
    const entry = sources.categories.find(item => (item.experiences?.page11 || item.experiences?.page21)
        && deriveD2Page11CategoryReference(item.categoryId, sources.categories) === category);
    const reference = category === 'bespoke' ? null : parseD2Page11TemplateReference(category);
    const alternative = !entry && reference ? sources.templateOptions?.get(reference.categoryId)?.find(option => option.reference === category) : undefined;
    if (category !== 'bespoke' && !entry && !alternative) {
        // Same code as before the alternatives existed: neither the categoryList.json default nor an experienceIndex.json file.
        add('D2_PAGE11_CATEGORY_UNKNOWN', 'template.category', `Category reference ${category} is absent from categoryList.json${reference ? ` and from the ${reference.categoryId} templates of experienceIndex.json` : ''}.`);
    }
    else if (alternative) {
        // A user-chosen template of the same category (experienceIndex.json); its experience comes from the index.
        if (definition.template.experience !== alternative.experience)
            add('D2_PAGE11_EXPERIENCE_DERIVATION', 'template.experience', `Experience must be ${alternative.experience} for template ${category}.`);
    }
    else {
        const expected = deriveD2Page11Experience(entry?.categoryId ?? 'bespoke', sources.categories);
        if (definition.template.experience !== expected)
            add('D2_PAGE11_EXPERIENCE_DERIVATION', 'template.experience', `Experience must be ${expected} for category ${category}.`);
        if (expected !== 'none') {
            const key = entry?.experiences?.page11 ? 'page11' : 'page21';
            const path = `templates/${entry.categoryId}/${key}.md`;
            if (!sources.templatePaths.has(path))
                add('D2_PAGE11_TEMPLATE_MISSING', 'template', `Selected template ${path} is absent.`);
        }
    }
    const templateCategory = category === 'bespoke' ? 'bespoke' : entry?.categoryId ?? reference?.categoryId;
    if (sources.chosenCategory && templateCategory && templateCategory !== sources.chosenCategory) {
        add('D2_PAGE11_TEMPLATE_CATEGORY', 'template.category', `Template ${category} belongs to ${templateCategory}, not to the chosen category ${sources.chosenCategory}.`);
    }
    const pageActors = sources.pageActors ?? [sources.actor];
    const currentNeeds = sources.needsPages.find(item => item.pageId === sources.pageId);
    if (!currentNeeds)
        add('D2_PAGE11_NEEDS_PAGE_MISSING', 'page11Needs', `Page ${sources.pageId} has no needs.json entry.`);
    else if (!currentNeeds.actors.includes(sources.actor))
        add('D2_PAGE11_NEEDS_ACTOR', 'page11Needs', `Actor ${sources.actor} is absent from needs.json page ${sources.pageId}.`);
    const keysOf = (writes, where) => writes.flatMap(write => {
        try {
            return [d2WriteKey(write)];
        }
        catch (error) {
            add('D2_PAGE11_TRANSITION_WITHOUT_REF', where, error instanceof Error ? error.message : String(error));
            return [];
        }
    });
    const pageWrites = new Set(keysOf(currentNeeds?.writes ?? [], 'page11Needs.writes'));
    const coveredWrites = new Set();
    const intentIds = new Set();
    for (const [id, organism] of Object.entries(definition.organisms)) {
        const unit = draft.organisms[id];
        if (!unit)
            continue;
        if (unit.selects && !definition.organisms[unit.selects])
            add('D2_PAGE11_SELECT_TARGET', `page11Needs.organisms.${id}.selects`, `Selection target ${unit.selects} is absent.`);
        const submitBindings = new Map();
        for (const binding of unit.submits) {
            if (submitBindings.has(binding.intentId))
                add('D2_PAGE11_SUBMIT_DUPLICATE', `page11Needs.organisms.${id}.submits`, `Submit ${binding.intentId} has duplicate bindings.`);
            submitBindings.set(binding.intentId, binding.write);
        }
        for (const intent of organism.intents) {
            if (intentIds.has(intent.id))
                add('D2_PAGE11_INTENT_DUPLICATE', `organisms.${id}.intents`, `Intent ${intent.id} is duplicated.`);
            intentIds.add(intent.id);
            if (intent.kind === 'submit') {
                const write = submitBindings.get(intent.id);
                if (!write || !pageWrites.has(write))
                    add('D2_PAGE11_SUBMIT_WRITE', `organisms.${id}.intents.${intent.id}`, `Submit ${intent.id} has no matching page write in needs.json.`);
                else
                    coveredWrites.add(write);
            }
            else {
                const target = findPage(sources.menu.tree, intent.to ?? '');
                if (!target)
                    add('D2_PAGE11_NAVIGATE_PAGE', `organisms.${id}.intents.${intent.id}`, `Navigate target ${intent.to} is absent from the menu.`);
                else if (!pageActors.some(actor => actorsFor(sources.menu, target.path).has(actor)))
                    add('D2_PAGE11_NAVIGATE_ACTOR', `organisms.${id}.intents.${intent.id}`, `No actor of the page (${pageActors.join(', ')}) can access target ${intent.to}.`);
                else {
                    const targetWrites = new Set(keysOf(sources.needsPages.find(item => item.pageId === intent.to)?.writes ?? [], `needs.${intent.to}.writes`));
                    const delegated = [...pageWrites].filter(write => targetWrites.has(write));
                    for (const write of delegated)
                        coveredWrites.add(write);
                }
            }
        }
        for (const binding of unit.submits)
            if (!organism.intents.some(intent => intent.kind === 'submit' && intent.id === binding.intentId))
                add('D2_PAGE11_SUBMIT_INVENTED', `page11Needs.organisms.${id}.submits`, `Binding ${binding.intentId} has no submit intent.`);
        for (const path of [...unit.reads, ...unit.edits]) {
            const entityId = path.split('.')[0];
            const entity = sources.entities[entityId];
            if (!entity || !resolvableFieldPaths(entity).includes(path))
                add('D2_PAGE11_FIELD_UNKNOWN', `page11Needs.organisms.${id}`, `Path ${path} is absent from ontology entity ${entityId}.`);
            else if (!pageActors.some(actor => granted(path, actor, sources.access.grants)))
                add('D2_PAGE11_FIELD_GRANT', `page11Needs.organisms.${id}`, `No actor of the page (${pageActors.join(', ')}) has a disclosure grant for ${path}.`);
        }
    }
    issues.push(...d2Page11WriteDuplicates(draft));
    issues.push(...d2Page11InputNotEdited(draft, currentNeeds?.writes ?? [], sources.entities));
    for (const write of pageWrites)
        if (!coveredWrites.has(write))
            add('D2_PAGE11_WRITE_UNCOVERED', 'page11Needs.writes', `Write ${write} needs a submit or accessible navigate target declaring the write.`);
    for (const [id, choices] of Object.entries(definition.molecules)) {
        if (!definition.organisms[id])
            add('D2_PAGE11_MOLECULE_ORGANISM', `molecules.${id}`, `Molecule target ${id} is absent.`);
        for (const choice of choices)
            for (const tag of [choice.preferred, choice.alternative].filter((item) => !!item)) {
                if (!sources.moleculeTags.has(tag))
                    add('D2_PAGE11_MOLECULE_UNKNOWN', `molecules.${id}`, `Tag ${tag} is absent from the selected molecule index.`);
            }
    }
    if (sources.promptTokens !== undefined && (!Number.isSafeInteger(sources.promptTokens) || sources.promptTokens > 160000))
        add('D2_PAGE11_PROMPT_LIMIT', 'promptTokens', `Decision prompt uses ${sources.promptTokens} tokens; maximum is 160000.`);
    return issues;
}
/**
 * A write that asks for typed input needs an organism that edits it (d2_72): a transition payload, or the required
 * fields of a create when nothing on the page edits the entity. Refused here, where the page11 can still be repaired.
 */
export function d2Page11InputNotEdited(draft, writes, entities) {
    const edited = new Set(Object.values(draft.organisms).flatMap(unit => unit.edits));
    const issues = [];
    for (const [organismId, unit] of Object.entries(draft.organisms)) {
        for (const binding of unit.submits) {
            const write = d2WriteByKey(writes, binding.write);
            if (!write)
                continue;
            const entity = entities[write.entity];
            const asked = write.operation === 'transition' ? d2TransitionPayload(entity, write.entity, write.transitionRef ?? '')
                : write.operation === 'create' && ![...edited].some(path => path.split('.')[0] === write.entity) ? d2CreateRequiredInput(entity, write.entity) : [];
            const missing = asked.filter(path => !edited.has(path));
            if (missing.length)
                issues.push({ code: 'D2_PAGE11_INPUT_NOT_EDITED', path: `page11Needs.organisms.${organismId}.submits.${binding.intentId}`,
                    message: `Submit ${binding.intentId} (${binding.write}) asks for ${missing.join(', ')}; add them to the edits of the form that serves it.` });
        }
    }
    return issues;
}
/** One write, one submit: the form that edits the entity owns it; an actions organism does not repeat it. */
export function d2Page11WriteDuplicates(draft) {
    const byWrite = new Map();
    for (const [id, unit] of Object.entries(draft.organisms)) {
        for (const binding of unit.submits)
            byWrite.set(binding.write, [...(byWrite.get(binding.write) ?? []), id]);
    }
    const issues = [];
    for (const [write, owners] of byWrite) {
        if (owners.length < 2)
            continue;
        const entity = write.split('.')[0];
        const form = owners.find(id => draft.organisms[id].edits.some(path => path.split('.')[0] === entity));
        issues.push({ code: 'D2_PAGE11_WRITE_DUPLICATE', path: `page11Needs.organisms.${owners.join(',')}`,
            message: `Write ${write} has a submit in ${owners.join(' and ')}. Keep one submit, in the organism that edits ${entity}${form ? ` (${form})` : ''}; the actions organism does not repeat it.` });
    }
    return issues;
}
export function gateD2Page11Pair(desktop, mobile) {
    let left;
    let right;
    try {
        left = buildD2Page11Definition(desktop);
        right = buildD2Page11Definition(mobile);
    }
    catch (error) {
        return [{ code: 'D2_PAGE11_FORMAT', path: 'pair', message: String(error) }];
    }
    const issues = [];
    if (Object.keys(left.organisms).sort().join('\0') !== Object.keys(right.organisms).sort().join('\0'))
        issues.push({ code: 'D2_PAGE11_DEVICE_ORGANISMS', path: 'organisms', message: 'Desktop and mobile must declare identical organism ids.' });
    if (left.template.category !== right.template.category || left.template.experience !== right.template.experience)
        issues.push({ code: 'D2_PAGE11_DEVICE_TEMPLATE', path: 'template', message: 'Desktop and mobile must use the same category and derived experience.' });
    return issues;
}
function findPage(nodes, id, ancestors = []) {
    for (const node of nodes) {
        const path = [...ancestors, node.id];
        if (node.id === id && node.kind === 'page')
            return { node, path };
        const child = findPage(node.children ?? [], id, path);
        if (child)
            return child;
    }
    return null;
}
function actorsFor(menu, path) {
    return new Set(Object.entries(menu.authorities).filter(([, refs]) => refs.some(ref => path.includes(ref))).map(([actor]) => actor.replace(/^actor:/u, '')));
}
function granted(path, actor, grants) {
    const entity = path.split('.')[0];
    return grants.some(grant => {
        if (grant.actorRef !== actor || !grant.entityRefs.includes(entity))
            return false;
        return grantShowsPath(grant.disclosure, path);
    });
}
