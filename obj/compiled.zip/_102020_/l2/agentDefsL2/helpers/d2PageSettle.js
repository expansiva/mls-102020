/// <mls fileReference="_102020_/l2/agentDefsL2/helpers/d2PageSettle.ts" enhancement="_blank"/>
export async function settleD2Pages(taskId, port, missingCode) {
    const ids = await port.pageIds();
    if (!ids)
        throw new Error(missingCode);
    const refusals = [];
    const pending = [];
    for (const pageId of ids) {
        if (await port.reusable(pageId))
            continue;
        const refusal = await port.refusal(pageId);
        // A refusal left by an earlier task is not this run's answer: the page is being redone.
        if (refusal && refusal.taskId === taskId)
            refusals.push(refusal);
        else
            pending.push(pageId);
    }
    if (pending.length)
        return { state: 'pending', pending };
    if (refusals.length)
        return { state: 'refused', refusals, pageIds: ids.filter(pageId => !refusals.some(row => row.pageId === pageId)) };
    return { state: 'ready', pageIds: ids };
}
export function d2PagesRefusedMessage(code, refusals) {
    return `${code}: ${refusals.map(row => `${row.pageId}: ${row.diagnostic}`).join(' || ')}`;
}
/** The tool arguments of one answer, whatever envelope the host used. */
export function d2ToolPayload(value, name, code) {
    const root = value && typeof value === 'object' ? value : {};
    const candidate = root.type === 'flexible' ? root.result?.arguments : root.arguments ?? root.payload ?? root;
    if (root.type === 'flexible' && root.result?.toolName !== name)
        throw new Error(`${code}_TOOL_MISMATCH`);
    if (typeof candidate !== 'string')
        return candidate;
    try {
        return JSON.parse(candidate);
    }
    catch {
        throw new Error(`${code}_TOOL_JSON`);
    }
}
