/// <mls fileReference="_102020_/l2/pageCraft.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getMaterializeOrchestrator } from '/_102020_/l2/agents/newModule/materializeOrchestrator.js';
import { getThreadByName } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { createThread, getTemporaryContext, getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { executeBeforePrompt, loadAgent } from '/_102027_/l2/aiAgentOrchestration.js';
// ─── Component ───────────────────────────────────────────────────────────────
let PageCraft102020 = class PageCraft102020 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`page-craft-102020 {
  display: block;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  font-size: 14px;
  color: #1a1a1a;
  background: transparent;
}
page-craft-102020 .pc-root {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 16px;
}
page-craft-102020 .pc-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 12px;
  border-bottom: 0.5px solid #e0e0e0;
}
page-craft-102020 .pc-logo {
  font-size: 16px;
  font-weight: 500;
  color: #1a1a1a;
  display: flex;
  align-items: center;
  gap: 8px;
}
page-craft-102020 .pc-logo span.pc-logo-icon {
  color: #1D9E75;
  font-size: 18px;
}
page-craft-102020 .pc-header-sub {
  font-size: 12px;
  color: #888;
  margin-top: 3px;
}
page-craft-102020 .pc-refresh {
  background: #fff;
  border: 0.5px solid #ccc;
  border-radius: 8px;
  padding: 5px 10px;
  cursor: pointer;
  font-size: 15px;
  color: #666;
  line-height: 1;
  transition: background 0.12s;
}
page-craft-102020 .pc-refresh:hover {
  background: #f5f5f5;
}
page-craft-102020 .pc-label {
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: #999;
  margin-bottom: 8px;
}
page-craft-102020 .pc-devices {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}
page-craft-102020 .pc-device-btn {
  padding: 6px 14px;
  font-size: 13px;
  border: 0.5px solid #ccc;
  border-radius: 8px;
  background: #fff;
  color: #555;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
}
page-craft-102020 .pc-device-btn:hover {
  background: #f5f5f5;
  color: #1a1a1a;
}
page-craft-102020 .pc-device-btn.active {
  background: #1D9E75;
  border-color: #1D9E75;
  color: #fff;
}
page-craft-102020 .pc-progress-wrap {
  margin: 4px 0 8px;
}
page-craft-102020 .pc-progress-label {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #888;
  margin-bottom: 6px;
}
page-craft-102020 .pc-progress-track {
  height: 4px;
  background: #eee;
  border-radius: 99px;
  border: 0.5px solid #e0e0e0;
  overflow: hidden;
}
page-craft-102020 .pc-progress-fill {
  height: 100%;
  background: #1D9E75;
  border-radius: 99px;
  transition: width 0.3s ease;
  min-width: 0;
}
page-craft-102020 .pc-module {
  border: 0.5px solid #e0e0e0;
  border-radius: 12px;
  padding: 16px;
  background: #fff;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
page-craft-102020 .pc-module-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
page-craft-102020 .pc-module-name {
  font-size: 15px;
  font-weight: 500;
  color: #1a1a1a;
}
page-craft-102020 .pc-module-pct {
  font-size: 13px;
  color: #888;
}
page-craft-102020 .pc-columns {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
page-craft-102020 .pc-col {
  display: flex;
  flex-direction: column;
}
page-craft-102020 .pc-col-content {
  border: 0.5px solid #e0e0e0;
  padding: 0.3rem;
  border-radius: 5px;
  height: stretch;
}
page-craft-102020 .pc-col-panel {
  border: 0.5px solid #e0e0e0;
  border-radius: 10px;
  overflow: hidden;
  flex: 1;
}
page-craft-102020 .pc-col-head {
  padding: 10px 14px;
  border-bottom: 0.5px solid #e0e0e0;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fafafa;
}
page-craft-102020 .pc-col-head h3 {
  font-size: 13px;
  font-weight: 500;
  color: #1a1a1a;
  flex: 1;
  margin: 0;
}
page-craft-102020 .pc-badge {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 20px;
  font-weight: 500;
  background: #f0f0f0;
  color: #666;
}
page-craft-102020 .pc-badge.done {
  background: #E1F5EE;
  color: #0F6E56;
}
page-craft-102020 .pc-col-body {
  padding: 8px;
  max-height: 420px;
  overflow-y: auto;
}
page-craft-102020 .pc-cap-label {
  font-size: 10px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: #bbb;
  padding: 6px 8px 3px;
}
page-craft-102020 .pc-page-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 8px;
  border: 0.5px solid transparent;
  cursor: pointer;
  margin-bottom: 3px;
  transition: background 0.1s, border-color 0.1s;
}
page-craft-102020 .pc-page-item:hover {
  background: #f5f5f5;
  border-color: #e0e0e0;
}
page-craft-102020 .pc-page-item.selected {
  background: #E1F5EE;
  border-color: #5DCAA5;
}
page-craft-102020 .pc-page-item.done {
  cursor: default;
}
page-craft-102020 .pc-page-icon {
  font-size: 16px;
  color: #bbb;
  min-width: 18px;
}
page-craft-102020 .selected .pc-page-icon {
  color: #0F6E56;
}
page-craft-102020 .done .pc-page-icon {
  color: #1D9E75;
}
page-craft-102020 .pc-page-info {
  flex: 1;
  min-width: 0;
}
page-craft-102020 .pc-page-name {
  font-size: 13px;
  font-weight: 500;
  color: #1a1a1a;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
page-craft-102020 .done .pc-page-name {
  color: #888;
}
page-craft-102020 .pc-page-desc {
  font-size: 11px;
  color: #aaa;
  margin-top: 1px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
page-craft-102020 .pc-status-pill {
  font-size: 10px;
  padding: 2px 7px;
  border-radius: 10px;
  font-weight: 500;
  white-space: nowrap;
}
page-craft-102020 .pc-status-pill.draft {
  background: #FAEEDA;
  color: #854F0B;
}
page-craft-102020 .pc-status-pill.generated {
  background: #E1F5EE;
  color: #0F6E56;
}
page-craft-102020 .pc-status-pill.unknown {
  background: #f0f0f0;
  color: #999;
}
page-craft-102020 .pc-empty {
  text-align: center;
  padding: 24px 12px;
  color: #bbb;
  font-size: 13px;
}
page-craft-102020 .pc-empty .pc-empty-icon {
  font-size: 24px;
  display: block;
  margin-bottom: 6px;
}
page-craft-102020 .pc-footer {
  display: flex;
  align-items: center;
  gap: 10px;
  border-top: 0.5px solid #e0e0e0;
  padding-top: 12px;
}
page-craft-102020 .pc-sel-summary {
  font-size: 12px;
  color: #888;
  flex: 1;
}
page-craft-102020 .pc-gen-btn {
  padding: 9px 20px;
  font-size: 14px;
  font-weight: 500;
  background: #1D9E75;
  border: none;
  border-radius: 8px;
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background 0.12s;
}
page-craft-102020 .pc-gen-btn:hover:not(:disabled) {
  background: #0F6E56;
}
page-craft-102020 .pc-gen-btn:disabled {
  background: #f0f0f0;
  color: #bbb;
  cursor: not-allowed;
}
page-craft-102020 .pc-state-box {
  padding: 32px;
  text-align: center;
  color: #888;
  font-size: 14px;
}
page-craft-102020 .pc-state-box.error {
  color: #c0392b;
}
page-craft-102020 .pc-state-box code {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 13px;
  color: #e74c3c;
}
`);
        this._loading = true;
        this._modules = [];
        this._selectedDevice = 'web';
        this._selectedPages = new Set();
        this._generating = false;
        this._error = null;
        this._devices = [
            { id: 'web', label: 'Web', icon: '🌐' },
            { id: 'mobile', label: 'Mobile', icon: '📱' },
            { id: 'ios', label: 'iOS', icon: '🍎' },
            { id: 'android', label: 'Android', icon: '🤖' },
            { id: 'pwa', label: 'PWA', icon: '⚡' },
            { id: 'tablet', label: 'Tablet', icon: '📟' },
        ];
        this.ex = `/// <mls fileReference="_102035_/l2/pizzaria/module.ts" enhancement="_blank" />
import type { AuraModuleFrontendDefinition } from '/_102029_/l2/contracts/bootstrap.js';

export const moduleGenome = {
  page11: {
    device: 'desktop',
    layout: 'standard',
  },
  page21: {
    device: 'mobile',
    layout: 'standard',
  },
} as const;

export const moduleStates = {
  currentSection: 'ui.pizzaria.currentSection',
  selectedCategory: 'ui.pizzaria.selectedCategory',
  searchQuery: 'ui.pizzaria.searchQuery',
  editorAuthor: 'ui.pizzaria.editorAuthor',
} as const;

export const moduleShellPreferences = {
  layout: {
    asideMode: {
      desktop: 'inline',
      mobile: 'fullscreen',
    },
  },
} as const;

export const moduleFrontendDefinition: AuraModuleFrontendDefinition = {
  pageTitle: 'pizzaria',
  device: 'desktop',
  navigation: [
    {
      id: 'monitor',
      label: 'Monitor',
      href: '/monitor',
      description: 'Mon',
    },
  ],
  routes: [
    {
      path: '/monitor',
      aliases: [],
      entrypoint: '/_102035_/l2/pizzaria/web/desktop/page13/monitor.js',
      tag: 'pizzaria--web--desktop--page13--monitor-102035',
      title: 'Monitor',
    },
  ],
};
`;
    }
    // ── Lifecycle ─────────────────────────────────────────────────────────────
    async connectedCallback() {
        super.connectedCallback();
        await this._scanProject();
    }
    firstUpdated() {
        /*setTimeout(() => {
            let out = addModuleNav(this.ex, { id: 'monitor', label: 'Monitor', href: '/monitor', description: 'Mon' })
            out = addModuleRoute(out, {
                path: '/monitors',
                aliases: [],
                entrypoint: '/_102035_/l2/pizzaria/web/desktop/page13/monitor.js',
                tag: 'pizzaria--web--desktop--page13--monitor-102035',
                title: 'Monitor',
            })

            if (this.preview) this.preview.value = out;

        }, 500)*/
    }
    // ── Render ────────────────────────────────────────────────────────────────
    render() {
        if (this._loading)
            return this._renderLoading();
        if (this._error)
            return this._renderError();
        if (this._modules.length === 0)
            return this._renderEmpty();
        return this._renderMain();
    }
    _renderLoading() {
        return html `<div class="state-box">Varrendo projeto...</div>`;
    }
    _renderError() {
        return html `<div class="state-box error">Erro: ${this._error}</div>`;
    }
    _renderEmpty() {
        return html `<div class="state-box">Nenhum <code>module.defs.ts</code> encontrado no projeto atual.</div>`;
    }
    _renderMain() {
        const selCount = this._selectedPages.size;
        return html `
            <textarea id="preview" style="border:1px solid; width:100%; display:none"></textarea>
            <div class="pc-root">

                <header class="pc-header">
                    <span class="pc-logo">⚙ PageCraft</span>
                    <button class="pc-refresh" title="Re-escanear projeto" @click=${this._scanProject}>↺</button>
                </header>

                <!-- Device selector -->
                <section class="pc-section">
                    <p class="pc-label">Dispositivo alvo</p>
                    <div class="pc-devices">
                        ${this._devices.map((d) => html `
                            <button
                                class="pc-device-btn ${this._selectedDevice === d.id ? 'active' : ''}"
                                @click=${() => this._selectDevice(d.id)}
                            >${d.icon} ${d.label}</button>
                        `)}
                    </div>
                </section>

                <!-- Modules -->
                ${this._modules.map((mod) => this._renderModule(mod))}

                <!-- Generate bar -->
                <footer class="pc-footer">
                    <span class="pc-sel-summary">
                        ${selCount === 0
            ? 'Nenhuma página selecionada'
            : `${selCount} página${selCount > 1 ? 's' : ''} selecionada${selCount > 1 ? 's' : ''}`}
                    </span>
                    <button
                        class="pc-gen-btn"
                        ?disabled=${selCount === 0 || this._generating}
                        @click=${this._generate}
                    >
                        ${this._generating ? 'Gerando...' : `Gerar para ${this._selectedDevice}`}
                    </button>
                </footer>

            </div>
        `;
    }
    _renderModule(mod) {
        const draft = this._allDraft(mod);
        const generated = this._allGenerated(mod);
        const total = mod.pages.length;
        const pct = total > 0 ? Math.round((generated.length / total) * 100) : 0;
        return html `
            <section class="pc-module">

                <div class="pc-module-head">
                    <span class="pc-module-name">Module: ${mod.moduleName}</span>
                    <span class="pc-pct">${pct}%</span>
                </div>
                <div class="pc-progress-track">
                    <div class="pc-progress-fill" style="width:${pct}%"></div>
                </div>

                <div class="pc-columns">

                    <!-- To generate -->
                    <div class="pc-col">
                        <p class="pc-col-label" style="margin-bottom:.3rem">Para gerar <span class="pc-badge">${draft.length}</span></p>
                        <div class="pc-col-content">
                            ${draft.length === 0
            ? html `<p class="pc-empty">Todas geradas ✓</p>` : draft.map((p) => this._renderDraftItem(p))}
                        </div>
                    </div>

                    <!-- Generated -->
                    <div class="pc-col">
                        <p class="pc-col-label" style="margin-bottom:.3rem">Já geradas <span class="pc-badge done">${generated.length}</span></p>
                        <div class="pc-col-content">
                            ${generated.length === 0
            ? html `<p class="pc-empty">Nenhuma ainda</p>` : generated.map((p) => this._renderDoneItem(p))}
                        </div>
                    </div>

                </div>
            </section>
        `;
    }
    _renderDraftItem(page) {
        const sel = this._selectedPages.has(page.key);
        return html `
            <div
                class="pc-page-item ${sel ? 'selected' : ''}"
                role="checkbox"
                aria-checked=${sel}
                tabindex="0"
                @click=${() => this._togglePage(page.key)}
                @keydown=${(e) => e.key === 'Enter' && this._togglePage(page.key)}
            >
                <span class="pc-check">${sel ? '◉' : '○'}</span>
                <span class="pc-page-name">${page.pageName}</span>
                <span class="pc-status-badge draft">draft</span>
            </div>
        `;
    }
    _renderDoneItem(page) {
        return html `
            <div class="pc-page-item done">
                <span class="pc-check done">✓</span>
                <span class="pc-page-name">${page.pageName}</span>
                <span class="pc-status-badge generated">gerado</span>
            </div>
        `;
    }
    // ── Scan logic ────────────────────────────────────────────────────────────
    async _scanProject() {
        this._loading = true;
        this._error = null;
        try {
            const files = mls.stor.files;
            const project = mls.actualProject;
            // 1. Find all module.defs.ts in current project
            const moduleKeys = Object.keys(files).filter((key) => {
                const f = files[key];
                return (f.project === project &&
                    f.shortName === 'module' &&
                    f.extension === '.defs.ts');
            });
            if (moduleKeys.length === 0) {
                this._modules = [];
                this._loading = false;
                return;
            }
            // 2. For each module key, resolve pages in same folder
            const groups = [];
            for (const moduleKey of moduleKeys) {
                const moduleFile = files[moduleKey];
                const moduleName = moduleFile.folder; // folder name = module name
                const folder = moduleFile.folder;
                // All .defs.ts in the same folder, excluding module.defs itself
                const pageKeys = Object.keys(files).filter((key) => {
                    const f = files[key];
                    return (f.project === project &&
                        f.folder === folder &&
                        f.extension === '.defs.ts' &&
                        f.shortName !== 'module');
                });
                // 3. Read each page file and determine status
                const pages = await Promise.all(pageKeys.map(async (key) => {
                    const f = files[key];
                    let status = 'unknown';
                    let pageName = f.shortName.replace(/\.defs$/, '');
                    try {
                        const raw = await f.getContent();
                        const parsed = this._parseDefinition(raw);
                        console.info(parsed);
                        if (parsed) {
                            status = parsed.status === 'draft' ? 'draft' : 'generated';
                            // prefer pageName from definition if available
                            const firstName = parsed.pages?.[0]?.pageName;
                            if (firstName)
                                pageName = firstName;
                        }
                        else {
                            status = 'generated';
                            // prefer pageName from definition if available
                            const firstName = f.shortName;
                            if (firstName)
                                pageName = firstName;
                        }
                    }
                    catch {
                        status = 'unknown';
                    }
                    return { key, shortName: f.shortName, folder, moduleName, status, pageName };
                }));
                groups.push({ moduleName, folder, pages });
            }
            this._modules = groups;
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : String(err);
        }
        finally {
            this._loading = false;
        }
    }
    /**
     * Safely extract `status` and `pages` from a raw TS/JS file that uses
     * `export const definition = { ... }`.
     * Strategy: pull out the object literal and JSON.parse a cleaned version.
     */
    _parseDefinition(raw) {
        try {
            // Extract the object between the first `{` after `definition =` and its matching `}`
            const start = raw.indexOf('{');
            if (start === -1)
                return null;
            // Find matching closing brace
            let depth = 0;
            let end = -1;
            for (let i = start; i < raw.length; i++) {
                if (raw[i] === '{')
                    depth++;
                else if (raw[i] === '}') {
                    depth--;
                    if (depth === 0) {
                        end = i;
                        break;
                    }
                }
            }
            if (end === -1)
                return null;
            let json = raw.slice(start, end + 1);
            // Convert JS object to JSON: remove trailing commas, quote unquoted keys
            json = json
                .replace(/\/\/[^\n]*/g, '') // strip line comments
                .replace(/\/\*[\s\S]*?\*\//g, '') // strip block comments
                .replace(/,(\s*[}\]])/g, '$1') // trailing commas
                .replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)(\s*):/g, '$1"$2"$3:'); // quote keys
            return JSON.parse(json);
        }
        catch {
            return null;
        }
    }
    // ── Interaction ───────────────────────────────────────────────────────────
    _selectDevice(device) {
        this._selectedDevice = device;
        this._selectedPages = new Set();
    }
    _togglePage(key) {
        const next = new Set(this._selectedPages);
        if (next.has(key))
            next.delete(key);
        else
            next.add(key);
        this._selectedPages = next;
    }
    async _generate() {
        if (this._selectedPages.size === 0 || this._generating)
            return;
        this._generating = true;
        await this.executeAgent();
        /*await new Promise((r) => setTimeout(r, 600)); // placeholder
        this._generating = false;
        await this._scanProject(); // re-scan to pick up new status*/
    }
    async executeAgent() {
        let pageName = '_102020_/l2/pageCraft.ts';
        let thread = await getThreadByName(pageName);
        if (!thread) {
            thread = await createThread(pageName, [], 'company');
        }
        const userId = getUserId();
        if (!userId)
            return;
        const threadId = thread?.threadId;
        if (!threadId || !thread)
            return;
        const moduleAgent = await loadAgent('agentToBePage');
        const messageForAgent = `{"page":"{{page}}", "moduleName":"{{module}}", "device":"web", "type":"page11"}`;
        for (let key of this._selectedPages.values()) {
            const md = this._modules.find((m) => m.pages.find((p) => p.key === key));
            if (!md)
                continue;
            const page = mls.stor.convertFileToFileReference(mls.stor.files[key]);
            const msg = messageForAgent.replace('{{page}}', page).replace('{{module}}', md.moduleName);
            if (!moduleAgent)
                throw new Error('Invalid agent');
            const context = getTemporaryContext(threadId, userId, msg);
            executeBeforePrompt(moduleAgent, context);
        }
        setTimeout(() => {
            if (!thread)
                return;
            window.mls.events.fire([2], ['collabMessages'], JSON.stringify({ type: 'thread-open', threadId: thread.threadId, taskId: '' }));
        }, 500);
    }
    _allDraft(module) {
        return module.pages.filter((p) => p.status === 'draft' || p.status === 'unknown');
    }
    _allGenerated(module) {
        return module.pages.filter((p) => p.status === 'generated');
    }
    async getSkill(info) {
        const orch = getMaterializeOrchestrator(info.path);
        const user = await orch.getVar(info.path, info.item.specVar);
        const skill = await orch.getSkill(info.item.skillPath);
        const prompt = `##Skill\n${skill}\n\n##User data\n${user}\n\n##User info\n${JSON.stringify(info)}`;
        return prompt;
    }
};
__decorate([
    state()
], PageCraft102020.prototype, "_loading", void 0);
__decorate([
    state()
], PageCraft102020.prototype, "_modules", void 0);
__decorate([
    state()
], PageCraft102020.prototype, "_selectedDevice", void 0);
__decorate([
    state()
], PageCraft102020.prototype, "_selectedPages", void 0);
__decorate([
    state()
], PageCraft102020.prototype, "_generating", void 0);
__decorate([
    state()
], PageCraft102020.prototype, "_error", void 0);
__decorate([
    query('#preview')
], PageCraft102020.prototype, "preview", void 0);
PageCraft102020 = __decorate([
    customElement('page-craft-102020')
], PageCraft102020);
export { PageCraft102020 };
