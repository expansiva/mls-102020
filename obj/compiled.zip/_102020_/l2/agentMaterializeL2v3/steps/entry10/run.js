/// <mls fileReference="_102020_/l2/agentMaterializeL2v3/steps/entry10/run.ts" enhancement="_blank"/>
import { writeJson } from '/_102035_/l2/solution/fs.js';
import { failM3Step, m3ErrorMessage, productionFailurePort } from '/_102020_/l2/agentMaterializeL2v3/helpers/m3StepFailure.js';
import { listM3RunDirs, m3TraceFileInfo } from '/_102020_/l2/agentMaterializeL2v3/helpers/m3Trace.js';
export const M3_RUN_VERSION = '2026-10-01-m3-run-v1';
export function productionEntryPort(identity) {
    return {
        listRunDirs: () => listM3RunDirs(mls.stor.files, identity.project, identity.module),
        writeJson,
        now: () => new Date(),
        failure: productionFailurePort(identity.project, identity.module, identity.runDir),
    };
}
export async function executeM3Entry(port, identity, command) {
    try {
        if (port.listRunDirs().includes(identity.runDir))
            throw new Error(`M3_RUN_DIR_TAKEN: ${identity.runDir}`);
        await port.writeJson(m3TraceFileInfo(identity.project, identity.module, identity.runDir, 'run'), {
            schemaVersion: M3_RUN_VERSION, project: identity.project, module: identity.module, pages: identity.pages,
            devices: identity.devices, runDir: identity.runDir, startedAt: port.now().toISOString(), command,
        });
        return { status: 'completed', summary: `entry10 started ${identity.runDir}` };
    }
    catch (error) {
        return { status: 'failed', reason: await failM3Step(port.failure, { module: identity.module, runDir: identity.runDir, stepId: 'entry10' }, m3ErrorMessage(error)) };
    }
}
