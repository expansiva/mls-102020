/// <mls fileReference="_102020_/l2/agentMaterializeL2v3/helpers/m3Trace.ts" enhancement="_blank"/>
/**
 * Single chokepoint for the run records of agentMaterializeL2v3: written to
 * `l2/<module>/pipeline/trace/agentMaterializeL2v3/run_<UTC AAAAMMDDhhmmss>/...`.
 * Level 2 on purpose (D-006): the trace lives next to the l2 artifacts it explains. The trace NEVER
 * deletes anything (D-007): every run keeps its own folder, and nothing here removes a file.
 * shortName never contains a dot (Studio round-trip). `project` is always a parameter, never
 * read from `mls.actualProject`.
 */
export const M3_TRACE_LEVEL = 2;
export const M3_AGENT_FOLDER = 'agentMaterializeL2v3';
const memoryDegradations = new Map();
/** In-memory key: two modules (or projects) may share a runDir name, so the runDir alone is not enough. */
function degradationKey(project, moduleName, runDir) {
    return `${project}:${moduleName}:${runDir}`;
}
/** `run_` + UTC AAAAMMDDhhmmss. Never local time. */
export function m3RunDirName(now) {
    const pad = (value, size = 2) => String(value).padStart(size, '0');
    return `run_${pad(now.getUTCFullYear(), 4)}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}`
        + `${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}${pad(now.getUTCSeconds())}`;
}
/** m3RunDirName(now); throws Error('M3_RUN_DIR_TAKEN: <name>') when it is already in existingRunDirs. */
export function m3NewRunDir(now, existingRunDirs) {
    const name = m3RunDirName(now);
    if (existingRunDirs.includes(name))
        throw new Error(`M3_RUN_DIR_TAKEN: ${name}`);
    return name;
}
/** `<module>/pipeline/trace/agentMaterializeL2v3` */
export function m3TraceRoot(moduleName) {
    return `${moduleName}/pipeline/trace/${M3_AGENT_FOLDER}`;
}
/** m3TraceRoot + `/<runDir>` + (`/<subpath>` when given) */
export function m3RunFolder(moduleName, runDir, subpath = '') {
    const base = `${m3TraceRoot(moduleName)}/${runDir}`;
    return subpath ? `${base}/${subpath}` : base;
}
export function m3TraceFileInfo(project, moduleName, runDir, shortName, subpath = '') {
    return {
        project,
        level: M3_TRACE_LEVEL,
        folder: m3RunFolder(moduleName, runDir, subpath),
        shortName,
        extension: '.json',
    };
}
export function m3TraceMlsPath(project, moduleName, runDir, subpath, fileName) {
    return `_${project}_/l2/${m3RunFolder(moduleName, runDir, subpath)}/${fileName}`;
}
/** Distinct `run_\d{14}` segments right under m3TraceRoot, from non-deleted level-2 files of this project; ascending. */
export function listM3RunDirs(files, project, moduleName) {
    if (!project || !moduleName)
        return [];
    const prefix = `${m3TraceRoot(moduleName)}/`;
    const found = new Set();
    for (const file of Object.values(files)) {
        if (!file || file.project !== project || file.level !== M3_TRACE_LEVEL || file.status === 'deleted')
            continue;
        const folder = String(file.folder || '');
        if (!folder.startsWith(prefix))
            continue;
        const segment = folder.slice(prefix.length).split('/')[0];
        if (/^run_\d{14}$/u.test(segment))
            found.add(segment);
    }
    return [...found].sort();
}
export function latestM3RunDir(runDirs) {
    return runDirs.length ? runDirs[runDirs.length - 1] : null;
}
export function describeAgentCommand(longMemory, fallback = '') {
    if (!longMemory)
        return fallback;
    const parts = [];
    if (longMemory.fastMode === 'true')
        parts.push('/fast');
    const cli = typeof longMemory.cliCommand === 'string' ? longMemory.cliCommand : '';
    if (cli === 'rebuild-all')
        parts.push('/rebuild all');
    else if (cli === 'rebuild-defs')
        parts.push('/rebuild defs');
    else if (cli)
        parts.push(cli);
    return parts.join(' ') || fallback;
}
/** Appends to <runDir>/degradations.json (best-effort) and to an in-memory list keyed by project:module:runDir. */
export async function recordM3Degradation(project, moduleName, runDir, kind, reason, path) {
    const entry = { at: new Date().toISOString(), kind, reason };
    if (path)
        entry.path = path;
    const key = degradationKey(project, moduleName, runDir);
    memoryDegradations.set(key, [...(memoryDegradations.get(key) ?? []), entry]);
    if (!project || !moduleName || !runDir)
        return;
    try {
        const existing = await readM3Degradations(project, moduleName, runDir);
        await writeM3Degradations(project, moduleName, runDir, [...existing, entry]);
    }
    catch { /* best-effort: the in-memory copy still reaches the run summary */ }
}
/** Reads <runDir>/degradations.json (falls back to memory), then clears both. */
export async function takeM3Degradations(project, moduleName, runDir) {
    let items = [];
    try {
        items = await readM3Degradations(project, moduleName, runDir);
    }
    catch {
        items = [];
    }
    const key = degradationKey(project, moduleName, runDir);
    if (!items.length)
        items = [...(memoryDegradations.get(key) ?? [])];
    memoryDegradations.delete(key);
    try {
        await writeM3Degradations(project, moduleName, runDir, []);
    }
    catch { /* leave the file if the clear fails */ }
    return items;
}
/** Writes <runDir>/summary.json with savedAt; returns its mls path, or null on failure. */
export async function saveM3RunSummary(project, summary) {
    try {
        if (!project || !summary.moduleName || !summary.runDir)
            return null;
        const info = m3TraceFileInfo(project, summary.moduleName, summary.runDir, 'summary');
        const source = `${JSON.stringify({ savedAt: new Date().toISOString(), ...summary }, null, 2)}\n`;
        await writeJsonStor(info, source);
        return `_${project}_/l2/${info.folder}/${info.shortName}.json`;
    }
    catch {
        return null;
    }
}
function degradationsFileInfo(project, moduleName, runDir) {
    return m3TraceFileInfo(project, moduleName, runDir, 'degradations');
}
async function readM3Degradations(project, moduleName, runDir) {
    if (!project || !moduleName || !runDir)
        return [];
    const file = mls.stor.files[mls.stor.getKeyToFile(degradationsFileInfo(project, moduleName, runDir))];
    if (!file || file.status === 'deleted' || !file.getContent)
        return [];
    const parsed = JSON.parse(String(await file.getContent()));
    return Array.isArray(parsed?.items) ? parsed.items.filter(isDegradation) : [];
}
async function writeM3Degradations(project, moduleName, runDir, items) {
    if (!project || !moduleName || !runDir)
        return;
    await writeJsonStor(degradationsFileInfo(project, moduleName, runDir), `${JSON.stringify({ items }, null, 2)}\n`);
}
async function writeJsonStor(info, source) {
    const { createStorFile } = await import('/_102027_/l2/libStor.js');
    const key = mls.stor.getKeyToFile(info);
    let file = mls.stor.files[key];
    if (!file)
        file = await createStorFile({ ...info, source }, false, false, false);
    if (file.status !== 'renamed' && file.status !== 'new')
        file.status = 'changed';
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: source });
}
function isDegradation(value) {
    if (!value || typeof value !== 'object')
        return false;
    const record = value;
    return typeof record.kind === 'string' && typeof record.reason === 'string';
}
