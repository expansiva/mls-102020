/// <mls fileReference="_102020_/l2/pluginFindTask.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { getUserId } from "/_102025_/l2/collabMessagesHelper.js";
import { msgGetTaskUpdate } from '/_102025_/l2/shared/api.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    find: 'Buscar',
};
const message_en = {
    loading: 'Loading...',
    find: 'Search',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginFindTask = class PluginFindTask extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-find-task-102020 {
  font-family: Arial, sans-serif;
  padding: 20px;
  font-size: var(--font-size-12);
  display: block;
}
plugin-find-task-102020 input,
plugin-find-task-102020 select,
plugin-find-task-102020 textarea {
  width: 100%;
  display: block;
  font-size: 1rem;
  line-height: 1.5;
  color: #000000;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
}
plugin-find-task-102020 button {
  background-color: var(--info-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  width: max-content;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #ffffff;
  cursor: pointer;
}
plugin-find-task-102020 button .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
plugin-find-task-102020 .error {
  color: var(--error-color);
}
plugin-find-task-102020 .section {
  margin-bottom: 20px;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
plugin-find-task-102020 .section > div {
  margin-bottom: 1rem;
}
`);
        this.msg = messages['en'];
        this.actualMessage = undefined;
        this.isLoading = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderSearch()}
        `;
    }
    renderSearch() {
        return html `
            <div class="section">
                <div>
                    <label class="title">MessageId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleThreadChange(e)}
                    /input>
                </div>
                <div>
                    <label class="title">TaskId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleTaskChange(e)}
                    /input>
                </div>
                <div>
                <button
                    @click=${this.findThread}
                    ?disabled=${this.isLoading}
                >
                    ${this.isLoading ? html `<span class="loader"></span>` : this.msg.find}
                </button>
                <small class="error">${this.error}</small>
            </div>
            </div>
            

            ${this.actualTask ? html `<small class="error">Task details moved to mls-102025.</small>` : ''}
        
        `;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.threadId = target.value.trim();
    }
    handleTaskChange(e) {
        const target = e.target;
        this.taskId = target.value.trim();
    }
    async findThread() {
        this.isLoading = true;
        try {
            const user = getUserId();
            if (!this.taskId || !this.threadId || !user)
                return;
            const result = await msgGetTaskUpdate({
                messageId: this.threadId,
                taskId: this.taskId,
                userId: user
            });
            if (!result.success || !result.response?.task) {
                throw new Error(result.error || 'Failed to fetch task');
            }
            this.actualTask = result.response.task;
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            this.actualTask = undefined;
            this.error = message;
        }
        finally {
            this.isLoading = false;
        }
    }
};
__decorate([
    state()
], PluginFindTask.prototype, "threadId", void 0);
__decorate([
    state()
], PluginFindTask.prototype, "taskId", void 0);
__decorate([
    state()
], PluginFindTask.prototype, "error", void 0);
__decorate([
    property()
], PluginFindTask.prototype, "actualTask", void 0);
__decorate([
    property()
], PluginFindTask.prototype, "actualMessage", void 0);
__decorate([
    property()
], PluginFindTask.prototype, "isLoading", void 0);
PluginFindTask = __decorate([
    customElement('plugin-find-task-102020')
], PluginFindTask);
export { PluginFindTask };
