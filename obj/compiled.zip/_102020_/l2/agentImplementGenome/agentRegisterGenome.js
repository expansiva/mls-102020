/// <mls fileReference="_102020_/l2/agentImplementGenome/agentRegisterGenome.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { registerPageGenome } from '/_102020_/l2/dsMatch/registerPageGenome.js';
import { buildGlobalCss } from '/_102020_/l2/dsMatch/buildGlobalCss.js';
import { parseStepArgs, mkCompleted, mkFail } from '/_102020_/l2/agentImplementGenome/planning.js';
export function createAgent() {
    return {
        agentName: 'agentRegisterGenome',
        agentProject: 102020,
        agentFolder: 'agentImplementGenome',
        agentDescription: 'Register the new page variation in module.ts (terminal, no LLM)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseStepArgs(args ?? step.prompt);
        const project = mls.actualProject || 0;
        if (!context.isTest) {
            // Register the new variation in module.ts.
            await registerPageGenome(project, a.module, a.layout, a.ds, a.device);
            // Regenerate the project-wide DS stylesheet from designSystems[*].tokens (Phase B).
            await buildGlobalCss(project);
        }
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        return [mkFail(context, parentStep, step, hookSequential, `[agentRegisterGenome] ${error instanceof Error ? error.message : String(error)}`)];
    }
}
