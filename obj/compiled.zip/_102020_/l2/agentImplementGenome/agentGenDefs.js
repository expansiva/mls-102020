/// <mls fileReference="_102020_/l2/agentImplementGenome/agentGenDefs.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { collabImport } from '/_102027_/l2/collabImport.js';
import { buildWorkItem, variationFolder } from '/_102020_/l2/dsMatch/derivePaths.js';
import { buildPageDsStamp, renderDsVersionExport } from '/_102020_/l2/dsMatch/dsVersion.js';
import { designSystemTsRef } from '/_102020_/l2/dsMatch/buildDesignSystemTs.js';
import { buildMoleculeCatalog } from '/_102020_/l2/dsMatch/buildMoleculeCatalog.js';
import { listLayoutElements, indexById } from '/_102020_/l2/dsMatch/layoutElements.js';
import { loadVariantSelections } from '/_102020_/l2/dsMatch/agent1.js';
import { resolveRulesForPage } from '/_102020_/l2/dsMatch/resolveRulesForPage.js';
import { rulesForPlainElement } from '/_102020_/l2/dsMatch/plainControlRules.js';
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { resolveTagToFile } from '/_102020_/l2/utils.js';
import { parseStepArgs, mkCompleted, mkFail, saveFile } from '/_102020_/l2/agentImplementGenome/planning.js';
// Fixed base render skill — ALWAYS first in the pipeline. Renders the structure
// (definition.layout) + the molecule assigned to each element + applies the DS tokens.
const GENOME_SKILL = '_102020_/l2/agentImplementGenome/skills/genCfePageGenome.ts';
// Defaults for the VARIABLE slots when the DS/layout entry in project.json declares no `skill`.
const DEFAULT_DS_SKILL = '_102020_/l2/agentImplementGenome/skills/genCfePageDesignSystem.ts';
const DEFAULT_LAYOUT_SKILL = '_102020_/l2/agentImplementGenome/skills/layout/genCfePageLayoutStandard.ts';
export function createAgent() {
    return {
        agentName: 'agentGenDefs',
        agentProject: 102020,
        agentFolder: 'agentImplementGenome',
        agentDescription: 'Assemble the final page defs deterministically: place resolved molecules per element (Fase E)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseStepArgs(args ?? step.prompt);
        const project = mls.actualProject || 0;
        const item = buildWorkItem(project, a.module, a.layout, a.ds, a.page, a.device);
        console.info(`[agentGenDefs] ▶ ${a.page} — montagem determinística (sem LLM)`);
        // 1. ORIGIN page11 defs as real objects (clone — we mutate and re-serialize).
        const origin = await importDefs(item.defsOrigem);
        if (!origin?.definition)
            throw new Error(`origin defs not loadable: ${item.defsOrigem}`);
        const definition = clone(origin.definition);
        const pipeline = clone(origin.pipeline ?? []);
        console.info(`[agentGenDefs] ${a.page}: page11 importado (origem=${item.defsOrigem})`);
        // 2. Agent2's per-element variant picks (tag). The semantic choice is already done; we only
        //    PLACE the chosen molecule on the element (by id). Elements Agent2 rejected are absent.
        const selections = await loadVariantSelections(item.defsDestino);
        const catalog = await buildMoleculeCatalog();
        const byTag = new Map(catalog.map(m => [m.tag, m]));
        const byId = indexById(listLayoutElements(definition.layout));
        console.info(`[agentGenDefs] ${a.page}: ${selections.length} variante(s) do Agent2 · ${byId.size} elemento(s) no layout · catálogo: ${catalog.length}`);
        // 3. Place one `molecule` per selected element. `tag: null` = Agent2 rejected/omitted —
        //    no molecule, but the group survives so the plain control can receive `layoutRules`.
        const usagePaths = new Set();
        const assigned = [];
        const groupById = new Map(); // molecule-less elements with a known group
        let placed = 0, unknownId = 0, unknownTag = 0, rejectedCount = 0;
        for (const { id, group, tag } of selections) {
            const el = byId.get(id);
            if (!el) {
                console.warn(`[agentGenDefs]   ⚠ ${id}: id não existe no layout (ignorado)`);
                unknownId++;
                continue;
            }
            if (!tag) {
                groupById.set(id, group);
                rejectedCount++;
                continue;
            }
            const entry = byTag.get(tag);
            if (!entry) {
                console.warn(`[agentGenDefs]   ⚠ ${id}: tag fora do catálogo: ${tag}`);
                groupById.set(id, group);
                unknownTag++;
                continue;
            }
            const f = resolveTagToFile(tag);
            const molecule = {
                project: entry.project,
                group,
                tag,
                purpose: entry.objective,
                import: f ? `/_${f.project}_/l2/${f.folder}/${f.shortName}.js` : '',
            };
            el.ref.molecule = molecule; // single molecule per element
            assigned.push(molecule);
            if (entry.usagePath)
                usagePaths.add(entry.usagePath);
            console.info(`[agentGenDefs]   ✓ ${id} [${el.kind}/${el.intent}] → ${group} → ${tag}`);
            placed++;
        }
        console.info(`[agentGenDefs] ${a.page}: ${placed} molécula(s) colocada(s) · ${rejectedCount} rejeitada(s) · ${unknownId} id-inválido · ${unknownTag} tag-inválida`);
        // 3b. Task 13 — molecule-less elements still follow the configured layout rules: stamp
        //     `layoutRules` (axes governing the element's group + input transversals; only axes
        //     the layout EXPLICITLY configured). Elements with a molecule get nothing — the
        //     molecule was filtered by those axes and already implements them.
        const { rules, configuredAxes } = await resolveRulesForPage(project, a.module, a.page, a.layout);
        let ruled = 0;
        for (const el of byId.values()) {
            if (el.ref.molecule)
                continue;
            const layoutRules = rulesForPlainElement(el.kind, groupById.get(el.id) ?? null, rules, configuredAxes);
            if (!layoutRules)
                continue;
            el.ref.layoutRules = layoutRules;
            console.info(`[agentGenDefs]   ◦ ${el.id} [${el.kind}] plain → layoutRules ${JSON.stringify(layoutRules)}`);
            ruled++;
        }
        console.info(`[agentGenDefs] ${a.page}: ${ruled} elemento(s) plain com layoutRules`);
        // 4. Repoint paths, override skills + dependsFiles, stamp, write.
        // Usage skills go in the pipeline `skills` array (the materializer feeds `skills` to the LLM
        // as skill sections; a `?key=skill` suffix on dependsFiles is understood by nobody).
        repointPaths(pipeline, a.layout, a.ds);
        const baseSkills = await resolvePageSkills(project, a.layout, a.ds);
        const cssRef = designSystemTsRef(project);
        const usageList = [...usagePaths].sort();
        const skills = [...baseSkills, ...usageList];
        for (const p of pipeline) {
            if (skills.length)
                p.skills = skills;
            p.dependsFiles = mergeDepends(p.dependsFiles, cssRef);
        }
        console.info(`[agentGenDefs] ${a.page}: skills=[${baseSkills.join(', ')}] + ${usageList.length} usage skill(s) · +ds=${cssRef}`);
        let finalSrc = renderDefs(item.defsDestino, definition, pipeline, dedupeAssigned(assigned));
        if (!context.isTest) {
            const stamp = await buildPageDsStamp(project, a.module, a.layout, a.ds, a.page, new Date().toISOString(), finalSrc);
            finalSrc = `${finalSrc.replace(/\s*$/, '')}\n\n${renderDsVersionExport(stamp)}\n`;
            await saveFile(item.defsDestino, finalSrc);
            console.info(`[agentGenDefs] ✓ ${a.page}: defs final gravado em ${item.defsDestino} (pageVersion rulesHash=${stamp.rulesHash})`);
        }
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        const msg = `[agentGenDefs] ${error instanceof Error ? error.message : String(error)}`;
        console.error('✗', msg);
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
// ─── helpers ──────────────────────────────────────────────────────────────
/** Import a defs file's exports ({ definition, pipeline }) as real objects. */
async function importDefs(ref) {
    const norm = ref.startsWith('/') ? ref.slice(1) : ref;
    const f = mls.stor.convertFileReferenceToFile(norm);
    if (!f)
        return null;
    return collabImport({ project: f.project, folder: f.folder, shortName: f.shortName, extension: '.defs.ts' });
}
/** Deep clone of a JSON-serializable defs object. */
function clone(o) { return JSON.parse(JSON.stringify(o)); }
/** Repoint each pipeline entry's outputPath/defPath from page11 → page{layout}{ds}. */
function repointPaths(pipeline, layout, ds) {
    const to = `/${variationFolder(layout, ds)}/`;
    for (const p of pipeline ?? []) {
        if (typeof p.outputPath === 'string')
            p.outputPath = p.outputPath.replace('/page11/', to);
        if (typeof p.defPath === 'string')
            p.defPath = p.defPath.replace('/page11/', to);
    }
}
/**
 * Resolve the render skills for this page, in pipeline order:
 *   [ genome (fixed), DS skill (per-DS), layout skill (per-layout) ].
 * The DS/layout skills come from project.json (designSystems[ds].skill / layouts[layout].skill),
 * falling back to the defaults above.
 */
async function resolvePageSkills(project, layout, ds) {
    const config = await getConfigProject(project);
    const dsSkill = config?.designSystems?.[String(ds)]?.skill || DEFAULT_DS_SKILL;
    const layoutSkill = config?.layouts?.[String(layout)]?.skill || DEFAULT_LAYOUT_SKILL;
    return [GENOME_SKILL, dsSkill, layoutSkill].filter(Boolean);
}
/** Merge the DS tokens module (designSystem.ts) into dependsFiles (plain path — no query suffixes). */
function mergeDepends(existing, cssRef) {
    const out = Array.isArray(existing) ? existing.filter((x) => typeof x === 'string') : [];
    if (!out.includes(cssRef))
        out.push(cssRef);
    return out;
}
/** Unique molecules by project|tag (for the flat moleculeAssignments tail / dsVersion stamp). */
function dedupeAssigned(molecules) {
    const seen = new Set();
    const out = [];
    for (const m of molecules) {
        const key = `${m.project}|${m.tag}`;
        if (seen.has(key))
            continue;
        seen.add(key);
        out.push(m);
    }
    return out;
}
/** Serialize the final defs: header + definition (with molecules) + pipeline + flat moleculeAssignments. */
function renderDefs(defsRef, definition, pipeline, assigned) {
    const cleanRef = defsRef.startsWith('/') ? defsRef.slice(1) : defsRef;
    return [
        `/// <mls fileReference="${cleanRef}" enhancement="_blank"/>`,
        '',
        `export const definition = ${JSON.stringify(definition, null, 2)};`,
        '',
        `export const pipeline = ${JSON.stringify(pipeline, null, 2)} as const;`,
        '',
        // Flat, unique used-molecule list. Source of truth for the dsVersion staleness stamp.
        `export const moleculeAssignments = ${JSON.stringify(assigned, null, 2)} as const;`,
        '',
    ].join('\n');
}
