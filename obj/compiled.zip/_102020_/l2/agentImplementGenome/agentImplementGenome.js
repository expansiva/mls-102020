/// <mls fileReference="_102020_/l2/agentImplementGenome/agentImplementGenome.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { listWorkItems, DEFAULT_DEVICE } from '/_102020_/l2/dsMatch/derivePaths.js';
import { mkAgentStep, mkFail, makePlanId } from '/_102020_/l2/agentImplementGenome/planning.js';
export function createAgent() {
    return {
        agentName: 'agentImplementGenome',
        agentProject: 102020,
        agentFolder: 'agentImplementGenome',
        agentDescription: 'Apply a design system to a module: derive page{layout}{ds} from page11',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const { module, layout, ds, device, pages } = JSON.parse(userPrompt);
    if (!module || layout == null || ds == null)
        throw new Error(`(${agent.agentName}) entry needs { module, layout, ds }`);
    const dev = device || DEFAULT_DEVICE;
    // Optional subset: keep only non-empty strings; empty → all pages.
    const targetPages = Array.isArray(pages) ? pages.filter(p => typeof p === 'string' && p) : [];
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: JSON.stringify({ module, layout, ds, device: dev, pages: targetPages }) },
            ],
            taskTitle: targetPages.length
                ? `Regenerate ${targetPages.length} page(s) · DS ${ds} on ${module}`
                : `Implement DS ${ds} (layout ${layout}) on ${module}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            // longMemory is string-only → the subset is JSON-encoded and parsed back in afterPromptStep.
            longTermMemory: { module, layout: String(layout), ds: String(ds), device: dev, pages: JSON.stringify(targetPages) },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid params`);
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        if (payload.type === 'result') {
            return [mkFail(context, parentStep, step, hookSequential, String(payload.result || 'confirmation returned an error'))];
        }
        if (payload.type !== 'flexible' || payload.result?.status !== 'ok') {
            return [mkFail(context, parentStep, step, hookSequential, 'design-system request not confirmed')];
        }
        const lm = (context.task?.iaCompressed?.longMemory || {});
        const module = lm['module'];
        const layout = lm['layout'];
        const ds = lm['ds'];
        const device = lm['device'] || DEFAULT_DEVICE;
        if (!module || layout == null || ds == null)
            throw new Error('missing run params in longMemory');
        const project = mls.actualProject || 0;
        let requested = [];
        try {
            requested = JSON.parse(lm['pages'] || '[]');
        }
        catch {
            requested = [];
        }
        const allPages = listWorkItems(project, module, layout, ds, device).map(i => i.page);
        // `pages` subset (validated against the page11 folder) → that subset; empty → all.
        const pages = requested.length ? allPages.filter(p => requested.includes(p)) : allPages;
        if (pages.length === 0) {
            throw new Error(requested.length
                ? `none of the requested pages [${requested.join(', ')}] exist in ${module}/web/${device}/page11`
                : `no pages found in ${module}/web/${device}/page11`);
        }
        const baseArgs = (page) => ({ module, layout, ds, device, page });
        const genIds = pages.map(p => makePlanId('gen', p));
        const intents = [];
        // Group A — Agent1: pick the molecule GROUPS per organism (writes groupSelections).
        for (const page of pages) {
            intents.push(mkAgentStep(context, step, makePlanId('select', page), `Select groups: ${page}`, 'agentSelectGroups', baseArgs(page), [], 'waiting_human_input', 'parallel_static'));
        }
        // Group B — Agent2: pick the VARIANT per organism from the DS-compatible candidates
        // (writes moleculeAssignments). Each waits on its own select.
        for (const page of pages) {
            intents.push(mkAgentStep(context, step, makePlanId('variant', page), `Pick variant: ${page}`, 'agentSelectVariant', baseArgs(page), [makePlanId('select', page)], 'waiting_dependency', 'parallel_static'));
        }
        // Group C — assemble the final defs. Each waits on its own variant.
        for (const page of pages) {
            intents.push(mkAgentStep(context, step, makePlanId('gen', page), `Gen defs: ${page}`, 'agentGenDefs', baseArgs(page), [makePlanId('variant', page)], 'waiting_dependency', 'parallel_static'));
        }
        // Terminal — register the variation in module.ts ONCE, after EVERY gen completes.
        intents.push(mkAgentStep(context, step, 'register', 'Register module genome', 'agentRegisterGenome', baseArgs(), genIds, 'waiting_dependency', 'sequential'));
        return intents;
    }
    catch (error) {
        const msg = `[${agent.agentName}] ${error instanceof Error ? error.message : String(error)}`;
        return [mkFail(context, parentStep, step, hookSequential, msg)];
    }
}
const system1 = `
<!-- modelType: codeinstruct -->

You validate a design-system derivation request. The human message is a JSON object
{ module, layout, ds, device, pages } (pages is an optional subset; empty = all pages).
If it is a well-formed request to apply a design system to a module, return ONLY:
{"type":"flexible","result":{"status":"ok"}}

If it is clearly invalid, return ONLY:
{"type":"result","result":"a short reason in the user's language"}

Return valid JSON only. No preamble, no markdown fences.

## Output format
export type Output =
  | { type: 'flexible'; result: { status: 'ok' } }
  | { type: 'result'; result: string };
`;
//#endregion
