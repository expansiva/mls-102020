/// <mls fileReference="_102020_/l2/buildFile.ts" enhancement="_blank"/>
import { getTokensCss, getGlobalCss } from '/_102027_/l2/designSystemBase.js';
import { getPath } from '/_102027_/l2/utils';
import { convertFileToTag, resolveTagToFile } from '/_102020_/l2/utils';
export function getDependenciesByHtml(file, html, theme, withCss = false) {
    return new Promise(async (resolve, reject) => {
        try {
            const ret = await getDependencies(file, 'byHtml', html, theme, withCss);
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
}
async function getDependencies(storFile, fileName, html, theme, withCss = false) {
    const { project, shortName, folder } = storFile;
    let wcComponents = extractTagsCustom(html);
    const tag = convertFileToTag({ project, shortName, folder });
    if (!wcComponents.includes(tag))
        wcComponents.push(tag);
    const importsMap = [];
    const importsJs = [];
    const importsLinks = [];
    const errors = [];
    const modules = {};
    await getCompileInfo(wcComponents, importsMap, importsJs, importsLinks, errors, modules);
    let tokens = await getTokensCss(project, theme);
    let globalCss = await getGlobalCss(project, theme);
    return {
        file: fileName,
        wcComponents,
        importsMap: Array.from(new Set(importsMap)),
        importsJs: Array.from(new Set(importsJs)),
        importsLinks: Array.from(new Set(importsLinks)),
        globalCss,
        tokens,
        errors
    };
}
function extractTagsCustom(html) {
    const container = document.createElement('div');
    container.innerHTML = html;
    const customTags = new Set();
    const tagsException = new Set([]);
    const allElements = container.querySelectorAll('*');
    allElements.forEach(element => {
        const tagName = element.tagName.toLowerCase();
        const isCustomTag = tagName.includes('-');
        const isInCodeBlock = element.closest('code') !== null;
        if (isCustomTag &&
            !tagsException.has(tagName) &&
            !isInCodeBlock) {
            customTags.add(tagName);
        }
    });
    return Array.from(customTags);
}
async function getCompileInfo(tags, myImportsMap, myImports, myLinks, myErrors, myModules) {
    for (const tag of tags) {
        try {
            const info = resolveTagToFile(tag);
            if (!info?.project || !info?.shortName)
                continue;
            const { project, shortName, folder } = info;
            const lv = mls.actualLevel === 1 ? 1 : 2;
            const key = mls.stor.getKeyToFiles(project, lv, shortName, folder, '.ts');
            const file = mls.stor.files[key];
            const ipath = {
                project,
                shortName,
                folder: file?.folder ?? folder,
            };
            const enhancementName = await getEnhancementFromFetch(ipath);
            if (!enhancementName)
                throw new Error('enhancementName not valid');
            if (enhancementName === '_blank') {
                await getJSBlank(myImports, ipath);
                continue;
            }
            if (!myModules[enhancementName]) {
                const pathInfo = getPath(enhancementName);
                if (!pathInfo)
                    throw new Error(`[] Not found path: ${enhancementName}`);
                myModules[enhancementName] = {
                    jsMap: false,
                    mModule: await mls.l2.enhancement.getEnhancementModule(pathInfo),
                };
            }
            await getJSImporMap(myImportsMap, enhancementName, myModules);
            await getJSImportEnhancement(myImports, enhancementName, myModules);
            await getJS(myImports, enhancementName, ipath, myModules);
            await getLinks(myLinks, enhancementName, myModules);
        }
        catch (e) {
            myErrors.push({ tag, error: e.message });
        }
    }
}
async function getEnhancementFromFetch(file) {
    const url = getImportUrl(file);
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
    }
    const txt = await response.text();
    const lines = txt.replace(/\r\n/g, '\n').split('\n');
    const mlsLine = lines.find(line => line.trim().startsWith('/// <mls '));
    ;
    if (!mlsLine) {
        throw new Error(`Not found tag 'mls' in ${url}`);
    }
    const enhancementMatch = mlsLine.match(/enhancement="([^"]+)"/);
    if (!enhancementMatch) {
        throw new Error('Not found attr "enhancement" in ' + url);
    }
    return enhancementMatch[1];
}
function getImportUrl(info) {
    let url = `/_${info.project}_/l2/${info.shortName}`;
    if (info.folder) {
        url = `/_${info.project}_/l2/${info.folder}/${info.shortName}`;
    }
    return url;
}
async function getJSImportEnhancement(myImports, enhacementName, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'import')
            return;
        myImports.push(i.ref);
    });
}
async function getJSImporMap(myImportsMap, enhacementName, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    if (myModules[enhacementName].jsMap)
        return;
    myModules[enhacementName].jsMap = true;
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'cdn')
            return;
        myImportsMap.push(`"${i.name}": "${i.ref}"`);
    });
}
async function getJSBlank(myImports, mfile) {
    let key = getImportUrl(mfile);
    if (myImports.includes(key))
        return;
    myImports.push(key);
}
async function getJS(myImports, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    let key = getImportUrl(mfile);
    if (myImports.includes(key))
        return;
    myImports.push(key);
}
async function getLinks(myLinks, enhacementName, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'link')
            return;
        myLinks.push({ rel: i.args, ref: i.ref });
    });
}
