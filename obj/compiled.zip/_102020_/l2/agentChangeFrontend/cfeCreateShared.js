/// <mls fileReference="_102020_/l2/agentChangeFrontend/cfeCreateShared.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { assertArray, assertRecord, assertString, createPlannerToolSchema, extractPlannerOutput, normalizeStringList, optionalString, } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
const CFE_LAYOUT_TOOL_NAME = 'submitCfePageLayout';
const strSchema = { type: 'string' };
const boolSchema = { type: 'boolean' };
const intSchema = { type: 'integer' };
const strArraySchema = { type: 'array', items: strSchema };
const layoutActionSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'action', 'labelKey', 'order'],
    properties: {
        id: strSchema,
        action: strSchema,
        labelKey: strSchema,
        order: intSchema,
        displayHint: strSchema,
    },
};
const layoutFieldSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'field', 'labelKey', 'order'],
    properties: {
        id: strSchema,
        field: strSchema,
        labelKey: strSchema,
        order: intSchema,
        required: boolSchema,
        inputType: strSchema,
        format: strSchema,
        source: strSchema,
    },
};
const layoutMoleculeSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'type', 'order', 'fields', 'columns', 'filters', 'toolbar', 'rowActions', 'actions'],
    properties: {
        id: strSchema,
        type: strSchema,
        order: intSchema,
        titleKey: strSchema,
        source: strSchema,
        binding: strSchema,
        action: strSchema,
        submitAction: strSchema,
        emptyKey: strSchema,
        displayHint: strSchema,
        fields: { type: 'array', items: layoutFieldSchema },
        columns: { type: 'array', items: layoutFieldSchema },
        filters: { type: 'array', items: layoutFieldSchema },
        toolbar: { type: 'array', items: layoutActionSchema },
        rowActions: { type: 'array', items: layoutActionSchema },
        actions: { type: 'array', items: layoutActionSchema },
    },
};
const layoutOrganismSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'type', 'organismName', 'titleKey', 'purpose', 'userActions', 'requiredEntities', 'readsFields', 'writesFields', 'rulesApplied', 'order', 'molecules'],
    properties: {
        id: strSchema,
        type: strSchema,
        organismName: strSchema,
        titleKey: strSchema,
        purpose: strSchema,
        userActions: strArraySchema,
        requiredEntities: strArraySchema,
        readsFields: strArraySchema,
        writesFields: strArraySchema,
        rulesApplied: strArraySchema,
        order: intSchema,
        molecules: { type: 'array', minItems: 1, items: layoutMoleculeSchema },
    },
};
const layoutSectionSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'type', 'sectionName', 'titleKey', 'mode', 'order', 'organisms'],
    properties: {
        id: strSchema,
        type: { enum: ['section', 'sectionTab'] },
        sectionName: strSchema,
        titleKey: strSchema,
        mode: strSchema,
        order: intSchema,
        organisms: { type: 'array', minItems: 1, items: layoutOrganismSchema },
    },
};
export const cfePageLayoutResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['pageLayout'],
    properties: {
        pageLayout: {
            type: 'object',
            additionalProperties: false,
            required: ['pageId', 'layoutId', 'sections', 'i18n', 'dataBindings'],
            properties: {
                pageId: strSchema,
                layoutId: strSchema,
                sections: { type: 'array', minItems: 1, items: layoutSectionSchema },
                i18n: { type: 'object', additionalProperties: strSchema },
                dataBindings: {
                    type: 'array',
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        required: ['id', 'source'],
                        properties: {
                            id: strSchema,
                            source: strSchema,
                            entity: strSchema,
                            command: strSchema,
                            description: strSchema,
                        },
                    },
                },
            },
        },
    },
};
export const cfePageLayoutToolSchema = createPlannerToolSchema(CFE_LAYOUT_TOOL_NAME, 'Submit the semantic layout for one frontend page.', cfePageLayoutResultSchema);
export const cfePageLayoutToolName = CFE_LAYOUT_TOOL_NAME;
export async function readCreateContext() {
    const project = mls.actualProject || 0;
    const modules = new Map();
    const entityToModule = new Map();
    const entities = new Map();
    const operations = new Map();
    const workflows = new Map();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        const shortName = String(file.shortName || '');
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!parsed)
            continue;
        const fileInfo = { project: file.project, level: file.level, folder, shortName, extension: file.extension };
        if (folder === 'workflows') {
            const workflow = workflowFromData(parsed.data, fileInfo, parsed.exportName);
            if (workflow)
                workflows.set(workflow.workflowId, workflow);
        }
        else if (folder === 'operations') {
            const operation = operationFromData(parsed.data, fileInfo, parsed.exportName);
            if (operation)
                operations.set(operation.operationId, operation);
        }
        else if (shortName === 'module' && folder && !folder.includes('/')) {
            const moduleData = isRecord(parsed.data.module) ? parsed.data.module : parsed.data;
            const moduleName = readString(moduleData.moduleName) || folder;
            ensureModule(modules, moduleName).visualStyle = moduleData.visualStyle;
        }
        else if (folder.endsWith('/ontology')) {
            const moduleName = folder.split('/')[0];
            const entity = entityFromData(parsed.data, shortName);
            if (moduleName && entity) {
                ensureModule(modules, moduleName).entityIds.add(entity.entityId);
                entityToModule.set(entity.entityId, moduleName);
                entities.set(entity.entityId, entity);
            }
        }
    }
    const moduleNames = Array.from(modules.keys()).sort();
    const moduleFallback = moduleNames.length === 1 ? moduleNames[0] : 'unknown';
    const moduleVisualStyle = {};
    for (const module of modules.values())
        moduleVisualStyle[module.moduleName] = module.visualStyle || {};
    for (const operation of operations.values())
        operation.moduleName = inferModule(operationEntities(operation), entityToModule, moduleFallback);
    for (const workflow of workflows.values())
        workflow.moduleName = inferModule(workflow.entities, entityToModule, moduleFallback);
    return { project, moduleNames, moduleVisualStyle, entities, operations, workflows, pages: buildPagePlans(workflows, operations, moduleFallback) };
}
export async function generatePageDefs(page) {
    const prepared = await preparePageCreate(page);
    await saveContractSharedDefs(prepared);
    await savePageLayoutDefs(prepared, deterministicLayoutFromBase(prepared));
}
export async function preparePageCreate(page) {
    const context = await readCreateContext();
    const operations = page.operationIds.map(id => context.operations.get(id) || syntheticOperation(page, id, context.project));
    const commands = operations.map(operation => commandFromOperation(operation, context.entities));
    const navigationRefs = [];
    const baseDefinition = pageDefinition(page, operations);
    const visualStyle = context.moduleVisualStyle[page.moduleName];
    const promptContext = buildLayoutPromptContext(context, page, operations, commands, baseDefinition, visualStyle);
    return { project: context.project, page, operations, commands, navigationRefs, baseDefinition, visualStyle, promptContext };
}
export async function saveContractSharedDefs(prepared) {
    await savePageCreateMarker(prepared, 'inProgress');
    await saveFrontendDefs(contractFileInfo(prepared.project, prepared.page), 'definition', prepared.commands, contractPipeline(prepared.project, prepared.page));
    await saveFrontendDefs(sharedFileInfo(prepared.project, prepared.page), 'definition', { bffCommands: prepared.commands, navigationRefs: prepared.navigationRefs }, sharedPipeline(prepared.project, prepared.page, prepared.commands));
}
export async function savePageLayoutDefs(prepared, layout) {
    validatePageLayout(prepared, layout);
    const definition = {
        ...prepared.baseDefinition,
        sections: layout.sections,
        layout: {
            id: layout.layoutId,
            type: 'page',
            sections: layout.sections,
        },
        i18n: layout.i18n,
        dataBindings: layout.dataBindings,
    };
    await saveFrontendDefs(pageFileInfo(prepared.project, prepared.page), 'definition', definition, pagePipeline(prepared.project, prepared.page, prepared.visualStyle));
    await savePageCreateMarker(prepared, 'done');
}
export async function finalizeGeneratedPages() {
    const context = await readCreateContext();
    const checkedPages = await Promise.all(context.pages.map(async (page) => ({ page, ok: await hasGeneratedDefs(context.project, page) })));
    const validPages = checkedPages.filter(item => item.ok).map(item => item.page);
    const skippedPages = checkedPages.filter(item => !item.ok).map(item => item.page.pageId);
    await updateConfigJson(context, validPages);
    const ownersDone = await updateOwnerStatuses(context, validPages.flatMap(page => page.ownerIds), 'done');
    await saveCreateReport(context.project, validPages, ownersDone, skippedPages);
    return { pagesDone: validPages.map(page => page.pageId), ownersDone, skippedPages };
}
export function parseCreatePageArgs(prompt) {
    if (!prompt)
        throw new Error('missing page args');
    const parsed = JSON.parse(prompt);
    const pageId = isRecord(parsed) ? readString(parsed.pageId) : '';
    if (!pageId)
        throw new Error(`invalid page args: ${prompt}`);
    return { pageId };
}
export function createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
}
export function createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, toolSchema, toolName) {
    if (!context.task)
        throw new Error('[createPromptReadyIntent] task invalid');
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: toolName } },
    };
}
export function createAgentStepPayload(planId, agentName, stepTitle, prompt, dependsOn, executionMode = 'sequential', status = 'waiting_dependency') {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        agentName,
        prompt: JSON.stringify(prompt),
        rags: [],
        planning: { planId, dependsOn, executionMode, executionHost: 'client' },
    };
}
export function createAddStepIntent(context, parentStep, step, args) {
    const intent = {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
    if (args)
        intent.executionMode = { type: 'parallel', args, maxParallel: 5 };
    return intent;
}
export function extractCfePageLayoutOutput(payload) {
    return extractPlannerOutput(payload, cfePageLayoutConfig);
}
const cfePageLayoutConfig = {
    toolName: CFE_LAYOUT_TOOL_NAME,
    normalizeResult: normalizeCfePageLayoutResult,
};
function normalizeCfePageLayoutResult(value) {
    const result = assertRecord(value, 'result');
    const pageLayout = assertRecord(result.pageLayout, 'result.pageLayout');
    return {
        pageLayout: {
            pageId: assertString(pageLayout.pageId, 'result.pageLayout.pageId'),
            layoutId: assertString(pageLayout.layoutId, 'result.pageLayout.layoutId'),
            sections: assertArray(pageLayout.sections, 'result.pageLayout.sections').map((item, index) => normalizeLayoutSection(item, `sections[${index}]`)),
            i18n: normalizeI18n(pageLayout.i18n),
            dataBindings: assertArray(pageLayout.dataBindings, 'result.pageLayout.dataBindings').map((item, index) => normalizeDataBinding(item, `dataBindings[${index}]`)),
        },
    };
}
function normalizeLayoutSection(value, path) {
    const section = assertRecord(value, path);
    return {
        id: assertString(section.id, `${path}.id`),
        type: assertString(section.type, `${path}.type`) === 'sectionTab' ? 'sectionTab' : 'section',
        sectionName: assertString(section.sectionName, `${path}.sectionName`),
        titleKey: assertString(section.titleKey, `${path}.titleKey`),
        mode: assertString(section.mode, `${path}.mode`),
        order: normalizeOrder(section.order, `${path}.order`),
        organisms: assertArray(section.organisms, `${path}.organisms`).map((item, index) => normalizeLayoutOrganism(item, `${path}.organisms[${index}]`)),
    };
}
function normalizeLayoutOrganism(value, path) {
    const organism = assertRecord(value, path);
    return {
        id: assertString(organism.id, `${path}.id`),
        type: assertString(organism.type, `${path}.type`),
        organismName: assertString(organism.organismName, `${path}.organismName`),
        titleKey: assertString(organism.titleKey, `${path}.titleKey`),
        purpose: assertString(organism.purpose, `${path}.purpose`),
        userActions: normalizeStringList(organism.userActions, `${path}.userActions`),
        requiredEntities: normalizeStringList(organism.requiredEntities, `${path}.requiredEntities`),
        readsFields: normalizeStringList(organism.readsFields, `${path}.readsFields`),
        writesFields: normalizeStringList(organism.writesFields, `${path}.writesFields`),
        rulesApplied: normalizeStringList(organism.rulesApplied, `${path}.rulesApplied`),
        order: normalizeOrder(organism.order, `${path}.order`),
        molecules: assertArray(organism.molecules, `${path}.molecules`).map((item, index) => normalizeLayoutMolecule(item, `${path}.molecules[${index}]`)),
    };
}
function normalizeLayoutMolecule(value, path) {
    const molecule = assertRecord(value, path);
    return {
        id: assertString(molecule.id, `${path}.id`),
        type: assertString(molecule.type, `${path}.type`),
        order: normalizeOrder(molecule.order, `${path}.order`),
        titleKey: optionalString(molecule.titleKey),
        source: optionalString(molecule.source),
        binding: optionalString(molecule.binding),
        action: optionalString(molecule.action),
        submitAction: optionalString(molecule.submitAction),
        emptyKey: optionalString(molecule.emptyKey),
        displayHint: optionalString(molecule.displayHint),
        fields: normalizeLayoutFields(molecule.fields, `${path}.fields`),
        columns: normalizeLayoutFields(molecule.columns, `${path}.columns`),
        filters: normalizeLayoutFields(molecule.filters, `${path}.filters`),
        toolbar: normalizeLayoutActions(molecule.toolbar, `${path}.toolbar`),
        rowActions: normalizeLayoutActions(molecule.rowActions, `${path}.rowActions`),
        actions: normalizeLayoutActions(molecule.actions, `${path}.actions`),
    };
}
function normalizeLayoutFields(value, path) {
    return assertArray(value, path).map((item, index) => {
        const field = assertRecord(item, `${path}[${index}]`);
        return {
            id: assertString(field.id, `${path}[${index}].id`),
            field: assertString(field.field, `${path}[${index}].field`),
            labelKey: assertString(field.labelKey, `${path}[${index}].labelKey`),
            order: normalizeOrder(field.order, `${path}[${index}].order`),
            required: field.required === true,
            inputType: optionalString(field.inputType),
            format: optionalString(field.format),
            source: optionalString(field.source),
        };
    });
}
function normalizeLayoutActions(value, path) {
    return assertArray(value, path).map((item, index) => {
        const action = assertRecord(item, `${path}[${index}]`);
        return {
            id: assertString(action.id, `${path}[${index}].id`),
            action: assertString(action.action, `${path}[${index}].action`),
            labelKey: assertString(action.labelKey, `${path}[${index}].labelKey`),
            order: normalizeOrder(action.order, `${path}[${index}].order`),
            displayHint: optionalString(action.displayHint),
        };
    });
}
function normalizeDataBinding(value, path) {
    const binding = assertRecord(value, path);
    return {
        id: assertString(binding.id, `${path}.id`),
        source: assertString(binding.source, `${path}.source`),
        entity: optionalString(binding.entity),
        command: optionalString(binding.command),
        description: optionalString(binding.description),
    };
}
function normalizeI18n(value) {
    const record = assertRecord(value, 'result.pageLayout.i18n');
    const normalized = {};
    for (const [key, item] of Object.entries(record))
        normalized[key] = assertString(item, `i18n.${key}`);
    return normalized;
}
function normalizeOrder(value, path) {
    if (typeof value === 'number' && Number.isInteger(value))
        return value;
    if (typeof value === 'string' && /^\d+$/.test(value))
        return Number(value);
    throw new Error(`${path} must be an integer`);
}
function buildLayoutPromptContext(context, page, operations, commands, baseDefinition, visualStyle) {
    const entityIds = new Set([...page.entityIds, ...operations.flatMap(operationEntities), ...commands.flatMap(command => [...readStringArray(command.readsEntities), ...readStringArray(command.writesEntities)])]);
    const entities = Array.from(entityIds).map(entityId => context.entities.get(entityId)).filter(Boolean).map(entity => ({
        entityId: entity.entityId,
        title: entity.title,
        fields: entity.fields,
        rulesApplied: entity.rulesApplied,
    }));
    const workflows = page.ownerIds
        .filter(id => id.startsWith('workflow:'))
        .map(id => context.workflows.get(id.slice('workflow:'.length))?.data)
        .filter(Boolean);
    return {
        page,
        baseDefinition,
        visualStyle,
        workflows,
        operations: operations.map(operation => ({
            operationId: operation.operationId,
            title: operation.title,
            actor: operation.actor,
            entity: operation.entity,
            kind: operation.kind,
            reads: operation.reads,
            writes: operation.writes,
            rulesApplied: operation.rulesApplied,
            story: operation.data.story,
            capability: operation.capability,
        })),
        contract: { bffCommands: commands },
        shared: { bffCommands: commands, availableActions: commands.map(command => command.commandName).filter(Boolean) },
        ontology: { entities },
        layoutRules: [
            'Keep the section -> organism structure. Do not replace it with generic components.',
            'Each section, organism, molecule, field, column and action needs a stable id and explicit order.',
            'Each operation must appear in at least one organism.userActions entry.',
            'Use molecules for visual composition: form, groupviewtable.mlDataTable, summaryPanel, statusTimeline, actionBar or another semantic type.',
            'Use labelKey/titleKey/emptyKey for all visible text and declare those keys in i18n.',
            'Do not emit HTML, CSS, DOM slots or raw web-component markup.',
            'Only reference actions from shared.availableActions.',
            'Only reference fields from contract inputs/outputs or ontology fields.',
        ],
    };
}
function validatePageLayout(prepared, layout) {
    if (layout.pageId !== prepared.page.pageId)
        throw new Error(`layout pageId ${layout.pageId} does not match ${prepared.page.pageId}`);
    const ids = new Set();
    const i18nKeys = new Set(Object.keys(layout.i18n));
    const actions = new Set(prepared.commands.map(command => readString(command.commandName)).filter(Boolean));
    const expectedActions = new Set(prepared.page.operationIds);
    const seenActions = new Set();
    const fields = allowedLayoutFields(prepared);
    registerId(ids, layout.layoutId, 'layout.layoutId');
    for (const section of layout.sections) {
        registerId(ids, section.id, `section:${section.sectionName}`);
        assertI18nKey(i18nKeys, section.titleKey, `${section.id}.titleKey`);
        if (section.organisms.length === 0)
            throw new Error(`${section.id} must have organisms`);
        for (const organism of section.organisms) {
            registerId(ids, organism.id, `organism:${organism.organismName}`);
            assertI18nKey(i18nKeys, organism.titleKey, `${organism.id}.titleKey`);
            for (const action of organism.userActions) {
                if (!actions.has(action))
                    throw new Error(`${organism.id}.userActions references unknown action ${action}`);
                seenActions.add(action);
            }
            for (const entity of organism.requiredEntities) {
                if (entity && !prepared.page.entityIds.includes(entity) && !prepared.operations.some(operation => operationEntities(operation).includes(entity))) {
                    throw new Error(`${organism.id}.requiredEntities references unknown entity ${entity}`);
                }
            }
            if (organism.molecules.length === 0)
                throw new Error(`${organism.id} must have molecules`);
            for (const molecule of organism.molecules)
                validateMolecule(ids, i18nKeys, actions, fields, molecule);
        }
    }
    for (const action of expectedActions) {
        if (!seenActions.has(action))
            throw new Error(`layout does not represent operation ${action}`);
    }
}
function validateMolecule(ids, i18nKeys, actions, fields, molecule) {
    registerId(ids, molecule.id, `molecule:${molecule.id}`);
    if (molecule.titleKey)
        assertI18nKey(i18nKeys, molecule.titleKey, `${molecule.id}.titleKey`);
    if (molecule.emptyKey)
        assertI18nKey(i18nKeys, molecule.emptyKey, `${molecule.id}.emptyKey`);
    for (const action of [molecule.action, molecule.submitAction].filter(Boolean))
        assertAction(actions, action, molecule.id);
    for (const field of [...molecule.fields, ...molecule.columns, ...molecule.filters]) {
        registerId(ids, field.id, `field:${field.id}`);
        assertI18nKey(i18nKeys, field.labelKey, `${field.id}.labelKey`);
        if (!fields.has(field.field))
            throw new Error(`${field.id}.field references unknown field ${field.field}`);
    }
    for (const action of [...molecule.toolbar, ...molecule.rowActions, ...molecule.actions]) {
        registerId(ids, action.id, `action:${action.id}`);
        assertI18nKey(i18nKeys, action.labelKey, `${action.id}.labelKey`);
        assertAction(actions, action.action, action.id);
    }
}
function assertAction(actions, action, path) {
    if (!actions.has(action))
        throw new Error(`${path} references unknown action ${action}`);
}
function assertI18nKey(i18nKeys, key, path) {
    if (!i18nKeys.has(key))
        throw new Error(`${path} references missing i18n key ${key}`);
}
function registerId(ids, id, path) {
    if (ids.has(id))
        throw new Error(`duplicate layout id ${id} at ${path}`);
    ids.add(id);
}
function allowedLayoutFields(prepared) {
    const allowed = new Set();
    for (const operation of prepared.operations) {
        for (const ref of [...fieldRefs(operation.reads), ...fieldRefs(operation.writes)]) {
            allowed.add(ref);
            allowed.add(ref.split('.')[1] || ref);
        }
    }
    for (const command of prepared.commands) {
        const commandName = readString(command.commandName);
        for (const field of [...commandFields(command.input), ...commandFields(command.output)]) {
            allowed.add(field);
            if (commandName) {
                allowed.add(`${commandName}.${field}`);
                allowed.add(`${commandName}.input.${field}`);
                allowed.add(`${commandName}.output.${field}`);
            }
        }
    }
    for (const entityId of unique([...prepared.page.entityIds, ...prepared.operations.flatMap(operationEntities)])) {
        const entity = prepared.promptContext.ontology && isRecord(prepared.promptContext.ontology)
            ? prepared.promptContext.ontology.entities?.find(item => isRecord(item) && item.entityId === entityId)
            : undefined;
        const fields = Array.isArray(entity?.fields) ? entity.fields : [];
        for (const field of fields) {
            if (!isRecord(field))
                continue;
            const fieldId = readString(field.fieldId);
            if (!fieldId)
                continue;
            allowed.add(fieldId);
            allowed.add(`${entityId}.${fieldId}`);
        }
    }
    return allowed;
}
function commandFields(value) {
    if (!Array.isArray(value))
        return [];
    return value.map(item => isRecord(item) ? readString(item.name) : '').filter(Boolean);
}
function deterministicLayoutFromBase(prepared) {
    const i18n = {};
    const sectionId = `section.${prepared.page.pageId}.main`;
    const sectionTitleKey = `${sectionId}.title`;
    i18n[sectionTitleKey] = prepared.page.pageName;
    const organisms = prepared.operations.map((operation, index) => deterministicOrganism(prepared, operation, index, i18n));
    return {
        pageId: prepared.page.pageId,
        layoutId: `page.${prepared.page.pageId}`,
        sections: [{
                id: sectionId,
                type: 'section',
                sectionName: prepared.page.pageName,
                titleKey: sectionTitleKey,
                mode: prepared.operations.some(op => op.kind !== 'query' && op.kind !== 'view') ? 'edit' : 'view',
                order: 10,
                organisms,
            }],
        i18n,
        dataBindings: prepared.commands.map(command => ({
            id: `binding.${prepared.page.pageId}.${readString(command.commandName)}`,
            source: `bff.${readString(command.commandName)}`,
            command: readString(command.commandName),
            description: readString(command.purpose),
        })),
    };
}
function deterministicOrganism(prepared, operation, index, i18n) {
    const command = prepared.commands.find(item => item.commandName === operation.operationId) || {};
    const isQuery = command.kind === 'query';
    const organismId = `organism.${prepared.page.pageId}.${operation.operationId}`;
    const organismTitleKey = `${organismId}.title`;
    i18n[organismTitleKey] = operation.title || humanizeId(operation.operationId);
    const moleculeId = `molecule.${prepared.page.pageId}.${operation.operationId}.${isQuery ? 'table' : 'form'}`;
    const moleculeTitleKey = `${moleculeId}.title`;
    const emptyKey = `${moleculeId}.empty`;
    i18n[moleculeTitleKey] = operation.title || humanizeId(operation.operationId);
    i18n[emptyKey] = 'Nenhum registro encontrado';
    const fields = commandFields(command.input).map((field, fieldIndex) => deterministicField(`${moleculeId}.field.${field}`, field, fieldIndex, i18n));
    const columns = commandFields(command.output).map((field, fieldIndex) => deterministicField(`${moleculeId}.column.${field}`, field, fieldIndex, i18n));
    const actionKey = `${moleculeId}.action.${operation.operationId}`;
    i18n[actionKey] = operation.title || humanizeId(operation.operationId);
    return {
        id: organismId,
        type: isQuery ? 'queryResult' : 'commandForm',
        organismName: toPascalCase(operation.operationId),
        titleKey: organismTitleKey,
        purpose: operation.title || humanizeId(operation.operationId),
        userActions: [operation.operationId],
        requiredEntities: operationEntities(operation),
        readsFields: fieldRefs(operation.reads),
        writesFields: fieldRefs(operation.writes),
        rulesApplied: operation.rulesApplied,
        order: (index + 1) * 10,
        molecules: [{
                id: moleculeId,
                type: isQuery ? 'groupviewtable.mlDataTable' : 'form',
                order: 10,
                titleKey: moleculeTitleKey,
                source: `bff.${operation.operationId}`,
                binding: `binding.${prepared.page.pageId}.${operation.operationId}`,
                submitAction: isQuery ? undefined : operation.operationId,
                action: isQuery ? operation.operationId : undefined,
                emptyKey,
                fields: isQuery ? [] : fields,
                columns: isQuery ? columns : [],
                filters: isQuery ? fields : [],
                toolbar: [],
                rowActions: isQuery ? [{ id: `${moleculeId}.rowAction.${operation.operationId}`, action: operation.operationId, labelKey: actionKey, order: 10 }] : [],
                actions: isQuery ? [] : [{ id: `${moleculeId}.action.${operation.operationId}`, action: operation.operationId, labelKey: actionKey, order: 10 }],
            }],
    };
}
function deterministicField(id, field, index, i18n) {
    const labelKey = `${id}.label`;
    i18n[labelKey] = humanizeId(field);
    return { id, field, labelKey, order: (index + 1) * 10 };
}
function buildPagePlans(workflows, operations, moduleFallback) {
    const pendingWorkflows = Array.from(workflows.values()).filter(owner => owner.statusFrontend === 'toCreate');
    const pendingOperations = Array.from(operations.values()).filter(owner => owner.statusFrontend === 'toCreate');
    const pendingOpsById = new Map(pendingOperations.map(op => [op.operationId, op]));
    const operationIdsUsedByWorkflow = new Set();
    const pages = [];
    for (const workflow of pendingWorkflows) {
        for (const operationId of workflow.operationIds)
            operationIdsUsedByWorkflow.add(operationId);
        const linkedOperations = workflow.operationIds.map(id => pendingOpsById.get(id)).filter(Boolean);
        pages.push({
            pageId: toSafeShortName(workflow.workflowId),
            pageName: workflow.title || humanizeId(workflow.workflowId),
            moduleName: workflow.moduleName || moduleFallback,
            sourceKind: 'workflow',
            ownerIds: unique([`workflow:${workflow.workflowId}`, ...linkedOperations.map(op => `operation:${op.operationId}`)]),
            actorIds: unique([...workflow.actors, ...linkedOperations.map(op => op.actor)]),
            entityIds: unique([...workflow.entities, ...linkedOperations.flatMap(operationEntities)]),
            operationIds: unique([...workflow.operationIds, ...linkedOperations.map(op => op.operationId)]),
            rulesApplied: unique([...workflow.rulesApplied, ...linkedOperations.flatMap(op => op.rulesApplied)]),
            capabilities: unique([...workflow.capabilities.map(c => readString(c.capabilityId)), ...linkedOperations.map(op => readString(op.capability?.capabilityId))]),
        });
    }
    for (const operation of pendingOperations) {
        if (operationIdsUsedByWorkflow.has(operation.operationId))
            continue;
        pages.push({
            pageId: toSafeShortName(operation.operationId),
            pageName: operation.title || humanizeId(operation.operationId),
            moduleName: operation.moduleName || moduleFallback,
            sourceKind: 'operation',
            ownerIds: [`operation:${operation.operationId}`],
            actorIds: unique([operation.actor]),
            entityIds: operationEntities(operation),
            operationIds: [operation.operationId],
            rulesApplied: operation.rulesApplied,
            capabilities: unique([readString(operation.capability?.capabilityId)]),
        });
    }
    return pages.sort((a, b) => `${a.moduleName}:${a.pageId}`.localeCompare(`${b.moduleName}:${b.pageId}`));
}
function commandFromOperation(operation, entities) {
    const primaryEntity = operation.entity || firstEntity(operationEntities(operation));
    const entity = entities.get(primaryEntity);
    const kind = operation.kind === 'query' || operation.kind === 'view' ? 'query' : 'command';
    return {
        commandName: operation.operationId,
        purpose: operation.title || humanizeId(operation.operationId),
        kind,
        input: kind === 'query' ? queryInput(entity) : commandInput(operation, entity),
        output: kind === 'query' ? queryOutput(entity) : commandOutput(entity),
        readsEntities: unique([operation.entity, ...normalizeEntityRefs(operation.reads)]),
        writesEntities: unique(normalizeEntityRefs(operation.writes)),
        readsTables: [],
        writesTables: [],
        usecaseRefs: [operation.operationId],
        layerContract: { controllerLayer: 'layer_2_controllers', mustCallLayer: 'layer_3_usecases', directTableAccessForbidden: true },
        rulesApplied: unique([...(operation.rulesApplied || []), ...(entity?.rulesApplied || [])]),
    };
}
function pageDefinition(page, operations) {
    return {
        pageId: page.pageId,
        pageName: page.pageName,
        actor: page.actorIds[0] || 'user',
        purpose: `Executar ${page.pageName}.`,
        capabilities: page.capabilities,
        flowRefs: {
            experienceFlows: page.sourceKind === 'workflow' ? page.ownerIds.filter(id => id.startsWith('workflow:')).map(id => id.slice('workflow:'.length)) : [],
            entityLifecycles: [],
            taskWorkflows: page.sourceKind === 'workflow' ? page.ownerIds.filter(id => id.startsWith('workflow:')).map(id => id.slice('workflow:'.length)) : [],
            automations: [],
        },
        pluginRefs: [],
        mdmRefs: [],
        pageInputs: [],
        navigationRefs: [],
        sections: [{
                sectionName: page.pageName,
                mode: operations.some(op => op.kind !== 'query' && op.kind !== 'view') ? 'edit' : 'view',
                organisms: operations.map(op => ({
                    organismName: toPascalCase(op.operationId),
                    purpose: op.title || humanizeId(op.operationId),
                    userActions: [op.operationId],
                    requiredEntities: operationEntities(op),
                    readsFields: fieldRefs(op.reads),
                    writesFields: fieldRefs(op.writes),
                    rulesApplied: op.rulesApplied,
                })),
            }],
    };
}
function contractPipeline(project, page) {
    return [{ id: `${page.pageId}__l2_contract`, type: 'l2_contract', outputPath: `_${project}_/l2/${page.moduleName}/web/contracts/${page.pageId}.ts`, defPath: `_${project}_/l2/${page.moduleName}/web/contracts/${page.pageId}.defs.ts`, dependsFiles: [], dependsOn: [], skills: ['_102020_/l2/agentMaterializeSolution/skills/genContract.ts'], agent: 'agentMaterializeGen' }];
}
function sharedPipeline(project, page, commands) {
    return [{ id: `${page.pageId}__l2_shared`, type: 'l2_shared', outputPath: `_${project}_/l2/${page.moduleName}/web/shared/${page.pageId}.ts`, defPath: `_${project}_/l2/${page.moduleName}/web/shared/${page.pageId}.defs.ts`, dependsFiles: [`_${project}_/l2/${page.moduleName}/web/contracts/${page.pageId}.ts`], dependsOn: [], skills: ['/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts'], rulesApplied: unique(commands.flatMap(command => Array.isArray(command.rulesApplied) ? command.rulesApplied.map(String) : [])), agent: 'agentMaterializeGen' }];
}
function pagePipeline(project, page, visualStyle) {
    return [{ id: `${page.pageId}__l2_page`, type: 'l2_page', outputPath: `_${project}_/l2/${page.moduleName}/web/desktop/page11/${page.pageId}.ts`, defPath: `_${project}_/l2/${page.moduleName}/web/desktop/page11/${page.pageId}.defs.ts`, dependsFiles: [`_${project}_/l2/${page.moduleName}/web/shared/${page.pageId}.ts`, `_${project}_/l2/${page.moduleName}/web/contracts/${page.pageId}.ts`], dependsOn: [], skills: ['_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts', '_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts'], afterSaveFrontEnd: '_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage', visualStyle: typeof visualStyle === 'string' ? { description: visualStyle } : (isRecord(visualStyle) ? visualStyle : {}), agent: 'agentMaterializeGen' }];
}
async function saveFrontendDefs(fileInfo, exportName, definition, pipeline) {
    const header = `/// <mls fileReference="${toDisplayRef(fileInfo)}" enhancement="_blank"/>\n\n`;
    await saveStorContent(fileInfo, `${header}export const ${exportName} = ${JSON.stringify(definition, null, 2)};\n\nexport const pipeline = ${JSON.stringify(pipeline, null, 2)} as const;\n`);
}
async function updateConfigJson(context, pages) {
    const fileInfo = { project: context.project, level: 0, folder: '', shortName: 'config', extension: '.json' };
    const existing = await readJsonFile(fileInfo);
    const config = isRecord(existing) ? existing : createBaseConfig(context.project);
    const projects = ensureRecord(config, 'projects');
    const projectKey = String(context.project);
    const projectConfig = ensureRecord(projects, projectKey);
    projectConfig.root = projectConfig.root || '.';
    projectConfig.type = projectConfig.type || 'client';
    const modules = ensureArray(projectConfig, 'modules');
    for (const moduleName of unique(pages.map(page => page.moduleName))) {
        const moduleConfig = upsertByKey(modules, 'moduleId', moduleName);
        moduleConfig.moduleId = moduleName;
        moduleConfig.basePath = moduleConfig.basePath || `/${moduleName}`;
        moduleConfig.shellMode = moduleConfig.shellMode || 'spa';
        moduleConfig.backendRouter = moduleConfig.backendRouter || `./_${context.project}_/l1/${moduleName}/layer_2_controllers/router.js`;
        const navigation = ensureArray(moduleConfig, 'navigation');
        const frontend = ensureRecord(moduleConfig, 'frontend');
        frontend.layer = 'l2';
        frontend.moduleEntrypoint = frontend.moduleEntrypoint || `./_${context.project}_/l2/${moduleName}/module.js`;
        frontend.moduleSource = frontend.moduleSource || `l2/${moduleName}/module.ts`;
        const frontendPages = ensureArray(frontend, 'pages');
        for (const page of pages.filter(p => p.moduleName === moduleName)) {
            Object.assign(upsertByKey(navigation, 'id', page.pageId), { id: page.pageId, label: page.pageName, href: `/${moduleName}/${page.pageId}`, description: page.pageName });
            Object.assign(upsertByKey(frontendPages, 'pageId', page.pageId), { pageId: page.pageId, route: `/${moduleName}/${page.pageId}`, source: `l2/${moduleName}/web/desktop/page11/${page.pageId}.ts`, definition: `l2/${moduleName}/web/desktop/page11/${page.pageId}.defs.ts`, componentTag: `${toKebabCase(moduleName)}--web--desktop--page11--${toKebabCase(page.pageId)}-${context.project}` });
        }
    }
    await saveStorContent(fileInfo, `${JSON.stringify(config, null, 2)}\n`);
}
async function updateOwnerStatuses(context, ownerIds, status) {
    const updated = [];
    const wanted = new Set(ownerIds);
    for (const workflow of context.workflows.values()) {
        const ownerId = `workflow:${workflow.workflowId}`;
        if (!wanted.has(ownerId))
            continue;
        workflow.data.statusFrontend = status;
        await saveConstDefault(workflow.fileInfo, workflow.exportName, workflow.data);
        updated.push(ownerId);
    }
    for (const operation of context.operations.values()) {
        const ownerId = `operation:${operation.operationId}`;
        if (!wanted.has(ownerId))
            continue;
        operation.data.statusFrontend = status;
        await saveConstDefault(operation.fileInfo, operation.exportName, operation.data);
        updated.push(ownerId);
    }
    return updated;
}
async function saveCreateReport(project, pages, ownersDone, skippedPages) {
    for (const moduleName of unique(pages.map(page => page.moduleName))) {
        const fileInfo = { project, level: 2, folder: `${moduleName}/trace`, shortName: 'frontend-create-report', extension: '.json' };
        await saveStorContent(fileInfo, `${JSON.stringify({ savedAt: new Date().toISOString(), pagesDone: pages.filter(p => p.moduleName === moduleName).map(p => p.pageId), ownersDone, skippedPages }, null, 2)}\n`);
    }
}
async function savePageCreateMarker(prepared, status) {
    const fileInfo = pageCreateMarkerFileInfo(prepared.project, prepared.page);
    await saveStorContent(fileInfo, `${JSON.stringify({
        savedAt: new Date().toISOString(),
        status,
        pageId: prepared.page.pageId,
        moduleName: prepared.page.moduleName,
        agent: 'agentCfeCreatePage',
    }, null, 2)}\n`);
}
async function hasGeneratedDefs(project, page) {
    const defsExist = [contractFileInfo(project, page), sharedFileInfo(project, page), pageFileInfo(project, page)].every(fileInfo => {
        const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        return !!file && file.status !== 'deleted';
    });
    if (!defsExist)
        return false;
    const marker = await readJsonFile(pageCreateMarkerFileInfo(project, page));
    return isRecord(marker) && marker.status === 'done';
}
function contractFileInfo(project, page) { return { project, level: 2, folder: `${page.moduleName}/web/contracts`, shortName: page.pageId, extension: '.defs.ts' }; }
function sharedFileInfo(project, page) { return { project, level: 2, folder: `${page.moduleName}/web/shared`, shortName: page.pageId, extension: '.defs.ts' }; }
function pageFileInfo(project, page) { return { project, level: 2, folder: `${page.moduleName}/web/desktop/page11`, shortName: page.pageId, extension: '.defs.ts' }; }
function pageCreateMarkerFileInfo(project, page) { return { project, level: 2, folder: `${page.moduleName}/trace/frontend-create-pages`, shortName: page.pageId, extension: '.json' }; }
function operationFromData(data, fileInfo, exportName) {
    const operationId = readString(data.operationId);
    if (!operationId)
        return null;
    return { operationId, title: readString(data.title) || humanizeId(operationId), actor: readString(data.actor), entity: normalizeEntityRef(readString(data.entity)), kind: readString(data.kind), reads: readStringArray(data.reads), writes: readStringArray(data.writes), rulesApplied: readStringArray(data.rulesApplied), statusFrontend: readString(data.statusFrontend), capability: isRecord(data.capability) ? data.capability : undefined, moduleName: '', fileInfo, exportName, data };
}
function syntheticOperation(page, operationId, project) {
    const entity = page.entityIds[0] || '';
    const kind = inferOperationKind(operationId);
    return {
        operationId,
        title: humanizeId(operationId),
        actor: page.actorIds[0] || 'user',
        entity,
        kind,
        reads: entity ? [entity] : [],
        writes: kind === 'query' || kind === 'view' ? [] : (entity ? [entity] : []),
        rulesApplied: page.rulesApplied,
        statusFrontend: 'synthetic',
        capability: page.capabilities[0] ? { capabilityId: page.capabilities[0] } : undefined,
        moduleName: page.moduleName,
        fileInfo: { project, level: 4, folder: 'operations', shortName: operationId, extension: '.defs.ts' },
        exportName: `synthetic${toPascalCase(operationId)}`,
        data: {},
    };
}
function inferOperationKind(operationId) {
    const id = operationId.toLowerCase();
    if (/^(list|view|get|show|browse|search|generate|report|ai)/.test(id) || id.includes('dashboard') || id.includes('summary') || id.includes('report'))
        return 'query';
    if (/^(create|add|record|open|register|start)/.test(id))
        return 'create';
    if (/^(delete|remove|cancel|archive|void)/.test(id))
        return 'delete';
    return 'update';
}
function workflowFromData(data, fileInfo, exportName) {
    const workflowId = readString(data.workflowId);
    if (!workflowId)
        return null;
    return { workflowId, title: readString(data.title) || humanizeId(workflowId), actors: readStringArray(data.actors), operationIds: readStringArray(data.operationIds), entities: normalizeEntityRefs(readStringArray(data.entities)), rulesApplied: readStringArray(data.rulesApplied), statusFrontend: readString(data.statusFrontend), capabilities: Array.isArray(data.capabilities) ? data.capabilities.filter(isRecord) : [], moduleName: '', fileInfo, exportName, data };
}
function entityFromData(data, fallbackId) {
    const entityId = readString(data.entityId) || fallbackId;
    if (!entityId)
        return null;
    const fields = Array.isArray(data.fields) ? data.fields.filter(isRecord).map(field => ({ fieldId: readString(field.fieldId), type: readString(field.type), required: field.required === true, enum: readStringArray(field.enum) })).filter(field => field.fieldId) : [];
    return { entityId, title: readString(data.title) || humanizeId(entityId), fields, rulesApplied: readStringArray(data.rulesApplied) };
}
function queryInput(entity) {
    if (!entity)
        return [];
    return entity.fields.filter(field => ['status', 'name', 'title', 'type', 'category'].some(token => field.fieldId.toLowerCase().includes(token))).slice(0, 4).map(field => ({ name: field.fieldId, type: toFrontendType(field.type), required: false }));
}
function queryOutput(entity) { return entity ? entity.fields.slice(0, 8).map(field => ({ name: field.fieldId, type: toFrontendType(field.type) })) : []; }
function commandInput(operation, entity) {
    if (!entity)
        return [];
    const explicitFields = new Set(fieldRefs(operation.writes).filter(ref => ref.startsWith(`${entity.entityId}.`)).map(ref => ref.split('.')[1]));
    const hasExplicit = explicitFields.size > 0;
    const isCreate = operation.kind === 'create';
    return entity.fields.filter(field => !isSystemField(field.fieldId)).filter(field => !hasExplicit || explicitFields.has(field.fieldId)).filter(field => !isCreate || !isLikelyIdField(field.fieldId)).slice(0, 10).map(field => ({ name: field.fieldId, type: toFrontendType(field.type), required: field.required === true && !isLikelyIdField(field.fieldId) }));
}
function commandOutput(entity) {
    if (!entity)
        return [];
    const idField = entity.fields.find(field => isLikelyIdField(field.fieldId)) || entity.fields[0];
    return idField ? [{ name: idField.fieldId, type: toFrontendType(idField.type) }] : [];
}
function operationEntities(operation) { return unique([operation.entity, ...normalizeEntityRefs(operation.reads), ...normalizeEntityRefs(operation.writes)]); }
function firstEntity(values) { return values.find(Boolean) || ''; }
function fieldRefs(values) { return values.filter(value => value.includes('.')).map(value => { const [entity, field] = value.split('.'); return `${normalizeEntityRef(entity)}.${field}`; }); }
function inferModule(entityIds, entityToModule, fallbackModule) { return entityIds.map(id => entityToModule.get(id)).find(Boolean) || fallbackModule; }
function normalizeEntityRefs(values) { return unique(values.map(normalizeEntityRef).filter(Boolean)); }
function normalizeEntityRef(value) { return value.split('.')[0].trim(); }
function parseDefsSource(content) {
    const exportMatch = content.match(/export\s+const\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=/);
    const start = content.indexOf('= ');
    const end = content.lastIndexOf(' as const;');
    if (!exportMatch || start === -1 || end === -1 || end <= start)
        return null;
    try {
        const parsed = JSON.parse(content.slice(start + 2, end));
        return isRecord(parsed) ? { exportName: exportMatch[1], data: parsed } : null;
    }
    catch {
        return null;
    }
}
async function readJsonFile(fileInfo) {
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        return file ? JSON.parse(String(await file.getContent())) : null;
    }
    catch {
        return null;
    }
}
async function saveStorContent(fileInfo, source) {
    const key = mls.stor.getKeyToFile(fileInfo);
    let storFile = mls.stor.files[key];
    if (!storFile)
        storFile = await createStorFile({ ...fileInfo, source }, false, false, false);
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: source });
}
async function saveConstDefault(fileInfo, exportName, data) {
    const header = `/// <mls fileReference="${toDisplayRef(fileInfo)}" enhancement="_blank"/>\n\n`;
    await saveStorContent(fileInfo, `${header}export const ${exportName} = ${JSON.stringify(data, null, 2)} as const;\n\nexport default ${exportName};\n`);
}
function createBaseConfig(project) {
    return {
        defaultProjectId: String(project),
        shellTemplates: { spa: './_102033_/l2/shared/spa/index.html', pwa: './_102033_/l2/shared/pwa/index.html' },
        publication: { defaultTarget: 'web', targets: { web: { assetBaseUrl: '', serveStaticFromServer: true, minify: false, sourcemap: true } } },
        clientShell: { mode: 'spa', activeProfile: 'production', regions: { aside: { activeProfile: 'defaultAura', profiles: { defaultAura: { renderer: { entrypoint: '/_102033_/l2/shared/layout/aura-aside.js', source: '../mls-102033/l2/shared/layout/aura-aside.ts', tag: 'collab-aura-aside' }, widthPx: 280 } } } } },
        projects: { '102027': { root: '../mls-102027', type: 'lib' }, '102029': { root: '../mls-102029', type: 'lib' }, '102033': { root: '../mls-102033', type: 'master frontend' }, '102034': { root: '../mls-102034', type: 'master backend' }, [String(project)]: { root: '.', type: 'client', modules: [] } },
    };
}
function ensureModule(modules, moduleName) { const existing = modules.get(moduleName); if (existing)
    return existing; const created = { moduleName, entityIds: new Set() }; modules.set(moduleName, created); return created; }
function ensureRecord(parent, key) { if (!isRecord(parent[key]))
    parent[key] = {}; return parent[key]; }
function ensureArray(parent, key) { if (!Array.isArray(parent[key]))
    parent[key] = []; return parent[key]; }
function upsertByKey(items, key, value) { let item = items.find(candidate => candidate[key] === value); if (!item) {
    item = { [key]: value };
    items.push(item);
} return item; }
function toDisplayRef(fileInfo) { const folder = fileInfo.folder ? `${fileInfo.folder}/` : ''; return `_${fileInfo.project}_/l${fileInfo.level}/${folder}${fileInfo.shortName}${fileInfo.extension}`; }
function toFrontendType(type) { const normalized = type.toLowerCase(); if (['number', 'integer', 'decimal', 'money', 'float'].includes(normalized))
    return 'number'; if (['boolean', 'bool'].includes(normalized))
    return 'boolean'; if (['date', 'datetime', 'time'].includes(normalized))
    return 'date'; return 'string'; }
function isSystemField(fieldId) { return ['createdat', 'updatedat'].includes(fieldId.toLowerCase()); }
function isLikelyIdField(fieldId) { return fieldId.toLowerCase().endsWith('id'); }
function readString(value) { return typeof value === 'string' ? value.trim() : ''; }
function readStringArray(value) { return Array.isArray(value) ? value.map(readString).filter(Boolean) : []; }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function unique(values) { return Array.from(new Set(values.filter(Boolean))); }
function toSafeShortName(value) { return value.trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'page'; }
function toKebabCase(value) { return value.replace(/([a-z0-9])([A-Z])/g, '$1-$2').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase(); }
function toPascalCase(value) { return value.split(/[^a-zA-Z0-9]+|(?=[A-Z])/).filter(Boolean).map(part => part.charAt(0).toUpperCase() + part.slice(1)).join('') || 'Organism'; }
function humanizeId(id) { const spaced = id.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').trim(); return spaced ? spaced.charAt(0).toUpperCase() + spaced.slice(1) : id; }
