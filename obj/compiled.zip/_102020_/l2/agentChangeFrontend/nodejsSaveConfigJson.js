/// <mls fileReference="_102020_/l2/agentChangeFrontend/nodejsSaveConfigJson.ts" enhancement="_blank"/>
// Publish-time composer (frontend side). Runs on the dev machine via tsx, BEFORE rsync:
//   tsx mls-102020/l2/agentChangeFrontend/nodejsSaveConfigJson.ts <clientId>
// The screen list does NOT live in l5/project.json: this routine discovers the pages by
// itself — l4 workflows/operations are the functional source of truth (pageId + title),
// and a page is only registered when its l2 artifacts are materialized on disk
// (contracts/<page>.ts + shared/<page>.ts + desktop/pageNN/<page>.ts).
// The unsuffixed route uses page11 when that genome exists, otherwise the first remaining
// genome. Additional desktop/pageNN variants are extra suffixed routes.
// It merges the frontend part of the workspace ProjectsConfig into mls-<clientId>/l5/config.json:
// shellTemplates, publication, clientShell (l5 customize overrides win), projects
// (master frontend + libs) and modules[].frontend.pages / navigation.
// Multi-module: each l5/project.json module is composed from ITS own l2. A module whose l2 is
// missing is skipped and its existing config.json entry is kept (in-progress generation). That
// differs from the backend composer, which DROPS leftovers whose persistence dirs are gone —
// a dead tableDefsDir crashes publish migration; a missing frontend l2 does not. Neither writer
// may clobber the other's fields (backendControllers / persistenceModules stay untouched here).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { navigationFromE8Menu } from './helpers/cfeModuleNavigation.js';
// Relative path (not /_102029_/...) because this file runs standalone via tsx at publish:
// tsx resolves relative .ts, but does not swap .js→.ts for path-mapped (/_XXX_/) runtime imports.
import { emitMlsDepJson } from '../../../mls-102029/l2/mlsDepManifest.js';
const HERE = path.dirname(process.argv[1] ? path.resolve(process.argv[1]) : process.cwd());
const ROOT = process.env.SAVE_CONFIG_ROOT ? path.resolve(process.env.SAVE_CONFIG_ROOT) : path.resolve(HERE, '../../../');
function fail(msg) { console.error(`[nodejsSaveConfigJson:frontend] ${msg}`); process.exit(1); }
function warn(msg) { console.warn(`[nodejsSaveConfigJson:frontend] WARN ${msg}`); }
function readJson(file) {
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    }
    catch {
        return null;
    }
}
function projectRuntimeMetadata(l5, clientId) {
    return {
        projectId: l5.projectId || clientId,
        domain: l5.domain,
        port: l5.port,
        databaseName: l5.databaseName,
        environment: l5.environment,
        studioEnabled: l5.studioEnabled,
    };
}
function addL5Dependencies(config, l5, clientId) {
    for (const dep of l5.dependencies || []) {
        const id = String(dep?.projectId || '').trim();
        if (!/^\d+$/.test(id) || id === clientId)
            continue;
        config.projects[id] = config.projects[id] || { root: `../mls-${id}`, type: 'lib' };
    }
}
/** Object literal of a generated .defs.ts (`export const x = {...};` or `... as const;`). */
function readDefsData(file) {
    let content;
    try {
        content = fs.readFileSync(file, 'utf8');
    }
    catch {
        return null;
    }
    const start = content.indexOf('= {');
    if (start === -1)
        return null;
    // `} as const;` and `} as const satisfies <Artifact>;` (agentNewSolution) both end the value at
    // ' as const'; the brace fallback keeps untyped defs readable.
    const asConst = content.indexOf(' as const', start);
    const end = asConst !== -1 ? asConst : content.lastIndexOf('};') + 1;
    if (end <= start)
        return null;
    try {
        const parsed = JSON.parse(content.slice(start + 2, asConst !== -1 ? end : end + 1).trim().replace(/;$/, ''));
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
    }
    catch {
        return null;
    }
}
function readString(value) { return typeof value === 'string' ? value.trim() : ''; }
function readStringArray(value) { return Array.isArray(value) ? value.map(readString).filter(Boolean) : []; }
function toSafeShortName(value) { return value.trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'page'; }
function humanizeId(id) { const spaced = id.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').trim(); return spaced ? spaced.charAt(0).toUpperCase() + spaced.slice(1) : id; }
function toKebab(str) { return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase(); }
function languageKeys(values) {
    return [...new Set(values
            .map(value => value.trim().replace(/_/g, '-').toLowerCase().split('-')[0])
            .filter(value => /^[a-z]{2,3}$/.test(value)))];
}
function discoverModuleLanguages(clientRoot, moduleName, l5) {
    const defs = readDefsData(path.join(clientRoot, 'l4', moduleName, 'module.defs.ts'));
    const moduleData = defs?.module && typeof defs.module === 'object' && !Array.isArray(defs.module)
        ? defs.module
        : defs;
    const moduleLanguages = readStringArray(moduleData?.languages);
    const projectLanguages = (l5.languages || []).map(item => readString(item?.language));
    return languageKeys(moduleLanguages.length > 0 ? moduleLanguages : projectLanguages);
}
function discoverDesignSystemNames(clientRoot) {
    let source;
    try {
        source = fs.readFileSync(path.join(clientRoot, 'l2', 'designSystem.ts'), 'utf8');
    }
    catch {
        return [];
    }
    const names = [];
    const seen = new Set();
    const themeNamePattern = /\bthemeName\s*:\s*(["'`])([^"'`]+)\1/g;
    for (const match of source.matchAll(themeNamePattern)) {
        const name = match[2].trim();
        const key = name.toLowerCase();
        if (name && !seen.has(key)) {
            seen.add(key);
            names.push(name);
        }
    }
    return names;
}
/** Tag for a generated page component. Page .ts files register the custom element in the LEGACY full
 *  format `<folder-kebab>--<shortName>-<project>` (e.g. cafe-flow--web--desktop--page11--ws-cook-kitchen-102049),
 *  regardless of whether the shortName contains hyphens. The previous "new format" special-case for
 *  hyphenated shortNames produced a truncated tag (page11--ws-cook-kitchen) that did not match the
 *  @customElement in the .ts, so the page rendered blank. Always use the legacy full format here. */
function convertFileToTag(info) {
    const kebabName = toKebab(info.shortName);
    const folderPrefix = info.folder ? `${toKebab(info.folder).replace(/\//g, '--')}--` : '';
    return `${folderPrefix}${kebabName}-${info.project}`;
}
/** Pages from l4. Primary grouping is the journey WORKSPACES (one page per workspace, matching
 *  agentChangeFrontend buildPagePlans); owners not covered by any workspace fall back to a per-owner
 *  page. When there is no journey, uses the legacy per-workflow/per-operation grouping. */
function discoverPages(clientRoot, moduleName) {
    // Tolerant readers (l4 v2): each owner type lives either in the legacy flat l4/<folder>/ or the
    // module-scoped l4/<module>/<folder>/. Read both and merge.
    const listDefsIn = (dir) => {
        if (!fs.existsSync(dir))
            return [];
        return fs.readdirSync(dir)
            .filter(name => name.endsWith('.defs.ts'))
            .map(name => readDefsData(path.join(dir, name)))
            .filter((data) => !!data);
    };
    const listDefs = (folder) => [
        ...listDefsIn(path.join(clientRoot, 'l4', folder)),
        ...listDefsIn(path.join(clientRoot, 'l4', moduleName, folder)),
    ];
    // Actors catalog + landings (l4/<module>/actors.defs.ts, or the ns4 access matrix, + siteMap).
    const actorCatalog = (readDefsData(path.join(clientRoot, 'l4', moduleName, 'actors.defs.ts'))?.actors || [])
        .map(actor => readString(actor?.actorId));
    const profileCatalog = (readDefsData(path.join(clientRoot, 'l4', moduleName, 'access', 'access-matrix.defs.ts'))?.profiles || [])
        .map(profile => readString(profile?.profileId));
    const validActors = new Set([...actorCatalog, ...profileCatalog].filter(Boolean));
    const siteMapData = readDefsData(path.join(clientRoot, 'l4', moduleName, 'siteMap.defs.ts'))
        || readDefsData(path.join(clientRoot, 'l4', moduleName, 'navigation.defs.ts'));
    const landingWorkspaceIds = new Set((siteMapData && Array.isArray(siteMapData.landings) ? siteMapData.landings : [])
        .map(landing => toSafeShortName(readString(landing?.workspaceId))).filter(Boolean));
    // Workspaces: standalone l4/<module>/workspaces/*.defs.ts (v2) OR nested in journeys/*.defs.ts (legacy).
    const workspaces = [];
    const addWorkspace = (ws) => {
        const wsId = readString(ws.workspaceId);
        if (!wsId)
            return;
        const actors = readStringArray(ws.actors).length ? readStringArray(ws.actors) : (readString(ws.actor) ? [readString(ws.actor)] : []);
        const bffUses = Array.isArray(ws.bffCalls)
            ? ws.bffCalls.flatMap(call => Array.isArray(call?.uses) ? call.uses.map(use => readString(use?.operationId)) : [])
            : [];
        const pageId = toSafeShortName(wsId);
        workspaces.push({
            pageId,
            label: readString(ws.title) || humanizeId(wsId),
            ops: new Set([...readStringArray(ws.operationIds), ...bffUses].filter(Boolean)),
            wf: readString(ws.workflowId),
            actors: actors.filter(actor => validActors.size === 0 || validActors.has(actor)),
            landing: readString(ws.kind) === 'landing' || landingWorkspaceIds.has(pageId),
        });
    };
    const workspacesDir = path.join(clientRoot, 'l4', moduleName, 'workspaces');
    if (fs.existsSync(workspacesDir)) {
        for (const name of fs.readdirSync(workspacesDir).filter(n => n.endsWith('.defs.ts'))) {
            const data = readDefsData(path.join(workspacesDir, name));
            if (data)
                addWorkspace(data);
        }
    }
    const journeyDir = path.join(clientRoot, 'l4', moduleName, 'journeys');
    if (workspaces.length === 0 && fs.existsSync(journeyDir)) {
        for (const name of fs.readdirSync(journeyDir).filter(n => n.endsWith('.defs.ts'))) {
            const data = readDefsData(path.join(journeyDir, name));
            const list = data && Array.isArray(data.workspaces) ? data.workspaces : [];
            for (const ws of list)
                if (ws && typeof ws === 'object')
                    addWorkspace(ws);
        }
    }
    const workflows = listDefs('workflows');
    const operations = listDefs('operations');
    const operationsById = new Map(operations.map(operation => [readString(operation.operationId), operation]));
    const routeParamsFor = (operationIds) => [...new Set(operationIds.flatMap(operationId => {
            const operation = operationsById.get(operationId);
            const inputs = operation && Array.isArray(operation.inputs) ? operation.inputs : [];
            return inputs
                .filter(input => readString(input?.source) === 'routeParam')
                .map(input => readString(input?.inputId))
                .filter(Boolean);
        }))];
    const actorsForOps = (operationIds) => [...new Set(operationIds
            .map(operationId => readString(operationsById.get(operationId)?.actor))
            .filter(actor => actor && (validActors.size === 0 || validActors.has(actor))))];
    const page = (pageId, label, operationIds, actors, landing = false) => ({ pageId, label, routeParams: routeParamsFor(operationIds), actors: actors.length ? actors : actorsForOps(operationIds), landing });
    const pages = [];
    const operationIdsUsedByWorkflow = new Set();
    for (const workflow of workflows)
        for (const opId of readStringArray(workflow.operationIds))
            operationIdsUsedByWorkflow.add(opId);
    if (workspaces.length > 0) {
        const coveredOps = new Set();
        const coveredWf = new Set();
        for (const ws of workspaces) {
            pages.push(page(ws.pageId, ws.label, [...ws.ops], ws.actors, ws.landing));
            ws.ops.forEach(o => coveredOps.add(o));
            if (ws.wf)
                coveredWf.add(ws.wf);
        }
        // Leftover owners not covered by any workspace keep a legacy per-owner page.
        for (const workflow of workflows) {
            const workflowId = readString(workflow.workflowId);
            if (!workflowId || coveredWf.has(workflowId))
                continue;
            pages.push(page(toSafeShortName(readString(workflow.pageId) || workflowId), readString(workflow.title) || humanizeId(workflowId), readStringArray(workflow.operationIds), readStringArray(workflow.actors)));
        }
        for (const operation of operations) {
            const operationId = readString(operation.operationId);
            if (!operationId || operationIdsUsedByWorkflow.has(operationId) || coveredOps.has(operationId))
                continue;
            pages.push(page(toSafeShortName(readString(operation.pageId) || operationId), readString(operation.title) || humanizeId(operationId), [operationId], []));
        }
    }
    else {
        for (const workflow of workflows) {
            const workflowId = readString(workflow.workflowId);
            if (!workflowId)
                continue;
            pages.push(page(toSafeShortName(readString(workflow.pageId) || workflowId), readString(workflow.title) || humanizeId(workflowId), readStringArray(workflow.operationIds), readStringArray(workflow.actors)));
        }
        for (const operation of operations) {
            const operationId = readString(operation.operationId);
            if (!operationId || operationIdsUsedByWorkflow.has(operationId))
                continue;
            pages.push(page(toSafeShortName(readString(operation.pageId) || operationId), readString(operation.title) || humanizeId(operationId), [operationId], []));
        }
    }
    const seen = new Set();
    return pages.filter(page => seen.has(page.pageId) ? false : (seen.add(page.pageId), true))
        .sort((a, b) => a.pageId.localeCompare(b.pageId));
}
function pageRoute(moduleName, pageId, routeParams) {
    return routeParams.reduce((route, param) => `${route}/:${param}?`, `/${moduleName}/${pageId}`);
}
function desktopGenomesWithTs(clientRoot, moduleName, pageId) {
    const desktopDir = path.join(clientRoot, 'l2', moduleName, 'web', 'desktop');
    if (!fs.existsSync(desktopDir))
        return [];
    return fs.readdirSync(desktopDir)
        .filter(name => /^page\d+$/.test(name))
        .filter(layout => fs.existsSync(path.join(desktopDir, layout, `${pageId}.ts`)))
        .sort((a, b) => a.localeCompare(b));
}
function primaryPageGenome(genomes) {
    return genomes.includes('page11') ? 'page11' : (genomes[0] || 'page11');
}
function isMaterialized(clientRoot, moduleName, pageId) {
    const web = path.join(clientRoot, 'l2', moduleName, 'web');
    const sharedOk = fs.existsSync(path.join(web, 'shared', `${pageId}.ts`));
    const pageOk = desktopGenomesWithTs(clientRoot, moduleName, pageId).length > 0;
    // Contracts: legacy is one per-page `<pageId>.ts`; l4 v2 (F3) is one per bffCall `<pageId>.<bffId>.ts`.
    // Accept either — a page is materialized when its shared + a page genome exist and at least one contract does.
    const contractsDir = path.join(web, 'contracts');
    const contractOk = fs.existsSync(path.join(contractsDir, `${pageId}.ts`))
        || (fs.existsSync(contractsDir) && fs.readdirSync(contractsDir).some(name => name.startsWith(`${pageId}.`) && name.endsWith('.ts') && !name.endsWith('.d.ts') && !name.endsWith('.defs.ts') && !name.endsWith('.test.ts')));
    return sharedOk && pageOk && contractOk;
}
function discoverPageVariants(clientRoot, clientId, moduleName, page, primaryGenome) {
    const desktopDir = path.join(clientRoot, 'l2', moduleName, 'web', 'desktop');
    if (!fs.existsSync(desktopDir))
        return [];
    const layouts = fs.readdirSync(desktopDir)
        .filter(name => /^page\d+$/.test(name) && name !== primaryGenome)
        .sort((a, b) => a.localeCompare(b));
    const variants = [];
    const usedRoutePageIds = new Set();
    for (const layout of layouts) {
        const tsPath = path.join(desktopDir, layout, `${page.pageId}.ts`);
        const defsPath = path.join(desktopDir, layout, `${page.pageId}.defs.ts`);
        if (!fs.existsSync(tsPath) || !fs.existsSync(defsPath))
            continue;
        const defs = readDefsData(defsPath);
        const variantId = toSafeShortName(readString(defs?.variantId) || layout);
        let routePageId = `${page.pageId}-${variantId}`;
        if (usedRoutePageIds.has(routePageId))
            routePageId = `${routePageId}-${layout}`;
        usedRoutePageIds.add(routePageId);
        variants.push({
            variantId,
            layout,
            routePageId,
            route: pageRoute(moduleName, routePageId, page.routeParams),
            source: `l2/${moduleName}/web/desktop/${layout}/${page.pageId}.ts`,
            definition: `l2/${moduleName}/web/desktop/${layout}/${page.pageId}.defs.ts`,
            componentTag: convertFileToTag({ project: Number(clientId), folder: `${moduleName}/web/desktop/${layout}`, shortName: page.pageId }),
            title: `${page.label} - ${variantId.toUpperCase()}`,
        });
    }
    return variants;
}
export class FrontendConfigComposeError extends Error {
    constructor(message) {
        super(message);
        this.name = 'FrontendConfigComposeError';
    }
}
function tryComposeModuleFrontend(clientRoot, clientId, moduleName, l5, designSystems) {
    const discovered = discoverPages(clientRoot, moduleName);
    if (discovered.length === 0)
        return { ok: false, reason: 'no pages discovered from l4 workflows/operations' };
    const pages = discovered.filter(page => {
        if (isMaterialized(clientRoot, moduleName, page.pageId))
            return true;
        warn(`module '${moduleName}' page '${page.pageId}' skipped: l2 artifacts not materialized (contracts/shared/pageNN)`);
        return false;
    });
    if (pages.length === 0)
        return { ok: false, reason: 'no discovered page is materialized in l2' };
    const labels = (l5.customize || {}).navigationLabels || {};
    const languages = discoverModuleLanguages(clientRoot, moduleName, l5);
    // Ownership of `modules[].navigation`: THIS agent. agentNewSolution seeds a menu at e10 from
    // model.menu (places only). That preview can point at pages that do not exist yet, so the menu
    // here is rebuilt as E8 model.menu ∩ pages that materialized — order from E8, existence from CF.
    // A materialized page that is not in model.menu stays routable and is not listed.
    const e8Model = readDefsData(path.join(clientRoot, 'l4', moduleName, 'workspace-model.defs.ts'));
    const e8Menu = (Array.isArray(e8Model?.menu) ? e8Model.menu : [])
        .map(entry => ({ workspaceId: toSafeShortName(readString(entry?.workspaceId)), label: readString(entry?.label) }))
        .filter(entry => entry.workspaceId);
    const navigation = navigationFromE8Menu({
        moduleName,
        menu: e8Menu,
        pages: pages.map(page => ({
            pageId: page.pageId, label: page.label, actors: page.actors, landing: page.landing,
        })),
        labels,
    });
    const pageIds = new Set(pages.map(page => page.pageId));
    const siteMapForLandings = readDefsData(path.join(clientRoot, 'l4', moduleName, 'siteMap.defs.ts'))
        || readDefsData(path.join(clientRoot, 'l4', moduleName, 'navigation.defs.ts'));
    const landings = ((siteMapForLandings && Array.isArray(siteMapForLandings.landings) ? siteMapForLandings.landings : [])
        .map(landing => ({ actorId: readString(landing?.actorId), pageId: toSafeShortName(readString(landing?.workspaceId)) }))
        .filter(landing => landing.actorId && pageIds.has(landing.pageId))
        .map(landing => ({ actorId: landing.actorId, pageId: landing.pageId, route: `/${moduleName}/${landing.pageId}` })));
    const variantPages = pages.flatMap(page => {
        const primary = primaryPageGenome(desktopGenomesWithTs(clientRoot, moduleName, page.pageId));
        return discoverPageVariants(clientRoot, clientId, moduleName, page, primary);
    });
    const pageTests = pages.flatMap(page => {
        const genomes = desktopGenomesWithTs(clientRoot, moduleName, page.pageId);
        const withTests = ['page11', ...genomes].filter((genome, index, list) => list.indexOf(genome) === index)
            .filter(genome => fs.existsSync(path.join(clientRoot, 'l2', moduleName, 'web', 'desktop', genome, `${page.pageId}.test.ts`)));
        const genome = withTests[0];
        return genome ? [`_${clientId}_/l2/${moduleName}/web/desktop/${genome}/${page.pageId}.test.js`] : [];
    });
    const frontend = {
        layer: 'l2',
        ...(pageTests.length > 0 ? { pageTests } : {}),
        pages: [
            ...pages.map((page) => {
                const primary = primaryPageGenome(desktopGenomesWithTs(clientRoot, moduleName, page.pageId));
                return {
                    pageId: page.pageId,
                    route: pageRoute(moduleName, page.pageId, page.routeParams),
                    source: `l2/${moduleName}/web/desktop/${primary}/${page.pageId}.ts`,
                    definition: `l2/${moduleName}/web/desktop/${primary}/${page.pageId}.defs.ts`,
                    componentTag: convertFileToTag({ project: Number(clientId), folder: `${moduleName}/web/desktop/${primary}`, shortName: page.pageId }),
                    title: labels[page.pageId] || page.label,
                    ...(page.actors.length ? { actors: page.actors } : {}),
                    ...(page.landing ? { public: true } : {}),
                };
            }),
            ...variantPages.map((page) => ({
                pageId: page.routePageId,
                route: page.route,
                source: page.source,
                definition: page.definition,
                componentTag: page.componentTag,
                title: page.title,
            })),
        ],
    };
    return {
        ok: true,
        pageCount: pages.length,
        apply: (mod) => {
            mod.basePath = mod.basePath || `/${moduleName}`;
            mod.shellMode = mod.shellMode || 'spa';
            mod.languages = languages;
            mod.designSystems = [...designSystems];
            mod.navigation = navigation;
            if (landings.length > 0)
                mod.landings = landings;
            mod.frontend = frontend;
        },
    };
}
export function composeFrontendRuntimeConfig(root, clientId) {
    if (!/^\d+$/.test(clientId))
        throw new FrontendConfigComposeError('usage: tsx nodejsSaveConfigJson.ts <clientId>');
    const clientRoot = path.join(root, `mls-${clientId}`);
    const runtimeL5Path = path.join(clientRoot, 'l5', 'runtime.project.json');
    const l5Path = fs.existsSync(runtimeL5Path) ? runtimeL5Path : path.join(clientRoot, 'l5', 'project.json');
    const l5 = readJson(l5Path);
    if (!l5)
        throw new FrontendConfigComposeError(`cannot read ${l5Path}`);
    const signature = l5.masters?.frontend;
    if (!signature)
        throw new FrontendConfigComposeError('l5/project.json has no masters.frontend signature (run agentChangeFrontend or add it)');
    const runtimeId = String(signature.runtimeProject);
    const moduleNames = (l5.modules || []).map(m => m.moduleName).filter(Boolean);
    const designSystems = discoverDesignSystemNames(clientRoot);
    const customize = l5.customize || {};
    const configPath = path.join(clientRoot, 'l5', 'config.json');
    const config = (readJson(configPath) || {});
    config.defaultProjectId = config.defaultProjectId || clientId;
    config.shellTemplates = customize.shellTemplates
        || { spa: `./_${runtimeId}_/l2/shared/spa/index.html`, pwa: `./_${runtimeId}_/l2/shared/pwa/index.html` };
    config.publication = customize.publication
        || config.publication
        || { defaultTarget: 'web', targets: { web: { assetBaseUrl: '', serveStaticFromServer: true, minify: false, sourcemap: true } } };
    config.clientShell = customize.clientShell
        || config.clientShell
        || {
            mode: 'spa',
            activeProfile: 'production',
            regions: {
                aside: {
                    activeProfile: 'defaultAura',
                    profiles: {
                        defaultAura: {
                            renderer: { entrypoint: `/_${runtimeId}_/l2/shared/layout/aura-aside.js`, source: `../mls-${runtimeId}/l2/shared/layout/aura-aside.ts`, tag: 'collab-aura-aside' },
                            widthPx: 280,
                        },
                    },
                },
            },
        };
    config.projects = config.projects || {};
    config.projects[clientId] = { ...(config.projects[clientId] || {}), root: '.', type: 'client', runtime: projectRuntimeMetadata(l5, clientId) };
    config.projects[runtimeId] = { root: `../mls-${runtimeId}`, type: 'master frontend' };
    const backendRuntimeId = l5.masters?.backend?.runtimeProject ? String(l5.masters.backend.runtimeProject) : '';
    if (backendRuntimeId) {
        config.projects[backendRuntimeId] = config.projects[backendRuntimeId] || { root: `../mls-${backendRuntimeId}`, type: 'master backend' };
    }
    delete config.projects['102027'];
    delete config.projects['102036'];
    config.projects['102029'] = config.projects['102029'] || { root: '../mls-102029', type: 'lib' };
    addL5Dependencies(config, l5, clientId);
    const client = config.projects[clientId];
    client.modules = client.modules || [];
    const composed = [];
    const skipped = [];
    for (const moduleName of moduleNames) {
        try {
            const result = tryComposeModuleFrontend(clientRoot, clientId, moduleName, l5, designSystems);
            if (!result.ok) {
                warn(`module '${moduleName}' skipped: ${result.reason}`);
                skipped.push({ moduleName, reason: result.reason });
                continue;
            }
            let mod = client.modules.find(m => m.moduleId === moduleName);
            if (!mod) {
                mod = { moduleId: moduleName, basePath: `/${moduleName}`, shellMode: 'spa' };
                client.modules.push(mod);
            }
            result.apply(mod);
            composed.push({ moduleName, pageCount: result.pageCount });
        }
        catch (error) {
            const reason = error instanceof Error ? error.message : String(error);
            warn(`module '${moduleName}' skipped: ${reason}`);
            skipped.push({ moduleName, reason });
        }
    }
    if (composed.length === 0) {
        throw new FrontendConfigComposeError(`no module could be composed from l2 (declared ${moduleNames.length}, skipped ${skipped.length}); project looks broken`);
    }
    fs.writeFileSync(configPath, `${JSON.stringify(config, null, 2)}\n`);
    emitMlsDepJson(path.join(clientRoot, 'mlsDep.json'), config, l5, {
        read: (file) => fs.readFileSync(file, 'utf8'),
        write: (file, source) => fs.writeFileSync(file, source),
    });
    const pageNote = composed.map(item => `${item.moduleName}: ${item.pageCount} page(s)`).join(', ');
    console.log(`[nodejsSaveRuntimeConfig:frontend] composed ${composed.length} module(s) (${pageNote}) → ${configPath}`);
    return { configPath, composed, skipped };
}
function main() {
    const clientId = (process.argv[2] || '').replace(/^mls-/, '');
    try {
        composeFrontendRuntimeConfig(ROOT, clientId);
    }
    catch (error) {
        fail(error instanceof Error ? error.message : String(error));
    }
}
const entry = process.argv[1] ? path.resolve(process.argv[1]) : '';
if (entry && entry === path.resolve(fileURLToPath(import.meta.url)))
    main();
