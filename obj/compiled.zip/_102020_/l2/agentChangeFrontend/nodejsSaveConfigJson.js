/// <mls fileReference="_102020_/l2/agentChangeFrontend/nodejsSaveConfigJson.ts" enhancement="_blank"/>
// Publish-time composer (frontend side). Runs on the dev machine via tsx, BEFORE rsync:
//   tsx mls-102020/l2/agentChangeFrontend/nodejsSaveConfigJson.ts <clientId>
// The screen list does NOT live in l5/project.json: this routine discovers the pages by
// itself — l4 workflows/operations are the functional source of truth (pageId + title),
// and a page is only registered when its l2 artifacts are materialized on disk
// (contracts/<page>.ts + shared/<page>.ts + desktop/page11/<page>.ts).
// Additional desktop/pageNN variants are registered as extra routes when materialized.
// It merges the frontend part of the workspace ProjectsConfig into mls-<clientId>/config.json:
// shellTemplates, publication, clientShell (l5 customize overrides win), projects
// (master frontend + libs) and modules[].frontend.pages / navigation.
import fs from 'node:fs';
import path from 'node:path';
const HERE = path.dirname(process.argv[1] ? path.resolve(process.argv[1]) : process.cwd());
const ROOT = process.env.SAVE_CONFIG_ROOT ? path.resolve(process.env.SAVE_CONFIG_ROOT) : path.resolve(HERE, '../../../');
function fail(msg) { console.error(`[nodejsSaveConfigJson:frontend] ${msg}`); process.exit(1); }
function warn(msg) { console.warn(`[nodejsSaveConfigJson:frontend] WARN ${msg}`); }
function readJson(file) {
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    }
    catch {
        return null;
    }
}
function projectRuntimeMetadata(l5, clientId) {
    return {
        projectId: l5.projectId || clientId,
        domain: l5.domain,
        port: l5.port,
        databaseName: l5.databaseName,
        environment: l5.environment,
        studioEnabled: l5.studioEnabled,
    };
}
function addL5Dependencies(config, l5, clientId) {
    for (const dep of l5.dependencies || []) {
        const id = String(dep?.projectId || '').trim();
        if (!/^\d+$/.test(id) || id === clientId)
            continue;
        config.projects[id] = config.projects[id] || { root: `../mls-${id}`, type: 'lib' };
    }
}
/** Object literal of a generated .defs.ts (`export const x = {...};` or `... as const;`). */
function readDefsData(file) {
    let content;
    try {
        content = fs.readFileSync(file, 'utf8');
    }
    catch {
        return null;
    }
    const start = content.indexOf('= {');
    if (start === -1)
        return null;
    const asConst = content.lastIndexOf(' as const;');
    const end = asConst !== -1 ? asConst : content.lastIndexOf('};') + 1;
    if (end <= start)
        return null;
    try {
        const parsed = JSON.parse(content.slice(start + 2, asConst !== -1 ? end : end + 1).trim().replace(/;$/, ''));
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
    }
    catch {
        return null;
    }
}
function readString(value) { return typeof value === 'string' ? value.trim() : ''; }
function readStringArray(value) { return Array.isArray(value) ? value.map(readString).filter(Boolean) : []; }
function toSafeShortName(value) { return value.trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'page'; }
function humanizeId(id) { const spaced = id.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').trim(); return spaced ? spaced.charAt(0).toUpperCase() + spaced.slice(1) : id; }
function toKebab(str) { return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase(); }
/** Tag for a generated page component. Page .ts files register the custom element in the LEGACY full
 *  format `<folder-kebab>--<shortName>-<project>` (e.g. cafe-flow--web--desktop--page11--ws-cook-kitchen-102049),
 *  regardless of whether the shortName contains hyphens. The previous "new format" special-case for
 *  hyphenated shortNames produced a truncated tag (page11--ws-cook-kitchen) that did not match the
 *  @customElement in the .ts, so the page rendered blank. Always use the legacy full format here. */
function convertFileToTag(info) {
    const kebabName = toKebab(info.shortName);
    const folderPrefix = info.folder ? `${toKebab(info.folder).replace(/\//g, '--')}--` : '';
    return `${folderPrefix}${kebabName}-${info.project}`;
}
/** Pages from l4. Primary grouping is the journey WORKSPACES (one page per workspace, matching
 *  agentChangeFrontend buildPagePlans); owners not covered by any workspace fall back to a per-owner
 *  page. When there is no journey, uses the legacy per-workflow/per-operation grouping. */
function discoverPages(clientRoot, moduleName) {
    const listDefs = (folder) => {
        const dir = path.join(clientRoot, 'l4', folder);
        if (!fs.existsSync(dir))
            return [];
        return fs.readdirSync(dir)
            .filter(name => name.endsWith('.defs.ts'))
            .map(name => readDefsData(path.join(dir, name)))
            .filter((data) => !!data);
    };
    // Journey workspaces (l4/{module}/journeys/*.defs.ts).
    const workspaces = [];
    const journeyDir = path.join(clientRoot, 'l4', moduleName, 'journeys');
    if (fs.existsSync(journeyDir)) {
        for (const name of fs.readdirSync(journeyDir).filter(n => n.endsWith('.defs.ts'))) {
            const data = readDefsData(path.join(journeyDir, name));
            const list = data && Array.isArray(data.workspaces) ? data.workspaces : [];
            for (const ws of list) {
                if (!ws || typeof ws !== 'object')
                    continue;
                const wsId = readString(ws.workspaceId);
                if (!wsId)
                    continue;
                workspaces.push({
                    pageId: toSafeShortName(wsId),
                    label: readString(ws.title) || humanizeId(wsId),
                    ops: new Set(readStringArray(ws.operationIds)),
                    wf: readString(ws.workflowId),
                });
            }
        }
    }
    const workflows = listDefs('workflows');
    const operations = listDefs('operations');
    const pages = [];
    const operationIdsUsedByWorkflow = new Set();
    for (const workflow of workflows)
        for (const opId of readStringArray(workflow.operationIds))
            operationIdsUsedByWorkflow.add(opId);
    if (workspaces.length > 0) {
        const coveredOps = new Set();
        const coveredWf = new Set();
        for (const ws of workspaces) {
            pages.push({ pageId: ws.pageId, label: ws.label });
            ws.ops.forEach(o => coveredOps.add(o));
            if (ws.wf)
                coveredWf.add(ws.wf);
        }
        // Leftover owners not covered by any workspace keep a legacy per-owner page.
        for (const workflow of workflows) {
            const workflowId = readString(workflow.workflowId);
            if (!workflowId || coveredWf.has(workflowId))
                continue;
            pages.push({ pageId: toSafeShortName(readString(workflow.pageId) || workflowId), label: readString(workflow.title) || humanizeId(workflowId) });
        }
        for (const operation of operations) {
            const operationId = readString(operation.operationId);
            if (!operationId || operationIdsUsedByWorkflow.has(operationId) || coveredOps.has(operationId))
                continue;
            pages.push({ pageId: toSafeShortName(readString(operation.pageId) || operationId), label: readString(operation.title) || humanizeId(operationId) });
        }
    }
    else {
        for (const workflow of workflows) {
            const workflowId = readString(workflow.workflowId);
            if (!workflowId)
                continue;
            pages.push({ pageId: toSafeShortName(readString(workflow.pageId) || workflowId), label: readString(workflow.title) || humanizeId(workflowId) });
        }
        for (const operation of operations) {
            const operationId = readString(operation.operationId);
            if (!operationId || operationIdsUsedByWorkflow.has(operationId))
                continue;
            pages.push({ pageId: toSafeShortName(readString(operation.pageId) || operationId), label: readString(operation.title) || humanizeId(operationId) });
        }
    }
    const seen = new Set();
    return pages.filter(page => seen.has(page.pageId) ? false : (seen.add(page.pageId), true))
        .sort((a, b) => a.pageId.localeCompare(b.pageId));
}
function isMaterialized(clientRoot, moduleName, pageId) {
    const web = path.join(clientRoot, 'l2', moduleName, 'web');
    return ['contracts', 'shared', 'desktop/page11']
        .every(part => fs.existsSync(path.join(web, part, `${pageId}.ts`)));
}
function discoverPageVariants(clientRoot, clientId, moduleName, page) {
    const desktopDir = path.join(clientRoot, 'l2', moduleName, 'web', 'desktop');
    if (!fs.existsSync(desktopDir))
        return [];
    const layouts = fs.readdirSync(desktopDir)
        .filter(name => /^page\d+$/.test(name) && name !== 'page11')
        .sort((a, b) => a.localeCompare(b));
    const variants = [];
    const usedRoutePageIds = new Set();
    for (const layout of layouts) {
        const tsPath = path.join(desktopDir, layout, `${page.pageId}.ts`);
        const defsPath = path.join(desktopDir, layout, `${page.pageId}.defs.ts`);
        if (!fs.existsSync(tsPath) || !fs.existsSync(defsPath))
            continue;
        const defs = readDefsData(defsPath);
        const variantId = toSafeShortName(readString(defs?.variantId) || layout);
        let routePageId = `${page.pageId}-${variantId}`;
        if (usedRoutePageIds.has(routePageId))
            routePageId = `${routePageId}-${layout}`;
        usedRoutePageIds.add(routePageId);
        variants.push({
            variantId,
            layout,
            routePageId,
            route: `/${moduleName}/${routePageId}`,
            source: `l2/${moduleName}/web/desktop/${layout}/${page.pageId}.ts`,
            definition: `l2/${moduleName}/web/desktop/${layout}/${page.pageId}.defs.ts`,
            componentTag: convertFileToTag({ project: Number(clientId), folder: `${moduleName}/web/desktop/${layout}`, shortName: page.pageId }),
            title: `${page.label} - ${variantId.toUpperCase()}`,
        });
    }
    return variants;
}
function main() {
    const clientId = (process.argv[2] || '').replace(/^mls-/, '');
    if (!/^\d+$/.test(clientId))
        fail('usage: tsx nodejsSaveConfigJson.ts <clientId>');
    const clientRoot = path.join(ROOT, `mls-${clientId}`);
    const l5 = readJson(path.join(clientRoot, 'l5', 'project.json'));
    if (!l5)
        fail(`cannot read ${path.join(clientRoot, 'l5', 'project.json')}`);
    const signature = l5.masters?.frontend;
    if (!signature)
        fail('l5/project.json has no masters.frontend signature (run agentChangeFrontend or add it)');
    const runtimeId = String(signature.runtimeProject);
    // Module resolution: from the l5 modules; multi-module needs the l4->module inference and
    // is out of scope until a real multi-module client exists.
    const moduleNames = (l5.modules || []).map(m => m.moduleName).filter(Boolean);
    if (moduleNames.length !== 1)
        fail(`expected exactly 1 module in l5/project.json, found ${moduleNames.length}`);
    const moduleName = moduleNames[0];
    const discovered = discoverPages(clientRoot, moduleName);
    if (discovered.length === 0)
        fail('no pages discovered from l4 workflows/operations');
    const pages = discovered.filter(page => {
        if (isMaterialized(clientRoot, moduleName, page.pageId))
            return true;
        warn(`page '${page.pageId}' skipped: l2 artifacts not materialized (contracts/shared/page11)`);
        return false;
    });
    if (pages.length === 0)
        fail('no discovered page is materialized in l2; run the materialization first');
    const customize = l5.customize || {};
    const configPath = path.join(clientRoot, 'config.json');
    const config = (readJson(configPath) || {});
    config.defaultProjectId = config.defaultProjectId || clientId;
    config.shellTemplates = customize.shellTemplates
        || { spa: `./_${runtimeId}_/l2/shared/spa/index.html`, pwa: `./_${runtimeId}_/l2/shared/pwa/index.html` };
    config.publication = customize.publication
        || config.publication
        || { defaultTarget: 'web', targets: { web: { assetBaseUrl: '', serveStaticFromServer: true, minify: false, sourcemap: true } } };
    config.clientShell = customize.clientShell
        || config.clientShell
        || {
            mode: 'spa',
            activeProfile: 'production',
            regions: {
                aside: {
                    activeProfile: 'defaultAura',
                    profiles: {
                        defaultAura: {
                            renderer: { entrypoint: `/_${runtimeId}_/l2/shared/layout/aura-aside.js`, source: `../mls-${runtimeId}/l2/shared/layout/aura-aside.ts`, tag: 'collab-aura-aside' },
                            widthPx: 280,
                        },
                    },
                },
            },
        };
    config.projects = config.projects || {};
    config.projects[clientId] = { ...(config.projects[clientId] || {}), root: '.', type: 'client', runtime: projectRuntimeMetadata(l5, clientId) };
    config.projects[runtimeId] = { root: `../mls-${runtimeId}`, type: 'master frontend' };
    // Frontend shared libs used by the generated l2 code and by the master frontend.
    config.projects['102027'] = config.projects['102027'] || { root: '../mls-102027', type: 'lib' };
    config.projects['102029'] = config.projects['102029'] || { root: '../mls-102029', type: 'lib' };
    addL5Dependencies(config, l5, clientId);
    const client = config.projects[clientId];
    client.modules = client.modules || [];
    let mod = client.modules.find(m => m.moduleId === moduleName);
    if (!mod) {
        mod = { moduleId: moduleName, basePath: `/${moduleName}`, shellMode: 'spa' };
        client.modules.push(mod);
    }
    mod.basePath = mod.basePath || `/${moduleName}`;
    mod.shellMode = mod.shellMode || 'spa';
    const labels = customize.navigationLabels || {};
    mod.navigation = pages.map((page) => ({
        id: page.pageId,
        label: labels[page.pageId] || page.label,
        href: `/${moduleName}/${page.pageId}`,
        description: labels[page.pageId] || page.label,
    }));
    const variantPages = pages.flatMap(page => discoverPageVariants(clientRoot, clientId, moduleName, page));
    mod.frontend = {
        layer: 'l2',
        pages: [
            ...pages.map((page) => ({
                pageId: page.pageId,
                route: `/${moduleName}/${page.pageId}`,
                source: `l2/${moduleName}/web/desktop/page11/${page.pageId}.ts`,
                definition: `l2/${moduleName}/web/desktop/page11/${page.pageId}.defs.ts`,
                componentTag: convertFileToTag({ project: Number(clientId), folder: `${moduleName}/web/desktop/page11`, shortName: page.pageId }),
                title: labels[page.pageId] || page.label,
            })),
            ...variantPages.map((page) => ({
                pageId: page.routePageId,
                route: page.route,
                source: page.source,
                definition: page.definition,
                componentTag: page.componentTag,
                title: page.title,
            })),
        ],
    };
    fs.writeFileSync(configPath, `${JSON.stringify(config, null, 2)}\n`);
    console.log(`[nodejsSaveConfigJson:frontend] composed ${pages.length} page(s) for module '${moduleName}' into ${configPath}`);
}
main();
