/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentCfeMaterializeGen.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { applyHeader, buildMaterializeTypecheckTest, buildHumanPrompt, buildSystemPrompt, DEFAULT_MODEL_TYPE, expandContextRef, GEN_TOOL, GEN_TOOL_NAME, parseDefs, testPathForOutputPath, } from '/_102020_/l2/agentChangeFrontend/cfeMaterializeCore.js';
import { compileAndGetErrors, compileMlsPathAndGetErrors, consumeMaterializeStudioMessages, extractToolCallArgs, getContentByMlsPath, parseMlsPath, saveGeneratedTs, saveGeneratedTsByMlsPath, } from '/_102020_/l2/agentChangeFrontend/cfeMaterializeStudio.js';
const AGENT_NAME = 'agentCfeMaterializeGen';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend',
        agentDescription: 'Generate one frontend L2 .ts file from an agentChangeFrontend .defs.ts pipeline item',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        if (!args)
            throw new Error('missing args');
        const genArgs = parseGenStepArgs(args);
        const genContext = await buildGenContext(genArgs.defPath);
        return [createPromptReadyIntent(context, parentStep, hookSequential, genArgs, genContext)];
    }
    catch (error) {
        const message = formatError('beforePromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkFailureStatus(context, parentStep, step, hookSequential, isRepairRun(args || step.prompt), message)];
    }
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        consumeMaterializeStudioMessages();
        const genArgs = parseGenStepArgs(step.prompt);
        // attempt >= 2 marks a REPAIR run (normal step added by the phase verify step, with the
        // compiler error as repairHint -> buildHumanPrompt); attempt undefined marks a fan-out slot.
        const repairRun = (genArgs.attempt ?? 1) >= 2;
        const { defPath } = genArgs;
        const defsContent = defPath ? await getContentByMlsPath(defPath) : null;
        const parsedDefs = defsContent ? parseDefs(defsContent) : null;
        const pipelineItem = parsedDefs?.item;
        if (!pipelineItem) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, `pipeline not found in defs: ${defPath || '(missing defPath)'}`)];
        }
        const raw = step.interaction?.payload?.[0];
        const output = extractToolCallArgs(raw, GEN_TOOL_NAME);
        if (!output?.code) {
            const detail = `missing generated code; payload=${describePayload(raw)}`;
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, detail, true)];
        }
        const parsed = parseMlsPath(pipelineItem.outputPath);
        if (!parsed) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, `invalid outputPath: ${pipelineItem.outputPath}`)];
        }
        const code = applyHeader(pipelineItem.outputPath, output.code);
        const saved = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, code);
        if (!saved) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(`saveGeneratedTs failed for ${pipelineItem.outputPath}`))];
        }
        const typecheckTest = buildMaterializeTypecheckTest(pipelineItem, parsedDefs ? parsedDefs.data : null);
        const typecheckPath = typecheckTest ? testPathForOutputPath(pipelineItem.outputPath) : null;
        if (typecheckPath && typecheckTest) {
            const testSaved = await saveGeneratedTsByMlsPath(typecheckPath, typecheckTest);
            if (!testSaved) {
                return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(`saveGeneratedTs failed for ${typecheckPath}`))];
            }
        }
        const compileErrors = [
            ...await compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName),
            ...(typecheckPath ? await compileMlsPathAndGetErrors(typecheckPath) : []),
        ];
        const studioDiagnostics = consumeMaterializeStudioMessages();
        if (compileErrors.length > 0) {
            const checkedFiles = typecheckPath ? `${pipelineItem.outputPath} + ${typecheckPath}` : pipelineItem.outputPath;
            const traceMsg = `compile/typecheck failed for ${checkedFiles}:\n${compileErrors.slice(0, 8).join('\n')}`;
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(traceMsg, studioDiagnostics), true)];
        }
        return [mkStatus(context, parentStep, step, hookSequential, 'completed', studioDiagnostics.length ? formatStudioDiagnostics(studioDiagnostics) : undefined, 'input_output')];
    }
    catch (error) {
        const message = formatError('afterPromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkFailureStatus(context, parentStep, step, hookSequential, isRepairRun(step.prompt), message)];
    }
}
function createPromptReadyIntent(context, parentStep, hookSequential, genArgs, genContext) {
    const args = JSON.stringify(genArgs);
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(genContext.skillSections, genContext.pipelineItem.outputPath, DEFAULT_MODEL_TYPE),
        humanPrompt: buildHumanPrompt(genContext.definitionData, genContext.contextSections, genContext.pipelineItem.outputPath, genArgs.repairHint),
        tools: [GEN_TOOL],
        toolChoice: { type: 'function', function: { name: GEN_TOOL_NAME } },
    };
}
async function buildGenContext(defPath) {
    const defsContent = await getContentByMlsPath(defPath);
    if (!defsContent)
        throw new Error(`[agentCfeMaterializeGen] defs not found: ${defPath}`);
    const parsed = parseDefs(defsContent);
    const pipelineItem = parsed.item;
    if (!pipelineItem)
        throw new Error(`[agentCfeMaterializeGen] pipeline not found: ${defPath}`);
    const skillSections = await readSections(pipelineItem.skills ?? [], 'skill');
    const contextSections = await readSections(pipelineItem.dependsFiles ?? [], 'context');
    return { pipelineItem, definitionData: parsed.data, skillSections, contextSections };
}
async function readSections(paths, kind) {
    const sections = [];
    for (const requestedPath of paths) {
        const expandedPaths = kind === 'context' ? expandContextRef(requestedPath) : [requestedPath];
        for (const path of expandedPaths) {
            const content = await getContentByMlsPath(path);
            if (!content)
                continue;
            if (kind === 'skill') {
                sections.push(`<!-- skill: ${path} -->\n${content}`);
            }
            else {
                sections.push(`### ${path}\n\`\`\`ts\n${content}\n\`\`\``);
            }
        }
    }
    return sections;
}
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    if (traceMsg) {
        if (status === 'failed')
            console.error(`[${AGENT_NAME}] ${traceMsg}`);
        else if (status === 'completed' && traceMsg.includes('Studio diagnostics'))
            console.warn(`[${AGENT_NAME}] ${traceMsg}`);
    }
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
// Fan-out-safe failure policy (skills/collab_messages.md): a 'failed' PARALLEL child fails the
// whole task, so fan-out slots (attempt undefined) NEVER return 'failed' and never add steps —
// they complete with a 'MATERIALIZE-FAILED: ' trace and the phase verify step
// (agentCfeMaterializePhase, mode 'verify') runs ONE bounded repair round with the compiler
// error in context (specAuraForge §11). Repair runs (attempt >= 2) are normal steps: their
// failure is the final visible failure after the budget is exhausted.
function mkFailureStatus(context, parentStep, step, hookSequential, repairRun, detail, manualRerunHint = false) {
    if (repairRun) {
        const suffix = manualRerunHint ? '\nmanual rerun required; Studio retry is disabled to avoid orphaned prompt hooks during continue/recovery.' : '';
        return mkStatus(context, parentStep, step, hookSequential, 'failed', `${detail}${suffix}`);
    }
    return mkStatus(context, parentStep, step, hookSequential, 'completed', `MATERIALIZE-FAILED: ${detail}`, 'input_output');
}
// Lenient attempt read for catch paths (raw may be missing or invalid JSON).
function isRepairRun(raw) {
    try {
        const parsed = raw ? JSON.parse(raw) : null;
        return isRecord(parsed) && typeof parsed.attempt === 'number' && parsed.attempt >= 2;
    }
    catch {
        return false;
    }
}
function withStudioDiagnostics(message, diagnostics = consumeMaterializeStudioMessages()) {
    if (!diagnostics.length)
        return message;
    return `${message}\n${formatStudioDiagnostics(diagnostics)}`;
}
function formatStudioDiagnostics(diagnostics) {
    return [
        'Studio diagnostics:',
        ...diagnostics.map(item => `- ${item.level}: ${item.message}`),
    ].join('\n');
}
function parseGenStepArgs(raw) {
    if (!raw)
        throw new Error('missing args');
    const parsed = JSON.parse(raw);
    if (!isRecord(parsed))
        throw new Error('args must be an object');
    const planId = readString(parsed.planId);
    const defPath = readString(parsed.defPath);
    if (!planId || !defPath)
        throw new Error('args missing planId or defPath');
    const attempt = typeof parsed.attempt === 'number' && Number.isInteger(parsed.attempt) ? parsed.attempt : undefined;
    const repairHint = readString(parsed.repairHint) || undefined;
    return { planId, defPath, attempt, repairHint };
}
function readString(value) {
    return typeof value === 'string' ? value : '';
}
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function formatError(stage, error) {
    const message = error instanceof Error ? error.message : String(error);
    return `${stage}: ${message}`;
}
function describePayload(raw) {
    if (raw === null)
        return 'null';
    if (raw === undefined)
        return 'undefined';
    if (typeof raw === 'string')
        return `string(${raw.slice(0, 160)})`;
    if (typeof raw !== 'object')
        return typeof raw;
    if (Array.isArray(raw))
        return `array(${raw.length})`;
    const keys = Object.keys(raw).slice(0, 8);
    return `object keys=[${keys.join(',')}]`;
}
