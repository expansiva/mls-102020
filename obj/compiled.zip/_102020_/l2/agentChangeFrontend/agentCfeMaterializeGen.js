/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentCfeMaterializeGen.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { applyHeader, buildMaterializeTypecheckTest, buildHumanPrompt, buildSystemPrompt, DEFAULT_MODEL_TYPE, GEN_TOOL, GEN_TOOL_NAME, parseDefs, testPathForOutputPath, } from '/_102020_/l2/agentChangeFrontend/cfeMaterializeCore.js';
import { compileAndGetErrors, compileMlsPathAndGetErrors, extractToolCallArgs, getContentByMlsPath, parseMlsPath, saveGeneratedTs, saveGeneratedTsByMlsPath, } from '/_102020_/l2/agentChangeFrontend/cfeMaterializeStudio.js';
export function createAgent() {
    return {
        agentName: 'agentCfeMaterializeGen',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend',
        agentDescription: 'Generate one frontend L2 .ts file from an agentChangeFrontend .defs.ts pipeline item',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        if (!args)
            throw new Error('missing args');
        const { defPath } = JSON.parse(args);
        const genContext = await buildGenContext(defPath);
        const intent = {
            type: 'prompt_ready',
            args,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt: buildSystemPrompt(genContext.skillSections, genContext.pipelineItem.outputPath, DEFAULT_MODEL_TYPE),
            humanPrompt: buildHumanPrompt(genContext.definitionData, genContext.contextSections, genContext.pipelineItem.outputPath),
            tools: [GEN_TOOL],
            toolChoice: { type: 'function', function: { name: GEN_TOOL_NAME } },
        };
        return [intent];
    }
    catch (error) {
        const message = formatError('beforePromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const { defPath } = JSON.parse(step.prompt || '{}');
        const defsContent = defPath ? await getContentByMlsPath(defPath) : null;
        const parsedDefs = defsContent ? parseDefs(defsContent) : null;
        const pipelineItem = parsedDefs?.item;
        if (!pipelineItem) {
            return [mkStatus(context, parentStep, step, hookSequential, 'failed', `pipeline not found in defs: ${defPath || '(missing defPath)'}`)];
        }
        const raw = step.interaction?.payload?.[0];
        const output = extractToolCallArgs(raw, GEN_TOOL_NAME);
        if (!output?.code) {
            return [mkStatus(context, parentStep, step, hookSequential, 'failed', `missing generated code for ${pipelineItem.outputPath}; payload=${describePayload(raw)}`)];
        }
        const parsed = parseMlsPath(pipelineItem.outputPath);
        if (!parsed) {
            return [mkStatus(context, parentStep, step, hookSequential, 'failed', `invalid outputPath: ${pipelineItem.outputPath}`)];
        }
        const code = applyHeader(pipelineItem.outputPath, output.code);
        const saved = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, code);
        if (!saved) {
            return [mkStatus(context, parentStep, step, hookSequential, 'failed', `saveGeneratedTs failed for ${pipelineItem.outputPath}`)];
        }
        const typecheckTest = buildMaterializeTypecheckTest(pipelineItem, parsedDefs ? parsedDefs.data : null);
        const typecheckPath = typecheckTest ? testPathForOutputPath(pipelineItem.outputPath) : null;
        if (typecheckPath && typecheckTest) {
            const testSaved = await saveGeneratedTsByMlsPath(typecheckPath, typecheckTest);
            if (!testSaved) {
                return [mkStatus(context, parentStep, step, hookSequential, 'failed', `saveGeneratedTs failed for ${typecheckPath}`)];
            }
        }
        const compileErrors = [
            ...await compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName),
            ...(typecheckPath ? await compileMlsPathAndGetErrors(typecheckPath) : []),
        ];
        if (compileErrors.length > 0) {
            const checkedFiles = typecheckPath ? `${pipelineItem.outputPath} + ${typecheckPath}` : pipelineItem.outputPath;
            return [mkStatus(context, parentStep, step, hookSequential, 'failed', `compile/typecheck failed for ${checkedFiles}:\n${compileErrors.slice(0, 8).join('\n')}`)];
        }
        return [mkStatus(context, parentStep, step, hookSequential, 'completed', undefined, 'input_output')];
    }
    catch (error) {
        const message = formatError('afterPromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
async function buildGenContext(defPath) {
    const defsContent = await getContentByMlsPath(defPath);
    if (!defsContent)
        throw new Error(`[agentCfeMaterializeGen] defs not found: ${defPath}`);
    const parsed = parseDefs(defsContent);
    const pipelineItem = parsed.item;
    if (!pipelineItem)
        throw new Error(`[agentCfeMaterializeGen] pipeline not found: ${defPath}`);
    const skillSections = await readSections(pipelineItem.skills ?? [], 'skill');
    const contextSections = await readSections(pipelineItem.dependsFiles ?? [], 'context');
    return { pipelineItem, definitionData: parsed.data, skillSections, contextSections };
}
async function readSections(paths, kind) {
    const sections = [];
    for (const path of paths) {
        const content = await getContentByMlsPath(path);
        if (!content)
            continue;
        if (kind === 'skill') {
            sections.push(`<!-- skill: ${path} -->\n${content}`);
        }
        else {
            sections.push(`### ${path}\n\`\`\`ts\n${content}\n\`\`\``);
        }
    }
    return sections;
}
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
function formatError(stage, error) {
    const message = error instanceof Error ? error.message : String(error);
    return `${stage}: ${message}`;
}
function describePayload(raw) {
    if (raw === null)
        return 'null';
    if (raw === undefined)
        return 'undefined';
    if (typeof raw === 'string')
        return `string(${raw.slice(0, 160)})`;
    if (typeof raw !== 'object')
        return typeof raw;
    if (Array.isArray(raw))
        return `array(${raw.length})`;
    const keys = Object.keys(raw).slice(0, 8);
    return `object keys=[${keys.join(',')}]`;
}
