/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentCfeV01PageConsole.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAddStepIntent, createAgentStepPayload, createUpdateStatusIntent, parseStepArgs, phasePlanId, } from '/_102020_/l2/agentChangeFrontend/cfeV01Shared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeV01PageConsole',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend',
        agentDescription: 'v0.1 page-level console test container',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const parsed = parseStepArgs(args || step.prompt);
    const page = parsed.page;
    if (!page)
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', 'missing page args')];
    return [
        createAddStepIntent(context, step, createChildStep(page, 'contract', [])),
        createAddStepIntent(context, step, createChildStep(page, 'shared', [phasePlanId('contract', page)])),
        createAddStepIntent(context, step, createChildStep(page, 'layout', [phasePlanId('shared', page)])),
        createAddStepIntent(context, step, createChildStep(page, 'config', [phasePlanId('layout', page)])),
        createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed'),
    ];
}
function createChildStep(page, phase, dependsOn) {
    return createAgentStepPayload(phasePlanId(phase, page), 'agentCfeV01PageChildConsole', `v0.1 ${phase} ${page.pageId}`, { page, phase }, dependsOn, 'sequential');
}
