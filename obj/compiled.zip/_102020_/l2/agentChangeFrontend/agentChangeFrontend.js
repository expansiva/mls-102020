/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentChangeFrontend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAddStepIntent, createAgentStepPayload, createUpdateStatusIntent } from '/_102020_/l2/agentChangeFrontend/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentChangeFrontend',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend',
        agentDescription: 'Stage 2 frontend reconciler. Create-only frontend defs and config from l4.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const command = parseCliCommand(userPrompt);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt(command) },
                { type: 'human', content: normalizePrompt(userPrompt) },
            ],
            taskTitle: 'agentChangeFrontend',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeFrontend', flowName: 'agentChangeFrontend', version: 'create-v1', cliCommand: command.kind },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    const payload = step.interaction?.payload?.[0];
    if (!payload || payload.type !== 'result' || payload.result !== 'rebuild_all') {
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', payload?.help || HELP_TEXT)];
    }
    const reset = await resetFrontendDoneStatuses();
    console.log(`[${agent.agentName}] /rebuild all reset ${reset.updated} owner(s) from done to toCreate`);
    const scanStep = createAgentStepPayload('scan-create-l4', 'agentCfeCreateScanL4', 'Ler L4 e criar paginas pendentes', { command: '/rebuild all', reset }, [], 'sequential', 'waiting_human_input');
    return [createAddStepIntent(context, step, scanStep)];
}
function parseCliCommand(prompt) {
    const normalized = normalizePrompt(prompt);
    if (normalized === '/rebuild all')
        return { kind: 'rebuildAll' };
    return { kind: 'help', reason: normalized ? `Comando desconhecido: ${normalized}` : 'Comando ausente.' };
}
function normalizePrompt(prompt) {
    return String(prompt || '')
        .trim()
        .replace(/^@@(?:agentChangeFrontend|changeFrontend)\s+/i, '')
        .replace(/\s+/g, ' ');
}
function systemPrompt(command) {
    const result = command.kind === 'rebuildAll'
        ? { type: 'result', result: 'rebuild_all' }
        : { type: 'result', result: 'help', help: HELP_TEXT };
    return `
<!-- modelType: codefast -->

Return only this exact JSON object:
${JSON.stringify(result)}

agentChangeFrontend is a strict CLI-like agent. It accepts only /rebuild all.
`;
}
async function resetFrontendDoneStatuses() {
    const owners = [];
    const project = mls.actualProject || 0;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        if (folder !== 'operations' && folder !== 'workflows')
            continue;
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!parsed || parsed.data.statusFrontend !== 'done')
            continue;
        parsed.data.statusFrontend = 'toCreate';
        await saveConstDefault(file, parsed.exportName, parsed.data);
        owners.push(`${folder.slice(0, -1)}:${readString(parsed.data.operationId) || readString(parsed.data.workflowId) || file.shortName}`);
    }
    return { updated: owners.length, owners };
}
function parseDefsSource(content) {
    const exportMatch = content.match(/export\s+const\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=/);
    if (!exportMatch)
        return null;
    const json = extractJsonLiteral(content, exportMatch.index || 0);
    if (!json)
        return null;
    try {
        const data = JSON.parse(json);
        return data && typeof data === 'object' && !Array.isArray(data) ? { exportName: exportMatch[1], data } : null;
    }
    catch {
        return null;
    }
}
function extractJsonLiteral(content, fromIndex) {
    const firstObject = content.indexOf('{', fromIndex);
    if (firstObject === -1)
        return '';
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = firstObject; index < content.length; index += 1) {
        const char = content[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{')
            depth += 1;
        if (char === '}') {
            depth -= 1;
            if (depth === 0)
                return content.slice(firstObject, index + 1);
        }
    }
    return '';
}
async function saveConstDefault(file, exportName, data) {
    const header = `/// <mls fileReference="${toDisplayRef(file)}" enhancement="_blank"/>\n\n`;
    const content = `${header}export const ${exportName} = ${JSON.stringify(data, null, 2)} as const;\n\nexport default ${exportName};\n`;
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
function toDisplayRef(file) {
    const folder = file.folder ? `${file.folder}/` : '';
    return `_${file.project}_/l${file.level}/${folder}${file.shortName}${file.extension}`;
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
const HELP_TEXT = `agentChangeFrontend

Uso:
@@changeFrontend /rebuild all

Comportamento:
- altera l4 operations/workflows com statusFrontend = done para toCreate
- nao deleta arquivos gerados
- a geracao seguinte sobrescreve os .defs.ts e atualiza config.json

Qualquer outro comando apenas mostra este help.`;
