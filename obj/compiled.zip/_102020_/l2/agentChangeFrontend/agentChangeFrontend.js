/// <mls fileReference="_102020_/l2/agentChangeFrontend/agentChangeFrontend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAgentStepPayload, createUpdateStatusIntent } from '/_102020_/l2/agentChangeFrontend/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentChangeFrontend',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend',
        agentDescription: 'Stage 2 frontend reconciler. Create-only frontend defs and config from l4.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const raw = userPrompt || context.message.content || '';
    const command = parseCliCommand(raw);
    const addMessageAI = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentChangeFrontend deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: normalizePrompt(raw) || 'agentChangeFrontend' },
            ],
            taskTitle: 'agentChangeFrontend',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeFrontend', flowName: 'agentChangeFrontend', version: 'create-v1', cliCommand: command.kind },
        },
    };
    if (command.kind === 'help') {
        return [addMessageAI, createBootstrapAddStepIntent(context, createHelpStep(command.reason))];
    }
    const reset = command.reset ? await resetFrontendDoneStatuses() : { updated: 0, owners: [] };
    const scanStep = createAgentStepPayload('scan-create-l4', 'agentCfeCreateScanL4', 'Ler L4 e criar paginas pendentes', { command: command.kind, reset, materialize: command.materialize, forceMaterialize: false }, [], 'sequential', 'waiting_human_input');
    return [addMessageAI, createBootstrapAddStepIntent(context, scanStep)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed without using the model payload.')];
}
function parseCliCommand(prompt) {
    const normalized = normalizePrompt(prompt);
    if (!normalized)
        return { kind: 'run', materialize: true, reset: false };
    if (normalized === '/help' || normalized === 'help')
        return { kind: 'help', reason: '' };
    if (/\brebuild\b/.test(normalized)) {
        if (/\bdefs\b/.test(normalized))
            return { kind: 'rebuild-defs', materialize: false, reset: true };
        if (/\ball\b/.test(normalized) || normalized === '/rebuild')
            return { kind: 'rebuild-all', materialize: true, reset: true };
    }
    if (normalized === '/run' || normalized === 'run')
        return { kind: 'run', materialize: true, reset: false };
    return { kind: 'help', reason: `Comando desconhecido: ${normalized}` };
}
function normalizePrompt(prompt) {
    return String(prompt || '')
        .trim()
        .replace(/^@@(?:agentChangeFrontend|changeFrontend)(?:\s+|$)/i, '')
        .replace(/\s+/g, ' ')
        .toLowerCase();
}
// Reset generation status in l5/{module}/todoFrontend.defs.ts (done -> toCreate). The l4 owner
// defs are read-only for this agent; status lives only in the todo (mirrors agentChangeBackend).
async function resetFrontendDoneStatuses() {
    const owners = [];
    const project = mls.actualProject || 0;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 5 || file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        if (String(file.shortName || '') !== 'todoFrontend')
            continue;
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!parsed)
            continue;
        const todoOwners = Array.isArray(parsed.data.owners)
            ? parsed.data.owners.filter((o) => !!o && typeof o === 'object' && !Array.isArray(o))
            : [];
        let changed = false;
        for (const owner of todoOwners) {
            if (readString(owner.status) !== 'done')
                continue;
            owner.status = 'toCreate';
            owners.push(`${readString(owner.ownerType)}:${readString(owner.ownerId)}`);
            changed = true;
        }
        if (changed) {
            parsed.data.updatedAt = new Date().toISOString();
            await saveConstDefault(file, parsed.exportName, parsed.data);
        }
    }
    return { updated: owners.length, owners };
}
function parseDefsSource(content) {
    const exportMatch = content.match(/export\s+const\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=/);
    if (!exportMatch)
        return null;
    const json = extractJsonLiteral(content, exportMatch.index || 0);
    if (!json)
        return null;
    try {
        const data = JSON.parse(json);
        return data && typeof data === 'object' && !Array.isArray(data) ? { exportName: exportMatch[1], data } : null;
    }
    catch {
        return null;
    }
}
function extractJsonLiteral(content, fromIndex) {
    const firstObject = content.indexOf('{', fromIndex);
    if (firstObject === -1)
        return '';
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = firstObject; index < content.length; index += 1) {
        const char = content[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{')
            depth += 1;
        if (char === '}') {
            depth -= 1;
            if (depth === 0)
                return content.slice(firstObject, index + 1);
        }
    }
    return '';
}
async function saveConstDefault(file, exportName, data) {
    const header = `/// <mls fileReference="${toDisplayRef(file)}" enhancement="_blank"/>\n\n`;
    const content = `${header}export const ${exportName} = ${JSON.stringify(data, null, 2)} as const;\n\nexport default ${exportName};\n`;
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
function toDisplayRef(file) {
    const folder = file.folder ? `${file.folder}/` : '';
    return `_${file.project}_/l${file.level}/${folder}${file.shortName}${file.extension}`;
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function createBootstrapAddStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function createHelpStep(reason) {
    return createAgentStepPayload('help', 'agentCfeHelp', 'Help', { reason, helpText: HELP_TEXT }, [], 'sequential', 'waiting_human_input');
}
const HELP_TEXT = `agentChangeFrontend

Uso:
@@changeFrontend /run
@@changeFrontend /rebuild all
@@changeFrontend /rebuild defs
@@changeFrontend /help

Comandos:
- /run          : default. Varre o todoFrontend por status = toCreate e materializa .ts quando o .defs.ts for mais novo ou o .ts nao existir. O l4 e read-only.
- /rebuild all  : altera owners do todoFrontend com status = done para toCreate, regenera .defs.ts e materializa .ts/config por updatedAt.
- /rebuild defs : altera owners do todoFrontend com status = done para toCreate e regenera somente os .defs.ts. Nao materializa .ts/config.
- /help         : mostra esta ajuda.

Qualquer outro comando apenas mostra este help.`;
