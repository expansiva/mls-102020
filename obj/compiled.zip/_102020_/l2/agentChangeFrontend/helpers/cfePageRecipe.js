/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfePageRecipe.ts" enhancement="_blank"/>
export const CONTENT_LANDING_CATEGORY = 'contentLanding';
const GENOMES = ['page11', 'page21', 'page31'];
function slot(genome, categoryRef) {
    const content = categoryRef === CONTENT_LANDING_CATEGORY;
    const page11 = genome === 'page11';
    return {
        genome,
        defsFormat: 'prose',
        templateMode: content || page11 ? 'pinned' : 'goal-first',
        attachExperienceSkill: content || !page11,
        splitByOrganism: false,
    };
}
export function isUxVariantsToken(token) {
    return /^\/?variants[=:]all$/i.test(String(token || '').trim());
}
export function parseUxVariantsMode(tokens) {
    return tokens.some(isUxVariantsToken) ? 'all' : 'default';
}
/** Always the three genomes. `variants` is accepted and ignored — the CLI still parses `variants:all`. */
export function pageSlotRecipes(categoryRef, _variants = 'default') {
    return GENOMES.map(genome => slot(genome, categoryRef));
}
export function pageSlotRecipe(categoryRef, genome) {
    const all = pageSlotRecipes(categoryRef);
    return all.find(slot => slot.genome === genome) || all[0];
}
/** Unsuffixed route uses page11 when it exists; otherwise the first remaining genome. */
export function primaryGenomeOf(existing) {
    if (existing.includes('page11'))
        return 'page11';
    return existing[0] || 'page11';
}
