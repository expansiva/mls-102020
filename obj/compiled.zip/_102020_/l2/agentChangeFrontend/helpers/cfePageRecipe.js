/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfePageRecipe.ts" enhancement="_blank"/>
export const CONTENT_LANDING_CATEGORY = 'contentLanding';
const MANAGEMENT_SLOTS = [
    { genome: 'page11', defsFormat: 'prose', templateMode: 'pinned', attachExperienceSkill: false, splitByOrganism: false },
    { genome: 'page21', defsFormat: 'object', templateMode: 'goal-first', attachExperienceSkill: true, splitByOrganism: false },
    { genome: 'page31', defsFormat: 'object', templateMode: 'goal-first', attachExperienceSkill: true, splitByOrganism: false },
];
function contentSlot(genome) {
    return { genome, defsFormat: 'prose', templateMode: 'pinned', attachExperienceSkill: true, splitByOrganism: true };
}
const CONTENT_SLOTS = ['page11', 'page21', 'page31'].map(contentSlot);
export function isUxVariantsToken(token) {
    return /^\/?variants[=:]all$/i.test(String(token || '').trim());
}
export function parseUxVariantsMode(tokens) {
    return tokens.some(isUxVariantsToken) ? 'all' : 'default';
}
export function pageSlotRecipes(categoryRef, variants = 'default') {
    const all = categoryRef === CONTENT_LANDING_CATEGORY ? CONTENT_SLOTS : MANAGEMENT_SLOTS;
    if (variants === 'all')
        return all;
    return categoryRef === CONTENT_LANDING_CATEGORY ? [CONTENT_SLOTS[0]] : [MANAGEMENT_SLOTS[2]];
}
export function pageSlotRecipe(categoryRef, genome) {
    const all = categoryRef === CONTENT_LANDING_CATEGORY ? CONTENT_SLOTS : MANAGEMENT_SLOTS;
    return all.find(slot => slot.genome === genome) || all[0];
}
/** Unsuffixed route uses page11 when it exists; otherwise the first remaining genome. */
export function primaryGenomeOf(existing) {
    if (existing.includes('page11'))
        return 'page11';
    return existing[0] || 'page11';
}
