/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeRunSteps.ts" enhancement="_blank"/>
export function collectRunStepRecords(roots) {
    const out = [];
    const queue = Array.isArray(roots) ? [...roots] : [];
    while (queue.length) {
        const raw = queue.shift();
        if (!raw || typeof raw !== 'object')
            continue;
        const step = raw;
        const traces = Array.isArray(step.interaction?.trace)
            ? step.interaction.trace.map(item => String(item))
            : [];
        const record = {
            stepId: typeof step.stepId === 'number' ? step.stepId : 0,
            type: String(step.type || ''),
            title: String(step.stepTitle || ''),
            status: String(step.status || ''),
        };
        if (typeof step.agentName === 'string' && step.agentName)
            record.agentName = step.agentName;
        if (traces.length)
            record.lastTrace = traces[traces.length - 1];
        out.push(record);
        if (Array.isArray(step.nextSteps))
            queue.push(...step.nextSteps);
        if (Array.isArray(step.interaction?.payload))
            queue.push(...step.interaction.payload);
    }
    return out;
}
