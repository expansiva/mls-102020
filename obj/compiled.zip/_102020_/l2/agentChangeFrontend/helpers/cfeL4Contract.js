/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeL4Contract.ts" enhancement="_blank"/>
import { clientInputPresentation, isClientBoundarySource } from '/_102029_/l2/clientBoundarySources.js';
const RUNTIME_RESOLVED_SOURCES = new Set([
    'actorSession',
    'businessContext',
    'currentWorkspace',
    'activeLifecycleInstance',
    'workflowState',
    'previousStepOutput',
    'systemDefault',
]);
export function frontendOutputShapeForOperation(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const kind = readString(operation.kind).toLowerCase();
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    const accessKind = readString(accessPattern.kind).toLowerCase();
    const pagination = readString(accessPattern.pagination).toLowerCase();
    const isQuery = kind === 'query' || kind === 'view';
    if (!isQuery)
        return 'object';
    if (accessKind === 'getbyid' || accessKind === 'commandinput')
        return 'object';
    if ((accessKind === 'list' || accessKind === 'lookup') && (pagination === 'optional' || pagination === 'required'))
        return 'paginated';
    return 'array';
}
export function frontendQueryStateDefaults(outputShape) {
    const shape = normalizeOutputShape(outputShape);
    if (shape === 'paginated')
        return { collection: false, defaultValue: { items: [], total: 0 } };
    if (shape === 'object')
        return { collection: false, defaultValue: null };
    return { collection: true, defaultValue: [] };
}
export function normalizeOutputShape(value) {
    const shape = readString(value);
    if (shape === 'paginated' || shape === 'object')
        return shape;
    return 'array';
}
export function isRuntimeResolvedInputSource(source) {
    return RUNTIME_RESOLVED_SOURCES.has(readString(source));
}
export function isUserFacingOperationInput(input) {
    return isClientBoundarySource(input.source);
}
/** userInput is editable; selectedEntity and routeParam are browser context, never form fields. */
export function frontendInputPresentation(input) {
    return clientInputPresentation(input.source);
}
export function hasL4OperationInputs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    return Array.isArray(operation.inputs);
}
export function l4OperationInputs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    if (!Array.isArray(operation.inputs))
        return [];
    return operation.inputs
        .filter(isRecord)
        .map(input => ({
        inputId: readString(input.inputId),
        fieldRef: readString(input.fieldRef),
        required: input.required === true,
        source: readString(input.source),
        description: readString(input.description),
    }))
        .filter(input => input.inputId && input.fieldRef);
}
export function hasL4OperationOutputRefs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    return Array.isArray(accessPattern.output);
}
export function l4OperationOutputRefs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    return Array.isArray(accessPattern.output) ? accessPattern.output.map(readString).filter(Boolean) : [];
}
const CONTENT_ORGANISM_ROLES = new Set(['hero', 'banner', 'richText', 'imageSet', 'ctaLink', 'showcase']);
export function isContentOrganismRole(role) {
    return CONTENT_ORGANISM_ROLES.has(readString(role));
}
function bffOutputKind(value) {
    const kind = readString(value);
    if (kind === 'paginated' || kind === 'object')
        return kind;
    if (kind === 'list' || kind === 'array')
        return 'array';
    return 'object';
}
function bffCallField(value) {
    if (!isRecord(value))
        return null;
    const name = readString(value.name);
    if (!name)
        return null;
    const field = { name, from: readString(value.from) };
    const type = readString(value.type);
    if (type)
        field.type = type;
    if (value.required === true)
        field.required = true;
    if (isRecord(value.item) && Array.isArray(value.item.fields)) {
        const fields = value.item.fields.map(bffCallField).filter((f) => f !== null);
        if (fields.length)
            field.item = { fields };
    }
    return field;
}
/** True when the workspace declares the l4 v2 bffCalls[] (vs the legacy operationIds-only shape). */
export function hasWorkspaceBffCalls(data) {
    const workspace = isRecord(data) ? data : {};
    return Array.isArray(workspace.bffCalls) && workspace.bffCalls.length > 0;
}
export function parseWorkspaceBffCalls(data) {
    const workspace = isRecord(data) ? data : {};
    if (!Array.isArray(workspace.bffCalls))
        return [];
    return workspace.bffCalls
        .filter(isRecord)
        .map(raw => {
        const bffId = readString(raw.bffId);
        if (!bffId)
            return null;
        const output = isRecord(raw.output)
            ? { kind: bffOutputKind(raw.output.kind), fields: (Array.isArray(raw.output.fields) ? raw.output.fields : []).map(bffCallField).filter((f) => f !== null) }
            : null;
        const call = {
            bffId,
            kind: readString(raw.kind) === 'command' ? 'command' : 'query',
            route: readString(raw.route),
            uses: (Array.isArray(raw.uses) ? raw.uses : []).filter(isRecord).map(use => readString(use.operationId)).filter(Boolean),
            input: (Array.isArray(raw.input) ? raw.input : []).map(bffCallField).filter((f) => f !== null),
            output,
        };
        return call;
    })
        .filter((call) => call !== null);
}
export function parseWorkspaceSections(data) {
    const workspace = isRecord(data) ? data : {};
    if (!Array.isArray(workspace.sections))
        return [];
    return workspace.sections
        .filter(isRecord)
        .map((raw, index) => ({
        sectionId: readString(raw.sectionId) || `section${index + 1}`,
        intent: readString(raw.intent),
        organisms: (Array.isArray(raw.organisms) ? raw.organisms : [])
            .filter(isRecord)
            .map(org => {
            const organism = { role: readString(org.role) };
            const dataSource = readString(org.dataSource);
            const action = readString(org.action);
            const attachTo = readString(org.attachTo);
            const slice = readString(org.slice);
            if (dataSource)
                organism.dataSource = dataSource;
            if (action)
                organism.action = action;
            if (attachTo)
                organism.attachTo = attachTo;
            if (slice)
                organism.slice = slice;
            return organism;
        })
            .filter(org => org.role),
    }))
        .filter(section => section.organisms.length > 0);
}
function fromOperationId(from) {
    const dot = from.indexOf('.');
    if (dot < 0)
        return { operationId: '', path: from };
    return { operationId: from.slice(0, dot), path: from.slice(dot + 1) };
}
/** Deterministic bffCall -> command shape. `operationInputs` maps operationId -> its l4 inputs[]. */
export function bffCallCommandShape(bffCall, operationInputs) {
    const inputs = bffCall.input.map(field => {
        const ref = fromOperationId(field.from);
        const opInput = (operationInputs.get(ref.operationId) || []).find(input => input.inputId === ref.path);
        const source = opInput ? opInput.source : 'userInput';
        return {
            name: field.name,
            required: field.required === true || (opInput ? opInput.required : false),
            presentation: clientInputPresentation(source),
            source,
        };
    });
    const outputFields = bffCall.output ? bffCall.output.fields.map(field => ({ name: field.name, type: field.type || 'string', required: field.required !== false })) : [];
    const outputKind = bffCall.output ? bffCall.output.kind : 'object';
    return {
        commandName: bffCall.bffId,
        kind: bffCall.kind,
        routeKey: bffCall.route,
        outputShape: outputKind,
        canonicalOutputShape: bffCall.output ? { kind: outputKind, fields: outputFields } : null,
        input: inputs,
        output: outputFields,
    };
}
// F3: byte-copy an l4 per-bffCall contract into l2. Bodies (Input/Output interfaces + `<bffId>Route`
// const) are preserved verbatim; only the `/// <mls fileReference=…>` header is rewritten to the l2 path
// (an l4 fileReference sitting in l2 would confuse enhancement/materialize) plus a "copied from l4" note.
export function buildL2ContractCopy(rawL4Source, l2Ref, l4Ref) {
    const note = `// copied from l4 — do not edit (source: ${l4Ref})`;
    const headerLine = `/// <mls fileReference="${l2Ref}" enhancement="_blank"/>`;
    const lines = rawL4Source.replace(/\r\n/g, '\n').split('\n');
    const headerIndex = lines.findIndex(line => line.includes('<mls fileReference='));
    if (headerIndex >= 0) {
        lines[headerIndex] = headerLine;
        // Drop a blank line immediately after the header (if any) so the note sits directly under it.
        const insertAt = headerIndex + 1;
        lines.splice(insertAt, 0, note);
        return `${lines.join('\n')}\n`.replace(/\n{3,}/g, '\n\n');
    }
    return `${headerLine}\n${note}\n\n${rawL4Source.replace(/\r\n/g, '\n').replace(/^\n+/, '')}`.replace(/\n{3,}/g, '\n\n');
}
/** True when a contract .ts was byte-copied from l4 (marked by buildL2ContractCopy) — preserved by cleanup. */
export function isCopiedL4Contract(source) {
    return /copied from l4 — do not edit/.test(source);
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
