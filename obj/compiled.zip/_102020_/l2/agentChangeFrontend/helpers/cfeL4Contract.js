/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeL4Contract.ts" enhancement="_blank"/>
import { clientInputPresentation, isClientBoundarySource } from '/_102029_/l2/clientBoundarySources.js';
const RUNTIME_RESOLVED_SOURCES = new Set([
    'actorSession',
    'businessContext',
    'currentWorkspace',
    'activeLifecycleInstance',
    'workflowState',
    'previousStepOutput',
    'systemDefault',
]);
export function frontendOutputShapeForOperation(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const kind = readString(operation.kind).toLowerCase();
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    const accessKind = readString(accessPattern.kind).toLowerCase();
    const pagination = readString(accessPattern.pagination).toLowerCase();
    const isQuery = kind === 'query' || kind === 'view';
    if (!isQuery)
        return 'object';
    if (accessKind === 'getbyid' || accessKind === 'commandinput')
        return 'object';
    if ((accessKind === 'list' || accessKind === 'lookup') && (pagination === 'optional' || pagination === 'required'))
        return 'paginated';
    return 'array';
}
export function frontendQueryStateDefaults(outputShape) {
    const shape = normalizeOutputShape(outputShape);
    if (shape === 'paginated')
        return { collection: false, defaultValue: { items: [], total: 0 } };
    if (shape === 'object')
        return { collection: false, defaultValue: null };
    return { collection: true, defaultValue: [] };
}
export function normalizeOutputShape(value) {
    const shape = readString(value);
    if (shape === 'paginated' || shape === 'object')
        return shape;
    return 'array';
}
export function isRuntimeResolvedInputSource(source) {
    return RUNTIME_RESOLVED_SOURCES.has(readString(source));
}
export function isUserFacingOperationInput(input) {
    return isClientBoundarySource(input.source);
}
/** userInput is editable; selectedEntity and routeParam are browser context, never form fields. */
export function frontendInputPresentation(input) {
    return clientInputPresentation(input.source);
}
/**
 * A query may run on connectedCallback when every REQUIRED input is already on the URL.
 * Required userInput/selection is empty at boot (the BFF 400s — 102049 searchProducts).
 * Required routeParam is filled by syncRouteParams before initialLoads fire.
 */
export function queryQualifiesForInitialLoad(fields) {
    return fields.every(field => field.required !== true || field.presentation === 'route');
}
export function hasL4OperationInputs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    return Array.isArray(operation.inputs);
}
export function l4OperationInputs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    if (!Array.isArray(operation.inputs))
        return [];
    return operation.inputs
        .filter(isRecord)
        .map(input => ({
        inputId: readString(input.inputId),
        fieldRef: readString(input.fieldRef),
        required: input.required === true,
        source: readString(input.source),
        description: readString(input.description),
    }))
        .filter(input => input.inputId && input.fieldRef);
}
export function hasL4OperationOutputRefs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    return Array.isArray(accessPattern.output);
}
export function l4OperationOutputRefs(operationData) {
    const operation = isRecord(operationData) ? operationData : {};
    const accessPattern = isRecord(operation.accessPattern) ? operation.accessPattern : {};
    return Array.isArray(accessPattern.output) ? accessPattern.output.map(readString).filter(Boolean) : [];
}
const CONTENT_ORGANISM_ROLES = new Set(['hero', 'banner', 'richText', 'imageSet', 'ctaLink', 'showcase']);
export function isContentOrganismRole(role) {
    return CONTENT_ORGANISM_ROLES.has(readString(role));
}
function bffOutputKind(value) {
    const kind = readString(value);
    if (kind === 'paginated' || kind === 'object')
        return kind;
    if (kind === 'list' || kind === 'array')
        return 'array';
    return 'object';
}
function bffCallField(value) {
    if (!isRecord(value))
        return null;
    const name = readString(value.name);
    if (!name)
        return null;
    const field = { name, from: readString(value.from) };
    const type = readString(value.type);
    if (type)
        field.type = type;
    if (value.required === true)
        field.required = true;
    if (isRecord(value.item) && Array.isArray(value.item.fields)) {
        const fields = value.item.fields.map(bffCallField).filter((f) => f !== null);
        if (fields.length)
            field.item = { fields };
    }
    return field;
}
/** True when the workspace declares the l4 v2 bffCalls[] (vs the legacy operationIds-only shape). */
export function hasWorkspaceBffCalls(data) {
    const workspace = isRecord(data) ? data : {};
    return Array.isArray(workspace.bffCalls) && workspace.bffCalls.length > 0;
}
export function parseWorkspaceBffCalls(data) {
    const workspace = isRecord(data) ? data : {};
    if (!Array.isArray(workspace.bffCalls))
        return [];
    return workspace.bffCalls
        .filter(isRecord)
        .map(raw => {
        const bffId = readString(raw.bffId);
        if (!bffId)
            return null;
        const output = isRecord(raw.output)
            ? { kind: bffOutputKind(raw.output.kind), fields: (Array.isArray(raw.output.fields) ? raw.output.fields : []).map(bffCallField).filter((f) => f !== null) }
            : null;
        const call = {
            bffId,
            kind: readString(raw.kind) === 'command' ? 'command' : 'query',
            route: readString(raw.route),
            uses: (Array.isArray(raw.uses) ? raw.uses : []).filter(isRecord).map(use => readString(use.operationId)).filter(Boolean),
            input: (Array.isArray(raw.input) ? raw.input : []).map(bffCallField).filter((f) => f !== null),
            output,
        };
        return call;
    })
        .filter((call) => call !== null);
}
export function parseWorkspaceSections(data) {
    const workspace = isRecord(data) ? data : {};
    if (!Array.isArray(workspace.sections))
        return [];
    return workspace.sections
        .filter(isRecord)
        .map((raw, index) => ({
        sectionId: readString(raw.sectionId) || `section${index + 1}`,
        intent: readString(raw.intent),
        organisms: (Array.isArray(raw.organisms) ? raw.organisms : [])
            .filter(isRecord)
            .map(org => {
            const organism = { role: readString(org.role) };
            const dataSource = readString(org.dataSource);
            const action = readString(org.action);
            const attachTo = readString(org.attachTo);
            const slice = readString(org.slice);
            const usage = readString(org.usage);
            if (dataSource)
                organism.dataSource = dataSource;
            if (action)
                organism.action = action;
            if (attachTo)
                organism.attachTo = attachTo;
            if (slice)
                organism.slice = slice;
            if (usage)
                organism.usage = usage;
            return organism;
        })
            .filter(org => org.role),
    }))
        .filter(section => section.organisms.length > 0);
}
function fromOperationId(from) {
    const dot = from.indexOf('.');
    if (dot < 0)
        return { operationId: '', path: from };
    return { operationId: from.slice(0, dot), path: from.slice(dot + 1) };
}
/** Deterministic bffCall -> command shape. `operationInputs` maps operationId -> its l4 inputs[]. */
export function bffCallCommandShape(bffCall, operationInputs) {
    const inputs = bffCall.input.map(field => {
        const ref = fromOperationId(field.from);
        const opInput = (operationInputs.get(ref.operationId) || []).find(input => input.inputId === ref.path);
        const source = opInput ? opInput.source : 'userInput';
        return {
            name: field.name,
            required: field.required === true || (opInput ? opInput.required : false),
            presentation: clientInputPresentation(source),
            source,
        };
    });
    const outputFields = bffCall.output ? bffCall.output.fields.map(field => ({
        name: field.name,
        type: field.type || (field.item ? 'array' : 'string'),
        required: field.required !== false,
        ...(field.item ? { item: field.item } : {}),
    })) : [];
    const outputKind = bffCall.output ? bffCall.output.kind : 'object';
    return {
        commandName: bffCall.bffId,
        kind: bffCall.kind,
        routeKey: bffCall.route,
        outputShape: outputKind,
        canonicalOutputShape: bffCall.output ? { kind: outputKind, fields: outputFields } : null,
        input: inputs,
        output: outputFields,
    };
}
const GENERATED_CONTRACT_MARKER = 'GENERATED from l4 bffCalls — do not edit';
/** One l2 contract file for a whole workspace: all bffCall Input/Output interfaces + route consts. */
export function buildWorkspaceContractSource(args) {
    const iface = (name, fields) => {
        if (fields.length === 0)
            return `export interface ${name} {}`;
        const body = fields.map(field => `  ${safeIdent(field.name)}${field.optional ? '?' : ''}: ${field.type};`).join('\n');
        return `export interface ${name} {\n${body}\n}`;
    };
    const blocks = args.calls.flatMap(call => [
        `// bffCall ${call.bffId} (${call.kind}) — Output kind=${call.outputKind}; route ${call.route}.`,
        iface(`${call.interfaceName}Input`, call.input),
        iface(`${call.interfaceName}Output`, call.output),
        `export const ${call.bffId}Route = '${call.route}' as const;`,
        '',
    ]);
    return [
        `/// <mls fileReference="${args.l2Ref}" enhancement="_blank"/>`,
        '',
        `// ${GENERATED_CONTRACT_MARKER} (workspace ${args.workspaceId}; one contract file per workspace, all bffCalls).`,
        '',
        ...blocks,
    ].join('\n');
}
function safeIdent(name) {
    return /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(name) ? name : JSON.stringify(name);
}
/** True when a contract .ts was generated from l4 bffCalls — preserved by rebuild-defs cleanup. */
export function isCopiedL4Contract(source) {
    return /GENERATED from l4 bffCalls — do not edit/.test(source);
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
