/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeRunReport.ts" enhancement="_blank"/>
export function buildCfRunReport(report) {
    return {
        moduleName: report.moduleName,
        attempt: report.attempt,
        final: report.final,
        repairRounds: report.repairRounds,
        pagesDone: report.pagesDone,
        ownersDone: report.ownersDone,
        skippedPages: report.skippedPages,
        gate: report.gate,
        agentBuild: report.agentBuild,
        steps: report.steps,
        summary: report.summary,
    };
}
export function cfRunLatestMlsPath(project, moduleName) {
    return `_${project}_/l4/${moduleName}/trace/cf-run.json`;
}
export function cfRunSnapshotMlsPath(project, moduleName, stamp) {
    return `_${project}_/l4/${moduleName}/trace/cf-run-${stamp}.json`;
}
