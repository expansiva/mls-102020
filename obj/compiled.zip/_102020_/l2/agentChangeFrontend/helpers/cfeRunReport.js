/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeRunReport.ts" enhancement="_blank"/>
import { cfePipelineTraceMlsPath } from '/_102020_/l2/agentChangeFrontend/helpers/cfePipelineTrace.js';
export function buildCfRunReport(report) {
    return {
        moduleName: report.moduleName,
        attempt: report.attempt,
        final: report.final,
        repairRounds: report.repairRounds,
        pagesDone: report.pagesDone,
        ownersDone: report.ownersDone,
        skippedPages: report.skippedPages,
        gate: report.gate,
        agentBuild: report.agentBuild,
        steps: report.steps,
        summary: report.summary,
    };
}
export function cfRunLatestMlsPath(project, moduleName) {
    return cfePipelineTraceMlsPath(project, moduleName, '', 'cf-run.json');
}
export function cfRunSnapshotMlsPath(project, moduleName, stamp) {
    return cfePipelineTraceMlsPath(project, moduleName, '', `cf-run-${stamp}.json`);
}
