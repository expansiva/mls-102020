/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeProjectTsc.ts" enhancement="_blank"/>
const TSC_ERROR = /(?:^|\s)(?:.*[/\\])?mls-(\d+)[/\\]l(\d+)[/\\](.+?)\.ts\((\d+),(\d+)\):\s*error\s+(TS\d+):\s*(.*)$/u;
export function parseTscDiagnostics(output) {
    const out = [];
    for (const raw of output.split(/\r?\n/)) {
        const line = raw.replace(/\u001b\[[0-9;]*m/g, '');
        const match = TSC_ERROR.exec(line);
        if (!match)
            continue;
        const rest = match[3];
        const slash = rest.lastIndexOf('/');
        out.push({
            project: Number(match[1]),
            level: Number(match[2]),
            folder: slash < 0 ? '' : rest.slice(0, slash),
            shortName: slash < 0 ? rest : rest.slice(slash + 1),
            code: match[6],
            message: match[7].trim(),
        });
    }
    return out;
}
export function mlsBaseFromDiskPath(abs) {
    const normalized = abs.replace(/\\/g, '/');
    const match = /^(.*)\/mls-\d+(?:\/|$)/.exec(normalized);
    return match ? match[1] : null;
}
/** Group tsc errors onto `${folder}::${shortName}` for files under `mls-<project>/l2/<moduleName>/`. */
export function groupTscErrorsByFile(diagnostics, moduleName, project) {
    const prefix = moduleName ? `${moduleName}/` : '';
    const errors = new Map();
    for (const item of diagnostics) {
        if (item.project !== project)
            continue;
        if (item.level !== 2)
            continue;
        const inModule = prefix !== '' && (item.folder === moduleName || item.folder.startsWith(prefix));
        if (!inModule)
            continue;
        const key = `${item.folder}::${item.shortName}`;
        const list = errors.get(key) ?? [];
        if (list.length < 12)
            list.push(`${item.code}: ${item.message}`);
        errors.set(key, list);
    }
    return errors;
}
export function countGroupedDiagnostics(grouped) {
    let n = 0;
    for (const list of grouped.values())
        n += list.length;
    return n;
}
export function formatCompileModuleTrace(trace) {
    const reason = trace.reason ? ` reason=${trace.reason}` : '';
    return `[cf-compile] path=${trace.path}${reason} files=${trace.files} raw=${trace.rawDiagnostics} afterFilter=${trace.afterFilter}`;
}
/** `ran` only when project tsc actually ran; omitted on the Monaco path (same optional field as the CB). */
export function tscGateOf(path) {
    if (path === 'project-tsc')
        return 'ran';
    if (path === 'unavailable')
        return 'unavailable';
    return undefined;
}
/** Instrument the project-tsc path: spawn-null vs parsed vs leftover after the in-module filter. */
export function traceProjectTscResult(output, moduleName, project, files, reasonIfNull) {
    if (output === null) {
        return {
            grouped: null,
            trace: { path: 'unavailable', reason: reasonIfNull, rawDiagnostics: 0, afterFilter: 0, files },
        };
    }
    const parsed = parseTscDiagnostics(output);
    const grouped = groupTscErrorsByFile(parsed, moduleName, project);
    return {
        grouped,
        trace: {
            path: 'project-tsc',
            rawDiagnostics: parsed.length,
            afterFilter: countGroupedDiagnostics(grouped),
            files,
        },
    };
}
export function flattenTscErrorsAsRefs(project, grouped) {
    const errors = [];
    for (const [key, list] of grouped) {
        const sep = key.indexOf('::');
        if (sep <= 0)
            continue;
        const folder = key.slice(0, sep);
        const shortName = key.slice(sep + 2);
        const ref = `_${project}_/l2/${folder}/${shortName}.ts`;
        for (const error of list)
            errors.push(`${ref}: ${error}`);
    }
    return errors;
}
export function mergeCompileTargets(inScope, compiled) {
    const seen = new Set(inScope.map(item => `${item.folder}::${item.real}`));
    const extra = [];
    for (const key of compiled.keys()) {
        if (seen.has(key))
            continue;
        const sep = key.indexOf('::');
        if (sep <= 0)
            continue;
        const folder = key.slice(0, sep);
        const real = key.slice(sep + 2);
        if (!real)
            continue;
        extra.push({ folder, shortName: real.toLowerCase(), real });
    }
    return extra.length ? [...inScope, ...extra] : inScope;
}
