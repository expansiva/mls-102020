/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeModuleNavigation.ts" enhancement="_blank"/>
export function navigationFromE8Menu(args) {
    const labels = args.labels || {};
    const pageById = new Map(args.pages.map(page => [page.pageId, page]));
    if (!args.menu.length) {
        return args.pages.map(page => navigationEntry(args.moduleName, page, labels[page.pageId] || page.label));
    }
    return args.menu.flatMap(entry => {
        const page = pageById.get(entry.workspaceId);
        if (!page)
            return [];
        return [navigationEntry(args.moduleName, page, labels[page.pageId] || entry.label || page.label)];
    });
}
function navigationEntry(moduleName, page, label) {
    return {
        id: page.pageId,
        label,
        href: `/${moduleName}/${page.pageId}`,
        description: label,
        ...(page.actors?.length ? { actors: page.actors } : {}),
        ...(page.landing ? { landing: true } : {}),
    };
}
