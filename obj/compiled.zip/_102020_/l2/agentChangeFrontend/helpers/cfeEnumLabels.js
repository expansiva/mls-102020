/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeEnumLabels.ts" enhancement="_blank"/>
export function readEnumLabels(value) {
    if (!Array.isArray(value))
        return [];
    const out = [];
    const seen = new Set();
    for (const item of value) {
        if (!item || typeof item !== 'object' || Array.isArray(item))
            continue;
        const rec = item;
        const code = typeof rec.code === 'string' ? rec.code.trim() : '';
        const label = typeof rec.label === 'string' ? rec.label.trim() : '';
        if (!code || seen.has(code))
            continue;
        seen.add(code);
        out.push({ code, label: label || code });
    }
    return out;
}
/** Prefer the authored label; fall back to the stored code when the L4 has none. */
export function enumDisplayLabel(code, labels) {
    if (!code)
        return code;
    const found = labels?.find(item => item.code === code);
    return found?.label || code;
}
export function enumDisplayOptions(codes, labels) {
    return codes.map(code => ({ value: code, label: enumDisplayLabel(code, labels) }));
}
