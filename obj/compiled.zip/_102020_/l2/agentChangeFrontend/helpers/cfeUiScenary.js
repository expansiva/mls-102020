/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfeUiScenary.ts" enhancement="_blank"/>
export function isDestructiveCommandName(commandName) {
    const stripped = commandName.replace(/^cmd/i, '');
    const titled = stripped.charAt(0).toUpperCase() + stripped.slice(1);
    return /^(Delete|Cancel)(?=[A-Z]|$)/.test(titled);
}
/** `cmdDecideTaskStatus` → `decideTaskStatus`; already-bare names stay. */
export function commandScenaryValue(commandName) {
    if (!/^cmd/i.test(commandName))
        return commandName;
    const rest = commandName.replace(/^cmd/i, '');
    if (!rest)
        return commandName;
    return rest.charAt(0).toLowerCase() + rest.slice(1);
}
export function isGetByIdQuery(command) {
    if (String(command.kind).toLowerCase() !== 'query')
        return false;
    const access = String(command.accessKind || '').toLowerCase();
    if (access === 'getbyid')
        return true;
    if (access === 'list' || access === 'lookup')
        return false;
    const shape = String(command.outputShape || '').toLowerCase();
    return shape === 'object' && requiredRouteOrSelectionInputs(command).length > 0;
}
export function isListOrHubQuery(command) {
    if (String(command.kind).toLowerCase() !== 'query')
        return false;
    if (isGetByIdQuery(command))
        return false;
    const access = String(command.accessKind || '').toLowerCase();
    if (access === 'list' || access === 'lookup')
        return true;
    const shape = String(command.outputShape || '').toLowerCase();
    return shape === 'array' || shape === 'paginated' || shape === '';
}
function requiredRouteOrSelectionInputs(command) {
    return (command.input || []).filter(field => field.required === true && isRouteOrSelectionInput(field));
}
export function isRouteOrSelectionInput(field) {
    const presentation = String(field.presentation || '').toLowerCase();
    const source = String(field.source || '').toLowerCase();
    if (presentation === 'route' || presentation === 'selection')
        return true;
    return source === 'routeparam' || source === 'selectedentity' || source === 'selection';
}
function inputStateKey(pageId, commandName, fieldName) {
    return `ui.${pageId}.input.${commandName}.${fieldName}`;
}
function preconditionKeys(pageId, command) {
    return requiredRouteOrSelectionInputs(command).map(field => inputStateKey(pageId, command.commandName, field.name));
}
/**
 * Always emits at least the base scene (even when the page has a single query).
 * Detail exists when some query has `selection: 'single'` AND a getById/inspect query is present.
 * Each non-destructive command is its own scene, named without the `cmd` prefix.
 */
export function deriveUiScenaries(pageId, commands) {
    const scenaries = [];
    const queries = commands.filter(command => String(command.kind).toLowerCase() === 'query' && command.commandName);
    const mutations = commands.filter(command => String(command.kind).toLowerCase() !== 'query' && command.commandName);
    const baseQuery = queries.find(isListOrHubQuery) || queries[0];
    scenaries.push({
        value: 'base',
        kind: 'base',
        ...(baseQuery?.commandName ? { commandName: baseQuery.commandName } : {}),
        preconditions: [],
    });
    const hasSingleSelection = commands.some(command => String(command.selection || '').toLowerCase() === 'single');
    const inspectQuery = queries.find(isGetByIdQuery);
    if (hasSingleSelection && inspectQuery) {
        scenaries.push({
            value: 'detail',
            kind: 'detail',
            commandName: inspectQuery.commandName,
            preconditions: preconditionKeys(pageId, inspectQuery),
        });
    }
    for (const command of mutations) {
        if (isDestructiveCommandName(command.commandName))
            continue;
        scenaries.push({
            value: commandScenaryValue(command.commandName),
            kind: 'command',
            commandName: command.commandName,
            preconditions: preconditionKeys(pageId, command),
        });
    }
    return scenaries;
}
export function destructiveCommandIds(commands) {
    return commands
        .filter(command => command.commandName && String(command.kind).toLowerCase() !== 'query' && isDestructiveCommandName(command.commandName))
        .map(command => command.commandName);
}
export const UI_SCENARY_DEFS_CONTRACT = [
    'uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):',
    '  scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }',
    '  preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.',
    '  URL `?scenary=` is a request; the shared setter is the source of truth.',
    '  destructiveCommandIds never become scenes (confirmation stays a modal).',
].join('\n');
