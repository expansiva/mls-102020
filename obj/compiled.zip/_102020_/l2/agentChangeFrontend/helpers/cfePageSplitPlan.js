/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfePageSplitPlan.ts" enhancement="_blank"/>
/**
 * @param bindings the page's dataBindings commands — a section referencing something outside this page
 *        (another workspace's bffCall) contributes nothing.
 * @returns null when the l4 gives nothing to split by; the caller must then report instead of guessing.
 */
export function buildSplitPlan(pageId, genome, sections, bindings, reason) {
    const known = new Set(bindings);
    const organisms = [];
    for (const section of sections) {
        const owned = [];
        for (const organism of section.organisms ?? []) {
            for (const ref of [organism.dataSource, organism.action, organism.attachTo]) {
                if (ref && known.has(ref) && !owned.includes(ref))
                    owned.push(ref);
            }
        }
        // A section with no binding of this page renders nothing data-driven — it would be an empty file.
        if (owned.length === 0)
            continue;
        organisms.push({ n: organisms.length + 1, organism: organismNameOf(section.sectionId), bindings: owned });
    }
    // One organism means the split changes nothing: the page would still be one big file plus a wrapper.
    if (organisms.length < 2)
        return null;
    const covered = new Set(organisms.flatMap(item => item.bindings));
    const orphans = bindings.filter(binding => !covered.has(binding));
    if (orphans.length > 0) {
        // Never silently drop a binding: the page keeps rendering what no section claimed.
        organisms.push({ n: organisms.length + 1, organism: 'other', bindings: orphans });
    }
    return { pageId, genome, reason, organisms };
}
/**
 * contentLanding: one pipeline item per organism (hero, richText, imageSet, form, counter…),
 * including organisms with no binding of this page. The section-level split above would skip
 * those and wait for an output-cap failure; this recipe materializes piece by piece from the start.
 */
export function buildOrganismSplitPlan(pageId, genome, sections, bindings, reason) {
    const known = new Set(bindings);
    const usedNames = new Set();
    const organisms = [];
    for (const section of sections) {
        for (const organism of section.organisms ?? []) {
            const owned = [];
            for (const ref of [organism.dataSource, organism.action, organism.attachTo]) {
                if (ref && known.has(ref) && !owned.includes(ref))
                    owned.push(ref);
            }
            const base = organismNameOf(organism.role || section.sectionId);
            organisms.push({ n: organisms.length + 1, organism: uniqueOrganismName(base, usedNames), bindings: owned });
        }
    }
    if (organisms.length < 2)
        return null;
    const covered = new Set(organisms.flatMap(item => item.bindings));
    const orphans = bindings.filter(binding => !covered.has(binding));
    if (orphans.length > 0) {
        organisms.push({ n: organisms.length + 1, organism: uniqueOrganismName('other', usedNames), bindings: orphans });
    }
    return { pageId, genome, reason, organisms };
}
function uniqueOrganismName(base, used) {
    if (!used.has(base)) {
        used.add(base);
        return base;
    }
    let n = 2;
    while (used.has(`${base}${n}`))
        n += 1;
    const name = `${base}${n}`;
    used.add(name);
    return name;
}
/** `sec-delay-risk-insights` / `delayRiskInsights` -> `delayRiskInsights` (a valid identifier fragment). */
export function organismNameOf(sectionId) {
    const withoutPrefix = sectionId.replace(/^sec[-_]/u, '');
    const parts = withoutPrefix.split(/[^A-Za-z0-9]+/u).filter(Boolean);
    if (parts.length === 0)
        return 'section';
    const [first, ...rest] = parts;
    const head = /^[A-Z]/u.test(first) ? first.charAt(0).toLowerCase() + first.slice(1) : first;
    return head + rest.map(part => part.charAt(0).toUpperCase() + part.slice(1)).join('');
}
