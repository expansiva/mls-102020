/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/cfePipelineTrace.ts" enhancement="_blank"/>
/**
 * Single chokepoint for CF run records: written to `l4/<module>/pipeline/trace/l2/...`.
 * The `/rebuild all` of this agent deletes that folder so a previous run cannot be reread.
 * shortName never contains a dot (Studio round-trip).
 */
export const CFE_PIPELINE_TRACE_LEVEL = 4;
export const CFE_PIPELINE_TRACE_LAYER = 'l2';
export const CFE_PIPELINE_AGENT_SLUG = 'changefrontend';
const memoryDegradations = [];
export function nextPipelineRunNn(existingShortNames, agentSlug) {
    const re = new RegExp(`^run(\\d+)_${agentSlug}$`);
    let max = 0;
    for (const name of existingShortNames) {
        const match = re.exec(name);
        if (match)
            max = Math.max(max, Number(match[1]));
    }
    return String(max + 1).padStart(2, '0');
}
export function cfePipelineFolder(moduleName) {
    return `${moduleName}/pipeline`;
}
export function cfePipelineTraceFolder(moduleName, subpath = '') {
    const base = `${cfePipelineFolder(moduleName)}/trace/${CFE_PIPELINE_TRACE_LAYER}`;
    return subpath ? `${base}/${subpath}` : base;
}
export function cfePipelineTraceFileInfo(moduleName, shortName, subpath = '', project = 0) {
    return {
        project,
        level: CFE_PIPELINE_TRACE_LEVEL,
        folder: cfePipelineTraceFolder(moduleName, subpath),
        shortName,
        extension: '.json',
    };
}
export function cfePipelineFileInfo(moduleName, shortName, project = 0) {
    return {
        project,
        level: CFE_PIPELINE_TRACE_LEVEL,
        folder: cfePipelineFolder(moduleName),
        shortName,
        extension: '.json',
    };
}
export function cfePipelineTraceMlsPath(project, moduleName, subpath, fileName) {
    return `_${project}_/l4/${cfePipelineTraceFolder(moduleName, subpath)}/${fileName}`;
}
export function isCfeMaterializeVerifyFolder(folder, moduleName) {
    return isCfeTraceSubfolder(folder, 'frontend-materialize-verify', moduleName);
}
export function isCfeTraceSubfolder(folder, subpath, moduleName) {
    const value = String(folder || '');
    if (moduleName)
        return value === cfePipelineTraceFolder(moduleName, subpath);
    return value.endsWith(`/pipeline/trace/${CFE_PIPELINE_TRACE_LAYER}/${subpath}`);
}
export function isCfePipelineTraceLevel(level) {
    return level === CFE_PIPELINE_TRACE_LEVEL;
}
export function isCfeLayerTraceFolder(folder, moduleName) {
    if (!moduleName)
        return false;
    const prefix = cfePipelineTraceFolder(moduleName);
    return folder === prefix || folder.startsWith(`${prefix}/`);
}
export function listCfeLayerTraceKeys(files, project, moduleName) {
    if (!project || !moduleName)
        return [];
    const keys = [];
    for (const [key, file] of Object.entries(files)) {
        if (!file || file.project !== project || file.level !== CFE_PIPELINE_TRACE_LEVEL || file.status === 'deleted')
            continue;
        if (!isCfeLayerTraceFolder(String(file.folder || ''), moduleName))
            continue;
        keys.push(key);
    }
    return keys;
}
/** Soft-delete `l4/<module>/pipeline/trace/l2/` of this module only. Used by `/rebuild all`. */
export async function clearCfeLayerTrace(project, moduleName) {
    if (!project || !moduleName)
        return [];
    const { deleteFile } = await import('/_102027_/l2/libStor.js');
    const deleted = [];
    for (const key of listCfeLayerTraceKeys(mls.stor.files, project, moduleName)) {
        const file = mls.stor.files[key];
        if (!file)
            continue;
        await deleteFile(file);
        deleted.push(key);
    }
    return deleted;
}
export function describeAgentCommand(longMemory, fallback = '') {
    if (!longMemory)
        return fallback;
    const parts = [];
    if (longMemory.fastMode === 'true')
        parts.push('/fast');
    const cli = typeof longMemory.cliCommand === 'string' ? longMemory.cliCommand : '';
    if (cli === 'rebuild-all')
        parts.push('/rebuild all');
    else if (cli === 'rebuild-defs')
        parts.push('/rebuild defs');
    else if (cli)
        parts.push(cli);
    return parts.join(' ') || fallback;
}
export async function recordCfeDegradation(moduleName, kind, reason, path) {
    const entry = { at: new Date().toISOString(), kind, reason };
    if (path)
        entry.path = path;
    memoryDegradations.push(entry);
    if (!moduleName)
        return;
    try {
        const existing = await readCfeDegradations(moduleName);
        await writeCfeDegradations(moduleName, [...existing, entry]);
    }
    catch { /* best-effort: the in-memory copy still reaches the run summary */ }
}
export async function takeCfeDegradations(moduleName) {
    let items = [];
    try {
        items = await readCfeDegradations(moduleName);
    }
    catch {
        items = [];
    }
    if (!items.length)
        items = [...memoryDegradations];
    memoryDegradations.length = 0;
    try {
        await writeCfeDegradations(moduleName, []);
    }
    catch { /* leave the file if the clear fails */ }
    return items;
}
export function listPipelineRunShortNames(moduleName) {
    const project = mls.actualProject || 0;
    const folder = cfePipelineFolder(moduleName);
    const names = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== CFE_PIPELINE_TRACE_LEVEL || file.status === 'deleted')
            continue;
        if (file.extension !== '.json' || String(file.folder || '') !== folder)
            continue;
        if (file.shortName)
            names.push(String(file.shortName));
    }
    return names;
}
export async function saveCfeRunSummary(summary) {
    try {
        const project = mls.actualProject || 0;
        if (!project || !summary.moduleName)
            return null;
        const nn = nextPipelineRunNn(listPipelineRunShortNames(summary.moduleName), CFE_PIPELINE_AGENT_SLUG);
        const info = cfePipelineFileInfo(summary.moduleName, `run${nn}_${CFE_PIPELINE_AGENT_SLUG}`, project);
        const source = `${JSON.stringify({ savedAt: new Date().toISOString(), ...summary }, null, 2)}\n`;
        await writeJsonStor(info, source);
        return `l4/${info.folder}/${info.shortName}.json`;
    }
    catch {
        return null;
    }
}
function degradationsFileInfo(moduleName) {
    return cfePipelineFileInfo(moduleName, 'degradations-changefrontend', mls.actualProject || 0);
}
async function readCfeDegradations(moduleName) {
    const project = mls.actualProject || 0;
    if (!project || !moduleName)
        return [];
    const file = mls.stor.files[mls.stor.getKeyToFile(degradationsFileInfo(moduleName))];
    if (!file || file.status === 'deleted' || !file.getContent)
        return [];
    const parsed = JSON.parse(String(await file.getContent()));
    return Array.isArray(parsed?.items) ? parsed.items.filter(isDegradation) : [];
}
async function writeCfeDegradations(moduleName, items) {
    const project = mls.actualProject || 0;
    if (!project || !moduleName)
        return;
    await writeJsonStor(degradationsFileInfo(moduleName), `${JSON.stringify({ items }, null, 2)}\n`);
}
async function writeJsonStor(info, source) {
    const { createStorFile } = await import('/_102027_/l2/libStor.js');
    const key = mls.stor.getKeyToFile(info);
    let file = mls.stor.files[key];
    if (!file)
        file = await createStorFile({ ...info, source }, false, false, false);
    if (file.status !== 'renamed' && file.status !== 'new')
        file.status = 'changed';
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: source });
}
function isDegradation(value) {
    if (!value || typeof value !== 'object')
        return false;
    const record = value;
    return typeof record.kind === 'string' && typeof record.reason === 'string';
}
