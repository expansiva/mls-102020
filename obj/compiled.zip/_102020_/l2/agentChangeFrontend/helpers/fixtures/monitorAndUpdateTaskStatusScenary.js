/// <mls fileReference="_102020_/l2/agentChangeFrontend/helpers/fixtures/monitorAndUpdateTaskStatusScenary.ts" enhancement="_blank"/>
export const MONITOR_PAGE_ID = 'monitorAndUpdateTaskStatus';
export const monitorAndUpdateTaskStatusCommands = [
    {
        commandName: 'qryInspectTaskSummary',
        kind: 'query',
        accessKind: 'list',
        selection: 'single',
        outputShape: 'array',
        input: [],
    },
    {
        commandName: 'qryLocateTask',
        kind: 'query',
        accessKind: 'list',
        selection: 'single',
        outputShape: 'array',
        input: [],
    },
    {
        commandName: 'qryInspectTask',
        kind: 'query',
        accessKind: 'getById',
        selection: 'none',
        outputShape: 'object',
        input: [{ name: 'taskId', required: true, presentation: 'route', source: 'routeParam' }],
    },
    {
        commandName: 'cmdDecideTaskStatus',
        kind: 'command',
        accessKind: 'transition',
        selection: 'none',
        outputShape: 'object',
        input: [
            { name: 'taskId', required: true, presentation: 'route', source: 'routeParam' },
            { name: 'status', required: true, presentation: 'form', source: 'userInput' },
        ],
    },
];
