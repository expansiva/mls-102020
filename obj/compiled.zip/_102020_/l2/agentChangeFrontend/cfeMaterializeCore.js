/// <mls fileReference="_102020_/l2/agentChangeFrontend/cfeMaterializeCore.ts" enhancement="_blank"/>
const LAYER_RANK = {
    l2_contract: 0,
    l2_shared: 1,
    l2_page: 2,
};
export function layerRank(type) {
    return type in LAYER_RANK ? LAYER_RANK[type] : 99;
}
export function orderItems(items) {
    return [...items].sort((a, b) => (layerRank(a.type) - layerRank(b.type)
        || pageKey(a).localeCompare(pageKey(b))
        || a.id.localeCompare(b.id)
        || a.outputPath.localeCompare(b.outputPath)));
}
function pageKey(item) {
    return item.outputPath.replace(/\.ts$/, '').split('/').pop() ?? item.id;
}
export function isStale(defsMs, tsMs, dependencyMs = null) {
    if (tsMs == null)
        return true;
    if (defsMs != null && defsMs > tsMs)
        return true;
    if (dependencyMs != null && dependencyMs > tsMs)
        return true;
    return false;
}
function extractConstObject(src, name) {
    const marker = `export const ${name}`;
    const at = src.indexOf(marker);
    if (at < 0)
        return null;
    const eq = src.indexOf('=', at);
    if (eq < 0)
        return null;
    let open = eq + 1;
    while (open < src.length && /\s/.test(src[open]))
        open++;
    const openCh = src[open];
    const closeCh = openCh === '[' ? ']' : openCh === '{' ? '}' : '';
    if (!closeCh)
        return null;
    let depth = 0;
    let inStr = false;
    let strCh = '';
    let i = open;
    for (; i < src.length; i++) {
        const c = src[i];
        if (inStr) {
            if (c === '\\') {
                i++;
                continue;
            }
            if (c === strCh)
                inStr = false;
            continue;
        }
        if (c === '"' || c === "'" || c === '`') {
            inStr = true;
            strCh = c;
            continue;
        }
        if (c === openCh)
            depth++;
        else if (c === closeCh) {
            depth--;
            if (depth === 0) {
                i++;
                break;
            }
        }
    }
    try {
        return JSON.parse(src.slice(open, i));
    }
    catch {
        return null;
    }
}
function firstExportName(src) {
    const re = /export const\s+([A-Za-z0-9_$]+)\s*=/g;
    let m;
    while ((m = re.exec(src))) {
        if (m[1] !== 'pipeline')
            return m[1];
    }
    return null;
}
export function parseDefs(src) {
    const dataExportName = firstExportName(src);
    const artifact = dataExportName ? extractConstObject(src, dataExportName) : null;
    const pipelineArr = extractConstObject(src, 'pipeline');
    const item = Array.isArray(pipelineArr) && pipelineArr.length ? pipelineArr[0] : null;
    const data = artifact && typeof artifact === 'object' && !Array.isArray(artifact) && 'data' in artifact
        ? artifact.data
        : artifact;
    return { dataExportName, artifact, data, item };
}
export const GEN_TOOL_NAME = 'submitGeneratedTs';
export const GEN_TOOL = {
    type: 'function',
    function: {
        name: GEN_TOOL_NAME,
        description: 'Submit the complete generated TypeScript file content.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['code'],
            properties: {
                code: { type: 'string', description: 'Complete TypeScript file content. Must start with the MLS header.' },
            },
        },
    },
};
export const DEFAULT_MODEL_TYPE = 'codeinstruct';
export function parseModelType(systemPrompt) {
    const m = systemPrompt.match(/<!--\s*modelType:\s*([A-Za-z0-9_-]+)\s*-->/);
    return m ? m[1] : null;
}
export function buildSystemPrompt(skillSections, outputPath, modelType) {
    const skills = skillSections.length ? skillSections.join('\n\n---\n\n') : '<!-- no skill loaded -->';
    const header = mlsHeaderForOutputPath(outputPath);
    return `<!-- modelType: ${modelType} -->
<!-- x-tool-strict: true -->

You generate one L2 frontend TypeScript file from a .defs.ts definition and context files.

Target file: ${outputPath}

The file must start with:
${header}

Follow the skill instructions exactly.
Use context files as source of truth for types, imports, states, actions, handlers and message keys.
Return ONLY the file through the ${GEN_TOOL_NAME} tool.

---

${skills}`;
}
export function buildHumanPrompt(data, contextSections, outputPath) {
    const lines = ['## Definition', '', '```json', JSON.stringify(data, null, 2), '```', ''];
    if (contextSections.length) {
        lines.push('## Context files (dependsFiles)', '');
        for (const c of contextSections)
            lines.push(c, '');
    }
    lines.push('## Output', '', `Generate ONLY the TypeScript for: ${outputPath}`, `Call ${GEN_TOOL_NAME} with the complete code.`);
    return lines.join('\n');
}
export function applyHeader(outputPath, code) {
    const header = mlsHeaderForOutputPath(outputPath);
    const trimmed = code.trimStart();
    const existingHeader = /^\/\/\/\s*<mls\b[^>]*\/>\s*/;
    if (existingHeader.test(trimmed))
        return trimmed.replace(existingHeader, `${header}\n\n`);
    return `${header}\n\n${trimmed}`;
}
export function mlsHeaderForOutputPath(outputPath) {
    return `/// <mls fileReference="${outputPath}" enhancement="${headerEnhancementForOutputPath(outputPath)}"/>`;
}
export function headerEnhancementForOutputPath(outputPath) {
    if (/^_\d+_\/l2\/[^/]+\/web\/shared\/[^/]+\.ts$/.test(outputPath))
        return '_102020_/l2/enhancementAura';
    if (/^_\d+_\/l2\/[^/]+\/web\/(?:desktop|mobile)\/page\d+\/[^/]+\.ts$/.test(outputPath))
        return '_102020_/l2/enhancementAura';
    return '_blank';
}
