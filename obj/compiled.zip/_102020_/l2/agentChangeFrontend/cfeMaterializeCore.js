/// <mls fileReference="_102020_/l2/agentChangeFrontend/cfeMaterializeCore.ts" enhancement="_blank"/>
export const CONTRACTS_102029 = [
    '_102029_/l2/collabLitElement.ts',
    '_102029_/l2/bffClient.ts',
    '_102029_/l2/collabState.ts',
    '_102029_/l2/interactionRuntime.ts',
];
export function expandContextRef(ref) {
    return ref === '_102029_.d.ts' ? [...CONTRACTS_102029] : [ref];
}
const LAYER_RANK = {
    l2_contract: 0,
    l2_shared: 1,
    l2_page: 2,
};
export function layerRank(type) {
    return type in LAYER_RANK ? LAYER_RANK[type] : 99;
}
export function orderItems(items) {
    return [...items].sort((a, b) => (layerRank(a.type) - layerRank(b.type)
        || pageKey(a).localeCompare(pageKey(b))
        || a.id.localeCompare(b.id)
        || a.outputPath.localeCompare(b.outputPath)));
}
function pageKey(item) {
    return item.outputPath.replace(/\.ts$/, '').split('/').pop() ?? item.id;
}
export function isStale(defsMs, tsMs, dependencyMs = null) {
    if (tsMs == null)
        return true;
    if (defsMs != null && defsMs > tsMs)
        return true;
    if (dependencyMs != null && dependencyMs > tsMs)
        return true;
    return false;
}
function extractConstObject(src, name) {
    const marker = `export const ${name}`;
    const at = src.indexOf(marker);
    if (at < 0)
        return null;
    const eq = src.indexOf('=', at);
    if (eq < 0)
        return null;
    let open = eq + 1;
    while (open < src.length && /\s/.test(src[open]))
        open++;
    const openCh = src[open];
    const closeCh = openCh === '[' ? ']' : openCh === '{' ? '}' : '';
    if (!closeCh)
        return null;
    let depth = 0;
    let inStr = false;
    let strCh = '';
    let i = open;
    for (; i < src.length; i++) {
        const c = src[i];
        if (inStr) {
            if (c === '\\') {
                i++;
                continue;
            }
            if (c === strCh)
                inStr = false;
            continue;
        }
        if (c === '"' || c === "'" || c === '`') {
            inStr = true;
            strCh = c;
            continue;
        }
        if (c === openCh)
            depth++;
        else if (c === closeCh) {
            depth--;
            if (depth === 0) {
                i++;
                break;
            }
        }
    }
    try {
        return JSON.parse(src.slice(open, i));
    }
    catch {
        return null;
    }
}
function firstExportName(src) {
    const re = /export const\s+([A-Za-z0-9_$]+)\s*=/g;
    let m;
    while ((m = re.exec(src))) {
        if (m[1] !== 'pipeline')
            return m[1];
    }
    return null;
}
export function parseDefs(src) {
    const dataExportName = firstExportName(src);
    const artifact = dataExportName ? extractConstObject(src, dataExportName) : null;
    const pipelineArr = extractConstObject(src, 'pipeline');
    const item = Array.isArray(pipelineArr) && pipelineArr.length ? pipelineArr[0] : null;
    const data = artifact && typeof artifact === 'object' && !Array.isArray(artifact) && 'data' in artifact
        ? artifact.data
        : artifact;
    return { dataExportName, artifact, data, item };
}
export const GEN_TOOL_NAME = 'submitGeneratedTs';
export const GEN_TOOL = {
    type: 'function',
    function: {
        name: GEN_TOOL_NAME,
        description: 'Submit the complete generated TypeScript file content.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['code'],
            properties: {
                code: { type: 'string', description: 'Complete TypeScript file content. Must start with the MLS header.' },
            },
        },
    },
};
export const DEFAULT_MODEL_TYPE = 'codeinstruct';
export const MATERIALIZE_REPAIR_ATTEMPTS = 1;
export function parseModelType(systemPrompt) {
    const m = systemPrompt.match(/<!--\s*modelType:\s*([A-Za-z0-9_-]+)\s*-->/);
    return m ? m[1] : null;
}
export function buildSystemPrompt(skillSections, outputPath, modelType) {
    const skills = skillSections.length ? skillSections.join('\n\n---\n\n') : '<!-- no skill loaded -->';
    const header = mlsHeaderForOutputPath(outputPath);
    return `<!-- modelType: ${modelType} -->
<!-- x-tool-strict: true -->

You generate one L2 frontend TypeScript file from a .defs.ts definition and context files.

Target file: ${outputPath}

The file must start with:
${header}

Follow the skill instructions exactly.
Use context files as source of truth for types, imports, states, actions, handlers and message keys.
The generated file is checked with TypeScript strict null checks and no implicit any.
Annotate callback parameters, avoid nullable assignments without guards, and do not rely on implicit any.
Return ONLY the file through the ${GEN_TOOL_NAME} tool.

---

${skills}`;
}
export function buildHumanPrompt(data, contextSections, outputPath, repairHint) {
    const lines = ['## Definition', '', '```json', JSON.stringify(data, null, 2), '```', ''];
    if (contextSections.length) {
        lines.push('## Context files (dependsFiles)', '');
        for (const c of contextSections)
            lines.push(c, '');
    }
    lines.push('## Output', '', `Generate ONLY the TypeScript for: ${outputPath}`, `Call ${GEN_TOOL_NAME} with the complete code.`);
    if (repairHint)
        lines.push('', repairHint);
    return lines.join('\n');
}
export function buildMissingCodeRepairHint(outputPath, detail) {
    return [
        '## Repair',
        `The previous attempt did not produce a complete tool response for ${outputPath}.`,
        detail ? `Reason: ${detail}` : '',
        `Return ONLY the ${GEN_TOOL_NAME} tool call with the COMPLETE TypeScript file.`,
        'Do not write analysis, markdown or partial code before calling the tool.',
    ].filter(Boolean).join('\n');
}
export function buildCompileRepairHint(outputPath, errors) {
    return [
        '## Repair',
        `The previous generated file for ${outputPath} failed TypeScript checking.`,
        '',
        'Compiler errors:',
        '```text',
        errors.slice(0, 20).join('\n'),
        '```',
        '',
        `Return the COMPLETE corrected TypeScript file through the ${GEN_TOOL_NAME} tool.`,
        'Fix exactly these syntax/type errors while preserving the .defs.ts contract and the existing context.',
    ].join('\n');
}
export function applyHeader(outputPath, code) {
    const header = mlsHeaderForOutputPath(outputPath);
    const trimmed = code.trimStart();
    const existingHeader = /^\/\/\/\s*<mls\b[^>]*\/>\s*/;
    if (existingHeader.test(trimmed))
        return trimmed.replace(existingHeader, `${header}\n\n`);
    return `${header}\n\n${trimmed}`;
}
export function testPathForOutputPath(outputPath) {
    return outputPath.replace(/\.ts$/, '.test.ts');
}
export function buildMaterializeTypecheckTest(item, data) {
    if (item.type === 'l2_contract')
        return buildContractTypecheckTest(item.outputPath, data);
    if (item.type === 'l2_shared')
        return buildSharedTypecheckTest(item.outputPath, data);
    return null;
}
export function mlsHeaderForOutputPath(outputPath) {
    return `/// <mls fileReference="${outputPath}" enhancement="${headerEnhancementForOutputPath(outputPath)}"/>`;
}
export function headerEnhancementForOutputPath(outputPath) {
    if (/^_\d+_\/l2\/[^/]+\/web\/shared\/[^/]+\.ts$/.test(outputPath))
        return '_102020_/l2/enhancementAura';
    if (/^_\d+_\/l2\/[^/]+\/web\/(?:desktop|mobile)\/page\d+\/[^/]+\.ts$/.test(outputPath))
        return '_102020_/l2/enhancementAura';
    return '_blank';
}
function buildContractTypecheckTest(outputPath, data) {
    if (!Array.isArray(data))
        return null;
    const moduleName = moduleNameFromOutputPath(outputPath);
    if (!moduleName)
        return null;
    const modulePrefix = toPascalCase(moduleName);
    const imports = new Set();
    const declarations = [];
    const assertions = [];
    for (const command of data) {
        if (!isRecord(command) || typeof command.commandName !== 'string')
            continue;
        const commandName = command.commandName;
        const commandPrefix = `${modulePrefix}${toPascalCase(commandName)}`;
        const inputName = `${commandPrefix}Input`;
        const outputName = `${commandPrefix}Output`;
        const outputItemName = `${commandPrefix}OutputItem`;
        const isQuery = command.kind === 'query';
        const outputShape = commandOutputShape(command);
        const inputFields = Array.isArray(command.input) ? command.input.filter(isRecord) : [];
        const outputFields = Array.isArray(command.output) ? command.output.filter(isRecord) : [];
        imports.add(inputName);
        imports.add(outputName);
        if (isQuery)
            imports.add(outputItemName);
        const expectedInputName = `Expected${inputName}`;
        const expectedOutputName = `Expected${outputName}`;
        const expectedOutputItemName = `Expected${outputItemName}`;
        declarations.push(`type ${expectedInputName} = ${objectType(inputFields, 'input')};`);
        assertions.push(`type ${assertName(inputName, commandName)} = Assert<Equal<${inputName}, ${expectedInputName}>>;`);
        if (isQuery) {
            declarations.push(`type ${expectedOutputItemName} = ${objectType(outputFields, 'output')};`);
            if (outputShape === 'paginated') {
                declarations.push(`type ${expectedOutputName} = { items: ${expectedOutputItemName}[]; total: number; page?: number; pageSize?: number; };`);
            }
            else if (outputShape === 'object') {
                declarations.push(`type ${expectedOutputName} = ${expectedOutputItemName};`);
            }
            else {
                declarations.push(`type ${expectedOutputName} = ${expectedOutputItemName}[];`);
            }
            assertions.push(`type ${assertName(outputItemName, commandName)} = Assert<Equal<${outputItemName}, ${expectedOutputItemName}>>;`);
            assertions.push(`type ${assertName(outputName, commandName)} = Assert<Equal<${outputName}, ${expectedOutputName}>>;`);
        }
        else {
            declarations.push(`type ${expectedOutputName} = ${objectType(outputFields, 'output')};`);
            assertions.push(`type ${assertName(outputName, commandName)} = Assert<Equal<${outputName}, ${expectedOutputName}>>;`);
        }
    }
    if (!imports.size)
        return null;
    const testPath = testPathForOutputPath(outputPath);
    return [
        mlsHeaderForOutputPath(testPath),
        '',
        `import type { ${[...imports].sort().join(', ')} } from './${fileBaseName(outputPath)}.js';`,
        '',
        'type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;',
        'type Assert<T extends true> = T;',
        '',
        '// This file is generated from .defs.ts so tsc catches contract drift in the generated .ts.',
        ...declarations,
        '',
        ...assertions,
        '',
        'export {};',
    ].join('\n');
}
function buildSharedTypecheckTest(outputPath, data) {
    if (!isRecord(data))
        return null;
    const moduleName = typeof data.moduleName === 'string' ? data.moduleName : moduleNameFromOutputPath(outputPath);
    const pageId = typeof data.pageId === 'string' ? data.pageId : fileBaseName(outputPath);
    if (!moduleName || !pageId)
        return null;
    const className = `${toPascalCase(moduleName)}${toPascalCase(pageId)}Base`;
    const stateAssertions = [];
    const actionAssertions = [];
    const contractImports = new Map();
    const states = Array.isArray(data.states) ? data.states.filter(isRecord) : [];
    for (const state of states) {
        const propertyName = typeof state.name === 'string' && state.name ? state.name : camelCaseFromKey(String(state.stateKey ?? ''));
        if (!propertyName)
            continue;
        const expectedType = stateAssertionType(state, sharedStateContractType(outputPath, data, state, contractImports));
        stateAssertions.push(`type ${assertName(`State_${propertyName}`, propertyName)} = Assert<Assignable<typeof page${propertyAccess(propertyName)}, ${expectedType}>>;`);
    }
    const actions = Array.isArray(data.actions) ? data.actions.filter(isRecord) : [];
    for (const action of actions) {
        if (typeof action.methodName === 'string' && action.methodName) {
            const fnType = action.kind === 'query' || action.kind === 'command' ? '(...args: any[]) => Promise<void>' : '(...args: any[]) => void';
            actionAssertions.push(`type ${assertName(`Action_${action.methodName}`, action.methodName)} = Assert<Assignable<typeof page${propertyAccess(action.methodName)}, ${fnType}>>;`);
        }
        if (typeof action.handlerName === 'string' && action.handlerName) {
            actionAssertions.push(`type ${assertName(`Handler_${action.handlerName}`, action.handlerName)} = Assert<Assignable<typeof page${propertyAccess(action.handlerName)}, (...args: any[]) => void>>;`);
        }
    }
    if (!stateAssertions.length && !actionAssertions.length)
        return null;
    const testPath = testPathForOutputPath(outputPath);
    return [
        mlsHeaderForOutputPath(testPath),
        '',
        `import type { ${className} } from './${fileBaseName(outputPath)}.js';`,
        ...contractImportLines(contractImports),
        '',
        'type IsAny<T> = 0 extends (1 & T) ? true : false;',
        'type Assignable<Actual, Expected> = IsAny<Actual> extends true ? false : [Actual] extends [Expected] ? true : false;',
        'type Assert<T extends true> = T;',
        '',
        `declare const page: ${className};`,
        '',
        '// This file is generated from .defs.ts. Add narrower state/action assertions here as materialization rules evolve.',
        ...stateAssertions,
        ...actionAssertions,
        '',
        'export {};',
    ].join('\n');
}
function objectType(fields, direction) {
    if (fields.length === 0)
        return '{}';
    const lines = ['{'];
    for (const field of fields) {
        const name = typeof field.name === 'string' && field.name ? field.name : null;
        if (!name)
            continue;
        const optional = direction === 'input' ? field.required !== true : field.required === false;
        lines.push(`  ${propertyKey(name)}${optional ? '?' : ''}: ${fieldType(field)};`);
    }
    lines.push('}');
    return lines.join('\n');
}
function fieldType(field) {
    if (Array.isArray(field.enum) && field.enum.length > 0 && field.enum.every(item => typeof item === 'string')) {
        return field.enum.map(item => JSON.stringify(item)).join(' | ');
    }
    const rawType = String(field.type ?? 'unknown').trim();
    const t = rawType.toLowerCase();
    if (t.endsWith('[]'))
        return `${primitiveType(t.slice(0, -2))}[]`;
    if (t === 'array' || t === 'list')
        return 'unknown[]';
    return primitiveType(t);
}
function primitiveType(type) {
    if (['string', 'uuid', 'guid', 'email', 'url', 'uri', 'date', 'datetime', 'date-time', 'time', 'timestamp', 'timestamptz'].includes(type))
        return 'string';
    if (['number', 'integer', 'int', 'int32', 'int64', 'float', 'double', 'decimal', 'money', 'currency'].includes(type))
        return 'number';
    if (type === 'boolean' || type === 'bool')
        return 'boolean';
    if (type === 'json' || type === 'object' || type === 'any' || type === 'unknown')
        return 'unknown';
    return 'unknown';
}
function stateAssertionType(state, contractType) {
    const types = [];
    if (Array.isArray(state.valueSet) && state.valueSet.length > 0 && state.valueSet.every(item => typeof item === 'string')) {
        types.push(...state.valueSet.map(item => JSON.stringify(item)));
    }
    else if (state.collection === true || Array.isArray(state.defaultValue)) {
        types.push('unknown[]');
    }
    else {
        const value = state.defaultValue;
        if (typeof value === 'number')
            types.push('number');
        else if (typeof value === 'boolean')
            types.push('boolean');
        else if (typeof value === 'string')
            types.push('string');
        else
            types.push('unknown');
    }
    if (contractType) {
        if (types.length === 1 && types[0] === 'unknown')
            types[0] = contractType;
        else
            types.push(contractType);
    }
    // A state initialized with null (the async-loaded contract data pattern: `T | null = null`)
    // is nullable, so the expected type must include null — otherwise Assignable<T | null, T>
    // fails with TS2344 on EVERY contract state (cafeFlow bug_changeFrontend1). 'unknown' already
    // absorbs null, so skip in that case.
    if ((state.defaultValue === null || state.nullable === true) && !types.includes('unknown')) {
        types.push('null');
    }
    return uniqueTypeUnion(types);
}
function sharedStateContractType(outputPath, data, state, imports) {
    const ref = isRecord(state.contractRef) ? state.contractRef : null;
    if (!ref || (ref.direction !== 'input' && ref.direction !== 'output'))
        return null;
    const commandName = typeof ref.commandName === 'string' && ref.commandName ? ref.commandName : null;
    const moduleName = typeof data.moduleName === 'string' && data.moduleName ? data.moduleName : moduleNameFromOutputPath(outputPath);
    const contractPath = sharedContractTsPath(outputPath, data);
    if (!commandName || !moduleName || !contractPath)
        return null;
    const inputType = `${toPascalCase(moduleName)}${toPascalCase(commandName)}Input`;
    const outputType = `${toPascalCase(moduleName)}${toPascalCase(commandName)}Output`;
    const importPath = relativeJsImportPath(outputPath, contractPath);
    const names = imports.get(importPath) ?? new Set();
    if (ref.direction === 'output') {
        names.add(outputType);
        imports.set(importPath, names);
        return outputType;
    }
    const field = typeof ref.field === 'string' && ref.field ? ref.field : null;
    if (!field)
        return null;
    names.add(inputType);
    imports.set(importPath, names);
    return `${inputType}[${JSON.stringify(field)}]`;
}
function commandOutputShape(command) {
    if (command.outputShape === 'paginated')
        return 'paginated';
    if (command.outputShape === 'object')
        return 'object';
    return 'array';
}
function sharedContractTsPath(outputPath, data) {
    const ref = isRecord(data.contractRef) ? data.contractRef : null;
    if (ref && typeof ref.tsPath === 'string' && ref.tsPath)
        return ref.tsPath;
    if (outputPath.includes('/web/shared/'))
        return outputPath.replace('/web/shared/', '/web/contracts/');
    return null;
}
function contractImportLines(imports) {
    return [...imports.entries()]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([importPath, names]) => `import type { ${[...names].sort().join(', ')} } from '${importPath}';`);
}
function relativeJsImportPath(fromPath, toPath) {
    const fromParts = fromPath.split('/');
    fromParts.pop();
    const toParts = toPath.replace(/\.ts$/, '.js').split('/');
    let i = 0;
    while (i < fromParts.length && i < toParts.length && fromParts[i] === toParts[i])
        i++;
    const parts = [...Array(fromParts.length - i).fill('..'), ...toParts.slice(i)];
    const rel = parts.join('/') || '.';
    return rel.startsWith('.') ? rel : `./${rel}`;
}
function uniqueTypeUnion(types) {
    if (types.includes('unknown'))
        return 'unknown';
    return [...new Set(types)].join(' | ') || 'unknown';
}
function moduleNameFromOutputPath(outputPath) {
    const match = /^_\d+_\/l2\/([^/]+)\//.exec(outputPath);
    return match ? match[1] : null;
}
function fileBaseName(outputPath) {
    const filename = outputPath.split('/').pop() ?? outputPath;
    return filename.replace(/\.ts$/, '');
}
function toPascalCase(value) {
    return value
        .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
        .split(/[^A-Za-z0-9]+/)
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join('');
}
function camelCaseFromKey(value) {
    const parts = value.split(/[^A-Za-z0-9]+/).filter(Boolean);
    if (!parts.length)
        return '';
    const [first, ...rest] = parts;
    return first.charAt(0).toLowerCase() + first.slice(1) + rest.map(toPascalCase).join('');
}
function propertyKey(value) {
    return /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(value) ? value : JSON.stringify(value);
}
function propertyAccess(value) {
    return /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(value) ? `.${value}` : `[${JSON.stringify(value)}]`;
}
function assertName(rawName, fallback) {
    const clean = rawName.replace(/[^A-Za-z0-9_$]+/g, '_').replace(/^([^A-Za-z_$])/, '_$1');
    return `_${clean || toPascalCase(fallback)}`;
}
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
