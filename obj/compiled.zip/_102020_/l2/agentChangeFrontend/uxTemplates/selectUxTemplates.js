/// <mls fileReference="_102020_/l2/agentChangeFrontend/uxTemplates/selectUxTemplates.ts" enhancement="_blank"/>
import { uxTemplates, uxTemplateRegistry } from "/_102020_/l2/agentChangeFrontend/uxTemplates/index.defs.js";
// Journey workspace.kind is a free string; map common spellings to the UxWorkspaceKind enum.
const WORKSPACE_KIND_ALIASES = {
    entitymanagement: "entityManagement",
    entity: "entityManagement",
    management: "entityManagement",
    crud: "entityManagement",
    workflow: "workflow",
    process: "workflow",
    lifecycle: "workflow",
    dashboard: "dashboard",
    report: "report",
    reporting: "report",
    adjustment: "adjustment",
    detail: "detail",
    form: "form",
    calendar: "calendar",
    schedule: "calendar",
};
function normalizeWorkspaceKind(raw) {
    const key = String(raw || "").trim().toLowerCase();
    return WORKSPACE_KIND_ALIASES[key] || String(raw || "").trim();
}
function overlapRatio(derived, templateValues) {
    if (derived.length === 0 || templateValues.length === 0)
        return 0;
    const set = new Set(templateValues.map(value => value.toLowerCase()));
    const hits = derived.filter(value => set.has(value.toLowerCase())).length;
    return hits / derived.length;
}
function includesInsensitive(values, target) {
    if (!target)
        return false;
    return values.map(value => value.toLowerCase()).includes(target.toLowerCase());
}
// Deterministic weighted score of a template against derived signals.
function scoreTemplate(template, signals) {
    const applies = template.appliesWhen;
    const workspaceKind = normalizeWorkspaceKind(signals.workspaceKind);
    const workspaceMatch = includesInsensitive(applies.workspaceKinds, workspaceKind) ? 1 : 0;
    const accessMatch = overlapRatio(signals.accessPatterns, applies.accessPatterns);
    const operationMatch = overlapRatio(signals.operationKinds, applies.operationKinds);
    const selectionMatch = includesInsensitive(applies.selection, signals.selection) ? 1 : 0;
    // Workspace kind is the strongest structural signal, then access pattern and operations.
    const score = 0.4 * workspaceMatch + 0.25 * accessMatch + 0.25 * operationMatch + 0.1 * selectionMatch;
    return Math.max(0, Math.min(1, score));
}
function toCandidate(template, score, threshold) {
    return {
        id: template.id,
        title: template.title,
        score: Number(score.toFixed(3)),
        highConfidence: score >= threshold,
        userJourney: template.userJourney,
        layoutGuidance: template.layoutGuidance,
        llmGuidance: template.llmGuidance,
        validationChecks: template.validationChecks,
        wiring: template.wiring || deriveWiring(template),
        appliesWhen: template.appliesWhen,
        rejectsWhen: template.rejectsWhen,
    };
}
function deriveWiring(template) {
    const actionKinds = Object.keys(template.slots.actionPresentation);
    const hasSelection = template.appliesWhen.selection.some(selection => selection !== 'none')
        || template.slots.contextualInputs.includes('selectedEntity');
    const hasDraft = template.appliesWhen.accessPatterns.includes('commandInput')
        || actionKinds.some(kind => ['create', 'update', 'adjust', 'command'].includes(kind));
    const hasMutation = actionKinds.some(kind => kind !== 'query' && kind !== 'view');
    return {
        minimumStates: [
            ...(hasSelection ? ['selectedId'] : []),
            ...(hasDraft ? ['formDraft'] : []),
            'loading',
            ...(hasMutation ? ['mutationFeedback'] : []),
        ],
        transitions: [
            ...(hasSelection && hasDraft ? ['rowSelect->selectedId->prepopulateDraft'] : []),
            ...(hasMutation ? ['submit->textualFeedback->refresh->clearFormAndSelection'] : []),
        ],
        microcopy: {
            actionLabels: 'domainAction',
            emptyState: 'nextStep',
            mutationFeedback: 'textualDismissible',
        },
    };
}
// Deterministic fallback when nothing scores: a form-ish screen gets single_form, otherwise
// tabular_classic. Guarantees at least one candidate so page generation never stalls.
function fallbackTemplate(signals) {
    const wantsForm = !signals.hasQueryList
        && signals.operationKinds.some(kind => ["create", "update", "adjust"].includes(kind.toLowerCase()));
    const preferredId = wantsForm ? "single_form" : "tabular_classic";
    return uxTemplates.find(template => template.id === preferredId) || uxTemplates[0];
}
// Ranked candidates (up to maxRecommendedTemplates). Never empty.
export function selectUxTemplateCandidates(signals, limit) {
    const threshold = uxTemplateRegistry.selectionPolicy.highConfidenceThreshold;
    const max = Math.max(1, limit ?? uxTemplateRegistry.selectionPolicy.maxRecommendedTemplates);
    const scored = uxTemplates
        .map(template => ({ template, score: scoreTemplate(template, signals) }))
        .filter(entry => entry.score > 0)
        .sort((a, b) => b.score - a.score);
    if (scored.length === 0) {
        const fallback = fallbackTemplate(signals);
        return [toCandidate(fallback, 0, threshold)];
    }
    return scored.slice(0, max).map(entry => toCandidate(entry.template, entry.score, threshold));
}
