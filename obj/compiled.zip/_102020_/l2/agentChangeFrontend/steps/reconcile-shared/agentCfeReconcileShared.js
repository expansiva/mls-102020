/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/reconcile-shared/agentCfeReconcileShared.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, parseCreatePageArgs, reconcileCreateRunPage } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeReconcileShared',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/reconcile-shared',
        agentDescription: 'Reconcile saved page layout variants into one shared defs artifact',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const { moduleName, pageId, runId } = parseArgs(args || step.prompt);
        await reconcileCreateRunPage(runId, pageId, moduleName);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed')];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}] ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `CREATE-SHARED-RECONCILE-FAILED: ${message}`)];
    }
}
function parseArgs(value) {
    const { moduleName, pageId } = parseCreatePageArgs(value);
    const parsed = JSON.parse(value || '{}');
    const runId = typeof parsed.runId === 'string' ? parsed.runId : '';
    if (!runId)
        throw new Error('missing create execution runId');
    return { moduleName, pageId, runId };
}
