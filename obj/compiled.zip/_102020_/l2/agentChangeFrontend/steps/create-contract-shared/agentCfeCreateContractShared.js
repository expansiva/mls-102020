/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/create-contract-shared/agentCfeCreateContractShared.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, parseCreatePageArgs, prepareCreateRunPage, saveBaseSharedDefs, saveContractDefs } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeCreateContractShared',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/create-contract-shared',
        agentDescription: 'Create one page contract and base shared defs without an LLM call',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const { pageId, runId } = parseArgs(args || step.prompt);
        const prepared = await prepareCreateRunPage(runId, pageId);
        await saveContractDefs(prepared);
        await saveBaseSharedDefs(prepared);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed')];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}] ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `CREATE-CONTRACT-SHARED-FAILED: ${message}`)];
    }
}
function parseArgs(value) {
    const { pageId } = parseCreatePageArgs(value);
    const parsed = JSON.parse(value || '{}');
    const runId = typeof parsed.runId === 'string' ? parsed.runId : '';
    if (!runId)
        throw new Error('missing create execution runId');
    return { pageId, runId };
}
