/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/materialize/agentCfeMaterializeGen.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readMaterializeItemFindings } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
import { applyHeader, bindingCommandsOf, buildCompileRepairHint, collectChartEventIssues, collectPageTemplateHygieneIssues, buildContextSection, buildMaterializeTypecheckTest, buildHumanPrompt, buildMissingCodeRepairHint, buildRuntimeDtsSection, buildSharedDtsSection, buildSystemPrompt, checkSharedDtsProvenance, stampSharedDtsArtifact, CONTRACTS_102029, DEFAULT_MODEL_TYPE, expandContextRef, GEN_TOOL, GEN_TOOL_NAME, isSplitWorthyFailure, isSharedDtsArtifactRef, isSharedRuntimeTsRef, sharedTsRefOfDtsArtifact, parseDefs, normalizeGeneratedCode, sharedDtsArtifactRef, testPathForOutputPath, trimDefinitionForPrompt, trimSharedI18nForPageContext, } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeCore.js';
import { compileAndGetErrors, compileMlsPathAndGetErrors, consumeMaterializeStudioMessages, extractToolCallArgs, formatGeneratedTsInStudio, getCompiledDtsByMlsPath, releaseBorrowedModelScope, preloadItemTypecheckDeps, getContentByMlsPath, parseMlsPath, saveArtifactTextByMlsPath, saveGeneratedTs, saveGeneratedTsByMlsPath, } from '/_102020_/l2/agentChangeFrontend/helpers/cfeMaterializeStudio.js';
// Deterministic l2_shared renderer (pure, import-free). Wired here so the Studio path stops paying the
// LLM — and stops hitting its output cap — for a file that is a mechanical projection of the defs.
import { ensureSharedScenaryMembers, generateSharedScaffold, sharedLlmFallbackTemplate } from '/_102020_/l2/agentChangeFrontend/helpers/cfeSharedScaffold.js';
import { buildPageSkeleton, markMissingOrganisms, organismFileRef } from '/_102020_/l2/agentChangeFrontend/helpers/cfePageSkeleton.js';
import { buildSplitPlan } from '/_102020_/l2/agentChangeFrontend/helpers/cfePageSplitPlan.js';
import { cfePipelineTraceMlsPath, recordCfeDegradation } from '/_102020_/l2/agentChangeFrontend/helpers/cfePipelineTrace.js';
const AGENT_NAME = 'agentCfeMaterializeGen';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/materialize',
        agentDescription: 'Generate one frontend L2 .ts file from an agentChangeFrontend .defs.ts pipeline item',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        if (!args)
            throw new Error('missing args');
        const genArgs = parseGenStepArgs(args);
        const genContext = await buildGenContext(genArgs.defPath, genArgs.itemId);
        // l2_shared is a MECHANICAL projection of defs + contract — no judgement is needed (see
        // steps/materialize/CHANGELOG 28/jul). Try the deterministic scaffold FIRST and skip the model
        // entirely when it succeeds. This is what kills the output-size wall: projectDetailWorkspace needs a
        // ~55k-token file in ONE tool call and the LLM path died with MAX_TOKENS_REACHED at 50000 after
        // 11m39s ($0.30), failing the whole task. The scaffold returns {code:null, reason} on any defs shape
        // it does not model, and then we fall through to the LLM exactly as before.
        let sharedTemplate;
        if (genContext.pipelineItem.type === 'l2_shared') {
            const deterministic = await materializeSharedDeterministic(context, parentStep, step, hookSequential, genContext.pipelineItem, genContext.definitionData, genArgs.attempt ?? 1);
            if (deterministic)
                return deterministic;
            // LLM fallback: send the scaffold (or the scenary block if the scaffold bailed) so the model
            // does not write the shared from scratch and drop setUiScenary / applyUrlScenary.
            sharedTemplate = await sharedTemplateForLlm(genContext.pipelineItem, genContext.definitionData);
        }
        // Repair rounds (attempt >= 2) arrive as fan-out slots carrying only compact refs — the
        // compiler errors are recomputed from disk HERE and injected into the LLM input (cleaned
        // later by the interaction cleaner), never persisted in a step prompt/args (DynamoDB 400KB
        // cap; skills/collab_messages.md "Interaction cleaner").
        const repairHint = (genArgs.attempt ?? 1) >= 2
            ? genArgs.repairHint ?? await computeRepairHint(genContext.pipelineItem, genArgs.planId, genArgs.attempt ?? 2)
            : undefined;
        // Deterministic page skeleton (i18n.md §4) — same helper the CLI uses, so both surfaces emit the
        // identical file shape. Only on the first attempt (see createPromptReadyIntent).
        const skeleton = repairHint ? undefined : await pageSkeletonFor(genContext.pipelineItem, genContext.siblings, genContext.definitionData);
        return [createPromptReadyIntent(context, parentStep, hookSequential, args, genContext, repairHint, skeleton, sharedTemplate)];
    }
    catch (error) {
        const message = formatError('beforePromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkFailureStatus(context, parentStep, step, hookSequential, isRepairRun(args || step.prompt), message)];
    }
}
/**
 * Deterministic l2_shared materialization (no LLM). Returns the intents that COMPLETE the step when the
 * scaffold produced the file, or null to fall through to the LLM (no contract in reach, scaffold bailed,
 * or the generated file did not compile — the model still gets its chance).
 *
 * Persists exactly what the LLM path persists (same .ts save, same typecheck test, same compile gate,
 * same shared .d.ts artifact), so nothing downstream can tell the two apart.
 */
async function materializeSharedDeterministic(context, parentStep, step, hookSequential, pipelineItem, definitionData, attempt) {
    try {
        const contractTsPath = isRecord(definitionData) && isRecord(definitionData.contractRef) && typeof definitionData.contractRef.tsPath === 'string'
            ? definitionData.contractRef.tsPath
            : '';
        const contractSource = contractTsPath ? await getContentByMlsPath(contractTsPath) : null;
        if (!contractSource)
            return null;
        // The .ts being overwritten is passed so existing translations survive: the scaffold emits every
        // declared locale, and regenerating used to reset them all to the default language (i18n.md item 4).
        const previousSource = await getContentByMlsPath(pipelineItem.outputPath);
        const scaffold = generateSharedScaffold(pipelineItem.outputPath, definitionData, contractSource, previousSource ?? undefined);
        if (!scaffold.code) {
            await recordCfeDegradation(moduleOfMlsPath(pipelineItem.outputPath), 'scaffold-bail', String(scaffold.reason || 'unknown'), pipelineItem.outputPath);
            return null;
        }
        // A REPAIR round whose scaffold reproduces the file already on disk has nothing to repair with: the
        // scaffold is a pure function of defs + contract, so re-saving its own output re-earns the finding
        // that opened the round and the budget drains one useless round at a time. Hand it to the model,
        // which does get the file and the findings. Byte-equality only — anything else keeps today's path.
        // (Silent: the absence of the 'deterministic scaffold' trace on the step IS the signal, and the
        // console guard keeps run-path prints to the ones already declared.)
        if (attempt >= 2 && previousSource === scaffold.code)
            return null;
        const parsed = parseMlsPath(pipelineItem.outputPath);
        if (!parsed)
            return null;
        consumeMaterializeStudioMessages();
        const guarded = ensureSharedScenaryMembers(scaffold.code, pipelineItem.outputPath, definitionData, contractSource);
        const saved = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, guarded.code);
        if (!saved)
            return null;
        const typecheckTest = buildMaterializeTypecheckTest(pipelineItem, definitionData);
        const typecheckPath = typecheckTest ? testPathForOutputPath(pipelineItem.outputPath) : null;
        if (typecheckPath && typecheckTest && !await saveGeneratedTsByMlsPath(typecheckPath, typecheckTest))
            return null;
        // The contract model was disposed as soon as the contract phase compiled it, so the shared —
        // which imports `/_<proj>_/l2/<module>/web/contracts/<pageId>.js` — could not resolve its own
        // import and every scaffold failed the gate with a FALSE TS2792, falling back to the LLM for 34
        // files that were already correct. Load it back first; best-effort, never blocking.
        // The model stays alive on purpose: it is what the shared resolves against for the rest of the
        // phase, and it is bounded (one per contract).
        try {
            await getCompiledDtsByMlsPath(contractTsPath);
        }
        catch { /* best-effort */ }
        const compileErrors = [
            ...await compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName),
            ...(typecheckPath ? await compileMlsPathAndGetErrors(typecheckPath) : []),
        ];
        if (compileErrors.length > 0) {
            // The scaffold is deterministic, so a compile error here is a defs/contract mismatch it could not
            // see. Hand the item to the LLM instead of failing: the file on disk is overwritten by its output.
            await recordCfeDegradation(moduleOfMlsPath(pipelineItem.outputPath), 'scaffold-compile-bail', compileErrors[0], pipelineItem.outputPath);
            return null;
        }
        await persistSharedDtsArtifact(pipelineItem.outputPath);
        // ONLY on the success path. The contract preloaded above is this item's own (one per shared) and has
        // no reader once the compiles are done — but a `return null` above falls through to the LLM path IN
        // THIS SAME HOOK, whose compile (afterPromptStep) resolves the shared against that very contract
        // model and has no preload of its own. Releasing on a bail exit would recreate the false TS2792 that
        // T2 fixed; those borrows go back at the verify boundary instead. Queued, not disposed —
        // `activeCompiles` still decides.
        releaseBorrowedModelScope();
        const studioDiagnostics = consumeMaterializeStudioMessages();
        const trace = `deterministic scaffold: ${scaffold.code.length}b, no LLM call${typecheckPath ? ' + typecheck test' : ''}`;
        return [mkStatus(context, parentStep, step, hookSequential, 'completed', studioDiagnostics.length ? `${trace}. ${formatStudioDiagnostics(studioDiagnostics)}` : trace, 'input_output')];
    }
    catch (error) {
        await recordCfeDegradation(moduleOfMlsPath(pipelineItem.outputPath), 'scaffold-exception-bail', formatError('materializeSharedDeterministic', error), pipelineItem.outputPath);
        return null;
    }
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        consumeMaterializeStudioMessages();
        const genArgs = parseGenStepArgs(step.prompt);
        // attempt >= 2 marks a REPAIR fan-out slot (queued by the phase verify step with compact
        // refs only; the compiler errors were recomputed in beforePromptStep). attempt undefined
        // marks a first-pass fan-out slot.
        const repairRun = (genArgs.attempt ?? 1) >= 2;
        const { defPath } = genArgs;
        const defsContent = defPath ? await getContentByMlsPath(defPath) : null;
        const parsedDefs = defsContent ? parseDefs(defsContent) : null;
        // Resolve by itemId, exactly as beforePromptStep does. A defs can hold N items (a split page), and
        // taking item[0] here would save every slot's output over the FIRST organism's file.
        const pipelineItem = (genArgs.itemId ? parsedDefs?.items.find(candidate => candidate.id === genArgs.itemId) : null) ?? parsedDefs?.item;
        if (!pipelineItem) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, `pipeline item not found in defs: ${genArgs.itemId ?? '(first)'} @ ${defPath || '(missing defPath)'}`)];
        }
        const raw = step.interaction?.payload?.[0];
        const output = extractToolCallArgs(raw, GEN_TOOL_NAME);
        if (!output?.code) {
            const detail = `missing generated code; payload=${describePayload(raw)}`;
            // The output cap is not repairable but it IS plannable: persist the split plan now, so the phase
            // verify can turn it into organism steps instead of burning repair rounds (paginaDividida.md §4.1).
            // Cap or timeout: both mean the page does not fit in one call, and both are fixed by a split.
            if (isSplitWorthyFailure(describePayload(raw))) {
                await writeSplitPlanFromL4(pipelineItem, parsedDefs?.data, detail, parsedDefs?.bindings);
            }
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, detail, true)];
        }
        const parsed = parseMlsPath(pipelineItem.outputPath);
        if (!parsed) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, `invalid outputPath: ${pipelineItem.outputPath}`)];
        }
        // Formatted BEFORE the textual gates below and before the save, so the hygiene checks, the
        // compile and the phase verify (which re-reads from disk) all see exactly the bytes that were
        // written — the safe order the format×gates contract requires (cf_format_codigo_gerado).
        const formatted = await formatGeneratedTsInStudio(applyHeader(pipelineItem.outputPath, normalizeGeneratedCode(pipelineItem, parsedDefs?.data, output.code)));
        const sharedGuard = pipelineItem.type === 'l2_shared'
            ? await applySharedScenaryGuard(pipelineItem, parsedDefs?.data, formatted)
            : { code: formatted, injected: false, original: formatted };
        const saved = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, sharedGuard.code);
        if (!saved) {
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(`saveGeneratedTs failed for ${pipelineItem.outputPath}`))];
        }
        const typecheckTest = buildMaterializeTypecheckTest(pipelineItem, parsedDefs ? parsedDefs.data : null);
        const typecheckPath = typecheckTest ? testPathForOutputPath(pipelineItem.outputPath) : null;
        if (typecheckPath && typecheckTest) {
            const testSaved = await saveGeneratedTsByMlsPath(typecheckPath, typecheckTest);
            if (!testSaved) {
                return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(`saveGeneratedTs failed for ${typecheckPath}`))];
            }
        }
        // Same reason as the repair hint: this compile decides whether the worker accepts its own output, so
        // it must see what the verify will see. Without the deps loaded it accepts a file the verify then
        // rejects, and the round is spent discovering that.
        await preloadItemTypecheckDeps(pipelineItem.type, pipelineItem.outputPath, defsContent);
        let compileErrors = [
            ...await compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName),
            ...(typecheckPath ? await compileMlsPathAndGetErrors(typecheckPath) : []),
            // bugpage21: catch the compiles-cleanly template defect in the TIGHTEST loop — right after this
            // worker saved its own .ts — instead of waiting for the phase verify round.
            ...(pipelineItem.type === 'l2_page' || pipelineItem.type === 'l2_page_organism' ? [...collectPageTemplateHygieneIssues(sharedGuard.code), ...collectChartEventIssues(sharedGuard.code)] : []),
        ];
        if (compileErrors.length > 0 && sharedGuard.injected) {
            const reverted = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, sharedGuard.original);
            if (reverted) {
                compileErrors = [
                    ...await compileAndGetErrors(parsed.project, parsed.level, parsed.folder, parsed.shortName),
                    ...(typecheckPath ? await compileMlsPathAndGetErrors(typecheckPath) : []),
                ];
            }
        }
        const studioDiagnostics = consumeMaterializeStudioMessages();
        // Which shared context this item was generated against (recorded by readContextSections). It
        // goes in the trace on EVERY outcome, so a raw-ts fallback is auditable instead of silent.
        const contextNote = consumeContextTrace(pipelineItem.outputPath);
        if (compileErrors.length > 0) {
            const checkedFiles = typecheckPath ? `${pipelineItem.outputPath} + ${typecheckPath}` : pipelineItem.outputPath;
            const traceMsg = `compile/typecheck failed for ${checkedFiles}${contextNote ? ` [${contextNote}]` : ''}:\n${compileErrors.slice(0, 8).join('\n')}`;
            return [mkFailureStatus(context, parentStep, step, hookSequential, repairRun, withStudioDiagnostics(traceMsg, studioDiagnostics), true)];
        }
        // Persist the compiled .d.ts of a freshly materialized shared so downstream page items (and
        // the CLI runtime) read the same authoritative context from disk. Best-effort: never blocks.
        if (pipelineItem.type === 'l2_shared')
            await persistSharedDtsArtifact(pipelineItem.outputPath);
        const completedNotes = [
            ...(contextNote ? [contextNote] : []),
            ...(studioDiagnostics.length ? [formatStudioDiagnostics(studioDiagnostics)] : []),
        ];
        return [mkStatus(context, parentStep, step, hookSequential, 'completed', completedNotes.length ? completedNotes.join('. ') : undefined, 'input_output')];
    }
    catch (error) {
        const message = formatError('afterPromptStep', error);
        console.error(`[${agent.agentName}] ${message}`);
        return [mkFailureStatus(context, parentStep, step, hookSequential, isRepairRun(step.prompt), message)];
    }
}
function createPromptReadyIntent(context, parentStep, hookSequential, rawArgs, genContext, repairHint, skeleton, sharedTemplate) {
    // The args of the slot travel VERBATIM: the server matches the waiting slot by exact string
    // (`q.args === args`), so re-serializing the parsed object silently changed the key order on a
    // repair ({planId, defPath, itemId, attempt} became {planId, defPath, attempt, itemId}) and the
    // fan-out slot was never found — the round stayed forever in waiting_human_input. The queued
    // string is by definition the one the server compares, and the phase never puts a repair hint in
    // it (it carries only {planId, defPath, itemId, attempt}), so nothing has to be stripped here.
    const args = rawArgs;
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(genContext.skillSections, genContext.pipelineItem.outputPath, DEFAULT_MODEL_TYPE),
        // The skeleton travels only on the FIRST attempt: on a repair the file on disk already is the
        // skeleton filled in, and re-sending the empty one would invite a rewrite from scratch.
        // The shared template travels on repair too: the current file is in the hint; the scaffold is
        // what the four scenary members must look like.
        humanPrompt: buildHumanPrompt(trimDefinitionForPrompt(genContext.pipelineItem.type, genContext.definitionData), genContext.contextSections, genContext.pipelineItem.outputPath, repairHint, repairHint ? undefined : skeleton, sharedTemplate),
        tools: [GEN_TOOL],
        toolChoice: { type: 'function', function: { name: GEN_TOOL_NAME } },
    };
}
async function sharedTemplateForLlm(pipelineItem, definitionData) {
    const contractTsPath = isRecord(definitionData) && isRecord(definitionData.contractRef) && typeof definitionData.contractRef.tsPath === 'string'
        ? definitionData.contractRef.tsPath
        : '';
    const contractSource = contractTsPath ? await getContentByMlsPath(contractTsPath) : null;
    if (!contractSource)
        return undefined;
    const previousSource = await getContentByMlsPath(pipelineItem.outputPath);
    const template = sharedLlmFallbackTemplate(pipelineItem.outputPath, definitionData, contractSource, previousSource ?? undefined);
    if (!template.code)
        return undefined;
    return { code: template.code, mode: template.mode };
}
async function applySharedScenaryGuard(pipelineItem, definitionData, code) {
    const contractTsPath = isRecord(definitionData) && isRecord(definitionData.contractRef) && typeof definitionData.contractRef.tsPath === 'string'
        ? definitionData.contractRef.tsPath
        : '';
    const contractSource = contractTsPath ? (await getContentByMlsPath(contractTsPath)) ?? '' : '';
    const guarded = ensureSharedScenaryMembers(code, pipelineItem.outputPath, definitionData, contractSource);
    return { code: guarded.code, injected: guarded.injected, original: code };
}
// Rebuild the repair hint from disk for a fan-out repair slot: missing/empty artifact -> missing
// code hint; otherwise compile the generated .ts (+ its typecheck test) and feed the errors back.
/**
 * Deterministic skeleton for a page item, or undefined when it cannot be built — then the model writes the
 * file from scratch exactly as before, so an unmodelled shared never blocks a run.
 *
 * Reads the RAW shared .ts, never the compiled .d.ts the context carries: the page imports DTO types from
 * it. The i18n catalogue comes from the shared .defs.ts, which is where it is planned.
 */
async function pageSkeletonFor(pipelineItem, siblings, data) {
    if (pipelineItem.type !== 'l2_page' && pipelineItem.type !== 'l2_page_organism')
        return undefined;
    // The page item now declares the shared-dts ARTIFACT (web/shared/<page>Dts.txt); the raw .ts ref
    // the skeleton needs is derived from it. Old defs still declare the .ts directly.
    const sharedRef = (pipelineItem.dependsFiles ?? []).find(ref => isSharedRuntimeTsRef(ref))
        ?? (pipelineItem.dependsFiles ?? []).map(ref => sharedTsRefOfDtsArtifact(ref)).find((ref) => !!ref);
    if (!sharedRef)
        return undefined;
    const sharedSource = await getContentByMlsPath(sharedRef);
    if (!sharedSource)
        return undefined;
    const sharedDefsSource = await getContentByMlsPath(sharedRef.replace(/\.ts$/u, '.defs.ts'));
    const sharedDefsData = sharedDefsSource ? parseDefs(sharedDefsSource).data : undefined;
    // The organisms of a split page are the sibling items of the same defs — the page composes them and an
    // organism builds only its own file (paginaDividida.md §3).
    const organisms = siblings
        .filter(item => item.type === 'l2_page_organism' && item.organism)
        .map(item => ({
        n: Number(/_O(\d+)\.ts$/u.exec(item.outputPath)?.[1] ?? 0),
        organism: item.organism,
        bindings: item.bindings ?? [],
    }))
        .filter(item => item.n > 0)
        .sort((a, b) => a.n - b.n);
    const current = pipelineItem.type === 'l2_page_organism'
        ? organisms.find(item => item.organism === pipelineItem.organism)?.n
        : undefined;
    const pagePath = pipelineItem.type === 'l2_page_organism'
        ? pipelineItem.outputPath.replace(/_O\d+\.ts$/u, '.ts')
        : pipelineItem.outputPath;
    let composed = organisms;
    if (pipelineItem.type === 'l2_page' && organisms.length) {
        const present = new Set();
        for (const organism of organisms) {
            const ref = organismFileRef(pagePath, organism.n);
            const content = await getContentByMlsPath(ref);
            if (content && content.trim())
                present.add(ref);
        }
        composed = markMissingOrganisms(organisms, pagePath, ref => present.has(ref));
        for (const organism of composed) {
            if (!organism.missing)
                continue;
            await recordCfeDegradation(moduleOfMlsPath(pagePath), 'missing-organism', `organism _O${organism.n} (${organism.organism}) was not materialized`, pagePath);
        }
    }
    // The previous content of THIS file — the organism's own .ts when building an organism, so a split page
    // does not lose the translations that live in its organisms.
    const previousSource = (await getContentByMlsPath(pipelineItem.outputPath)) ?? undefined;
    const built = buildPageSkeleton({
        outputPath: pagePath, data, sharedTsRef: sharedRef, sharedSource, sharedDefsData, previousSource, organisms: composed, current,
    });
    if (!built.code) {
        await recordCfeDegradation(moduleOfMlsPath(pipelineItem.outputPath), 'skeleton-skip', String(built.reason || 'unknown'), pipelineItem.outputPath);
    }
    return built.code ?? undefined;
}
/**
 * On an output-cap failure, project the l4 workspace sections into a split plan and persist it.
 *
 * The plan is DERIVED, not decided: the l4 already declares the page's sections and the bffCall each
 * organism binds to (cfePageSplitPlan). Written here, in the slot that failed, because this is where the
 * page defs and the reason are both in hand; the phase verify is what turns it into steps.
 *
 * Best-effort: a page with no usable l4 simply keeps the plain failure, which the trace already explains.
 */
export async function writeSplitPlanFromL4(pipelineItem, data, reason, siblingBindings) {
    const parsed = parseMlsPath(pipelineItem.outputPath);
    if (!parsed)
        return false;
    const moduleName = parsed.folder.split('/')[0];
    const genome = parsed.folder.split('/').pop() || '';
    const wsSource = await getContentByMlsPath(`_${parsed.project}_/l4/${moduleName}/workspaces/${parsed.shortName}.defs.ts`);
    if (!wsSource)
        return false;
    const workspace = extractFirstExportedObject(wsSource);
    const sections = (isRecord(workspace) && Array.isArray(workspace.sections) ? workspace.sections : [])
        .filter(isRecord)
        .map(section => ({
        sectionId: String(section.sectionId ?? ''),
        organisms: (Array.isArray(section.organisms) ? section.organisms : []).filter(isRecord),
    }))
        .filter(section => section.sectionId);
    const sharedTs = (pipelineItem.dependsFiles ?? []).find(ref => isSharedRuntimeTsRef(ref))
        ?? (pipelineItem.dependsFiles ?? []).map(ref => sharedTsRefOfDtsArtifact(ref)).find((ref) => !!ref);
    const sharedDefsSource = sharedTs ? await getContentByMlsPath(sharedTs.replace(/\.ts$/u, '.defs.ts')) : null;
    const sharedData = sharedDefsSource ? parseDefs(sharedDefsSource).data : undefined;
    const bindings = bindingCommandsOf(data, siblingBindings, sharedData);
    const plan = buildSplitPlan(parsed.shortName, genome, sections, bindings, reason);
    if (!plan)
        return false;
    return saveArtifactTextByMlsPath(cfePipelineTraceMlsPath(parsed.project, moduleName, `frontend-page-split/${genome}`, `${parsed.shortName}.json`), `${JSON.stringify(plan, null, 2)}\n`);
}
/** First `export const X = { … }` of a defs — balanced braces, then JSON (the file is JSON.stringify output). */
function extractFirstExportedObject(source) {
    const at = source.search(/export const [A-Za-z0-9_]+ = \{/u);
    if (at < 0)
        return null;
    const start = source.indexOf('{', at);
    let depth = 0;
    for (let i = start; i < source.length; i++) {
        if (source[i] === '{')
            depth++;
        else if (source[i] === '}' && --depth === 0) {
            try {
                return JSON.parse(source.slice(start, i + 1));
            }
            catch {
                return null;
            }
        }
    }
    return null;
}
async function computeRepairHint(pipelineItem, planId, attempt) {
    const outputPath = pipelineItem.outputPath;
    const content = await getContentByMlsPath(outputPath);
    if (!content || !content.trim()) {
        return buildMissingCodeRepairHint(outputPath, `generated file missing or empty: ${outputPath}`);
    }
    // What the VERIFY actually saw, written by it for this exact slot. The recompute below covers the
    // compiler and the template hygiene; everything else (enum labels, selection controls, i18n block,
    // custom-element tag, contract fields, design tokens…) only exists here. Empty for a finalize
    // module-compile slot, whose planId is the round — that path is compile-driven and the recompute
    // below is the whole of it.
    const declaredFindings = await readMaterializeItemFindings(moduleOfMlsPath(outputPath), planId, attempt);
    // THE SAME preload the verify does, before the same compile. Without it the imports resolve loosely
    // and a cross-file TS2339 simply is not reported: the verify (which preloads) failed the item, the hint
    // (which did not) came back empty, and the model was asked to repair a file with no error in hand. It
    // returned an almost identical file three rounds running on one `project.clientName`. After T6 the
    // verify releases its models at the end of each round, so by the time the hint compiles the deps are
    // ALWAYS unloaded — the blindness stopped being intermittent and became certain.
    // Not released here: the rewrite this hint feeds compiles right after and needs the same models
    // loaded; the phase verify is the boundary that gives them back.
    const ownDefs = pipelineItem.defPath ? await getContentByMlsPath(pipelineItem.defPath) : null;
    await preloadItemTypecheckDeps(pipelineItem.type, outputPath, ownDefs);
    const errors = [...await compileMlsPathAndGetErrors(outputPath)];
    const testPath = testPathForOutputPath(outputPath);
    const testContent = await getContentByMlsPath(testPath);
    if (testContent && testContent.trim())
        errors.push(...await compileMlsPathAndGetErrors(testPath));
    // bugpage21: the phase verify also rejects TEMPLATE-HYGIENE defects (an invented module-level helper
    // rendered by name, which paints the function source on screen). Those are NOT compiler errors, and a
    // repair slot carries only {planId, defPath, attempt} — so recompute them from disk HERE too, or the
    // model would be asked to regenerate without ever seeing the remedy and would burn the round blind.
    // Safe to recompute: collectPageTemplateHygieneIssues is a pure function of the file text.
    if (pipelineItem.type === 'l2_page')
        errors.push(...collectPageTemplateHygieneIssues(content));
    for (const finding of declaredFindings)
        if (!errors.includes(finding))
            errors.push(finding);
    // `content` travels WITH the findings: a repair that does not carry the file it repairs is a first-pass
    // generation wearing an error list (see buildCompileRepairHint).
    return errors.length ? buildCompileRepairHint(outputPath, errors.slice(0, 12), content) : undefined;
}
/** `_102047_/l2/todo/web/shared/x.ts` -> `todo`. Empty when the ref is not an l2 module path. */
function moduleOfMlsPath(mlsPath) {
    const parts = String(mlsPath || '').split('/');
    const at = parts.indexOf('l2');
    const moduleName = at >= 0 ? parts[at + 1] ?? '' : '';
    return moduleName === 'trace' ? '' : moduleName;
}
async function buildGenContext(defPath, itemId) {
    const defsContent = await getContentByMlsPath(defPath);
    if (!defsContent)
        throw new Error(`[agentCfeMaterializeGen] defs not found: ${defPath}`);
    const parsed = parseDefs(defsContent);
    // A defs can carry N items (a split page: organisms + the page), so the slot says WHICH one it is.
    // Falling back to the first keeps a task queued before itemId existed meaning exactly what it meant.
    const pipelineItem = (itemId ? parsed.items.find(candidate => candidate.id === itemId) : null) ?? parsed.item;
    if (!pipelineItem)
        throw new Error(`[agentCfeMaterializeGen] pipeline item not found: ${itemId ?? '(first)'} in ${defPath}`);
    const skillSections = await readSections(pipelineItem.skills ?? [], 'skill');
    const contextSections = await readContextSections(pipelineItem);
    return { pipelineItem, siblings: parsed.items, definitionData: parsed.data, skillSections, contextSections };
}
// Context diet (flow.json materializationContextPolicy): for page items the shared base class is
// sent as its compiled .d.ts INSTEAD of the raw source — the compact, authoritative public surface
// (typed msg keys, properties, handlers). Resolution order: fresh persisted artifact
// (web/shared/<page>Dts.txt, declared in the page defs) -> compile on demand -> raw .ts fallback,
// each item recording which one it got (context=dts / context=raw-ts). The _102029_ runtime
// library files are likewise sent as compiled .d.ts (their implementation bodies are ~8k tokens
// of noise per shared item). designSystem.ts is summarized to token names inside
// buildContextSection.
const RUNTIME_102029_REFS = new Set(CONTRACTS_102029);
// Which context the shared base class actually reached this item as — 'context=dts' or
// 'context=raw-ts (reason)'. Recorded by readContextSections (beforePromptStep) and surfaced into
// the step trace by afterPromptStep, so the fallback stops being invisible (run02 102047: the .ts
// went out raw and nothing said so). Module-level and best-effort on purpose: both hooks of a
// fan-out slot run in the same client session; losing the note on a reload only loses the note.
const contextTraceByOutput = new Map();
function consumeContextTrace(outputPath) {
    const note = contextTraceByOutput.get(outputPath);
    contextTraceByOutput.delete(outputPath);
    return note;
}
async function readContextSections(pipelineItem) {
    const sections = [];
    for (const requestedPath of pipelineItem.dependsFiles ?? []) {
        for (const path of expandContextRef(requestedPath)) {
            // Declared shared-dts artifact (web/shared/<page>Dts.txt) — the page defs points at the
            // artifact itself since 27/ago, so nothing is swapped implicitly. Resolution: fresh artifact
            // -> compile on demand -> raw .ts fallback, and the choice is recorded for the step trace.
            if (isSharedDtsArtifactRef(path)) {
                const sharedTsPath = sharedTsRefOfDtsArtifact(path);
                if (!sharedTsPath)
                    continue;
                const resolved = await resolveSharedDts(sharedTsPath);
                if (resolved.dts) {
                    contextTraceByOutput.set(pipelineItem.outputPath, 'context=dts');
                    sections.push(buildSharedDtsSection(sharedTsPath, resolved.dts));
                }
                else {
                    const raw = await getContentByMlsPath(sharedTsPath);
                    if (!raw)
                        continue;
                    contextTraceByOutput.set(pipelineItem.outputPath, `context=raw-ts (${resolved.reason})`);
                    sections.push(buildContextSection(sharedTsPath, trimSharedI18nForPageContext(raw)));
                }
                continue;
            }
            // Legacy defs (pre-27/ago) still declare the shared .ts and rely on the implicit swap.
            if (pipelineItem.type === 'l2_page' && isSharedRuntimeTsRef(path)) {
                const resolved = await resolveSharedDts(path);
                if (resolved.dts) {
                    contextTraceByOutput.set(pipelineItem.outputPath, 'context=dts');
                    sections.push(buildSharedDtsSection(path, resolved.dts));
                    continue;
                }
                contextTraceByOutput.set(pipelineItem.outputPath, `context=raw-ts (${resolved.reason})`);
            }
            if (RUNTIME_102029_REFS.has(path)) {
                const dts = await getCompiledDtsByMlsPath(path);
                if (dts) {
                    sections.push(buildRuntimeDtsSection(path, dts));
                    continue;
                }
            }
            const content = await getContentByMlsPath(path);
            if (!content)
                continue;
            // Raw-source fallback for the shared: strip every non-default locale. The page needs the key NAMES
            // to reference them, not three translations of each string — 18KB of a 95KB shared on
            // projectDetailWorkspace. Same trim the CLI applies (i18n.md §12.1).
            const trimmed = pipelineItem.type === 'l2_page' && isSharedRuntimeTsRef(path)
                ? trimSharedI18nForPageContext(content)
                : content;
            sections.push(buildContextSection(path, trimmed));
        }
    }
    return sections;
}
async function persistSharedDtsArtifact(sharedTsPath) {
    const artifactPath = sharedDtsArtifactRef(sharedTsPath);
    if (!artifactPath)
        return;
    const dts = await getCompiledDtsByMlsPath(sharedTsPath);
    if (!dts)
        return;
    // Stamped with the source it came from: an artifact whose provenance cannot be proved is refused by
    // resolveSharedDts, so writing one unstamped would retire the artifact path altogether.
    const source = await getContentByMlsPath(sharedTsPath);
    await saveArtifactTextByMlsPath(artifactPath, source ? stampSharedDtsArtifact(dts, source) : dts);
}
// Persisted artifact first (readable by both runtimes), then compile on demand. The artifact is served
// only when its stamp proves it was derived from the shared .ts NOW ON DISK — see
// checkSharedDtsProvenance for why mtime cannot answer this. The reason travels with a null dts so the
// raw-ts fallback can SAY why it happened (context trace).
async function resolveSharedDts(sharedTsPath) {
    const artifactPath = sharedDtsArtifactRef(sharedTsPath);
    let reason = 'no artifact ref derivable';
    if (artifactPath) {
        const artifact = await getContentByMlsPath(artifactPath);
        if (artifact === null)
            reason = `artifact missing: ${artifactPath}`;
        else {
            const checked = checkSharedDtsProvenance(artifact, await getContentByMlsPath(sharedTsPath));
            if (checked.dts)
                return checked;
            reason = `${checked.reason}: ${artifactPath}`;
        }
    }
    const compiled = await getCompiledDtsByMlsPath(sharedTsPath);
    if (compiled)
        return { dts: compiled, reason: 'compiled on demand' };
    return { dts: null, reason: `${reason}; compile on demand failed` };
}
async function readSections(paths, kind) {
    void kind;
    const sections = [];
    for (const path of paths) {
        const content = await getContentByMlsPath(path);
        if (!content)
            continue;
        sections.push(`<!-- skill: ${path} -->\n${content}`);
    }
    return sections;
}
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    if (traceMsg && status === 'failed')
        console.error(`[${AGENT_NAME}] ${traceMsg}`);
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
// Failure policy (skills/collab_messages.md): a 'failed' PARALLEL child fails the whole task, so
// fan-out slots NEVER return 'failed'. Repair runs (attempt >= 2) must also be able to continue to
// the NEXT repair round, so they don't self-fail either. Every failure path here completes with a
// 'MATERIALIZE-FAILED: ' trace; the phase 'verify' step (agentCfeMaterializePhase, mode 'verify') is
// the completion gate — it runs bounded repair rounds with the compiler error in context
// (specAuraForge §11). Exhaustion is recorded as CLI-materialization pending because the CLI can
// continue from the generated artifacts without discarding the whole changeFrontend task.
function mkFailureStatus(context, parentStep, step, hookSequential, repairRun, detail, manualRerunHint = false) {
    // The output cap is not a code defect and a repair cannot fix it — the same prompt hits the same
    // ceiling. Say so in the trace, with the file to write, so the run is not read as a flaky failure.
    // KNOWN LIMIT: the verify still spends its repair rounds on this item, because it reads the artifact
    // from disk and never sees this reason (paginaDividida.md §4.1).
    const hint = isSplitWorthyFailure(detail) ? ' -> does not fit in one call: SPLIT this page; a repair cannot help.' : '';
    return mkStatus(context, parentStep, step, hookSequential, 'completed', `MATERIALIZE-FAILED: ${detail}${hint}`, 'input_output');
}
// Lenient attempt read for catch paths (raw may be missing or invalid JSON).
function isRepairRun(raw) {
    try {
        const parsed = raw ? JSON.parse(raw) : null;
        return isRecord(parsed) && typeof parsed.attempt === 'number' && parsed.attempt >= 2;
    }
    catch {
        return false;
    }
}
function withStudioDiagnostics(message, diagnostics = consumeMaterializeStudioMessages()) {
    if (!diagnostics.length)
        return message;
    return `${message}\n${formatStudioDiagnostics(diagnostics)}`;
}
function formatStudioDiagnostics(diagnostics) {
    return [
        'Studio diagnostics:',
        ...diagnostics.map(item => `- ${item.level}: ${item.message}`),
    ].join('\n');
}
function parseGenStepArgs(raw) {
    if (!raw)
        throw new Error('missing args');
    const parsed = JSON.parse(raw);
    if (!isRecord(parsed))
        throw new Error('args must be an object');
    const planId = readString(parsed.planId);
    const defPath = readString(parsed.defPath);
    if (!planId || !defPath)
        throw new Error('args missing planId or defPath');
    const attempt = typeof parsed.attempt === 'number' && Number.isInteger(parsed.attempt) ? parsed.attempt : undefined;
    const repairHint = readString(parsed.repairHint) || undefined;
    // WHICH item of the defs this slot builds. Absent on a task queued before split support: the slot then
    // resolves pipeline[0], which is what one-artifact-per-defs always meant.
    const itemId = readString(parsed.itemId) || undefined;
    return { planId, defPath, attempt, repairHint, itemId };
}
function readString(value) {
    return typeof value === 'string' ? value : '';
}
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function formatError(stage, error) {
    const message = error instanceof Error ? error.message : String(error);
    return `${stage}: ${message}`;
}
function describePayload(raw) {
    if (raw === null)
        return 'null';
    if (raw === undefined)
        return 'undefined';
    if (typeof raw === 'string')
        return `string(${raw.slice(0, 160)})`;
    if (typeof raw !== 'object')
        return typeof raw;
    if (Array.isArray(raw))
        return `array(${raw.length})`;
    const keys = Object.keys(raw).slice(0, 8);
    return `object keys=[${keys.join(',')}]`;
}
