/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/register/agentCfeRegisterFrontend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, registerGeneratedFrontendPages } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeRegisterFrontend',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/register',
        agentDescription: 'Register materialized frontend pages in config.json and drop leftover page preview HTML',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const result = await registerGeneratedFrontendPages();
        const trace = `pagesRegistered=${result.pagesRegistered.length}; skippedPages=${result.skippedPages.length}`;
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace)];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}] ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
