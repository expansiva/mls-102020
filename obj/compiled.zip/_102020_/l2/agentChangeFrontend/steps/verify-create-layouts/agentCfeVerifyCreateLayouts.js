/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/verify-create-layouts/agentCfeVerifyCreateLayouts.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, listCreateRunLayoutFailureTraces, verifyCreateRunPrimaryLayouts } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeVerifyCreateLayouts',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/verify-create-layouts',
        agentDescription: 'Fail the sequential creation barrier when a primary page layout was not saved',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const runId = parseRunId(step.prompt);
        const failures = verifyCreateRunPrimaryLayouts(runId);
        const layoutErrors = await listCreateRunLayoutFailureTraces(runId);
        if (failures.length > 0) {
            const details = layoutErrors.length ? `\n\nLayout worker errors:\n${layoutErrors.join('\n')}` : '';
            throw new Error(`Primary layout validation failed:\n${failures.join('\n')}${details}`);
        }
        const details = layoutErrors.length ? `\n\nLayout worker errors (non-primary variants):\n${layoutErrors.join('\n')}` : '';
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `All primary layouts were saved.${details}`)];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}] ${message}`);
        // This is deliberately sequential: a strict primary-layout failure must block materialization,
        // but must never mark a parallel child failed while the fan-out still has queued work.
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
function parseRunId(value) {
    const parsed = value ? JSON.parse(value) : {};
    const runId = typeof parsed.runId === 'string' ? parsed.runId : '';
    if (!runId)
        throw new Error('missing create execution runId');
    return runId;
}
