/// <mls fileReference="_102020_/l2/agentChangeFrontend/steps/scan/agentCfeCreateScanL4.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAddStepIntent, createAgentStepPayload, createUpdateStatusIntent, listCreateRunLayoutArgs, readCreateContext, startCreateRun } from '/_102020_/l2/agentChangeFrontend/helpers/cfeCreateShared.js';
export function createAgent() {
    return {
        agentName: 'agentCfeCreateScanL4',
        agentProject: 102020,
        agentFolder: 'agentChangeFrontend/steps/scan',
        agentDescription: 'Scan todoFrontend=toCreate owners (l4 read-only) and start create fan-out',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scanArgs = parseScanArgs(step.prompt);
        const createContext = await readCreateContext();
        if (createContext.pages.length === 0) {
            if (scanArgs.materialize !== false) {
                const materialize = createMaterializeStep(scanArgs, []);
                return [
                    createAddStepIntent(context, parentStep, materialize),
                    createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'No todoFrontend=toCreate owners. Queued materialization freshness check.'),
                ];
            }
            return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'No todoFrontend=toCreate owners.')];
        }
        const runId = `cfe-${context.message.orderAt}`;
        startCreateRun(runId, createContext);
        const layoutArgs = await listCreateRunLayoutArgs(runId);
        const pageArgs = createContext.pages.map(page => JSON.stringify({ pageId: page.pageId, runId }));
        const contractSharedFanout = createAgentStepPayload('create-contract-shared-fanout', 'agentCfeCreateContractShared', 'Criar contratos/shared {{completed}}/{{total}}, falhas {{failed}}', { planId: 'create-contract-shared-fanout' }, [], 'parallel_dynamic', 'in_progress');
        contractSharedFanout.interaction = {
            input: [{ type: 'system', content: '<!-- modelType: codefast -->' }],
            cost: 0,
            trace: [`cached one L4 create context; queued ${pageArgs.length} deterministic contract/shared item(s)`],
            payload: null,
        };
        const layoutFanout = createAgentStepPayload('create-layout-fanout', 'agentCfeCreateLayout', 'Criar layouts {{completed}}/{{total}}, falhas {{failed}}', { planId: 'create-layout-fanout' }, ['create-contract-shared-fanout'], 'parallel_dynamic', 'waiting_dependency');
        // A dependent parallel parent is unlocked directly into parallel dispatch. The backend requires
        // this interaction/input to exist before it can claim any child slot (runLLMStepParallel).
        layoutFanout.interaction = createParallelFanoutInteraction(`queued ${layoutArgs.length} pinned layout item(s)`);
        const reconcileFanout = createAgentStepPayload('reconcile-shared-fanout', 'agentCfeReconcileShared', 'Reconciliar shared {{completed}}/{{total}}, falhas {{failed}}', { planId: 'reconcile-shared-fanout' }, ['create-layout-fanout'], 'parallel_dynamic', 'waiting_dependency');
        reconcileFanout.interaction = createParallelFanoutInteraction(`queued ${pageArgs.length} shared reconciliation item(s)`);
        const verifyLayouts = createAgentStepPayload('verify-create-layouts', 'agentCfeVerifyCreateLayouts', 'Verificar layouts primarios', { planId: 'verify-create-layouts', runId }, ['reconcile-shared-fanout'], 'sequential', 'waiting_dependency');
        const intents = [
            createAddStepIntent(context, parentStep, contractSharedFanout, pageArgs),
            createAddStepIntent(context, parentStep, layoutFanout, layoutArgs.map(item => JSON.stringify(item))),
            createAddStepIntent(context, parentStep, reconcileFanout, pageArgs),
            createAddStepIntent(context, parentStep, verifyLayouts),
        ];
        if (scanArgs.materialize !== false) {
            const materialize = createMaterializeStep(scanArgs, ['verify-create-layouts']);
            intents.push(createAddStepIntent(context, parentStep, materialize));
        }
        intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Scanned L4 once; queued ${pageArgs.length} page contract/shared item(s), ${layoutArgs.length} pinned layout item(s) and reconciliation${scanArgs.materialize === false ? ' (defs-only).' : '.'}`));
        return intents;
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}] ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
function createParallelFanoutInteraction(trace) {
    return {
        input: [{ type: 'system', content: '<!-- deterministic parallel fan-out host -->' }],
        cost: 0,
        trace: [trace],
        payload: null,
    };
}
function parseScanArgs(prompt) {
    if (!prompt)
        return {};
    try {
        const parsed = JSON.parse(prompt);
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    }
    catch {
        return {};
    }
}
function createMaterializeStep(scanArgs, dependsOn) {
    return createAgentStepPayload('materialize-create-l2', 'agentCfeMaterializeL2', 'Materializar frontend L2', { planId: 'materialize-create-l2', force: scanArgs.forceMaterialize === true }, dependsOn, 'sequential', dependsOn.length > 0 ? 'waiting_dependency' : 'waiting_human_input');
}
