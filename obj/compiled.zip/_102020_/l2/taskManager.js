/// <mls fileReference="_102020_/l2/taskManager.ts" enhancement="_blank" />
// ─── Module-level store ───────────────────────────────────────────────
// Lives outside any component — survives DOM re-creation between knob navigations.
const _store = new Map();
const _listeners = new Set();
// ─── Write ───────────────────────────────────────────────────────────
export function setTask(key, task) {
    _store.set(key, task);
    _listeners.forEach(fn => fn());
}
// ─── Read ─────────────────────────────────────────────────────────────
export function getTask(key) {
    return _store.get(key);
}
export function getTasksByScope(scope) {
    const prefix = `${scope}:`;
    const result = new Map();
    _store.forEach((task, key) => { if (key.startsWith(prefix))
        result.set(key, task); });
    return result;
}
export function hasRunning(scope) {
    return [...getTasksByScope(scope).values()].some(t => t.status === 'running');
}
// ─── Subscription ────────────────────────────────────────────────────
// Returns an unsubscribe function. Call it in disconnectedCallback.
export function subscribeTaskManager(listener) {
    _listeners.add(listener);
    return () => _listeners.delete(listener);
}
