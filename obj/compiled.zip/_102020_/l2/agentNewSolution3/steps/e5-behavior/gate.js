/// <mls fileReference="_102020_/l2/agentNewSolution3/steps/e5-behavior/gate.ts" enhancement="_blank"/>
// E5 gate: pure functions only (no stor access). Entity fields/statusEnum arrive as
// parameters (Ns3E5EntityDefsInfo) so tests run without the browser runtime. isRecord and
// sameStringSet are local on purpose: importing them (ns3Fs / e3 gate) would pull libStor
// into the node test harness, which has no mls runtime.
import { errorIssue, warningIssue } from '/_102020_/l2/agentNewSolution3/helpers/ns3Gate.js';
export const E5_CLASSIFICATION_SCHEMA_VERSION = '2026-07-11-ns3-e5-v2';
export const NS3_OPERATION_KINDS = ['create', 'update', 'delete', 'query', 'view'];
// Explicit business decision for every managed (mdm/cadastral) entity: how records leave the base.
// 'delete' requires a delete operation; 'inactivate' requires a lifecycle state; 'immutable'
// requires a reason. Silent omission (the 102051 gap: no delete anywhere) is a gate error.
export const NS3_E5_DELETION_POLICIES = ['delete', 'inactivate', 'immutable'];
export const NS3_E5_EXECUTION_MODES = ['sequential', 'parallel_static', 'parallel_dynamic'];
export const NS3_E5_ACCESS_PATTERN_KINDS = ['list', 'getById', 'lookup', 'commandInput'];
export const NS3_E5_PAGINATIONS = ['none', 'optional', 'required'];
export const NS3_E5_SELECTIONS = ['none', 'single', 'multiple'];
// Shared source vocabulary for operation inputs AND contextResolution entries.
export const NS3_E5_SOURCES = [
    'userInput', 'actorSession', 'businessContext', 'currentWorkspace', 'selectedEntity',
    'activeLifecycleInstance', 'workflowState', 'routeParam', 'previousStepOutput', 'systemDefault',
];
// Highest first: capability priority = highest priority among the item featureRefs.
export const NS3_E5_PRIORITY_ORDER = ['now', 'soon', 'later', 'never'];
// copied from _102029_/l2/runtimeConfigTypes.ts L4_CONTEXT_ORIGIN_CATALOG — keep in sync.
// Local copy on purpose: importing runtimeConfigTypes could pull browser deps into the
// node test harness, and this gate must stay pure.
export const NS3_L4_CONTEXT_ORIGIN_CATALOG = {
    actorSession: ['actorSession.actorId', 'actorSession.scope'],
    businessContext: ['businessContext.activeCompanyId', 'businessContext.activeUnitId'],
    currentWorkspace: ['currentWorkspace.workspaceId'],
    systemDefault: ['systemDefault.now', 'systemDefault.uuid', 'systemDefault.locale'],
};
// Sources whose originRef must resolve to a saved entity field ('Entity.field').
const ENTITY_ORIGIN_SOURCES = ['selectedEntity', 'activeLifecycleInstance', 'workflowState', 'previousStepOutput'];
const QUERY_ACCESS_KINDS = ['list', 'getById', 'lookup'];
const WRITE_OPERATION_KINDS = ['create', 'update', 'delete'];
// ---------------------------------------------------------------------------
// prepare
// ---------------------------------------------------------------------------
export function prepareE5Classification(input, context) {
    const record = isRecord(input) ? input : {};
    const workflows = Array.isArray(record.workflows) ? record.workflows.filter(isRecord) : [];
    const operations = Array.isArray(record.operations) ? record.operations.filter(isRecord) : [];
    return {
        schemaVersion: E5_CLASSIFICATION_SCHEMA_VERSION,
        moduleName: readString(record.moduleName) || context.moduleName,
        createdAt: new Date().toISOString(),
        workflows: workflows.map(item => ({
            workflowId: readString(item.workflowId) || '',
            title: readString(item.title) || '',
            actorId: readString(item.actorId) || '',
            primaryEntity: readString(item.primaryEntity) || '',
            featureRefs: readStringArray(item.featureRefs),
            operationIds: readStringArray(item.operationIds),
        })),
        operations: operations.map(item => ({
            operationId: readString(item.operationId) || '',
            title: readString(item.title) || '',
            actorId: readString(item.actorId) || '',
            entity: readString(item.entity) || '',
            // Invalid values pass through so the schema check reports them (no silent fallback).
            kind: (readString(item.kind) || ''),
            featureRefs: readStringArray(item.featureRefs),
            ...(readString(item.workflowId) ? { workflowId: readString(item.workflowId) } : {}),
        })),
        managedEntities: (Array.isArray(record.managedEntities) ? record.managedEntities.filter(isRecord) : []).map(item => ({
            entity: readString(item.entity) || '',
            // Invalid values pass through so the schema check reports them (no silent fallback).
            deletionPolicy: (readString(item.deletionPolicy) || ''),
            ...(readString(item.inactivationState) ? { inactivationState: readString(item.inactivationState) } : {}),
            ...(readString(item.reason) ? { reason: readString(item.reason) } : {}),
        })),
    };
}
export function prepareE5Workflow(input) {
    const record = isRecord(input) ? input : {};
    const transitions = Array.isArray(record.transitions) ? record.transitions.filter(isRecord) : [];
    return {
        workflowId: readString(record.workflowId) || '',
        title: readString(record.title) || '',
        executionMode: (readString(record.executionMode) || ''),
        trigger: readString(record.trigger) || '',
        actors: readStringArray(record.actors),
        states: readStringArray(record.states),
        transitions: transitions.map(item => ({
            from: readString(item.from) || '',
            to: readString(item.to) || '',
            on: readString(item.on) || '',
            ...(readString(item.by) ? { by: readString(item.by) } : {}),
            ...(readString(item.guard) ? { guard: readString(item.guard) } : {}),
        })),
        operationIds: readStringArray(record.operationIds),
        entities: readStringArray(record.entities),
        rulesApplied: readStringArray(record.rulesApplied),
        story: readStory(record.story),
    };
}
export function prepareE5Operation(input) {
    const record = isRecord(input) ? input : {};
    const access = isRecord(record.accessPattern) ? record.accessPattern : {};
    const inputs = Array.isArray(record.inputs) ? record.inputs.filter(isRecord) : [];
    const contextResolution = Array.isArray(record.contextResolution) ? record.contextResolution.filter(isRecord) : [];
    return {
        operationId: readString(record.operationId) || '',
        title: readString(record.title) || '',
        actor: readString(record.actor) || '',
        entity: readString(record.entity) || '',
        kind: (readString(record.kind) || ''),
        reads: readStringArray(record.reads),
        writes: readStringArray(record.writes),
        rulesApplied: readStringArray(record.rulesApplied),
        story: readStory(record.story),
        accessPattern: {
            kind: (readString(access.kind) || ''),
            ...(readString(access.description) ? { description: readString(access.description) } : {}),
            entity: readString(access.entity) || '',
            keyField: readString(access.keyField) || '',
            ...(readStringArray(access.filters).length ? { filters: readStringArray(access.filters) } : {}),
            ...(readStringArray(access.sort).length ? { sort: readStringArray(access.sort) } : {}),
            pagination: (readString(access.pagination) || ''),
            selection: (readString(access.selection) || ''),
            output: readStringArray(access.output),
        },
        inputs: inputs.map(item => ({
            inputId: readString(item.inputId) || '',
            fieldRef: readString(item.fieldRef) || '',
            required: item.required === true,
            source: (readString(item.source) || ''),
            description: readString(item.description) || '',
        })),
        contextResolution: contextResolution.map(item => ({
            ...(readString(item.inputId) ? { inputId: readString(item.inputId) } : {}),
            targetRef: readString(item.targetRef) || '',
            source: (readString(item.source) || ''),
            // Empty string when missing so the schema (minLength 1) and the gate both report it.
            originRef: readString(item.originRef) || '',
            description: readString(item.description) || '',
        })),
        acceptanceAssertions: readStringArray(record.acceptanceAssertions),
    };
}
// ---------------------------------------------------------------------------
// deterministic attach (NEVER produced by the LLM)
// ---------------------------------------------------------------------------
export function priorityFromFeatures(featureRefs, features) {
    let bestIndex = -1;
    for (const ref of featureRefs) {
        const feature = features.find(item => item.featureId === ref);
        if (!feature)
            continue;
        const index = NS3_E5_PRIORITY_ORDER.indexOf(feature.priority);
        if (index >= 0 && (bestIndex < 0 || index < bestIndex))
            bestIndex = index;
    }
    return bestIndex >= 0 ? NS3_E5_PRIORITY_ORDER[bestIndex] : 'later';
}
export function attachWorkflowDeterministic(artifact, args) {
    return {
        ...artifact,
        pageId: args.classification.workflowId,
        capabilities: [{
                capabilityId: args.classification.workflowId,
                title: artifact.title,
                actor: artifact.actors[0] || args.classification.actorId,
                priority: priorityFromFeatures(args.classification.featureRefs, args.features),
            }],
        statusFrontend: 'toCreate',
        statusBackend: 'toCreate',
    };
}
export function attachOperationDeterministic(artifact, args) {
    const pageId = args.classification.workflowId || args.classification.operationId;
    const commandName = args.classification.operationId;
    // The capability represents the owning workflow when there is one (title and
    // priority follow the workflow); standalone operations carry their own capability.
    const capabilityRefs = args.owningWorkflow ? args.owningWorkflow.featureRefs : args.classification.featureRefs;
    return {
        ...artifact,
        pageId,
        commandName,
        bffName: `${args.moduleName}.${pageId}.${commandName}`,
        capability: {
            capabilityId: pageId,
            title: args.owningWorkflow ? args.owningWorkflow.title : artifact.title,
            actor: args.classification.actorId,
            priority: priorityFromFeatures(capabilityRefs, args.features),
        },
        statusFrontend: 'toCreate',
        statusBackend: 'toCreate',
    };
}
// ---------------------------------------------------------------------------
// invariants
// ---------------------------------------------------------------------------
export function validateE5Classification(artifact, context) {
    const issues = [];
    const featureIds = new Set(context.features.map(item => item.featureId));
    const workflowIds = new Set(artifact.workflows.map(item => item.workflowId));
    const operationIds = new Set(artifact.operations.map(item => item.operationId));
    if (artifact.moduleName !== context.moduleName) {
        issues.push(errorIssue('classification.moduleName.mismatch', `moduleName must be "${context.moduleName}", got "${artifact.moduleName}"`));
    }
    const allIds = new Set();
    for (const id of [...artifact.workflows.map(item => item.workflowId), ...artifact.operations.map(item => item.operationId)]) {
        if (allIds.has(id))
            issues.push(errorIssue('classification.id.duplicate', `duplicated id "${id}" across workflows+operations`, id));
        allIds.add(id);
    }
    for (const workflow of artifact.workflows) {
        if (!context.actorIds.includes(workflow.actorId)) {
            issues.push(errorIssue('classification.actor.unknown', `workflow ${workflow.workflowId}: actorId "${workflow.actorId}" is not in the E4 roster`, workflow.workflowId));
        }
        if (!context.entityIds.includes(workflow.primaryEntity)) {
            issues.push(errorIssue('classification.entity.unknown', `workflow ${workflow.workflowId}: primaryEntity "${workflow.primaryEntity}" is not an E3 entity`, workflow.workflowId));
        }
        for (const operationId of workflow.operationIds) {
            if (!operationIds.has(operationId)) {
                issues.push(errorIssue('classification.workflow.operation.unknown', `workflow ${workflow.workflowId}: operationId "${operationId}" is not a declared operation`, workflow.workflowId));
            }
        }
        for (const ref of workflow.featureRefs) {
            if (!featureIds.has(ref)) {
                issues.push(warningIssue('classification.featureRef.unknown', `workflow ${workflow.workflowId}: featureRef "${ref}" is not an E2 feature`, workflow.workflowId));
            }
        }
    }
    for (const operation of artifact.operations) {
        if (!context.actorIds.includes(operation.actorId)) {
            issues.push(errorIssue('classification.actor.unknown', `operation ${operation.operationId}: actorId "${operation.actorId}" is not in the E4 roster`, operation.operationId));
        }
        if (!context.entityIds.includes(operation.entity)) {
            issues.push(errorIssue('classification.entity.unknown', `operation ${operation.operationId}: entity "${operation.entity}" is not an E3 entity`, operation.operationId));
        }
        if (operation.workflowId) {
            const owner = artifact.workflows.find(item => item.workflowId === operation.workflowId);
            if (!owner) {
                issues.push(errorIssue('classification.operation.workflow.unknown', `operation ${operation.operationId}: workflowId "${operation.workflowId}" is not a declared workflow`, operation.operationId));
            }
            else if (!owner.operationIds.includes(operation.operationId)) {
                issues.push(errorIssue('classification.operation.workflow.unlisted', `operation ${operation.operationId}: owning workflow ${operation.workflowId} does not list it in operationIds`, operation.operationId));
            }
        }
        for (const ref of operation.featureRefs) {
            if (!featureIds.has(ref)) {
                issues.push(warningIssue('classification.featureRef.unknown', `operation ${operation.operationId}: featureRef "${ref}" is not an E2 feature`, operation.operationId));
            }
        }
    }
    // Feature coverage: every non-never E2 feature must be realized by >=1 item.
    // Missing 'now' coverage blocks; soon/later coverage gaps only warn.
    const covered = new Set([
        ...artifact.workflows.flatMap(item => item.featureRefs),
        ...artifact.operations.flatMap(item => item.featureRefs),
    ]);
    for (const feature of context.features) {
        if (feature.priority === 'never' || covered.has(feature.featureId))
            continue;
        const message = `no workflow/operation featureRefs cover feature "${feature.featureId}" (priority ${feature.priority})`;
        if (feature.priority === 'now')
            issues.push(errorIssue('classification.feature.uncovered', message, feature.featureId));
        else
            issues.push(warningIssue('classification.feature.uncovered', message, feature.featureId));
    }
    if (workflowIds.size === 0 && artifact.operations.length === 0) {
        issues.push(errorIssue('classification.empty', 'classification declares no workflows and no operations'));
    }
    validateManagedEntities(artifact, context, issues);
    return { artifact, issues };
}
// Managed (mdm/cadastral) entities and the deletionPolicy requirement. Scope (refined after the
// 102048 run — kind must not force a single UX and core lifecycle entities exit via their own
// states):
//   - mdm entity with ANY write operation (standalone or workflow-owned): entry REQUIRED (error).
//   - non-mdm entity with standalone writes and NO statusEnum: entry required (error) — nothing
//     else models how records leave the base.
//   - non-mdm entity with standalone writes and a statusEnum: entry recommended (warning) — the
//     lifecycle usually models the exit (e.g. Project.cancelled).
// This is the guard against the 102051 gap (CRUDs without delete/inactivation, silently).
function validateManagedEntities(artifact, context, issues) {
    const standaloneWrites = new Map();
    const anyWrites = new Map();
    for (const operation of artifact.operations) {
        if (!WRITE_OPERATION_KINDS.includes(operation.kind))
            continue;
        const all = anyWrites.get(operation.entity) ?? new Set();
        all.add(operation.kind);
        anyWrites.set(operation.entity, all);
        if (operation.workflowId)
            continue;
        const kinds = standaloneWrites.get(operation.entity) ?? new Set();
        kinds.add(operation.kind);
        standaloneWrites.set(operation.entity, kinds);
    }
    // Entities whose policy must be validated: mdm with any write + entities with standalone writes.
    const underManagement = new Map(standaloneWrites);
    for (const [entity, kinds] of anyWrites) {
        if (context.entityKinds[entity] === 'mdm' && !underManagement.has(entity)) {
            underManagement.set(entity, kinds);
        }
    }
    const declared = new Map(artifact.managedEntities.map(item => [item.entity, item]));
    for (const [entity, kinds] of underManagement) {
        const policy = declared.get(entity);
        if (!policy) {
            const isMdm = context.entityKinds[entity] === 'mdm';
            const hasLifecycle = (context.entityDefs[entity]?.statusEnum || []).length > 0;
            const message = `entity "${entity}" has write operations but no managedEntities entry — declare its deletionPolicy (delete | inactivate | immutable)`;
            if (isMdm || !hasLifecycle)
                issues.push(errorIssue('classification.managedEntity.missing', message, entity));
            else
                issues.push(warningIssue('classification.managedEntity.missing', `${message}; its statusEnum may already model the exit — declare it explicitly if so (inactivate)`, entity));
            continue;
        }
        if (policy.deletionPolicy === 'delete' && !kinds.has('delete')) {
            issues.push(errorIssue('classification.managedEntity.delete.missing', `entity "${entity}" declares deletionPolicy "delete" but has no standalone delete operation`, entity));
        }
        if (policy.deletionPolicy === 'inactivate') {
            const state = policy.inactivationState || '';
            if (!state) {
                issues.push(errorIssue('classification.managedEntity.inactivation.missing', `entity "${entity}" declares deletionPolicy "inactivate" but no inactivationState`, entity));
            }
            else {
                const defs = context.entityDefs[entity];
                if (!defs) {
                    issues.push(warningIssue('classification.managedEntity.inactivation.unverified', `entity "${entity}": no defs on disk; inactivationState "${state}" cannot be verified`, entity));
                }
                else if (!(defs.statusEnum || []).includes(state)) {
                    issues.push(errorIssue('classification.managedEntity.inactivation.unknown', `entity "${entity}": inactivationState "${state}" is not in the entity statusEnum [${(defs.statusEnum || []).join(', ')}]`, entity));
                }
            }
            if (!kinds.has('update')) {
                issues.push(errorIssue('classification.managedEntity.inactivation.noUpdate', `entity "${entity}" declares deletionPolicy "inactivate" but has no standalone update operation to change the state`, entity));
            }
        }
        if (policy.deletionPolicy === 'immutable') {
            if (!(policy.reason || '').trim()) {
                issues.push(errorIssue('classification.managedEntity.immutable.reason', `entity "${entity}" declares deletionPolicy "immutable" without a business reason`, entity));
            }
            if (kinds.has('delete')) {
                issues.push(errorIssue('classification.managedEntity.immutable.conflict', `entity "${entity}" declares deletionPolicy "immutable" but has a standalone delete operation`, entity));
            }
        }
        // Management completeness: an entity under management needs create+update (browse/query is
        // checked downstream by the workspace derivation, not here).
        if (!kinds.has('create')) {
            issues.push(warningIssue('classification.managedEntity.create.missing', `entity "${entity}" is under management but has no standalone create operation`, entity));
        }
    }
    for (const policy of artifact.managedEntities) {
        if (!context.entityIds.includes(policy.entity)) {
            issues.push(errorIssue('classification.managedEntity.entity.unknown', `managedEntities entry "${policy.entity}" is not an E3 entity`, policy.entity));
            continue;
        }
        if (!underManagement.has(policy.entity)) {
            issues.push(warningIssue('classification.managedEntity.unused', `managedEntities entry "${policy.entity}" has no write operations under management — entry is inert`, policy.entity));
        }
    }
}
/**
 * Operations listed in a workflow that neither create the lifecycle instance (the trigger) nor
 * cause any REAL transition (from !== to) do not belong to the workflow — they are management/
 * cadastral operations that must be standalone. Deterministic; runs at e5-finalize over the saved
 * workflow defs (transitions only exist after the per-workflow calls, so the classification gate
 * cannot see this).
 */
export function computeE5WorkflowDemotions(workflows, classification) {
    const kindById = new Map(classification.operations.map(operation => [operation.operationId, operation.kind]));
    const demotions = [];
    for (const workflow of workflows) {
        const realTransitionOns = new Set(workflow.transitions.filter(transition => transition.from !== transition.to).map(transition => transition.on));
        for (const operationId of workflow.operationIds) {
            if (kindById.get(operationId) === 'create')
                continue; // the trigger stays
            if (realTransitionOns.has(operationId))
                continue;
            demotions.push({ workflowId: workflow.workflowId, operationId });
        }
    }
    return demotions;
}
/** Rewrites the deterministic attach of a demoted operation: standalone pageId/bffName. */
export function demoteE5OperationDefs(defs, moduleName) {
    return {
        ...defs,
        pageId: defs.operationId,
        commandName: defs.operationId,
        bffName: `${moduleName}.${defs.operationId}.${defs.operationId}`,
    };
}
export function validateE5Workflow(artifact, context) {
    const issues = [];
    const states = new Set(artifact.states);
    const operationIds = new Set(artifact.operationIds);
    if (artifact.workflowId !== context.itemId) {
        issues.push(errorIssue('workflow.id.mismatch', `workflowId must be "${context.itemId}", got "${artifact.workflowId}"`));
    }
    if (!sameStringSet(artifact.operationIds, context.classification.operationIds)) {
        issues.push(errorIssue('workflow.operations.mismatch', `workflow ${artifact.workflowId}: operationIds must exactly equal the classification set [${context.classification.operationIds.join(', ')}]`));
    }
    for (const transition of artifact.transitions) {
        if (!states.has(transition.from)) {
            issues.push(errorIssue('workflow.transition.state.unknown', `workflow ${artifact.workflowId}: transition "from" state "${transition.from}" is not declared in states`));
        }
        if (!states.has(transition.to)) {
            issues.push(errorIssue('workflow.transition.state.unknown', `workflow ${artifact.workflowId}: transition "to" state "${transition.to}" is not declared in states`));
        }
        if (!operationIds.has(transition.on)) {
            issues.push(errorIssue('workflow.transition.operation.unknown', `workflow ${artifact.workflowId}: transition "on" "${transition.on}" is not one of the workflow operationIds`));
        }
        // Self-transitions are FORBIDDEN (102048 finding): "planning -> planning on updateProject" is
        // a cadastral edit dressed as a transition — it laundered management operations into workflows,
        // emptied managedEntities and created accidental state guards on data edits. An operation that
        // does not change the state does not belong to the workflow: drop the transition (creation is
        // the trigger, not a transition; data edits are standalone operations).
        if (transition.from === transition.to) {
            issues.push(errorIssue('workflow.transition.self', `workflow ${artifact.workflowId}: self-transition "${transition.from}" -> "${transition.to}" on ${transition.on} — transitions must change the state; remove it (creation is the workflow trigger; cadastral edits are standalone operations)`));
        }
    }
    // States must mirror the primary entity lifecycle (equal or subset of statusEnum).
    const primaryDefs = context.entityDefs[context.classification.primaryEntity];
    const statusEnum = primaryDefs?.statusEnum || [];
    if (statusEnum.length > 0) {
        for (const state of artifact.states) {
            if (!statusEnum.includes(state)) {
                issues.push(errorIssue('workflow.state.unknown', `workflow ${artifact.workflowId}: state "${state}" is not in ${context.classification.primaryEntity}.statusEnum [${statusEnum.join(', ')}]`, state));
            }
        }
    }
    else {
        issues.push(warningIssue('workflow.states.unverified', `workflow ${artifact.workflowId}: primary entity ${context.classification.primaryEntity} has no statusEnum; states cannot be verified`));
    }
    for (const actor of artifact.actors) {
        if (!context.actorIds.includes(actor)) {
            issues.push(errorIssue('workflow.actor.unknown', `workflow ${artifact.workflowId}: actor "${actor}" is not in the E4 roster`, actor));
        }
    }
    for (const entity of artifact.entities) {
        if (!context.entityIds.includes(entity)) {
            issues.push(errorIssue('workflow.entity.unknown', `workflow ${artifact.workflowId}: entity "${entity}" is not an E3 entity`, entity));
        }
    }
    for (const ruleId of artifact.rulesApplied) {
        if (!context.ruleIds.includes(ruleId)) {
            issues.push(warningIssue('workflow.rule.unknown', `workflow ${artifact.workflowId}: rulesApplied "${ruleId}" is not an E4 ruleId`, ruleId));
        }
    }
    return { artifact, issues };
}
export function validateE5Operation(defs, context) {
    const issues = [];
    if (defs.operationId !== context.itemId) {
        issues.push(errorIssue('operation.id.mismatch', `operationId must be "${context.itemId}", got "${defs.operationId}"`));
    }
    if (defs.kind !== context.classification.kind) {
        issues.push(errorIssue('operation.kind.mismatch', `operation ${defs.operationId}: kind "${defs.kind}" differs from the classification ("${context.classification.kind}")`));
    }
    if (!context.entityIds.includes(defs.entity)) {
        issues.push(errorIssue('operation.entity.unknown', `operation ${defs.operationId}: entity "${defs.entity}" is not an E3 entity`));
    }
    for (const entity of defs.reads) {
        if (!context.entityIds.includes(entity)) {
            issues.push(errorIssue('operation.reads.unknown', `operation ${defs.operationId}: reads entity "${entity}" is not an E3 entity`, entity));
        }
    }
    for (const entity of defs.writes) {
        if (!context.entityIds.includes(entity)) {
            issues.push(errorIssue('operation.writes.unknown', `operation ${defs.operationId}: writes entity "${entity}" is not an E3 entity`, entity));
        }
    }
    if (!context.entityIds.includes(defs.accessPattern.entity)) {
        issues.push(errorIssue('operation.accessPattern.entity.unknown', `operation ${defs.operationId}: accessPattern.entity "${defs.accessPattern.entity}" is not an E3 entity`));
    }
    validateKeyField(defs, context, issues);
    if (QUERY_ACCESS_KINDS.includes(defs.accessPattern.kind) && defs.accessPattern.output.length === 0) {
        issues.push(errorIssue('operation.accessPattern.output.empty', `operation ${defs.operationId}: accessPattern.kind "${defs.accessPattern.kind}" requires a non-empty output[]`));
    }
    if (defs.accessPattern.kind === 'commandInput' && defs.inputs.length === 0) {
        issues.push(errorIssue('operation.inputs.empty', `operation ${defs.operationId}: accessPattern.kind "commandInput" requires non-empty inputs`));
    }
    for (const input of defs.inputs) {
        if (!NS3_E5_SOURCES.includes(input.source)) {
            issues.push(errorIssue('operation.input.source.invalid', `operation ${defs.operationId}: input "${input.inputId}" source "${input.source}" is not a valid source`, input.inputId));
        }
        if (input.required && (!input.inputId || !input.fieldRef || !input.source)) {
            issues.push(errorIssue('operation.input.incomplete', `operation ${defs.operationId}: required input must declare inputId, fieldRef and source`, input.inputId));
        }
        validateFieldRef(defs.operationId, `input "${input.inputId}"`, input.fieldRef, context, issues);
    }
    for (const resolution of defs.contextResolution) {
        if (!NS3_E5_SOURCES.includes(resolution.source)) {
            issues.push(errorIssue('operation.context.source.invalid', `operation ${defs.operationId}: contextResolution "${resolution.targetRef}" source "${resolution.source}" is not a valid source`, resolution.targetRef));
            continue;
        }
        validateContextOriginRef(defs.operationId, resolution, context, issues);
    }
    if (WRITE_OPERATION_KINDS.includes(defs.kind) && defs.writes.length === 0) {
        issues.push(errorIssue('operation.writes.empty', `operation ${defs.operationId}: kind "${defs.kind}" requires non-empty writes`));
    }
    for (const ruleId of defs.rulesApplied) {
        if (!context.ruleIds.includes(ruleId)) {
            issues.push(warningIssue('operation.rule.unknown', `operation ${defs.operationId}: rulesApplied "${ruleId}" is not an E4 ruleId`, ruleId));
        }
    }
    // Recheck the deterministic attach (defense against code drift and LLM leakage).
    const expectedPageId = context.classification.workflowId || context.classification.operationId;
    const expectedCommand = context.classification.operationId;
    const expectedBff = `${context.moduleName}.${expectedPageId}.${expectedCommand}`;
    if (defs.pageId !== expectedPageId || defs.commandName !== expectedCommand || defs.bffName !== expectedBff) {
        issues.push(errorIssue('operation.bffName.mismatch', `operation ${defs.operationId}: pageId/commandName/bffName must be the deterministic values "${expectedPageId}"/"${expectedCommand}"/"${expectedBff}"`));
    }
    return { artifact: defs, issues };
}
// ---------------------------------------------------------------------------
// markdown
// ---------------------------------------------------------------------------
export function renderE5Markdown(classification, workflows, operations, options = {}) {
    const lines = [];
    lines.push(`# E5 — Workflows & Operations: ${classification.moduleName}`);
    lines.push('');
    lines.push(`- module: \`${classification.moduleName}\``);
    lines.push(`- workflows: ${workflows.length} / operations: ${operations.length}`);
    if (options.generatedAt)
        lines.push(`- generatedAt: ${options.generatedAt}`);
    lines.push('');
    lines.push('## Workflows');
    lines.push('');
    for (const workflow of workflows) {
        lines.push(`### ${workflow.workflowId} — ${workflow.title}`);
        lines.push('');
        lines.push(`- actor: ${workflow.actors.join(', ')} — trigger: ${workflow.trigger}`);
        lines.push(`- states: ${workflow.states.length} (${workflow.states.join(' → ')})`);
        lines.push(`- transitions: ${workflow.transitions.length}`);
        lines.push(`- operations: ${workflow.operationIds.join(', ')}`);
        lines.push('');
    }
    lines.push('## Operations');
    lines.push('');
    lines.push('| operationId | kind | entity | actor | bffName |');
    lines.push('| --- | --- | --- | --- | --- |');
    for (const operation of operations) {
        lines.push(`| ${operation.operationId} | ${operation.kind} | ${operation.entity} | ${operation.actor} | \`${operation.bffName}\` |`);
    }
    return lines.join('\n');
}
// ---------------------------------------------------------------------------
// private helpers
// ---------------------------------------------------------------------------
function validateKeyField(defs, context, issues) {
    const parts = defs.accessPattern.keyField.split('.');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
        issues.push(errorIssue('operation.accessPattern.key.unknown', `operation ${defs.operationId}: keyField "${defs.accessPattern.keyField}" must have the format "Entity.field"`));
        return;
    }
    const [entityId, fieldId] = parts;
    if (!context.entityIds.includes(entityId)) {
        issues.push(errorIssue('operation.accessPattern.key.unknown', `operation ${defs.operationId}: keyField entity "${entityId}" is not an E3 entity`));
        return;
    }
    const entityDefs = context.entityDefs[entityId];
    if (!entityDefs) {
        issues.push(warningIssue('operation.accessPattern.key.unverified', `operation ${defs.operationId}: keyField entity "${entityId}" has no defs on disk; field cannot be verified`));
        return;
    }
    if (!entityDefs.fields.some(field => field.fieldId === fieldId)) {
        issues.push(errorIssue('operation.accessPattern.key.unknown', `operation ${defs.operationId}: keyField field "${fieldId}" does not exist in ${entityId} defs`));
    }
}
// Ported from agentNewSolution2 validateContextResolutionRef: every contextResolution entry must
// carry a resolvable originRef — the server-side resolution recipe agentChangeBackend materializes.
function validateContextOriginRef(operationId, resolution, context, issues) {
    const { source, originRef, targetRef } = resolution;
    if (!originRef) {
        issues.push(errorIssue('operation.context.origin.missing', `operation ${operationId}: contextResolution "${targetRef || '?'}" is missing originRef (the server-side resolution recipe)`, targetRef));
        return;
    }
    if (source === 'actorSession' || source === 'businessContext' || source === 'currentWorkspace' || source === 'systemDefault') {
        const allowed = NS3_L4_CONTEXT_ORIGIN_CATALOG[source];
        if (!allowed.includes(originRef)) {
            issues.push(errorIssue('operation.context.origin.invalid', `operation ${operationId}: ${source} originRef "${originRef}" must be one of ${allowed.join(', ')}`, targetRef));
        }
        return;
    }
    if (ENTITY_ORIGIN_SOURCES.includes(source)) {
        const parts = originRef.split('.');
        if (parts.length !== 2 || !parts[0] || !parts[1]) {
            issues.push(errorIssue('operation.context.origin.unknown', `operation ${operationId}: ${source} originRef "${originRef}" must have the format "Entity.field"`, targetRef));
            return;
        }
        const [entityId, fieldId] = parts;
        if (!context.entityIds.includes(entityId)) {
            issues.push(errorIssue('operation.context.origin.unknown', `operation ${operationId}: ${source} originRef entity "${entityId}" is not an E3 entity`, targetRef));
            return;
        }
        const entityDefs = context.entityDefs[entityId];
        if (!entityDefs) {
            // Entity is known but its defs are not on disk yet: downgrade the field check to a warning.
            issues.push(warningIssue('operation.context.origin.unverified', `operation ${operationId}: ${source} originRef entity "${entityId}" has no defs on disk; field "${fieldId}" cannot be verified`, targetRef));
            return;
        }
        if (!entityDefs.fields.some(field => field.fieldId === fieldId)) {
            issues.push(errorIssue('operation.context.origin.unknown', `operation ${operationId}: ${source} originRef field "${fieldId}" does not exist in ${entityId} defs`, targetRef));
        }
        return;
    }
    if (source === 'routeParam' && !/^routeParam\.[A-Za-z0-9_-]+$/.test(originRef)) {
        issues.push(errorIssue('operation.context.origin.invalid', `operation ${operationId}: routeParam originRef "${originRef}" must be routeParam.<name>`, targetRef));
        return;
    }
    if (source === 'userInput' && !/^userInput\.[A-Za-z0-9_-]+$/.test(originRef)) {
        issues.push(errorIssue('operation.context.origin.invalid', `operation ${operationId}: userInput originRef "${originRef}" must be userInput.<name>`, targetRef));
    }
}
function validateFieldRef(operationId, label, fieldRef, context, issues) {
    const parts = fieldRef.split('.');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
        issues.push(errorIssue('operation.input.fieldRef.unknown', `operation ${operationId}: ${label} fieldRef "${fieldRef}" must have the format "Entity.field"`));
        return;
    }
    const [entityId, fieldId] = parts;
    if (!context.entityIds.includes(entityId)) {
        issues.push(errorIssue('operation.input.fieldRef.unknown', `operation ${operationId}: ${label} fieldRef entity "${entityId}" is not an E3 entity`));
        return;
    }
    const entityDefs = context.entityDefs[entityId];
    if (entityDefs && !entityDefs.fields.some(field => field.fieldId === fieldId)) {
        issues.push(warningIssue('operation.input.field.unknown', `operation ${operationId}: ${label} field "${fieldId}" does not exist in ${entityId} defs`));
    }
}
function readStory(value) {
    const record = isRecord(value) ? value : {};
    return {
        actor: readString(record.actor) || '',
        goal: readString(record.goal) || '',
        steps: readStringArray(record.steps),
        outcome: readString(record.outcome) || '',
    };
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
function readStringArray(value) {
    return Array.isArray(value)
        ? value.map(item => readString(item)).filter((item) => !!item)
        : [];
}
function sameStringSet(a, b) {
    if (a.length !== b.length)
        return false;
    const setB = new Set(b);
    return a.every(item => setB.has(item));
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
