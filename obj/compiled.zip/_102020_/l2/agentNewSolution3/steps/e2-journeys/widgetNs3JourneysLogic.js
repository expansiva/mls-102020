/// <mls fileReference="_102020_/l2/agentNewSolution3/steps/e2-journeys/widgetNs3JourneysLogic.ts" enhancement="_blank"/>
export const NS3_E2_PRIORITIES = ['now', 'soon', 'later', 'never'];
export function emptyNs3JourneysWidgetEdits() {
    return {
        featurePriorities: {},
        journeyBusinessRules: {},
        journeyNotes: {},
    };
}
export function hasNs3JourneysWidgetEdits(edits) {
    return Object.keys(edits.featurePriorities).length > 0
        || Object.keys(edits.journeyBusinessRules).length > 0
        || Object.keys(edits.journeyNotes).length > 0;
}
export function isNs3E2Priority(value) {
    return NS3_E2_PRIORITIES.includes(value);
}
export function parseNs3BusinessRulesText(text) {
    return text
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(Boolean);
}
export function serializeNs3BusinessRules(rules) {
    return rules.join('\n');
}
export function sameStringArray(left, right) {
    if (left.length !== right.length)
        return false;
    return left.every((value, index) => value === right[index]);
}
export function applyNs3JourneysWidgetEdits(artifact, edits) {
    const featurePriorities = edits.featurePriorities || {};
    const journeyBusinessRules = edits.journeyBusinessRules || {};
    const journeyNotes = edits.journeyNotes || {};
    return {
        ...artifact,
        actors: artifact.actors.map(actor => ({ ...actor })),
        journeys: artifact.journeys.map(journey => {
            const next = {
                ...journey,
                steps: journey.steps.map(step => ({ ...step, featureRefs: [...step.featureRefs] })),
                businessRules: [...journey.businessRules],
            };
            if (hasOwn(journeyBusinessRules, journey.journeyId))
                next.businessRules = [...(journeyBusinessRules[journey.journeyId] || [])];
            if (hasOwn(journeyNotes, journey.journeyId))
                next.notes = journeyNotes[journey.journeyId] || '';
            return next;
        }),
        features: artifact.features.map(feature => {
            const priority = featurePriorities[feature.featureId];
            return {
                ...feature,
                priority: isNs3E2Priority(priority) ? priority : feature.priority,
                actorIds: [...feature.actorIds],
            };
        }),
        decisions: artifact.decisions.map(decision => ({ ...decision })),
    };
}
export function buildNs3JourneysReviewPayload(input) {
    const edits = input.edits || emptyNs3JourneysWidgetEdits();
    return {
        type: 'checkpoint-journeys-answer',
        action: input.action,
        moduleName: input.artifact.moduleName,
        version: input.artifact.version,
        approved: input.action === 'approve',
        adjustment: (input.adjustment || '').trim(),
        edits: {
            featurePriorities: { ...edits.featurePriorities },
            journeyBusinessRules: cloneStringArrayRecord(edits.journeyBusinessRules),
            journeyNotes: { ...edits.journeyNotes },
        },
        changes: (input.changes || []).map(change => ({ ...change })),
        proposedArtifact: applyNs3JourneysWidgetEdits(input.artifact, edits),
    };
}
function cloneStringArrayRecord(record) {
    const clone = {};
    Object.keys(record).forEach(key => { clone[key] = [...(record[key] || [])]; });
    return clone;
}
function hasOwn(record, key) {
    return Object.prototype.hasOwnProperty.call(record, key);
}
