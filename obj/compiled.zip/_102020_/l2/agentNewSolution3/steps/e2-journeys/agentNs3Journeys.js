/// <mls fileReference="_102020_/l2/agentNewSolution3/steps/e2-journeys/agentNs3Journeys.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { NS3_AGENT_FOLDER, isRecord, listExistingModuleFolders, ns3L2File, ns3PipelineArtifactFileInfo, parseMaybeJson, readJsonArtifact, readStorText, writeJsonArtifact, writeMarkdownArtifact, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js';
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution3/helpers/ns3Ids.js';
import { runNs3Gate } from '/_102020_/l2/agentNewSolution3/helpers/ns3Gate.js';
import { approveNs3Step, createNs3Pipeline, markNs3DownstreamDirty, markNs3StepRunning, readNs3Pipeline, writeNs3Pipeline, } from '/_102020_/l2/agentNewSolution3/helpers/ns3Pipeline.js';
import { writeNs3Trace } from '/_102020_/l2/agentNewSolution3/helpers/ns3Trace.js';
import { prepareE2JourneysArtifact, renderE2JourneysMarkdown, validateE2JourneysInvariants, } from '/_102020_/l2/agentNewSolution3/steps/e2-journeys/gate.js';
const AGENT_NAME = 'agentNs3Journeys';
const TOOL_NAME = 'submitNs3Journeys';
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102020,
        agentFolder: `${NS3_AGENT_FOLDER}/steps/e2-journeys`,
        agentDescription: 'E2 - journeys and feature catalog for agentNewSolution3',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
        beforeClarificationStep,
        openStepView,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const hookArgs = args || step.prompt || JSON.stringify({ planId: 'e2-journeys' });
    const parsedArgs = parseArgs(hookArgs);
    if (parsedArgs.planId === 'checkpoint-journeys') {
        const moduleName = await resolveE2ReviewModule(parsedArgs.moduleName);
        const artifact = await readJsonArtifact(ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), true);
        if (!artifact)
            throw new Error(`[${AGENT_NAME}] e2-journeys.json not found for ${moduleName}`);
        return [checkpointPromptReady(context, parentStep, hookSequential, moduleName, artifact, hookArgs)];
    }
    const moduleName = await resolveE2Module(parsedArgs.moduleName);
    const draft = await readJsonArtifact(ns3PipelineArtifactFileInfo(moduleName, 'e1-draft', '.json'), true);
    if (!draft)
        throw new Error(`[${AGENT_NAME}] e1-draft.json not found for ${moduleName}`);
    const previous = parsedArgs.adjustment || parsedArgs.retryContext || parsedArgs.reviewPayload
        ? await readJsonArtifact(ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys', '.json'), false)
        : null;
    const schema = await readE2Schema();
    const platform = await readNs3Text('skills', 'platform', '.md', true);
    const prompt = await readNs3Text('steps/e2-journeys', 'prompt', '.md', true);
    const humanPrompt = [
        '## E1 draft (only source)',
        JSON.stringify(draft, null, 2),
        '',
        parsedArgs.adjustment ? `## Adjustment request\n${parsedArgs.adjustment}\n` : '',
        parsedArgs.retryContext ? `## Gate retry context\n${parsedArgs.retryContext}\n` : '',
        previous ? `## Current E2 artifact\n${JSON.stringify(previous, null, 2)}\n` : '',
    ].filter(Boolean).join('\n');
    return [{
            type: 'prompt_ready',
            args: hookArgs,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task.PK,
            hookSequential,
            parentStepId: parentStep.stepId,
            systemPrompt: `${prompt.split('{{toolName}}').join(TOOL_NAME)}\n\n${platform}\n\n${buildToolInstruction()}`,
            humanPrompt,
            tools: [createToolSchema(schema)],
            toolChoice: { type: 'function', function: { name: TOOL_NAME } },
        }];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let moduleNameForTrace = null;
    try {
        const parsedArgs = parseArgs(step.prompt);
        if (parsedArgs.planId === 'checkpoint-journeys') {
            return handleCheckpointPromptResult(context, parentStep, step, hookSequential);
        }
        const output = extractE2Output(step.interaction?.payload?.[0]);
        if (output.status === 'failed') {
            return [updateStatus(context, parentStep, step, hookSequential, 'failed', output.trace.join('\n') || 'E2 journeys returned failed')];
        }
        const moduleName = parsedArgs.moduleName || readString(output.result.moduleName) || '';
        const draft = await readJsonArtifact(ns3PipelineArtifactFileInfo(normalizeModuleFolderName(moduleName), 'e1-draft', '.json'), true);
        const e1ActorIds = (draft?.actors || []).map(actor => actor.actorId);
        const artifact = prepareE2JourneysArtifact(output.result);
        moduleNameForTrace = artifact.moduleName;
        const previous = parsedArgs.adjustment || parsedArgs.retryContext || parsedArgs.reviewPayload
            ? await readJsonArtifact(ns3PipelineArtifactFileInfo(artifact.moduleName, 'e2-journeys', '.json'), false)
            : null;
        if ((parsedArgs.adjustment || parsedArgs.reviewPayload) && previous?.version) {
            artifact.version = Math.max(artifact.version || 1, previous.version + 1);
        }
        const gateInputs = {
            e1DraftCreatedAt: draft?.createdAt || '',
            adjustment: parsedArgs.adjustment || '',
            retryContext: parsedArgs.retryContext || '',
            reviewPayload: parsedArgs.reviewPayload || null,
        };
        const schema = await readE2Schema();
        let pipeline = await readNs3Pipeline(artifact.moduleName) || createNs3Pipeline(artifact.moduleName);
        pipeline = markNs3StepRunning(pipeline, 'e2-journeys', gateInputs);
        const gate = await runNs3Gate({
            stepId: 'e2-journeys',
            schema,
            artifact,
            inputs: gateInputs,
            pipeline,
            validate: item => validateE2JourneysInvariants(item, { e1ActorIds }),
        });
        if (gate.pipeline)
            pipeline = gate.pipeline;
        await writeNs3Pipeline(pipeline);
        const attempt = parsedArgs.retryAttempt || gate.attempts;
        const markdown = renderE2JourneysMarkdown(artifact, {
            previous,
            adjustment: parsedArgs.adjustment,
            retryContext: parsedArgs.retryContext,
            generatedAt: new Date().toISOString(),
        });
        if (parsedArgs.adjustment || parsedArgs.reviewPayload) {
            await writeJsonArtifact(ns3PipelineArtifactFileInfo(artifact.moduleName, `e2-journeys.v${artifact.version}`, '.json'), artifact);
            await writeMarkdownArtifact(ns3PipelineArtifactFileInfo(artifact.moduleName, `e2-journeys.v${artifact.version}`, '.md'), markdown);
        }
        await writeJsonArtifact(ns3PipelineArtifactFileInfo(artifact.moduleName, 'e2-journeys', '.json'), artifact);
        await writeMarkdownArtifact(ns3PipelineArtifactFileInfo(artifact.moduleName, 'e2-journeys', '.md'), markdown);
        if (!gate.ok) {
            const traceMsg = gate.errors.map(issue => `${issue.code}: ${issue.message}`).join('\n');
            await writeNs3Trace(moduleNameForTrace, 'e2-journeys', AGENT_NAME, attempt, { artifact, gate, retryContext: gate.retryContext }, traceMsg);
            const intents = [updateStatus(context, parentStep, step, hookSequential, 'failed', traceMsg)];
            if (attempt < 2)
                intents.unshift(addGateRetryStep(context, parentStep, artifact.moduleName, gate.retryContext || traceMsg));
            return intents;
        }
        await writeNs3Trace(artifact.moduleName, 'e2-journeys', AGENT_NAME, attempt, { artifact, gate });
        if (parsedArgs.afterAdjustment) {
            await appendE2AuditEvent(artifact.moduleName, {
                eventId: createAuditEventId('adjustment-generated'),
                at: new Date().toISOString(),
                kind: 'adjustment-generated',
                moduleName: artifact.moduleName,
                fromVersion: previous?.version,
                toVersion: artifact.version,
                summary: parsedArgs.adjustment || '',
            });
        }
        const intents = [updateStatus(context, parentStep, step, hookSequential, 'completed', `e2-journeys ready for ${artifact.moduleName}`, 'input_output')];
        if (parsedArgs.afterAdjustment || !hasStepWithPlanId(context, 'checkpoint-journeys')) {
            intents.unshift(addCheckpointReviewStep(context, parentStep, artifact.moduleName));
        }
        return intents;
    }
    catch (error) {
        const traceMsg = error instanceof Error ? error.message : String(error);
        if (moduleNameForTrace)
            await writeNs3Trace(moduleNameForTrace, 'e2-journeys', AGENT_NAME, 1, { stepId: step.stepId }, traceMsg);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', traceMsg)];
    }
}
function checkpointPromptReady(context, parentStep, hookSequential, moduleName, artifact, hookArgs) {
    return {
        type: 'prompt_ready',
        args: hookArgs,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildCheckpointSystemPrompt(moduleName),
        humanPrompt: [
            `Render the E2 journeys checkpoint for module "${moduleName}".`,
            `Current artifact version: ${artifact.version}.`,
            'Return only the clarification payload requested in the system prompt.',
        ].join('\n'),
    };
}
function buildCheckpointSystemPrompt(moduleName) {
    return `<!-- modelType: codefast -->

Return JSON only. Do not call tools. Do not explain.

Required payload:
{
  "type": "clarification",
  "json": {
    "planId": "checkpoint-journeys",
    "moduleName": "${moduleName}",
    "title": "Review E2 journeys"
  }
}`;
}
function handleCheckpointPromptResult(context, parentStep, step, hookSequential) {
    const result = normalizeCheckpointPayload(step.interaction?.payload?.[0]);
    if (!result.ok)
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', result.error)];
    return [];
}
function normalizeCheckpointPayload(payload) {
    const parsed = parseMaybeJson(payload);
    const result = isRecord(parsed) && parsed.type === 'flexible' ? parseMaybeJson(parsed.result) : parsed;
    if (!isRecord(result))
        return { ok: false, error: 'checkpoint-journeys did not return a payload object' };
    if (result.type === 'result')
        return { ok: false, error: readString(result.result) || 'checkpoint-journeys returned result error' };
    if (result.type !== 'clarification')
        return { ok: false, error: `checkpoint-journeys returned invalid type: ${String(result.type)}` };
    const json = parseMaybeJson(result.json);
    if (!isRecord(json) || json.planId !== 'checkpoint-journeys')
        return { ok: false, error: 'checkpoint-journeys clarification json is invalid' };
    return { ok: true };
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    const parsed = parseCheckpointJson(json);
    if (parsed.planId !== 'checkpoint-journeys') {
        throw new Error(`[${AGENT_NAME}] unsupported clarification ${parsed.planId || '(missing)'}`);
    }
    await import('/_102020_/l2/agentNewSolution3/steps/e2-journeys/widgetNs3Journeys.js');
    const moduleName = await resolveE2ReviewModule(parsed.moduleName);
    const el = document.createElement('widget-ns3-journeys-102020');
    el.value = { moduleName, mode: 'new-module' };
    el.addEventListener('ns3-journeys-review', (event) => {
        const detail = event.detail;
        void applyJourneysReview(context, parentStep, step, hookSequential, detail)
            .catch(error => console.error(`[${agent.agentName}] ${error instanceof Error ? error.message : String(error)}`));
    });
    return el;
}
async function applyJourneysReview(context, parentStep, step, hookSequential, payload) {
    if (!context.task)
        throw new Error(`[${AGENT_NAME}] task invalid`);
    if (!payload || payload.type !== 'checkpoint-journeys-answer')
        throw new Error(`[${AGENT_NAME}] invalid journeys review payload`);
    const moduleName = normalizeModuleFolderName(payload.moduleName);
    // Anchor mutations on a non-terminal agent step: the backend rejects add-step /
    // update-status on a completed/failed parent (addTaskAISteps "Parent step cannot be modified").
    const mutationParent = findMutableParentStep(context, parentStep);
    const intents = [
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `checkpoint-journeys ${payload.action}`),
    ];
    if (payload.action === 'approve') {
        intents.unshift(resultStep(context, mutationParent, 'checkpoint-journeys-answer', ['checkpoint-journeys'], 'Journeys approved', {
            type: 'checkpoint-journeys-answer',
            moduleName,
            approved: true,
            version: payload.version,
            changes: payload.changes,
            edits: payload.edits,
        }));
        // Resume mode builds only the e2/checkpoint steps, so the phase-2 chain may not exist yet.
        // Add the missing steps BEFORE the completed answer result lands (open waiting_dependency
        // children also keep the parent chain from auto-completing at approval).
        intents.unshift(...(await buildMissingPhase2AddSteps(context, mutationParent)));
    }
    else if (payload.action === 'adjust') {
        const requestPlanId = `checkpoint-journeys-adjustment-request-${Date.now()}`;
        const adjustment = buildReviewAdjustmentText(payload);
        // Intent order matters: the OPEN adjustment step must land BEFORE the completed
        // result step. Otherwise setStepCompletedIfChildrenCompleted sees only completed
        // children (the pending clarification in interaction.payload is not counted),
        // auto-completes the parent chain, and the add-step below is rejected.
        intents.unshift(resultStep(context, mutationParent, requestPlanId, ['checkpoint-journeys'], 'Journeys adjustment request', {
            type: 'checkpoint-journeys-adjustment-request',
            moduleName,
            version: payload.version,
            adjustment: payload.adjustment,
            edits: payload.edits,
            changes: payload.changes,
        }));
        intents.unshift(addAdjustmentRunStep(context, mutationParent, moduleName, adjustment, requestPlanId, payload));
    }
    else {
        throw new Error(`[${AGENT_NAME}] unsupported journeys review action: ${String(payload.action)}`);
    }
    await applyIntentsAndRefresh(context, intents);
    if (payload.action === 'approve') {
        await approveJourneysCheckpoint(moduleName, payload);
    }
    else {
        await appendE2AuditEvent(moduleName, {
            eventId: createAuditEventId('adjustment-requested'),
            at: new Date().toISOString(),
            kind: 'adjustment-requested',
            moduleName,
            fromVersion: payload.version,
            summary: payload.adjustment || summarizeReviewChanges(payload),
            payload,
        });
    }
    await continuePoolingTask(context);
}
async function approveJourneysCheckpoint(moduleName, payload) {
    let pipeline = await readNs3Pipeline(moduleName) || createNs3Pipeline(moduleName);
    if (pipeline.steps['checkpoint-journeys']?.status === 'approved') {
        pipeline = markNs3DownstreamDirty(pipeline, 'e2-journeys');
    }
    pipeline = approveNs3Step(pipeline, 'e2-journeys', 'human', payload.version);
    pipeline = approveNs3Step(pipeline, 'checkpoint-journeys', 'human', payload.version);
    await writeNs3Pipeline(pipeline);
    await appendE2AuditEvent(moduleName, {
        eventId: createAuditEventId('approved'),
        at: new Date().toISOString(),
        kind: 'approved',
        moduleName,
        fromVersion: payload.version,
        toVersion: payload.version,
        summary: 'E2 journeys approved by human checkpoint.',
        payload,
    });
}
async function applyIntentsAndRefresh(context, intents) {
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200) {
        throw new Error(response?.msg || 'Error applying journeys checkpoint');
    }
    const ret = response;
    context.task = ret.task;
    if (ret.message)
        context.message = ret.message;
}
function resultStep(context, parentStep, planId, dependsOn, stepTitle, result) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify(result, null, 2),
            planning: { planId, dependsOn, executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
function addAdjustmentRunStep(context, parentStep, moduleName, adjustment, dependsOnPlanId, payload) {
    const runId = Date.now();
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: `Adjust E2 journeys v${payload.version}`,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: AGENT_NAME,
            prompt: JSON.stringify({ planId: 'e2-journeys', moduleName, adjustment, afterAdjustment: true, reviewPayload: payload }),
            rags: [],
            planning: { planId: `e2-journeys-adjustment-${runId}`, dependsOn: [dependsOnPlanId], executionMode: 'sequential', executionHost: 'client' },
        },
    };
}
function addCheckpointReviewStep(context, parentStep, moduleName) {
    const runId = Date.now();
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: 'Review E2 journeys',
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: AGENT_NAME,
            prompt: JSON.stringify({ planId: 'checkpoint-journeys', moduleName }),
            rags: [],
            planning: { planId: `checkpoint-journeys-review-${runId}`, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
        },
    };
}
async function resolveE2Module(requested) {
    if (requested) {
        const normalized = normalizeModuleFolderName(requested);
        const draft = await readJsonArtifact(ns3PipelineArtifactFileInfo(normalized, 'e1-draft', '.json'), false);
        if (draft)
            return normalized;
    }
    for (const module of listExistingModuleFolders()) {
        const draft = await readJsonArtifact(ns3PipelineArtifactFileInfo(module, 'e1-draft', '.json'), false);
        if (!draft)
            continue;
        const pipeline = await readNs3Pipeline(module);
        if (!pipeline?.steps['e2-journeys'] || pipeline.steps['e2-journeys'].status !== 'approved')
            return module;
    }
    throw new Error(`[${AGENT_NAME}] no module with an e1-draft ready for E2`);
}
async function resolveE2ReviewModule(requested) {
    if (requested) {
        const normalized = normalizeModuleFolderName(requested);
        const artifact = await readJsonArtifact(ns3PipelineArtifactFileInfo(normalized, 'e2-journeys', '.json'), false);
        if (artifact)
            return normalized;
    }
    for (const module of listExistingModuleFolders()) {
        const artifact = await readJsonArtifact(ns3PipelineArtifactFileInfo(module, 'e2-journeys', '.json'), false);
        if (!artifact)
            continue;
        const pipeline = await readNs3Pipeline(module);
        if (!pipeline?.steps['checkpoint-journeys'] || pipeline.steps['checkpoint-journeys'].status !== 'approved')
            return module;
    }
    return resolveE2Module(requested);
}
async function openStepView(agent, context, step) {
    await import('/_102020_/l2/agentNewSolution3/steps/e2-journeys/widgetNs3Journeys.js');
    const moduleName = await resolveOpenViewModule(step);
    const el = document.createElement('widget-ns3-journeys-102020');
    el.value = moduleName
        ? { moduleName, mode: 'new-module' }
        : { readOnly: true };
    return el;
}
async function resolveOpenViewModule(step) {
    const parsedArgs = parseArgs(step.prompt);
    if (parsedArgs.moduleName)
        return normalizeModuleFolderName(parsedArgs.moduleName);
    const payloadModule = readModuleNameFromE2Payload(step.interaction?.payload?.[0]);
    if (payloadModule)
        return payloadModule;
    for (const module of listExistingModuleFolders()) {
        const artifact = await readJsonArtifact(ns3PipelineArtifactFileInfo(module, 'e2-journeys', '.json'), false);
        if (artifact?.moduleName)
            return artifact.moduleName;
    }
    return '';
}
function readModuleNameFromE2Payload(payload) {
    try {
        const output = extractE2Output(payload);
        const moduleName = readString(output.result.moduleName);
        return moduleName ? normalizeModuleFolderName(moduleName) : '';
    }
    catch {
        return '';
    }
}
async function appendE2AuditEvent(moduleName, event) {
    const fileInfo = ns3PipelineArtifactFileInfo(moduleName, 'e2-journeys-audit', '.json');
    const existing = await readJsonArtifact(fileInfo, false);
    const events = Array.isArray(existing) ? existing : [];
    events.push(event);
    await writeJsonArtifact(fileInfo, events);
}
function createAuditEventId(kind) {
    return `${kind}-${Date.now()}`;
}
function buildReviewAdjustmentText(payload) {
    return [
        'Apply this human review to the current E2 journeys artifact.',
        'Keep unchanged IDs and text stable. Only change what is required by the review.',
        payload.adjustment ? `\nHuman adjustment prompt:\n${payload.adjustment}` : '',
        `\nWidget edits and change log:\n${JSON.stringify({ edits: payload.edits, changes: payload.changes }, null, 2)}`,
        `\nProposed artifact after direct widget edits:\n${JSON.stringify(payload.proposedArtifact, null, 2)}`,
    ].filter(Boolean).join('\n');
}
function summarizeReviewChanges(payload) {
    if (payload.adjustment)
        return payload.adjustment;
    if (!payload.changes.length)
        return 'Adjustment requested without explicit change log.';
    return payload.changes.map(change => change.summary).filter(Boolean).join('; ') || 'Adjustment requested from widget edits.';
}
function parseCheckpointJson(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? {
        planId: readString(parsed.planId),
        moduleName: readString(parsed.moduleName),
    } : {};
}
// Resume mode (agentNewSolution3.buildResumeTree) creates only the e2/checkpoint steps.
// On approval the phase-2 chain must exist so 'checkpoint-journeys-answer' can unlock e3.
async function buildMissingPhase2AddSteps(context, parentStep) {
    const { buildPhase2Steps, getRootPlan } = await import('/_102020_/l2/agentNewSolution3/agentNewSolution3.js');
    const steps = buildPhase2Steps(getRootPlan(context));
    return steps
        .filter(step => !hasStepWithPlanId(context, step.planning?.planId || ''))
        .map(step => ({
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    }));
}
// Same pattern as e1 (agentNs3Draft.ts): when the original parent was auto-completed
// by setStepCompletedIfChildrenCompleted, fall back to the nearest mutable agent step.
function findMutableParentStep(context, parentStep) {
    const current = findStepById(context, parentStep.stepId);
    if (isMutableAgentStep(current))
        return current;
    const ownerParentId = findParentStepId(context, parentStep.stepId);
    const ownerParent = ownerParentId ? findStepById(context, ownerParentId) : null;
    if (isMutableAgentStep(ownerParent))
        return ownerParent;
    const root = context.task?.iaCompressed?.nextSteps?.[0] || null;
    if (isMutableAgentStep(root))
        return root;
    return parentStep;
}
function isMutableAgentStep(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function findStepById(context, stepId) {
    if (!context.task)
        return null;
    return getAllSteps(context.task.iaCompressed?.nextSteps).find(item => item.stepId === stepId) || null;
}
function findParentStepId(context, childStepId) {
    if (!context.task)
        return null;
    for (const item of getAllSteps(context.task.iaCompressed?.nextSteps)) {
        if (item.nextSteps?.some(child => child.stepId === childStepId))
            return item.stepId;
        if (item.interaction?.payload?.some(child => child.stepId === childStepId))
            return item.stepId;
    }
    return null;
}
function hasStepWithPlanId(context, planId) {
    if (!context.task)
        return false;
    return getAllSteps(context.task.iaCompressed?.nextSteps).some(item => item.planning?.planId === planId);
}
function addGateRetryStep(context, parentStep, moduleName, retryContext) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: 'Retry E2 journeys gate',
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: AGENT_NAME,
            prompt: JSON.stringify({ planId: 'e2-journeys', moduleName, retryAttempt: 2, retryContext }),
            rags: [],
            planning: { planId: `e2-journeys-retry-${Date.now()}`, dependsOn: ['e2-journeys'], executionMode: 'sequential', executionHost: 'client' },
        },
    };
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
    // 'input_output' drops the step's LLM input/payload/trace from the task record once the
    // artifact is safely on disk (DynamoDB item limit is 400KB).
    if (cleaner)
        intent.cleaner = cleaner;
    return intent;
}
function createToolSchema(resultSchema) {
    return {
        type: 'function',
        function: {
            name: TOOL_NAME,
            description: 'Submit the E2 journeys and feature catalog.',
            parameters: {
                type: 'object',
                additionalProperties: false,
                required: ['status', 'result', 'trace'],
                properties: {
                    status: { enum: ['ok', 'failed'] },
                    result: resultSchema,
                    trace: { type: 'array', items: { type: 'string' } },
                },
            },
        },
    };
}
function extractE2Output(payload) {
    const parsed = parseMaybeJson(payload);
    if (!isRecord(parsed))
        throw new Error('missing E2 payload');
    if (parsed.type === 'result')
        throw new Error(readString(parsed.result) || 'E2 returned result error');
    const direct = tryNormalizeE2Envelope(parsed);
    if (direct)
        return direct;
    if (parsed.type === 'flexible') {
        const flexible = parseMaybeJson(parsed.result);
        const fromFlexible = tryNormalizeE2Envelope(flexible);
        if (fromFlexible)
            return fromFlexible;
        const fromFlexibleTool = tryExtractToolOutput(flexible);
        if (fromFlexibleTool)
            return fromFlexibleTool;
        const fromFlexibleOpenAi = tryExtractOpenAiToolCall(flexible);
        if (fromFlexibleOpenAi)
            return fromFlexibleOpenAi;
    }
    const fromTool = tryExtractToolOutput(parsed);
    if (fromTool)
        return fromTool;
    const fromOpenAi = tryExtractOpenAiToolCall(parsed);
    if (fromOpenAi)
        return fromOpenAi;
    throw new Error(`payload does not contain a recognized ${TOOL_NAME} output`);
}
function tryExtractToolOutput(value) {
    const record = parseMaybeJson(value);
    if (!isRecord(record) || record.toolName !== TOOL_NAME)
        return null;
    return normalizeToolArguments(record.arguments);
}
function normalizeToolArguments(value, depth = 0) {
    const args = parseMaybeJson(value);
    if (!isRecord(args))
        throw new Error('tool arguments must be an object');
    const direct = tryNormalizeE2Envelope(args);
    if (direct)
        return direct;
    if (args.arguments !== undefined && depth < 3)
        return normalizeToolArguments(args.arguments, depth + 1);
    throw new Error(`tool arguments do not contain ${TOOL_NAME} output`);
}
function tryExtractOpenAiToolCall(value) {
    if (!isRecord(value) || !Array.isArray(value.tool_calls))
        return null;
    for (const call of value.tool_calls) {
        if (!isRecord(call) || !isRecord(call.function) || call.function.name !== TOOL_NAME)
            continue;
        return normalizeToolArguments(call.function.arguments);
    }
    return null;
}
function tryNormalizeE2Envelope(value) {
    const output = parseMaybeJson(value);
    if (!isRecord(output) || output.result === undefined)
        return null;
    const result = parseMaybeJson(output.result);
    if (!isRecord(result) || isToolWrapper(result))
        return null;
    return {
        status: normalizePlannerStatus(output.status),
        result,
        trace: normalizeStringArray(output.trace),
    };
}
function isToolWrapper(value) {
    const record = parseMaybeJson(value);
    return isRecord(record) && record.toolName === TOOL_NAME && record.arguments !== undefined;
}
function normalizePlannerStatus(value) {
    if (value === undefined)
        return 'ok';
    if (value === 'ok' || value === 'failed')
        return value;
    if (value === 'needs_input')
        return 'ok';
    throw new Error(`invalid planner status: ${String(value)}`);
}
function normalizeStringArray(value) {
    return Array.isArray(value) ? value.map(item => readString(item)).filter((item) => !!item) : [];
}
async function readE2Schema() {
    const raw = await readNs3Text('schemas', 'e2-journeys.schema', '.json', true);
    const parsed = parseMaybeJson(raw);
    if (!isRecord(parsed))
        throw new Error('[readE2Schema] invalid schema');
    return parsed;
}
async function readNs3Text(folder, shortName, extension, required = false) {
    return readStorText(ns3L2File(`${NS3_AGENT_FOLDER}/${folder}`, shortName, extension), required);
}
function parseArgs(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? {
        planId: readString(parsed.planId),
        moduleName: readString(parsed.moduleName),
        adjustment: readString(parsed.adjustment),
        afterAdjustment: parsed.afterAdjustment === true,
        retryAttempt: typeof parsed.retryAttempt === 'number' ? parsed.retryAttempt : undefined,
        retryContext: readString(parsed.retryContext),
        reviewPayload: parsed.reviewPayload,
    } : {};
}
function buildToolInstruction() {
    return `
Call the "${TOOL_NAME}" tool with only these top-level arguments:
{
  "status": "ok" | "failed",
  "result": E2 artifact matching the JSON schema,
  "trace": []
}

Do not include "type", "toolName", or "arguments" in the tool arguments.
Use status "failed" only when the E1 draft is missing or unusable.
`;
}
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
