/// <mls fileReference="_102020_/l2/agentNewSolution3/helpers/ns3Pipeline.ts" enhancement="_blank"/>
import { normalizeModuleFolderName } from '/_102020_/l2/agentNewSolution3/helpers/ns3Ids.js';
export const NS3_PIPELINE_SCHEMA_VERSION = '2026-07-05-ns3-pipeline-v1';
export const NS3_PHASE1_STEP_IDS = [
    'e1-draft',
    'checkpoint-draft',
    'e2-journeys',
    'checkpoint-journeys',
];
export function createNs3Pipeline(moduleNameInput, stepIds = NS3_PHASE1_STEP_IDS) {
    const now = new Date().toISOString();
    const moduleName = normalizeModuleFolderName(moduleNameInput);
    const steps = {};
    for (const stepId of stepIds) {
        steps[stepId] = { status: 'pending', updatedAt: now };
    }
    return {
        schemaVersion: NS3_PIPELINE_SCHEMA_VERSION,
        flowId: 'agentNewSolution3',
        moduleName,
        createdAt: now,
        updatedAt: now,
        steps,
    };
}
export function ensureNs3Step(state, stepId) {
    const now = new Date().toISOString();
    if (!state.steps[stepId])
        state.steps[stepId] = { status: 'pending', updatedAt: now };
    return state.steps[stepId];
}
export function markNs3StepRunning(state, stepId, inputs) {
    const next = clonePipeline(state);
    const now = new Date().toISOString();
    const step = ensureNs3Step(next, stepId);
    step.status = 'running';
    step.dirty = false;
    if (inputs !== undefined)
        step.inputsHash = computeInputsHash(inputs);
    step.updatedAt = now;
    next.updatedAt = now;
    return next;
}
export function recordNs3GateResult(state, stepId, gate, inputs) {
    const next = clonePipeline(state);
    const now = new Date().toISOString();
    const step = ensureNs3Step(next, stepId);
    step.status = gate.ok ? (step.status === 'approved' ? 'approved' : 'pending') : 'gate_failed';
    step.dirty = false;
    if (inputs !== undefined)
        step.inputsHash = computeInputsHash(inputs);
    step.lastGate = { ok: gate.ok, checkedAt: now, errors: gate.errors, warnings: gate.warnings };
    step.updatedAt = now;
    next.updatedAt = now;
    return next;
}
export function approveNs3Step(state, stepId, approvedBy, artifactVersion) {
    const next = clonePipeline(state);
    const now = new Date().toISOString();
    const step = ensureNs3Step(next, stepId);
    step.status = 'approved';
    step.dirty = false;
    step.approvedAt = now;
    step.approvedBy = approvedBy;
    if (artifactVersion !== undefined)
        step.artifactVersion = artifactVersion;
    step.updatedAt = now;
    next.updatedAt = now;
    return next;
}
export function markNs3DownstreamDirty(state, fromStepId, order = NS3_PHASE1_STEP_IDS) {
    const next = clonePipeline(state);
    const start = order.indexOf(fromStepId);
    if (start < 0)
        return next;
    const now = new Date().toISOString();
    for (const stepId of order.slice(start + 1)) {
        const step = ensureNs3Step(next, stepId);
        if (step.status === 'approved') {
            step.dirty = true;
            step.updatedAt = now;
        }
    }
    next.updatedAt = now;
    return next;
}
export function nextNs3UnapprovedStep(state, order = NS3_PHASE1_STEP_IDS) {
    for (const stepId of order) {
        const step = state.steps[stepId];
        if (!step || step.status !== 'approved' || step.dirty)
            return stepId;
    }
    return null;
}
export function computeInputsHash(input) {
    const text = stableStringify(input);
    let hash = 5381;
    for (let index = 0; index < text.length; index += 1) {
        hash = ((hash << 5) + hash) ^ text.charCodeAt(index);
    }
    return `djb2:${(hash >>> 0).toString(16).padStart(8, '0')}`;
}
export async function readNs3Pipeline(moduleName) {
    const { ns3PipelineFileInfo, readJsonArtifact } = await import('/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js');
    return readJsonArtifact(ns3PipelineFileInfo(moduleName), false);
}
export async function writeNs3Pipeline(state) {
    const { ns3PipelineFileInfo, writeJsonArtifact } = await import('/_102020_/l2/agentNewSolution3/helpers/ns3Fs.js');
    return writeJsonArtifact(ns3PipelineFileInfo(state.moduleName), state);
}
function clonePipeline(state) {
    return JSON.parse(JSON.stringify(state));
}
function stableStringify(value) {
    if (value === null || typeof value !== 'object')
        return JSON.stringify(value);
    if (Array.isArray(value))
        return `[${value.map(stableStringify).join(',')}]`;
    const record = value;
    return `{${Object.keys(record).sort().map(key => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(',')}}`;
}
