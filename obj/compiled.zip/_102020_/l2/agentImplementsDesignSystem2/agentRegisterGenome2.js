/// <mls fileReference="_102020_/l2/agentImplementsDesignSystem2/agentRegisterGenome2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { registerPageGenome } from '/_102020_/l2/dsMatch/registerPageGenome.js';
import { recordUsedMolecules } from '/_102020_/l2/dsMatch/recordResolvedMolecules.js';
import { parseStepArgs, mkCompleted, mkFail } from '/_102020_/l2/agentImplementsDesignSystem2/planning.js';
export function createAgent() {
    return {
        agentName: 'agentRegisterGenome2',
        agentProject: 102020,
        agentFolder: 'agentImplementsDesignSystem2',
        agentDescription: 'Register the new page variation in module.ts (terminal, no LLM)',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    try {
        const a = parseStepArgs(args ?? step.prompt);
        const project = mls.actualProject || 0;
        if (!context.isTest) {
            // 1. Register the new variation in module.ts.
            await registerPageGenome(project, a.module, a.layout, a.ds, a.device);
            // 2. Record ONLY the molecules the pages actually used on the DS.
            await recordUsedMolecules(project, a.module, a.layout, a.ds, a.device);
        }
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        return [mkFail(context, parentStep, step, hookSequential, `[agentRegisterGenome2] ${error instanceof Error ? error.message : String(error)}`)];
    }
}
