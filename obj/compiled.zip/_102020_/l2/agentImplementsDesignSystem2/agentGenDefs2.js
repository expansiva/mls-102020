/// <mls fileReference="_102020_/l2/agentImplementsDesignSystem2/agentGenDefs2.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { buildWorkItem } from '/_102020_/l2/dsMatch/derivePaths.js';
import { buildPageDsStamp, renderDsVersionExport } from '/_102020_/l2/dsMatch/dsVersion.js';
import { parseStepArgs, readRawSource, saveFile, mkCompleted, mkFail } from '/_102020_/l2/agentImplementsDesignSystem2/planning.js';
export function createAgent() {
    return {
        agentName: 'agentGenDefs2',
        agentProject: 102020,
        agentFolder: 'agentImplementsDesignSystem2',
        agentDescription: 'Assemble the final page defs from origin defs + resolved molecules (Fase E)',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const a = parseStepArgs(args ?? step.prompt);
    const project = mls.actualProject || 0;
    const item = buildWorkItem(project, a.module, a.layout, a.ds, a.page, a.device);
    const origemSource = await readRawSource(item.defsOrigem);
    const novoSource = await readRawSource(item.defsDestino); // moleculeAssignments + usagePaths
    const humanPrompt = [
        `## Original page defs (page11) — mirror this exact structure\n\`\`\`typescript\n${origemSource}\n\`\`\``,
        `## Resolved molecules (ALREADY chosen — do NOT change them; just place them)\n\`\`\`typescript\n${novoSource}\n\`\`\``,
        `## Output path\n${item.defsDestino}`,
    ].join('\n\n');
    const continueParallel = {
        type: 'prompt_ready',
        args: args ?? step.prompt,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt,
        systemPrompt: system1,
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (payload?.type !== 'flexible' || !payload.result)
            throw new Error(`invalid payload: ${JSON.stringify(payload)}`);
        const out = payload.result;
        if (typeof out.srcFile !== 'string' || !out.srcFile)
            throw new Error('missing srcFile in result');
        const a = parseStepArgs(step.prompt);
        const project = mls.actualProject || 0;
        const item = buildWorkItem(project, a.module, a.layout, a.ds, a.page, a.device);
        // The LLM returns ONLY the clean merged defs. We append the molecule metadata exports
        // here, deterministically, by reading them from the NEW defs BEFORE we overwrite it
        // (so the terminal can record which molecules the page used). Guarded so we never
        // duplicate if the model already emitted them.
        let finalSrc = out.srcFile;
        if (!finalSrc.includes('export const moleculeAssignments')) {
            const tail = extractAssignmentsTail(await readRawSource(item.defsDestino));
            if (tail)
                finalSrc = `${finalSrc.replace(/\s*$/, '')}\n\n${tail}\n`;
        }
        if (!context.isTest) {
            // Stamp the DS version (effective rules hash + used-molecules hash) this page was
            // generated under, so staleness can be detected when the DS rules or the molecules
            // it uses later change. Built from finalSrc (which already carries moleculeAssignments).
            if (!finalSrc.includes('export const dsVersion')) {
                const stamp = await buildPageDsStamp(project, a.module, a.ds, a.page, new Date().toISOString(), finalSrc);
                finalSrc = `${finalSrc.replace(/\s*$/, '')}\n\n${renderDsVersionExport(stamp)}\n`;
            }
            await saveFile(item.defsDestino, finalSrc);
        }
        return [mkCompleted(context, parentStep, step, hookSequential)];
    }
    catch (error) {
        return [mkFail(context, parentStep, step, hookSequential, `[agentGenDefs2] ${error instanceof Error ? error.message : String(error)}`)];
    }
}
/** The molecule metadata exports from the NEW defs (moleculeAssignments + usagePaths). */
function extractAssignmentsTail(novoSource) {
    const idx = novoSource.indexOf('export const moleculeAssignments');
    return idx >= 0 ? novoSource.slice(idx).trim() : '';
}
const system1 = `
<!-- modelType: codereasoning -->

You must return ONLY a valid JSON object. No preamble, no markdown fences.
srcFile MUST be a single JSON string: escape newlines as \\n, tabs as \\t, double quotes
as \\", backslashes as \\\\. Never embed raw multiline code in the JSON value.

## Task
Produce the FINAL page defs for the new design system, given the ORIGINAL page defs
(page11) and the RESOLVED molecule assignments.

## Rules
- Mirror the ORIGINAL defs structure exactly (same exports, sections, organisms, fields).
- For each organism, inject a "molecules" array from moleculeAssignments (match by
  organismName): each entry { "group", "tag", "purpose", "import" } — copy ALL four
  fields exactly, including "import", from the matching moleculeAssignments molecule.
  Organisms with no assigned molecules stay unchanged.
- NEVER change/add/remove molecule choices — use EXACTLY the tags given. You only PLACE them.
- Do NOT add a "moleculesPaths" key. Instead, for EACH path in the input "usagePaths",
  append an entry to the pipeline's EXISTING "dependsFiles" array, in the form
  "<path>?key=skill" (e.g. "_102020_/l2/skills/molecules/groupViewData/usage.ts?key=skill").
  Keep ALL existing dependsFiles entries; do not duplicate; do not add the bare path
  without the "?key=skill" suffix.
- Repoint the first line /// <mls fileReference=...> and any outputPath/defPath from
  page11 to the Output path's folder (page{layout}{ds}); keep the page name the same.
- Keep the loose JSON-ish formatting of the original definition.
- Output ONLY the merged defs (header + definition + pipeline). Do NOT re-emit the
  resolved-molecules input, its header, or its moleculeAssignments/usagePaths/dsVersion
  exports — those are appended later by code.

## Output format
export type Output = {
  type: 'flexible';
  result: { srcFile: string };
};
`;
//#endregion
